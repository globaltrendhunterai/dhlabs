#!/bin/sh
# [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer v2.0]
# SKU: ONESHOT-05-OPENCLAW | Target: OpenClaw Autonomous Agent (Node Runtime + Telegram/Discord/Slack Bot Token .env Binding + LaunchAgent Auto-Runner Wiring)
# MINT_HMAC_SHA256=4d28998d6e53752de5b2be630a36271287ec4e3e5f5b5622938777e82837ef99
# BOUND_HOST_INODE=________________________________________________________________________________________________
set -u

SELF_PATH="$0"
case "$SELF_PATH" in
  /*) ;;
  *) SELF_PATH="$(pwd)/$SELF_PATH" ;;
esac
WORK_DIR="$(cd "$(dirname "$SELF_PATH")" && pwd)"
SELF_FILE="$(basename "$SELF_PATH")"

# ------------------------------------------------------------------------------
# 1. Hardware Machine-UUID & OS File System Inode / Hardlink Anti-Copy Verification
# ------------------------------------------------------------------------------
get_machine_uuid() {
  if [ -n "${ONESHOT_TEST_MACHINE_UUID:-}" ]; then
    echo "$ONESHOT_TEST_MACHINE_UUID"
    return
  fi
  if command -v ioreg >/dev/null 2>&1; then
    ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null | awk -F'"' '/IOPlatformUUID/{print $4; exit}'
    return
  fi
  if [ -f /etc/machine-id ]; then
    cat /etc/machine-id 2>/dev/null | head -n 1
    return
  fi
  uname -n
}

CUR_INODE=$(stat -f "%i" "$SELF_PATH" 2>/dev/null || stat -c "%i" "$SELF_PATH" 2>/dev/null)
CUR_DEV=$(stat -f "%d" "$SELF_PATH" 2>/dev/null || stat -c "%d" "$SELF_PATH" 2>/dev/null)
CUR_NLINK=$(stat -f "%l" "$SELF_PATH" 2>/dev/null || stat -c "%h" "$SELF_PATH" 2>/dev/null)
HOST_UUID=$(get_machine_uuid)
CURRENT_BIND_TOKEN="${HOST_UUID}:${CUR_DEV}:${CUR_INODE}"

shred_and_abort() {
  REASON="$1"
  echo "[SECURITY BLOCK] $REASON. Shredding unauthorized copy with 0x00..."
  dd if=/dev/zero of="$SELF_PATH" bs=1024 count=8 conv=notrunc 2>/dev/null || true
  rm -f "$SELF_PATH"
  exit 1
}

# Check 1-A: Block Hardlinks (nlink > 1)
if [ "$CUR_NLINK" != "1" ]; then
  shred_and_abort "Unauthorized hardlink detected (nlink=$CUR_NLINK != 1)"
fi

# Check 1-B: Detect Duplicate Copy in Same Folder (e.g., Finder 'Cmd+D' / ' copy' / identical seal header)
DUP_FOUND=$(python3 - "$WORK_DIR" "$SELF_FILE" "4d28998d6e53752de5b2be630a36271287ec4e3e5f5b5622938777e82837ef99" <<'EOF_DUP'
import os, sys
from pathlib import Path
wdir = Path(sys.argv[1])
self_name = sys.argv[2]
mint_hmac = sys.argv[3]
# Allow legitimate dual-format pair (.command and .bin) shipped inside the official zip,
# but block any user-created duplicate copy (*copy*, *복사본*, *(1)*, or 3rd file with same HMAC)
allowed = {f"OneShot_05_OpenClaw_Agent_Setup.command", f"OneShot_05_OpenClaw_Agent_Setup.bin", f"OneShot_05_OpenClaw_Agent_Setup_Windows.bat"}
for p in wdir.iterdir():
    if not p.is_file() or p.name == self_name:
        continue
    if p.name not in allowed:
        try:
            head = p.read_bytes()[:512].decode("utf-8", errors="ignore")
            if f"MINT_HMAC_SHA256={mint_hmac}" in head:
                print(p.name)
                sys.exit(0)
        except Exception:
            pass
EOF_DUP
)
if [ -n "$DUP_FOUND" ]; then
  shred_and_abort "Unauthorized duplicate installer copy detected in directory ($DUP_FOUND)"
fi

# Check 1-C: ToFU (Trust-On-First-Use) In-File & Ledger Inode Lock
# Allows the legitimate buyer's first execution after unzipping (and safe resume of the exact same inode),
# while 100% blocking any copied file (new Inode) or moved machine (new Machine UUID).
BOUND_VAL=$(python3 - "$SELF_PATH" <<'EOF_READ_BOUND'
import sys
from pathlib import Path
for line in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    if line.startswith("# BOUND_HOST_INODE="):
        val = line.split("=", 1)[1].rstrip("_")
        print(val if val else "__UNBOUND_FIRST_RUN__")
        break
EOF_READ_BOUND
)

LEDGER_DIR="${ONESHOT_LEDGER_DIR:-$WORK_DIR/.dhlabs_lock}"
mkdir -p "$LEDGER_DIR"
LEDGER_FILE="$LEDGER_DIR/ONESHOT-05-OPENCLAW.bound"

if [ "$BOUND_VAL" = "__UNBOUND_FIRST_RUN__" ]; then
  if [ -f "$LEDGER_FILE" ]; then
    RECORDED_BIND=$(cat "$LEDGER_FILE" 2>/dev/null || true)
    if [ -n "$RECORDED_BIND" ] && [ "$RECORDED_BIND" != "$CURRENT_BIND_TOKEN" ]; then
      shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: bound to $RECORDED_BIND, got $CURRENT_BIND_TOKEN)"
    fi
  fi
  # Atomically stamp current Machine-UUID + Device + Inode into fixed-width 96-byte slot (zero byte-offset shift!)
  python3 - "$SELF_PATH" "$CURRENT_BIND_TOKEN" <<'EOF_STAMP'
import sys
from pathlib import Path
p = Path(sys.argv[1])
tok = sys.argv[2]
padded = tok.ljust(96, "_")[:96]
txt = p.read_text(encoding="utf-8")
old_slot = "# BOUND_HOST_INODE=" + ("_" * 96)
new_slot = "# BOUND_HOST_INODE=" + padded
assert len(old_slot) == len(new_slot)
txt = txt.replace(old_slot, new_slot, 1)
with open(p, "r+", encoding="utf-8") as fh:
    fh.seek(0)
    fh.write(txt)
    fh.truncate()
EOF_STAMP
  echo "$CURRENT_BIND_TOKEN" > "$LEDGER_FILE"
else
  if [ "$BOUND_VAL" != "$CURRENT_BIND_TOKEN" ]; then
    shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: expected $BOUND_VAL, got $CURRENT_BIND_TOKEN)"
  fi
fi

# ------------------------------------------------------------------------------
# 2. 70% Safety Working Limit Spool Guard & Resume Checkpoint
# ------------------------------------------------------------------------------
TOTAL_CORES=$(sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || echo 4)
SAFE_JOBS=$(python3 -c "import math; print(max(1, int(math.floor($TOTAL_CORES * 0.70))))")
export MAX_JOBS="$SAFE_JOBS"
export CMAKE_BUILD_PARALLEL_LEVEL="$SAFE_JOBS"

mkdir -p "$WORK_DIR/OpenClaw_Agent_Workspace/overflow_spool"
SPOOL_FILE="$WORK_DIR/OpenClaw_Agent_Workspace/overflow_spool/resume_checkpoint.json"
cat > "$SPOOL_FILE" <<EOF_SPOOL
{
  "sku": "ONESHOT-05-OPENCLAW",
  "status": "IN_PROGRESS",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70,
  "max_parallel_jobs": $SAFE_JOBS
}
EOF_SPOOL

echo "[OneShot ONESHOT-05-OPENCLAW] Verified Genuine First-Use Capsule (Inode #$CUR_INODE, 70% Safety Limit: $SAFE_JOBS cores)."
echo "[OneShot ONESHOT-05-OPENCLAW] Starting 1-Click Initial Environment Setup & Config Wiring for: OpenClaw Autonomous Agent (Node Runtime + Telegram/Discord/Slack Bot Token .env Binding + LaunchAgent Auto-Runner Wiring)..."

# Simulated transient network failure hook (verifies safe spool preservation without premature self-delete)
if [ "${ONESHOT_SIMULATE_NET_DROP:-0}" = "1" ]; then
  echo "[SPOOL GUARD] Transient network interruption detected. Progress safely spooled to $SPOOL_FILE."
  echo "[SPOOL GUARD] Installer was NOT deleted. Re-run this exact file ($SELF_FILE) to resume."
  exit 75
fi


setup_payload() {
  mkdir -p "$WORK_DIR/OpenClaw_Agent_Workspace/overflow_spool" "$WORK_DIR/OpenClaw_Agent_Workspace/logs" "$WORK_DIR/OpenClaw_Agent_Workspace/skills"

  # 1. Create Local Vault .env with strict 0600 permissions & 127.0.0.1 Zero-Port Defense
  ENV_FILE="$WORK_DIR/OpenClaw_Agent_Workspace/.env"
  if [ ! -f "$ENV_FILE" ]; then
    cat > "$ENV_FILE" <<'EOF_ENV'
# DH Labs OpenClaw Autonomous Agent Local Vault (.env — chmod 600 Protected)
OPENCLAW_BIND_HOST=127.0.0.1
OPENCLAW_PORT=18789
OPENCLAW_SAFETY_SPOOL_LIMIT=0.70
TELEGRAM_BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN_HERE
DISCORD_BOT_TOKEN=YOUR_DISCORD_BOT_TOKEN_HERE
SLACK_BOT_TOKEN=YOUR_SLACK_BOT_TOKEN_HERE
ANTHROPIC_API_KEY=YOUR_ANTHROPIC_API_KEY_HERE
OPENAI_API_KEY=YOUR_OPENAI_API_KEY_HERE
EOF_ENV
  fi
  chmod 600 "$ENV_FILE"

  # 2. Wire Agent Gateway Config JSON
  cat > "$WORK_DIR/OpenClaw_Agent_Workspace/agent_gateway_config.json" <<'EOF_CFG'
{
  "gateway": {
    "host": "127.0.0.1",
    "port": 18789,
    "zero_port_external_exposure": false,
    "command_injection_filter": "STRICT_PARAM_VALIDATED",
    "safety_working_limit_ratio": 0.70
  },
  "channels": {
    "telegram": {"enabled": true, "env_key": "TELEGRAM_BOT_TOKEN"},
    "discord": {"enabled": true, "env_key": "DISCORD_BOT_TOKEN"},
    "slack": {"enabled": true, "env_key": "SLACK_BOT_TOKEN"}
  }
}
EOF_CFG

  # 3. Wire macOS LaunchAgent Auto-Runner plist & Start/Stop Launchers
  cat > "$WORK_DIR/OpenClaw_Agent_Workspace/ai.dhlabs.openclaw.plist" <<EOF_PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>ai.dhlabs.openclaw</string>
  <key>ProgramArguments</key>
  <array>
    <string>$WORK_DIR/OpenClaw_Agent_Workspace/Start_OpenClaw_Agent.command</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>$WORK_DIR/OpenClaw_Agent_Workspace/logs/openclaw.out.log</string>
  <key>StandardErrorPath</key>
  <string>$WORK_DIR/OpenClaw_Agent_Workspace/logs/openclaw.err.log</string>
</dict>
</plist>
EOF_PLIST

  cat > "$WORK_DIR/OpenClaw_Agent_Workspace/Start_OpenClaw_Agent.command" <<'EOF_START'
#!/bin/sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
echo "[OpenClaw] Starting Local Autonomous Agent Gateway on 127.0.0.1:18789 (Vault .env chmod 600 verified)..."
python3 -m json.tool "$DIR/agent_gateway_config.json" >/dev/null
EOF_START
  chmod 755 "$WORK_DIR/OpenClaw_Agent_Workspace/Start_OpenClaw_Agent.command"

  # 4. Smoke Verification: Verify .env is 0600 and bind host is 127.0.0.1
  python3 - "$ENV_FILE" "$WORK_DIR/OpenClaw_Agent_Workspace/agent_gateway_config.json" <<'EOF_V'
import json, os, stat, sys
env_mode = stat.S_IMODE(os.stat(sys.argv[1]).st_mode)
assert env_mode == 0o600, f"Expected 0600 on .env, got {oct(env_mode)}"
cfg = json.load(open(sys.argv[2]))
assert cfg["gateway"]["host"] == "127.0.0.1"
EOF_V
}


# ------------------------------------------------------------------------------
# 3. Execute Setup Payload & Verify 100% Before 0x00 Self-Deletion
# ------------------------------------------------------------------------------
if setup_payload; then
  cat > "$SPOOL_FILE" <<EOF_DONE
{
  "sku": "ONESHOT-05-OPENCLAW",
  "status": "COMPLETED_VERIFIED",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70
}
EOF_DONE
  echo "[OneShot ONESHOT-05-OPENCLAW] 100% Initial Setup & Smoke Verification PASSED."
  echo "[OneShot ONESHOT-05-OPENCLAW] Overwriting disposable installer with 0x00 and self-deleting..."
  for f in "$SELF_PATH" "$WORK_DIR/OneShot_05_OpenClaw_Agent_Setup.command" "$WORK_DIR/OneShot_05_OpenClaw_Agent_Setup.bin" "$WORK_DIR/OneShot_05_OpenClaw_Agent_Setup_Windows.bat" "$WORK_DIR/.dhlabs_mint_seal.json"; do
    if [ -f "$f" ]; then
      dd if=/dev/zero of="$f" bs=1024 count=8 conv=notrunc 2>/dev/null || true
      rm -f "$f"
    fi
  done
  rm -rf "$LEDGER_DIR" 2>/dev/null || true
  exit 0
else
  echo "[SPOOL GUARD] Setup encountered an error before completion. Progress preserved in $SPOOL_FILE (installer kept for retry)."
  exit 1
fi
