@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-05-OPENCLAW | MINT_HMAC_SHA256=9efa49652e33bd652fbddfe16fe94f930beb8d3a76f22a441b047f5f3a03a0de
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_05_OpenClaw_Agent_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-05-OPENCLAW] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
