@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-05-OPENCLAW | MINT_HMAC_SHA256=4d28998d6e53752de5b2be630a36271287ec4e3e5f5b5622938777e82837ef99
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_05_OpenClaw_Agent_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-05-OPENCLAW] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
