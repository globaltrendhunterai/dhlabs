@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-03-RVC | MINT_HMAC_SHA256=153d080dbd504e8211f011cd6c06b8c5217a3e5dfa341ba2dc33788d9ab9d7b8
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_03_RVC_Applio_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-03-RVC] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
