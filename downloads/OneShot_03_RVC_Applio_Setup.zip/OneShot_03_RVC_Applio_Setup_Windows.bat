@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-03-RVC | MINT_HMAC_SHA256=a6660a16f6b7e0b7ba9cf50363dd141f465b6fd1ece491572878d0561fb8ff64
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_03_RVC_Applio_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-03-RVC] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
