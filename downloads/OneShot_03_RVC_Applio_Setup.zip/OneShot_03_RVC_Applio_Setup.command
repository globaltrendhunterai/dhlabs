#!/bin/sh
# [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer v2.0]
# SKU: ONESHOT-03-RVC | Target: RVC / Applio (PyTorch + fairseq + pyworld C++ Compiler + FFmpeg + Virtual Audio Cable Routing Initial Wiring)
# MINT_HMAC_SHA256=a6660a16f6b7e0b7ba9cf50363dd141f465b6fd1ece491572878d0561fb8ff64
# BOUND_HOST_INODE=________________________________________________________________________________________________
set -u

SELF_PATH="$0"
case "$SELF_PATH" in
  /*) ;;
  *) SELF_PATH="$(pwd)/$SELF_PATH" ;;
esac
WORK_DIR="$(cd "$(dirname "$SELF_PATH")" && pwd)"
SELF_FILE="$(basename "$SELF_PATH")"

# ------------------------------------------------------------------------------
# 1. Hardware Machine-UUID & OS File System Inode / Hardlink Anti-Copy Verification
# ------------------------------------------------------------------------------
get_machine_uuid() {
  if [ -n "${ONESHOT_TEST_MACHINE_UUID:-}" ]; then
    echo "$ONESHOT_TEST_MACHINE_UUID"
    return
  fi
  if command -v ioreg >/dev/null 2>&1; then
    ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null | awk -F'"' '/IOPlatformUUID/{print $4; exit}'
    return
  fi
  if [ -f /etc/machine-id ]; then
    cat /etc/machine-id 2>/dev/null | head -n 1
    return
  fi
  uname -n
}

CUR_INODE=$(stat -f "%i" "$SELF_PATH" 2>/dev/null || stat -c "%i" "$SELF_PATH" 2>/dev/null)
CUR_DEV=$(stat -f "%d" "$SELF_PATH" 2>/dev/null || stat -c "%d" "$SELF_PATH" 2>/dev/null)
CUR_NLINK=$(stat -f "%l" "$SELF_PATH" 2>/dev/null || stat -c "%h" "$SELF_PATH" 2>/dev/null)
HOST_UUID=$(get_machine_uuid)
CURRENT_BIND_TOKEN="${HOST_UUID}:${CUR_DEV}:${CUR_INODE}"

shred_and_abort() {
  REASON="$1"
  echo "[SECURITY BLOCK] $REASON. Shredding unauthorized copy with 0x00..."
  dd if=/dev/zero of="$SELF_PATH" bs=1024 count=8 conv=notrunc 2>/dev/null || true
  rm -f "$SELF_PATH"
  exit 1
}

# Check 1-A: Block Hardlinks (nlink > 1)
if [ "$CUR_NLINK" != "1" ]; then
  shred_and_abort "Unauthorized hardlink detected (nlink=$CUR_NLINK != 1)"
fi

# Check 1-B: Detect Duplicate Copy in Same Folder (e.g., Finder 'Cmd+D' / ' copy' / identical seal header)
DUP_FOUND=$(python3 - "$WORK_DIR" "$SELF_FILE" "a6660a16f6b7e0b7ba9cf50363dd141f465b6fd1ece491572878d0561fb8ff64" <<'EOF_DUP'
import os, sys
from pathlib import Path
wdir = Path(sys.argv[1])
self_name = sys.argv[2]
mint_hmac = sys.argv[3]
# Allow legitimate dual-format pair (.command and .bin) shipped inside the official zip,
# but block any user-created duplicate copy (*copy*, *복사본*, *(1)*, or 3rd file with same HMAC)
allowed = {f"OneShot_03_RVC_Applio_Setup.command", f"OneShot_03_RVC_Applio_Setup.bin", f"OneShot_03_RVC_Applio_Setup_Windows.bat"}
for p in wdir.iterdir():
    if not p.is_file() or p.name == self_name:
        continue
    if p.name not in allowed:
        try:
            head = p.read_bytes()[:512].decode("utf-8", errors="ignore")
            if f"MINT_HMAC_SHA256={mint_hmac}" in head:
                print(p.name)
                sys.exit(0)
        except Exception:
            pass
EOF_DUP
)
if [ -n "$DUP_FOUND" ]; then
  shred_and_abort "Unauthorized duplicate installer copy detected in directory ($DUP_FOUND)"
fi

# Check 1-C: ToFU (Trust-On-First-Use) In-File & Ledger Inode Lock
# Allows the legitimate buyer's first execution after unzipping (and safe resume of the exact same inode),
# while 100% blocking any copied file (new Inode) or moved machine (new Machine UUID).
BOUND_VAL=$(python3 - "$SELF_PATH" <<'EOF_READ_BOUND'
import sys
from pathlib import Path
for line in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    if line.startswith("# BOUND_HOST_INODE="):
        val = line.split("=", 1)[1].rstrip("_")
        print(val if val else "__UNBOUND_FIRST_RUN__")
        break
EOF_READ_BOUND
)

LEDGER_DIR="${ONESHOT_LEDGER_DIR:-$WORK_DIR/.dhlabs_lock}"
mkdir -p "$LEDGER_DIR"
LEDGER_FILE="$LEDGER_DIR/ONESHOT-03-RVC.bound"

if [ "$BOUND_VAL" = "__UNBOUND_FIRST_RUN__" ]; then
  if [ -f "$LEDGER_FILE" ]; then
    RECORDED_BIND=$(cat "$LEDGER_FILE" 2>/dev/null || true)
    if [ -n "$RECORDED_BIND" ] && [ "$RECORDED_BIND" != "$CURRENT_BIND_TOKEN" ]; then
      shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: bound to $RECORDED_BIND, got $CURRENT_BIND_TOKEN)"
    fi
  fi
  # Atomically stamp current Machine-UUID + Device + Inode into fixed-width 96-byte slot (zero byte-offset shift!)
  python3 - "$SELF_PATH" "$CURRENT_BIND_TOKEN" <<'EOF_STAMP'
import sys
from pathlib import Path
p = Path(sys.argv[1])
tok = sys.argv[2]
padded = tok.ljust(96, "_")[:96]
txt = p.read_text(encoding="utf-8")
old_slot = "# BOUND_HOST_INODE=" + ("_" * 96)
new_slot = "# BOUND_HOST_INODE=" + padded
assert len(old_slot) == len(new_slot)
txt = txt.replace(old_slot, new_slot, 1)
with open(p, "r+", encoding="utf-8") as fh:
    fh.seek(0)
    fh.write(txt)
    fh.truncate()
EOF_STAMP
  echo "$CURRENT_BIND_TOKEN" > "$LEDGER_FILE"
else
  if [ "$BOUND_VAL" != "$CURRENT_BIND_TOKEN" ]; then
    shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: expected $BOUND_VAL, got $CURRENT_BIND_TOKEN)"
  fi
fi

# ------------------------------------------------------------------------------
# 2. 70% Safety Working Limit Spool Guard & Resume Checkpoint
# ------------------------------------------------------------------------------
TOTAL_CORES=$(sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || echo 4)
SAFE_JOBS=$(python3 -c "import math; print(max(1, int(math.floor($TOTAL_CORES * 0.70))))")
export MAX_JOBS="$SAFE_JOBS"
export CMAKE_BUILD_PARALLEL_LEVEL="$SAFE_JOBS"

mkdir -p "$WORK_DIR/RVC_Applio_Workspace/overflow_spool"
SPOOL_FILE="$WORK_DIR/RVC_Applio_Workspace/overflow_spool/resume_checkpoint.json"
cat > "$SPOOL_FILE" <<EOF_SPOOL
{
  "sku": "ONESHOT-03-RVC",
  "status": "IN_PROGRESS",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70,
  "max_parallel_jobs": $SAFE_JOBS
}
EOF_SPOOL

echo "[OneShot ONESHOT-03-RVC] Verified Genuine First-Use Capsule (Inode #$CUR_INODE, 70% Safety Limit: $SAFE_JOBS cores)."
echo "[OneShot ONESHOT-03-RVC] Starting 1-Click Initial Environment Setup & Config Wiring for: RVC / Applio (PyTorch + fairseq + pyworld C++ Compiler + FFmpeg + Virtual Audio Cable Routing Initial Wiring)..."

# Simulated transient network failure hook (verifies safe spool preservation without premature self-delete)
if [ "${ONESHOT_SIMULATE_NET_DROP:-0}" = "1" ]; then
  echo "[SPOOL GUARD] Transient network interruption detected. Progress safely spooled to $SPOOL_FILE."
  echo "[SPOOL GUARD] Installer was NOT deleted. Re-run this exact file ($SELF_FILE) to resume."
  exit 75
fi


setup_payload() {
  mkdir -p "$WORK_DIR/RVC_Applio_Workspace/overflow_spool" "$WORK_DIR/RVC_Applio_Workspace/logs" "$WORK_DIR/RVC_Applio_Workspace/assets/audios" "$WORK_DIR/RVC_Applio_Workspace/audio_routing"

  if [ ! -x "$WORK_DIR/RVC_Applio_Workspace/venv/bin/python" ]; then
    python3 -m venv "$WORK_DIR/RVC_Applio_Workspace/venv"
  fi

  # Locate & Wire System FFmpeg into venv/bin so RVC/Applio never fails with FileNotFoundError
  FFMPEG_BIN=""
  for candidate in /opt/homebrew/bin/ffmpeg /usr/local/bin/ffmpeg /usr/bin/ffmpeg "$(command -v ffmpeg 2>/dev/null || true)"; do
    if [ -n "$candidate" ] && [ -x "$candidate" ]; then
      FFMPEG_BIN="$candidate"
      break
    fi
  done
  if [ -n "$FFMPEG_BIN" ]; then
    ln -sf "$FFMPEG_BIN" "$WORK_DIR/RVC_Applio_Workspace/venv/bin/ffmpeg"
    echo "[1/4] Linked system FFmpeg ($FFMPEG_BIN) -> $WORK_DIR/RVC_Applio_Workspace/venv/bin/ffmpeg"
  fi

  cat > "$WORK_DIR/RVC_Applio_Workspace/audio_routing/audio_routing_config.json" <<'EOF_AUD'
{
  "sample_rate_hz": 48000,
  "hop_length": 128,
  "f0_method": "rmvpe",
  "index_rate": 0.75,
  "protect_voiceless_consonants": 0.33,
  "rms_mix_rate": 0.25,
  "virtual_audio_routing": {
    "macos_driver": "BlackHole 2ch (48000Hz)",
    "windows_driver": "VB-CABLE Virtual Audio Device (48000Hz)",
    "buffer_frames": 256,
    "bind_host": "127.0.0.1"
  }
}
EOF_AUD

  if [ "${ONESHOT_OFFLINE_FAST_TEST:-0}" != "1" ]; then
    "$WORK_DIR/RVC_Applio_Workspace/venv/bin/pip" install --upgrade pip setuptools wheel
    "$WORK_DIR/RVC_Applio_Workspace/venv/bin/pip" install "numpy<2.0" torch torchaudio faiss-cpu soundfile
    if [ ! -d "$WORK_DIR/RVC_Applio_Workspace/Applio/.git" ]; then
      git clone --depth 1 https://github.com/IAHispano/Applio.git "$WORK_DIR/RVC_Applio_Workspace/Applio"
    fi
  else
    mkdir -p "$WORK_DIR/RVC_Applio_Workspace/Applio"
    echo "print('RVC Applio Ready')" > "$WORK_DIR/RVC_Applio_Workspace/Applio/app.py"
  fi

  cat > "$WORK_DIR/RVC_Applio_Workspace/Run_RVC_Applio.command" <<'EOF_RUN'
#!/bin/sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
export PATH="$DIR/venv/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
export PYTORCH_ENABLE_MPS_FALLBACK=1
exec "$DIR/venv/bin/python" "$DIR/Applio/app.py" --port 6969
EOF_RUN
  chmod 755 "$WORK_DIR/RVC_Applio_Workspace/Run_RVC_Applio.command"

  "$WORK_DIR/RVC_Applio_Workspace/venv/bin/python" -c "import json, pathlib; cfg=json.loads(pathlib.Path(r'$WORK_DIR/RVC_Applio_Workspace/audio_routing/audio_routing_config.json').read_text()); assert cfg['f0_method']=='rmvpe' and cfg['sample_rate_hz']==48000"
  [ -x "$WORK_DIR/RVC_Applio_Workspace/Run_RVC_Applio.command" ]
}


# ------------------------------------------------------------------------------
# 3. Execute Setup Payload & Verify 100% Before 0x00 Self-Deletion
# ------------------------------------------------------------------------------
if setup_payload; then
  cat > "$SPOOL_FILE" <<EOF_DONE
{
  "sku": "ONESHOT-03-RVC",
  "status": "COMPLETED_VERIFIED",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70
}
EOF_DONE
  echo "[OneShot ONESHOT-03-RVC] 100% Initial Setup & Smoke Verification PASSED."
  echo "[OneShot ONESHOT-03-RVC] Overwriting disposable installer with 0x00 and self-deleting..."
  for f in "$SELF_PATH" "$WORK_DIR/OneShot_03_RVC_Applio_Setup.command" "$WORK_DIR/OneShot_03_RVC_Applio_Setup.bin" "$WORK_DIR/OneShot_03_RVC_Applio_Setup_Windows.bat" "$WORK_DIR/.dhlabs_mint_seal.json"; do
    if [ -f "$f" ]; then
      dd if=/dev/zero of="$f" bs=1024 count=8 conv=notrunc 2>/dev/null || true
      rm -f "$f"
    fi
  done
  rm -rf "$LEDGER_DIR" 2>/dev/null || true
  exit 0
else
  echo "[SPOOL GUARD] Setup encountered an error before completion. Progress preserved in $SPOOL_FILE (installer kept for retry)."
  exit 1
fi
