@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-06-WHISPERX | MINT_HMAC_SHA256=e9d831ae78d8a21c200adb80a1c6401db1ca974a96d6e950ad5caaeb47d658ee
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_06_WhisperX_Diarization_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-06-WHISPERX] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
