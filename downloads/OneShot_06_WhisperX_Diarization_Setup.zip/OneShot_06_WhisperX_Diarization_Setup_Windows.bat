@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-06-WHISPERX | MINT_HMAC_SHA256=33caf41ef64314ca04a96b63f321ca55484863c66aa656e0a478e71215f0325a
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_06_WhisperX_Diarization_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-06-WHISPERX] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
