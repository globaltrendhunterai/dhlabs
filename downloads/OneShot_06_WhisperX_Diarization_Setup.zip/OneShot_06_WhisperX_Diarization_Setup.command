#!/bin/sh
# [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer v2.0]
# SKU: ONESHOT-06-WHISPERX | Target: WhisperX (System FFmpeg PATH + CTranslate2 cuDNN 8/9 GPU Matching + HuggingFace Pyannote Speaker Diarization Wiring)
# MINT_HMAC_SHA256=e9d831ae78d8a21c200adb80a1c6401db1ca974a96d6e950ad5caaeb47d658ee
# BOUND_HOST_INODE=________________________________________________________________________________________________
set -u

SELF_PATH="$0"
case "$SELF_PATH" in
  /*) ;;
  *) SELF_PATH="$(pwd)/$SELF_PATH" ;;
esac
WORK_DIR="$(cd "$(dirname "$SELF_PATH")" && pwd)"
SELF_FILE="$(basename "$SELF_PATH")"

# ------------------------------------------------------------------------------
# 1. Hardware Machine-UUID & OS File System Inode / Hardlink Anti-Copy Verification
# ------------------------------------------------------------------------------
get_machine_uuid() {
  if [ -n "${ONESHOT_TEST_MACHINE_UUID:-}" ]; then
    echo "$ONESHOT_TEST_MACHINE_UUID"
    return
  fi
  if command -v ioreg >/dev/null 2>&1; then
    ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null | awk -F'"' '/IOPlatformUUID/{print $4; exit}'
    return
  fi
  if [ -f /etc/machine-id ]; then
    cat /etc/machine-id 2>/dev/null | head -n 1
    return
  fi
  uname -n
}

CUR_INODE=$(stat -f "%i" "$SELF_PATH" 2>/dev/null || stat -c "%i" "$SELF_PATH" 2>/dev/null)
CUR_DEV=$(stat -f "%d" "$SELF_PATH" 2>/dev/null || stat -c "%d" "$SELF_PATH" 2>/dev/null)
CUR_NLINK=$(stat -f "%l" "$SELF_PATH" 2>/dev/null || stat -c "%h" "$SELF_PATH" 2>/dev/null)
HOST_UUID=$(get_machine_uuid)
CURRENT_BIND_TOKEN="${HOST_UUID}:${CUR_DEV}:${CUR_INODE}"

shred_and_abort() {
  REASON="$1"
  echo "[SECURITY BLOCK] $REASON. Shredding unauthorized copy with 0x00..."
  dd if=/dev/zero of="$SELF_PATH" bs=1024 count=8 conv=notrunc 2>/dev/null || true
  rm -f "$SELF_PATH"
  exit 1
}

# Check 1-A: Block Hardlinks (nlink > 1)
if [ "$CUR_NLINK" != "1" ]; then
  shred_and_abort "Unauthorized hardlink detected (nlink=$CUR_NLINK != 1)"
fi

# Check 1-B: Detect Duplicate Copy in Same Folder (e.g., Finder 'Cmd+D' / ' copy' / identical seal header)
DUP_FOUND=$(python3 - "$WORK_DIR" "$SELF_FILE" "e9d831ae78d8a21c200adb80a1c6401db1ca974a96d6e950ad5caaeb47d658ee" <<'EOF_DUP'
import os, sys
from pathlib import Path
wdir = Path(sys.argv[1])
self_name = sys.argv[2]
mint_hmac = sys.argv[3]
# Allow legitimate dual-format pair (.command and .bin) shipped inside the official zip,
# but block any user-created duplicate copy (*copy*, *복사본*, *(1)*, or 3rd file with same HMAC)
allowed = {f"OneShot_06_WhisperX_Diarization_Setup.command", f"OneShot_06_WhisperX_Diarization_Setup.bin", f"OneShot_06_WhisperX_Diarization_Setup_Windows.bat"}
for p in wdir.iterdir():
    if not p.is_file() or p.name == self_name:
        continue
    if p.name not in allowed:
        try:
            head = p.read_bytes()[:512].decode("utf-8", errors="ignore")
            if f"MINT_HMAC_SHA256={mint_hmac}" in head:
                print(p.name)
                sys.exit(0)
        except Exception:
            pass
EOF_DUP
)
if [ -n "$DUP_FOUND" ]; then
  shred_and_abort "Unauthorized duplicate installer copy detected in directory ($DUP_FOUND)"
fi

# Check 1-C: ToFU (Trust-On-First-Use) In-File & Ledger Inode Lock
# Allows the legitimate buyer's first execution after unzipping (and safe resume of the exact same inode),
# while 100% blocking any copied file (new Inode) or moved machine (new Machine UUID).
BOUND_VAL=$(python3 - "$SELF_PATH" <<'EOF_READ_BOUND'
import sys
from pathlib import Path
for line in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    if line.startswith("# BOUND_HOST_INODE="):
        val = line.split("=", 1)[1].rstrip("_")
        print(val if val else "__UNBOUND_FIRST_RUN__")
        break
EOF_READ_BOUND
)

LEDGER_DIR="${ONESHOT_LEDGER_DIR:-$WORK_DIR/.dhlabs_lock}"
mkdir -p "$LEDGER_DIR"
LEDGER_FILE="$LEDGER_DIR/ONESHOT-06-WHISPERX.bound"

if [ "$BOUND_VAL" = "__UNBOUND_FIRST_RUN__" ]; then
  if [ -f "$LEDGER_FILE" ]; then
    RECORDED_BIND=$(cat "$LEDGER_FILE" 2>/dev/null || true)
    if [ -n "$RECORDED_BIND" ] && [ "$RECORDED_BIND" != "$CURRENT_BIND_TOKEN" ]; then
      shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: bound to $RECORDED_BIND, got $CURRENT_BIND_TOKEN)"
    fi
  fi
  # Atomically stamp current Machine-UUID + Device + Inode into fixed-width 96-byte slot (zero byte-offset shift!)
  python3 - "$SELF_PATH" "$CURRENT_BIND_TOKEN" <<'EOF_STAMP'
import sys
from pathlib import Path
p = Path(sys.argv[1])
tok = sys.argv[2]
padded = tok.ljust(96, "_")[:96]
txt = p.read_text(encoding="utf-8")
old_slot = "# BOUND_HOST_INODE=" + ("_" * 96)
new_slot = "# BOUND_HOST_INODE=" + padded
assert len(old_slot) == len(new_slot)
txt = txt.replace(old_slot, new_slot, 1)
with open(p, "r+", encoding="utf-8") as fh:
    fh.seek(0)
    fh.write(txt)
    fh.truncate()
EOF_STAMP
  echo "$CURRENT_BIND_TOKEN" > "$LEDGER_FILE"
else
  if [ "$BOUND_VAL" != "$CURRENT_BIND_TOKEN" ]; then
    shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: expected $BOUND_VAL, got $CURRENT_BIND_TOKEN)"
  fi
fi

# ------------------------------------------------------------------------------
# 2. 70% Safety Working Limit Spool Guard & Resume Checkpoint
# ------------------------------------------------------------------------------
TOTAL_CORES=$(sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || echo 4)
SAFE_JOBS=$(python3 -c "import math; print(max(1, int(math.floor($TOTAL_CORES * 0.70))))")
export MAX_JOBS="$SAFE_JOBS"
export CMAKE_BUILD_PARALLEL_LEVEL="$SAFE_JOBS"

mkdir -p "$WORK_DIR/WhisperX_Workspace/overflow_spool"
SPOOL_FILE="$WORK_DIR/WhisperX_Workspace/overflow_spool/resume_checkpoint.json"
cat > "$SPOOL_FILE" <<EOF_SPOOL
{
  "sku": "ONESHOT-06-WHISPERX",
  "status": "IN_PROGRESS",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70,
  "max_parallel_jobs": $SAFE_JOBS
}
EOF_SPOOL

echo "[OneShot ONESHOT-06-WHISPERX] Verified Genuine First-Use Capsule (Inode #$CUR_INODE, 70% Safety Limit: $SAFE_JOBS cores)."
echo "[OneShot ONESHOT-06-WHISPERX] Starting 1-Click Initial Environment Setup & Config Wiring for: WhisperX (System FFmpeg PATH + CTranslate2 cuDNN 8/9 GPU Matching + HuggingFace Pyannote Speaker Diarization Wiring)..."

# Simulated transient network failure hook (verifies safe spool preservation without premature self-delete)
if [ "${ONESHOT_SIMULATE_NET_DROP:-0}" = "1" ]; then
  echo "[SPOOL GUARD] Transient network interruption detected. Progress safely spooled to $SPOOL_FILE."
  echo "[SPOOL GUARD] Installer was NOT deleted. Re-run this exact file ($SELF_FILE) to resume."
  exit 75
fi


setup_payload() {
  mkdir -p "$WORK_DIR/WhisperX_Workspace/overflow_spool" "$WORK_DIR/WhisperX_Workspace/input_media" "$WORK_DIR/WhisperX_Workspace/output_subtitles"

  if [ ! -x "$WORK_DIR/WhisperX_Workspace/venv/bin/python" ]; then
    python3 -m venv "$WORK_DIR/WhisperX_Workspace/venv"
  fi

  # Link System FFmpeg into venv/bin
  for candidate in /opt/homebrew/bin/ffmpeg /usr/local/bin/ffmpeg /usr/bin/ffmpeg "$(command -v ffmpeg 2>/dev/null || true)"; do
    if [ -n "$candidate" ] && [ -x "$candidate" ]; then
      ln -sf "$candidate" "$WORK_DIR/WhisperX_Workspace/venv/bin/ffmpeg"
      break
    fi
  done

  if [ "${ONESHOT_OFFLINE_FAST_TEST:-0}" != "1" ]; then
    "$WORK_DIR/WhisperX_Workspace/venv/bin/pip" install --upgrade pip setuptools wheel
    "$WORK_DIR/WhisperX_Workspace/venv/bin/pip" install torch torchaudio ctranslate2 faster-whisper whisperx pyannote.audio
  fi

  # Generate Hardware-Adaptive Word-Level SRT & Speaker Diarization Runner (Prevents float16 crash on Mac/CPU!)
  cat > "$WORK_DIR/WhisperX_Workspace/transcribe_to_srt.py" <<'EOF_WX'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import json
import os
import platform
import shutil
import sys
from pathlib import Path

def detect_optimal_compute():
    # Prevents #1 WhisperX error: ValueError: Requested float16 compute type on CPU/MPS
    try:
        import torch
        if torch.cuda.is_available():
            return "cuda", "float16", 16
    except Exception:
        pass
    return "cpu", "int8", 4

def main():
    parser = argparse.ArgumentParser(description="DH Labs WhisperX Word-Level SRT & Speaker Diarization Runner")
    parser.add_argument("media_file", nargs="?", help="Input video/audio file (.mp4, .mp3, .wav, .m4a)")
    parser.add_argument("--hf-token", default=os.environ.get("HF_TOKEN", ""), help="HuggingFace token for Pyannote Speaker Diarization")
    parser.add_argument("--lang", default=None, help="Language code (e.g. ko, en, ja)")
    parser.add_argument("--self-test", action="store_true", help="Run hardware & FFmpeg wiring smoke check")
    args = parser.parse_args()

    device, compute_type, batch_size = detect_optimal_compute()
    ffmpeg_path = shutil.which("ffmpeg") or "/opt/homebrew/bin/ffmpeg"

    if args.self_test:
        print(json.dumps({
            "status": "PASS",
            "device": device,
            "compute_type": compute_type,
            "batch_size": batch_size,
            "ffmpeg_wired": bool(ffmpeg_path and os.path.exists(ffmpeg_path))
        }))
        return 0

    if not args.media_file:
        parser.print_help()
        return 0

    import whisperx
    media_path = Path(args.media_file).resolve()
    out_dir = media_path.parent
    print(f"[WhisperX] Loading model on device={device} (compute_type={compute_type}, batch_size={batch_size})...")
    model = whisperx.load_model("large-v3", device, compute_type=compute_type, language=args.lang)
    audio = whisperx.load_audio(str(media_path))
    result = model.transcribe(audio, batch_size=batch_size)
    model_a, metadata = whisperx.load_align_model(language_code=result["language"], device=device)
    result = whisperx.align(result["segments"], model_a, metadata, audio, device, return_char_alignments=False)
    if args.hf_token:
        diarize_model = whisperx.DiarizationPipeline(use_auth_token=args.hf_token, device=device)
        diarize_segments = diarize_model(audio)
        result = whisperx.assign_word_speakers(diarize_segments, result)
    writer = whisperx.utils.get_writer("srt", str(out_dir))
    writer(result, str(media_path), {"max_line_width": 42, "max_line_count": 2, "highlight_words": False})
    print(f"[WhisperX] Saved synced SRT subtitle in {out_dir}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
EOF_WX
  chmod 755 "$WORK_DIR/WhisperX_Workspace/transcribe_to_srt.py"

  cat > "$WORK_DIR/WhisperX_Workspace/Drop_Video_Here_For_SRT.command" <<'EOF_DROP'
#!/bin/sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
export PATH="$DIR/venv/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
exec "$DIR/venv/bin/python" "$DIR/transcribe_to_srt.py" "$@"
EOF_DROP
  chmod 755 "$WORK_DIR/WhisperX_Workspace/Drop_Video_Here_For_SRT.command"

  "$WORK_DIR/WhisperX_Workspace/venv/bin/python" "$WORK_DIR/WhisperX_Workspace/transcribe_to_srt.py" --self-test | grep -q '"status": "PASS"'
}


# ------------------------------------------------------------------------------
# 3. Execute Setup Payload & Verify 100% Before 0x00 Self-Deletion
# ------------------------------------------------------------------------------
if setup_payload; then
  cat > "$SPOOL_FILE" <<EOF_DONE
{
  "sku": "ONESHOT-06-WHISPERX",
  "status": "COMPLETED_VERIFIED",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70
}
EOF_DONE
  echo "[OneShot ONESHOT-06-WHISPERX] 100% Initial Setup & Smoke Verification PASSED."
  echo "[OneShot ONESHOT-06-WHISPERX] Overwriting disposable installer with 0x00 and self-deleting..."
  for f in "$SELF_PATH" "$WORK_DIR/OneShot_06_WhisperX_Diarization_Setup.command" "$WORK_DIR/OneShot_06_WhisperX_Diarization_Setup.bin" "$WORK_DIR/OneShot_06_WhisperX_Diarization_Setup_Windows.bat" "$WORK_DIR/.dhlabs_mint_seal.json"; do
    if [ -f "$f" ]; then
      dd if=/dev/zero of="$f" bs=1024 count=8 conv=notrunc 2>/dev/null || true
      rm -f "$f"
    fi
  done
  rm -rf "$LEDGER_DIR" 2>/dev/null || true
  exit 0
else
  echo "[SPOOL GUARD] Setup encountered an error before completion. Progress preserved in $SPOOL_FILE (installer kept for retry)."
  exit 1
fi
