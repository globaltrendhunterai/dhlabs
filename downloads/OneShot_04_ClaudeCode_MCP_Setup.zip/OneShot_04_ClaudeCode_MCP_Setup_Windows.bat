@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-04-CLAUDECODE | MINT_HMAC_SHA256=88d940db4f7a056b25c0f5d6ee608b5ba2ee462b674685ec2862921a82ab3156
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_04_ClaudeCode_MCP_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-04-CLAUDECODE] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
