@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-04-CLAUDECODE | MINT_HMAC_SHA256=4f7ac0a52f0a9fbb074f19725c6097e3f63636fbaf24ce376beb243cd0cda8ce
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_04_ClaudeCode_MCP_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-04-CLAUDECODE] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
