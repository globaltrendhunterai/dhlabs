#!/bin/sh
# [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer v2.0]
# SKU: ONESHOT-04-CLAUDECODE | Target: Claude Code CLI + Essential MCP Servers (Node.js/Git PATH + Filesystem/Fetch/Memory/SQLite/Git MCP JSON Initial Wiring)
# MINT_HMAC_SHA256=88d940db4f7a056b25c0f5d6ee608b5ba2ee462b674685ec2862921a82ab3156
# BOUND_HOST_INODE=________________________________________________________________________________________________
set -u

SELF_PATH="$0"
case "$SELF_PATH" in
  /*) ;;
  *) SELF_PATH="$(pwd)/$SELF_PATH" ;;
esac
WORK_DIR="$(cd "$(dirname "$SELF_PATH")" && pwd)"
SELF_FILE="$(basename "$SELF_PATH")"

# ------------------------------------------------------------------------------
# 1. Hardware Machine-UUID & OS File System Inode / Hardlink Anti-Copy Verification
# ------------------------------------------------------------------------------
get_machine_uuid() {
  if [ -n "${ONESHOT_TEST_MACHINE_UUID:-}" ]; then
    echo "$ONESHOT_TEST_MACHINE_UUID"
    return
  fi
  if command -v ioreg >/dev/null 2>&1; then
    ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null | awk -F'"' '/IOPlatformUUID/{print $4; exit}'
    return
  fi
  if [ -f /etc/machine-id ]; then
    cat /etc/machine-id 2>/dev/null | head -n 1
    return
  fi
  uname -n
}

CUR_INODE=$(stat -f "%i" "$SELF_PATH" 2>/dev/null || stat -c "%i" "$SELF_PATH" 2>/dev/null)
CUR_DEV=$(stat -f "%d" "$SELF_PATH" 2>/dev/null || stat -c "%d" "$SELF_PATH" 2>/dev/null)
CUR_NLINK=$(stat -f "%l" "$SELF_PATH" 2>/dev/null || stat -c "%h" "$SELF_PATH" 2>/dev/null)
HOST_UUID=$(get_machine_uuid)
CURRENT_BIND_TOKEN="${HOST_UUID}:${CUR_DEV}:${CUR_INODE}"

shred_and_abort() {
  REASON="$1"
  echo "[SECURITY BLOCK] $REASON. Shredding unauthorized copy with 0x00..."
  dd if=/dev/zero of="$SELF_PATH" bs=1024 count=8 conv=notrunc 2>/dev/null || true
  rm -f "$SELF_PATH"
  exit 1
}

# Check 1-A: Block Hardlinks (nlink > 1)
if [ "$CUR_NLINK" != "1" ]; then
  shred_and_abort "Unauthorized hardlink detected (nlink=$CUR_NLINK != 1)"
fi

# Check 1-B: Detect Duplicate Copy in Same Folder (e.g., Finder 'Cmd+D' / ' copy' / identical seal header)
DUP_FOUND=$(python3 - "$WORK_DIR" "$SELF_FILE" "88d940db4f7a056b25c0f5d6ee608b5ba2ee462b674685ec2862921a82ab3156" <<'EOF_DUP'
import os, sys
from pathlib import Path
wdir = Path(sys.argv[1])
self_name = sys.argv[2]
mint_hmac = sys.argv[3]
# Allow legitimate dual-format pair (.command and .bin) shipped inside the official zip,
# but block any user-created duplicate copy (*copy*, *복사본*, *(1)*, or 3rd file with same HMAC)
allowed = {f"OneShot_04_ClaudeCode_MCP_Setup.command", f"OneShot_04_ClaudeCode_MCP_Setup.bin", f"OneShot_04_ClaudeCode_MCP_Setup_Windows.bat"}
for p in wdir.iterdir():
    if not p.is_file() or p.name == self_name:
        continue
    if p.name not in allowed:
        try:
            head = p.read_bytes()[:512].decode("utf-8", errors="ignore")
            if f"MINT_HMAC_SHA256={mint_hmac}" in head:
                print(p.name)
                sys.exit(0)
        except Exception:
            pass
EOF_DUP
)
if [ -n "$DUP_FOUND" ]; then
  shred_and_abort "Unauthorized duplicate installer copy detected in directory ($DUP_FOUND)"
fi

# Check 1-C: ToFU (Trust-On-First-Use) In-File & Ledger Inode Lock
# Allows the legitimate buyer's first execution after unzipping (and safe resume of the exact same inode),
# while 100% blocking any copied file (new Inode) or moved machine (new Machine UUID).
BOUND_VAL=$(python3 - "$SELF_PATH" <<'EOF_READ_BOUND'
import sys
from pathlib import Path
for line in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    if line.startswith("# BOUND_HOST_INODE="):
        val = line.split("=", 1)[1].rstrip("_")
        print(val if val else "__UNBOUND_FIRST_RUN__")
        break
EOF_READ_BOUND
)

LEDGER_DIR="${ONESHOT_LEDGER_DIR:-$WORK_DIR/.dhlabs_lock}"
mkdir -p "$LEDGER_DIR"
LEDGER_FILE="$LEDGER_DIR/ONESHOT-04-CLAUDECODE.bound"

if [ "$BOUND_VAL" = "__UNBOUND_FIRST_RUN__" ]; then
  if [ -f "$LEDGER_FILE" ]; then
    RECORDED_BIND=$(cat "$LEDGER_FILE" 2>/dev/null || true)
    if [ -n "$RECORDED_BIND" ] && [ "$RECORDED_BIND" != "$CURRENT_BIND_TOKEN" ]; then
      shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: bound to $RECORDED_BIND, got $CURRENT_BIND_TOKEN)"
    fi
  fi
  # Atomically stamp current Machine-UUID + Device + Inode into fixed-width 96-byte slot (zero byte-offset shift!)
  python3 - "$SELF_PATH" "$CURRENT_BIND_TOKEN" <<'EOF_STAMP'
import sys
from pathlib import Path
p = Path(sys.argv[1])
tok = sys.argv[2]
padded = tok.ljust(96, "_")[:96]
txt = p.read_text(encoding="utf-8")
old_slot = "# BOUND_HOST_INODE=" + ("_" * 96)
new_slot = "# BOUND_HOST_INODE=" + padded
assert len(old_slot) == len(new_slot)
txt = txt.replace(old_slot, new_slot, 1)
with open(p, "r+", encoding="utf-8") as fh:
    fh.seek(0)
    fh.write(txt)
    fh.truncate()
EOF_STAMP
  echo "$CURRENT_BIND_TOKEN" > "$LEDGER_FILE"
else
  if [ "$BOUND_VAL" != "$CURRENT_BIND_TOKEN" ]; then
    shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: expected $BOUND_VAL, got $CURRENT_BIND_TOKEN)"
  fi
fi

# ------------------------------------------------------------------------------
# 2. 70% Safety Working Limit Spool Guard & Resume Checkpoint
# ------------------------------------------------------------------------------
TOTAL_CORES=$(sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || echo 4)
SAFE_JOBS=$(python3 -c "import math; print(max(1, int(math.floor($TOTAL_CORES * 0.70))))")
export MAX_JOBS="$SAFE_JOBS"
export CMAKE_BUILD_PARALLEL_LEVEL="$SAFE_JOBS"

mkdir -p "$WORK_DIR/ClaudeCode_MCP_Workspace/overflow_spool"
SPOOL_FILE="$WORK_DIR/ClaudeCode_MCP_Workspace/overflow_spool/resume_checkpoint.json"
cat > "$SPOOL_FILE" <<EOF_SPOOL
{
  "sku": "ONESHOT-04-CLAUDECODE",
  "status": "IN_PROGRESS",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70,
  "max_parallel_jobs": $SAFE_JOBS
}
EOF_SPOOL

echo "[OneShot ONESHOT-04-CLAUDECODE] Verified Genuine First-Use Capsule (Inode #$CUR_INODE, 70% Safety Limit: $SAFE_JOBS cores)."
echo "[OneShot ONESHOT-04-CLAUDECODE] Starting 1-Click Initial Environment Setup & Config Wiring for: Claude Code CLI + Essential MCP Servers (Node.js/Git PATH + Filesystem/Fetch/Memory/SQLite/Git MCP JSON Initial Wiring)..."

# Simulated transient network failure hook (verifies safe spool preservation without premature self-delete)
if [ "${ONESHOT_SIMULATE_NET_DROP:-0}" = "1" ]; then
  echo "[SPOOL GUARD] Transient network interruption detected. Progress safely spooled to $SPOOL_FILE."
  echo "[SPOOL GUARD] Installer was NOT deleted. Re-run this exact file ($SELF_FILE) to resume."
  exit 75
fi


setup_payload() {
  mkdir -p "$WORK_DIR/ClaudeCode_MCP_Workspace/overflow_spool" "$WORK_DIR/ClaudeCode_MCP_Workspace/backups"
  export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

  # Determine target config paths (Supports sandbox override via ONESHOT_CLAUDE_CONFIG_DIR for safe testing)
  TARGET_CFG_DIR="${ONESHOT_CLAUDE_CONFIG_DIR:-$WORK_DIR/ClaudeCode_MCP_Workspace/claude_config}"
  mkdir -p "$TARGET_CFG_DIR"

  if [ "${ONESHOT_OFFLINE_FAST_TEST:-0}" != "1" ] && command -v npm >/dev/null 2>&1; then
    npm install -g @anthropic-ai/claude-code || npm install --prefix "$WORK_DIR/ClaudeCode_MCP_Workspace/cli_local" @anthropic-ai/claude-code
  fi

  # Non-Destructive JSON Merge of 5 Essential Zero-Key MCP Servers (Preserves 100% of existing user MCP servers!)
  python3 - "$TARGET_CFG_DIR" "$WORK_DIR/ClaudeCode_MCP_Workspace" <<'EOF_PY'
import json
import os
import shutil
import sys
import time
from pathlib import Path

cfg_dir = Path(sys.argv[1])
ws_dir = Path(sys.argv[2])
home_str = str(Path.home())

essential_mcp = {
    "filesystem": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-filesystem", home_str]
    },
    "fetch": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-fetch"]
    },
    "memory": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-memory"]
    },
    "sqlite": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-sqlite", "--db-path", str(ws_dir / "local_memory.db")]
    },
    "git": {
        "command": "uvx",
        "args": ["mcp-server-git"]
    }
}

for fname in ("claude_desktop_config.json", ".claude.json"):
    fpath = cfg_dir / fname
    data = {}
    if fpath.exists():
        bak = ws_dir / "backups" / f"{fname}.{int(time.time())}.bak"
        shutil.copy2(fpath, bak)
        try:
            data = json.loads(fpath.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    if not isinstance(data, dict):
        data = {}
    mcp_servers = data.get("mcpServers")
    if not isinstance(mcp_servers, dict):
        mcp_servers = {}
    for k, v in essential_mcp.items():
        if k not in mcp_servers:
            mcp_servers[k] = v
    data["mcpServers"] = mcp_servers
    fpath.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

# Verify all 5 essential MCP servers exist and JSON is valid
verified = json.loads((cfg_dir / "claude_desktop_config.json").read_text(encoding="utf-8"))
for req_key in ("filesystem", "fetch", "memory", "sqlite", "git"):
    assert req_key in verified["mcpServers"], f"Missing MCP key: {req_key}"
EOF_PY

  cat > "$WORK_DIR/ClaudeCode_MCP_Workspace/Verify_MCP_Status.command" <<EOF_RUN
#!/bin/sh
set -e
export PATH="/opt/homebrew/bin:/usr/local/bin:\$PATH"
python3 -m json.tool "$TARGET_CFG_DIR/claude_desktop_config.json"
EOF_RUN
  chmod 755 "$WORK_DIR/ClaudeCode_MCP_Workspace/Verify_MCP_Status.command"
  [ -f "$TARGET_CFG_DIR/claude_desktop_config.json" ] && [ -f "$TARGET_CFG_DIR/.claude.json" ]
}


# ------------------------------------------------------------------------------
# 3. Execute Setup Payload & Verify 100% Before 0x00 Self-Deletion
# ------------------------------------------------------------------------------
if setup_payload; then
  cat > "$SPOOL_FILE" <<EOF_DONE
{
  "sku": "ONESHOT-04-CLAUDECODE",
  "status": "COMPLETED_VERIFIED",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70
}
EOF_DONE
  echo "[OneShot ONESHOT-04-CLAUDECODE] 100% Initial Setup & Smoke Verification PASSED."
  echo "[OneShot ONESHOT-04-CLAUDECODE] Overwriting disposable installer with 0x00 and self-deleting..."
  for f in "$SELF_PATH" "$WORK_DIR/OneShot_04_ClaudeCode_MCP_Setup.command" "$WORK_DIR/OneShot_04_ClaudeCode_MCP_Setup.bin" "$WORK_DIR/OneShot_04_ClaudeCode_MCP_Setup_Windows.bat" "$WORK_DIR/.dhlabs_mint_seal.json"; do
    if [ -f "$f" ]; then
      dd if=/dev/zero of="$f" bs=1024 count=8 conv=notrunc 2>/dev/null || true
      rm -f "$f"
    fi
  done
  rm -rf "$LEDGER_DIR" 2>/dev/null || true
  exit 0
else
  echo "[SPOOL GUARD] Setup encountered an error before completion. Progress preserved in $SPOOL_FILE (installer kept for retry)."
  exit 1
fi
