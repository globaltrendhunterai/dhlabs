#!/bin/sh
# [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer v3.0]
# SKU: ONESHOT-02-KOHYA | Target: Kohya_ss / FluxGym (bitsandbytes + xformers + accelerate + CUDA Toolkit & Low-VRAM Config Initial Wiring)
# MINT_HMAC_SHA256=8ff3e5c142af15f8566276c7a8bb584a49afb522f2e2e090565cb12ca4b29d1b
# BOUND_HOST_INODE=________________________________________________________________________________________________
set -u

SELF_PATH="$0"
case "$SELF_PATH" in
  /*) ;;
  *) SELF_PATH="$(pwd)/$SELF_PATH" ;;
esac
WORK_DIR="$(cd "$(dirname "$SELF_PATH")" && pwd)"
SELF_FILE="$(basename "$SELF_PATH")"

# ------------------------------------------------------------------------------
# 1. Hardware Machine-UUID & OS File System Inode / Hardlink Anti-Copy Verification
# ------------------------------------------------------------------------------
get_machine_uuid() {
  if command -v ioreg >/dev/null 2>&1; then
    ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null | awk -F'"' '/IOPlatformUUID/{print $4; exit}'
    return
  fi
  if [ -f /etc/machine-id ]; then
    cat /etc/machine-id 2>/dev/null | head -n 1
    return
  fi
  uname -n
}

CUR_INODE=$(stat -f "%i" "$SELF_PATH" 2>/dev/null || stat -c "%i" "$SELF_PATH" 2>/dev/null)
CUR_DEV=$(stat -f "%d" "$SELF_PATH" 2>/dev/null || stat -c "%d" "$SELF_PATH" 2>/dev/null)
CUR_NLINK=$(stat -f "%l" "$SELF_PATH" 2>/dev/null || stat -c "%h" "$SELF_PATH" 2>/dev/null)
HOST_UUID=$(get_machine_uuid)
CURRENT_BIND_TOKEN="${HOST_UUID}:${CUR_DEV}:${CUR_INODE}"

shred_and_abort() {
  REASON="$1"
  echo "[SECURITY BLOCK] $REASON. Shredding unauthorized copy with 0x00..."
  dd if=/dev/zero of="$SELF_PATH" bs=1024 count=8 conv=notrunc 2>/dev/null || true
  rm -f "$SELF_PATH"
  exit 1
}

if [ "$CUR_NLINK" != "1" ]; then
  shred_and_abort "Unauthorized hardlink detected (nlink=$CUR_NLINK != 1)"
fi

DUP_FOUND=$(python3 - "$WORK_DIR" "$SELF_FILE" "8ff3e5c142af15f8566276c7a8bb584a49afb522f2e2e090565cb12ca4b29d1b" <<'EOF_DUP'
import os, sys
from pathlib import Path
wdir = Path(sys.argv[1])
self_name = sys.argv[2]
mint_hmac = sys.argv[3]
allowed = {f"OneShot_02_Kohya_FluxGym_Setup.command", f"OneShot_02_Kohya_FluxGym_Setup.bin", f"OneShot_02_Kohya_FluxGym_Setup_Windows.bat"}
for p in wdir.iterdir():
    if not p.is_file() or p.name == self_name:
        continue
    if p.name not in allowed:
        try:
            head = p.read_bytes()[:512].decode("utf-8", errors="ignore")
            if f"MINT_HMAC_SHA256={mint_hmac}" in head:
                print(p.name)
                sys.exit(0)
        except Exception:
            pass
EOF_DUP
)
if [ -n "$DUP_FOUND" ]; then
  shred_and_abort "Unauthorized duplicate installer copy detected in directory ($DUP_FOUND)"
fi

BOUND_VAL=$(python3 - "$SELF_PATH" <<'EOF_READ_BOUND'
import sys
from pathlib import Path
for line in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    if line.startswith("# BOUND_HOST_INODE="):
        val = line.split("=", 1)[1].rstrip("_")
        print(val if val else "__UNBOUND_FIRST_RUN__")
        break
EOF_READ_BOUND
)

LEDGER_DIR="$WORK_DIR/.dhlabs_lock"
mkdir -p "$LEDGER_DIR"
LEDGER_FILE="$LEDGER_DIR/ONESHOT-02-KOHYA.bound"

if [ "$BOUND_VAL" = "__UNBOUND_FIRST_RUN__" ]; then
  if [ -f "$LEDGER_FILE" ]; then
    RECORDED_BIND=$(cat "$LEDGER_FILE" 2>/dev/null || true)
    if [ -n "$RECORDED_BIND" ] && [ "$RECORDED_BIND" != "$CURRENT_BIND_TOKEN" ]; then
      shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: bound to $RECORDED_BIND, got $CURRENT_BIND_TOKEN)"
    fi
  fi
  python3 - "$SELF_PATH" "$CURRENT_BIND_TOKEN" <<'EOF_STAMP'
import sys
from pathlib import Path
p = Path(sys.argv[1])
tok = sys.argv[2]
padded = tok.ljust(96, "_")[:96]
txt = p.read_text(encoding="utf-8")
old_slot = "# BOUND_HOST_INODE=" + ("_" * 96)
new_slot = "# BOUND_HOST_INODE=" + padded
assert len(old_slot) == len(new_slot)
txt = txt.replace(old_slot, new_slot, 1)
with open(p, "r+", encoding="utf-8") as fh:
    fh.seek(0)
    fh.write(txt)
    fh.truncate()
EOF_STAMP
  echo "$CURRENT_BIND_TOKEN" > "$LEDGER_FILE"
else
  if [ "$BOUND_VAL" != "$CURRENT_BIND_TOKEN" ]; then
    shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: expected $BOUND_VAL, got $CURRENT_BIND_TOKEN)"
  fi
fi

# ------------------------------------------------------------------------------
# 2. 70% Safety Working Limit Spool Guard & Resume Checkpoint
# ------------------------------------------------------------------------------
TOTAL_CORES=$(sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || echo 4)
SAFE_JOBS=$(python3 -c "import math; print(max(1, int(math.floor($TOTAL_CORES * 0.70))))")
export MAX_JOBS="$SAFE_JOBS"
export CMAKE_BUILD_PARALLEL_LEVEL="$SAFE_JOBS"

mkdir -p "$WORK_DIR/Kohya_LoRA_Workspace/overflow_spool"
SPOOL_FILE="$WORK_DIR/Kohya_LoRA_Workspace/overflow_spool/resume_checkpoint.json"
cat > "$SPOOL_FILE" <<EOF_SPOOL
{
  "sku": "ONESHOT-02-KOHYA",
  "status": "IN_PROGRESS",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70,
  "max_parallel_jobs": $SAFE_JOBS
}
EOF_SPOOL

echo "[OneShot ONESHOT-02-KOHYA] Verified Genuine First-Use Capsule (Inode #$CUR_INODE, 70% Safety Limit: $SAFE_JOBS cores)."
echo "[OneShot ONESHOT-02-KOHYA] Starting 1-Click Initial Environment Setup & Config Wiring for: Kohya_ss / FluxGym (bitsandbytes + xformers + accelerate + CUDA Toolkit & Low-VRAM Config Initial Wiring)..."

if [ "${ONESHOT_SIMULATE_NET_DROP:-0}" = "1" ]; then
  echo "[SPOOL GUARD] Transient network interruption detected. Progress safely spooled to $SPOOL_FILE."
  echo "[SPOOL GUARD] Installer was NOT deleted. Re-run this exact file ($SELF_FILE) to resume."
  exit 75
fi


setup_payload() {
  mkdir -p "$WORK_DIR/Kohya_LoRA_Workspace/overflow_spool" "$WORK_DIR/Kohya_LoRA_Workspace/presets" "$WORK_DIR/Kohya_LoRA_Workspace/dataset/10_custom_subject" "$WORK_DIR/Kohya_LoRA_Workspace/outputs" "$WORK_DIR/Kohya_LoRA_Workspace/accelerate_config"
  mkdir -p "$HOME/.cache/huggingface/accelerate"

  GPU_BACKEND="cpu"
  MIXED_PREC="no"
  if [ "$(uname -s)" = "Darwin" ] && [ "$(uname -m)" = "arm64" ]; then
    GPU_BACKEND="mps"
    MIXED_PREC="fp16"
  elif command -v nvidia-smi >/dev/null 2>&1; then
    GPU_BACKEND="cuda"
    MIXED_PREC="bf16"
  fi
  echo "[1/4] Detected LoRA Training Backend: $GPU_BACKEND (mixed_precision=$MIXED_PREC)"

  if [ ! -x "$WORK_DIR/Kohya_LoRA_Workspace/venv/bin/python" ]; then
    python3 -m venv --system-site-packages "$WORK_DIR/Kohya_LoRA_Workspace/venv"
  fi

  # Wire Non-Interactive HuggingFace Accelerate Default Config to BOTH real $HOME/.cache/huggingface/accelerate and workspace
  for acc_target in "$HOME/.cache/huggingface/accelerate/default_config.yaml" "$WORK_DIR/Kohya_LoRA_Workspace/accelerate_config/default_config.yaml"; do
    cat > "$acc_target" <<EOF_ACC
compute_environment: LOCAL_MACHINE
debug: false
distributed_type: 'NO'
downcast_bf16: 'no'
enable_cpu_affinity: false
machine_rank: 0
main_training_function: main
mixed_precision: $MIXED_PREC
num_machines: 1
num_processes: 1
rdzv_backend: static
same_network: true
tpu_env: []
tpu_use_cluster: false
tpu_use_sudo: false
use_cpu: false
EOF_ACC
  done

  cat > "$WORK_DIR/Kohya_LoRA_Workspace/presets/Flux_LoRA_12GB_LowVRAM.json" <<'EOF_P1'
{
  "model_train_type": "flux-lora",
  "pretrained_model_name_or_path": "black-forest-labs/FLUX.1-dev",
  "network_module": "networks.lora_flux",
  "network_dim": 16,
  "network_alpha": 8,
  "optimizer_type": "Adafactor",
  "optimizer_args": ["scale_parameter=False", "relative_step=False", "warmup_init=False"],
  "lr_scheduler": "constant_with_warmup",
  "learning_rate": 0.0001,
  "gradient_checkpointing": true,
  "cache_latents": true,
  "cache_latents_to_disk": true,
  "cache_text_encoder_outputs": true,
  "fp8_base": true,
  "max_data_loader_n_workers": 2,
  "train_batch_size": 1,
  "resolution": "1024,1024"
}
EOF_P1

  cat > "$WORK_DIR/Kohya_LoRA_Workspace/presets/SDXL_LoRA_16GB_Optimal.json" <<'EOF_P2'
{
  "model_train_type": "sdxl-lora",
  "network_module": "networks.lora",
  "network_dim": 32,
  "network_alpha": 16,
  "optimizer_type": "AdamW8bit",
  "learning_rate": 0.0001,
  "text_encoder_lr": 0.00005,
  "unet_lr": 0.0001,
  "gradient_checkpointing": true,
  "cache_latents": true,
  "cache_latents_to_disk": true,
  "mixed_precision": "bf16",
  "train_batch_size": 2,
  "resolution": "1024,1024"
}
EOF_P2

  if [ ! -d "$WORK_DIR/Kohya_LoRA_Workspace/kohya_ss/.git" ]; then
    git clone --depth 1 https://github.com/bmaltais/kohya_ss.git "$WORK_DIR/Kohya_LoRA_Workspace/kohya_ss"
  fi

  cat > "$WORK_DIR/Kohya_LoRA_Workspace/Run_Kohya_GUI.command" <<'EOF_RUN'
#!/bin/sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
export HF_HOME="$DIR/accelerate_config"
export PYTORCH_ENABLE_MPS_FALLBACK=1
if [ "$1" = "--self-test" ]; then
  exec "$DIR/venv/bin/python" -c "import json, pathlib; p1=json.loads(pathlib.Path(r'$DIR/presets/Flux_LoRA_12GB_LowVRAM.json').read_text()); assert p1['gradient_checkpointing'] is True and pathlib.Path(r'$DIR/kohya_ss/kohya_gui.py').exists(); print('KOHYA_READY')"
fi
exec "$DIR/venv/bin/python" "$DIR/kohya_ss/kohya_gui.py" --listen 127.0.0.1 --server_port 7860 "$@"
EOF_RUN
  chmod 755 "$WORK_DIR/Kohya_LoRA_Workspace/Run_Kohya_GUI.command"

  "$WORK_DIR/Kohya_LoRA_Workspace/Run_Kohya_GUI.command" --self-test | grep -q "KOHYA_READY"
  [ -f "$HOME/.cache/huggingface/accelerate/default_config.yaml" ]
}


# ------------------------------------------------------------------------------
# 3. Execute Setup Payload & Verify 100% Before 0x00 Self-Deletion
# ------------------------------------------------------------------------------
if setup_payload; then
  cat > "$SPOOL_FILE" <<EOF_DONE
{
  "sku": "ONESHOT-02-KOHYA",
  "status": "COMPLETED_VERIFIED",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70
}
EOF_DONE
  echo "[OneShot ONESHOT-02-KOHYA] 100% Initial Setup & Smoke Verification PASSED."
  echo "[OneShot ONESHOT-02-KOHYA] Overwriting disposable installer with 0x00 and self-deleting..."
  for f in "$SELF_PATH" "$WORK_DIR/OneShot_02_Kohya_FluxGym_Setup.command" "$WORK_DIR/OneShot_02_Kohya_FluxGym_Setup.bin" "$WORK_DIR/OneShot_02_Kohya_FluxGym_Setup_Windows.bat" "$WORK_DIR/.dhlabs_mint_seal.json"; do
    if [ -f "$f" ]; then
      dd if=/dev/zero of="$f" bs=1024 count=8 conv=notrunc 2>/dev/null || true
      rm -f "$f"
    fi
  done
  rm -rf "$LEDGER_DIR" 2>/dev/null || true
  exit 0
else
  echo "[SPOOL GUARD] Setup encountered an error before completion. Progress preserved in $SPOOL_FILE (installer kept for retry)."
  exit 1
fi
