@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-02-KOHYA | MINT_HMAC_SHA256=8ff3e5c142af15f8566276c7a8bb584a49afb522f2e2e090565cb12ca4b29d1b
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_02_Kohya_FluxGym_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-02-KOHYA] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
