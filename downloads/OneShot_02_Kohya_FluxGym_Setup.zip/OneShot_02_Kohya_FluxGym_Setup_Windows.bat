@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-02-KOHYA | MINT_HMAC_SHA256=ce8d341cbdce57caf9327c13ef327125f2b9ab26927d6f28948e2d37b7c844ae
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_02_Kohya_FluxGym_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-02-KOHYA] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
