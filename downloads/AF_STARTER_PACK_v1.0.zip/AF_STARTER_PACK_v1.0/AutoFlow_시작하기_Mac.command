#!/usr/bin/env bash
export LANG="en_US.UTF-8"
export LC_ALL="en_US.UTF-8"
# 프록시 환경 방어 (외부 VPN/Fiddler 바이패스)
export NO_PROXY="127.0.0.1,localhost"
export no_proxy="127.0.0.1,localhost"

# ==============================================================================
# 0. macOS Gatekeeper Quarantine Auto-Release
# ==============================================================================
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Recursively unquarantine all downloaded package files (Zero Gatekeeper Warnings)
xattr -dr com.apple.quarantine "$SCRIPT_DIR" 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/autoflow_rust "$SCRIPT_DIR"/.system/daemon/autoflow_rust "$SCRIPT_DIR"/.system/autoflow_rust 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/bin/node "$SCRIPT_DIR"/.system/bin/node "$SCRIPT_DIR"/bin/*.sh "$SCRIPT_DIR"/.system/scripts/*.sh "$SCRIPT_DIR"/scripts/*.sh 2>/dev/null || true

# ==============================================================================
# AutoFlow Enterprise 1-Click Instant Launcher for macOS
# Automatically handles Colima/Docker Daemon, spins up n8n & Defender, opens UI
# ==============================================================================

echo "================================================================================"
echo "⚡ AutoFlow Enterprise 1-Click Instant Launcher (macOS)"
echo "   Directory: $SCRIPT_DIR"
echo "================================================================================"

# ==============================================================================
# 0-A. Single Instance Mutex Lock Guard & Stale PID Defense
# ==============================================================================
CHECK_RUNNING=0
TARGET_PORT="${PORT:-5678}"
PORT_FILE="$SCRIPT_DIR/logs/active_port.txt"
if [ ! -f "$PORT_FILE" ] && [ -f "$SCRIPT_DIR/.system/logs/active_port.txt" ]; then
    PORT_FILE="$SCRIPT_DIR/.system/logs/active_port.txt"
fi
if [ -f "$PORT_FILE" ]; then
    SAVED_PORT=$(cat "$PORT_FILE" 2>/dev/null | tr -d '[:space:]')
    if [ -n "$SAVED_PORT" ]; then TARGET_PORT="$SAVED_PORT"; fi
fi

PID_FILE="$SCRIPT_DIR/logs/engine.pid"
if [ ! -f "$PID_FILE" ] && [ -f "$SCRIPT_DIR/.system/logs/engine.pid" ]; then
    PID_FILE="$SCRIPT_DIR/.system/logs/engine.pid"
fi

if [ -f "$PID_FILE" ]; then
    EXISTING_PID=$(cat "$PID_FILE" 2>/dev/null | tr -d '[:space:]')
    if [ -n "$EXISTING_PID" ] && kill -0 "$EXISTING_PID" 2>/dev/null; then
        HTTP_CHECK=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 2 "http://127.0.0.1:${TARGET_PORT}/setup_wizard.html" || true)
        if [ "$HTTP_CHECK" = "200" ] || [ "$HTTP_CHECK" = "401" ] || [ "$HTTP_CHECK" = "302" ]; then
            CHECK_RUNNING=1
        else
            echo "⚠️ [Stale PID 감지] 프로세스(PID: $EXISTING_PID)가 포트 $TARGET_PORT 에 응답하지 않습니다. 기존 잠금을 해제합니다."
            kill -9 "$EXISTING_PID" 2>/dev/null || true
            rm -f "$PID_FILE" "$SCRIPT_DIR/logs/engine.pid" "$SCRIPT_DIR/.system/logs/engine.pid" 2>/dev/null || true
            CHECK_RUNNING=0
        fi
    else
        rm -f "$PID_FILE" "$SCRIPT_DIR/logs/engine.pid" "$SCRIPT_DIR/.system/logs/engine.pid" 2>/dev/null || true
        CHECK_RUNNING=0
    fi
fi

if [ $CHECK_RUNNING -eq 1 ]; then
    echo ""
    echo "================================================================================"
    echo "⚡ 이미 실행 중인 AutoFlow 엔진을 감지했습니다. 기존 브라우저 탭으로 안전하게 연결합니다."
    echo "================================================================================"
    echo "   ▶ 활성 포트: $TARGET_PORT"
    echo "   ▶ 중복 프로세스 스폰 방지 및 단일 인스턴스 락 활성화"
    echo "================================================================================"
    if [ "${AUTOFLOW_NO_BROWSER:-0}" != "1" ]; then
        open "http://127.0.0.1:${TARGET_PORT}"
    fi
    exit 0
fi

# ==============================================================================
# Legal Agreement & Liability Disclaimer Gate (Web Wizard Mandatory Gate)
# ==============================================================================
touch "$SCRIPT_DIR/.legal_agreed" 2>/dev/null || true
echo "⚖️  AutoFlow Enterprise 라이선스(EULA) 및 법적 면책 안내 (상세: EULA_PERPETUAL_LICENSE.md)"
echo "🚀 1초 초고속 백그라운드 기동을 시작합니다..."

# ==============================================================================
# Standalone Portable V8 Engine Fallback (Zero Docker Required)
# ==============================================================================
launch_standalone_engine() {
    echo ""
    echo "================================================================================"
    echo "⚡ [AutoFlow 자립 구동] Docker 미설치 감지 -> 동봉된 초경량 포터블 엔진(bin/node)으로 즉시 1초 자립 구동합니다."
    echo "================================================================================"
    
    NODE_BIN=""
    if [ -x "$SCRIPT_DIR/.system/bin/node" ] && "$SCRIPT_DIR/.system/bin/node" -v >/dev/null 2>&1; then
        NODE_BIN="$SCRIPT_DIR/.system/bin/node"
    elif [ -x "./bin/node" ] && ./bin/node -v >/dev/null 2>&1; then
        NODE_BIN="$SCRIPT_DIR/bin/node"
    elif [ -x "$SCRIPT_DIR/runtime/node_darwin/bin/node" ] && "$SCRIPT_DIR/runtime/node_darwin/bin/node" -v >/dev/null 2>&1; then
        NODE_BIN="$SCRIPT_DIR/runtime/node_darwin/bin/node"
    elif command -v node >/dev/null 2>&1 && "$(command -v node)" -v >/dev/null 2>&1; then
        NODE_BIN="$(command -v node)"
    elif [ -x "/opt/homebrew/bin/node" ] && /opt/homebrew/bin/node -v >/dev/null 2>&1; then
        NODE_BIN="/opt/homebrew/bin/node"
    elif [ -x "/usr/local/bin/node" ] && /usr/local/bin/node -v >/dev/null 2>&1; then
        NODE_BIN="/usr/local/bin/node"
    fi

    if [ -z "$NODE_BIN" ]; then
        ARCH_NAME="$(uname -m)"
        if [ "$ARCH_NAME" = "arm64" ]; then
            NODE_DIST_ARCH="darwin-arm64"
        else
            NODE_DIST_ARCH="darwin-x64"
        fi
        NODE_TAR_URL="https://nodejs.org/dist/v20.18.0/node-v20.18.0-${NODE_DIST_ARCH}.tar.gz"
        echo "📦 현재 Mac 아키텍처(${ARCH_NAME}) 전용 포터블 Node.js(${NODE_DIST_ARCH}) 무인 자동 다운로드 중..."
        mkdir -p "$SCRIPT_DIR/.system/bin" "$SCRIPT_DIR/bin"
        TMP_NODE_TGZ="$SCRIPT_DIR/.system/bin/node_portable.tar.gz"
        if curl -fsSL "$NODE_TAR_URL" -o "$TMP_NODE_TGZ"; then
            tar -xzf "$TMP_NODE_TGZ" -C "$SCRIPT_DIR/.system/bin" "node-v20.18.0-${NODE_DIST_ARCH}/bin/node" 2>/dev/null || tar -xzf "$TMP_NODE_TGZ" -C "$SCRIPT_DIR/.system/bin"
            if [ -f "$SCRIPT_DIR/.system/bin/node-v20.18.0-${NODE_DIST_ARCH}/bin/node" ]; then
                mv -f "$SCRIPT_DIR/.system/bin/node-v20.18.0-${NODE_DIST_ARCH}/bin/node" "$SCRIPT_DIR/.system/bin/node"
                rm -rf "$SCRIPT_DIR/.system/bin/node-v20.18.0-${NODE_DIST_ARCH}" "$TMP_NODE_TGZ"
            fi
            chmod +x "$SCRIPT_DIR/.system/bin/node" 2>/dev/null || true
            xattr -dr com.apple.quarantine "$SCRIPT_DIR/.system/bin/node" 2>/dev/null || true
            if [ -x "$SCRIPT_DIR/.system/bin/node" ] && "$SCRIPT_DIR/.system/bin/node" -v >/dev/null 2>&1; then
                NODE_BIN="$SCRIPT_DIR/.system/bin/node"
                echo "✅ 아키텍처 맞춤 포터블 Node.js(${NODE_DIST_ARCH}) 준비 완료!"
            fi
        fi
    fi
    PORTABLE_NODE="$NODE_BIN"
    
    PORTABLE_ENTRY=""
    if [ -f "$SCRIPT_DIR/.system/bin/n8n-entry.js" ]; then
        PORTABLE_ENTRY="$SCRIPT_DIR/.system/bin/n8n-entry.js"
    elif [ -f "$SCRIPT_DIR/bin/n8n-entry.js" ]; then
        PORTABLE_ENTRY="$SCRIPT_DIR/bin/n8n-entry.js"
    elif [ -f "$SCRIPT_DIR/dist/common_assets/n8n-entry.js" ]; then
        PORTABLE_ENTRY="$SCRIPT_DIR/dist/common_assets/n8n-entry.js"
    fi
    
    if [ -z "$PORTABLE_NODE" ] || [ -z "$PORTABLE_ENTRY" ]; then
        echo "❌ [ERROR] 초경량 포터블 엔진 파일(bin/node 또는 bin/n8n-entry.js)을 찾을 수 없습니다."
        read -p "Press [Enter] to exit..."
        exit 1
    fi
    
    mkdir -p "$SCRIPT_DIR/logs" "$SCRIPT_DIR/.system/logs"
    
    # 0-Sync: Double-Click Instant Cloud & OS Anchor Synchronization (Non-blocking background sync for 3-sec instant boot)
    RECHARGE_CLI="$SCRIPT_DIR/.system/core/recharge_cli.js"
    if [ ! -f "$RECHARGE_CLI" ]; then RECHARGE_CLI="$SCRIPT_DIR/core/recharge_cli.js"; fi
    if [ -f "$RECHARGE_CLI" ]; then
        ( "$PORTABLE_NODE" "$RECHARGE_CLI" sync >/dev/null 2>&1 ) &
    fi

    echo "🚀 동봉된 포터블 Node.js V8 런타임으로 즉각 백그라운드 기동 중..."
    echo "   ▶ 런타임: $PORTABLE_NODE"
    echo "   ▶ 엔트리: $PORTABLE_ENTRY"
    
    nohup "$PORTABLE_NODE" "$PORTABLE_ENTRY" > "$SCRIPT_DIR/logs/standalone_engine.log" 2>&1 &
    ENGINE_PID=$!
    echo "$ENGINE_PID" > "$SCRIPT_DIR/logs/engine.pid"
    echo "$ENGINE_PID" > "$SCRIPT_DIR/.system/logs/engine.pid" 2>/dev/null || true
    
    # Keep Mac awake as long as engine process lives (even after launcher script exits)
    caffeinate -d -i -m -u -w "$ENGINE_PID" &
    
    echo "✅ 자립 구동 엔진 프로세스 활성화 (PID: $ENGINE_PID)"

    # Launch Sidecar Daemons & Watchdog
    SIDECAR_JS="$SCRIPT_DIR/.system/core/autoflow_sidecar_daemon.js"
    if [ ! -f "$SIDECAR_JS" ]; then SIDECAR_JS="$SCRIPT_DIR/core/autoflow_sidecar_daemon.js"; fi
    if [ -f "$SIDECAR_JS" ]; then
        nohup "$PORTABLE_NODE" "$SIDECAR_JS" > "$SCRIPT_DIR/logs/sidecar_daemon.log" 2>&1 &
        echo "$!" > "$SCRIPT_DIR/logs/sidecar.pid"
        echo "✅ 자가치유 사이드카 데몬 활성화 (포트: 8080)"
    fi

    BEACON_JS="$SCRIPT_DIR/.system/core/telemetry_beacon.js"
    if [ ! -f "$BEACON_JS" ]; then BEACON_JS="$SCRIPT_DIR/core/telemetry_beacon.js"; fi
    if [ -f "$BEACON_JS" ]; then
        nohup "$PORTABLE_NODE" "$BEACON_JS" > "$SCRIPT_DIR/logs/telemetry_beacon.log" 2>&1 &
        echo "$!" > "$SCRIPT_DIR/logs/beacon.pid"
        echo "✅ 원격 관제 텔레메트리 비콘 활성화"
    fi

    WATCHDOG_JS="$SCRIPT_DIR/.system/core/watchdog.js"
    if [ ! -f "$WATCHDOG_JS" ]; then WATCHDOG_JS="$SCRIPT_DIR/core/watchdog.js"; fi
    if [ -f "$WATCHDOG_JS" ]; then
        nohup "$PORTABLE_NODE" "$WATCHDOG_JS" > "$SCRIPT_DIR/logs/watchdog.log" 2>&1 &
        echo "$!" > "$SCRIPT_DIR/logs/watchdog.pid"
        echo "✅ 프로세스 무인 수호 와치독 활성화 (포트 감시)"
    fi
    
    # Resolve dynamic active port & verify process liveness (wait up to 10s with 0.5s polling)
    ACTUAL_PORT=""
    PORT_FILE="$SCRIPT_DIR/logs/active_port.txt"
    POLL_COUNT=0
    ENGINE_HEALTHY=0
    while [ $POLL_COUNT -lt 20 ]; do
        if [ -n "$ENGINE_PID" ] && ! kill -0 "$ENGINE_PID" 2>/dev/null; then
            break
        fi
        if [ ! -f "$PORT_FILE" ] && [ -f "$SCRIPT_DIR/.system/logs/active_port.txt" ]; then
            PORT_FILE="$SCRIPT_DIR/.system/logs/active_port.txt"
        fi
        if [ -f "$PORT_FILE" ]; then
            READ_PORT=$(cat "$PORT_FILE" 2>/dev/null | tr -d '[:space:]')
            if [ -n "$READ_PORT" ] && [ "$READ_PORT" -eq "$READ_PORT" ] 2>/dev/null; then
                HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 1 "http://127.0.0.1:${READ_PORT}/setup_wizard.html" || true)
                if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "401" ] || [ "$HTTP_CODE" = "302" ]; then
                    ACTUAL_PORT="$READ_PORT"
                    ENGINE_HEALTHY=1
                    break
                fi
            fi
        fi
        sleep 0.5
        POLL_COUNT=$((POLL_COUNT + 1))
    done

    # 백그라운드 엔진 기동 실패 가드 (가짜 성공 EXIT_CODE=0 은폐 차단)
    if [ $ENGINE_HEALTHY -eq 0 ]; then
        if [ -n "$ENGINE_PID" ] && ! kill -0 "$ENGINE_PID" 2>/dev/null; then
            echo ""
            echo "❌ [오류] AutoFlow 백그라운드 엔진 프로세스(PID: $ENGINE_PID)가 비정상 종료되었습니다."
        else
            echo ""
            echo "❌ [오류] AutoFlow 엔진이 응답하지 않거나 기동에 실패했습니다."
        fi
        if [ -f "$SCRIPT_DIR/logs/standalone_engine.log" ]; then
            echo "📋 [부팅 에러 로그 (standalone_engine.log)]:"
            tail -n 25 "$SCRIPT_DIR/logs/standalone_engine.log"
        fi
        echo ""
        read -p "창을 닫으려면 엔터(Enter) 키를 누르세요..."
        exit 1
    fi

    if [ -d "$HOME/Desktop" ]; then
        cat <<EOF > "$HOME/Desktop/AutoFlow_설정열기.url"
[InternetShortcut]
URL=http://127.0.0.1:${ACTUAL_PORT}
EOF
        echo "[INFO] Desktop shortcut created: ~/Desktop/AutoFlow_설정열기.url"
    fi

    echo "🌐 AutoFlow Studio 브라우저를 자동 오픈합니다 (포트: ${ACTUAL_PORT})..."
    if [ "${AUTOFLOW_NO_BROWSER:-0}" != "1" ]; then
        open "http://127.0.0.1:${ACTUAL_PORT}"
    fi
    
    echo ""
    echo "================================================================================"
    echo "🎉 AutoFlow 무설치 자립 구동 모드로 정상 실행되었습니다!"
    echo "================================================================================"
    echo "   - n8n Studio UI:       http://127.0.0.1:${ACTUAL_PORT}"
    echo "   - 사내 PC 정합성 관제: file://$SCRIPT_DIR/recon_quarantine_viewer.html"
    echo "   - 엔진 로그:           $SCRIPT_DIR/logs/standalone_engine.log"
    echo "   - 워크플로우 보관소:   $SCRIPT_DIR/blueprints"
    echo "================================================================================"
    echo "ℹ️ 이 터미널 창을 닫아도 AutoFlow는 백그라운드에서 계속 실행됩니다."
    echo ""
    exit 0
}

# 1. Check if this is a Standalone Portable Package (no docker-compose file bundled) or Docker CLI is absent
if [ ! -f "$SCRIPT_DIR/docker-compose.enterprise.yml" ] && [ ! -f "$SCRIPT_DIR/docker-compose.autoflow.yml" ] && [ ! -f "$SCRIPT_DIR/docker-compose.yml" ]; then
    launch_standalone_engine
fi

if ! command -v docker &> /dev/null; then
    launch_standalone_engine
fi

# 2. Check Docker Daemon & Auto-Start (Colima / Docker Desktop)
echo "🔍 Checking Docker Daemon status..."
if ! docker info &> /dev/null; then
    echo "⚠️ Docker daemon is not active. Attempting auto-recovery..."
    
    # 2-A: Try Colima if present
    if command -v colima &> /dev/null; then
        echo "🚀 Detected Colima. Starting Colima runtime..."
        colima start || true
    fi
    
    # 2-B: If still down, try opening Docker Desktop app
    if ! docker info &> /dev/null; then
        if [ -d "/Applications/Docker.app" ]; then
            echo "🚀 Launching Docker Desktop application..."
            open -a Docker
        fi
        
        echo ""
        echo "⏳ Waiting for Docker Daemon to become ready (base 180s)..."
        echo "💡 (Note: Intel Mac, older hardware, or initial cold boot may take 1 to 2 minutes)"
        
        WAIT_COUNT=0
        MAX_WAIT=180
        
        while ! docker info &> /dev/null; do
            sleep 5
            WAIT_COUNT=$((WAIT_COUNT + 5))
            echo "   ... waiting for Docker Daemon ($WAIT_COUNT s / $MAX_WAIT s)"
            
            if [ $WAIT_COUNT -ge $MAX_WAIT ]; then
                echo ""
                echo "⚠️ [NOTICE] Docker daemon did not finish starting within $MAX_WAIT seconds."
                echo "❓ Would you like to wait an additional 60 seconds? (System might be under heavy load)"
                read -p "👉 Wait more? [Y = Yes, wait 60s / N = Cancel]: " USER_CHOICE
                
                case "$USER_CHOICE" in
                    [yY][eE][sS]|[yY])
                        MAX_WAIT=$((MAX_WAIT + 60))
                        echo "🔄 Extending wait time to $MAX_WAIT seconds..."
                        ;;
                    *)
                        echo ""
                        echo "⚠️ Docker 데몬 응답 없음 -> 초경량 포터블 엔진(bin/node)으로 즉시 자립 구동합니다."
                        launch_standalone_engine
                        ;;
                esac
            fi
        done
        echo ""
    fi
fi

echo "✅ Docker Daemon is ACTIVE and ready!"

# 3. Locate Compose File (Prioritize enterprise specification)
COMPOSE_FILE="docker-compose.enterprise.yml"
if [ ! -f "$COMPOSE_FILE" ]; then
    if [ -f "docker-compose.autoflow.yml" ]; then
        COMPOSE_FILE="docker-compose.autoflow.yml"
    elif [ -f "docker-compose.yml" ]; then
        COMPOSE_FILE="docker-compose.yml"
    else
        launch_standalone_engine
    fi
fi
echo "📁 Target Compose File: $COMPOSE_FILE"

# 4. Detect Docker Compose CLI
if docker compose version &> /dev/null; then
    COMPOSE_CMD="docker compose"
elif command -v docker-compose &> /dev/null; then
    COMPOSE_CMD="docker-compose"
else
    echo "❌ [ERROR] Neither 'docker compose' nor 'docker-compose' was found."
    read -p "Press [Enter] to exit..."
    exit 1
fi
echo "⚙️ Using Compose Command: $COMPOSE_CMD"

# 5. Launch containers in background
echo "🚀 Starting AutoFlow containers in detached mode..."
$COMPOSE_CMD -f "$COMPOSE_FILE" up -d

if [ $? -ne 0 ]; then
    echo "❌ [ERROR] Failed to start Docker containers."
    read -p "Press [Enter] to exit..."
    exit 1
fi

# 6. Verify container health
echo "🔍 Checking container status..."
$COMPOSE_CMD -f "$COMPOSE_FILE" ps

# 7. Create Desktop Shortcut & Open Browser UI
ACTUAL_PORT=""
PORT_FILE="$SCRIPT_DIR/logs/active_port.txt"
POLL_COUNT=0
while [ $POLL_COUNT -lt 10 ]; do
    if [ -f "$PORT_FILE" ]; then
        READ_PORT=$(cat "$PORT_FILE" 2>/dev/null | tr -d '[:space:]')
        if [ -n "$READ_PORT" ] && [ "$READ_PORT" -eq "$READ_PORT" ] 2>/dev/null; then
            ACTUAL_PORT="$READ_PORT"
            break
        fi
    fi
    sleep 0.5
    POLL_COUNT=$((POLL_COUNT + 1))
done

if [ -z "$ACTUAL_PORT" ]; then
    ACTUAL_PORT="${PORT:-5678}"
fi

if [ -d "$HOME/Desktop" ]; then
    cat <<EOF > "$HOME/Desktop/AutoFlow_설정열기.url"
[InternetShortcut]
URL=http://127.0.0.1:${ACTUAL_PORT}
EOF
    echo "[INFO] Desktop shortcut created: ~/Desktop/AutoFlow_설정열기.url"
fi

echo "🌐 Launching AutoFlow Studio in default browser (Port: ${ACTUAL_PORT})..."
open "http://127.0.0.1:${ACTUAL_PORT}"

echo ""
echo "================================================================================"
echo "🎉 AutoFlow Enterprise Sidecar Successfully Launched!"
echo "================================================================================"
echo "   - n8n Studio UI:       http://127.0.0.1:${ACTUAL_PORT}"
echo "   - Defender Engine:     http://127.0.0.1:8080"
echo "   - 사내 PC 정합성 관제: file://$SCRIPT_DIR/recon_quarantine_viewer.html"
echo "   - Blueprints Location: $SCRIPT_DIR/blueprints"
echo "================================================================================"
echo "ℹ️ You may close this terminal window. AutoFlow will continue running in background."
echo ""
