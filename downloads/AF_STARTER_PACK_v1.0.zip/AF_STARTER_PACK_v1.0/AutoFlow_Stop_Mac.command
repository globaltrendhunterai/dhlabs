#!/usr/bin/env bash
export LANG="en_US.UTF-8"
export LC_ALL="en_US.UTF-8"
# ==============================================================================
# AutoFlow Enterprise 1-Click Safe Stop Launcher (macOS)
# Safely terminates watchdog.pid, engine.pid, sidecar.pid, beacon.pid,
# .rust_gateway.pid, and all package daemons (supports Korean + space + symlink paths)
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPT_DIR_PHYS="$(cd "$(dirname "$0")" && pwd -P)"
cd "$SCRIPT_DIR"

xattr -dr com.apple.quarantine "$SCRIPT_DIR" 2>/dev/null || true

echo "================================================================================"
echo "🛑 AutoFlow Enterprise 1-Click Stop Launcher (macOS)"
echo "   Directory: $SCRIPT_DIR"
echo "================================================================================"

CHECK_PORT="5678"
if [ -f "$SCRIPT_DIR/logs/active_port.txt" ]; then
    SAVED_PORT=$(cat "$SCRIPT_DIR/logs/active_port.txt" 2>/dev/null | tr -d '[:space:]')
    if [ -n "$SAVED_PORT" ]; then
        CHECK_PORT="$SAVED_PORT"
    fi
fi

STOPPED_COUNT=0

stop_pid_file() {
    local pid_file="$1"
    local label="$2"
    if [ -f "$pid_file" ]; then
        local target_pid
        target_pid=$(cat "$pid_file" 2>/dev/null | tr -d '[:space:]')
        if [ -n "$target_pid" ] && kill -0 "$target_pid" 2>/dev/null; then
            echo "🔹 Stopping $label (PID: $target_pid)..."
            kill -15 "$target_pid" 2>/dev/null || true
            sleep 0.1
            if kill -0 "$target_pid" 2>/dev/null; then
                kill -9 "$target_pid" 2>/dev/null || true
            fi
            STOPPED_COUNT=$((STOPPED_COUNT + 1))
        fi
        rm -f "$pid_file"
    fi
}

# Step 1. Stop PIDs recorded in PID files (watchdog.pid first to prevent respawn!)
stop_pid_file "$SCRIPT_DIR/logs/watchdog.pid" "Watchdog Daemon"
stop_pid_file "$SCRIPT_DIR/logs/engine.pid" "AutoFlow Engine"
stop_pid_file "$SCRIPT_DIR/logs/sidecar.pid" "Sidecar Daemon"
stop_pid_file "$SCRIPT_DIR/logs/beacon.pid" "Telemetry Beacon"
stop_pid_file "$SCRIPT_DIR/.rust_gateway.pid" "Rust Gateway"
stop_pid_file "$SCRIPT_DIR/.system/logs/watchdog.pid" "Watchdog Daemon (.system)"
stop_pid_file "$SCRIPT_DIR/.system/logs/engine.pid" "AutoFlow Engine (.system)"
stop_pid_file "$SCRIPT_DIR/.system/logs/sidecar.pid" "Sidecar Daemon (.system)"
stop_pid_file "$SCRIPT_DIR/.system/logs/beacon.pid" "Telemetry Beacon (.system)"

# Step 2. Stop any remaining package-scoped daemons (ps -ww + lsof \x.. UTF-8 decoding + physical symlink path)
match_process_to_package() {
    local pid="$1"
    local proc_cmd
    proc_cmd=$(ps -ww -p "$pid" -o command= 2>/dev/null || true)
    if [ -n "$proc_cmd" ]; then
        if [[ "$proc_cmd" == *"$SCRIPT_DIR"* ]] || [[ "$proc_cmd" == *"$SCRIPT_DIR_PHYS"* ]]; then
            return 0
        fi
    fi
    local raw_cwd
    raw_cwd=$(lsof -a -p "$pid" -d cwd -Fn 2>/dev/null | grep '^n' | cut -c2- || true)
    if [ -n "$raw_cwd" ]; then
        local decoded_cwd
        decoded_cwd=$(printf "%b" "$raw_cwd" 2>/dev/null || echo "$raw_cwd")
        if [ "$raw_cwd" = "$SCRIPT_DIR" ] || [ "$raw_cwd" = "$SCRIPT_DIR_PHYS" ] || [ "$decoded_cwd" = "$SCRIPT_DIR" ] || [ "$decoded_cwd" = "$SCRIPT_DIR_PHYS" ]; then
            return 0
        fi
    fi
    return 1
}

for TARGET in "watchdog.js" "n8n-entry.js" "autoflow_sidecar_daemon.js" "telemetry_beacon.js" "autoflow_rust"; do
    for PID in $(pgrep -f "$TARGET" 2>/dev/null || true); do
        if [ "$PID" = "$$" ]; then continue; fi
        if match_process_to_package "$PID"; then
            echo "🔹 Terminating $TARGET (PID: $PID)..."
            kill -15 "$PID" 2>/dev/null || true
            STOPPED_COUNT=$((STOPPED_COUNT + 1))
        fi
    done
done

sleep 0.4

# Force cleanup any stubborn processes in this directory
for TARGET in "watchdog.js" "n8n-entry.js" "autoflow_sidecar_daemon.js" "telemetry_beacon.js" "autoflow_rust"; do
    for PID in $(pgrep -f "$TARGET" 2>/dev/null || true); do
        if [ "$PID" = "$$" ]; then continue; fi
        if match_process_to_package "$PID"; then
            kill -9 "$PID" 2>/dev/null || true
        fi
    done
done

rm -f "$SCRIPT_DIR/logs/watchdog.pid" "$SCRIPT_DIR/logs/engine.pid" "$SCRIPT_DIR/logs/sidecar.pid" "$SCRIPT_DIR/logs/beacon.pid" "$SCRIPT_DIR/logs/active_port.txt" "$SCRIPT_DIR/.rust_gateway.pid"

# Step 3. Verify port release
PORT_WAIT=0
while [ $PORT_WAIT -lt 6 ]; do
    if ! lsof -ti :"$CHECK_PORT" >/dev/null 2>&1; then
        break
    fi
    sleep 0.3
    PORT_WAIT=$((PORT_WAIT + 1))
done

echo ""
echo "================================================================================"
echo "✅ AutoFlow 엔진 및 백그라운드 데몬이 안전하게 모두 종료되었습니다."
echo "   - 종료된 프로세스 감지 수: ${STOPPED_COUNT}개"
echo "   - 포트(${CHECK_PORT}) 반환 확인 완료"
echo "================================================================================"
exit 0
