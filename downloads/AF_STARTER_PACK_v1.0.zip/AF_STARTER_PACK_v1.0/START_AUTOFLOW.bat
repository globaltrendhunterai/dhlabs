@echo off
chcp 65001 >nul
cd /d "%~dp0"
title AutoFlow Production Workflow Suite - 1-Click Smart Launcher (Windows)
color 0B

echo ==============================================================================
echo    AutoFlow Production Workflow Suite - 1초 더블클릭 런처 (Windows)
echo    사내 영구 무인 자동화 엔진을 프로덕션 모드로 시작합니다.
echo ==============================================================================
echo.

:: 0. 포터블 Node.js 및 환경 경로 우선순위 설정
set PATH=%~dp0bin;%~dp0.internal_vault\bin;%PATH%
set TARGET_PORT=5678
if not "%N8N_PORT%"=="" set TARGET_PORT=%N8N_PORT%
set TARGET_URL=http://localhost:%TARGET_PORT%/setup_wizard.html

:: [방어벽 3차] 비상용 CONFIG_HERE.txt 기본 생성
if not exist "CONFIG_HERE.txt" (
    (
        echo # AutoFlow 초간편 메모장 설정 ^(브라우저 미오픈 시 사용^)
        echo # 아래 항목에 발급받으신 키를 입력하고 저장하신 후 런처를 다시 실행하시면 자동 적용됩니다.
        echo AUTORUN_LICENSE_SN=
        echo MARKET_API_KEY=
        echo MARKET_SECRET_KEY=
    ) > CONFIG_HERE.txt
)

:: 1. AutoFlow 엔진 기동 여부 검사 (logs\engine.pid 실제 프로세스 생존 검사)
set IS_RUNNING=0
if exist "logs\engine.pid" (
    for /f "usebackq tokens=*" %%p in ("logs\engine.pid") do (
        tasklist /fi "PID eq %%p" 2>nul | findstr /i "%%p" >nul 2>&1
        if not errorlevel 1 set IS_RUNNING=1
    )
)
if "%IS_RUNNING%"=="1" (
    echo [OK] AutoFlow 엔진이 이미 백그라운드에서 실행 중입니다.
    goto :OPEN_BROWSER
)

:: 2. n8n 실행 시도
echo [INFO] n8n 자동화 엔진을 백그라운드에서 가동합니다...
if not exist "logs" mkdir "logs"
if exist "logs\active_port.txt" del /f /q "logs\active_port.txt" >nul 2>&1
if exist "%~dp0bin\node.exe" (
    echo [INFO] 번들링된 포터블 Node.js로 무인 실행합니다...
    start /b "" "%~dp0bin\node.exe" "%~dp0bin\n8n-entry.js"
) else (
    where n8n >nul 2>&1
    if %ERRORLEVEL% equ 0 (
        start /b "" cmd /c "n8n start"
    ) else (
        where npx >nul 2>&1
        if %ERRORLEVEL% equ 0 (
            echo [INFO] npx를 감지했습니다. 무설치 포터블 모드로 n8n을 실행합니다...
            start /b "" cmd /c "npx --yes n8n start"
        ) else (
            echo [오류] 시스템에 Node.js 또는 n8n이 설치되어 있지 않습니다.
            echo https://nodejs.org 에서 Node.js LTS 버전을 설치하신 후 다시 실행해주세요.
            echo.
            pause
            exit /b 1
        )
    )
)

:: [콜드 스타트 방어] 능동 헬스체크 루프 (최대 10초) & active_port.txt 동적 감지
echo [INFO] 엔진 응답 및 동적 바인딩 포트를 감지하고 있습니다 (능동 헬스체크)...
for /l %%i in (1,1,20) do (
    if exist "logs\active_port.txt" (
        for /f "usebackq tokens=*" %%p in ("logs\active_port.txt") do set TARGET_PORT=%%p
        goto :PORT_RESOLVED
    )
    timeout /t 1 /nobreak >nul
)

:PORT_RESOLVED
if exist "logs\active_port.txt" (
    for /f "usebackq tokens=*" %%p in ("logs\active_port.txt") do set TARGET_PORT=%%p
)
set TARGET_URL=http://localhost:%TARGET_PORT%/setup_wizard.html

:OPEN_BROWSER
if exist "logs\active_port.txt" (
    for /f "usebackq tokens=*" %%p in ("logs\active_port.txt") do set TARGET_PORT=%%p
)
set TARGET_URL=http://localhost:%TARGET_PORT%/setup_wizard.html

:: [방어벽 2차] 클립보드 자동 복사
echo %TARGET_URL%| clip >nul 2>&1
echo [안내] 설정 주소가 클립보드에 자동 복사되었습니다 (Ctrl+V로 주소창 붙여넣기 가능).

:: [방어벽 1차] 단독 창 모드 실행 시도
start msedge --app="%TARGET_URL%" >nul 2>&1
if %ERRORLEVEL% neq 0 (
    start chrome --app="%TARGET_URL%" >nul 2>&1
    if %ERRORLEVEL% neq 0 (
        start "" "%TARGET_URL%"
    )
)

:SUCCESS_BANNER
echo.
echo ==============================================================================
echo   AutoFlow 엔진이 정상적으로 연결되었습니다!
echo   * 브라우저 URL: %TARGET_URL%
echo   * 활성 포트: %TARGET_PORT%
echo   * 워크플로우 적용 방법:
echo     1. 브라우저에서 n8n 화면 열기
echo     2. 본 폴더의 .n8n.json 워크플로우 파일을 n8n 캔버스로 드래그 앤 드롭
echo     3. 상단 'Active' 스위치를 켜면 즉시 실무 가동 완료!
echo   * 상세 매뉴얼: 3MIN_QUICKSTART_GUIDE.md
echo ==============================================================================
echo ※ 본 창을 닫아도 백그라운드에서 자동화 엔진이 계속 동작합니다.
echo.
timeout /t 5 >nul
