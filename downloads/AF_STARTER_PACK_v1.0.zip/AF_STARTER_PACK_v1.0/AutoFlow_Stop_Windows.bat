@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

title AutoFlow Enterprise 1-Click Safe Stop Launcher (Windows)
cd /d "%~dp0"
pushd "%~dp0" >nul 2>&1

echo ================================================================================
echo  AutoFlow Enterprise 1-Click Stop Launcher (Windows)
echo  Working Directory: %~dp0
echo ================================================================================

set CHECK_PORT=5678
if exist "logs\active_port.txt" (
    set /p SAVED_PORT=<"logs\active_port.txt"
    set SAVED_PORT=!SAVED_PORT: =!
    if not "!SAVED_PORT!"=="" set CHECK_PORT=!SAVED_PORT!
)

:: 1. Stop PID in logs/engine.pid (logs\engine.pid)
if exist "logs\engine.pid" (
    set /p ENGINE_PID=<"logs\engine.pid"
    set ENGINE_PID=!ENGINE_PID: =!
    if not "!ENGINE_PID!"=="" (
        echo [*] Stopping AutoFlow Engine ^(PID: !ENGINE_PID!^)...
        taskkill /F /T /PID !ENGINE_PID! >nul 2>&1
    )
    del /f /q "logs\engine.pid" >nul 2>&1
)
if exist "%~dp0.system\logs\engine.pid" (
    set /p ENGINE_PID=<"%~dp0.system\logs\engine.pid"
    set ENGINE_PID=!ENGINE_PID: =!
    if not "!ENGINE_PID!"=="" (
        echo [*] Stopping AutoFlow Engine (.system) ^(PID: !ENGINE_PID!^)...
        taskkill /F /T /PID !ENGINE_PID! >nul 2>&1
    )
    del /f /q "%~dp0.system\logs\engine.pid" >nul 2>&1
)

:: 2. Stop PID in .rust_gateway.pid
if exist ".rust_gateway.pid" (
    set /p RUST_PID=<".rust_gateway.pid"
    set RUST_PID=!RUST_PID: =!
    if not "!RUST_PID!"=="" (
        echo [*] Stopping Rust Gateway ^(PID: !RUST_PID!^)...
        taskkill /F /T /PID !RUST_PID! >nul 2>&1
    )
    del /f /q ".rust_gateway.pid" >nul 2>&1
)

:: 3. Stop package-scoped daemons (watchdog.js, n8n-entry.js, autoflow_sidecar_daemon.js, telemetry_beacon.js, autoflow_rust)
echo [*] Terminating package background daemons (n8n-entry.js, autoflow_sidecar_daemon.js, telemetry_beacon.js, watchdog.js, autoflow_rust)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$dir = '%~dp0'.TrimEnd('\'); $targets = @('watchdog.js', 'n8n-entry.js', 'autoflow_sidecar_daemon.js', 'telemetry_beacon.js', 'autoflow_rust', 'windows_keepalive.ps1'); Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | ForEach-Object { $cmd = $_.CommandLine; $exe = $_.ExecutablePath; if ($cmd) { foreach ($t in $targets) { if ($cmd -like ('*' + $t + '*')) { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } } } if ($exe -and $exe.StartsWith($dir, [System.StringComparison]::OrdinalIgnoreCase)) { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } }" >nul 2>&1

if exist "logs\active_port.txt" del /f /q "logs\active_port.txt" >nul 2>&1

:: 4. Verify port release
timeout /t 1 /nobreak >nul
netstat -ano | findstr /R /C:":!CHECK_PORT! " >nul 2>&1
if !ERRORLEVEL! EQU 0 (
    for /f "tokens=5" %%a in ('netstat -aon ^| findstr /R /C:":!CHECK_PORT! "') do (
        taskkill /F /PID %%a >nul 2>&1
    )
)

echo.
echo ================================================================================
echo  [OK] AutoFlow 엔진 및 백그라운드 데몬이 안전하게 모두 종료되었습니다.
echo   - 포트(!CHECK_PORT!) 반환 및 PID 잠금 해제 완료
echo ================================================================================
timeout /t 2 /nobreak >nul
popd >nul 2>&1
exit /b 0
