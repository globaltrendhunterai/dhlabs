@echo off
chcp 65001 >nul
cd /d "%~dp0"
title AutoFlow 24/7 Self-Healing System (원클릭 지능형 자가치유)
color 0b

echo ==============================================================================
echo   AutoFlow 24시간 무인 자가치유 실행기 (Windows)
echo   사내 영구 무인 자동화 엔진 환경 소독 및 자가 복구를 진행합니다.
echo ==============================================================================
echo.

set TARGET_PORT=5678
set BOOTED=0

:: 1. Node 런타임 및 엔트리 파일 경로 탐색
set NODE_BIN=
if exist "%~dp0bin\node.exe" set NODE_BIN=%~dp0bin\node.exe
if "%NODE_BIN%"=="" (
    where node >nul 2>&1
    if not errorlevel 1 set NODE_BIN=node
)

if "%NODE_BIN%"=="" (
    echo [오류] Node.js 런타임을 찾을 수 없습니다.
    echo https://nodejs.org 에서 Node.js LTS 버전을 설치하신 후 다시 실행해주세요.
    echo.
    pause
    exit /b 1
)

set ENTRY_FILE=
if exist "%~dp0bin\n8n-entry.js" set ENTRY_FILE=%~dp0bin\n8n-entry.js
if "%ENTRY_FILE%"=="" (
    if exist "%~dp0n8n-entry.js" set ENTRY_FILE=%~dp0n8n-entry.js
)

if "%ENTRY_FILE%"=="" (
    echo [오류] AutoFlow 엔진 진입점(n8n-entry.js)을 찾을 수 없습니다.
    echo.
    pause
    exit /b 1
)

if not exist "logs" mkdir "logs"

:: 2. 기존 프로세스 소독
echo [Step 1] 기존 프로세스 상태 진단 및 환경 소독...
if exist "logs\engine.pid" (
    for /f "usebackq tokens=*" %%p in ("logs\engine.pid") do (
        taskkill /f /pid %%p >nul 2>&1
    )
    del /f /q "logs\engine.pid" >nul 2>&1
)
if exist "logs\active_port.txt" del /f /q "logs\active_port.txt" >nul 2>&1

:: 3. 번들 Node 엔진 백그라운드 기동
echo.
echo [Step 2] 번들 Node 엔진 백그라운드 안전 기동...
start /b "" "%NODE_BIN%" "%ENTRY_FILE%" > logs\autoflow_engine.log 2>&1

:: 4. 능동 헬스체크 및 동적 포트 감지 (최대 15초)
echo.
echo [Step 3] 엔진 부팅 완료 및 동적 바인딩 포트 감지 (능동 헬스체크)...
for /l %%i in (1,1,30) do (
    if exist "logs\active_port.txt" (
        for /f "usebackq tokens=*" %%p in ("logs\active_port.txt") do set TARGET_PORT=%%p
        set BOOTED=1
        goto :REPAIR_CHECK_DONE
    )
    curl.exe -s -f -m 1 http://127.0.0.1:5678/setup_wizard.html >nul 2>&1
    if not errorlevel 1 (
        set TARGET_PORT=5678
        set BOOTED=1
        goto :REPAIR_CHECK_DONE
    )
    timeout /t 1 /nobreak >nul
)

:REPAIR_CHECK_DONE
if exist "logs\active_port.txt" (
    for /f "usebackq tokens=*" %%p in ("logs\active_port.txt") do set TARGET_PORT=%%p
)
set TARGET_URL=http://localhost:%TARGET_PORT%/setup_wizard.html

echo.
echo [Step 4] 자가치유 복구 결과 검증...
if "%BOOTED%"=="1" (
    echo ==============================================================================
    echo   [성공] AutoFlow 자동화 엔진 자가치유 복구가 완료되었습니다!
    echo   * 복구 대시보드 URL: %TARGET_URL%
    echo   * 활성 포트: %TARGET_PORT%
    echo ==============================================================================
    echo.
    start "" "%TARGET_URL%"
) else (
    echo ==============================================================================
    echo   [복구 실패] 엔진 기동에 실패했습니다.
    echo   * logs\autoflow_engine.log 파일을 확인해 주세요.
    echo ==============================================================================
    echo.
)

pause
