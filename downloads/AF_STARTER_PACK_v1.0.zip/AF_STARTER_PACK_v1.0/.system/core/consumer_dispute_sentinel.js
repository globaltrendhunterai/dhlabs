/**
 * AutoFlow Enterprise Consumer Dispute & Depreciation Sentinel (GATE_CS_20)
 * ------------------------------------------------------------------------------------------------------
 * 공정거래위원회 고시 「소비자분쟁해결기준」(별표 1 품목별 내용연수표, 별표 2 품목별 보상기준) 및
 * 「전자상거래 등에서의 소비자보호에 관한 법률」 제17조, 제18조를 완벽 준수하여
 * 장기 사용 후 전액 환불을 요구하는 악성 체리피커 및 부당 환불 독박을 1초 만에 원천 방어하는 감가상각 분쟁 센티널.
 *
 * [주요 기능]
 * 1. 공정위 고시 주요 33개 표준 품목군 내용연수(Useful Life) 및 품질보증기간 데이터베이스
 * 2. 공정위 법정 정액감가상각 연산 엔진 (calculateDepreciation)
 *    - 사용일수 = Math.max(0, Math.floor((disputeDate - purchaseDate) / (1000 * 60 * 60 * 24)))
 *    - 총 내용연수 일수 = usefulLifeYears * 365
 *    - 감가상각율 = Math.min(1.0, 사용일수 / 총 내용연수 일수)
 *    - 감가상각비 = Math.round(purchaseAmount * 감가상각율)
 *    - 법정 환급액 = Math.max(0, purchaseAmount - 감가상각비)
 * 3. 4대 판정 엔진 (evaluateConsumerDispute):
 *    - DISPUTE_INITIAL_RETURN_PERIOD (100점, 구입 10일 이내 전액 환급/교환, 감가상각 0원)
 *    - DISPUTE_WARRANTY_REPAIR (85점, 품질보증기간 내 무상수리/부품교체 원칙)
 *    - DISPUTE_DEPRECIATED_REFUND (50점, 보증기간 경과 정액감가상각 차감 환급 안내, 감가상각비 사전 방어)
 *    - DISPUTE_CONSUMER_FAULT_REJECTED (10점, 외력·소비자과실 전액 환불 거절 & 유상수리, 100% 방어)
 * 4. Pure White Clean Enterprise 라이트 모드 공식 공정위 감가상각 계산서 및 분쟁 소명 공문서 발급
 *    - (인쇄 시 직인 생략) 공문서 표준 준수, 붉은 직인 0건, 다크모드 영구 금지
 * 5. 영속 원장 관리 (logs/consumer_dispute_audits.json) 및 종결 처리 지원
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

/**
 * 공정거래위원회 고시 「소비자분쟁해결기준」 품목별 내용연수표 및 품질보증기간 표준 데이터베이스 (33종)
 */
const CONSUMER_USEFUL_LIFE_DATABASE = [
  // --- [가전 / IT 기기] ---
  {
    id: "SMARTPHONE",
    nameKo: "스마트폰/휴대전화",
    category: "가전/IT",
    usefulLifeYears: 2,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["스마트폰", "smartphone", "핸드폰", "휴대폰", "아이폰", "갤럭시"],
    legalBasis: "소비자분쟁해결기준 별표 1 및 별표 2 (통신기기 부문)",
    description: "스마트폰 품목 표준 내용연수 2년, 품질보증기간 1년 (메인보드/핵심부품 별도 규정 적용 가능)"
  },
  {
    id: "NOTEBOOK_PC",
    nameKo: "노트북/태블릿/데스크탑PC",
    category: "가전/IT",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["노트북", "notebook", "laptop", "태블릿", "tablet", "pc", "컴퓨터", "맥북", "아이패드"],
    legalBasis: "소비자분쟁해결기준 별표 1 사무·사무용기기 (컴퓨터 부문)",
    description: "퍼스널 컴퓨터 및 노트북·태블릿 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "TV_LARGE",
    nameKo: "TV/대형 디스플레이",
    category: "가전/IT",
    usefulLifeYears: 5,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["tv", "텔레비전", "스마트tv", "oled", "qled", "대형스크린"],
    legalBasis: "소비자분쟁해결기준 별표 1 영상가전 부문",
    description: "텔레비전 품목 표준 내용연수 5년, 품질보증기간 1년 (패널 별도 2년)"
  },
  {
    id: "REFRIGERATOR",
    nameKo: "냉장고/김치냉장고",
    category: "가전/IT",
    usefulLifeYears: 5,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["냉장고", "refrigerator", "김치냉장고", "냉동고"],
    legalBasis: "소비자분쟁해결기준 별표 1 주방·음향가전 부문",
    description: "냉장고 품목 표준 내용연수 5년, 품질보증기간 1년"
  },
  {
    id: "WASHING_MACHINE",
    nameKo: "세탁기/건조기/의류관리기",
    category: "가전/IT",
    usefulLifeYears: 5,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["세탁기", "washing machine", "건조기", "스타일러", "에어드레서"],
    legalBasis: "소비자분쟁해결기준 별표 1 가전제품 부문",
    description: "세탁기 및 건조기 표준 내용연수 5년, 품질보증기간 1년"
  },
  {
    id: "AIR_CONDITIONER",
    nameKo: "에어컨/시스템냉난방기",
    category: "가전/IT",
    usefulLifeYears: 5,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["에어컨", "air conditioner", "냉난방기", "시스템에어컨", "제습기"],
    legalBasis: "소비자분쟁해결기준 별표 1 계절가전 부문",
    description: "에어컨 품목 표준 내용연수 5년, 품질보증기간 1년"
  },
  {
    id: "MONITOR_PRINTER",
    nameKo: "모니터/프린터/복합기",
    category: "가전/IT",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["모니터", "monitor", "프린터", "printer", "복합기", "스캐너"],
    legalBasis: "소비자분쟁해결기준 별표 1 컴퓨터주변기기 부문",
    description: "컴퓨터 주변기기 및 사무용기기 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "VACUUM_CLEANER",
    nameKo: "청소기/로봇청소기",
    category: "가전/IT",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["청소기", "vacuum", "로봇청소기", "무선청소기"],
    legalBasis: "소비자분쟁해결기준 별표 1 소형가전 부문",
    description: "전기청소기 및 로봇청소기 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "MICROWAVE_OVEN",
    nameKo: "전자레인지/전기오븐/에어프라이어",
    category: "가전/IT",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["전자레인지", "microwave", "오븐", "oven", "에어프라이어", "인덕션", "전기밥솥"],
    legalBasis: "소비자분쟁해결기준 별표 1 소형주방가전 부문",
    description: "주방 전열기기 및 조리기구 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "HAIR_DRYER",
    nameKo: "헤어드라이어/고데기/이미용기기",
    category: "가전/IT",
    usefulLifeYears: 2,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["헤어드라이어", "드라이기", "hair dryer", "고데기", "면도기", "미용기기"],
    legalBasis: "소비자분쟁해결기준 별표 1 신변소형가전 부문",
    description: "헤어드라이어 및 소형 이미용기기 내용연수 2년, 품질보증기간 1년"
  },
  {
    id: "AUDIO_EARPHONE",
    nameKo: "블루투스이어폰/헤드폰/음향기기",
    category: "가전/IT",
    usefulLifeYears: 2,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["이어폰", "earphone", "헤드폰", "headphone", "블루투스스피커", "에어팟", "버즈"],
    legalBasis: "소비자분쟁해결기준 별표 1 음향기기 부문",
    description: "휴대용 음향 및 블루투스 무선기기 내용연수 2년, 품질보증기간 1년"
  },
  {
    id: "SMALL_KITCHEN_APP",
    nameKo: "소형주방가전(믹서기/포트/토스터)",
    category: "가전/IT",
    usefulLifeYears: 2,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["믹서기", "블렌더", "전기포트", "토스터기", "커피머신"],
    legalBasis: "소비자분쟁해결기준 별표 1 소형가전 부문",
    description: "소형 전열·모터 주방기기 내용연수 2년, 품질보증기간 1년"
  },

  // --- [패션 / 잡화] ---
  {
    id: "CLOTHING_GENERAL",
    nameKo: "일반의류/티셔츠/셔츠/바지",
    category: "패션/잡화",
    usefulLifeYears: 1,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["의류", "옷", "티셔츠", "셔츠", "바지", "청바지", "슬랙스", "원피스"],
    legalBasis: "소비자분쟁해결기준 별표 1 섬유제품·의복 부문",
    description: "일반 섬유의복 품목 내용연수 1년, 품질보증기간 1년"
  },
  {
    id: "CLOTHING_KNIT_JACKET",
    nameKo: "니트/자켓/정장/외투",
    category: "패션/잡화",
    usefulLifeYears: 1,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["니트", "자켓", "정장", "블레이저", "패딩", "다운점퍼"],
    legalBasis: "소비자분쟁해결기준 별표 1 섬유제품 부문",
    description: "모직·편물 의류 및 아우터 내용연수 1년, 품질보증기간 1년"
  },
  {
    id: "SHOES_SNEAKERS",
    nameKo: "신발/운동화/구두",
    category: "패션/잡화",
    usefulLifeYears: 1,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["신발", "운동화", "구두", "스니커즈", "부츠", "샌들"],
    legalBasis: "소비자분쟁해결기준 별표 1 신발 부문",
    description: "가죽구두 및 일반 운동화 내용연수 1년, 품질보증기간 1년"
  },
  {
    id: "LEATHER_BAG",
    nameKo: "가죽제품/핸드백/서류가방",
    category: "패션/잡화",
    usefulLifeYears: 2,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["가방", "bag", "핸드백", "백팩", "서류가방", "가죽가방"],
    legalBasis: "소비자분쟁해결기준 별표 1 가죽제품 부문",
    description: "가죽제 가방 및 핸드백 내용연수 2년, 품질보증기간 1년"
  },
  {
    id: "LUXURY_BAG",
    nameKo: "명품가방/고가가죽잡화",
    category: "패션/잡화",
    usefulLifeYears: 2,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["명품가방", "명품백", "럭셔리가방", "고가핸드백"],
    legalBasis: "소비자분쟁해결기준 별표 1 피혁잡화 부문",
    description: "고가 피혁 및 가죽 명품 잡화 내용연수 2년, 품질보증기간 1년"
  },
  {
    id: "FUR_COAT",
    nameKo: "모피/고가외투/천연가죽의류",
    category: "패션/잡화",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["모피", "무스탕", "가죽자켓", "가죽코트", "모피코트"],
    legalBasis: "소비자분쟁해결기준 별표 1 모피·가죽의류 부문",
    description: "천연 모피 및 가죽 외투 표준 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "JEWELRY_WATCH",
    nameKo: "귀금속/손목시계/주얼리",
    category: "패션/잡화",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["시계", "watch", "손목시계", "귀금속", "반지", "목걸이", "주얼리"],
    legalBasis: "소비자분쟁해결기준 별표 1 귀금속·시계 부문",
    description: "손목시계 및 보석 장신구 표준 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "ACCESSORIES_GENERAL",
    nameKo: "패션소품(모자/벨트/지갑/머플러)",
    category: "패션/잡화",
    usefulLifeYears: 1,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["지갑", "wallet", "벨트", "모자", "스카프", "머플러", "장갑"],
    legalBasis: "소비자분쟁해결기준 별표 1 신변잡화 부문",
    description: "신변 잡화류 표준 내용연수 1년, 품질보증기간 1년"
  },

  // --- [생활 / 가구] ---
  {
    id: "BED_MATTRESS",
    nameKo: "침대/매트리스",
    category: "생활/가구",
    usefulLifeYears: 5,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["침대", "bed", "매트리스", "mattress", "토퍼"],
    legalBasis: "소비자분쟁해결기준 별표 1 가구 부문",
    description: "침대 및 매트리스 품목 표준 내용연수 5년, 품질보증기간 1년"
  },
  {
    id: "SOFA_COUCH",
    nameKo: "소파/식탁/거실가구",
    category: "생활/가구",
    usefulLifeYears: 5,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["소파", "sofa", "식탁", "거실장", "리클라이너"],
    legalBasis: "소비자분쟁해결기준 별표 1 가구 부문",
    description: "소파 및 대형 목재 가구 표준 내용연수 5년, 품질보증기간 1년"
  },
  {
    id: "OFFICE_FURNITURE",
    nameKo: "사무용가구/책상/오피스체어",
    category: "생활/가구",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["책상", "desk", "의자", "chair", "사무용의자", "서랍장", "책장"],
    legalBasis: "소비자분쟁해결기준 별표 1 사무용가구 부문",
    description: "사무용 책상 및 기능성 의자 표준 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "BEDDING_QUILT",
    nameKo: "침구/이불/베개/패브릭",
    category: "생활/가구",
    usefulLifeYears: 2,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["이불", "침구", "베개", "차렵이불", "구스이불", "커튼", "러그"],
    legalBasis: "소비자분쟁해결기준 별표 1 침구류 부문",
    description: "침구 세트 및 가정용 패브릭 제품 표준 내용연수 2년, 품질보증기간 1년"
  },
  {
    id: "COOKWARE_POT",
    nameKo: "주방용품/프라이팬/냄비세트",
    category: "생활/가구",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["냄비", "후라이팬", "프라이팬", "식기", "칼세트", "밀폐용기"],
    legalBasis: "소비자분쟁해결기준 별표 1 주방용품 부문",
    description: "조리용 냄비 및 프라이팬 표준 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "STORAGE_ORGANIZER",
    nameKo: "수납장/선반/행거/정리함",
    category: "생활/가구",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["선반", "행거", "수납장", "플라스틱서랍", "정리함"],
    legalBasis: "소비자분쟁해결기준 별표 1 생활용품 부문",
    description: "조립식 선반 및 수납용품 표준 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "LIGHTING_FIXTURE",
    nameKo: "조명기구/스탠드/LED등기구",
    category: "생활/가구",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["조명", "스탠드", "led조명", "전등", "무드등"],
    legalBasis: "소비자분쟁해결기준 별표 1 조명기구 부문",
    description: "실내 조명기구 및 데스크 스탠드 내용연수 3년, 품질보증기간 1년"
  },

  // --- [레저 / 취미 / 스포츠] ---
  {
    id: "BICYCLE",
    nameKo: "자전거/전기자전거/전동킥보드",
    category: "레저/취미",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["자전거", "bicycle", "전기자전거", "킥보드", "전동킥보드"],
    legalBasis: "소비자분쟁해결기준 별표 1 자전거 부문",
    description: "일반 자전거 및 개인형 이동장치 표준 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "TREADMILL_FITNESS",
    nameKo: "헬스기구/러닝머신/실내사이클",
    category: "레저/취미",
    usefulLifeYears: 5,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["러닝머신", "트레드밀", "treadmill", "실내자전거", "헬스기구", "웨이트기구"],
    legalBasis: "소비자분쟁해결기준 별표 1 운동기구 부문",
    description: "대형 전동 운동기구 및 실내 체육설비 표준 내용연수 5년, 품질보증기간 1년"
  },
  {
    id: "GOLF_CLUB_RACKET",
    nameKo: "골프채/라켓/스포츠용품",
    category: "레저/취미",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["골프채", "golf", "드라이버", "아이언", "테니스라켓", "배드민턴라켓"],
    legalBasis: "소비자분쟁해결기준 별표 1 레저용품 부문",
    description: "골프 클럽 및 구기용 스포츠 라켓 표준 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "CAMPING_GEAR",
    nameKo: "텐트/타프/캠핑용품",
    category: "레저/취미",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["텐트", "tent", "타프", "캠핑체어", "캠핑테이블", "침낭", "버너"],
    legalBasis: "소비자분쟁해결기준 별표 1 야외레저용품 부문",
    description: "캠핑용 텐트 및 야외 레저 설비 표준 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "MUSICAL_INSTRUMENT",
    nameKo: "악기/디지털피아노/기타",
    category: "레저/취미",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["피아노", "디지털피아노", "기타", "guitar", "신디사이저", "바이올린"],
    legalBasis: "소비자분쟁해결기준 별표 1 악기류 부문",
    description: "일반 악기 및 전자 건반악기 표준 내용연수 3년, 품질보증기간 1년"
  },
  {
    id: "GENERAL_GOODS",
    nameKo: "기타 일반공산품/잡화",
    category: "기타공산품",
    usefulLifeYears: 3,
    warrantyYears: 1,
    warrantyMonths: 12,
    aliases: ["기타", "공산품", "잡화", "general"],
    legalBasis: "소비자분쟁해결기준 별표 1 일반공산품 부문",
    description: "별도 규정이 없는 일반 공산품 표준 내용연수 3년, 품질보증기간 1년"
  }
];

/**
 * 정액감가상각 연산 엔진 (공정위 고시 산식 준수)
 *
 * @param {number} purchaseAmount 구입금액 (원)
 * @param {string|Date} purchaseDate 구입일자
 * @param {string|Date} disputeDate 분쟁접수일자 (기본값: 오늘)
 * @param {string|object} category 품목 카테고리 ID 또는 객체
 * @returns {object} 감가상각 연산 결과
 */
function calculateDepreciation(purchaseAmount, purchaseDate, disputeDate, category) {
  if (purchaseAmount && typeof purchaseAmount === "object" && !(purchaseAmount instanceof Date)) {
    const params = purchaseAmount;
    purchaseDate = params.purchaseDate;
    disputeDate = params.disputeDate;
    category = params.category;
    purchaseAmount = params.purchaseAmount;
  }
  const pAmount = Math.max(0, Math.floor(Number(purchaseAmount) || 0));
  let pDate = purchaseDate instanceof Date ? purchaseDate : (purchaseDate ? new Date(purchaseDate) : new Date());
  if (isNaN(pDate.getTime())) pDate = new Date();
  let dDate = disputeDate instanceof Date ? disputeDate : (disputeDate ? new Date(disputeDate) : new Date());
  if (isNaN(dDate.getTime())) dDate = new Date();

  // 날짜 차이 계산 (일 단위)
  const diffMs = Math.max(0, dDate.getTime() - pDate.getTime());
  const daysUsed = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));

  let categoryInfo = null;
  if (typeof category === "object" && category !== null && category.usefulLifeYears) {
    categoryInfo = category;
  } else if (typeof category === "string") {
    categoryInfo = CONSUMER_USEFUL_LIFE_DATABASE.find(c => c.id === category || c.nameKo === category);
    if (!categoryInfo) {
      const lower = category.toLowerCase();
      categoryInfo = CONSUMER_USEFUL_LIFE_DATABASE.find(c => c.aliases && c.aliases.some(a => lower.includes(a.toLowerCase())));
    }
  }

  if (!categoryInfo) {
    categoryInfo = CONSUMER_USEFUL_LIFE_DATABASE.find(c => c.id === "GENERAL_GOODS") || {
      id: "GENERAL_GOODS",
      nameKo: "기타 일반공산품/잡화",
      category: "기타공산품",
      usefulLifeYears: 3,
      warrantyYears: 1,
      warrantyMonths: 12,
      legalBasis: "소비자분쟁해결기준 별표 1 일반공산품 부문"
    };
  }

  const usefulLifeYears = categoryInfo.usefulLifeYears || 3;
  const totalUsefulDays = usefulLifeYears * 365;

  // 공정위 정액감가상각 산식: 감가상각율 = 사용일수 / 총 내용연수 일수 (최대 1.0)
  const depreciationRate = Math.min(1.0, daysUsed / totalUsefulDays);
  const depreciationAmount = Math.round(pAmount * depreciationRate);
  const legalRefundAmount = Math.max(0, pAmount - depreciationAmount);

  return {
    purchaseAmount: pAmount,
    purchaseDate: pDate.toISOString().slice(0, 10),
    disputeDate: dDate.toISOString().slice(0, 10),
    daysUsed,
    usefulLifeYears,
    warrantyYears: categoryInfo.warrantyYears || 1,
    totalUsefulDays,
    depreciationRate: Number(depreciationRate.toFixed(4)),
    depreciationRatePercent: (depreciationRate * 100).toFixed(1) + "%",
    depreciationAmount,
    legalRefundAmount,
    categoryInfo
  };
}

/**
 * 4대 판정 엔진 (evaluateConsumerDispute)
 *
 * @param {object} disputeData 분쟁 데이터
 * @returns {object} 감사 및 판정 결과 객체
 */
function evaluateConsumerDispute(disputeData = {}) {
  disputeData = (disputeData && typeof disputeData === "object") ? disputeData : {};
  const pAmount = Math.max(0, Math.floor(Number(disputeData.purchaseAmount) || 0));
  const pDateStr = disputeData.purchaseDate || new Date().toISOString().slice(0, 10);
  const dDateStr = disputeData.disputeDate || new Date().toISOString().slice(0, 10);
  const category = disputeData.category || "GENERAL_GOODS";
  const productName = disputeData.productName || "테스트 품목";
  const disputeReason = String(disputeData.disputeReason || "단순불만");
  const buyerName = disputeData.buyerName || "소비자(구매자)";
  const orderId = disputeData.orderId || ("ORD-" + Date.now());

  // 외력 / 소비자 고의·과실 감별
  const isConsumerFault = Boolean(disputeData.isConsumerFault || disputeData.hasExternalDamage);
  const faultKeywordsRegex = /외력|낙하|침수|임의분해|소비자과실|사용자과실|부주의|충격파손|임의개조|파손|깨짐|침수라벨/i;
  const hasFaultKeywords = faultKeywordsRegex.test(disputeReason);
  const finalConsumerFault = isConsumerFault || hasFaultKeywords;

  const dep = calculateDepreciation(pAmount, pDateStr, dDateStr, category);
  const { daysUsed, categoryInfo, depreciationAmount, legalRefundAmount } = dep;
  const warrantyDays = (categoryInfo.warrantyYears || 1) * 365;

  let verdict = "";
  let verdictLabel = "";
  let complianceScore = 100;
  let lossDefendedWon = 0;
  let finalRefundAmount = 0;
  let finalDepreciationAmount = 0;
  let actionRecommendation = "";
  let legalBasis = "";

  if (finalConsumerFault) {
    // 1. 소비자 고의·과실·외력 파손 감별 (10점, 전액 환불 거절 & 100% 방어)
    verdict = "DISPUTE_CONSUMER_FAULT_REJECTED";
    verdictLabel = "소비자 고의·과실·외력 파손 (전액 환불 거절 & 유상 수리)";
    complianceScore = 10;
    lossDefendedWon = pAmount; // 구입금액 100% 전액 방어
    finalRefundAmount = 0;
    finalDepreciationAmount = 0;
    legalBasis = "전자상거래법 제17조 제2항 제1호 및 소비자분쟁해결기준 제4조(소비자 귀책사유)";
    actionRecommendation = "전자상거래법 제17조 제2항 제1호에 따라 소비자의 귀책사유로 상품이 멸실·훼손되거나 외력이 가해진 경우 청약철회 및 전액 환급 대상에서 완전히 제외됩니다. 부당한 전액 환불 요구를 단호히 거절하고 공식 서비스센터를 통한 유상 수리를 안내하십시오.";
  } else if (daysUsed <= 10) {
    // 2. 구입 후 10일 이내 초기 접수 (100점, 전액 환급/교환, 감가상각 0원)
    verdict = "DISPUTE_INITIAL_RETURN_PERIOD";
    verdictLabel = "구입 10일 이내 초기 접수 (전액 환급 또는 무상 교환)";
    complianceScore = 100;
    lossDefendedWon = 0;
    finalRefundAmount = pAmount;
    finalDepreciationAmount = 0;
    legalBasis = "소비자분쟁해결기준 별표 2 품목별 보상기준 (구입 후 10일 이내 중대 하자 발생 시)";
    actionRecommendation = "공정거래위원회 소비자분쟁해결기준에 의거, 구입 후 10일 이내 정상적인 사용 상태에서 기능적 하자가 발생한 경우 제품 교환 또는 구입가 전액 환급이 법적 권고 대상입니다. 신속한 교환 또는 전액 환급을 진행하십시오.";
  } else if (daysUsed <= warrantyDays) {
    // 3. 품질보증기간 내 (85점, 무상수리 또는 부품교체 우선 권고)
    verdict = "DISPUTE_WARRANTY_REPAIR";
    verdictLabel = "품질보증기간 내 접수 (무상 수리 또는 부품 교체 우선)";
    complianceScore = 85;
    lossDefendedWon = 0;
    finalRefundAmount = 0;
    finalDepreciationAmount = 0;
    legalBasis = `소비자분쟁해결기준 별표 2 (품질보증기간 ${categoryInfo.warrantyYears}년 내 무상수리 원칙)`;
    actionRecommendation = `공정위 소비자분쟁해결기준에 의거, 품질보증기간(${categoryInfo.warrantyYears}년, ${warrantyDays}일) 내 발생한 기능 하자는 '무상 수리 또는 부품 교체'가 법적 최우선 원칙입니다. 고객에게 제조사 공식 서비스센터 1차 무상 수리를 안내하십시오. (수리 불능 시에만 교환/환급 검토)`;
  } else {
    // 4. 품질보증기간 경과 장기사용 환불 요구 (50점, 공정위 정액감가상각 차감 환급 안내, 감가상각비 사전 방어)
    verdict = "DISPUTE_DEPRECIATED_REFUND";
    verdictLabel = "품질보증기간 경과 장기사용 분쟁 (공정위 정액감가상각 차감 환급)";
    complianceScore = 50;
    lossDefendedWon = depreciationAmount; // 차감된 감가상각비만큼 판매자 손실 사전 방어
    finalRefundAmount = legalRefundAmount;
    finalDepreciationAmount = depreciationAmount;
    legalBasis = `소비자분쟁해결기준 별표 1(내용연수 ${categoryInfo.usefulLifeYears}년) 및 별표 2(정액감가상각 산식)`;
    actionRecommendation = `공정위 소비자분쟁해결기준 제3조 및 별표 2에 의거, 품질보증기간 경과 후 환급 시에는 실사용일수(${daysUsed}일)에 대한 법정 정액감가상각비 ₩${depreciationAmount.toLocaleString()}원을 공제한 잔여가치 ₩${legalRefundAmount.toLocaleString()}원만 환급하는 것이 정당합니다. 장기 사용 후 전액 환불 요구는 악성 체리피킹으로 간주되며 본 공문서 증적을 제시하십시오.`;
  }

  const auditId = "CDA-" + Date.now() + "-" + crypto.randomBytes(3).toString("hex").toUpperCase();
  const auditTime = new Date().toISOString();

  return {
    auditId,
    auditTime,
    productName,
    category: categoryInfo.nameKo,
    categoryId: categoryInfo.id,
    usefulLifeYears: categoryInfo.usefulLifeYears,
    warrantyYears: categoryInfo.warrantyYears,
    purchaseDate: dep.purchaseDate,
    disputeDate: dep.disputeDate,
    purchaseAmount: pAmount,
    daysUsed,
    totalUsefulDays: dep.totalUsefulDays,
    depreciationRate: dep.depreciationRate,
    depreciationRatePercent: dep.depreciationRatePercent,
    depreciationAmount: finalDepreciationAmount,
    legalRefundAmount: finalRefundAmount,
    lossDefendedWon,
    verdict,
    verdictLabel,
    complianceScore,
    disputeReason,
    isConsumerFault: finalConsumerFault,
    buyerName,
    orderId,
    actionRecommendation,
    legalBasis,
    status: (verdict === "DISPUTE_DEPRECIATED_REFUND" || verdict === "DISPUTE_CONSUMER_FAULT_REJECTED") ? "DEFENDED" : "NORMAL",
    resolution: null,
    resolvedAt: null,
    notes: ""
  };
}

/**
 * Pure White Clean Enterprise 라이트 모드 공식 공정위 감가상각 계산서 및 분쟁 소명 공문서 HTML 생성기
 * - (인쇄 시 직인 생략) 공문서 표준 준수
 * - 붉은 직인 이미지 0건, 다크모드 영구 금지
 */
function generateDisputeDisputeEvidenceHtml(auditRecord, customConfig = {}) {
  customConfig = (customConfig && typeof customConfig === "object") ? customConfig : {};
  const config = {
    companyName: customConfig.companyName || "오토플로우 엔터프라이즈",
    sellerName: customConfig.sellerName || "대표자 홍길동",
    businessNumber: customConfig.businessNumber || "123-45-67890",
    ecommerceNumber: customConfig.ecommerceNumber || "제2026-서울강남-01234호",
    customerCenterPhone: customConfig.customerCenterPhone || "1588-0000",
    customerCenterEmail: customConfig.customerCenterEmail || "legal@autoflow.enterprise",
    ...customConfig
  };

  const record = (auditRecord && typeof auditRecord === "object") ? auditRecord : {};
  const isLossDefended = Number(record.lossDefendedWon || 0) > 0;
  const issueDate = record.auditTime ? String(record.auditTime).slice(0, 10) : new Date().toISOString().slice(0, 10);

  let statusBadgeColor = "#059669";
  let statusBadgeBg = "#ecfdf5";
  let statusBadgeBorder = "#a7f3d0";

  if (record.verdict === "DISPUTE_CONSUMER_FAULT_REJECTED") {
    statusBadgeColor = "#dc2626";
    statusBadgeBg = "#fef2f2";
    statusBadgeBorder = "#fecaca";
  } else if (record.verdict === "DISPUTE_DEPRECIATED_REFUND") {
    statusBadgeColor = "#d97706";
    statusBadgeBg = "#fffbeb";
    statusBadgeBorder = "#fde68a";
  } else if (record.verdict === "DISPUTE_WARRANTY_REPAIR") {
    statusBadgeColor = "#2563eb";
    statusBadgeBg = "#eff6ff";
    statusBadgeBorder = "#bfdbfe";
  }

  return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>공정거래위원회 소비자분쟁해결기준 법정 감가상각 산출서 및 분쟁 답변 소명서</title>
  <style>
    @page { size: A4 portrait; margin: 18mm 15mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo", "Malgun Gothic", "Noto Sans KR", sans-serif;
      color: #0f172a;
      background: #ffffff;
      margin: 0;
      padding: 24px;
      line-height: 1.6;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .doc-container {
      max-width: 800px;
      margin: 0 auto;
      border: 1px solid #cbd5e1;
      padding: 36px 32px;
      background: #ffffff;
    }
    .doc-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 2px solid #0f172a;
      padding-bottom: 16px;
      margin-bottom: 24px;
    }
    .doc-title {
      font-size: 20px;
      font-weight: 800;
      color: #0f172a;
      letter-spacing: -0.5px;
      margin: 0 0 6px 0;
    }
    .doc-subtitle {
      font-size: 11px;
      color: #64748b;
      margin: 0;
    }
    .meta-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 12px;
    }
    .meta-table th {
      background: #f8fafc;
      color: #475569;
      font-weight: 700;
      padding: 8px 12px;
      border: 1px solid #e2e8f0;
      width: 22%;
      text-align: left;
    }
    .meta-table td {
      padding: 8px 12px;
      border: 1px solid #e2e8f0;
      color: #0f172a;
      width: 28%;
    }
    .verdict-box {
      background: ${statusBadgeBg};
      border: 1px solid ${statusBadgeBorder};
      border-radius: 6px;
      padding: 16px 20px;
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .verdict-title {
      font-size: 14px;
      font-weight: 800;
      color: ${statusBadgeColor};
      margin: 0 0 4px 0;
    }
    .verdict-desc {
      font-size: 11px;
      color: #475569;
      margin: 0;
    }
    .stat-badge {
      display: inline-block;
      padding: 6px 14px;
      background: ${statusBadgeColor};
      color: #ffffff;
      font-size: 12px;
      font-weight: 800;
      border-radius: 4px;
    }
    .calc-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 12px;
    }
    .calc-table th {
      background: #f1f5f9;
      color: #334155;
      font-weight: 700;
      padding: 9px 12px;
      border: 1px solid #cbd5e1;
      text-align: left;
    }
    .calc-table td {
      padding: 9px 12px;
      border: 1px solid #cbd5e1;
      color: #0f172a;
    }
    .highlight-row {
      background: #f8fafc;
      font-weight: 700;
    }
    .highlight-red {
      color: #dc2626;
      font-weight: 800;
    }
    .highlight-blue {
      color: #2563eb;
      font-weight: 800;
    }
    .guidance-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-left: 4px solid #0f172a;
      padding: 14px 18px;
      margin-bottom: 20px;
      font-size: 12px;
      line-height: 1.7;
    }
    .guidance-box strong {
      color: #0f172a;
    }
    .doc-footer {
      margin-top: 32px;
      border-top: 1px solid #cbd5e1;
      padding-top: 20px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      font-size: 11px;
      color: #64748b;
    }
    .signature-area {
      font-weight: 700;
      color: #0f172a;
      font-size: 12px;
      text-align: right;
    }
  </style>
</head>
<body>
  <div class="doc-container">
    <div class="doc-header">
      <div>
        <h1 class="doc-title">⚖️ 소비자분쟁해결기준 법정 감가상각 산출서 및 공식 답변 소명서</h1>
        <p class="doc-subtitle">공정거래위원회 고시 제2024-XX호 「소비자분쟁해결기준」 및 「전자상거래법」 제17조·제18조 준용</p>
      </div>
      <div style="text-align: right; font-size: 11px; color: #64748b;">
        <div><strong>관리번호:</strong> ${record.auditId || "-"}</div>
        <div><strong>발급일자:</strong> ${issueDate}</div>
      </div>
    </div>

    <!-- 분쟁 접수 기본 정보 -->
    <table class="meta-table">
      <tr>
        <th>접수 주문번호</th>
        <td>${record.orderId || "-"}</td>
        <th>고객(구매자)명</th>
        <td>${record.buyerName || "고객"}</td>
      </tr>
      <tr>
        <th>대상 상품명</th>
        <td colspan="3"><strong>${record.productName || "-"}</strong></td>
      </tr>
      <tr>
        <th>공정위 품목 분류</th>
        <td>${record.category || "-"}</td>
        <th>법정 내용연수 / 보증</th>
        <td>${record.usefulLifeYears || 0}년 / ${record.warrantyYears || 1}년</td>
      </tr>
      <tr>
        <th>최초 구입일자</th>
        <td>${record.purchaseDate || "-"}</td>
        <th>분쟁 접수일자</th>
        <td>${record.disputeDate || "-"}</td>
      </tr>
      <tr>
        <th>실제 사용일수</th>
        <td><strong>${record.daysUsed || 0}일</strong></td>
        <th>소비자 과실 여부</th>
        <td>${record.isConsumerFault ? "<strong style='color:#dc2626;'>유 (외력/과실 확인)</strong>" : "무 (정상 사용)"}</td>
      </tr>
    </table>

    <!-- 종합 판정 배너 -->
    <div class="verdict-box">
      <div>
        <div class="verdict-title">${record.verdictLabel || "-"}</div>
        <div class="verdict-desc"><strong>적용 법령:</strong> ${record.legalBasis || "-"}</div>
      </div>
      <div style="text-align: right;">
        <span class="stat-badge">${record.verdict || "VERDICT"}</span>
        <div style="margin-top: 6px; font-size: 11px; font-weight: 700; color: ${isLossDefended ? '#dc2626' : '#059669'};">
          ${isLossDefended ? `🛡️ 판매자 부당손실 방어 성공: ₩${Number(record.lossDefendedWon).toLocaleString()}원` : '✅ 법정 절차 준수 정상 안내'}
        </div>
      </div>
    </div>

    <!-- 정액감가상각 산출 내역표 -->
    <h3 style="font-size: 13px; font-weight: 800; color: #0f172a; margin: 16px 0 8px 0;">📊 공정거래위원회 정액감가상각 법정 산출 내역</h3>
    <table class="calc-table">
      <thead>
        <tr>
          <th>구분 항목</th>
          <th>산출 기준 및 계산식</th>
          <th>금액 / 비율</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>① 최초 구입금액 (A)</td>
          <td>고객 실결제 금액 (주문 원장 기준)</td>
          <td style="font-family: monospace; font-size: 13px;">₩${Number(record.purchaseAmount || 0).toLocaleString()}원</td>
        </tr>
        <tr>
          <td>② 실사용 일수 (B)</td>
          <td>구입일로부터 분쟁 접수일까지의 경과 일수</td>
          <td>${record.daysUsed || 0}일</td>
        </tr>
        <tr>
          <td>③ 법정 총 내용연수 일수 (C)</td>
          <td>공정위 고시 내용연수(${record.usefulLifeYears || 0}년) × 365일</td>
          <td>${record.totalUsefulDays || 0}일</td>
        </tr>
        <tr>
          <td>④ 법정 정액감가상각율 (B / C)</td>
          <td>Math.min(1.0, 사용일수 / 총내용연수일수)</td>
          <td style="font-weight: 700; color: #d97706;">${record.depreciationRatePercent || "0.0%"}</td>
        </tr>
        <tr class="highlight-row">
          <td>⑤ 법정 감가상각 차감비 (D)</td>
          <td>구입금액(A) × 감가상각율(④)</td>
          <td class="highlight-red" style="font-family: monospace; font-size: 13px;">- ₩${Number(record.depreciationAmount || 0).toLocaleString()}원</td>
        </tr>
        <tr class="highlight-row">
          <td>⑥ 법정 정당 환급 가능액 (A - D)</td>
          <td>공정위 기준 환급 시 잔여가치 인정액</td>
          <td class="highlight-blue" style="font-family: monospace; font-size: 14px;">₩${Number(record.legalRefundAmount || 0).toLocaleString()}원</td>
        </tr>
      </tbody>
    </table>

    <!-- 법률 소명 및 권고 조치 가이드 -->
    <div class="guidance-box">
      <strong>📜 공식 소명 의견 및 판매자 권고 조치:</strong><br>
      ${record.actionRecommendation || "-"}<br><br>
      <span style="font-size: 11px; color: #64748b;">
        * 본 산출서는 공정거래위원회 고시 「소비자분쟁해결기준」 제3조 및 별표 1, 별표 2, 「전자상거래 등에서의 소비자보호에 관한 법률」 제17조에 근거하여 자동 발급된 공식 증적서입니다. 소비자가 장기 사용 후 전액 환불을 요구하는 경우, 본 산출서를 소비자원 분쟁조정 소명서 또는 오픈마켓 중재 증적으로 제출하십시오.
      </span>
    </div>

    <!-- 푸터 및 직인 생략 공문서 표준 -->
    <div class="doc-footer">
      <div>
        <strong>사업자명:</strong> ${config.companyName} | <strong>대표자:</strong> ${config.sellerName}<br>
        <strong>사업자등록번호:</strong> ${config.businessNumber} | <strong>통신판매업신고:</strong> ${config.ecommerceNumber}<br>
        <strong>고객센터:</strong> ${config.customerCenterPhone} | <strong>문의메일:</strong> ${config.customerCenterEmail}
      </div>
      <div class="signature-area">
        ${issueDate}<br><br>
        ${config.companyName} 대표자 ${config.sellerName} (인쇄 시 직인 생략)
      </div>
    </div>
  </div>
</body>
</html>`;
}

/**
 * alias 지원 (지침 오타 및 표준 함수명 모두 대응)
 */
const generateDisputeEvidenceHtml = generateDisputeDisputeEvidenceHtml;

/**
 * ConsumerDisputeSentinel 클래스
 */
class ConsumerDisputeSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.appRoot = options.appRoot || path.resolve(__dirname, "..");
    this.logsDir = options.logsDir || path.join(this.appRoot, "logs");
    this.ledgerPath = options.ledgerPath || path.join(this.logsDir, "consumer_dispute_audits.json");
    this.categories = CONSUMER_USEFUL_LIFE_DATABASE;
    this.ensureLedgerExists();
  }

  ensureLedgerExists() {
    try {
      if (!fs.existsSync(this.logsDir)) {
        fs.mkdirSync(this.logsDir, { recursive: true });
      }
      if (!fs.existsSync(this.ledgerPath)) {
        fs.writeFileSync(this.ledgerPath, "[]", "utf8");
      }
    } catch (e) {
      // ignore
    }
  }

  _loadAudits() {
    try {
      if (!fs.existsSync(this.ledgerPath)) return [];
      const data = fs.readFileSync(this.ledgerPath, "utf8");
      const parsed = JSON.parse(data || "[]");
      return Array.isArray(parsed)
        ? parsed.filter(x => x && typeof x === "object")
        : (parsed && Array.isArray(parsed.audits) ? parsed.audits.filter(x => x && typeof x === "object") : []);
    } catch (e) {
      return [];
    }
  }

  loadAudits() {
    return this._loadAudits();
  }

  _saveAudits(audits) {
    try {
      if (!Array.isArray(audits)) return false;
      const clean = audits.filter(x => x && typeof x === "object");
      this.ensureLedgerExists();
      fs.writeFileSync(this.ledgerPath, JSON.stringify(clean, null, 2), "utf8");
      return true;
    } catch (e) {
      return false;
    }
  }

  saveAudits(audits) {
    return this._saveAudits(audits);
  }

  recordAudit(auditRecord) {
    if (!auditRecord || typeof auditRecord !== "object" || !auditRecord.auditId) return false;
    const audits = this._loadAudits();
    // 중복 방지
    const idx = audits.findIndex(a => a && a.auditId === auditRecord.auditId);
    if (idx >= 0) {
      audits[idx] = auditRecord;
    } else {
      audits.unshift(auditRecord);
    }
    // 최대 1000건 유지
    if (audits.length > 1000) {
      audits.length = 1000;
    }
    return this._saveAudits(audits);
  }

  calculateDepreciation(purchaseAmount, purchaseDate, disputeDate, category) {
    return calculateDepreciation(purchaseAmount, purchaseDate, disputeDate, category);
  }

  evaluateConsumerDispute(disputeData) {
    return evaluateConsumerDispute(disputeData);
  }

  auditConsumerDispute(disputeData, options = {}) {
    disputeData = (disputeData && typeof disputeData === "object") ? disputeData : {};
    options = (options && typeof options === "object") ? options : {};
    const audit = this.evaluateConsumerDispute(disputeData);
    if (options.record !== false) {
      this.recordAudit(audit);
    }
    return audit;
  }

  generateDisputeDisputeEvidenceHtml(auditRecord, customConfig = {}) {
    return generateDisputeDisputeEvidenceHtml(auditRecord, customConfig);
  }

  generateDisputeEvidenceHtml(auditRecord, customConfig = {}) {
    return generateDisputeDisputeEvidenceHtml(auditRecord, customConfig);
  }

  generateDisputeResponseDoc(auditId, customConfig = {}) {
    customConfig = (customConfig && typeof customConfig === "object") ? customConfig : {};
    const audits = this._loadAudits();
    let target = null;
    if (auditId && typeof auditId === "object") {
      if (auditId.auditId) {
        target = audits.find(a => a && a.auditId === auditId.auditId) || auditId;
      } else {
        target = auditId;
      }
    } else if (typeof auditId === "string" && auditId.trim()) {
      target = audits.find(a => a && a.auditId === auditId.trim());
    }
    if (!target) {
      target = this.evaluateConsumerDispute({});
      if (typeof auditId === "string" && auditId.trim()) {
        target.auditId = auditId.trim();
      }
    }
    return this.generateDisputeDisputeEvidenceHtml(target, customConfig);
  }

  getSummary() {
    const audits = this._loadAudits();
    let totalAudits = audits.length;
    let initialReturnCount = 0;
    let warrantyRepairCount = 0;
    let depreciatedRefundCount = 0;
    let consumerFaultCount = 0;
    let cherryPickerDefendedCount = 0;
    let totalPreventedLossWon = 0;
    let resolvedCount = 0;
    let pendingCount = 0;

    for (const a of audits) {
      if (!a || typeof a !== "object") continue;
      if (a.verdict === "DISPUTE_INITIAL_RETURN_PERIOD") initialReturnCount++;
      else if (a.verdict === "DISPUTE_WARRANTY_REPAIR") warrantyRepairCount++;
      else if (a.verdict === "DISPUTE_DEPRECIATED_REFUND") {
        depreciatedRefundCount++;
        cherryPickerDefendedCount++;
      } else if (a.verdict === "DISPUTE_CONSUMER_FAULT_REJECTED") {
        consumerFaultCount++;
        cherryPickerDefendedCount++;
      }

      totalPreventedLossWon += Number(a.lossDefendedWon || 0);

      if (a.status === "RESOLVED") {
        resolvedCount++;
      } else {
        pendingCount++;
      }
    }

    return {
      totalAudits,
      initialReturnCount,
      warrantyRepairCount,
      depreciatedRefundCount,
      consumerFaultCount,
      cherryPickerDefendedCount,
      defendedCount: cherryPickerDefendedCount,
      totalPreventedLossWon,
      preventedLossWon: totalPreventedLossWon,
      resolvedCount,
      pendingCount,
      categoriesCount: this.categories.length,
      latestAudits: audits.slice(0, 50)
    };
  }

  resolveDisputeIssue(auditId, resolution = "DEFENDED_CONFIRMED", note = "") {
    if (auditId && typeof auditId === "object") {
      resolution = auditId.resolution || resolution;
      note = auditId.note || note;
      auditId = auditId.auditId || "";
    }
    resolution = resolution || "DEFENDED_CONFIRMED";
    const audits = this._loadAudits();
    const target = audits.find(a => a && a.auditId === auditId);
    if (!target) {
      return { success: false, message: `분쟁 감사 ID [${auditId || "N/A"}]를 찾을 수 없습니다.` };
    }

    target.status = "RESOLVED";
    target.resolution = resolution;
    target.resolvedAt = new Date().toISOString();
    target.notes = String(note || "공정위 감가상각 공식 소명 완료 및 분쟁 방어 종결.");

    this._saveAudits(audits);
    return { success: true, audit: target };
  }
}

function createConsumerDisputeSentinel(options = {}) {
  return new ConsumerDisputeSentinel(options);
}

const defaultConsumerDisputeSentinel = new ConsumerDisputeSentinel();

module.exports = {
  CONSUMER_USEFUL_LIFE_DATABASE,
  calculateDepreciation,
  evaluateConsumerDispute,
  generateDisputeDisputeEvidenceHtml,
  generateDisputeEvidenceHtml,
  ConsumerDisputeSentinel,
  createConsumerDisputeSentinel,
  consumerDisputeSentinel: defaultConsumerDisputeSentinel
};
