# AutoFlow Windows Sleep Prevention Daemon (Zero-Privilege Keep-Alive)
# Prevents Windows from entering Modern Standby / Sleep mode while AutoFlow is running.
# Does NOT touch Windows Registry, does NOT require Administrator (UAC) rights.
# Allows monitor display to turn off safely while keeping CPU & Network alive for Coupang polling.

Write-Output "[AutoFlow Guardian] Initializing Zero-Privilege Sleep Prevention..."

try {
    $code = @'
    using System;
    using System.Runtime.InteropServices;
    public class SleepUtil {
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern uint SetThreadExecutionState(uint esFlags);
    }
'@
    Add-Type -TypeDefinition $code -ErrorAction Stop

    # ES_CONTINUOUS (0x80000000) | ES_SYSTEM_REQUIRED (0x00000001) | ES_AWAYMODE_REQUIRED (0x00000040)
    $EXECUTION_STATE = [uint32]0x80000041
    [SleepUtil]::SetThreadExecutionState($EXECUTION_STATE) | Out-Null
    Write-Output "[AutoFlow Guardian] System Sleep successfully locked. AutoFlow order ingestion will run 24/7 without freezing."

    # Loop with low CPU overhead (heartbeat every 60s)
    while ($true) {
        Start-Sleep -Seconds 60
        [SleepUtil]::SetThreadExecutionState($EXECUTION_STATE) | Out-Null
    }
} catch {
    Write-Output "[AutoFlow Guardian] Sleep prevention fallback active: $($_.Exception.Message)"
    while ($true) {
        Start-Sleep -Seconds 60
    }
}
