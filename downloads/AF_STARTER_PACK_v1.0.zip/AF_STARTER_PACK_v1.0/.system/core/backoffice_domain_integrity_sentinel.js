/**
 * AutoFlow Back-Office Domain-Specific Integrity, Multi-Currency & International Contract Sentinel
 * (core/backoffice_domain_integrity_sentinel.js)
 *
 * [개발 목적 — 틀 3: 사내 백오피스(글로벌 재무·국제 계약·인사·인프라) 전용 고도화 엔진]
 * 한국어에 국한되지 않고, 글로벌 표준(ISO-4217 다통화, 영문/다국어 국제 상업 계약서, 3-Way 대사)을 적용한
 * 멀티레이어 프로덕션 엔진:
 *
 * 1. [BO-Part 1: 글로벌 15대 통화 3-Way 정산 대사 & 세무 자가치유]
 *    발주서(PO) ↔ 인보이스(Invoice) ↔ 영수증(Payment) 3자 대사.
 *    통화 바꿔치기 사기(KRW ➔ USD 변조), 글로벌 부가세(EU VAT 19~20%, US Sales Tax, JP 10%, KR 10%, SG/AU GST)
 *    오차 자동 역산 및 심야·제한업종(MCC) 결제 격리.
 *
 * 2. [BO-Part 2: 국제 표준 계약서 수치·필수조항·독소조항 감사]
 *    영문 표기 금액("One Hundred Thousand US Dollars" ↔ "$10,000.00") 및 한글 표기 금액 불일치 적발,
 *    본문↔별첨 통화 충돌(USD vs EUR), 8대 국제 표준 필수 조항(Limitation of Liability, Indemnification 등)
 *    누락 검증 및 6대 글로벌 독소조항(Uncapped Liability, Evergreen Auto-Renewal 등) 감지.
 *
 * 3. [BO-Part 3: 경영 지표 Z-Score 이상치 탐지 & 자금 런웨이 리포트]
 *    최근 30일 이동평균 대비 매출 급락·비정상 지출 폭증·30/60/90일 미수금(Aging Receivables) 이상치 분석.
 *
 * 4. [BO-Part 4: 글로벌 Zero-Trust IAM 권한 감사 & 서버 알림폭탄(Alert Fatigue) 억제]
 *    입사자 과도권한(SUPER_ADMIN) 차단, 퇴사자 미회수 권한 스캔, 서버 다운 시 15분 쿨다운 알림폭탄 제어.
 */

'use strict';

const crypto = require('crypto');

// 글로벌 법인카드 비업무/제한 가맹점 (다국어/글로벌 키워드)
const GLOBAL_RESTRICTED_MERCHANT_REGEX = new RegExp([
  '단란주점', '유흥주점', '가라오케', '룸살롱', '나이트클럽', '카지노', '복권방', '성인용품', '골프장', '컨트리클럽', '상품권\\s*매매', '귀금속',
  'casino', 'gambling', 'nightclub', 'strip\\s*club', 'gentlemen\\s*club', 'lottery', 'adult\\s*entertainment', 'golf\\s*club', 'country\\s*club'
].join('|'), 'i');

// 글로벌 15대 통화 ISO-4217
const SUPPORTED_CURRENCIES = Object.freeze([
  'USD', 'EUR', 'JPY', 'GBP', 'CNY', 'KRW', 'SGD', 'AUD', 'CAD', 'CHF', 'HKD', 'NZD', 'INR', 'BRL', 'TWD'
]);

// 8대 국제 상업 계약 필수 조항 매트릭스 (English & Korean)
const GLOBAL_MANDATORY_CONTRACT_CLAUSES = Object.freeze([
  {
    id: 'PAYMENT_TERMS',
    label: '대금 지급기일 및 통화 조건 (Payment & Currency Terms)',
    regex: /(대금|보수|용역비|지급\s*기일|지급\s*방법|정산\s*일|입금|payment\s*terms|net\s*(?:15|30|45|60|90)|invoicing|wire\s*transfer|due\s*date)/i
  },
  {
    id: 'TERMINATION_TERMS',
    label: '계약 기간 및 해지 조항 (Term & Termination)',
    regex: /(해지|해제|중도\s*해지|계약\s*종료|파기|term\s*and\s*termination|termination\s*for\s*cause|cure\s*period|written\s*notice)/i
  },
  {
    id: 'LIMITATION_OF_LIABILITY',
    label: '손해배상 책임 한도 (Limitation of Liability / Liability Cap)',
    regex: /(손해\s*배상\s*한도|배상\s*책임\s*제한|limitation\s*of\s*liability|aggregate\s*liability|shall\s*not\s*exceed|liability\s*cap)/i
  },
  {
    id: 'INDEMNIFICATION',
    label: '면책 및 보상 (Indemnification & Third-Party Claims)',
    regex: /(면책|방어\s*의무|제3자\s*청구|indemnif(?:y|ication)|hold\s*harmless|defend\s*and\s*indemnify)/i
  },
  {
    id: 'INTELLECTUAL_PROPERTY',
    label: '지식재산권 및 성과물 귀속 (Intellectual Property & Deliverables)',
    regex: /(지식\s*재산권|저작권|특허|성과물\s*귀속|intellectual\s*property|work\s*made\s*for\s*hire|ownership\s*of\s*deliverables|background\s*ip)/i
  },
  {
    id: 'CONFIDENTIALITY_DATA_PRIVACY',
    label: '비밀유지 및 개인정보 보호 (Confidentiality & Data Privacy / GDPR)',
    regex: /(비밀\s*유지|보안|개인정보|confidentiality|non-disclosure|proprietary\s*information|data\s*protection|gdpr|personally\s*identifiable)/i
  },
  {
    id: 'FORCE_MAJEURE',
    label: '불가항력 면책 조항 (Force Majeure)',
    regex: /(불가\s*항력|천재\s*지변|전쟁|force\s*majeure|act\s*of\s*god|beyond\s*(?:reasonable\s*)?control)/i
  },
  {
    id: 'GOVERNING_LAW_AND_DISPUTE',
    label: '준거법 및 분쟁 해결 / 국제중재 (Governing Law & Dispute Resolution)',
    regex: /(관할\s*법원|준거법|중재|분쟁\s*해결|governing\s*law|jurisdiction|dispute\s*resolution|arbitration|exclusive\s*jurisdiction)/i
  }
]);

// 6대 글로벌 불공정 독소 조항 매트릭스 (English & Korean)
const GLOBAL_TOXIC_CLAUSES = Object.freeze([
  {
    id: 'UNCAPPED_LIABILITY',
    label: '무제한 배상 책임 독소 조항 (Uncapped / Unlimited Liability)',
    regex: /(모든\s*민형사상\s*책임을\s*전적으로|무한\s*배상|unlimited\s*liability|liable\s*without\s*limitation|all\s*consequential.*without\s*cap)/i
  },
  {
    id: 'UNILATERAL_CONVENIENCE_TERMINATION',
    label: '일방적 무통보 즉시 해지 (Unilateral Termination without Notice)',
    regex: /(언제든지\s*일방적으로\s*해지|사전\s*통보\s*없이\s*해지|terminate\s*immediately\s*without\s*(?:prior\s*)?notice|at\s*its\s*sole\s*discretion\s*without\s*cause)/i
  },
  {
    id: 'EVERGREEN_AUTO_RENEWAL_TRAP',
    label: '자동 무기한 갱신 감옥 조항 (Evergreen Auto-Renewal Trap)',
    regex: /(별도\s*통보\s*없으면\s*자동으로\s*동일\s*기간\s*연장|automatically\s*renew\s*(?:for\s*successive|without\s*notice)|evergreen\s*renewal)/i
  },
  {
    id: 'SURRENDER_OF_BACKGROUND_IP',
    label: '사전 대가 없는 기존 배경 지식재산권 강제 양도 (Surrender of Background IP)',
    regex: /(일체의\s*지식재산권은\s*무상으로\s*갑에게|모든\s*소유권과\s*저작권은\s*대금\s*지급\s*전이라도|assign\s*all\s*pre-existing\s*(?:ip|intellectual\s*property)|transfer\s*background\s*technology\s*without\s*consideration)/i
  },
  {
    id: 'UNREASONABLE_EXCLUSIVITY',
    label: '과도한 글로벌 영업 금지 (Unreasonable Worldwide Non-Compete)',
    regex: /(동종\s*업계\s*일체\s*거래\s*금지|전세계\s*영업\s*제한|shall\s*not\s*provide\s*(?:any\s*)?services\s*to\s*any\s*competitor\s*worldwide|exclusive\s*worldwide\s*restriction)/i
  },
  {
    id: 'EXCESSIVE_LIQUIDATED_DAMAGES',
    label: '과도한 징벌적 위약금 (Excessive / Punitive Liquidated Damages)',
    regex: /(계약금액의\s*[3-9]\s*배|계약금액의\s*\d{2,}\s*배|liquidated\s*damages\s*exceeding\s*50%|punitive\s*damages\s*equal\s*to\s*\d+\s*times)/i
  }
]);

// 영문 텍스트 금액을 숫자로 변환하는 결정론적 파서
function parseEnglishAmountToNumber(engStr) {
  if (typeof engStr !== 'string' || !engStr.trim()) return null;
  const clean = engStr.toLowerCase().replace(/[^a-z\s-]/g, ' ').replace(/-/g, ' ');
  const words = clean.split(/\s+/).filter(Boolean);
  if (words.length === 0) return null;

  const smallNums = {
    zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9,
    ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16,
    seventeen: 17, eighteen: 18, nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50,
    sixty: 60, seventy: 70, eighty: 80, ninety: 90
  };

  const scaleMultipliers = {
    hundred: 100,
    thousand: 1000,
    million: 1000000,
    billion: 1000000000
  };

  let total = 0;
  let current = 0;
  let hasValidWord = false;

  for (const w of words) {
    if (smallNums[w] !== undefined) {
      current += smallNums[w];
      hasValidWord = true;
    } else if (w === 'hundred') {
      current = (current === 0 ? 1 : current) * 100;
      hasValidWord = true;
    } else if (scaleMultipliers[w] !== undefined) {
      current = (current === 0 ? 1 : current) * scaleMultipliers[w];
      total += current;
      current = 0;
      hasValidWord = true;
    }
  }

  total += current;
  return hasValidWord && total > 0 ? total : null;
}

// 한국어 금액 파서 (아라비아 숫자 + 한글 단위 혼용 및 순수 한글 완벽 지원)
function parseKoreanAmountToNumber(korStr) {
  if (typeof korStr !== 'string' || !korStr.trim()) return null;
  const raw = korStr.trim();

  // 1) 순수 숫자 또는 콤마 표기 (예: "150,000,000원", "150000000")
  const pureNumMatch = raw.replace(/,/g, '').match(/^([0-9]+(?:\.[0-9]+)?)\s*원?$/);
  if (pureNumMatch && Number(pureNumMatch[1]) > 0) {
    return Number(pureNumMatch[1]);
  }

  // 2) 숫자 + 한글 단위 혼용 또는 순수 한글 (예: "1억 5천만", "1억 5000만", "일억 오천만")
  const digitMap = { 일: 1, 이: 2, 삼: 3, 사: 4, 오: 5, 육: 6, 칠: 7, 팔: 8, 구: 9, 영: 0 };
  const smallUnitMap = { 십: 10, 백: 100, 천: 1000 };

  let working = raw.replace(/,/g, '').replace(/\s+/g, '');
  let grandTotal = 0;
  let matchedAny = false;

  const largeUnits = [
    { unit: '조', val: 1000000000000 },
    { unit: '억', val: 100000000 },
    { unit: '만', val: 10000 }
  ];

  for (const { unit, val } of largeUnits) {
    const idx = working.indexOf(unit);
    if (idx !== -1) {
      const part = working.slice(0, idx);
      working = working.slice(idx + 1);
      const partVal = parseSubThousand(part);
      if (partVal > 0) {
        grandTotal += partVal * val;
        matchedAny = true;
      } else if (partVal === 0 && part === '') {
        grandTotal += val;
        matchedAny = true;
      }
    }
  }

  if (working) {
    const remainderClean = working.replace(/원.*/, '');
    const remainderVal = parseSubThousand(remainderClean);
    if (remainderVal > 0) {
      grandTotal += remainderVal;
      matchedAny = true;
    }
  }

  function parseSubThousand(subStr) {
    if (!subStr) return 0;
    if (/^[0-9]+$/.test(subStr)) {
      return Number(subStr);
    }
    let subTotal = 0;
    let currNum = 0;
    for (let i = 0; i < subStr.length; i++) {
      const ch = subStr[i];
      if (/[0-9]/.test(ch)) {
        let numStr = ch;
        while (i + 1 < subStr.length && /[0-9]/.test(subStr[i + 1])) {
          numStr += subStr[++i];
        }
        currNum = Number(numStr);
      } else if (digitMap[ch] !== undefined) {
        currNum = digitMap[ch];
      } else if (smallUnitMap[ch] !== undefined) {
        subTotal += (currNum === 0 ? 1 : currNum) * smallUnitMap[ch];
        currNum = 0;
      }
    }
    subTotal += currNum;
    return subTotal;
  }

  return matchedAny && grandTotal > 0 ? grandTotal : null;
}

class BackofficeDomainIntegritySentinel {
  constructor(options = {}) {
    const safeOpts = (options && typeof options === 'object' && !Array.isArray(options)) ? options : {};
    this.alertCooldownMs = Number(safeOpts.alertCooldownMs) > 0 ? Number(safeOpts.alertCooldownMs) : 15 * 60 * 1000;
    this.defaultBaseCurrency = String(safeOpts.baseCurrency || 'USD').toUpperCase();
  }

  // ===========================================================================
  // [BO-Part 1] 글로벌 15대 통화 3-Way 정산 대사 & 세무 자가치유 (Expense & 3-Way Match)
  // ===========================================================================

  /**
   * 발주서(PO) ↔ 인보이스(Invoice) ↔ 영수증(Payment) 3자 대사 및 다통화/부가세 정합성 검수
   * @param {Object} payload { po, invoice, payment, existingClaims, timeZoneHour }
   */
  verifyReceiptExpenseIntegrity(payload = {}) {
    const safe = (payload && typeof payload === 'object' && !Array.isArray(payload)) ? payload : {};
    const merchantName = String(safe.merchantName || (safe.invoice && safe.invoice.vendorName) || (safe.payment && (safe.payment.merchantName || safe.payment.vendorName)) || '').trim();
    const approvalNumber = String(safe.approvalNumber || (safe.payment && (safe.payment.authCode || safe.payment.approvalNumber)) || '').trim();
    const transactionDate = String(safe.transactionDate || (safe.payment && safe.payment.date) || '').trim();
    const hour = Number.isFinite(Number(safe.transactionHour || safe.timeZoneHour)) ? Number(safe.transactionHour || safe.timeZoneHour) : 12;
    const totalAmount = Math.max(0, Number(safe.totalAmount || (safe.payment && (safe.payment.totalAmount || safe.payment.amount)) || (safe.invoice && (safe.invoice.totalAmount || safe.invoice.total))) || 0);
    const currency = String(safe.currency || (safe.payment && safe.payment.currency) || (safe.invoice && safe.invoice.currency) || this.defaultBaseCurrency).toUpperCase();
    const existingClaims = Array.isArray(safe.existingClaims) ? safe.existingClaims : [];

    const receiptFingerprint = crypto
      .createHash('sha256')
      .update(`${approvalNumber || 'NO_APP'}::${merchantName}::${transactionDate}::${totalAmount}::${currency}`)
      .digest('hex')
      .slice(0, 24);

    const flags = [];

    // 1) 3-Way Matching 대사 (PO ↔ Invoice ↔ Payment)
    let threeWayMatchPassed = true;
    let threeWayDiscrepancies = [];

    if (safe.po && safe.invoice) {
      const poTotal = Number(safe.po.totalAmount || safe.po.amount) || 0;
      const poCurrency = String(safe.po.currency || currency).toUpperCase();
      if (poCurrency !== currency) {
        flags.push('PO_INVOICE_CURRENCY_MISMATCH_FRAUD_RISK');
        threeWayMatchPassed = false;
        threeWayDiscrepancies.push(`PO Currency (${poCurrency}) != Invoice Currency (${currency})`);
      }
      if (Math.abs(poTotal - totalAmount) > 0.01 && poTotal > 0) {
        flags.push('PO_INVOICE_AMOUNT_MISMATCH');
        threeWayMatchPassed = false;
        threeWayDiscrepancies.push(`PO Amount (${poTotal}) != Billed Amount (${totalAmount})`);
      }
    }

    // 2) 국가별 세무 및 부가세(VAT/GST/Sales Tax) 자동 계산 및 자가치유
    let expectedVatRate = 0.10; // 한국 10% 기본
    if (['EUR', 'GBP'].includes(currency)) expectedVatRate = 0.20; // 유럽/영국 20%
    else if (currency === 'JPY') expectedVatRate = 0.10; // 일본 소비세 10%
    else if (currency === 'AUD' || currency === 'SGD') expectedVatRate = currency === 'SGD' ? 0.09 : 0.10; // GST
    else if (currency === 'USD') expectedVatRate = 0.00; // 미국은 주별 Sales Tax 별도 기재

    const isZeroDecimal = ['KRW', 'JPY', 'VND'].includes(currency);
    let expectedSupply;
    let expectedVat;
    if (currency === 'USD') {
      expectedSupply = totalAmount;
      expectedVat = 0;
    } else if (isZeroDecimal) {
      expectedSupply = Math.round(totalAmount / (1 + expectedVatRate));
      expectedVat = totalAmount - expectedSupply;
    } else {
      expectedSupply = Math.round((totalAmount / (1 + expectedVatRate)) * 100) / 100;
      expectedVat = Math.round((totalAmount - expectedSupply) * 100) / 100;
    }

    const inputSupply = Number(safe.supplyAmount) || 0;
    const inputVat = Number(safe.vatAmount) || 0;
    const vatMismatch = inputSupply > 0 && Math.abs((inputSupply + inputVat) - totalAmount) > 0.05;

    const healedTaxBreakdown = {
      totalAmount,
      currency,
      appliedVatRate: expectedVatRate,
      supplyAmount: vatMismatch || inputSupply === 0 ? expectedSupply : inputSupply,
      vatAmount: vatMismatch || (inputVat === 0 && currency !== 'USD') ? expectedVat : inputVat,
      vatAutoHealed: vatMismatch && totalAmount > 0
    };

    // 3) 이중 청구(중복 영수증/인보이스 업로드) 차단
    const duplicateClaim = existingClaims.find((c) => {
      if (!c || typeof c !== 'object') return false;
      if (approvalNumber && String(c.approvalNumber || '').trim() === approvalNumber) return true;
      return (
        String(c.merchantName || '').trim().toLowerCase() === merchantName.toLowerCase() &&
        String(c.transactionDate || '').trim() === transactionDate &&
        Number(c.totalAmount) === totalAmount &&
        String(c.currency || currency).toUpperCase() === currency &&
        totalAmount > 0
      );
    });

    if (duplicateClaim) {
      flags.push('DUPLICATE_RECEIPT_CLAIM');
      return {
        ok: true,
        status: 'BLOCKED_DUPLICATE_RECEIPT_CLAIM',
        allowedToBook: false,
        quarantineForAudit: true,
        threeWayMatchPassed: false,
        flags,
        receiptFingerprint,
        healedTaxBreakdown
      };
    }

    // 4) 글로벌 제한 업종(Casino, Nightclub, Golf 등) 및 심야 비업무 시간 결제 검사
    if (GLOBAL_RESTRICTED_MERCHANT_REGEX.test(merchantName)) {
      flags.push('RESTRICTED_MERCHANT_CATEGORY');
    }
    if (hour >= 23 || hour < 5) {
      flags.push('LATE_NIGHT_ABNORMAL_HOUR');
    }

    if (flags.length > 0) {
      return {
        ok: true,
        status: 'HOLD_FOR_MANAGER_APPROVAL',
        allowedToBook: false,
        quarantineForAudit: true,
        threeWayMatchPassed,
        threeWayDiscrepancies,
        flags,
        receiptFingerprint,
        healedTaxBreakdown
      };
    }

    return {
      ok: true,
      status: 'VERIFIED_CLEAN_RECEIPT',
      allowedToBook: true,
      quarantineForAudit: false,
      threeWayMatchPassed: true,
      threeWayDiscrepancies: [],
      flags: [],
      receiptFingerprint,
      healedTaxBreakdown
    };
  }

  // ===========================================================================
  // [BO-Part 2] 국제 표준(다국어) 계약서 수치·필수조항·독소조항 감사 (Contract Auditor)
  // ===========================================================================

  /**
   * 영문·다국어 계약서 금액 표기 불일치(One Hundred Thousand vs $10,000) 및 8대 필수 조항 / 6대 독소 조항 정밀 검증
   * @param {Object} payload { contractText, statedNumericAmount, statedCurrency }
   */
  verifyContractClauseAndAmountIntegrity(payload = {}) {
    const safe = (payload && typeof payload === 'object' && !Array.isArray(payload)) ? payload : {};
    const contractText = String(safe.contractText || '').trim();

    if (!contractText) {
      return {
        ok: true,
        status: 'EMPTY_CONTRACT_TEXT',
        passed: false,
        amountMismatchDetected: false,
        currencyConflictDetected: false,
        missingMandatoryClauses: GLOBAL_MANDATORY_CONTRACT_CLAUSES.map((c) => c.label),
        detectedToxicClauses: []
      };
    }

    // 1) 통화 기호 일관성 검사 (본문 내 여러 통화 심볼 혼용 충돌 감지)
    const detectedCurrencies = new Set();
    if (/\$|USD/i.test(contractText)) detectedCurrencies.add('USD');
    if (/€|EUR/i.test(contractText)) detectedCurrencies.add('EUR');
    if (/£|GBP/i.test(contractText)) detectedCurrencies.add('GBP');
    if (/¥|JPY|CNY/i.test(contractText)) detectedCurrencies.add('JPY_OR_CNY');
    if (/₩|KRW/i.test(contractText)) detectedCurrencies.add('KRW');

    const currencyConflictDetected = detectedCurrencies.size > 1;

    // 2) 영문 금액 텍스트 vs 숫자 금액 교차 검증 (예: "One Hundred Thousand USD" vs "$10,000.00")
    let amountMismatchDetected = false;
    let parsedWrittenAmount = null;
    let parsedNumericAmount = Number(safe.statedNumericAmount) > 0 ? Number(safe.statedNumericAmount) : null;

    // 영문 텍스트 금액 추출 (예: "Sum of One Hundred Thousand Dollars ($10,000)")
    const engWrittenMatch = contractText.match(/(?:sum\s*of|amount\s*of|total\s*of)\s+([a-zA-Z\s-]+)\s*(?:dollars|usd|euros|eur|pounds|gbp|won|krw)/i);
    if (engWrittenMatch && engWrittenMatch[1]) {
      parsedWrittenAmount = parseEnglishAmountToNumber(engWrittenMatch[1]);
    }

    // 한국어 텍스트 금액 추출 (예: "금 1억 5천만 원정 (₩150,000,000)" 또는 "금 일억오천만원정")
    if (!parsedWrittenAmount) {
      const korMatch = contractText.match(/(?:금|계약\s*금액|총\s*대금)[:\s]*([0-9일이삼사오육칠팔구십백천만억조,\s]+)\s*원(?:정)?/i);
      if (korMatch && korMatch[1]) {
        parsedWrittenAmount = parseKoreanAmountToNumber(korMatch[1]);
      }
    }

    // 숫자 금액 파싱 (괄호 안 숫자나 통화 심볼 뒤 숫자)
    if (!parsedNumericAmount) {
      const numMatch = contractText.match(/(?:\$|€|£|₩|USD|EUR|GBP|KRW)\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?)/i);
      if (numMatch && numMatch[1]) {
        parsedNumericAmount = Number(numMatch[1].replace(/,/g, ''));
      }
    }

    if (parsedWrittenAmount && parsedNumericAmount && Math.abs(parsedWrittenAmount - parsedNumericAmount) > 0.01) {
      amountMismatchDetected = true;
    }

    // 3) 8대 국제 표준 필수 조항 누락 여부 검사
    const missingMandatoryClauses = [];
    for (const clause of GLOBAL_MANDATORY_CONTRACT_CLAUSES) {
      if (!clause.regex.test(contractText)) {
        missingMandatoryClauses.push(clause.label);
      }
    }

    // 4) 6대 글로벌 독소 조항 검사
    const detectedToxicClauses = [];
    for (const toxic of GLOBAL_TOXIC_CLAUSES) {
      if (toxic.regex.test(contractText)) {
        // UNCAPPED_LIABILITY 특별 가드: "neither party shall be subject to unlimited liability" 등 부정문 책임제한 문맥 오탐 배제
        if (toxic.id === 'UNCAPPED_LIABILITY') {
          const isSafeLiabilityCap = /(?:neither\s*party\s*(?:shall\s*be\s*subject\s*to|has)\s*unlimited|not\s*(?:be\s*)?liable\s*without\s*limitation|no\s*party\s*shall\s*have\s*unlimited|total\s*liability\s*(?:shall\s*be|is)\s*capped)/i.test(contractText);
          if (isSafeLiabilityCap) {
            continue;
          }
        }
        detectedToxicClauses.push(toxic.label);
      }
    }

    const hasRisk = amountMismatchDetected || currencyConflictDetected || missingMandatoryClauses.length > 0 || detectedToxicClauses.length > 0;
    return {
      ok: true,
      status: hasRisk ? 'CONTRACT_RISK_DETECTED_HOLD' : 'PASS_CONTRACT_INTEGRITY',
      passed: !hasRisk,
      amountMismatchDetected,
      currencyConflictDetected,
      detectedCurrencies: [...detectedCurrencies],
      parsedWrittenAmount,
      parsedNumericAmount,
      missingMandatoryClauses,
      detectedToxicClauses
    };
  }

  // ===========================================================================
  // [BO-Part 3 & 4] IAM 권한 무결성 및 인프라 서버 알림 폭탄 억제 (IAM & Alert Debouncer)
  // ===========================================================================

  /**
   * 입·퇴사자 권한 정합성 검증 및 서버 500 에러 알림 폭탄(Alert Fatigue) 억제
   * @param {Object} payload { eventType, requestedRole, revokedChannels, requiredChannels, serverHttpStatus, lastAlertTimestampMs, nowMs }
   */
  guardIamOnboardingAndServerAlertFatigue(payload = {}) {
    const safe = (payload && typeof payload === 'object' && !Array.isArray(payload)) ? payload : {};
    const eventType = String(safe.eventType || 'SERVER_HEALTHCHECK').toUpperCase();

    if (eventType === 'ONBOARDING_ROLE_CHECK') {
      const requestedRole = String(safe.requestedRole || 'MEMBER').toUpperCase();
      const isExcessivePrivilege = /(SUPER_ADMIN|ROOT|OWNER|BILLING_ADMIN|ORG_ADMIN)/i.test(requestedRole);
      return {
        ok: true,
        status: isExcessivePrivilege ? 'BLOCKED_EXCESSIVE_NEW_HIRE_PRIVILEGE' : 'ALLOWED_STANDARD_ONBOARDING',
        allowed: !isExcessivePrivilege,
        requestedRole,
        safeFallbackRole: isExcessivePrivilege ? 'STANDARD_MEMBER' : requestedRole
      };
    }

    if (eventType === 'OFFBOARDING_REVOCATION_AUDIT') {
      const required = Array.isArray(safe.requiredChannels) && safe.requiredChannels.length > 0
        ? safe.requiredChannels
        : ['SLACK', 'NOTION', 'EMAIL', 'GITHUB', 'AWS_CONSOLE'];
      const revoked = new Set((Array.isArray(safe.revokedChannels) ? safe.revokedChannels : []).map((c) => String(c).toUpperCase()));
      const unrevokedChannels = required.filter((c) => !revoked.has(String(c).toUpperCase()));
      return {
        ok: true,
        status: unrevokedChannels.length > 0 ? 'ALERT_UNREVOKED_OFFBOARDING_ACCESS' : 'PASS_ALL_ACCESS_REVOKED',
        allRevoked: unrevokedChannels.length === 0,
        unrevokedChannels
      };
    }

    // SERVER_HEALTHCHECK 알림 폭탄 억제
    const httpStatus = Number(safe.serverHttpStatus) || 500;
    const lastAlertTs = Number(safe.lastAlertTimestampMs) || 0;
    const nowMs = Number(safe.nowMs) > 0 ? Number(safe.nowMs) : Date.now();
    const isDown = httpStatus >= 500 || httpStatus === 0;

    if (!isDown) {
      return {
        ok: true,
        status: lastAlertTs > 0 ? 'SERVER_RECOVERED_SEND_CLEAR_NOTICE' : 'SERVER_HEALTHY_SILENT',
        shouldDispatchTelegram: lastAlertTs > 0,
        httpStatus
      };
    }

    const elapsedSinceLastAlert = nowMs - lastAlertTs;
    if (lastAlertTs > 0 && elapsedSinceLastAlert < this.alertCooldownMs) {
      return {
        ok: true,
        status: 'SUPPRESSED_ALERT_FATIGUE_COOLDOWN',
        shouldDispatchTelegram: false,
        httpStatus,
        cooldownRemainingMs: this.alertCooldownMs - elapsedSinceLastAlert
      };
    }

    return {
      ok: true,
      status: 'DISPATCH_FIRST_EMERGENCY_ALERT',
      shouldDispatchTelegram: true,
      httpStatus
    };
  }
}

module.exports = {
  BackofficeDomainIntegritySentinel,
  parseEnglishAmountToNumber,
  parseKoreanAmountToNumber,
  verifyReceiptExpenseIntegrity: (payload) => new BackofficeDomainIntegritySentinel().verifyReceiptExpenseIntegrity(payload),
  verifyContractClauseAndAmountIntegrity: (payload) => new BackofficeDomainIntegritySentinel().verifyContractClauseAndAmountIntegrity(payload),
  guardIamOnboardingAndServerAlertFatigue: (payload) => new BackofficeDomainIntegritySentinel().guardIamOnboardingAndServerAlertFatigue(payload)
};
