@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title AutoFlow Enterprise Engine 라이선스 관리 및 충전 런처
cd /d "%~dp0"

set "NODE_BIN="
if exist "%~dp0bin\node.exe" (
    set "NODE_BIN=%~dp0bin\node.exe"
) else if exist "%~dp0..\bin\node.exe" (
    set "NODE_BIN=%~dp0..\bin\node.exe"
) else (
    where node >nul 2>nul
    if !errorlevel! equ 0 set "NODE_BIN=node"
)

if "!NODE_BIN!"=="" (
    echo [*] Windows 포터블 Node.js 런타임^(node-v20.18.0-win-x64^) 무인 자동 다운로드 중...
    if not exist "%~dp0bin" mkdir "%~dp0bin"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference = 'SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $zipUrl = 'https://nodejs.org/dist/v20.18.0/node-v20.18.0-win-x64.zip'; $zipPath = Join-Path '%~dp0' 'bin\node_win_x64.zip'; $extractDir = Join-Path '%~dp0' 'bin\node_extract_tmp'; Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing; if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }; Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force; Copy-Item -Path (Join-Path $extractDir 'node-v20.18.0-win-x64\node.exe') -Destination (Join-Path '%~dp0' 'bin\node.exe') -Force; Remove-Item $zipPath -Force -ErrorAction SilentlyContinue; Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue"
    if exist "%~dp0bin\node.exe" (
        set "NODE_BIN=%~dp0bin\node.exe"
    ) else (
        echo ❌ Node.js 런타임 자동 다운로드에 실패했습니다. 네트워크 연결을 확인해 주세요.
        pause
        exit /b 1
    )
)

set "SCRIPT_FILE=%~dp0recharge_cli.js"
if not exist "!SCRIPT_FILE!" (
    if exist "%~dp0core\recharge_cli.js" set "SCRIPT_FILE=%~dp0core\recharge_cli.js"
)

cls
echo ============================================================
echo ⚡ AutoFlow Enterprise Engine 라이선스 관리 및 충전 런처
echo ============================================================
echo.
"!NODE_BIN!" "!SCRIPT_FILE!" status
echo.
echo 원하시는 작업을 선택하세요:
echo  [1] 1개월(30일) 기간 충전팩 적용
echo  [2] 3개월(90일) 기간 충전팩 적용
echo  [3] 1년(365일) 엔터프라이즈 충전팩 적용
echo  [4] 직접 일수 입력 (Custom)
echo  [5] 라이선스 상태 새로고침
echo  [q] 종료
echo.
set /p choice="선택 (1-5, q): "

if "!choice!"=="1" (
    "!NODE_BIN!" "!SCRIPT_FILE!" 30 "TOPUP_30DAYS_WIN_%RANDOM%" "1개월 충전팩 수동 적용"
) else if "!choice!"=="2" (
    "!NODE_BIN!" "!SCRIPT_FILE!" 90 "TOPUP_90DAYS_WIN_%RANDOM%" "3개월 충전팩 수동 적용"
) else if "!choice!"=="3" (
    "!NODE_BIN!" "!SCRIPT_FILE!" 365 "TOPUP_365DAYS_WIN_%RANDOM%" "1년 충전팩 수동 적용"
) else if "!choice!"=="4" (
    set /p custom_days="추가할 일수를 입력하세요 (예: 15): "
    "!NODE_BIN!" "!SCRIPT_FILE!" !custom_days! "TOPUP_CUSTOM_WIN_%RANDOM%" "직접 입력 충전팩 적용"
) else if "!choice!"=="5" (
    cls
    "!NODE_BIN!" "!SCRIPT_FILE!" status
) else if /i "!choice!"=="q" (
    exit /b 0
) else (
    echo 잘못된 입력입니다.
)

echo.
pause
