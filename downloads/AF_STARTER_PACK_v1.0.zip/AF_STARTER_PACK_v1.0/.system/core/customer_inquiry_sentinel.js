/**
 * AutoFlow Customer Inquiry SLA & Auto-Triage Sentinel
 * (core/customer_inquiry_sentinel.js)
 * 
 * [목적 및 비즈니스/법무 배경]
 * 1. 쿠팡 WING 고객 문의(Q&A) 24시간 SLA 답변 기한 초과 방어 및 판매자 점수(아이템위너) 감점 원천 차단.
 * 2. 5대 핵심 카테고리([배송조회], [취소/변경], [반품/교환], [상품/옵션], [파손/오배송]) 1초 정밀 자동 분류.
 * 3. 4단계 SLA 위험도 매트릭스(SAFE, ATTENTION, URGENT, EXPIRED) 카운트다운 및 18시간 경과 시 긴급 경보 발송.
 * 4. 「전자상거래 등에서의 소비자보호에 관한 법률」 제20조 제2항 준수: 1초 맞춤형 고객 안심 초동 응대문 자동 생성.
 * 5. 격한 항의 및 불만(ANGRY_ESCALATION) 사전 감별을 통한 1:1 우선 전담 처리 및 악성 1점 리뷰 원천 차단.
 */

const fs = require("fs");
const path = require("path");

class CustomerInquirySentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/customer_inquiries.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/customer_inquiry_config.json");
    this.slaHours = options.slaHours || 24;
    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(
          this.storagePath,
          JSON.stringify({ inquiries: [], resolvedInquiries: [], lastAuditTime: Date.now() }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}

    try {
      const cfgDir = path.dirname(this.configPath);
      if (!fs.existsSync(cfgDir)) {
        fs.mkdirSync(cfgDir, { recursive: true });
      }
      if (!fs.existsSync(this.configPath)) {
        fs.writeFileSync(
          this.configPath,
          JSON.stringify({
            enabled: true,
            slaHours: 24,
            warningHours: 18,
            urgentAlertOnTelegram: true,
            storeName: "AutoFlow 공식 스토어 고객센터",
            sellerCsPhone: "1544-0000"
          }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (_) {}
    return {
      enabled: true,
      slaHours: 24,
      warningHours: 18,
      urgentAlertOnTelegram: true,
      storeName: "AutoFlow 공식 스토어 고객센터",
      sellerCsPhone: "1544-0000"
    };
  }

  saveConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object") ? newConfig : {};
    try {
      const current = this.getConfig();
      const merged = Object.assign({}, current, newConfig);
      fs.writeFileSync(this.configPath, JSON.stringify(merged, null, 2), "utf8");
      return merged;
    } catch (err) {
      return this.getConfig();
    }
  }

  /**
   * 고객 문의 내용 기반 5대 카테고리 1초 정밀 자동 분류
   * @param {Object} inquiry 문의 객체 { inquiryId, content, title, ... }
   * @returns {string} SHIPPING_STATUS | CANCEL_CHANGE | RETURN_EXCHANGE | PRODUCT_SPEC | DEFECT_DAMAGE | GENERAL
   */
  classifyInquiry(inquiry = {}) {
    inquiry = (inquiry && typeof inquiry === "object") ? inquiry : {};
    const text = `${inquiry.title || ""} ${inquiry.content || ""} ${inquiry.inquiryType || ""}`.trim();
    if (!text) return "GENERAL";

    // 1. 파손 / 하자 / 불량 / 오배송 (최우선 감별)
    const defectPatterns = /(파손|깨짐|터짐|찌그러|불량|하자|오배송|누락|부품|작동.*안|고장|박스.*찢)/i;
    if (defectPatterns.test(text)) {
      return "DEFECT_DAMAGE";
    }

    // 2. 취소 / 주문정보 변경
    const cancelPatterns = /(취소|주문.*취소|결제.*취소|옵션.*변경|주소.*변경|수정|잘못.*주문|취소.*해.*주|철회)/i;
    if (cancelPatterns.test(text)) {
      return "CANCEL_CHANGE";
    }

    // 3. 반품 / 교환 / 환불
    const returnPatterns = /(반품|교환|환불|맞교환|수거|회수|반송|반품.*접수|보내.*드립|단순.*변심)/i;
    if (returnPatterns.test(text)) {
      return "RETURN_EXCHANGE";
    }

    // 4. 배송 조회 / 위치 / 일정
    const shippingPatterns = /(배송|송장|운송장|택배|언제.*도착|언제.*오|출발|조회|어디.*쯤|배송.*현황|도착.*예정)/i;
    if (shippingPatterns.test(text)) {
      return "SHIPPING_STATUS";
    }

    // 5. 상품 상세 / 스펙 / 유통기한 / 재고
    const productPatterns = /(상품|사이즈|색상|규격|성분|유통기한|호환|재고|재입고|사용법|용량|정품|단종)/i;
    if (productPatterns.test(text)) {
      return "PRODUCT_SPEC";
    }

    return "GENERAL";
  }

  /**
   * 격한 항의 및 악성 리뷰 위험 감별 (ANGRY_ESCALATION)
   * @param {Object} inquiry 문의 객체
   * @returns {boolean}
   */
  isAngryEscalation(inquiry = {}) {
    inquiry = (inquiry && typeof inquiry === "object") ? inquiry : {};
    const text = `${inquiry.title || ""} ${inquiry.content || ""}`;
    const angryPatterns = /(사기|고발|신고|소비자원|경찰|장난|최악|사기꾼|장난치|당장|환불해라|미쳤|개판|장난하나|똥개훈련)/i;
    return angryPatterns.test(text);
  }

  /**
   * 24시간 SLA 잔여 시간 및 4단계 위험도 산출
   * @param {Object} inquiry 문의 객체 { createdAt, inquiryTime, ... }
   * @param {number} currentTime 현재 시각 (ms)
   * @returns {Object}
   */
  evaluateSlaStatus(inquiry = {}, currentTime = Date.now()) {
    inquiry = (inquiry && typeof inquiry === "object") ? inquiry : {};
    let nowMs = (currentTime instanceof Date) ? currentTime.getTime() : Number(currentTime);
    if (!Number.isFinite(nowMs) || nowMs <= 0) {
      nowMs = Date.now();
    }
    let created = inquiry.createdAt ? new Date(inquiry.createdAt).getTime() : Number(inquiry.inquiryTime);
    if (!Number.isFinite(created) || created <= 0) {
      created = nowMs;
    }
    const elapsedMs = Math.max(0, nowMs - created);
    const elapsedHours = elapsedMs / (1000 * 60 * 60);

    const config = this.getConfig();
    const slaHours = config.slaHours || 24;
    const warningHours = config.warningHours || 18;

    const remainingHours = Math.max(0, slaHours - elapsedHours);

    let level = "SAFE";
    let isUrgent = false;
    let isExpired = false;

    if (elapsedHours >= slaHours) {
      level = "EXPIRED";
      isExpired = true;
    } else if (elapsedHours >= warningHours) {
      level = "URGENT";
      isUrgent = true;
    } else if (elapsedHours >= 12) {
      level = "ATTENTION";
    } else {
      level = "SAFE";
    }

    const isAngry = this.isAngryEscalation(inquiry);
    if (isAngry && level === "ATTENTION") {
      level = "URGENT";
      isUrgent = true;
    }

    return {
      inquiryId: inquiry.inquiryId || inquiry.id || "INQ-UNKNOWN",
      createdAt: new Date(created).toISOString(),
      elapsedHours: Math.round(elapsedHours * 10) / 10,
      remainingHours: Math.round(remainingHours * 10) / 10,
      level, // SAFE | ATTENTION | URGENT | EXPIRED
      isUrgent,
      isExpired,
      isAngryEscalation: isAngry
    };
  }

  /**
   * 1초 맞춤형 고객 감동 표준 초동 응대문 자동 생성
   * @param {Object} inquiry 문의 객체
   * @param {string} category 카테고리 (미지정 시 자동 분류)
   * @returns {string}
   */
  generateInitialResponse(inquiry = {}, category = null) {
    inquiry = (inquiry && typeof inquiry === "object") ? inquiry : {};
    const cat = (typeof category === "string" && category.trim()) ? category.trim() : this.classifyInquiry(inquiry);
    const config = this.getConfig();
    const storeName = config.storeName || "AutoFlow 고객센터";
    const csPhone = config.sellerCsPhone || "1544-0000";
    const customerName = inquiry.customerName || "고객";
    const productName = inquiry.productName || "주문 상품";
    const isAngry = this.isAngryEscalation(inquiry);

    let body = "";

    if (isAngry) {
      body = `먼저 이용에 큰 불편과 심려를 끼쳐 드려 머리 숙여 깊이 사과드립니다.\n` +
        `고객님께서 남겨주신 말씀 하나하나 엄중히 확인하고 있으며, 해당 건은 전담 매니저에게 최우선 긴급 배정되어 신속한 해결 방안을 검토 중에 있습니다.\n` +
        `신속히 추가 확인 후 본 창 또는 등록 연락처를 통해 100% 만족하실 수 있는 조치를 취해드리겠습니다. 다시 한번 진심으로 죄송합니다.`;
    } else {
      switch (cat) {
        case "SHIPPING_STATUS":
          body = `소중한 [${productName}] 주문에 감사드립니다.\n` +
            `고객님의 상품은 현재 물류센터에서 안전하게 검수 및 포장 출고 준비 중에 있습니다.\n` +
            `출고 즉시 쿠팡 시스템에 택배사 송장번호가 등록되며, 보통 출고 익일(영업일 기준 1~2일 내) 고객님의 댁 앞으로 안전하게 배송 완료될 예정입니다.\n` +
            `조금만 기다려 주시면 정성을 다해 안전하게 배송해 드리겠습니다.`;
          break;

        case "CANCEL_CHANGE":
          body = `주문 정보 변경 및 취소 관련하여 안내드립니다.\n` +
            `현재 주문 건의 물류센터 출고 진행 상태를 즉시 확인하고 있습니다.\n` +
            `아직 상품이 발송(집하)되기 전 단계라면 요청하신 대로 즉시 취소/변경 처리를 도와드리며, 이미 송장이 출력되어 포장 중인 경우에는 반품 절차로 안내해 드릴 수 있습니다.\n` +
            `확인되는 즉시 신속하게 확정 처리 내역을 안내해 드리겠습니다.`;
          break;

        case "RETURN_EXCHANGE":
          body = `반품 및 교환 접수 관련하여 안내드립니다.\n` +
            `이용에 불편을 드려 대단히 죄송합니다. 고객님의 반품/교환 요청을 100% 안심하고 진행하실 수 있도록 전담 기사님 수거 접수를 준비하고 있습니다.\n` +
            `상품이 훼손되지 않도록 받으셨던 박스에 그대로 포장하여 문 앞에 보관해 주시면, 택배 기사님께서 1~2영업일 내 방문하여 안전하게 회수할 예정입니다.\n` +
            `물품 회수 확인 즉시 신속한 교환 발송 또는 환불 처리를 완료해 드리겠습니다.`;
          break;

        case "DEFECT_DAMAGE":
          body = `배송 중 상품 파손/불량으로 인해 큰 불편을 드려 대단히 죄송합니다.\n` +
            `저희 스토어는 고객 감동을 최우선으로 하며, 파손 및 오배송 건에 대해 100% 무상 맞교환 및 재발송을 원칙으로 책임 처리해 드립니다.\n` +
            `불편하시겠지만 파손된 상품의 사진을 본 문의창이나 고객센터(${csPhone})로 남겨주시면, 반품 접수와 동시에 새 제품을 즉시 당일 특급 출고해 드리겠습니다.\n` +
            `이용에 불편을 드린 점 다시 한번 깊이 사과드립니다.`;
          break;

        case "PRODUCT_SPEC":
          body = `[${productName}] 상품에 관심을 가져주셔서 대단히 감사드립니다.\n` +
            `고객님께서 문의하신 상품 규격 및 상세 정보에 대해 담당 부서와 상품 정보DB를 즉시 교차 확인하고 있습니다.\n` +
            `정확하고 신뢰할 수 있는 안내를 위해 상세 내용을 검토한 뒤 1시간 이내에 본 문의창을 통해 상세히 안내해 드리겠습니다.\n` +
            `추가로 궁금하신 점은 언제든 편하게 남겨주시기 바랍니다.`;
          break;

        case "GENERAL":
        default:
          body = `저희 스토어를 찾아주셔서 감사드립니다.\n` +
            `남겨주신 소중한 문의 사항을 담당자가 꼼꼼히 확인하고 있습니다.\n` +
            `고객님의 궁금하신 점이 신속하고 명확하게 해소될 수 있도록 성심성의껏 확인 후 빠르게 답변 드리겠습니다.`;
          break;
      }
    }

    return `안녕하세요, ${customerName}님. ${storeName}입니다.\n\n` +
      `${body}\n\n` +
      `항상 건강하시고 행복한 하루 보내시길 바랍니다.\n` +
      `- ${storeName} 배상 (문의: ${csPhone})`;
  }

  /**
   * 텔레그램 / 슬랙 발송용 긴급 고객문의 경보 메시지
   * @param {Object} inquiry 문의 객체
   * @param {Object} slaStatus SLA 평가 결과
   * @returns {string}
   */
  formatUrgentInquiryAlert(inquiry = {}, slaStatus = {}) {
    inquiry = (inquiry && typeof inquiry === "object") ? inquiry : {};
    slaStatus = (slaStatus && typeof slaStatus === "object") ? slaStatus : {};
    const category = this.classifyInquiry(inquiry);
    const categoryName = {
      SHIPPING_STATUS: "📦 배송조회/일정",
      CANCEL_CHANGE: "🛑 주문취소/변경",
      RETURN_EXCHANGE: "🔄 반품/교환신청",
      PRODUCT_SPEC: "🏷️ 상품스펙/재고",
      DEFECT_DAMAGE: "💥 파손/오배송 (긴급)",
      GENERAL: "💬 일반문의"
    }[category] || "💬 일반문의";

    const inquiryId = inquiry.inquiryId || inquiry.id || "INQ-UNKNOWN";
    const customer = inquiry.customerName || "고객";
    const title = inquiry.title || (typeof inquiry.content === "string" ? inquiry.content.slice(0, 30) : "") || "문의 내용 없음";

    let headerBadge = "⚠️ [쿠팡 고객문의 18시간 경과 — SLA 마감 임박]";
    if (slaStatus.level === "EXPIRED") {
      headerBadge = "🚨 [쿠팡 고객문의 24시간 SLA 초과 — 페널티 긴급 방어 요망]";
    } else if (slaStatus.isAngryEscalation) {
      headerBadge = "🔥 [쿠팡 고객 긴급 항의 접수 — 악성리뷰 사전 차단 요망]";
    }

    return `${headerBadge}\n\n` +
      `• 문의 ID: ${inquiryId}\n` +
      `• 고객명: ${customer}\n` +
      `• 문의 분류: ${categoryName}\n` +
      `• 경과 시간: ${slaStatus.elapsedHours || 0}시간 경과 (잔여: ${slaStatus.remainingHours || 0}시간)\n` +
      `• 문의 내용: "${title}"\n\n` +
      `👉 쿠팡 WING 문의 관리 바로가기: https://wing.coupang.com/tenants/seller-web/voc/inquiry/list\n` +
      `💡 AutoFlow 셋업 마법사에서 1초 맞춤 안심 초동 답변을 즉시 복사하여 등록할 수 있습니다.`;
  }

  /**
   * 신규 수집된 고객 문의 목록 일괄 분석 및 영속화
   * @param {Array} rawInquiries 문의 배열
   * @returns {Array} 분석 완료된 문의 목록
   */
  recordInquiries(rawInquiries = []) {
    if (rawInquiries && !Array.isArray(rawInquiries) && Array.isArray(rawInquiries.inquiries)) {
      rawInquiries = rawInquiries.inquiries;
    }
    if (!Array.isArray(rawInquiries) || rawInquiries.length === 0) {
      return [];
    }

    let data = { inquiries: [], resolvedInquiries: [], lastAuditTime: Date.now() };
    try {
      if (fs.existsSync(this.storagePath)) {
        const parsed = JSON.parse(fs.readFileSync(this.storagePath, "utf8"));
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          data = parsed;
        }
      }
    } catch (_) {}
    data.inquiries = Array.isArray(data.inquiries) ? data.inquiries.filter(x => x && typeof x === "object") : [];
    data.resolvedInquiries = Array.isArray(data.resolvedInquiries) ? data.resolvedInquiries.filter(x => x && typeof x === "object") : [];

    const now = Date.now();
    const processed = [];

    for (const raw of rawInquiries) {
      if (!raw || typeof raw !== "object") continue;
      const inquiryId = raw.inquiryId || raw.id || `INQ-${now}-${Math.random().toString(36).substr(2, 5)}`;
      const category = this.classifyInquiry(raw);
      const slaStatus = this.evaluateSlaStatus(raw, now);
      const suggestedResponse = this.generateInitialResponse(raw, category);

      const inquiryObj = {
        inquiryId,
        orderId: raw.orderId || null,
        customerName: raw.customerName || "고객",
        title: raw.title || "",
        content: raw.content || "",
        category,
        status: raw.status || "PENDING", // PENDING | ANSWERED | RESOLVED
        createdAt: slaStatus.createdAt,
        slaStatus,
        suggestedResponse,
        lastUpdated: now
      };

      // 기존 목록에서 중복 여부 확인
      const existingIdx = data.inquiries.findIndex(i => i.inquiryId === inquiryId);
      if (existingIdx >= 0) {
        data.inquiries[existingIdx] = Object.assign({}, data.inquiries[existingIdx], inquiryObj);
      } else {
        data.inquiries.push(inquiryObj);
      }

      processed.push(inquiryObj);
    }

    data.lastAuditTime = now;
    try {
      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
    } catch (_) {}

    return processed;
  }

  /**
   * 답변 완료 및 해결 처리
   * @param {string} inquiryId 문의 ID
   * @param {string} resolution 해결 내용
   * @returns {boolean}
   */
  resolveInquiry(inquiryId, resolution = "ANSWERED") {
    if (inquiryId && typeof inquiryId === "object") {
      resolution = inquiryId.resolution || resolution;
      inquiryId = inquiryId.inquiryId || inquiryId.id || "";
    }
    if (!inquiryId) return false;
    resolution = resolution || "ANSWERED";
    let data = { inquiries: [], resolvedInquiries: [], lastAuditTime: Date.now() };
    try {
      if (fs.existsSync(this.storagePath)) {
        const parsed = JSON.parse(fs.readFileSync(this.storagePath, "utf8"));
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          data = parsed;
        }
      }
    } catch (_) {}
    data.inquiries = Array.isArray(data.inquiries) ? data.inquiries.filter(x => x && typeof x === "object") : [];
    data.resolvedInquiries = Array.isArray(data.resolvedInquiries) ? data.resolvedInquiries.filter(x => x && typeof x === "object") : [];

    const idx = data.inquiries.findIndex(i => i.inquiryId === inquiryId);
    if (idx >= 0) {
      const item = data.inquiries.splice(idx, 1)[0];
      item.status = "RESOLVED";
      item.resolvedAt = new Date().toISOString();
      item.resolution = resolution;
      data.resolvedInquiries.push(item);
      try {
        fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
        return true;
      } catch (_) {}
    }
    return false;
  }

  /**
   * 현재 문의 대기열 요약 통계
   * @returns {Object}
   */
  getInquirySummary() {
    let data = { inquiries: [], resolvedInquiries: [], lastAuditTime: Date.now() };
    try {
      if (fs.existsSync(this.storagePath)) {
        const parsed = JSON.parse(fs.readFileSync(this.storagePath, "utf8"));
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          data = parsed;
        }
      }
    } catch (_) {}
    data.inquiries = Array.isArray(data.inquiries) ? data.inquiries.filter(x => x && typeof x === "object") : [];
    data.resolvedInquiries = Array.isArray(data.resolvedInquiries) ? data.resolvedInquiries.filter(x => x && typeof x === "object") : [];

    const now = Date.now();
    let safeCount = 0;
    let attentionCount = 0;
    let urgentCount = 0;
    let expiredCount = 0;
    let angryCount = 0;

    const activeList = data.inquiries.map(item => {
      const sla = this.evaluateSlaStatus(item, now);
      if (sla.level === "EXPIRED") expiredCount++;
      else if (sla.level === "URGENT") urgentCount++;
      else if (sla.level === "ATTENTION") attentionCount++;
      else safeCount++;

      if (sla.isAngryEscalation) angryCount++;

      return Object.assign({}, item, { slaStatus: sla });
    });

    return {
      totalPending: activeList.length,
      safeCount,
      attentionCount,
      urgentCount,
      expiredCount,
      angryCount,
      totalResolved: data.resolvedInquiries.length,
      lastAuditTime: data.lastAuditTime,
      inquiries: activeList.slice(0, 50)
    };
  }
}

module.exports = {
  CustomerInquirySentinel,
  createCustomerInquirySentinel: (options = {}) => new CustomerInquirySentinel((options && typeof options === "object") ? options : {})
};
