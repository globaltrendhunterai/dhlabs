/**
 * AutoFlow Seizure Defense Sentinel (GATE_LEGAL_15 / Gate 50)
 * ------------------------------------------------------------------------------------------------------
 * 온라인 판매자가 채무 분쟁, 세금 체납, 거래처 미지급 등으로 인해 쿠팡 WING/스마트스토어 정산 계좌가
 * 가압류/본압류되어 발생하는 흑자도산(연쇄 부도 및 운영자금 동결)을 사전에 감별하고,
 * 「민사집행법」 제246조(압류금지채권) 제1항 제8호 및 동법 시행령 제7조,
 * 「국세징수법」 제41조(압류금지 재산)에 근거한 법정 최저생계비(월 185만 원)를 즉시 인출/회수할 수 있도록
 * 돕는 정산금 압류 방어 센티널.
 *
 * [주요 법률 규격 및 4대 판정 엔진]
 * 1. 법정 최저생계비 압류금지 상수:
 *    - EXEMPT_LIVING_COST_LIMIT = 1,850,000원 (민사집행법 시행령 제7조)
 * 2. 4대 판정 엔진 (auditSeizureStatus):
 *    - SEIZURE_SAFE: 정상 정산 계좌 (동결 위험 0건, 안전 가동, 100점, 방어액 0원)
 *    - SEIZURE_WARNING_PRE_NOTICE: 독촉/지급명령 접수 등 압류 전조 증상 감지 (계좌 분리 및 선제 예방 가이드, 85점, 방어액 0원)
 *    - SEIZURE_CRITICAL_ATTACHED: 쿠팡 정산금 가압류/압류 동결 발생 (185만 원 압류금지채권 범위변경 신청 즉시 권고, 법원 제출 공문서 자동 생성, 건당 1,850,000원 생계자금 방어, 20점)
 *    - SEIZURE_TAX_DELINQUENCY: 국세/지방세 체납 처분 압류 (국세징수법 제41조 생계비 압류금지 소명서 생성, 건당 1,850,000원 방어, 10점)
 * 3. 법정 압류 해제 가능액 계산:
 *    - Math.min(seizedAmount, 1850000) (최대 1,850,000원 방어액 산출)
 * 4. Pure White Clean Enterprise 라이트 모드 공식 법원 제출용 압류금지채권 범위변경 신청서 및 쿠팡 소명 공문서 HTML 생성기:
 *    - 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수, 붉은 직인 0건, 다크모드 영구 금지.
 *    - 「민사집행법」 제246조 제2항, 「국세징수법」 제41조 준용.
 * 5. 영속 원장 (logs/seizure_defense_audits.json) 및 종결 처리 지원
 */

"use strict";

const fs = require("fs");
const path = require("path");

const EXEMPT_LIVING_COST_LIMIT = 1850000;

class SeizureDefenseSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/seizure_defense_audits.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/seizure_defense_config.json");

    this.ensureDirectory(this.storagePath);
    this.ensureDirectory(this.configPath);
  }

  ensureDirectory(filePath) {
    if (!filePath || typeof filePath !== "string") return;
    try {
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    } catch (e) {
      // ignore
    }
  }

  getConfig() {
    const defaults = {
      enabled: true,
      storeName: "오토플로우 공식 스토어",
      platform: "쿠팡 WING",
      bankName: "기업은행",
      accountNumber: "110-098-765432",
      ownerName: "대표자",
      businessNumber: "123-45-67890",
      courtName: "서울중앙지방법원",
      exemptLivingCostLimit: EXEMPT_LIVING_COST_LIMIT
    };

    if (fs.existsSync(this.configPath)) {
      try {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          return Object.assign({}, defaults, parsed);
        }
      } catch (e) {
        return defaults;
      }
    }
    return defaults;
  }

  loadAudits() {
    if (!fs.existsSync(this.storagePath)) {
      return [];
    }
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw || "[]");
      if (Array.isArray(parsed)) {
        return parsed.filter(a => a && typeof a === "object" && a.auditId);
      }
      if (parsed && typeof parsed === "object" && parsed.auditId) {
        return [parsed];
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  saveAudits(audits) {
    if (!Array.isArray(audits)) {
      if (audits && typeof audits === "object" && audits.auditId) {
        return this.recordAudit(audits);
      }
      return false;
    }
    try {
      const cleanAudits = audits.filter(a => a && typeof a === "object" && a.auditId);
      fs.writeFileSync(this.storagePath, JSON.stringify(cleanAudits, null, 2), "utf8");
      return true;
    } catch (e) {
      return false;
    }
  }

  recordAudit(auditRecord) {
    if (!auditRecord || typeof auditRecord !== "object" || !auditRecord.auditId) {
      return false;
    }
    const audits = this.loadAudits();
    const existingIndex = audits.findIndex(a => a && a.auditId === auditRecord.auditId);
    if (existingIndex >= 0) {
      audits[existingIndex] = auditRecord;
    } else {
      audits.unshift(auditRecord);
    }
    if (audits.length > 1000) {
      audits.length = 1000;
    }
    return this.saveAudits(audits);
  }

  /**
   * 오픈마켓 정산금 압류/가압류 리스크 사전 감별 및 최저생계비 방어 연산
   * @param {Object} seizureData 
   * @param {Object} options 
   * @returns {Object} auditResult
   */
  auditSeizureStatus(seizureData = {}, options = {}) {
    const hasInput = Boolean(
      seizureData &&
      typeof seizureData === "object" &&
      !Array.isArray(seizureData) &&
      (seizureData.seizureType || seizureData.status || seizureData.type || seizureData.seizedAmount || seizureData.storeName || seizureData.creditorName || seizureData.caseNumber || seizureData.notes || seizureData.reason || seizureData.debtType || seizureData.platform || seizureData.bankName)
    );
    seizureData = (seizureData && typeof seizureData === "object" && !Array.isArray(seizureData)) ? seizureData : {};
    options = (options && typeof options === "object" && !Array.isArray(options)) ? options : {};

    const config = this.getConfig();
    const rawSeized = Math.max(0, Number(seizureData.seizedAmount || 0));
    const storeName = seizureData.storeName || config.storeName || "스토어";
    const platform = seizureData.platform || seizureData.settlementPlatform || config.platform || "쿠팡 WING";
    const bankName = seizureData.bankName || config.bankName || "주거래은행";
    const accountNumber = seizureData.accountNumber || config.accountNumber || "계좌번호 미지정";
    const creditorName = seizureData.creditorName || "채권자";
    const caseNumber = seizureData.caseNumber || "사건번호 미기재";
    const courtName = seizureData.courtName || config.courtName || "관할 지방법원";
    const taxOffice = seizureData.taxOffice || "관할 세무서";

    const typeCandidate = String(seizureData.seizureType || seizureData.status || seizureData.type || "").toUpperCase();
    const textContext = `${typeCandidate} ${seizureData.notes || ""} ${seizureData.reason || ""} ${seizureData.debtType || ""} ${creditorName} ${caseNumber}`;

    let verdict = "SEIZURE_SAFE";
    let score = 100;
    let riskLevel = "SAFE";
    let verdictTitle = "정상 정산 계좌 (동결 위험 0건)";
    let actionRecommendation = "정산 계좌가 정상 운영 중입니다. 주기적 매출 대사 및 정산 계좌 안전 모니터링을 지속하십시오.";
    let legalBasis = "민사집행법 제246조 및 민법 제681조 (정상 수임 및 정산 집행)";
    let defendedAmount = 0;

    // 4대 판정 분기: 1) 명시적 타입 지정 우선 처리
    if (typeCandidate === "SEIZURE_TAX_DELINQUENCY" || typeCandidate === "TAX_DELINQUENCY" || typeCandidate === "TAX") {
      verdict = "SEIZURE_TAX_DELINQUENCY";
    } else if (typeCandidate === "SEIZURE_CRITICAL_ATTACHED" || typeCandidate === "CRITICAL_ATTACHED" || typeCandidate === "ATTACHED") {
      verdict = "SEIZURE_CRITICAL_ATTACHED";
    } else if (typeCandidate === "SEIZURE_WARNING_PRE_NOTICE" || typeCandidate === "WARNING_PRE_NOTICE" || typeCandidate === "WARNING" || typeCandidate === "PRE_NOTICE") {
      verdict = "SEIZURE_WARNING_PRE_NOTICE";
    } else if (typeCandidate === "SEIZURE_SAFE" || typeCandidate === "SAFE" || typeCandidate === "NORMAL") {
      verdict = "SEIZURE_SAFE";
    } else {
      // 2) 텍스트 컨텍스트 기반 자동 감별
      if (/체납|국세|지방세|세무서|조세/i.test(textContext)) {
        verdict = "SEIZURE_TAX_DELINQUENCY";
      } else if (/가압류|본압류|채권압류|계좌동결|지급정지|강제집행/i.test(textContext) && !/본압류\s*전/i.test(textContext)) {
        verdict = "SEIZURE_CRITICAL_ATTACHED";
      } else if (/독촉|지급명령|내용증명|경고|소송접수|분쟁/i.test(textContext)) {
        verdict = "SEIZURE_WARNING_PRE_NOTICE";
      } else {
        verdict = "SEIZURE_SAFE";
      }
    }

    if (verdict === "SEIZURE_TAX_DELINQUENCY") {
      score = 10;
      riskLevel = "CRITICAL_TAX";
      verdictTitle = "국세/지방세 체납 처분 압류 발생";
      actionRecommendation = "과세관청(세무서/지자체)의 체납처분으로 정산 계좌가 압류되었습니다. 「국세징수법 제41조(압류금지 재산)」에 근거하여 3개월간 생계유지에 필요한 법정 최저생계비(185만 원) 압류 해제 신청서 및 소명서를 관할 세무서 징세계 및 쿠팡 정산팀에 즉시 제출하여 생계자금을 방어하십시오.";
      legalBasis = "국세징수법 제41조 제1항 제2호 및 동법 시행령 제31조 (생계유지 필요 압류금지 재산 185만 원)";
      defendedAmount = rawSeized > 0 ? Math.min(rawSeized, EXEMPT_LIVING_COST_LIMIT) : EXEMPT_LIVING_COST_LIMIT;
    } else if (verdict === "SEIZURE_CRITICAL_ATTACHED") {
      score = 20;
      riskLevel = "CRITICAL";
      verdictTitle = "쿠팡 정산금 가압류/본압류 동결 발생";
      actionRecommendation = "정산금 동결로 인한 흑자도산(운영자금 경색) 방어를 위해 관할 지방법원에 「민사집행법 제246조 제2항에 따른 압류금지채권 범위변경 신청서」를 즉시 제출하고, 쿠팡 정산팀에 법정 최저생계비(월 185만 원) 압류금지 채권 소명 공문을 즉각 접수하여 생계자금을 즉시 회수하십시오.";
      legalBasis = "민사집행법 제246조 제1항 제8호 및 동법 시행령 제7조 (월 185만 원 압류금지채권) & 동조 제2항 (범위변경 신청)";
      defendedAmount = rawSeized > 0 ? Math.min(rawSeized, EXEMPT_LIVING_COST_LIMIT) : EXEMPT_LIVING_COST_LIMIT;
    } else if (verdict === "SEIZURE_WARNING_PRE_NOTICE") {
      score = 85;
      riskLevel = "WARNING";
      verdictTitle = "압류 전조 증상 감지 (독촉/지급명령 접수)";
      actionRecommendation = "채권자로부터 독촉장 또는 지급명령이 도달한 상태입니다. 쿠팡/스마트스토어 정산 계좌 분리 지정, 분할 상환 협의, 또는 즉시이의신청(2주 이내)을 선제 진행하여 본압류를 원천 예방하십시오.";
      legalBasis = "민사소송법 제468조(이의신청) 및 민사집행법 제246조 사전 보호 대비";
      defendedAmount = 0;
    } else {
      score = 100;
      riskLevel = "SAFE";
      verdictTitle = "정상 정산 계좌 (동결 위험 0건)";
      actionRecommendation = "정산 계좌가 정상 운영 중입니다. 주기적 매출 대사 및 정산 계좌 안전 모니터링을 지속하십시오.";
      legalBasis = "민사집행법 제246조 및 민법 제681조 (정상 수임 및 정산 집행)";
      defendedAmount = 0;
    }

    const auditRecord = {
      auditId: "SZ-DEF-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7).toUpperCase(),
      timestamp: new Date().toISOString(),
      storeName,
      platform,
      bankName,
      accountNumber,
      creditorName,
      caseNumber,
      courtName,
      taxOffice,
      seizedAmount: rawSeized,
      exemptLimit: EXEMPT_LIVING_COST_LIMIT,
      defendedAmount: defendedAmount,
      preventedLoss: defendedAmount,
      defendedWon: defendedAmount,
      verdict,
      status: verdict,
      score,
      riskLevel,
      verdictTitle,
      actionRecommendation,
      legalBasis,
      resolved: false,
      statusLabel: verdict === "SEIZURE_SAFE" ? "RESOLVED" : "PENDING",
      notes: seizureData.notes || ""
    };

    if (options.record !== false && (hasInput || options.record === true)) {
      this.recordAudit(auditRecord);
    }

    return auditRecord;
  }

  /**
   * Pure White Clean Enterprise 라이트 모드 공식 압류금지채권 범위변경 신청서 및 소명서 HTML 생성기
   * 대한민국 공문서 표준 (인쇄 시 직인 생략) 준수, 붉은 직인 0건, 다크모드 영구 금지
   * 「민사집행법」 제246조 제2항, 「국세징수법」 제41조 준용
   * @param {Object} auditRecord 
   * @param {Object} customConfig 
   * @returns {string} html
   */
  generateSeizureDisputeEvidenceHtml(auditRecord = {}, customConfig = {}) {
    auditRecord = (auditRecord && typeof auditRecord === "object") ? auditRecord : {};
    customConfig = (customConfig && typeof customConfig === "object") ? customConfig : {};
    const config = Object.assign({}, this.getConfig(), customConfig);
    const currentDate = new Date().toISOString().slice(0, 10);
    const defended = Number(auditRecord.defendedAmount || auditRecord.preventedLoss || 0);
    const seized = Number(auditRecord.seizedAmount || 0);
    const remainingAttached = Math.max(0, seized - defended);

    let badgeText = "정상 안전 (압류 위험 0건)";
    let badgeClass = "badge-safe";
    if (auditRecord.verdict === "SEIZURE_WARNING_PRE_NOTICE") {
      badgeText = "주의 (압류 전조 증상 감지)";
      badgeClass = "badge-warning";
    } else if (auditRecord.verdict === "SEIZURE_CRITICAL_ATTACHED") {
      badgeText = "위험 (가압류/본압류 동결 발생)";
      badgeClass = "badge-danger";
    } else if (auditRecord.verdict === "SEIZURE_TAX_DELINQUENCY") {
      badgeText = "심각 (조세체납처분 압류 발생)";
      badgeClass = "badge-danger";
    }

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>압류금지채권 범위변경 신청서 및 오픈마켓 정산금 최저생계비 보호 소명서</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Malgun Gothic", "맑은 고딕", helvetica, sans-serif;
      background: #ffffff;
      color: #0f172a;
      line-height: 1.6;
      margin: 0;
      padding: 24px;
    }
    .page-container {
      max-width: 820px;
      margin: 0 auto;
      border: 1px solid #cbd5e1;
      padding: 32px;
      background: #ffffff;
    }
    .header-table { width: 100%; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
    .title { font-size: 20px; font-weight: 800; color: #0f172a; }
    .subtitle { font-size: 11px; color: #64748b; margin-top: 4px; }
    .doc-meta { font-size: 11px; color: #475569; text-align: right; }
    .section-title { font-size: 13px; font-weight: 800; color: #0f172a; margin: 18px 0 8px 0; border-left: 3px solid #2563eb; padding-left: 8px; }
    .info-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px; }
    .info-table th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 7px 10px; text-align: left; width: 24%; color: #334155; }
    .info-table td { border: 1px solid #cbd5e1; padding: 7px 10px; color: #0f172a; }
    .badge-safe { color: #16a34a; font-weight: 800; }
    .badge-warning { color: #d97706; font-weight: 800; }
    .badge-danger { color: #dc2626; font-weight: 800; }
    .summary-box { background: #f8fafc; border: 1px solid #cbd5e1; padding: 14px; border-radius: 4px; margin-bottom: 18px; font-size: 12px; }
    .law-cite { background: #f1f5f9; border-left: 3px solid #64748b; padding: 10px 14px; font-size: 11px; color: #334155; margin: 14px 0; line-height: 1.6; }
    .calc-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px; text-align: center; }
    .calc-table th { background: #f1f5f9; border: 1px solid #cbd5e1; padding: 8px 6px; color: #1e293b; font-weight: 700; }
    .calc-table td { border: 1px solid #cbd5e1; padding: 8px 6px; color: #0f172a; }
    .highlight-won { color: #dc2626; font-weight: 800; font-size: 13px; }
    .shield-won { color: #16a34a; font-weight: 800; font-size: 13px; }
    .sign-table { width: 100%; border-collapse: collapse; margin-top: 24px; font-size: 11px; }
    .sign-table td { border: 1px solid #cbd5e1; padding: 12px; width: 50%; vertical-align: top; }
    .official-sign { margin-top: 28px; text-align: center; border-top: 1px solid #cbd5e1; padding-top: 18px; font-size: 11px; color: #475569; }
    .no-print-btn { text-align: center; margin-bottom: 16px; }
    @media print {
      .no-print-btn { display: none; }
      body { padding: 0; }
      .page-container { border: none; padding: 0; }
    }
  </style>
</head>
<body>
  <div class="no-print-btn">
    <button onclick="window.print()" style="padding: 8px 18px; background: #0f172a; color: #ffffff; border: none; border-radius: 4px; font-size: 12px; font-weight: 700; cursor: pointer;">🖨️ 법원 제출용 신청서 인쇄 / PDF 저장</button>
  </div>

  <div class="page-container">
    <table class="header-table">
      <tr>
        <td>
          <div class="title">압류금지채권 범위변경 신청서 및 최저생계비 보호 소명서</div>
          <div class="subtitle">「민사집행법」 제246조 제1항 제8호·제2항 및 「국세징수법」 제41조 준용</div>
        </td>
        <td class="doc-meta">
          사건(문서)번호: ${auditRecord.auditId || "SZ-DEF-LEGAL"}<br>
          신청일자: ${currentDate}<br>
          제출기관: ${auditRecord.courtName || config.courtName} / ${auditRecord.platform || config.platform} 정산팀
        </td>
      </tr>
    </table>

    <div class="summary-box">
      <strong>[정산금 압류 방어 종합 진단]</strong>: 
      <span class="${badgeClass}">${badgeText}</span> | 법무 안전점수: <strong>${auditRecord.score || 100}점</strong>
      <br>
      <strong>법정 최저생계비 방어액</strong>: <span class="shield-won">₩${defended.toLocaleString()}원</span> (법원 범위변경 신청 즉시 인출 청구 대상)
      <br>
      <strong>조치 권고사항</strong>: ${auditRecord.actionRecommendation || "정상 가동"}
    </div>

    <div class="section-title">1. 신청인(채무자) 및 오픈마켓 정산 계좌 기본 정보</div>
    <table class="info-table">
      <tr>
        <th>스토어 상호명</th>
        <td>${auditRecord.storeName || config.storeName}</td>
        <th>대표자 성명</th>
        <td>${config.ownerName || "대표자"}</td>
      </tr>
      <tr>
        <th>사업자등록번호</th>
        <td>${config.businessNumber || "123-45-67890"}</td>
        <th>정산 대상 플랫폼</th>
        <td><strong>${auditRecord.platform || config.platform}</strong></td>
      </tr>
      <tr>
        <th>지정 거래은행</th>
        <td>${auditRecord.bankName || config.bankName}</td>
        <th>압류/동결 정산계좌</th>
        <td><strong>${auditRecord.accountNumber || config.accountNumber}</strong></td>
      </tr>
    </table>

    <div class="section-title">2. 채권 압류 및 강제집행 처분 내역</div>
    <table class="info-table">
      <tr>
        <th>집행 사건번호</th>
        <td><strong>${auditRecord.caseNumber || "사건번호 미기재"}</strong></td>
        <th>압류 채권자</th>
        <td>${auditRecord.creditorName || "채권자"}</td>
      </tr>
      <tr>
        <th>관할 법원 / 과세관청</th>
        <td>${auditRecord.courtName || auditRecord.taxOffice || "관할 기관"}</td>
        <th>동결된 정산금 총액</th>
        <td><span class="highlight-won">₩${seized.toLocaleString()}원</span></td>
      </tr>
    </table>

    <div class="section-title">3. 민사집행법 제246조 법정 최저생계비(185만 원) 압류 해제 산출표</div>
    <table class="calc-table">
      <thead>
        <tr>
          <th>구분</th>
          <th>동결 정산금액</th>
          <th>법정 압류금지 한도 (월)</th>
          <th>즉시 인출/해제 청구액</th>
          <th>잔여 집행 가능액</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>오픈마켓 정산 채권</strong></td>
          <td>₩${seized.toLocaleString()}원</td>
          <td>₩${EXEMPT_LIVING_COST_LIMIT.toLocaleString()}원</td>
          <td><span class="shield-won">₩${defended.toLocaleString()}원</span></td>
          <td>₩${remainingAttached.toLocaleString()}원</td>
        </tr>
      </tbody>
    </table>

    <div class="law-cite">
      <strong>[핵심 법령상 근거 및 보호 조항]</strong><br>
      • <strong>민사집행법 제246조(압류금지채권) 제1항 제8호 및 동법 시행령 제7조</strong>: 채무자의 1월간 생계유지에 필요한 <strong>185만 원</strong> 이하의 예금채권 등은 압류하지 못합니다.<br>
      • <strong>민사집행법 제246조 제2항</strong>: 법원은 당사자가 신청하면 채권자와 채무자의 생활형편, 그 밖의 사정을 고려하여 압류명령의 전부 또는 일부를 취소하거나 압류명령을 변경할 수 있습니다.<br>
      • <strong>국세징수법 제41조(압류금지 재산)</strong>: 체납자 및 그와 생계를 같이하는 가족의 3개월간 생계유지에 필요한 소액금융재산(185만 원)은 체납처분 압류가 원천 금지됩니다.
    </div>

    <div class="section-title">4. 신청 취지 및 생계비 보호 필요성 소명</div>
    <div style="font-size: 11px; color: #334155; line-height: 1.7; background: #ffffff; border: 1px solid #cbd5e1; padding: 12px; margin-bottom: 16px;">
      1. 신청인은 온라인 오픈마켓(${auditRecord.platform || config.platform})을 운영하는 소상공인으로서, 금번 채권 압류 및 계좌 동결로 인하여 기초 생계유지비용은 물론 정상적인 판매 정산금 인출이 전면 차단되었습니다.<br>
      2. 「민사집행법」 제246조 제1항 제8호 및 동법 시행령 제7조에 의거, 월 185만 원은 국민기초생활보장법상 최저생계비를 고려한 법정 압류금지 채권에 해당합니다.<br>
      3. 이에 신청인은 동법 제246조 제2항에 따라 상기 동결 정산금 중 <strong>법정 최저생계비 금 1,850,000원(₩${defended.toLocaleString()}원)</strong>에 대하여 압류금지채권의 범위변경을 신청하오니, 조속히 압류 해제 및 지급 인출을 허가하여 주시기 바랍니다.
    </div>

    <div class="section-title">5. 첨부 서류</div>
    <div style="font-size: 11px; color: #475569; margin-bottom: 16px;">
      1. 오픈마켓 정산내역서 및 계좌 동결 사실확인원 1부<br>
      2. 압류 계좌 예금거래실적증명서(최근 1개월 입출금 내역) 1부<br>
      3. 사업자등록증 사본 1부
    </div>

    <div class="section-title">6. 법원 제출 및 오픈마켓 정산팀 소명 접수부</div>
    <table class="sign-table">
      <tr>
        <td>
          <strong>[신청인(채무자)]</strong><br><br>
          스토어 상호: ${auditRecord.storeName || config.storeName}<br>
          신청인 성명: ${config.ownerName || "대표자"} (인쇄 시 직인 생략)<br>
          신청 일자: ${currentDate}
        </td>
        <td>
          <strong>[접수 및 확인 기관]</strong><br><br>
          귀중: <strong>${auditRecord.courtName || config.courtName} 민사집행과</strong><br>
          참조: <strong>${auditRecord.platform || config.platform} 정산보호팀</strong><br>
          접수 일자: ${currentDate}
        </td>
      </tr>
    </table>

    <div class="official-sign">
      본 문서는 AutoFlow 법무 리스크 센티널(GATE_LEGAL_15)에 의해 생성된 공식 압류금지채권 소명서입니다.<br>
      대한민국 공문서 표준에 의거하여 <strong>(인쇄 시 직인 생략)</strong> 처리되었습니다.
    </div>
  </div>
</body>
</html>`;
  }

  getSummary() {
    const audits = this.loadAudits();
    const totalAudits = audits.length;
    let safeCount = 0;
    let warningCount = 0;
    let criticalCount = 0;
    let taxDelinquencyCount = 0;
    let defendedCount = 0;
    let totalPreventedLossWon = 0;
    let resolvedCount = 0;
    let pendingCount = 0;

    for (const a of audits) {
      if (!a || typeof a !== "object") continue;
      if (a.verdict === "SEIZURE_SAFE") {
        safeCount++;
      } else if (a.verdict === "SEIZURE_WARNING_PRE_NOTICE") {
        warningCount++;
      } else if (a.verdict === "SEIZURE_CRITICAL_ATTACHED") {
        criticalCount++;
        defendedCount++;
      } else if (a.verdict === "SEIZURE_TAX_DELINQUENCY") {
        taxDelinquencyCount++;
        defendedCount++;
      }

      const loss = Number(a.defendedAmount || a.preventedLoss || a.defendedWon || 0);
      totalPreventedLossWon += loss;

      if (a.resolved || a.statusLabel === "RESOLVED") {
        resolvedCount++;
      } else {
        pendingCount++;
      }
    }

    return {
      totalAudits,
      safeCount,
      warningCount,
      criticalCount,
      taxDelinquencyCount,
      defendedCount,
      criticalDefended: defendedCount,
      totalPreventedLossWon,
      preventedLossSum: totalPreventedLossWon,
      preventedLossWon: totalPreventedLossWon,
      resolvedCount,
      pendingCount,
      recentAudits: audits.slice(0, 50),
      latestAudits: audits.slice(0, 50)
    };
  }

  resolveSeizureIssue(auditId, resolution = "DEFENDED_CONFIRMED", note = "") {
    if (auditId && typeof auditId === "object") {
      resolution = auditId.resolution || resolution || "DEFENDED_CONFIRMED";
      note = auditId.note || note || "";
      auditId = auditId.auditId || "";
    }
    resolution = (typeof resolution === "string" && resolution) ? resolution : "DEFENDED_CONFIRMED";
    const audits = this.loadAudits();
    const target = audits.find(a => a && a.auditId === auditId);
    if (!target) {
      return { success: false, message: `압류 방어 감사 ID [${auditId || ""}]를 찾을 수 없습니다.` };
    }

    target.resolved = true;
    target.statusLabel = "RESOLVED";
    target.resolution = resolution;
    target.resolvedAt = new Date().toISOString();
    target.notes = String(note || "압류금지채권 범위변경 신청 또는 세무서 소명서 접수 및 최저생계비 인출 조치 완료.");

    this.saveAudits(audits);
    return { success: true, audit: target };
  }
}

const createSeizureDefenseSentinel = (options = {}) => new SeizureDefenseSentinel(options);
SeizureDefenseSentinel.createSeizureDefenseSentinel = createSeizureDefenseSentinel;

module.exports = SeizureDefenseSentinel;
module.exports.SeizureDefenseSentinel = SeizureDefenseSentinel;
module.exports.createSeizureDefenseSentinel = createSeizureDefenseSentinel;
module.exports.EXEMPT_LIVING_COST_LIMIT = EXEMPT_LIVING_COST_LIMIT;
