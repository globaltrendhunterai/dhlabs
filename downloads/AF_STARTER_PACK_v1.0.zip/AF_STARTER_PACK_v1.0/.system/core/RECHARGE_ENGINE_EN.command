#!/bin/bash
# AutoFlow Engine - Interactive License Recharge Launcher (macOS Global Edition)
xattr -dr com.apple.quarantine "$(cd "$(dirname "$0")" && pwd)" 2>/dev/null || true
cd "$(dirname "$0")"
chmod +x ./bin/node ../bin/node 2>/dev/null || true

# Resolve node executable (./bin/node -> ../bin/node -> /opt/homebrew/bin/node -> /usr/local/bin/node -> command -v node)
NODE_BIN=""
for candidate in "./bin/node" "../bin/node" "/opt/homebrew/bin/node" "/usr/local/bin/node"; do
  if [ -x "$candidate" ] && "$candidate" -v >/dev/null 2>&1; then
    NODE_BIN="$candidate"
    break
  fi
done
if [ -z "$NODE_BIN" ] && command -v node >/dev/null 2>&1; then
  CANDIDATE_CMD="$(command -v node)"
  if "$CANDIDATE_CMD" -v >/dev/null 2>&1; then
    NODE_BIN="$CANDIDATE_CMD"
  fi
fi

if [ -z "$NODE_BIN" ]; then
  echo "❌ Node.js runtime not detected. Please install Node.js from https://nodejs.org"
  if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
    read -p "Press [Enter] to exit..."
  fi
  exit 1
fi

SCRIPT_FILE="recharge_cli.js"
if [ ! -f "$SCRIPT_FILE" ] && [ -f "./core/recharge_cli.js" ]; then
  SCRIPT_FILE="./core/recharge_cli.js"
fi

if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  clear 2>/dev/null || true
fi
echo "============================================================"
echo "⚡ AutoFlow Enterprise Engine License & Top-Up Console"
echo "============================================================"
echo ""
"$NODE_BIN" "$SCRIPT_FILE" status --lang=en
echo ""
echo "Select an operation:"
echo " [1] Apply 1-Month (30 Days) Top-Up Pack  ($49)"
echo " [2] Apply 3-Month (90 Days) Top-Up Pack  ($129 - 12% OFF)"
echo " [3] Apply 1-Year (365 Days) Top-Up Pack ($399 - 32% OFF)"
echo " [4] Enter Custom Days"
echo " [5] Bind License Key / Token"
echo " [6] Refresh Status"
echo " [q] Quit"
echo ""
choice="1"
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "Your choice (1-6, q): " choice
fi

case "$choice" in
  1)
    "$NODE_BIN" "$SCRIPT_FILE" 30 "TOPUP_30DAYS_$(date +%s)" "1-Month Top-Up" --lang=en
    ;;
  2)
    "$NODE_BIN" "$SCRIPT_FILE" 90 "TOPUP_90DAYS_$(date +%s)" "3-Month Top-Up" --lang=en
    ;;
  3)
    "$NODE_BIN" "$SCRIPT_FILE" 365 "TOPUP_365DAYS_$(date +%s)" "1-Year Top-Up" --lang=en
    ;;
  4)
    read -p "Enter number of days to add (e.g. 15): " custom_days
    "$NODE_BIN" "$SCRIPT_FILE" "$custom_days" "TOPUP_CUSTOM_$(date +%s)" "Custom Top-Up" --lang=en
    ;;
  5)
    read -p "Enter your License Key or Voucher Token: " token_val
    "$NODE_BIN" "$SCRIPT_FILE" bind "$token_val" --lang=en
    ;;
  6)
    clear 2>/dev/null || true
    "$NODE_BIN" "$SCRIPT_FILE" status --lang=en
    ;;
  q|Q)
    echo "Exiting."
    exit 0
    ;;
  *)
    echo "Invalid option."
    ;;
esac

echo ""
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "Press [Enter] to close this window..."
fi
