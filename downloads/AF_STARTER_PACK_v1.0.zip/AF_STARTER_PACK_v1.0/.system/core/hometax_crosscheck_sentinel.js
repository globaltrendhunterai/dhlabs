/**
 * AutoFlow HomeTax Cross-Check Sentinel (Gate 40: GATE_LEGAL_10)
 * 
 * [법무 및 세무 컴플라이언스]
 * 1. 「부가가치세법」 제32조(세금계산서 등), 제54조(매입처별 세금계산서합계표의 제출)
 * 2. 「부가가치세법」 제60조 제7항(매입처별 세금계산서합계표 불성실 가산세 0.5%)
 * 3. 「조세범 처벌법」 제15조(현금영수증 미발급 가산세 20%) 및 「소득세법」 제162조의3
 * 4. 쿠팡 WING 수수료 매입세액(10%) 공제 누락 방어 및 국세청 24자리 전자세금계산서 승인번호 1원 정밀 크로스체크
 * 5. Pure White Clean Enterprise 라이트 모드 및 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건)
 */

"use strict";

const fs = require("fs");
const path = require("path");

class HomeTaxCrossCheckSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/hometax_crosscheck_audit.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/hometax_crosscheck_config.json");

    this.ensureDirectory(this.storagePath);
    this.ensureDirectory(this.configPath);
  }

  ensureDirectory(filePath) {
    try {
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    } catch (e) {
      // ignore
    }
  }

  _loadAudits() {
    try {
      if (fs.existsSync(this.storagePath)) {
        const raw = fs.readFileSync(this.storagePath, "utf8");
        const parsed = JSON.parse(raw || "[]");
        return Array.isArray(parsed)
          ? parsed.filter(x => x && typeof x === "object")
          : (parsed && Array.isArray(parsed.audits) ? parsed.audits.filter(x => x && typeof x === "object") : []);
      }
    } catch (e) {
      // ignore
    }
    return [];
  }

  loadAudits() {
    return this._loadAudits();
  }

  _saveAudits(audits) {
    try {
      if (!Array.isArray(audits)) return false;
      const clean = audits.filter(x => x && typeof x === "object");
      this.ensureDirectory(this.storagePath);
      fs.writeFileSync(this.storagePath, JSON.stringify(clean, null, 2), "utf8");
      return true;
    } catch (e) {
      return false;
    }
  }

  saveAudits(audits) {
    return this._saveAudits(audits);
  }

  getConfig() {
    const defaults = {
      enabled: true,
      storeName: "오토플로우 공식 스토어",
      sellerName: "대표자",
      bizRegNumber: "123-45-67890",
      coupangBizRegNumber: "120-88-00767", // 쿠팡(주) 공식 사업자등록번호
      cashReceiptMandatoryThreshold: 100000, // 10만원 이상 의무발급 기준
      cashReceiptPenaltyRate: 0.20, // 조세범 처벌법 제15조 20% 가산세
      taxInvoiceOmissionPenaltyRate: 0.005, // 부가세법 제60조 0.5% 가산세
      vatRate: 0.10 // 부가가치세 10%
    };

    if (fs.existsSync(this.configPath)) {
      try {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          return Object.assign({}, defaults, parsed);
        }
      } catch (e) {
        return defaults;
      }
    }
    return defaults;
  }

  saveConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object") ? newConfig : {};
    const current = this.getConfig();
    const merged = Object.assign({}, current, newConfig);
    try {
      this.ensureDirectory(this.configPath);
      fs.writeFileSync(this.configPath, JSON.stringify(merged, null, 2), "utf8");
    } catch (_) {}
    return merged;
  }

  /**
   * 국세청 24자리 전자세금계산서 승인번호 유효성 검증
   * 규격: YYYYMMDD-XXXXXXXX-XXXXXXXX (8자리-8자리-8자리 = 총 24자리 숫자 + 2 하이픈)
   * @param {string} invoiceNo
   * @returns {boolean}
   */
  isValidTaxInvoiceNumber(invoiceNo) {
    if (!invoiceNo || typeof invoiceNo !== "string") return false;
    const clean = invoiceNo.trim();
    const regex = /^[0-9]{8}-[0-9]{8}-[0-9]{8}$/;
    return regex.test(clean);
  }

  /**
   * 대한민국 사업자등록번호 유효성 검증 (3자리-2자리-5자리)
   * @param {string} bizNo
   * @returns {boolean}
   */
  isValidBizRegNumber(bizNo) {
    if (!bizNo || typeof bizNo !== "string") return false;
    const clean = bizNo.trim();
    const regex = /^[0-9]{3}-[0-9]{2}-[0-9]{5}$/;
    return regex.test(clean);
  }

  /**
   * 쿠팡 WING 수수료/매출 데이터 vs 국세청 홈택스 전자세금계산서 1초 크로스체크
   * @param {Object} wingData WING 정산/수수료 요약
   * @param {Array} hometaxInvoices 홈택스 매입 세금계산서 배열
   * @param {Array} cashOrders 현금결제(무통장/계좌이체) 주문 배열
   * @param {Object} customOptions
   * @returns {Object} 대사 결과
   */
  reconcileHomeTaxRecords(wingData = {}, hometaxInvoices = [], cashOrders = [], customOptions = {}) {
    wingData = (wingData && typeof wingData === "object") ? wingData : {};
    if (!Array.isArray(hometaxInvoices) && Array.isArray(wingData.hometaxInvoices)) {
      hometaxInvoices = wingData.hometaxInvoices;
    }
    if (!Array.isArray(cashOrders) && Array.isArray(wingData.cashOrders)) {
      cashOrders = wingData.cashOrders;
    }
    hometaxInvoices = Array.isArray(hometaxInvoices) ? hometaxInvoices : [];
    cashOrders = Array.isArray(cashOrders) ? cashOrders : [];
    customOptions = (customOptions && typeof customOptions === "object") ? customOptions : {};

    const config = Object.assign({}, this.getConfig(), customOptions);

    const settlementMonth = wingData.settlementMonth || new Date().toISOString().slice(0, 7);
    const wingFeeSupply = Math.max(0, parseInt(wingData.feeSupplyAmount || 0, 10) || 0);
    const wingFeeVat = Math.max(0, parseInt(wingData.feeVatAmount || Math.round(wingFeeSupply * config.vatRate), 10) || 0);
    const wingFeeTotal = wingFeeSupply + wingFeeVat;

    // 1. 홈택스 매입 세금계산서 분석
    let hometaxFeeSupply = 0;
    let hometaxFeeVat = 0;
    const matchedInvoices = [];
    const invalidInvoices = [];

    hometaxInvoices.forEach((inv, idx) => {
      if (!inv || typeof inv !== "object") return;
      const invNo = String(inv.invoiceNumber || "").trim();
      const isValidFormat = this.isValidTaxInvoiceNumber(invNo);
      const supplierBizNo = String(inv.supplierBizNo || "").trim();
      const supplyAmt = Math.max(0, parseInt(inv.supplyAmount || 0, 10) || 0);
      const vatAmt = Math.max(0, parseInt(inv.vatAmount || 0, 10) || 0);

      const isCoupang = supplierBizNo === config.coupangBizRegNumber || String(inv.supplierName || "").includes("쿠팡");

      const item = {
        id: inv.id || `HT-INV-${idx + 1}`,
        invoiceNumber: invNo,
        isValidFormat,
        supplierName: inv.supplierName || (isCoupang ? "쿠팡(주)" : "기타공급자"),
        supplierBizNo,
        isCoupang,
        supplyAmount: supplyAmt,
        vatAmount: vatAmt,
        totalAmount: supplyAmt + vatAmt,
        issueDate: inv.issueDate || settlementMonth + "-10"
      };

      if (!isValidFormat) {
        invalidInvoices.push(item);
      } else {
        matchedInvoices.push(item);
        if (isCoupang) {
          hometaxFeeSupply += supplyAmt;
          hometaxFeeVat += vatAmt;
        }
      }
    });

    const hometaxFeeTotal = hometaxFeeSupply + hometaxFeeVat;

    // 2. 수수료 매입세금계산서 대사
    const supplyDiff = wingFeeSupply - hometaxFeeSupply;
    const vatDiff = wingFeeVat - hometaxFeeVat;
    const isFeeMatched = (supplyDiff === 0 && vatDiff === 0 && wingFeeSupply > 0);

    let feeStatus = "PERFECT_MATCH";
    let feeRiskLevel = "SAFE";
    let feeStatusText = "쿠팡 WING 수수료와 홈택스 전자세금계산서 1원 단위 100% 일치";

    if (wingFeeSupply > 0 && hometaxFeeSupply === 0) {
      feeStatus = "MISSING_IN_HOMETAX";
      feeRiskLevel = "CRITICAL";
      feeStatusText = "홈택스 매입세금계산서 미발행/미조회 (매입세액 공제 누락 위기)";
    } else if (supplyDiff !== 0 || vatDiff !== 0) {
      feeStatus = "AMOUNT_MISMATCH";
      feeRiskLevel = "URGENT";
      feeStatusText = `수수료 공급가액 ${Math.abs(supplyDiff).toLocaleString()}원 불일치 (가산세 리스크)`;
    }

    // 매입세액 누락 방어액 (미발행/누락 시 손실될 뻔한 세액)
    const protectedVatDeduction = isFeeMatched ? wingFeeVat : (hometaxFeeVat > 0 ? hometaxFeeVat : 0);
    // 불성실 가산세 리스크 (공급가액 차액의 0.5%)
    const potentialOmissionPenalty = Math.round(Math.abs(supplyDiff) * config.taxInvoiceOmissionPenaltyRate);

    // 3. 현금영수증 의무발행 점검
    const cashReceiptIssues = [];
    let unissuedCashTotal = 0;
    let potentialCashReceiptPenalty = 0;

    cashOrders.forEach((order, idx) => {
      if (!order || typeof order !== "object") return;
      const orderAmt = Math.max(0, parseInt(order.orderAmount || 0, 10) || 0);
      const hasReceipt = Boolean(order.cashReceiptIssued);
      const isMandatory = orderAmt >= config.cashReceiptMandatoryThreshold;

      if (!hasReceipt) {
        unissuedCashTotal += orderAmt;
        const penalty = Math.round(orderAmt * config.cashReceiptPenaltyRate);
        potentialCashReceiptPenalty += penalty;

        cashReceiptIssues.push({
          id: order.orderId || `CASH-ORD-${idx + 1}`,
          customerName: order.customerName || "미확인구매자",
          orderAmount: orderAmt,
          isMandatory,
          penaltyRisk: penalty,
          orderDate: order.orderDate || new Date().toISOString().slice(0, 10),
          recommendedAction: "국세청 자진발급(010-000-1234) 즉시 발행 요망"
        });
      }
    });

    const isCashReceiptSafe = cashReceiptIssues.length === 0;

    // 종합 상태 판정
    let overallStatus = "CLEAN_COMPLIANT";
    if (feeRiskLevel === "CRITICAL" || cashReceiptIssues.length > 0) {
      overallStatus = "TAX_RISK_DETECTED";
    } else if (feeRiskLevel === "URGENT") {
      overallStatus = "DISCREPANCY_WARNING";
    }

    return {
      auditId: `HT-AUDIT-${Date.now()}`,
      timestamp: new Date().toISOString(),
      settlementMonth,
      storeName: config.storeName,
      sellerName: config.sellerName,
      bizRegNumber: config.bizRegNumber,
      coupangBizRegNumber: config.coupangBizRegNumber,
      overallStatus,
      feeReconciliation: {
        status: feeStatus,
        riskLevel: feeRiskLevel,
        statusText: feeStatusText,
        isMatched: isFeeMatched,
        wingFeeSupply,
        wingFeeVat,
        wingFeeTotal,
        hometaxFeeSupply,
        hometaxFeeVat,
        hometaxFeeTotal,
        supplyDiff,
        vatDiff,
        protectedVatDeduction,
        potentialOmissionPenalty
      },
      cashReceiptAudit: {
        isSafe: isCashReceiptSafe,
        unissuedCount: cashReceiptIssues.length,
        unissuedCashTotal,
        potentialPenalty: potentialCashReceiptPenalty,
        issues: cashReceiptIssues
      },
      hometaxInvoices: {
        totalCount: hometaxInvoices.length,
        matchedCount: matchedInvoices.length,
        invalidCount: invalidInvoices.length,
        matchedInvoices,
        invalidInvoices
      }
    };
  }

  /**
   * 세무 대리인(세무사) 제출용 1초 다이제스트 텍스트 포맷터
   * @param {Object} reconData 대사 결과
   * @returns {string} 텍스트
   */
  formatTaxAccountantDigest(reconData = {}) {
    reconData = (reconData && typeof reconData === "object") ? reconData : {};
    const fee = (reconData.feeReconciliation && typeof reconData.feeReconciliation === "object") ? reconData.feeReconciliation : {};
    const cash = (reconData.cashReceiptAudit && typeof reconData.cashReceiptAudit === "object") ? reconData.cashReceiptAudit : {};
    const month = reconData.settlementMonth || new Date().toISOString().slice(0, 7);
    const supplyDiff = Number(fee.supplyDiff || 0);
    const unissuedCount = Number(cash.unissuedCount || 0);

    return `[AutoFlow 홈택스 매입매출 크로스체크 세무 보고서]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
■ 신고 대상월: ${month}
■ 상호(대표): ${reconData.storeName || "스토어"} (${reconData.sellerName || "대표자"})
■ 사업자번호: ${reconData.bizRegNumber || "123-45-67890"}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[1. 쿠팡 판매수수료 매입세금계산서 대사]
- WING 정산 수수료 공급가액: ${Number(fee.wingFeeSupply || 0).toLocaleString()}원 (부가세: ${Number(fee.wingFeeVat || 0).toLocaleString()}원)
- 홈택스 매입 세금계산서액: ${Number(fee.hometaxFeeSupply || 0).toLocaleString()}원 (부가세: ${Number(fee.hometaxFeeVat || 0).toLocaleString()}원)
- 대사 판정: ${fee.statusText || "확인 요망"}
- 매입세액 공제 가능액: ${Number(fee.protectedVatDeduction || 0).toLocaleString()}원
${supplyDiff !== 0 ? `⚠️ 불일치 차액: 공급가액 ${supplyDiff.toLocaleString()}원 (확인 필요)` : "✅ 1원 오차 없이 100% 일치"}

[2. 현금영수증 발행 점검 (조세범처벌법 제15조)]
- 현금 결제 미발행 건수: ${unissuedCount}건
- 미발행 총액: ${Number(cash.unissuedCashTotal || 0).toLocaleString()}원
${unissuedCount > 0 ? `⚠️ 20% 가산세 위험 노출액: ${Number(cash.potentialPenalty || 0).toLocaleString()}원 (국세청 자진발급 요망)` : "✅ 현금영수증 미발행 0건 (가산세 위험 없음)"}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
※ 본 자료는 국세청 승인번호 및 WING 정산 원장 대사 완료 데이터입니다. (인쇄 시 직인 생략)`;
  }

  /**
   * 텔레그램/슬랙 긴급 경보 메시지 포맷터
   * @param {Object} reconData 대사 결과
   * @returns {string} 마크다운 메시지
   */
  formatHomeTaxAlertBlock(reconData = {}) {
    reconData = (reconData && typeof reconData === "object") ? reconData : {};
    const fee = (reconData.feeReconciliation && typeof reconData.feeReconciliation === "object") ? reconData.feeReconciliation : {};
    const cash = (reconData.cashReceiptAudit && typeof reconData.cashReceiptAudit === "object") ? reconData.cashReceiptAudit : {};
    const month = reconData.settlementMonth || new Date().toISOString().slice(0, 7);

    const isRisk = Boolean(reconData.overallStatus && reconData.overallStatus !== "CLEAN_COMPLIANT");
    const badge = isRisk ? "🚨 [세무 가산세 위험 감지 - 즉시 조치 요망]" : "✅ [홈택스 세무 대사 정상]";

    return `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${badge}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
■ 정산 대상월: ${month}
■ 쿠팡 수수료 대사: ${fee.statusText || "정상 확인"}
■ 매입세액 공제액: ₩${Number(fee.protectedVatDeduction || 0).toLocaleString()}원
■ 현금영수증 미발행: ${Number(cash.unissuedCount || 0)}건 (가산세 위험: ₩${Number(cash.potentialPenalty || 0).toLocaleString()}원)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
※ 세무 신고 전 오토플로우 대사 보고서를 확인하십시오.`;
  }

  /**
   * Pure White Clean Enterprise 라이트 모드 국세청 공식 소명 감사보고서 HTML 렌더링
   * 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건)
   * @param {Object} reconData 대사 결과
   * @returns {string} HTML
   */
  generateHomeTaxAuditReportHtml(reconData = {}) {
    reconData = (reconData && typeof reconData === "object") ? reconData : {};
    const fee = (reconData.feeReconciliation && typeof reconData.feeReconciliation === "object") ? reconData.feeReconciliation : {};
    const cash = (reconData.cashReceiptAudit && typeof reconData.cashReceiptAudit === "object") ? reconData.cashReceiptAudit : {};
    const inv = (reconData.hometaxInvoices && typeof reconData.hometaxInvoices === "object") ? reconData.hometaxInvoices : {};
    const month = reconData.settlementMonth || new Date().toISOString().slice(0, 7);
    const currentDate = new Date().toISOString().slice(0, 10);
    const supplyDiff = Number(fee.supplyDiff || 0);
    const vatDiff = Number(fee.vatDiff || 0);

    const invoiceRowsHtml = (Array.isArray(inv.matchedInvoices) ? inv.matchedInvoices.filter(m => m && typeof m === "object") : []).map((m, i) => `
      <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
        <td style="padding: 8px 10px; text-align: center; color: #64748b;">${i + 1}</td>
        <td style="padding: 8px 10px; font-family: monospace; font-weight: 600; color: #0f172a;">${m.invoiceNumber || "-"}</td>
        <td style="padding: 8px 10px; color: #1e293b;">${m.supplierName || "-"} (${m.supplierBizNo || "-"})</td>
        <td style="padding: 8px 10px; text-align: right; font-weight: 600; color: #0f172a;">₩${Number(m.supplyAmount || 0).toLocaleString()}</td>
        <td style="padding: 8px 10px; text-align: right; color: #2563eb;">₩${Number(m.vatAmount || 0).toLocaleString()}</td>
        <td style="padding: 8px 10px; text-align: center; color: #16a34a; font-weight: 700;">정상 확인</td>
      </tr>
    `).join("") || `
      <tr>
        <td colspan="6" style="padding: 16px; text-align: center; color: #94a3b8; font-size: 11px;">대사된 전자세금계산서 내역이 없습니다.</td>
      </tr>
    `;

    const cashRowsHtml = (Array.isArray(cash.issues) ? cash.issues.filter(c => c && typeof c === "object") : []).map((c, i) => `
      <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
        <td style="padding: 8px 10px; text-align: center; color: #64748b;">${i + 1}</td>
        <td style="padding: 8px 10px; font-weight: 600; color: #0f172a;">${c.id || "-"}</td>
        <td style="padding: 8px 10px; color: #1e293b;">${c.customerName || "-"}</td>
        <td style="padding: 8px 10px; text-align: right; font-weight: 600; color: #0f172a;">₩${Number(c.orderAmount || 0).toLocaleString()}</td>
        <td style="padding: 8px 10px; text-align: right; font-weight: 700; color: #dc2626;">₩${Number(c.penaltyRisk || 0).toLocaleString()}</td>
        <td style="padding: 8px 10px; text-align: center; color: #d97706; font-weight: 600;">자진발급 필요</td>
      </tr>
    `).join("") || `
      <tr>
        <td colspan="6" style="padding: 16px; text-align: center; color: #16a34a; font-size: 11px; font-weight: 600;">현금영수증 미발행 주문이 없습니다 (가산세 0건).</td>
      </tr>
    `;

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>국세청 전자세금계산서·현금영수증 매입매출 크로스체크 감사보고서</title>
  <style>
    @page { size: A4 portrait; margin: 15mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Malgun Gothic", "Apple SD Gothic Neo", sans-serif;
      background: #ffffff;
      color: #0f172a;
      line-height: 1.5;
      margin: 0;
      padding: 24px;
    }
    .page-container {
      max-width: 800px;
      margin: 0 auto;
      border: 1px solid #cbd5e1;
      padding: 32px;
      background: #ffffff;
    }
    .header-table { width: 100%; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
    .title { font-size: 20px; font-weight: 800; color: #0f172a; letter-spacing: -0.5px; }
    .doc-meta { font-size: 11px; color: #475569; text-align: right; }
    .section-title { font-size: 13px; font-weight: 800; color: #0f172a; margin: 16px 0 8px 0; border-left: 3px solid #2563eb; padding-left: 8px; }
    .info-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px; }
    .info-table th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 6px 10px; text-align: left; width: 22%; color: #334155; }
    .info-table td { border: 1px solid #cbd5e1; padding: 6px 10px; color: #0f172a; }
    .summary-box { background: #f1f5f9; border: 1px solid #cbd5e1; padding: 14px; border-radius: 4px; margin-bottom: 18px; }
    .data-table { width: 100%; border-collapse: collapse; margin-bottom: 18px; font-size: 11px; }
    .data-table th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 8px 10px; color: #334155; }
    .data-table td { border: 1px solid #e2e8f0; }
    .stat-badge-pass { color: #16a34a; font-weight: 800; }
    .stat-badge-fail { color: #dc2626; font-weight: 800; }
    .official-sign { margin-top: 32px; text-align: center; border-top: 1px solid #cbd5e1; padding-top: 20px; font-size: 12px; color: #334155; }
    .no-print-btn { text-align: center; margin-bottom: 16px; }
    @media print {
      .no-print-btn { display: none; }
      body { padding: 0; }
      .page-container { border: none; padding: 0; }
    }
  </style>
</head>
<body>
  <div class="no-print-btn">
    <button onclick="window.print()" style="padding: 8px 18px; background: #0f172a; color: #ffffff; border: none; border-radius: 4px; font-size: 12px; font-weight: 700; cursor: pointer;">🖨️ 보고서 인쇄 / PDF 저장</button>
  </div>

  <div class="page-container">
    <table class="header-table">
      <tr>
        <td class="title">국세청 전자세금계산서·현금영수증 매입매출 크로스체크 감사보고서</td>
        <td class="doc-meta">
          문서번호: ${reconData.auditId || "-"}<br>
          발급일자: ${currentDate}<br>
          신고대상월: ${month}
        </td>
      </tr>
    </table>

    <table class="info-table">
      <tr>
        <th>상호 (스토어명)</th>
        <td>${reconData.storeName || "스토어"}</td>
        <th>사업자등록번호</th>
        <td style="font-family: monospace; font-weight: 600;">${reconData.bizRegNumber || "123-45-67890"}</td>
      </tr>
      <tr>
        <th>성명 (대표자)</th>
        <td>${reconData.sellerName || "대표자"}</td>
        <th>대사 플랫폼</th>
        <td>쿠팡(주) 마켓플레이스 (120-88-00767)</td>
      </tr>
      <tr>
        <th>관할 세무서</th>
        <td>사업장 소재지 관할 세무서장 귀하</td>
        <th>종합 세무 판정</th>
        <td class="${reconData.overallStatus === "CLEAN_COMPLIANT" ? "stat-badge-pass" : "stat-badge-fail"}">
          ${reconData.overallStatus === "CLEAN_COMPLIANT" ? "✅ 적격 세무 대사 완료 (가산세 리스크 0원)" : "⚠️ 불일치/가산세 위험 감지"}
        </td>
      </tr>
    </table>

    <div class="summary-box">
      <table style="width: 100%; font-size: 12px;">
        <tr>
          <td style="width: 33%; text-align: center; border-right: 1px solid #cbd5e1;">
            <div style="font-size: 11px; color: #64748b;">확보된 매입세액 공제액 (10%)</div>
            <div style="font-size: 16px; font-weight: 800; color: #2563eb; margin-top: 4px;">₩${Number(fee.protectedVatDeduction || 0).toLocaleString()}원</div>
          </td>
          <td style="width: 33%; text-align: center; border-right: 1px solid #cbd5e1;">
            <div style="font-size: 11px; color: #64748b;">매입 세금계산서 대사 상태</div>
            <div style="font-size: 15px; font-weight: 800; color: ${fee.isMatched ? "#16a34a" : "#dc2626"}; margin-top: 4px;">${fee.statusText || "확인 필요"}</div>
          </td>
          <td style="width: 33%; text-align: center;">
            <div style="font-size: 11px; color: #64748b;">현금영수증 미발행 가산세 리스크 (20%)</div>
            <div style="font-size: 16px; font-weight: 800; color: ${Number(cash.potentialPenalty || 0) > 0 ? "#dc2626" : "#16a34a"}; margin-top: 4px;">₩${Number(cash.potentialPenalty || 0).toLocaleString()}원</div>
          </td>
        </tr>
      </table>
    </div>

    <div class="section-title">1. 쿠팡 WING 수수료 vs 국세청 홈택스 매입 세금계산서 대사 명세</div>
    <table class="info-table" style="margin-bottom: 12px;">
      <tr>
        <th>구분</th>
        <th style="text-align: right;">공급가액</th>
        <th style="text-align: right;">부가가치세 (10%)</th>
        <th style="text-align: right;">합계금액</th>
        <th style="text-align: center;">대사 판정</th>
      </tr>
      <tr>
        <td style="font-weight: 600;">(A) 쿠팡 WING 정산 수수료</td>
        <td style="text-align: right;">₩${Number(fee.wingFeeSupply || 0).toLocaleString()}</td>
        <td style="text-align: right; color: #2563eb;">₩${Number(fee.wingFeeVat || 0).toLocaleString()}</td>
        <td style="text-align: right; font-weight: 700;">₩${Number(fee.wingFeeTotal || 0).toLocaleString()}</td>
        <td rowspan="2" style="text-align: center; font-weight: 800; color: ${fee.isMatched ? "#16a34a" : "#dc2626"}; vertical-align: middle;">
          ${fee.isMatched ? "100% 일치" : "차액 발생"}
        </td>
      </tr>
      <tr>
        <td style="font-weight: 600;">(B) 국세청 홈택스 매입 승인</td>
        <td style="text-align: right;">₩${Number(fee.hometaxFeeSupply || 0).toLocaleString()}</td>
        <td style="text-align: right; color: #2563eb;">₩${Number(fee.hometaxFeeVat || 0).toLocaleString()}</td>
        <td style="text-align: right; font-weight: 700;">₩${Number(fee.hometaxFeeTotal || 0).toLocaleString()}</td>
      </tr>
      <tr style="background: #f8fafc; font-weight: 700;">
        <td>차액 (A - B)</td>
        <td style="text-align: right; color: ${supplyDiff === 0 ? "#16a34a" : "#dc2626"};">₩${supplyDiff.toLocaleString()}</td>
        <td style="text-align: right; color: ${vatDiff === 0 ? "#16a34a" : "#dc2626"};">₩${vatDiff.toLocaleString()}</td>
        <td style="text-align: right; color: ${supplyDiff === 0 ? "#16a34a" : "#dc2626"};">₩${(supplyDiff + vatDiff).toLocaleString()}</td>
        <td style="text-align: center; font-size: 10px; color: #64748b;">${supplyDiff === 0 ? "가산세 0원" : "소명 요망"}</td>
      </tr>
    </table>

    <div class="section-title">2. 국세청 24자리 전자세금계산서 승인 목록 (검증 완료 건)</div>
    <table class="data-table">
      <thead>
        <tr>
          <th style="width: 6%;">No</th>
          <th style="width: 32%;">국세청 승인번호 (24자리)</th>
          <th style="width: 26%;">공급자 상호(사업자번호)</th>
          <th style="width: 16%; text-align: right;">공급가액</th>
          <th style="width: 12%; text-align: right;">세액</th>
          <th style="width: 8%; text-align: center;">상태</th>
        </tr>
      </thead>
      <tbody>
        ${invoiceRowsHtml}
      </tbody>
    </table>

    <div class="section-title">3. 현금영수증 의무발행 점검 및 미발행 가산세 리스크 내역 (조세범 처벌법 제15조)</div>
    <table class="data-table">
      <thead>
        <tr>
          <th style="width: 6%;">No</th>
          <th style="width: 22%;">주문번호</th>
          <th style="width: 20%;">구매자명</th>
          <th style="width: 18%; text-align: right;">현금결제액</th>
          <th style="width: 18%; text-align: right;">20% 가산세 위험</th>
          <th style="width: 16%; text-align: center;">권장 조치</th>
        </tr>
      </thead>
      <tbody>
        ${cashRowsHtml}
      </tbody>
    </table>

    <div style="font-size: 10px; color: #64748b; line-height: 1.6; margin-top: 16px;">
      1. 본 감사보고서는 「부가가치세법」 제54조 및 국세청 전산망에 등록된 24자리 승인번호 전자세금계산서를 기준으로 작성되었습니다.<br>
      2. 쿠팡 WING 수수료 매입세액 공제 누락 시 부가가치세 10%의 매입세액이 불공제되므로, 본 보고서의 공급가액 및 세액을 관할 세무서 확정신고서 매입처별 세금계산서합계표에 반드시 반영하십시오.<br>
      3. 현금영수증 미발행 건은 「조세범 처벌법」 제15조에 따라 20% 가산세가 부과되므로 국세청 홈택스에서 5일 이내 자진발급(010-000-1234) 처리하시기 바랍니다.
    </div>

    <div class="official-sign">
      상기 명세는 쿠팡 마켓플레이스 정산 원장 및 국세청 홈택스 전자세금계산서 발행 데이터와 1원 단위까지 정합함을 확인합니다.<br><br>
      <strong>${currentDate}</strong><br><br>
      <strong>제출인(신고인): ${reconData.storeName || "스토어"} (${reconData.sellerName || "대표자"}) (인쇄 시 직인 생략)</strong><br>
      <span style="font-size: 10px; color: #94a3b8;">시스템 발급: AutoFlow Enterprise HomeTax Cross-Check Sentinel v2.0 (인쇄 시 직인 생략)</span>
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * 대사 결과 영속화 및 통계 갱신
   * @param {Object} reconData
   */
  recordReconcileAudit(reconData) {
    if (!reconData || typeof reconData !== "object") return false;
    try {
      let records = this._loadAudits();
      records.unshift(reconData);
      // 최근 100건 보존
      if (records.length > 100) {
        records = records.slice(0, 100);
      }
      return this._saveAudits(records);
    } catch (e) {
      return false;
    }
  }

  /**
   * 대사 이력 및 요약 통계 조회
   * @returns {Object}
   */
  getHomeTaxSummary() {
    let totalAudits = 0;
    let totalProtectedVat = 0;
    let totalCashPenaltyRisk = 0;
    let pendingIssuesCount = 0;
    const recentAudits = this._loadAudits();
    totalAudits = recentAudits.length;

    recentAudits.forEach(aud => {
      if (!aud || typeof aud !== "object") return;
      const fee = (aud.feeReconciliation && typeof aud.feeReconciliation === "object") ? aud.feeReconciliation : {};
      const cash = (aud.cashReceiptAudit && typeof aud.cashReceiptAudit === "object") ? aud.cashReceiptAudit : {};
      totalProtectedVat += Number(fee.protectedVatDeduction || 0);
      totalCashPenaltyRisk += Number(cash.potentialPenalty || 0);
      if (aud.overallStatus !== "CLEAN_COMPLIANT") {
        pendingIssuesCount++;
      }
    });

    return {
      totalAudits,
      totalProtectedVat,
      totalCashPenaltyRisk,
      pendingIssuesCount,
      recentAudits: recentAudits.slice(0, 10)
    };
  }

  getSummary() {
    return this.getHomeTaxSummary();
  }

  /**
   * 현금영수증 자진발급 완료 또는 대사 이슈 해결 처리
   * @param {string} auditId
   * @param {string} action
   * @param {string} note
   * @returns {Object}
   */
  resolveHomeTaxIssue(auditId, action = "AUTO_RESOLVED", note = "") {
    if (auditId && typeof auditId === "object") {
      action = auditId.action || action;
      note = auditId.note || note;
      auditId = auditId.auditId || "";
    }
    action = action || "AUTO_RESOLVED";
    if (!fs.existsSync(this.storagePath)) return { success: false, message: "감사 원장 없음" };

    try {
      const records = this._loadAudits();
      const target = records.find(r => r && r.auditId === auditId);
      if (!target) return { success: false, message: "감사 기록을 찾을 수 없음" };

      target.overallStatus = "CLEAN_COMPLIANT";
      target.resolvedAt = new Date().toISOString();
      target.resolveAction = action;
      target.resolveNote = note || "국세청 자진발급 및 세무 대사 종결 완료";

      this._saveAudits(records);
      return { success: true, updatedRecord: target };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
}

module.exports = {
  HomeTaxCrossCheckSentinel,
  createHomeTaxCrossCheckSentinel: (options = {}) => new HomeTaxCrossCheckSentinel((options && typeof options === "object") ? options : {})
};
