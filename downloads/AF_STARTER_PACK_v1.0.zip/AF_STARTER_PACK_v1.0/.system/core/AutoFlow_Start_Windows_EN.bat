@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title AutoFlow Enterprise 1-Click Instant Launcher (Windows Global Edition)
cd /d "%~dp0"

echo ================================================================================
echo ⚡ AutoFlow Enterprise 1-Click Instant Launcher (Windows)
echo ================================================================================

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%~dp0' -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1

if not exist ".legal_agreed" (
    echo.
    echo ================================================================================
    echo ⚖️  [AutoFlow Enterprise Commercial License (EULA) ^& Disclaimer]
    echo ================================================================================
    echo  1. [AS-IS PRINCIPLE]: This software is provided 'AS-IS' under a single-seat license.
    echo  2. [THIRD-PARTY APIS]: Developer assumes no liability for external API policy changes.
    echo  3. [WARRANTY SCOPE]: Includes autonomous self-healing trial ^& perpetual n8n.
    echo  4. [FULL TERMS]: Full legal specifications in EULA_PERPETUAL_LICENSE.md.
    echo ================================================================================
    echo.
    set /p USER_LEGAL_CONSENT="👉 Do you accept the AutoFlow Commercial License (EULA) terms? [y/N]: "
    if /i not "!USER_LEGAL_CONSENT!"=="y" (
        echo.
        echo ⚠️ Terms declined. Safely terminating AutoFlow launcher.
        pause
        exit /b 0
    )
    echo agreed > ".legal_agreed"
    echo ✅ Legal consent recorded (.legal_agreed created).
)

set "NODE_BIN="
if exist "%~dp0bin\node.exe" (
    set "NODE_BIN=%~dp0bin\node.exe"
) else if exist "%~dp0..\bin\node.exe" (
    set "NODE_BIN=%~dp0..\bin\node.exe"
) else (
    where node >nul 2>nul
    if !errorlevel! equ 0 set "NODE_BIN=node"
)

if "!NODE_BIN!"=="" (
    echo [*] Auto-downloading portable Node.js runtime ^(node-v20.18.0-win-x64^)...
    if not exist "%~dp0bin" mkdir "%~dp0bin"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference = 'SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $zipUrl = 'https://nodejs.org/dist/v20.18.0/node-v20.18.0-win-x64.zip'; $zipPath = Join-Path '%~dp0' 'bin\node_win_x64.zip'; $extractDir = Join-Path '%~dp0' 'bin\node_extract_tmp'; Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing; if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }; Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force; Copy-Item -Path (Join-Path $extractDir 'node-v20.18.0-win-x64\node.exe') -Destination (Join-Path '%~dp0' 'bin\node.exe') -Force; Remove-Item $zipPath -Force -ErrorAction SilentlyContinue; Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue"
    if exist "%~dp0bin\node.exe" (
        set "NODE_BIN=%~dp0bin\node.exe"
    ) else (
        echo ❌ Failed to download portable Node.js runtime. Please check your internet connection.
        pause
        exit /b 1
    )
)

echo.
echo 🔄 Synchronizing engine license ^& hardware identity...
if exist "core\recharge_cli.js" (
    "!NODE_BIN!" "core\recharge_cli.js" sync --lang=en >nul 2>&1
    "!NODE_BIN!" "core\recharge_cli.js" status --lang=en
)
echo.

echo 🚀 Booting AutoFlow background daemons...
if not exist "logs" mkdir logs
start /b "" "!NODE_BIN!" "bin\n8n-entry.js" > logs\standalone_engine.log 2>&1
if exist "core\autoflow_sidecar_daemon.js" (
    start /b "" "!NODE_BIN!" "core\autoflow_sidecar_daemon.js" > logs\sidecar_daemon.log 2>&1
)
if exist "core\telemetry_beacon.js" (
    start /b "" "!NODE_BIN!" "core\telemetry_beacon.js" > logs\telemetry_beacon.log 2>&1
)
if exist "core\watchdog.js" (
    start /b "" "!NODE_BIN!" "core\watchdog.js" > logs\watchdog.log 2>&1
)

echo ✅ AutoFlow daemons launched!
if exist "%USERPROFILE%\Desktop" (
    echo [InternetShortcut] > "%USERPROFILE%\Desktop\AutoFlow_Open_Console.url"
    echo URL=http://localhost:5678 >> "%USERPROFILE%\Desktop\AutoFlow_Open_Console.url"
    echo [INFO] Desktop shortcut created: %USERPROFILE%\Desktop\AutoFlow_Open_Console.url
)
echo 🌐 Opening AutoFlow Studio in your default browser...
timeout /t 2 >nul
start http://localhost:5678

echo.
echo ================================================================================
echo 🎉 AutoFlow is now running smoothly in background!
echo ================================================================================
echo    - Studio UI:           http://localhost:5678
echo    - Sidecar Healthcheck: http://localhost:8080/healthz
echo    - License Top-Up:      Run RECHARGE_ENGINE.bat
echo ================================================================================
echo.
pause
