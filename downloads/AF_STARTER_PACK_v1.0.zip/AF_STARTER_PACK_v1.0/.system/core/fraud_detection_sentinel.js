/**
 * AutoFlow Coupang & E-Commerce Fraud Detection & Chargeback Defense Sentinel
 * (Gate 43: GATE_LEGAL_11)
 * (core/fraud_detection_sentinel.js)
 * 
 * [법률 및 전자금융거래 컴플라이언스]
 * 1. 「여신전문금융업법」 제16조(신용카드회원등에 대한 책임) 준용:
 *    - 도용 카드 결제 및 부정 거래 발생 시 판매자의 선의·무과실 입증 및 1초 출고보류(Stop-Shipment)로 차지백(환불 독박) 방어.
 * 2. 「전자문서 및 전자거래 기본법」 제4조(전자문서의 효력) 및 「전자상거래법」 제24조(전자결제의 안전성 확보 등).
 * 3. 5대 가중치 FDS 판정 엔진 (evaluateFraudRisk):
 *    - 시간대 위험도 (심야 02:00~05:00 가중치 +20점)
 *    - IP 중복/단시간 빈도 (1분 내 동일 IP 다중 결제 +25점)
 *    - 주문 금액 및 수량 이상치 (50만 원 이상 고액 또는 단일 품목 10개 이상 싹쓸이 +25점)
 *    - 배송지/수령인 이상치 (가상 주소지, 특수문자, 대포폰 의심 패턴 +20점)
 *    - 수령인명-전화번호-주소 교차 불일치 (+15점)
 * 4. 4대 위험도 분류:
 *    - FRAUD_SAFE (0~20점): 정상 승인 (자동 발주 및 즉시 출고 진행)
 *    - FRAUD_SUSPICIOUS (21~60점): 주의 (출고 전 구매자 유선 확인 권고)
 *    - FRAUD_HIGH_RISK (61~85점): 고위험 (1초 출고보류 Stop-Shipment 연동 및 차지백 방어액 산출)
 *    - FRAUD_CRITICAL_BLOCKED (86~100점): 초고위험 (즉각 주문 홀드 및 카드사/쿠팡 부정거래 신고 증적 자동 생성)
 * 5. Pure White Clean Enterprise 라이트 모드 공식 소명 증적서 HTML 생성기:
 *    - 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건, 다크모드 영구 금지).
 * 6. 영속 원장(`logs/fraud_detection_audits.json`), 통계 집계(`getSummary()`), 이슈 종결(`resolveFraudOrder()`).
 */

"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

class FraudDetectionSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/fraud_detection_audits.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/fraud_detection_config.json");
    this._recentIpHistory = []; // 단시간 IP 빈도 추적용 메모리 캐시

    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const storageDir = path.dirname(this.storagePath);
      if (!fs.existsSync(storageDir)) {
        fs.mkdirSync(storageDir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(this.storagePath, JSON.stringify([], null, 2), "utf8");
      }
    } catch (_) {}

    try {
      const configDir = path.dirname(this.configPath);
      if (!fs.existsSync(configDir)) {
        fs.mkdirSync(configDir, { recursive: true });
      }
      if (!fs.existsSync(this.configPath)) {
        fs.writeFileSync(
          this.configPath,
          JSON.stringify({
            enabled: true,
            storeName: "AutoFlow 공식 스마트스토어",
            sellerName: "오토플로우 대표",
            sellerPhone: "02-1544-0000",
            sellerEmail: "compliance@autoflow.local",
            highValueThresholdWon: 500000,
            bulkQuantityThreshold: 10,
            autoStopShipmentOnHighRisk: true,
            lateNightStartHour: 2,
            lateNightEndHour: 5
          }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (_) {}
    return {
      enabled: true,
      storeName: "AutoFlow 공식 스마트스토어",
      sellerName: "오토플로우 대표",
      sellerPhone: "02-1544-0000",
      sellerEmail: "compliance@autoflow.local",
      highValueThresholdWon: 500000,
      bulkQuantityThreshold: 10,
      autoStopShipmentOnHighRisk: true,
      lateNightStartHour: 2,
      lateNightEndHour: 5
    };
  }

  /**
   * 원장 로드 (안전 파싱 및 null 요소 필터링)
   */
  _loadAudits() {
    try {
      if (fs.existsSync(this.storagePath)) {
        const raw = fs.readFileSync(this.storagePath, "utf8");
        const parsed = JSON.parse(raw || "[]");
        return Array.isArray(parsed)
          ? parsed.filter(x => x && typeof x === "object")
          : (parsed && Array.isArray(parsed.audits) ? parsed.audits.filter(x => x && typeof x === "object") : []);
      }
    } catch (_) {}
    return [];
  }

  loadAudits() {
    return this._loadAudits();
  }

  _saveAudits(audits) {
    try {
      if (!Array.isArray(audits)) return false;
      const clean = audits.filter(x => x && typeof x === "object");
      this._ensureStorage();
      fs.writeFileSync(this.storagePath, JSON.stringify(clean, null, 2), "utf8");
      return true;
    } catch (err) {
      console.error("[FraudDetectionSentinel] 원장 저장 실패:", err.message);
      return false;
    }
  }

  saveAudits(audits) {
    return this._saveAudits(audits);
  }

  /**
   * 단건 감사 기록 영속화
   */
  recordAudit(auditRecord) {
    if (!auditRecord || typeof auditRecord !== "object") return false;
    try {
      const audits = this._loadAudits();
      const existingIdx = audits.findIndex(a => a && a.auditId && a.auditId === auditRecord.auditId);
      if (existingIdx >= 0) {
        audits[existingIdx] = auditRecord;
      } else {
        audits.unshift(auditRecord);
      }
      if (audits.length > 5000) {
        audits.length = 5000;
      }
      return this._saveAudits(audits);
    } catch (err) {
      console.error("[FraudDetectionSentinel] 원장 저장 실패:", err.message);
      return false;
    }
  }

  /**
   * 5대 가중치 FDS 판정 엔진
   * @param {Object} orderData 주문 데이터
   * @param {Object} customOptions 옵션 재정의
   * @returns {Object} FDS 감사 결과
   */
  evaluateFraudRisk(orderData = {}, customOptions = {}) {
    orderData = (orderData && typeof orderData === "object") ? orderData : {};
    customOptions = (customOptions && typeof customOptions === "object") ? customOptions : {};
    const config = Object.assign({}, this.getConfig(), customOptions);

    const orderId = String(orderData.orderId || orderData.order_id || `CP-${Date.now()}`).trim();
    const customerName = String(orderData.customerName || orderData.buyerName || "홍길동").trim();
    const receiverName = String(orderData.receiverName || orderData.recipientName || customerName).trim();
    const customerPhone = String(orderData.customerPhone || orderData.phone || "010-1234-5678").trim();
    const receiverPhone = String(orderData.receiverPhone || customerPhone).trim();
    const shippingAddress = String(orderData.shippingAddress || orderData.receiverAddress || orderData.address || "서울특별시 강남구 테헤란로 123").trim();
    const totalAmount = Number(orderData.totalAmount || orderData.orderAmount || orderData.amount || 0);
    const quantity = Number(orderData.quantity || orderData.totalQuantity || orderData.orderQuantity || 1);
    const ipAddress = String(orderData.ipAddress || orderData.orderIp || orderData.ip || "127.0.0.1").trim();
    const marketplace = String(orderData.marketplace || "쿠팡 (Coupang Wing)").trim();
    const checkTimestamp = orderData.orderTime || orderData.orderedAt || orderData.paidAt || new Date().toISOString();

    const riskFactors = [];
    let totalScore = 0;

    // 1. 시간대 위험도 (심야 02:00~05:00 가중치 +20점)
    let orderHour = -1;
    try {
      if (typeof checkTimestamp === "string") {
        if (checkTimestamp.includes("T")) {
          const d = new Date(checkTimestamp);
          if (!isNaN(d.getTime())) {
            orderHour = d.getHours();
          }
        } else if (checkTimestamp.match(/(\d{1,2}):(\d{2})/)) {
          const m = checkTimestamp.match(/(\d{1,2}):(\d{2})/);
          orderHour = parseInt(m[1], 10);
        }
      }
    } catch (_) {}
    if (orderHour === -1) {
      orderHour = new Date().getHours();
    }

    const isLateNight = (orderHour >= config.lateNightStartHour && orderHour < config.lateNightEndHour);
    if (isLateNight || orderData.isLateNight === true) {
      const lateScore = 20;
      totalScore += lateScore;
      riskFactors.push({
        factorId: "TIME_WINDOW_LATE_NIGHT",
        name: "시간대 위험도 (심야 결제)",
        score: lateScore,
        details: `결제 시간대(${String(orderHour).padStart(2, "0")}:00)가 심야(02:00~05:00) 도용 취약 시간대에 해당`,
        isTriggered: true
      });
    } else {
      riskFactors.push({
        factorId: "TIME_WINDOW_LATE_NIGHT",
        name: "시간대 위험도 (심야 결제)",
        score: 0,
        details: `정상 주간/야간 시간대 결제(${String(orderHour).padStart(2, "0")}:00)`,
        isTriggered: false
      });
    }

    // 2. IP 중복/단시간 빈도 (1분 내 동일 IP 다중 결제 +25점)
    const now = Date.now();
    // 메모리 캐시 정리 (최근 5분 이내만 유지)
    this._recentIpHistory = this._recentIpHistory.filter(item => (now - item.timestamp) < 300000);

    let ipFreq = Number(orderData.ipFrequency || 1);
    const sameIpRecent = this._recentIpHistory.filter(
      item => item.ip === ipAddress && (now - item.timestamp) <= 60000 && item.orderId !== orderId
    );

    if (sameIpRecent.length > 0) {
      ipFreq += sameIpRecent.length;
    }
    if (orderData.sameIpWithinOneMin === true || orderData.isShortIntervalMultiIp === true) {
      ipFreq = Math.max(ipFreq, 2);
    }

    // 현재 IP 기록 캐싱
    this._recentIpHistory.push({ ip: ipAddress, orderId, timestamp: now });

    if (ipFreq >= 2) {
      const ipScore = 25;
      totalScore += ipScore;
      riskFactors.push({
        factorId: "IP_SHORT_INTERVAL_BURST",
        name: "IP 중복 및 단시간 연쇄 결제 빈도",
        score: ipScore,
        details: `동일 IP(${ipAddress})로부터 1분 내 ${ipFreq}회 연속 결제 감지 (도용 카드 무작위 대입 패턴)`,
        isTriggered: true
      });
    } else {
      riskFactors.push({
        factorId: "IP_SHORT_INTERVAL_BURST",
        name: "IP 중복 및 단시간 연쇄 결제 빈도",
        score: 0,
        details: `단일 고유 IP 정상 접근 (${ipAddress})`,
        isTriggered: false
      });
    }

    // 3. 주문 금액 및 수량 이상치 (50만 원 이상 고액 또는 단일 품목 10개 이상 싹쓸이 +25점)
    const isHighValue = totalAmount >= config.highValueThresholdWon;
    const isBulkQty = quantity >= config.bulkQuantityThreshold;

    if (isHighValue || isBulkQty || orderData.isAbnormalAmount === true) {
      let valScore = 25;
      if (isHighValue && !isBulkQty) valScore = 25;
      if (!isHighValue && isBulkQty) valScore = 20;
      if (isHighValue && isBulkQty) valScore = 25;

      totalScore += valScore;
      riskFactors.push({
        factorId: "AMOUNT_QTY_OUTLIER",
        name: "주문 금액 및 수량 이상치 (대량 싹쓸이)",
        score: valScore,
        details: `주문금액 ₩${totalAmount.toLocaleString()}원 (기준 50만 원) 또는 단일 품목 ${quantity}개 대량 싹쓸이 결제 패턴`,
        isTriggered: true
      });
    } else {
      riskFactors.push({
        factorId: "AMOUNT_QTY_OUTLIER",
        name: "주문 금액 및 수량 이상치 (대량 싹쓸이)",
        score: 0,
        details: `정상 주문 범위 (₩${totalAmount.toLocaleString()}원, ${quantity}개)`,
        isTriggered: false
      });
    }

    // 4. 배송지/수령인 이상치 (가상 주소지, 특수문자, 대포폰 의심 패턴 +20점)
    const virtualAddressKeywords = [
      "무인택배", "택배함", "보관함", "지하철", "물류창고", "사서함", "폐가",
      "가상주소", "P.O.BOX", "PO BOX", "편의점보관", "임의주소", "무인함"
    ];
    const isVirtualAddress = virtualAddressKeywords.some(kw => shippingAddress.includes(kw));
    const hasSpecialCharsInAddress = (shippingAddress.match(/[!@#$%^&*()_+=\[\]{};':"\\|<>?~`]/g) || []).length >= 3;
    const isTooShortAddress = shippingAddress.replace(/\s+/g, "").length < 6;

    // 대포폰 / 비정상 연락처 패턴
    const cleanPhone = receiverPhone.replace(/[^0-9]/g, "");
    const isDummyPhone = (
      cleanPhone === "01000000000" ||
      cleanPhone === "01011111111" ||
      cleanPhone === "01012345678" ||
      cleanPhone === "01099999999" ||
      cleanPhone === "01088888888" ||
      cleanPhone.length < 10 ||
      cleanPhone.length > 11 ||
      !cleanPhone.startsWith("01")
    );

    if (isVirtualAddress || hasSpecialCharsInAddress || isTooShortAddress || isDummyPhone || orderData.isAbnormalAddressPhone === true) {
      const addrScore = 20;
      totalScore += addrScore;
      const addrReasons = [];
      if (isVirtualAddress) addrReasons.push("가상/무인보관함 주소");
      if (hasSpecialCharsInAddress) addrReasons.push("주소 내 특수문자 다수");
      if (isTooShortAddress) addrReasons.push("주소 길이 극소");
      if (isDummyPhone) addrReasons.push(`비정상/대포폰 의심 연락처 (${receiverPhone})`);

      riskFactors.push({
        factorId: "ADDRESS_PHONE_ANOMALY",
        name: "배송지 및 연락처 이상치 (가상지/대포폰)",
        score: addrScore,
        details: addrReasons.join(", ") || "가상 주소지 또는 대포폰 의심 패턴",
        isTriggered: true
      });
    } else {
      riskFactors.push({
        factorId: "ADDRESS_PHONE_ANOMALY",
        name: "배송지 및 연락처 이상치 (가상지/대포폰)",
        score: 0,
        details: "정상 유효 배송지 및 유효 이동전화 번호 확인",
        isTriggered: false
      });
    }

    // 5. 수령인명-전화번호-주소 교차 불일치 (+15점)
    const abnormalNames = ["테스트", "test", "asdf", "ㅁㄴㅇㄹ", "ㅋㅋㅋ", "zzz", "익명", "구매자", "받는사람", "123", "abc", "홍길동"];
    const isAbnormalReceiverName = abnormalNames.includes(receiverName.toLowerCase()) || receiverName.length < 2 || /^[a-zA-Z0-9]+$/.test(receiverName);
    const isCustomerMismatch = (customerName !== receiverName && isAbnormalReceiverName);
    const isForcedMismatch = (orderData.isIdentityMismatch === true);

    if (isCustomerMismatch || isForcedMismatch || (customerName !== receiverName && isVirtualAddress)) {
      const mismatchScore = 15;
      totalScore += mismatchScore;
      riskFactors.push({
        factorId: "IDENTITY_MISMATCH",
        name: "수령인명-전화번호-주소 교차 불일치",
        score: mismatchScore,
        details: `구매자명(${customerName}) 대비 수령인명(${receiverName}) 불일치 및 가명/임의문자열 감지`,
        isTriggered: true
      });
    } else {
      riskFactors.push({
        factorId: "IDENTITY_MISMATCH",
        name: "수령인명-전화번호-주소 교차 불일치",
        score: 0,
        details: `구매자-수령인 신원 정보 정상 일치 (${customerName})`,
        isTriggered: false
      });
    }

    // 최종 위험 점수 정규화 (0 ~ 100점)
    totalScore = Math.min(100, Math.max(0, totalScore));

    // 4대 위험도 분류
    let riskLevel = "FRAUD_SAFE";
    let riskLevelLabel = "정상 승인 (FRAUD_SAFE)";
    let stopShipment = false;
    let preventedLossWon = 0;
    let actionRecommendation = "정상 거래 승인 - 자동 발주 및 즉시 정상 출고를 진행하십시오.";
    let disputeEvidenceReady = false;

    if (totalScore <= 20) {
      riskLevel = "FRAUD_SAFE";
      riskLevelLabel = "정상 승인 (FRAUD_SAFE)";
      stopShipment = false;
      preventedLossWon = 0;
      actionRecommendation = "정상 거래 승인 - 이상 징후 없음. 자동 발주 및 정규 출고 스케줄을 유지하십시오.";
    } else if (totalScore <= 60) {
      riskLevel = "FRAUD_SUSPICIOUS";
      riskLevelLabel = "주의 관찰 (FRAUD_SUSPICIOUS)";
      stopShipment = false;
      preventedLossWon = 0;
      actionRecommendation = "주의 관찰 권고 - 부정 결제 의심 징후가 있습니다. 출고 전 구매자 유선 확인(010 안심콜)을 권고합니다.";
    } else if (totalScore <= 85) {
      riskLevel = "FRAUD_HIGH_RISK";
      riskLevelLabel = "고위험 탐지 (FRAUD_HIGH_RISK)";
      stopShipment = true;
      preventedLossWon = totalAmount;
      disputeEvidenceReady = true;
      actionRecommendation = "고위험 도용 결제 의심 - 1초 출고보류(Stop-Shipment) 즉각 발동. 차지백 손실 방어를 위해 유선 확인 전까지 출고를 전면 보류하십시오.";
    } else {
      riskLevel = "FRAUD_CRITICAL_BLOCKED";
      riskLevelLabel = "초고위험 즉각 차단 (FRAUD_CRITICAL_BLOCKED)";
      stopShipment = true;
      preventedLossWon = totalAmount;
      disputeEvidenceReady = true;
      actionRecommendation = "초고위험 부정 거래 차단 - 카드도용/대포폰/싹쓸이 연쇄 결제 감지. 즉각 주문을 홀드하고 카드사 및 쿠팡 부정거래 신고 공식 증적서를 제출하십시오.";
    }

    const auditId = `FDS-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
    const evaluatedAt = new Date().toISOString();

    const auditRecord = {
      auditId,
      orderId,
      marketplace,
      customerName,
      customerPhone,
      receiverName,
      receiverPhone,
      shippingAddress,
      totalAmount,
      quantity,
      ipAddress,
      orderHour,
      checkTimestamp,
      riskScore: totalScore,
      riskLevel,
      riskLevelLabel,
      stopShipment,
      preventedLossWon,
      actionRecommendation,
      disputeEvidenceReady,
      riskFactors,
      status: "OPEN",
      resolution: null,
      resolvedAt: null,
      note: "",
      evaluatedAt
    };

    return auditRecord;
  }

  /**
   * 이슈 종결 처리
   */
  resolveFraudOrder(auditId, resolution = "VERIFIED_GENUINE", note = "") {
    if (auditId && typeof auditId === "object") {
      resolution = auditId.resolution || resolution;
      note = auditId.note || note;
      auditId = auditId.auditId || auditId.orderId || "";
    }
    resolution = resolution || "VERIFIED_GENUINE";
    const audits = this._loadAudits();
    const target = audits.find(a => a && (a.auditId === auditId || a.orderId === auditId));
    if (!target) {
      return { success: false, message: `감사 기록(${auditId || "N/A"})을 찾을 수 없습니다.` };
    }

    target.status = "RESOLVED";
    target.resolution = resolution;
    target.resolvedAt = new Date().toISOString();
    target.note = note || `담당자 조치 완료 (${resolution})`;

    this.recordAudit(target);
    return { success: true, message: `FDS 이슈 종결 완료 (${target.orderId} - ${resolution})`, record: target };
  }

  /**
   * 단건 조회
   */
  getAuditById(auditId) {
    if (auditId && typeof auditId === "object") {
      auditId = auditId.auditId || auditId.orderId || "";
    }
    if (!auditId) return null;
    const audits = this._loadAudits();
    return audits.find(a => a && (a.auditId === auditId || a.orderId === auditId)) || null;
  }

  /**
   * 대시보드 통계 집계
   */
  getSummary() {
    const audits = this._loadAudits();
    let safeCount = 0;
    let suspiciousCount = 0;
    let highRiskCount = 0;
    let criticalBlockedCount = 0;
    let preventedLossWon = 0;

    for (const a of audits) {
      if (!a || typeof a !== "object") continue;
      if (a.riskLevel === "FRAUD_SAFE") safeCount++;
      else if (a.riskLevel === "FRAUD_SUSPICIOUS") suspiciousCount++;
      else if (a.riskLevel === "FRAUD_HIGH_RISK") {
        highRiskCount++;
        preventedLossWon += (a.preventedLossWon || 0);
      } else if (a.riskLevel === "FRAUD_CRITICAL_BLOCKED") {
        criticalBlockedCount++;
        preventedLossWon += (a.preventedLossWon || 0);
      }
    }

    return {
      totalAudits: audits.length,
      safeCount,
      suspiciousCount,
      highRiskCount,
      criticalBlockedCount,
      preventedLossWon,
      recentAudits: audits.slice(0, 15)
    };
  }

  /**
   * Pure White Clean Enterprise 라이트 모드 여신전문금융업법 제16조 준용 공식 소명 증적서 HTML 생성기
   * 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건, 다크모드 영구 금지)
   */
  generateFraudDisputeEvidenceHtml(auditRecord = {}) {
    if (typeof auditRecord === "string" && auditRecord.trim()) {
      auditRecord = this.getAuditById(auditRecord.trim()) || { orderId: auditRecord.trim() };
    }
    auditRecord = (auditRecord && typeof auditRecord === "object") ? auditRecord : {};
    const config = this.getConfig();
    const record = (auditRecord.auditId && Array.isArray(auditRecord.riskFactors))
      ? auditRecord
      : this.evaluateFraudRisk(auditRecord);

    const issueDate = new Date().toISOString().replace("T", " ").substring(0, 19) + " KST";
    const certSerial = "FDS-EVID-" + crypto.createHash("md5").update((record.auditId || "") + issueDate).digest("hex").toUpperCase().substring(0, 16);

    // 개인정보보호법에 따른 안전 마스킹
    const maskName = (name) => {
      if (!name || name.length <= 1) return "*";
      if (name.length === 2) return name[0] + "*";
      return name[0] + "*".repeat(name.length - 2) + name[name.length - 1];
    };
    const maskPhone = (phone) => {
      const clean = String(phone || "").replace(/[^0-9]/g, "");
      if (clean.length === 11) {
        return clean.substring(0, 3) + "-****-" + clean.substring(7);
      } else if (clean.length === 10) {
        return clean.substring(0, 3) + "-***-" + clean.substring(6);
      }
      return phone || "010-0000-0000";
    };

    const customerMasked = maskName(record.customerName || "홍길동");
    const receiverMasked = maskName(record.receiverName || "홍길동");
    const phoneMasked = maskPhone(record.receiverPhone || record.customerPhone || "010-0000-0000");

    let badgeBg = "#10b981";
    let badgeText = "#ffffff";
    if (record.riskLevel === "FRAUD_SUSPICIOUS") {
      badgeBg = "#f59e0b";
      badgeText = "#ffffff";
    } else if (record.riskLevel === "FRAUD_HIGH_RISK") {
      badgeBg = "#ef4444";
      badgeText = "#ffffff";
    } else if (record.riskLevel === "FRAUD_CRITICAL_BLOCKED") {
      badgeBg = "#7f1d1d";
      badgeText = "#ffffff";
    }

    const factorRows = (record.riskFactors || []).filter(f => f && typeof f === "object").map(f => `
      <tr>
        <td style="padding: 10px 14px; border: 1px solid #e2e8f0; font-weight: 600; font-size: 13px; color: #1e293b;">${f.name || "-"}</td>
        <td style="padding: 10px 14px; border: 1px solid #e2e8f0; text-align: center; font-weight: 700; font-size: 13px; color: ${f.score > 0 ? '#b91c1c' : '#059669'};">
          ${f.score > 0 ? `+${f.score}점 (이상치 감지)` : '0점 (정상)'}
        </td>
        <td style="padding: 10px 14px; border: 1px solid #e2e8f0; font-size: 12px; color: #475569;">${f.details || "-"}</td>
      </tr>
    `).join("");

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>부정 결제 의심 및 차지백 방어 공식 소명 증적서 (${certSerial})</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Pretendard", "Segoe UI", Roboto, sans-serif;
      background: #f8fafc;
      color: #0f172a;
      margin: 0;
      padding: 40px 20px;
    }
    .doc-container {
      max-width: 900px;
      margin: 0 auto;
      background: #ffffff;
      border: 2px solid #0f172a;
      border-radius: 8px;
      padding: 44px 50px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }
    .doc-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 2px solid #0f172a;
      padding-bottom: 22px;
      margin-bottom: 26px;
    }
    .doc-title-group h1 {
      font-size: 24px;
      font-weight: 800;
      margin: 0 0 6px 0;
      color: #0f172a;
      letter-spacing: -0.5px;
    }
    .doc-title-group p {
      font-size: 13px;
      color: #475569;
      margin: 0;
    }
    .doc-actions {
      text-align: right;
    }
    .print-btn {
      background: #0f172a;
      color: #ffffff;
      border: none;
      padding: 9px 18px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
    }
    .meta-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 16px 20px;
      margin-bottom: 24px;
      font-size: 12.5px;
    }
    .meta-item span.label {
      color: #64748b;
      font-weight: 600;
      margin-right: 8px;
    }
    .meta-item span.value {
      color: #0f172a;
      font-weight: 700;
      font-family: monospace;
    }
    .legal-box {
      background: #eff6ff;
      border-left: 4px solid #2563eb;
      padding: 14px 18px;
      border-radius: 4px;
      font-size: 12px;
      color: #1e40af;
      line-height: 1.6;
      margin-bottom: 26px;
    }
    .risk-banner {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      padding: 16px 20px;
      margin-bottom: 26px;
    }
    .risk-pill {
      display: inline-block;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 800;
      background: ${badgeBg};
      color: ${badgeText};
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 26px;
    }
    th {
      background: #f1f5f9;
      padding: 11px 14px;
      border: 1px solid #cbd5e1;
      font-size: 12px;
      font-weight: 700;
      color: #334155;
      text-align: left;
    }
    .statement-box {
      background: #fffbeb;
      border-left: 4px solid #f59e0b;
      padding: 14px 18px;
      border-radius: 4px;
      font-size: 12px;
      color: #92400e;
      line-height: 1.6;
      margin-bottom: 28px;
    }
    .doc-footer {
      border-top: 1px solid #e2e8f0;
      padding-top: 24px;
      margin-top: 24px;
    }
    .signature-area {
      text-align: right;
      font-size: 13px;
      font-weight: 700;
      color: #0f172a;
      line-height: 1.8;
      margin-bottom: 16px;
    }
    .system-badge {
      font-size: 11px;
      color: #64748b;
      display: flex;
      justify-content: space-between;
    }
    @media print {
      body {
        padding: 0;
        background: #ffffff;
      }
      .doc-container {
        border: none;
        box-shadow: none;
        padding: 0;
        max-width: 100%;
      }
      .print-btn {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="doc-container">
    <div class="doc-header">
      <div class="doc-title-group">
        <h1>🛡️ 부정 결제 의심 및 차지백 방어 공식 소명 증적서</h1>
        <p>Official Affidavit & Dispute Evidence of Fraud Detection & Chargeback Defense</p>
      </div>
      <div class="doc-actions">
        <button type="button" class="print-btn" onclick="window.print()">🖨️ 증적서 인쇄 / PDF 저장</button>
      </div>
    </div>

    <div class="meta-grid">
      <div class="meta-item"><span class="label">증적 일련번호:</span><span class="value">${certSerial}</span></div>
      <div class="meta-item"><span class="label">발급 일시:</span><span class="value">${issueDate}</span></div>
      <div class="meta-item"><span class="label">주문번호 (Order ID):</span><span class="value">${record.orderId}</span></div>
      <div class="meta-item"><span class="label">마켓플레이스:</span><span class="value" style="font-family: inherit;">${record.marketplace}</span></div>
      <div class="meta-item"><span class="label">결제 금액 / 수량:</span><span class="value">₩${Number(record.totalAmount || 0).toLocaleString()}원 / ${record.quantity}개</span></div>
      <div class="meta-item"><span class="label">주문자 / 수령인:</span><span class="value" style="font-family: inherit;">${customerMasked} / ${receiverMasked} (${phoneMasked})</span></div>
      <div class="meta-item" style="grid-column: span 2;"><span class="label">배송지 주소:</span><span class="value" style="font-family: inherit;">${record.shippingAddress}</span></div>
      <div class="meta-item"><span class="label">접속 IP / 결제시각:</span><span class="value">${record.ipAddress} (${record.checkTimestamp})</span></div>
      <div class="meta-item"><span class="label">소명 사업자:</span><span class="value" style="font-family: inherit;">${config.storeName} (${config.sellerName})</span></div>
    </div>

    <div class="legal-box">
      <strong>⚖️ 관련 법률 및 법적 소명 근거:</strong><br>
      본 소명서는 <strong>「여신전문금융업법」 제16조(신용카드회원등에 대한 책임)</strong>, <strong>「전자문서 및 전자거래 기본법」 제4조(전자문서의 효력)</strong>, <strong>「전자상거래 등에서의 소비자보호에 관한 법률」 제24조(전자결제의 안전성 확보 등)</strong>에 의거하여, 판매자가 도용 신용카드 결제 및 비정상 연쇄 거래 징후를 사전에 감지하고 고의·과실 없이 즉각적인 출고보류(Stop-Shipment) 및 거래 사실 확인 조치를 이행하였음을 증명하는 공식 공문서입니다. 신용카드사, PG사 및 오픈마켓(쿠팡 등) 분쟁 시 판매자 귀책 배제 및 차지백(부당환불) 방어 소명 자료로 효력을 가집니다.
    </div>

    <div class="risk-banner">
      <div>
        <div style="font-size: 11px; font-weight: 700; color: #64748b; margin-bottom: 4px;">FDS 위험도 종합 판정 결과</div>
        <div style="font-size: 18px; font-weight: 800; color: #0f172a;">
          위험 점수: <span style="color: ${record.riskScore >= 60 ? '#b91c1c' : '#059669'};">${record.riskScore}점 / 100점</span>
        </div>
      </div>
      <div style="text-align: right;">
        <span class="risk-pill">${record.riskLevelLabel}</span>
        <div style="margin-top: 6px; font-size: 11px; font-weight: 700; color: ${record.stopShipment ? '#b91c1c' : '#059669'};">
          ${record.stopShipment ? `🛑 1초 출고보류(Stop-Shipment) 발동 | 방어액 ₩${Number(record.preventedLossWon || 0).toLocaleString()}원` : '✅ 정상 출고 가능 상태'}
        </div>
      </div>
    </div>

    <table style="margin-bottom: 20px;">
      <thead>
        <tr>
          <th style="width: 32%;">5대 가중치 FDS 판정 항목</th>
          <th style="width: 22%; text-align: center;">위험 점수</th>
          <th style="width: 46%;">세부 감별 분석 내역</th>
        </tr>
      </thead>
      <tbody>
        ${factorRows}
      </tbody>
    </table>

    <div class="statement-box">
      <strong>📋 카드사 및 플랫폼(쿠팡 WING) 제출용 공식 진술:</strong><br>
      당 판매자는 위 주문 건에 대해 비정상 거래(심야 접속, IP 이상 빈도, 고액/대량 싹쓸이, 배송지/연락처 이상치 등)를 감지하여 <strong>물품 출고를 즉각 보류하고 손실 방어 조치를 취하였습니다.</strong> 본 건에 대한 부정 사용 차지백 요청 발생 시 당사의 선량한 관리자로서의 주의 의무 이행 사실이 인정되어야 하며, 판매자에게 부당한 결제 대금 환수나 페널티를 부과할 수 없음을 진술합니다.
    </div>

    <div class="doc-footer">
      <div class="signature-area">
        ${issueDate.substring(0, 10)}<br><br>
        소명인(판매자): ${config.storeName} (${config.sellerName}) (인쇄 시 직인 생략)
      </div>
      <div class="system-badge">
        <span>발급 엔진: AutoFlow Enterprise Fraud Detection Sentinel v2.0 (인쇄 시 직인 생략)</span>
        <span>고객/법무 문의: ${config.sellerPhone} | ${config.sellerEmail}</span>
      </div>
    </div>
  </div>
</body>
</html>`;
  }
}

function createFraudDetectionSentinel(options = {}) {
  return new FraudDetectionSentinel((options && typeof options === "object") ? options : {});
}

const defaultFraudDetectionSentinel = new FraudDetectionSentinel();

module.exports = {
  FraudDetectionSentinel,
  createFraudDetectionSentinel,
  fraudDetectionSentinel: defaultFraudDetectionSentinel
};
