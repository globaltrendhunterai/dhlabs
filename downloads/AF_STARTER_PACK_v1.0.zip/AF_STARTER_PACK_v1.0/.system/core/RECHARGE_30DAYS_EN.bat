@echo off
chcp 65001 >nul
rem AutoFlow Engine - License Top-Up Quick Launcher (Windows Universal Edition)
setlocal enabledelayedexpansion

cd /d "%~dp0"

echo ============================================================
echo [AutoFlow Universal Self-Healing Engine License Top-Up]
echo ============================================================

set "NODE_BIN="
if exist "%~dp0bin\node.exe" (
    set "NODE_BIN=%~dp0bin\node.exe"
) else if exist "%~dp0..\bin\node.exe" (
    set "NODE_BIN=%~dp0..\bin\node.exe"
) else (
    where node >nul 2>nul
    if !errorlevel! equ 0 set "NODE_BIN=node"
)

if "!NODE_BIN!"=="" (
    echo [*] Auto-downloading portable Node.js runtime ^(node-v20.18.0-win-x64^)...
    if not exist "%~dp0bin" mkdir "%~dp0bin"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference = 'SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $zipUrl = 'https://nodejs.org/dist/v20.18.0/node-v20.18.0-win-x64.zip'; $zipPath = Join-Path '%~dp0' 'bin\node_win_x64.zip'; $extractDir = Join-Path '%~dp0' 'bin\node_extract_tmp'; Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing; if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }; Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force; Copy-Item -Path (Join-Path $extractDir 'node-v20.18.0-win-x64\node.exe') -Destination (Join-Path '%~dp0' 'bin\node.exe') -Force; Remove-Item $zipPath -Force -ErrorAction SilentlyContinue; Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue"
    if exist "%~dp0bin\node.exe" (
        set "NODE_BIN=%~dp0bin\node.exe"
    ) else (
        echo [ERROR] Failed to download portable Node.js runtime. Please check your internet connection.
        pause
        exit /b 1
    )
)

set "SCRIPT_FILE=%~dp0recharge_cli.js"
if not exist "!SCRIPT_FILE!" (
    if exist "%~dp0core\recharge_cli.js" set "SCRIPT_FILE=%~dp0core\recharge_cli.js"
)

echo.
echo Select the duration of the license you purchased:
echo   [1] 30-Day Starter Top-Up (+30 days)
echo   [2] 90-Day Pro Top-Up (+90 days)
echo   [3] 180-Day Semi-Annual Top-Up (+180 days)
echo   [Enter] Default to 30 days
set /p USER_CHOICE="Enter choice (1/2/3 or days) [Default: 1]: "

set DAYS=30
if "!USER_CHOICE!"=="2" set DAYS=90
if "!USER_CHOICE!"=="90" set DAYS=90
if "!USER_CHOICE!"=="3" set DAYS=180
if "!USER_CHOICE!"=="180" set DAYS=180

echo.
set /p USER_KEY="Enter your Gumroad License Key (optional, press Enter to skip): "
if "!USER_KEY!"=="" set USER_KEY=GUMROAD_TOPUP_%RANDOM%

echo.
"!NODE_BIN!" "!SCRIPT_FILE!" !DAYS! "!USER_KEY!" "Gumroad Top-Up (+!DAYS! days)" --lang=en

echo.
pause
