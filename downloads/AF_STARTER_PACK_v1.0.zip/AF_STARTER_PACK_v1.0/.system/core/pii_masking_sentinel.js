/**
 * core/pii_masking_sentinel.js
 * 
 * AutoFlow 개인정보보호법 제16조/제29조 안심 수호 센티널 (PII Masking Guardian)
 * 
 * 1. 고객 성명 마스킹 (2자: 홍*, 3자: 홍*동, 4자: 남궁**, 영문 앞뒤 제외 마스킹)
 * 2. 전화번호 마스킹 (010-****-5678 등 중간 3~4자리 마스킹)
 * 3. 배송지 주소 마스킹 (시/군/구/도로명 보존, 상세 동·호수/지번 마스킹)
 * 4. 공공장소/직장 내 메신저 팝업 화면 노출(Shoulder Surfing) 원천 방어
 */

class PiiMaskingSentinel {
  /**
   * 고객 성명 안심 마스킹
   * @param {string} name 
   * @returns {string}
   */
  maskName(name) {
    if (!name || typeof name !== "string") return name || "";
    const clean = name.trim();
    if (clean.length <= 1) return clean;
    if (clean.length === 2) {
      return clean[0] + "*";
    }
    if (clean.length === 3) {
      return clean[0] + "*" + clean[2];
    }
    if (clean.length === 4) {
      return clean.slice(0, 2) + "**";
    }
    // 5자 이상 또는 영문명 (앞 2자 + 가운데 마스킹 + 끝 1자)
    const midLen = Math.max(1, clean.length - 3);
    return clean.slice(0, 2) + "*".repeat(midLen) + clean.slice(-1);
  }

  /**
   * 전화번호 안심 마스킹
   * @param {string} phone 
   * @returns {string}
   */
  maskPhone(phone) {
    if (!phone || typeof phone !== "string") return phone || "";
    const clean = phone.trim();

    // 하이픈 포함 형식 (예: 010-1234-5678, 02-123-4567)
    if (clean.includes("-")) {
      const parts = clean.split("-");
      if (parts.length === 3) {
        return `${parts[0]}-${"*".repeat(parts[1].length)}-${parts[2]}`;
      }
    }

    // 하이픈 없는 10~11자리 숫자 형식 (예: 01012345678)
    const digitsOnly = clean.replace(/[^0-9]/g, "");
    if (digitsOnly.length === 11) {
      return digitsOnly.slice(0, 3) + "****" + digitsOnly.slice(7);
    } else if (digitsOnly.length === 10) {
      return digitsOnly.slice(0, 3) + "***" + digitsOnly.slice(6);
    }

    return clean;
  }

  /**
   * 배송지 주소 안심 마스킹
   * 시/도/구/동/도로명까지 표시하고 상세 번호/호수는 마스킹
   * @param {string} address 
   * @returns {string}
   */
  maskAddress(address) {
    if (!address || typeof address !== "string") return address || "";
    const clean = address.trim();
    const tokens = clean.split(/\s+/);
    if (tokens.length <= 2) {
      return clean;
    }

    // 앞 2~3단어(시/도/구/로)는 유지하고 뒤쪽 상세 지번/아파트/동·호수는 마스킹
    const preservedCount = Math.min(3, Math.max(2, tokens.length - 2));
    const preserved = tokens.slice(0, preservedCount).join(" ");
    return `${preserved} (상세주소 보호)`;
  }

  /**
   * 주문 객체 전체 PII 안심 마스킹 변환
   * @param {Object} order 
   * @param {boolean} enabled 
   * @returns {Object}
   */
  maskOrder(order, enabled = true) {
    if (!order || typeof order !== "object") return order;
    if (!enabled) return { ...order };

    const masked = { ...order };

    if (masked.customerName) masked.customerName = this.maskName(masked.customerName);
    if (masked.receiverName) masked.receiverName = this.maskName(masked.receiverName);
    if (masked.buyerName) masked.buyerName = this.maskName(masked.buyerName);

    if (masked.customerPhone) masked.customerPhone = this.maskPhone(masked.customerPhone);
    if (masked.receiverPhone) masked.receiverPhone = this.maskPhone(masked.receiverPhone);
    if (masked.buyerPhone) masked.buyerPhone = this.maskPhone(masked.buyerPhone);

    if (masked.shippingAddress) masked.shippingAddress = this.maskAddress(masked.shippingAddress);
    if (masked.address) masked.address = this.maskAddress(masked.address);

    return masked;
  }
}

const defaultPiiSentinel = new PiiMaskingSentinel();

module.exports = {
  PiiMaskingSentinel,
  piiMaskingSentinel: defaultPiiSentinel
};
