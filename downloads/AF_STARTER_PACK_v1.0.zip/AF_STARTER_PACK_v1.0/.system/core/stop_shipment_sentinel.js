/**
 * AutoFlow Stop-Shipment Airbag Sentinel
 * 
 * [설계 목적]
 * 구매자가 쿠팡에서 주문 후 택배 포장/발송 직전에 [주문 취소] 또는 [반품/교환]을 요청할 경우,
 * 셀러가 이를 실시간으로 인지하지 못하고 상품을 출고해버려 발생하는 편도/왕복 택배비 손실 및
 * 고객 분쟁(CS)을 1초 만에 원천 차단하는 긴급 출고 보류(Stop-Shipment) 에어백 가드.
 * 
 * [주요 기능]
 * 1. 실시간 취소/반품 요청 상태(CANCEL_REQUEST, RETURN_REQUEST) 즉시 감지
 * 2. 텔레그램/슬랙 긴급 다이렉트 출고 보류 경보 발송 포맷팅
 * 3. 출고 보류 대상 주문 실시간 큐 관리 및 영속화 (logs/stop_shipment_orders.json)
 * 4. 셋업 마법사 1초 보류 목록 조회 및 원클릭 출고 확인 처리
 */

const fs = require("fs");
const path = require("path");

class StopShipmentSentinel {
  constructor(options = {}) {
    this.storagePath = options.storagePath || path.join(__dirname, "..", "logs", "stop_shipment_orders.json");
    this.maxOrders = options.maxOrders || 200;
  }

  _ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(this.storagePath, JSON.stringify([], null, 2), "utf8");
      }
    } catch (e) {
      console.error("[StopShipmentSentinel] 저장소 초기화 실패 (non-fatal):", e.message);
    }
  }

  getStopShipmentOrders() {
    this._ensureStorage();
    try {
      if (fs.existsSync(this.storagePath)) {
        const data = fs.readFileSync(this.storagePath, "utf8");
        const list = JSON.parse(data);
        if (Array.isArray(list)) return list;
      }
    } catch (e) {
      console.error("[StopShipmentSentinel] 주문 목록 로드 실패 (non-fatal):", e.message);
    }
    return [];
  }

  /**
   * 주문 목록 중 취소/반품 요청 주문을 감지하여 출고 보류 큐에 등록
   * @param {Array} rawOrders - 쿠팡 WING 주문 목록
   * @returns {Array} 새로 감지된 출고 보류 주문 목록
   */
  detectStopShipments(rawOrders = []) {
    this._ensureStorage();
    if (!Array.isArray(rawOrders) || rawOrders.length === 0) {
      return [];
    }

    const currentList = this.getStopShipmentOrders();
    const existingIds = new Set(currentList.map(item => String(item.orderId)));
    const newlyDetected = [];

    const nowIso = new Date().toISOString();

    for (const order of rawOrders) {
      if (!order) continue;
      const orderId = String(order.orderId || order.order_id || "");
      if (!orderId) continue;

      const status = String(order.status || order.orderStatus || "").toUpperCase();
      const cancelReason = order.cancelReason || order.reason || "구매자 단순 변심/배송지 변경 요청";
      const receiverName = order.receiverName || order.receiver_name || "고객";
      const productName = order.productName || order.product_name || "상품";

      const isCancelRequest = status.includes("CANCEL") || status.includes("취소");
      const isReturnRequest = status.includes("RETURN") || status.includes("반품");

      if ((isCancelRequest || isReturnRequest) && !existingIds.has(orderId)) {
        const item = {
          orderId,
          type: isCancelRequest ? "CANCEL_REQUEST" : "RETURN_REQUEST",
          typeText: isCancelRequest ? "주문 취소 요청" : "반품/교환 요청",
          status,
          receiverName,
          productName,
          cancelReason,
          detectedAt: nowIso,
          resolved: false
        };

        newlyDetected.push(item);
        currentList.unshift(item);
        existingIds.add(orderId);
      }
    }

    if (newlyDetected.length > 0) {
      try {
        const trimmed = currentList.slice(0, this.maxOrders);
        fs.writeFileSync(this.storagePath, JSON.stringify(trimmed, null, 2), "utf8");
      } catch (e) {
        console.error("[StopShipmentSentinel] 보류 목록 저장 실패 (non-fatal):", e.message);
      }
    }

    return newlyDetected;
  }

  /**
   * 출고 보류 대상 긴급 경보 메시지 포맷팅
   */
  formatStopShipmentAlert(order) {
    if (!order) return "";
    return [
      "🛑 [긴급 출고 보류 안내 — 포장/발송을 즉시 중단하십시오]",
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
      `• 주문번호: ${order.orderId}`,
      `• 요청구분: ${order.typeText || '취소 요청'}`,
      `• 수령인: ${order.receiverName || '고객'}`,
      `• 상품명: ${order.productName || '상품'}`,
      `• 요청사유: ${order.cancelReason || '구매자 요청'}`,
      `• 감지시각: ${order.detectedAt || new Date().toISOString()}`,
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
      "⚠️ 이미 송장이 발행되었더라도 택배 기사님 인계를 중단하세요.",
      "오발송 시 발생하는 왕복 배송비 및 반품 분쟁을 예방합니다."
    ].join("\n");
  }

  /**
   * 특정 보류 주문을 조치 완료(Resolved) 처리
   */
  resolveOrder(orderId) {
    this._ensureStorage();
    const currentList = this.getStopShipmentOrders();
    let found = false;

    for (const item of currentList) {
      if (String(item.orderId) === String(orderId)) {
        item.resolved = true;
        item.resolvedAt = new Date().toISOString();
        found = true;
        break;
      }
    }

    if (found) {
      try {
        fs.writeFileSync(this.storagePath, JSON.stringify(currentList, null, 2), "utf8");
      } catch (e) {
        console.error("[StopShipmentSentinel] 조치 상태 저장 실패 (non-fatal):", e.message);
      }
    }
    return found;
  }

  /**
   * 모의 취소 주문 주입 (테스트 및 셀러 검증용)
   */
  injectSimulatedCancelOrder(customId = null) {
    const simId = customId || `SIM-CANCEL-${Date.now().toString().slice(-6)}`;
    const simOrder = [{
      orderId: simId,
      status: "CANCEL_REQUEST",
      receiverName: "이*희",
      productName: "프리미엄 무선 블루투스 마우스 (블랙)",
      cancelReason: "배송지 변경 후 재주문 요청"
    }];
    return this.detectStopShipments(simOrder);
  }
}

const defaultStopShipmentSentinel = new StopShipmentSentinel();

module.exports = {
  StopShipmentSentinel,
  stopShipmentSentinel: defaultStopShipmentSentinel
};
