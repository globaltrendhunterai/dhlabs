#!/bin/bash
# AutoFlow Engine - 30-Day Complimentary Trial Activation Launcher (macOS Global Edition)
xattr -dr com.apple.quarantine "$(cd "$(dirname "$0")" && pwd)" 2>/dev/null || true
cd "$(dirname "$0")"
chmod +x ./bin/node ../bin/node 2>/dev/null || true

echo "============================================================"
echo "[AutoFlow Self-Healing Engine 30-Day Free Trial Activation]"
echo "============================================================"

# Resolve node executable (./bin/node -> ../bin/node -> /opt/homebrew/bin/node -> /usr/local/bin/node -> command -v node)
NODE_BIN=""
for candidate in "./bin/node" "../bin/node" "/opt/homebrew/bin/node" "/usr/local/bin/node"; do
  if [ -x "$candidate" ] && "$candidate" -v >/dev/null 2>&1; then
    NODE_BIN="$candidate"
    break
  fi
done
if [ -z "$NODE_BIN" ] && command -v node >/dev/null 2>&1; then
  CANDIDATE_CMD="$(command -v node)"
  if "$CANDIDATE_CMD" -v >/dev/null 2>&1; then
    NODE_BIN="$CANDIDATE_CMD"
  fi
fi

if [ -z "$NODE_BIN" ]; then
  echo "[ERROR] Node.js runtime not detected. Please install Node.js from https://nodejs.org"
  if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
    read -p "Press [Enter] to exit..."
  fi
  exit 1
fi

SCRIPT_FILE="activate_trial_cli.js"
if [ ! -f "$SCRIPT_FILE" ] && [ -f "./core/activate_trial_cli.js" ]; then
  SCRIPT_FILE="./core/activate_trial_cli.js"
fi

"$NODE_BIN" "$SCRIPT_FILE" 30 "GUMROAD_FREE_TRIAL" "30-Day Complimentary Engine Trial" --lang=en

echo ""
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "Press [Enter] to close this window..."
fi
