'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT_DIR = path.resolve(__dirname, '..');

const PRIMARY_HTML_FILES = [
  'setup_wizard.html',
  'checkout.html',
  'index.html',
  'catalog/WORKFLOW_MENU_BOARD.html',
  'autoflow_rust/static/recon_quarantine_viewer.html',
  'autoflow_web/static/autoflow.html',
  'autoflow_web/static/picflow.html',
  'autoflow_web/static/reconflow.html',
  'autoflow_web/static/order_success.html',
  'autoflow_web/static/order_fail.html',
  'autoflow_web/static/refund.html',
  'autoflow_web/static/terms.html',
  'autoflow_web/static/privacy.html',
  'master_control_console.html'
];

const SYNC_GROUPS = [
  {
    master: 'setup_wizard.html',
    targets: [
      'autoflow_rust/static/setup_wizard.html',
      'autoflow_web/static/setup_wizard.html',
      'dist/cloudflare_pages/setup_wizard.html',
      'docs/setup_wizard.html',
      'dist/common_assets/setup_wizard.html',
      'dist/AF_STARTER_PACK_v1.0/setup_wizard.html',
      'dist/AF_STARTER_PACK_v1.0/static/setup_wizard.html'
    ]
  },
  {
    master: 'checkout.html',
    targets: [
      'autoflow_rust/static/checkout.html',
      'autoflow_web/static/checkout.html',
      'dist/cloudflare_pages/checkout.html',
      'docs/checkout.html'
    ]
  },
  {
    master: 'index.html',
    targets: [
      'autoflow_rust/static/index.html',
      'autoflow_web/static/index.html',
      'dist/cloudflare_pages/index.html',
      'dist/index.html'
    ]
  },
  {
    master: 'autoflow_rust/static/recon_quarantine_viewer.html',
    targets: [
      'autoflow_web/static/recon_quarantine_viewer.html',
      'dist/cloudflare_pages/recon_quarantine_viewer.html'
    ]
  },
  {
    master: 'catalog/WORKFLOW_MENU_BOARD.html',
    targets: [
      'autoflow_rust/static/WORKFLOW_MENU_BOARD.html',
      'autoflow_web/static/WORKFLOW_MENU_BOARD.html',
      'dist/cloudflare_pages/WORKFLOW_MENU_BOARD.html',
      'dist/AF_STARTER_PACK_v1.0/static/WORKFLOW_MENU_BOARD.html'
    ]
  },
  {
    master: 'autoflow_web/static/autoflow.html',
    targets: [
      'autoflow_rust/static/autoflow.html',
      'dist/cloudflare_pages/autoflow.html'
    ]
  },
  {
    master: 'autoflow_web/static/picflow.html',
    targets: [
      'autoflow_rust/static/picflow.html',
      'dist/cloudflare_pages/picflow.html'
    ]
  },
  {
    master: 'autoflow_web/static/reconflow.html',
    targets: [
      'autoflow_rust/static/reconflow.html',
      'dist/cloudflare_pages/reconflow.html'
    ]
  },
  {
    master: 'autoflow_web/static/order_success.html',
    targets: [
      'autoflow_rust/static/order_success.html',
      'dist/cloudflare_pages/order_success.html'
    ]
  },
  {
    master: 'autoflow_web/static/order_fail.html',
    targets: [
      'autoflow_rust/static/order_fail.html',
      'dist/cloudflare_pages/order_fail.html'
    ]
  }
];

function createDomSandbox(customInputOverrides = {}) {
  const elStore = new Map();
  let inputMode = customInputOverrides.inputMode || 'NORMAL';
  let networkMode = customInputOverrides.networkMode || 'ONLINE';
  let fetchCallCount = 0;

  const getDynamicValue = (id) => {
    if (inputMode === 'ADVERSARIAL_BOUNDARY') {
      if (/date|time|at|deadline/i.test(id)) return 'INVALID_DATE_VALUE_###';
      if (/price|amount|qty|count|weight|height|days/i.test(id)) return '-999999999';
      if (/ticket|key|serial/i.test(id)) return 'AF-TKT-v1.corrupt_base64_@@@.bad_sig';
      return '';
    }
    return 'test_value';
  };

  const makeEl = (id = '') => {
    if (id && elStore.has(id)) return elStore.get(id);
    const targetObj = {
      id,
      value: getDynamicValue(id),
      className: 'fa-solid fa-check',
      textContent: 'test',
      innerText: 'test',
      innerHTML: '<div></div>',
      checked: true,
      disabled: false,
      files: [{ name: 'test.json', size: 100 }],
      style: new Proxy({}, { set: (o, k, v) => { o[k] = v; return true; }, get: (o, k) => o[k] || '' }),
      dataset: new Proxy({ tier: 'MANAGED_PRO', cycle: 'MONTHLY', filter: 'ALL' }, { get: (o, k) => o[k] || '1' }),
      classList: {
        _classes: new Set(['active']),
        add(...c) { c.forEach(x => this._classes.add(x)); },
        remove(...c) { c.forEach(x => this._classes.delete(x)); },
        toggle(c, force) {
          if (force === undefined) {
            if (this._classes.has(c)) { this._classes.delete(c); return false; }
            this._classes.add(c); return true;
          }
          if (force) this._classes.add(c); else this._classes.delete(c);
          return Boolean(force);
        },
        contains(c) { return this._classes.has(c); }
      },
      getAttribute: (k) => (k === 'href' ? '#test' : '1'),
      setAttribute: () => {},
      removeAttribute: () => {},
      addEventListener: () => {},
      removeEventListener: () => {},
      appendChild: () => makeEl(),
      removeChild: () => {},
      insertBefore: () => {},
      remove: () => {},
      focus: () => {},
      blur: () => {},
      click: () => {},
      select: () => {},
      scrollIntoView: () => {},
      closest: () => makeEl(),
      querySelector: () => makeEl(),
      querySelectorAll: () => [],
      getBoundingClientRect: () => ({ top: 0, left: 0, width: 100, height: 40, bottom: 40, right: 100 }),
      contentWindow: { focus: () => {}, print: () => {} },
      contentDocument: { open: () => {}, write: () => {}, close: () => {} },
      parentElement: null,
      parentNode: null,
      children: [],
      options: [{ value: '1', text: 'opt' }],
      selectedIndex: 0
    };
    const proxy = new Proxy(targetObj, {
      get(t, prop) {
        if (prop === 'value' && inputMode === 'ADVERSARIAL_BOUNDARY') {
          return getDynamicValue(id);
        }
        if (prop === 'parentElement' || prop === 'parentNode') return makeEl();
        if (prop in t) return t[prop];
        return () => {};
      },
      set(t, prop, val) {
        t[prop] = val;
        return true;
      }
    });
    if (id) elStore.set(id, proxy);
    return proxy;
  };

  const listeners = { DOMContentLoaded: [], keydown: [], click: [], load: [] };
  const docObj = {
    getElementById: (id) => makeEl(id),
    getElementsByName: () => [makeEl('radio1'), makeEl('radio2')],
    getElementsByClassName: () => [makeEl('cls1')],
    getElementsByTagName: () => [makeEl('tag1')],
    querySelector: (sel) => makeEl(sel),
    querySelectorAll: () => [makeEl('q1'), makeEl('q2')],
    createElement: (tag) => makeEl(tag),
    createTextNode: () => makeEl('text'),
    addEventListener: (ev, fn) => { if (listeners[ev]) listeners[ev].push(fn); },
    removeEventListener: () => {},
    body: makeEl('body'),
    documentElement: makeEl('html'),
    head: makeEl('head'),
    cookie: '',
    hidden: false,
    visibilityState: 'visible',
    execCommand: () => true
  };

  const storageMap = new Map();
  const storage = {
    getItem: (k) => (storageMap.has(k) ? storageMap.get(k) : null),
    setItem: (k, v) => { storageMap.set(k, String(v)); },
    removeItem: (k) => { storageMap.delete(k); },
    clear: () => { storageMap.clear(); }
  };

  const windowObj = {
    document: docObj,
    localStorage: storage,
    sessionStorage: storage,
    performance: { now: () => Date.now() },
    matchMedia: () => ({ matches: false, addListener: () => {}, removeListener: () => {}, addEventListener: () => {}, removeEventListener: () => {} }),
    navigator: {
      clipboard: { writeText: async () => {} },
      userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X)',
      language: customInputOverrides.language || 'ko-KR'
    },
    location: {
      href: 'http://localhost:5678/',
      origin: 'http://localhost:5678',
      pathname: '/',
      search: '?sku=EC-01&tier=MANAGED_PRO&orderId=ORD-TEST-01',
      hash: '',
      reload: () => {},
      assign: () => {},
      replace: () => {}
    },
    history: { pushState: () => {}, replaceState: () => {} },
    fetch: async (urlStr) => {
      fetchCallCount++;
      if (networkMode === 'OFFLINE_DROP') {
        throw new Error('NETWORK_DISCONNECTED_DURING_WAVE_6');
      }
      const isHeartbeat = String(urlStr || '').includes('heartbeat');
      return {
        ok: true,
        status: 200,
        headers: { get: () => 'application/json' },
        json: async () => ({
          success: true,
          status: isHeartbeat ? 'HEALTHY' : 'SUCCESS',
          changed: true,
          hash: 'a1b2c3d4',
          items: [],
          quarantined_items: [
            {
              trace_id: 'TRACE-WAVE-01',
              quarantined_at: '2026-10-17T12:00:00.000Z',
              module_code: 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD',
              cause_code: 'MARKETPLACE_FEE_OVERCHARGE_DETECTED',
              status: 'AWAITING_RECON_APPROVAL',
              error_log: '수수료율 13.8% 초과 징수 감지 (계약 10.8%)'
            }
          ],
          modules: [],
          data: {
            dashboard: {
              daemon: { pid: 1234, bound_port: 15679, active_profile: 'KR', uptime_formatted: '120s' },
              self_healing: { heal_count: 3, defended_faults: 3, dlq_count: 0, health_pulse: 'HEALTHY', response_time_ms: 127 },
              reconciliation: { matrix_status: 'MATCHED', matching_rate: 100 },
              risk_matrix: { total_defended_count: 128, total_defended_amount_krw: 3840000 },
              license: { hwid: 'HWID-TEST', guarantee: 'Permanent Active' }
            },
            pipeline: { workflow_name: 'AutoFlow Pipeline', nodes: [] }
          },
          rates: { KRW: 1, USD: 0.00075, JPY: 0.11, EUR: 0.00068 },
          order: { order_id: 'ORD-1', status: 'PAID', workflow_id: 'WF-1', paid_amount: 189000, license_key: 'AF-PRO-TESTKEY-2026' },
          settings: {},
          config: {},
          evaluations: [],
          logs: [],
          entries: [],
          nodes: [{ id: 'n1', name: 'Coupang Order Trigger', type: 'webhook', status: 'ACTIVE' }],
          active_node_scope: { activeNodeCount: 1, granularModuleCount: 16, recommendedGranularBitmask: 229359 }
        }),
        text: async () => '{}',
        blob: async () => ({})
      };
    },
    setInterval: () => 1,
    clearInterval: () => {},
    setTimeout: (fn) => {
      if (customInputOverrides.flushTimeoutsImmediately && typeof fn === 'function') {
        try { fn(); } catch (e) {}
      }
      return 1;
    },
    clearTimeout: () => {},
    requestAnimationFrame: () => 1,
    alert: () => {},
    confirm: () => true,
    prompt: () => '',
    open: () => ({ document: { write() {}, close() {} }, focus() {}, print() {}, close() {} }),
    print: () => {},
    scrollTo: () => {},
    addEventListener: (ev, fn) => { if (listeners[ev]) listeners[ev].push(fn); },
    removeEventListener: () => {},
    IntersectionObserver: function () { return { observe() {}, unobserve() {}, disconnect() {} }; },
    MutationObserver: function () { return { observe() {}, disconnect() {} }; },
    URLSearchParams,
    URL: Object.assign(URL, { createObjectURL: () => 'blob:mock', revokeObjectURL: () => {} }),
    Blob: function () {},
    FileReader: function () { this.readAsText = () => {}; this.readAsDataURL = () => {}; },
    FormData: function () { return { append() {} }; },
    AbortController: function () { return { signal: {}, abort() {} }; },
    Event: function (t) {
      this.type = t;
      this.preventDefault = () => {};
      this.stopPropagation = () => {};
      this.target = makeEl('target');
      this.currentTarget = makeEl('currentTarget');
    },
    CustomEvent: function (t, o) { this.type = t; this.detail = o && o.detail; },
    Chart: function () { return { update() {}, destroy() {} }; },
    TossPayments: function () {
      return {
        requestPayment: async () => {},
        widgets: () => ({
          setAmount: async () => {},
          renderPaymentMethods: async () => {},
          renderAgreement: async () => {},
          requestPayment: async () => {}
        })
      };
    },
    console: { log() {}, warn() {}, error() {}, info() {} },
    Math, Date, JSON, Object, Array, String, Number, Boolean, RegExp, Map, Set, Promise,
    Error, TypeError, ReferenceError, SyntaxError, RangeError, Uint8Array, Int32Array, ArrayBuffer,
    parseInt, parseFloat, isNaN, isFinite, encodeURIComponent, decodeURIComponent, encodeURI, decodeURI,
    btoa: s => Buffer.from(String(s)).toString('base64'),
    atob: s => Buffer.from(String(s), 'base64').toString('utf8')
  };
  windowObj.window = windowObj;
  windowObj.globalThis = windowObj;
  windowObj.self = windowObj;
  windowObj.event = new windowObj.Event('click');

  return {
    sandbox: vm.createContext(windowObj),
    listeners,
    windowObj,
    makeEl,
    elStore,
    setInputMode: (m) => { inputMode = m; },
    setNetworkMode: (m) => { networkMode = m; },
    getFetchCallCount: () => fetchCallCount
  };
}

/**
 * 자유의지 기반 1차~10차 맥락 변수 적응형 & 연쇄 변이 재귀 점검 엔진
 * (Autonomous 10-Wave Context-Adaptive & State-Mutation Recursive Inspector)
 *
 * 고정된 10개 체크리스트만 기계적으로 확인하는 방식이 아니라:
 *  - Wave 1에서 현재 코드베이스의 모든 상태 변수·함수·DOM·라우트 그래프를 동적으로 추출(ΔV1)하고,
 *  - Wave 2~9에서 이전 차수의 실행 결과와 상태 변이(ΔV_k)를 다음 차수의 입력 변수로 연쇄 주입하며,
 *  - Wave 10에서 누적된 모든 변이(∑ΔV_1..9) 위에서 재검증을 수행해 무결점 수렴(Fixed-Point Convergence)을 실측한다.
 */
function runTenPassDetailAuditSync(rootDir = ROOT_DIR, customContext = {}) {
  const passResults = {};
  const waves = [];
  const stateDeltas = {};
  const errors = [];

  let pass1MissingHandlers = [];
  let pass4DuplicateIds = [];
  let pass5UnmatchedDomAccess = [];
  let pass6RuntimeErrors = [];
  let pass6HandlerErrors = [];
  let totalHandlersExecuted = 0;

  const fileContexts = new Map();
  const discoveredApiPaths = new Set();

  // ============================================================================
  // WAVE 1: Context Discovery & Live State/Symbol Graph Extraction (-> ΔV1)
  // ============================================================================
  let totalDiscoveredMutableVars = 0;
  let totalDiscoveredFunctions = 0;

  for (const rel of PRIMARY_HTML_FILES) {
    const full = path.join(rootDir, rel);
    if (!fs.existsSync(full)) continue;
    const src = fs.readFileSync(full, 'utf8');
    const htmlOnly = src.replace(/<script[\s\S]*?<\/script>/gi, '');
    const scripts = [...src.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/gi)];

    const ids = [...htmlOnly.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
    const allIdsInFile = new Set([...src.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]));
    const idCounts = {};
    ids.forEach(id => { idCounts[id] = (idCounts[id] || 0) + 1; });
    for (const [id, count] of Object.entries(idCounts)) {
      if (count > 1) pass4DuplicateIds.push(`${rel}#${id}(x${count})`);
    }

    const jsBodies = [];
    scripts.forEach(m => {
      const attrs = m[1] || '';
      if (!/src=|application\/ld\+json|application\/json/i.test(attrs)) {
        jsBodies.push(m[2]);
      }
    });
    const allJs = jsBodies.join('\n');

    const mutableVars = [...new Set([...allJs.matchAll(/(?:let|var)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=/g)].map(m => m[1]))];
    const declaredFns = [...new Set([...allJs.matchAll(/function\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*\(/g)].map(m => m[1]))];
    totalDiscoveredMutableVars += mutableVars.length;
    totalDiscoveredFunctions += declaredFns.length;

    const handlers = [...new Set([
      ...[...htmlOnly.matchAll(/\bon(?:click|change|input|submit)="([^"]+)"/g)].map(m => m[1]),
      ...[...htmlOnly.matchAll(/\bon(?:click|change|input|submit)='([^']+)'/g)].map(m => m[1])
    ])];

    for (const h of handlers) {
      const fnMatch = h.match(/^\s*(?:return\s+)?([a-zA-Z_$][a-zA-Z0-9_$]*)\s*\(/);
      if (fnMatch) {
        const fn = fnMatch[1];
        if (['if', 'window', 'document', 'console', 'alert', 'confirm', 'history', 'location', 'navigator', 'localStorage', 'sessionStorage', 'setTimeout', 'clearTimeout', 'event', 'this'].includes(fn)) continue;
        const defRe = new RegExp(`(?:function\\s+${fn}\\b|(?:const|let|var)\\s+${fn}\\s*=|window\\.${fn}\\s*=)`);
        if (!defRe.test(allJs)) {
          pass1MissingHandlers.push(`${rel}:${fn}`);
        }
      }
    }

    for (const m of allJs.matchAll(/document\.getElementById\(\s*["']([^"']+)["']\s*\)\s*\./g)) {
      const targetId = m[1];
      if (!allIdsInFile.has(targetId) && !allJs.includes(targetId)) {
        pass5UnmatchedDomAccess.push(`${rel}#${targetId}`);
      }
    }

    if (['setup_wizard.html', 'autoflow_rust/static/recon_quarantine_viewer.html', 'checkout.html'].includes(rel)) {
      for (const m of src.matchAll(/["'`](\/api\/[a-zA-Z0-9_\/-]+)(?:\?[^"'`]*)?["'`]/g)) {
        discoveredApiPaths.add(m[1]);
      }
    }

    fileContexts.set(rel, {
      rel,
      src,
      scripts,
      handlers,
      mutableVars,
      declaredFns,
      allIdsInFile
    });
  }

  stateDeltas.deltaV1_discoveredContext = {
    filesAnalyzed: fileContexts.size,
    totalDiscoveredMutableVars,
    totalDiscoveredFunctions,
    totalDiscoveredApiPaths: discoveredApiPaths.size
  };

  // ============================================================================
  // WAVE 2: Pre-Initialization & Temporal Order Perturbation (ΔV1 -> ΔV2)
  //   - Executes scripts on an English-locale / pre-fetch timing context BEFORE
  //     DOMContentLoaded or async fetch resolution, then invokes early-callable
  //     functions while state variables (lastHeartbeatData, paymentWidget, etc.) are still null.
  // ============================================================================
  let wave2PreInitErrors = [];
  for (const [rel, ctx] of fileContexts.entries()) {
    const env = createDomSandbox({ language: 'en-US' });
    ctx.env = env;

    ctx.scripts.forEach((m, idx) => {
      const attrs = m[1] || '';
      if (/src=|application\/ld\+json|application\/json/i.test(attrs)) return;
      try {
        vm.runInContext(m[2], env.sandbox, { filename: `${rel}#script${idx}`, timeout: 2500 });
      } catch (e) {
        pass6RuntimeErrors.push(`${rel}#script${idx}: ${e.name}: ${e.message}`);
        wave2PreInitErrors.push(`${rel}#script${idx}: ${e.name}: ${e.message}`);
      }
    });

    // Early invocation before DOMContentLoaded / before fetch resolves (null-state stress test)
    const earlyProbeCalls = [
      "if (typeof setLang === 'function') { setLang('en'); setLang('ko'); }",
      "if (typeof updateHeartbeatDisplay === 'function') { updateHeartbeatDisplay(); }",
      "if (typeof selectTier === 'function') { selectTier('MANAGED_PRO'); }",
      "if (typeof switchCatalogView === 'function') { switchCatalogView('MASTER'); }",
      "if (typeof setQuarantineModuleFilter === 'function') { setQuarantineModuleFilter('MOD_P'); setQuarantineModuleFilter('ALL'); }"
    ];
    for (const probe of earlyProbeCalls) {
      try {
        vm.runInContext(probe, env.sandbox, { timeout: 1000 });
      } catch (e) {
        wave2PreInitErrors.push(`${rel}[PreInit:${probe}]: ${e.name}: ${e.message}`);
        pass6RuntimeErrors.push(`${rel}[PreInit]: ${e.name}: ${e.message}`);
      }
    }
  }
  stateDeltas.deltaV2_preInitTiming = {
    earlyProbesVerified: fileContexts.size * 5,
    preInitErrors: wave2PreInitErrors.length
  };

  // ============================================================================
  // WAVE 3: Boot Lifecycle & Inline Event Handler State-Space Execution (ΔV2 -> ΔV3)
  // ============================================================================
  for (const [rel, ctx] of fileContexts.entries()) {
    const { env, handlers } = ctx;
    for (const fn of env.listeners.DOMContentLoaded) {
      try {
        const r = fn(new env.windowObj.Event('DOMContentLoaded'));
        if (r && typeof r.catch === 'function') {
          r.catch(e => { pass6RuntimeErrors.push(`${rel}#DOMContentLoaded: ${e.name}: ${e.message}`); });
        }
      } catch (e) {
        pass6RuntimeErrors.push(`${rel}#DOMContentLoaded: ${e.name}: ${e.message}`);
      }
    }
    if (typeof env.windowObj.onload === 'function') {
      try {
        const r = env.windowObj.onload(new env.windowObj.Event('load'));
        if (r && typeof r.catch === 'function') {
          r.catch(e => { pass6RuntimeErrors.push(`${rel}#window.onload: ${e.name}: ${e.message}`); });
        }
      } catch (e) {
        pass6RuntimeErrors.push(`${rel}#window.onload: ${e.name}: ${e.message}`);
      }
    }

    for (const h of handlers) {
      totalHandlersExecuted++;
      try {
        const res = vm.runInContext(
          `(function(event){ ${h} }).call(__mockBtn, event)`,
          Object.assign(env.sandbox, { __mockBtn: env.makeEl('btn') }),
          { timeout: 1000 }
        );
        if (res && typeof res.catch === 'function') {
          res.catch(e => { pass6HandlerErrors.push(`${rel}[${h}]: Async ${e.name}: ${e.message}`); });
        }
      } catch (e) {
        pass6HandlerErrors.push(`${rel}[${h}]: ${e.name}: ${e.message}`);
      }
    }
  }
  stateDeltas.deltaV3_handlerExecution = {
    totalHandlersExecuted,
    runtimeErrors: pass6RuntimeErrors.length,
    handlerErrors: pass6HandlerErrors.length
  };

  // ============================================================================
  // WAVE 4: Adversarial & Boundary Input Perturbation on Mutated State (ΔV3 -> ΔV4)
  //   - Now that Wave 3 has mutated the sandbox state, switch DOM inputs to
  //     ADVERSARIAL_BOUNDARY mode (invalid dates, negative numbers, corrupt tickets, empty strings)
  //     and re-execute handlers to verify nothing crashes on hostile user input!
  // ============================================================================
  let wave4AdversarialErrors = [];
  let adversarialRuns = 0;
  for (const [rel, ctx] of fileContexts.entries()) {
    if (!['setup_wizard.html', 'checkout.html', 'autoflow_rust/static/recon_quarantine_viewer.html'].includes(rel)) continue;
    ctx.env.setInputMode('ADVERSARIAL_BOUNDARY');
    for (const h of ctx.handlers) {
      adversarialRuns++;
      try {
        const res = vm.runInContext(
          `(function(event){ ${h} }).call(__mockBtn, event)`,
          Object.assign(ctx.env.sandbox, { __mockBtn: ctx.env.makeEl('btn_adv') }),
          { timeout: 1000 }
        );
        if (res && typeof res.catch === 'function') {
          res.catch(e => { wave4AdversarialErrors.push(`${rel}[Adv:${h}]: ${e.name}: ${e.message}`); });
        }
      } catch (e) {
        wave4AdversarialErrors.push(`${rel}[Adv:${h}]: ${e.name}: ${e.message}`);
      }
    }
    ctx.env.setInputMode('NORMAL');
  }
  if (wave4AdversarialErrors.length > 0) {
    pass6HandlerErrors.push(...wave4AdversarialErrors);
  }
  stateDeltas.deltaV4_adversarialFuzzing = {
    adversarialRuns,
    adversarialErrors: wave4AdversarialErrors.length
  };

  // ============================================================================
  // WAVE 5: Sequential Cross-Modal & Language-Switch State Interference (ΔV4 -> ΔV5)
  //   - Tests chained multi-step interactions on the live VM contexts (opening multiple modals,
  //     pressing Escape, switching languages, filtering & exporting).
  // ============================================================================
  let wave5InterferenceErrors = [];
  const swCtx = fileContexts.get('setup_wizard.html');
  const rqCtx = fileContexts.get('autoflow_rust/static/recon_quarantine_viewer.html');
  if (swCtx) {
    try {
      vm.runInContext(`
        if (typeof openByokGuideModal === 'function') openByokGuideModal();
        if (typeof openRefundModal === 'function') openRefundModal('ORD-CHAIN-1');
        if (typeof closeAllWizardModals === 'function') closeAllWizardModals();
        if (typeof previewModuleTicketString === 'function') {
          previewModuleTicketString('AF-PRO-STANDARD-KEY-2026');
          previewModuleTicketString('AF-TKT-v1.eyJiaXRtYXNrIjo3LCJ2YWxpZERheXMiOjMwfQ.sig');
        }
        if (typeof setLang === 'function') { setLang('en'); setLang('ko'); }
      `, swCtx.env.sandbox, { timeout: 1000 });
    } catch (e) {
      wave5InterferenceErrors.push(`setup_wizard.html[Wave5Chain]: ${e.name}: ${e.message}`);
    }
  }
  if (rqCtx) {
    try {
      vm.runInContext(`
        if (typeof setQuarantineModuleFilter === 'function') {
          setQuarantineModuleFilter('MOD_P');
          setQuarantineModuleFilter('MOD_Q');
          setQuarantineModuleFilter('BRANCH_QUORUM');
          setQuarantineModuleFilter('ALL');
        }
        if (typeof downloadServerSideQuarantineExport === 'function') {
          downloadServerSideQuarantineExport('CSV');
          downloadServerSideQuarantineExport('JSON');
        }
        if (typeof closeAllReconModals === 'function') closeAllReconModals();
      `, rqCtx.env.sandbox, { timeout: 1000 });
    } catch (e) {
      wave5InterferenceErrors.push(`recon_quarantine_viewer.html[Wave5Chain]: ${e.name}: ${e.message}`);
    }
  }
  const swSrc = swCtx ? swCtx.src : '';
  const rqSrc = rqCtx ? rqCtx.src : '';
  const hasModalGuards =
    wave5InterferenceErrors.length === 0 &&
    swSrc.includes('function closeAllWizardModals(') &&
    rqSrc.includes('function closeAllReconModals(') &&
    /key\s*===\s*["']Escape["']/.test(swSrc) &&
    /key\s*===\s*["']Escape["']/.test(rqSrc) &&
    !rqSrc.includes('openExportReportSelector');

  stateDeltas.deltaV5_crossModalInterference = {
    passed: hasModalGuards,
    interferenceErrors: wave5InterferenceErrors
  };

  // ============================================================================
  // WAVE 6: Asynchronous Concurrency, In-Flight Re-entrancy & Network Drop Perturbation (ΔV5 -> ΔV6)
  //   - Simulates network drop (OFFLINE_DROP) after valid state is loaded and verifies
  //     in-flight locks + last-good cache preservation + zero sleep guard.
  // ============================================================================
  let wave6DropErrors = [];
  if (swCtx) {
    swCtx.env.setNetworkMode('OFFLINE_DROP');
    try {
      vm.runInContext(`
        if (typeof fetchHeartbeatStatus === 'function') fetchHeartbeatStatus();
        if (typeof fetchLicenseStatus === 'function') fetchLicenseStatus();
        if (typeof fetchUnifiedPulse === 'function') fetchUnifiedPulse(false);
      `, swCtx.env.sandbox, { timeout: 1000 });
    } catch (e) {
      wave6DropErrors.push(`setup_wizard.html[OfflineDrop]: ${e.message}`);
    }
    swCtx.env.setNetworkMode('ONLINE');
  }
  if (rqCtx) {
    rqCtx.env.setNetworkMode('OFFLINE_DROP');
    try {
      vm.runInContext(`
        if (typeof loadQuarantineItems === 'function') loadQuarantineItems();
      `, rqCtx.env.sandbox, { timeout: 1000 });
    } catch (e) {
      wave6DropErrors.push(`recon_quarantine_viewer.html[OfflineDrop]: ${e.message}`);
    }
    rqCtx.env.setNetworkMode('ONLINE');
  }

  const hasTimerInFlightLocks =
    wave6DropErrors.length === 0 &&
    swSrc.includes('isHeartbeatFetchInFlight') &&
    swSrc.includes('isLicenseFetchInFlight') &&
    swSrc.includes('isUnifiedPulseInFlight') &&
    rqSrc.includes('isQuarantineFetchInFlight') &&
    rqSrc.includes('오프라인 캐시 유지 중') &&
    !swSrc.includes('if (document.hidden) return') &&
    !rqSrc.includes('if (document.hidden) return');

  stateDeltas.deltaV6_concurrencyAndOfflineDrop = {
    passed: hasTimerInFlightLocks,
    offlineDropErrors: wave6DropErrors
  };

  // ============================================================================
  // WAVE 7: Frontend Consumer <-> Dual-Backend Route & Semantic Schema Contract Check (ΔV6 -> ΔV7)
  //   - Checks all 139 discovered API paths across bin/n8n-entry.js & core/autoflow_sidecar_daemon.js
  //     AND verifies that newly added sidecar routes implement the exact response schema
  //     expected by frontend consumers (status: 'HEALTHY' for heartbeat, hash/dashboard for unified-pulse,
  //     LicenseManager fair refund + HARDWARE_MISMATCH 403 for refund-request, RFC 4180 export report).
  // ============================================================================
  const n8nSrc = fs.readFileSync(path.join(rootDir, 'bin/n8n-entry.js'), 'utf8');
  const sidecarSrc = fs.readFileSync(path.join(rootDir, 'core/autoflow_sidecar_daemon.js'), 'utf8');
  const missingInN8n = [];
  const missingInSidecar = [];
  for (const p of discoveredApiPaths) {
    if (!n8nSrc.includes(`"${p}"`) && !n8nSrc.includes(`'${p}'`)) missingInN8n.push(p);
    const inSidecarExplicit = sidecarSrc.includes(`"${p}"`) || sidecarSrc.includes(`'${p}'`);
    const inSidecarPrefix = p.startsWith('/api/system/') && sidecarSrc.includes("url.pathname.startsWith('/api/system/')");
    if (!inSidecarExplicit && !inSidecarPrefix) missingInSidecar.push(p);
  }

  const sidecarDaemon = require('./autoflow_sidecar_daemon');
  const exportCsvTest = sidecarDaemon.buildQuarantineEvidenceExportReport(
    [{ trace_id: 'T1', module_code: 'MOD_P', error_log: '=SUM(1,2) 수수료 과다' }],
    { filter: 'MOD_P', format: 'CSV' }
  );
  const semanticSchemaParityOk =
    sidecarSrc.includes("status: 'HEALTHY'") &&
    sidecarSrc.includes('verifyRefundEligibilityWithHardware') &&
    sidecarSrc.includes('calculateFairRefund') &&
    sidecarSrc.includes('HARDWARE_MISMATCH_BLOCKED') &&
    exportCsvTest.success === true &&
    exportCsvTest.originalDataPreserved === true &&
    exportCsvTest.autoMutated === false &&
    exportCsvTest.body.includes("'=SUM(1,2)");

  stateDeltas.deltaV7_backendContractParity = {
    totalApiPathsChecked: discoveredApiPaths.size,
    missingInN8n: missingInN8n.length,
    missingInSidecar: missingInSidecar.length,
    semanticSchemaParityOk
  };

  // ============================================================================
  // WAVE 8: Sentinel & License State-Machine Perturbation & Dry-Run Non-Mutation (ΔV7 -> ΔV8)
  // ============================================================================
  const { workflowTopologySentinel } = require('./workflow_topology_sentinel');
  const { LicenseManager } = require('./license_manager');
  const requiredTopologyMethods = [
    'getDashboardActiveNodeScopeSummary',
    'handleIncomingNodeEventScoped',
    'executeModularEnginePipeline',
    'executeMcpModuleTool',
    'applyCustomerApprovedBranchSync',
    'approveAndSyncConsensusBranch',
    'evaluateBranchQuorumAndReset',
    'resolveSchemaDriftQuarantine',
    'verifyNodeRuntimeEnclaveBinding'
  ];
  const missingSentinelMethods = requiredTopologyMethods.filter(m => typeof workflowTopologySentinel[m] !== 'function');

  // Execute live state-machine perturbation (negative bitmask + dryRun non-mutation check)
  const negBitmaskProbe = workflowTopologySentinel.handleIncomingNodeEventScoped({
    nodeName: 'Wave8ProbeNode',
    activeBitmask: -1,
    requiredBitmask: 4,
    payload: { test: true }
  });
  const lmProbe = new LicenseManager();
  const statusBeforeProbe = lmProbe.getMasterNoticeAndStoreGateStatus();
  const dryRunProbe = lmProbe.stageMasterNoticeAndStoreGate({
    dryRun: true,
    presetCode: 'PRESET_FEE_TARIFF_OTA_PACK'
  });
  const statusAfterProbe = lmProbe.getMasterNoticeAndStoreGateStatus();
  const {
    attemptMutateFrozenModule,
    composeNewModuleAdaptedToFrozenRegistry,
    evaluateInterlockMatrix,
    inspectAndCrystallizeAllCoreEngines
  } = require('./module_composition_interlock_engine');

  // Verify Immutable Module Freeze, Forward Engine Adaptation & 6 Inter-Module Conflict Mutex Groups
  const mutateAttempt = attemptMutateFrozenModule('MOD_A', { engineChain: [] });
  const adaptedModuleRes = composeNewModuleAdaptedToFrozenRegistry({
    moduleId: 'MOD_R_ADAPTED_SYNTH',
    dependsOnFrozenModules: ['MOD_A', 'MOD_K'],
    mutexWithFrozenModules: ['MOD_K'],
    inputContract: ['orderId']
  });
  const adaptedExecNormal = adaptedModuleRes.module.executeAdapted({ orderId: 'ORD-1' }, { activeModules: ['MOD_A'] });
  const adaptedExecBlocked = adaptedModuleRes.module.executeAdapted({ orderId: 'ORD-1' }, { activeModules: ['MOD_K'] });
  const mutexMatrixEval = evaluateInterlockMatrix(
    ['MOD_A', 'MOD_B', 'MOD_D', 'MOD_F', 'MOD_H', 'MOD_J', 'MOD_K', 'MOD_L', 'MOD_M', 'MOD_N', 'MOD_O', 'MOD_P', 'MOD_Q'],
    {
      shipmentHoldActive: true,
      reconQuarantineActive: true,
      legalComplianceHoldActive: true,
      seizureEmergencyActive: true,
      palletOverloadActive: true,
      cherrypickerDefenseActive: true
    }
  );
  const moduleCompositionAndInterlockOk =
    mutateAttempt.status === 'BLOCKED_FROZEN_MODULE_IMMUTABLE' &&
    mutateAttempt.mutated === false &&
    adaptedModuleRes.ok === true &&
    adaptedModuleRes.existingFrozenModulesMutated === false &&
    adaptedExecNormal.status === 'EXECUTED_WITH_FROZEN_ADAPTATION' &&
    adaptedExecBlocked.status === 'INTERLOCKED_SUPPRESSED_BY_MUTEX' &&
    adaptedExecBlocked.variableEliminated === true &&
    mutexMatrixEval.conflictVariablesRemaining === 0 &&
    mutexMatrixEval.triggeredConflictGroups.length === 6 &&
    mutexMatrixEval.suppressedModules.length >= 6;

  const sentinelStateMachineOk =
    missingSentinelMethods.length === 0 &&
    negBitmaskProbe.status === 'SKIPPED_SILENTLY' &&
    negBitmaskProbe.autoIngested === false &&
    dryRunProbe.dryRun === true &&
    dryRunProbe.stateMutated === false &&
    statusBeforeProbe.noticeVersion === statusAfterProbe.noticeVersion &&
    moduleCompositionAndInterlockOk;

  const n8nTryCatchCount = (n8nSrc.match(/JSON\.parse\(/g) || []).length;
  const sidecarTryCatchCount = (sidecarSrc.match(/JSON\.parse\(/g) || []).length;
  const hasDefensiveJson =
    n8nTryCatchCount > 10 &&
    sidecarTryCatchCount > 10 &&
    sidecarSrc.includes('INVALID_JSON_PAYLOAD');

  stateDeltas.deltaV8_sentinelStateMachine = {
    sentinelStateMachineOk,
    moduleCompositionAndInterlockOk,
    conflictVariablesRemaining: mutexMatrixEval.conflictVariablesRemaining,
    triggeredConflictGroupsCount: mutexMatrixEval.triggeredConflictGroups.length,
    missingSentinelMethods,
    hasDefensiveJson
  };

  // ============================================================================
  // WAVE 9: Post-Mutation DOM Hygiene, Jargon/Price Shield & Multi-Origin 0-Diff Sync (ΔV8 -> ΔV9)
  //   - Inspects both static source and dynamically mutated DOM elements (e.g., ticketPreviewResultBadge)
  //     after Waves 1-8 ran, ensuring no Bitmask= jargon or forbidden price tags leaked into the UI.
  // ============================================================================
  const outOfSyncFiles = [];
  for (const g of SYNC_GROUPS) {
    const mPath = path.join(rootDir, g.master);
    if (!fs.existsSync(mPath)) continue;
    const mBuf = fs.readFileSync(mPath);
    for (const t of g.targets) {
      const tPath = path.join(rootDir, t);
      if (!fs.existsSync(tPath)) continue;
      const tBuf = fs.readFileSync(tPath);
      if (!mBuf.equals(tBuf)) {
        outOfSyncFiles.push(`${g.master} != ${t}`);
      }
    }
  }
  const mutatedBadgeText = swCtx && swCtx.env.elStore.has('ticketPreviewResultBadge')
    ? String(swCtx.env.elStore.get('ticketPreviewResultBadge').innerText || '')
    : '';
  const hasJargonOrPriceLeak =
    /Bitmask=/.test(swSrc) ||
    /Bitmask=/.test(rqSrc) ||
    /Bitmask=/.test(mutatedBadgeText) ||
    /₩\s*(?:9,900|19,000|29,000|15,900|12,900|3,900|5,900)/.test(swSrc) ||
    /₩\s*[0-9]/.test(rqSrc);

  stateDeltas.deltaV9_domHygieneAndSync = {
    outOfSyncCount: outOfSyncFiles.length,
    hasJargonOrPriceLeak,
    mutatedBadgeSample: mutatedBadgeText
  };

  // ============================================================================
  // WAVE 10: Recursive Post-Mutation Convergence & Full Core Engine Crystallization
  //   - Re-executes all handlers on the dirty/accumulated state (∑ΔV_1..9) AND
  //     verifies that all 51 existing core engines + 17 composite modules crystallize
  //     into SEALED_CONSTANT (remainingMutableVariables === 0).
  // ============================================================================
  let wave10ConvergenceErrors = [];
  if (customContext && typeof customContext.extraValidator === 'function') {
    try {
      const extraRes = customContext.extraValidator({ fileContexts, stateDeltas });
      if (extraRes === false) wave10ConvergenceErrors.push('Custom context extraValidator returned false');
    } catch (e) {
      wave10ConvergenceErrors.push(`CustomValidator: ${e.message}`);
    }
  }
  for (const [rel, ctx] of fileContexts.entries()) {
    for (const h of ctx.handlers) {
      try {
        const res = vm.runInContext(
          `(function(event){ ${h} }).call(__mockBtn, event)`,
          Object.assign(ctx.env.sandbox, { __mockBtn: ctx.env.makeEl('btn_conv') }),
          { timeout: 1000 }
        );
        if (res && typeof res.catch === 'function') {
          res.catch(e => { wave10ConvergenceErrors.push(`${rel}[Wave10Async:${h}]: ${e.name}: ${e.message}`); });
        }
      } catch (e) {
        wave10ConvergenceErrors.push(`${rel}[Wave10Convergence:${h}]: ${e.name}: ${e.message}`);
      }
    }
  }

  const crystallizationRes = inspectAndCrystallizeAllCoreEngines();
  if (!crystallizationRes.passed || crystallizationRes.remainingMutableVariables !== 0) {
    for (const f of crystallizationRes.failures) {
      wave10ConvergenceErrors.push(`EngineCrystallization[${f.file || f.moduleId}:${f.target || f.stage}]: ${f.error}`);
    }
  }

  const converged = wave10ConvergenceErrors.length === 0 && crystallizationRes.remainingMutableVariables === 0;
  stateDeltas.deltaV10_convergence = {
    converged,
    totalCoreEnginesInspected: crystallizationRes.totalCoreEnginesInspected,
    totalEngineMethodsVerified: crystallizationRes.totalEngineMethodsVerified,
    totalCompositeModulesFrozen: crystallizationRes.totalCompositeModulesFrozen,
    totalConflictMutexGroups: crystallizationRes.totalConflictMutexGroups,
    remainingMutableVariables: crystallizationRes.remainingMutableVariables,
    wave10ConvergenceErrors
  };

  // Map the 10 Adaptive Waves into passResults & waves array
  passResults.pass1_inline_handlers = { passed: pass1MissingHandlers.length === 0, missing: pass1MissingHandlers, wave: 1 };
  passResults.pass2_api_route_parity = {
    passed: missingInN8n.length === 0 && missingInSidecar.length === 0 && semanticSchemaParityOk,
    totalApiPathsChecked: discoveredApiPaths.size,
    missingInN8n,
    missingInSidecar,
    semanticSchemaParityOk,
    wave: 7
  };
  passResults.pass3_sentinel_methods = {
    passed: sentinelStateMachineOk,
    checkedCount: requiredTopologyMethods.length,
    missingSentinelMethods,
    sentinelStateMachineOk,
    moduleCompositionAndInterlockOk,
    wave: 8
  };
  passResults.pass4_zero_duplicate_ids = { passed: pass4DuplicateIds.length === 0, duplicates: pass4DuplicateIds, wave: 1 };
  passResults.pass5_dom_null_safety = { passed: pass5UnmatchedDomAccess.length === 0 && wave2PreInitErrors.length === 0, unmatched: pass5UnmatchedDomAccess, wave2PreInitErrors, wave: 2 };
  passResults.pass6_v8_runtime_and_handlers = {
    passed: pass6RuntimeErrors.length === 0 && pass6HandlerErrors.length === 0 && converged,
    totalHandlersExecuted,
    adversarialRuns,
    runtimeErrors: pass6RuntimeErrors,
    handlerErrors: pass6HandlerErrors,
    wave10ConvergenceErrors,
    wave: 3
  };
  passResults.pass7_timer_inflight_and_24x7 = { passed: hasTimerInFlightLocks, offlineDropErrors: wave6DropErrors, wave: 6 };
  passResults.pass8_modal_ux_and_unified_export = { passed: hasModalGuards, interferenceErrors: wave5InterferenceErrors, wave: 5 };
  passResults.pass9_defensive_json_parsing = {
    passed: hasDefensiveJson,
    n8nJsonParseSites: n8nTryCatchCount,
    sidecarJsonParseSites: sidecarTryCatchCount,
    wave: 8
  };
  passResults.pass10_zero_diff_and_clean_copy = {
    passed: outOfSyncFiles.length === 0 && !hasJargonOrPriceLeak && converged && swSrc.includes('function showWizardToast(') && rqSrc.includes('function showReconToast('),
    outOfSyncFiles,
    hasJargonOrPriceLeak,
    converged,
    remainingMutableVariables: crystallizationRes.remainingMutableVariables,
    wave: 10
  };

  for (let i = 1; i <= 10; i++) {
    waves.push({
      wave: i,
      deltaKey: Object.keys(stateDeltas)[i - 1],
      delta: Object.values(stateDeltas)[i - 1]
    });
  }

  if (!passResults.pass1_inline_handlers.passed) errors.push(`Wave 1 (Handler Discovery) Failed: ${pass1MissingHandlers.join(', ')}`);
  if (!passResults.pass4_zero_duplicate_ids.passed) errors.push(`Wave 1 (DOM ID Graph) Failed: ${pass4DuplicateIds.join(', ')}`);
  if (!passResults.pass5_dom_null_safety.passed) errors.push(`Wave 2 (Pre-Init & Null Timing Perturbation) Failed: ${[...pass5UnmatchedDomAccess, ...wave2PreInitErrors].join(', ')}`);
  if (!passResults.pass6_v8_runtime_and_handlers.passed) errors.push(`Wave 3/4/10 (V8 Runtime + Adversarial Fuzzing + Convergence) Failed: ${[...pass6RuntimeErrors, ...pass6HandlerErrors, ...wave10ConvergenceErrors].join(' | ')}`);
  if (!passResults.pass8_modal_ux_and_unified_export.passed) errors.push(`Wave 5 (Cross-Modal Interference) Failed: ${wave5InterferenceErrors.join(', ')}`);
  if (!passResults.pass7_timer_inflight_and_24x7.passed) errors.push(`Wave 6 (Concurrency & Offline Drop) Failed: ${wave6DropErrors.join(', ')}`);
  if (!passResults.pass2_api_route_parity.passed) errors.push(`Wave 7 (Frontend-Backend Schema Contract) Failed: n8n=[${missingInN8n.join(',')}] sidecar=[${missingInSidecar.join(',')}] schemaOk=${semanticSchemaParityOk}`);
  if (!passResults.pass3_sentinel_methods.passed) errors.push(`Wave 8 (Sentinel State Machine & Module Interlock) Failed: ${missingSentinelMethods.join(', ')}`);
  if (!passResults.pass9_defensive_json_parsing.passed) errors.push('Wave 8 (Defensive JSON Boundary) Failed');
  if (!passResults.pass10_zero_diff_and_clean_copy.passed) errors.push(`Wave 9/10 (Post-Mutation Hygiene & Convergence) Failed: outOfSync=[${outOfSyncFiles.join(',')}] jargonOrPrice=${hasJargonOrPriceLeak} converged=${converged}`);

  return {
    passed: errors.length === 0,
    converged,
    remainingMutableVariables: crystallizationRes.remainingMutableVariables,
    totalCoreEnginesInspected: crystallizationRes.totalCoreEnginesInspected,
    totalCompositeModulesFrozen: crystallizationRes.totalCompositeModulesFrozen,
    totalConflictMutexGroups: crystallizationRes.totalConflictMutexGroups,
    totalPasses: 10,
    passedCount: Object.values(passResults).filter(p => p.passed).length,
    passResults,
    waves,
    stateDeltas,
    errors
  };
}

async function runTenPassDetailAudit(rootDir = ROOT_DIR, customContext = {}) {
  return runTenPassDetailAuditSync(rootDir, customContext);
}

module.exports = {
  runTenPassDetailAudit,
  runTenPassDetailAuditSync,
  PRIMARY_HTML_FILES,
  SYNC_GROUPS
};
