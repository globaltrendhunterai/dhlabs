#!/usr/bin/env bash
export LANG="en_US.UTF-8"
export LC_ALL="en_US.UTF-8"
# ==============================================================================
# AutoFlow Enterprise 1-Click Instant Launcher (macOS Global Edition)
# Automatically spins up n8n & Self-Healing Sidecar Daemon, opens Studio UI
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# macOS Gatekeeper quarantine release defense for downloaded package
xattr -dr com.apple.quarantine "$SCRIPT_DIR" 2>/dev/null || true
chmod +x "$SCRIPT_DIR/bin/node" "$SCRIPT_DIR/daemon/autoflow_rust" "$SCRIPT_DIR"/*.command 2>/dev/null || true

echo "================================================================================"
echo "⚡ AutoFlow Enterprise 1-Click Instant Launcher (macOS)"
echo "   Directory: $SCRIPT_DIR"
echo "================================================================================"

# ==============================================================================
# Legal Agreement & Liability Disclaimer Gate (1-Time Mandatory Verification)
# ==============================================================================
LEGAL_FLAG="$SCRIPT_DIR/.legal_agreed"
if [ "${AUTOFLOW_AUTO_AGREE_EULA:-0}" = "1" ]; then
    touch "$LEGAL_FLAG"
fi
if [ ! -f "$LEGAL_FLAG" ]; then
    echo ""
    echo "================================================================================"
    echo "⚖️  [AutoFlow Enterprise Commercial License (EULA) & Disclaimer]"
    echo "================================================================================"
    echo " 1. [AS-IS PRINCIPLE]: This software is provided 'AS-IS' with a single-seat perpetual license."
    echo " 2. [THIRD-PARTY APIS]: Developer assumes no liability for external API policy changes,"
    echo "    traffic throttling, or marketplace maintenance."
    echo " 3. [WARRANTY SCOPE]: Includes 15-day autonomous self-healing engine trial & perpetual n8n workflows."
    echo " 4. [FULL TERMS]: Full legal specifications are provided in EULA_PERPETUAL_LICENSE.md."
    echo "================================================================================"
    echo ""
    printf "👉 Do you accept the AutoFlow Commercial License (EULA) terms? [y/N]: "
    read -r USER_LEGAL_CONSENT
    case "$USER_LEGAL_CONSENT" in
        [yY][eE][sS]|[yY])
            touch "$LEGAL_FLAG"
            echo "✅ Legal consent recorded (.legal_agreed created)."
            echo "🚀 Launching in 1 second..."
            echo ""
            ;;
        *)
            echo ""
            echo "⚠️ Terms declined. Safely terminating AutoFlow launcher."
            echo ""
            exit 0
            ;;
    esac
fi

# ==============================================================================
# Standalone Portable V8 Engine Fallback (Zero Docker Required)
# ==============================================================================
launch_standalone_engine() {
    echo ""
    echo "================================================================================"
    echo "⚡ [AutoFlow Standalone Mode] Starting ultra-lightweight portable engine (bin/node)..."
    echo "================================================================================"
    
    NODE_BIN=""
    if [ -x "./bin/node" ] && ./bin/node -v >/dev/null 2>&1; then
        NODE_BIN="$SCRIPT_DIR/bin/node"
    elif [ -x "../bin/node" ] && ../bin/node -v >/dev/null 2>&1; then
        NODE_BIN="$(cd .. && pwd)/bin/node"
    elif [ -x "/opt/homebrew/bin/node" ] && /opt/homebrew/bin/node -v >/dev/null 2>&1; then
        NODE_BIN="/opt/homebrew/bin/node"
    elif [ -x "/usr/local/bin/node" ] && /usr/local/bin/node -v >/dev/null 2>&1; then
        NODE_BIN="/usr/local/bin/node"
    elif command -v node >/dev/null 2>&1 && "$(command -v node)" -v >/dev/null 2>&1; then
        NODE_BIN="$(command -v node)"
    fi

    if [ -z "$NODE_BIN" ]; then
        ARCH_NAME="$(uname -m)"
        if [ "$ARCH_NAME" = "arm64" ]; then
            NODE_DIST_ARCH="darwin-arm64"
        else
            NODE_DIST_ARCH="darwin-x64"
        fi
        NODE_TAR_URL="https://nodejs.org/dist/v20.18.0/node-v20.18.0-${NODE_DIST_ARCH}.tar.gz"
        echo "📦 Auto-downloading portable Node.js (${NODE_DIST_ARCH})..."
        mkdir -p "$SCRIPT_DIR/bin"
        TMP_NODE_TGZ="$SCRIPT_DIR/bin/node_portable.tar.gz"
        if curl -fsSL "$NODE_TAR_URL" -o "$TMP_NODE_TGZ"; then
            tar -xzf "$TMP_NODE_TGZ" -C "$SCRIPT_DIR/bin" "node-v20.18.0-${NODE_DIST_ARCH}/bin/node" 2>/dev/null || tar -xzf "$TMP_NODE_TGZ" -C "$SCRIPT_DIR/bin"
            if [ -f "$SCRIPT_DIR/bin/node-v20.18.0-${NODE_DIST_ARCH}/bin/node" ]; then
                mv -f "$SCRIPT_DIR/bin/node-v20.18.0-${NODE_DIST_ARCH}/bin/node" "$SCRIPT_DIR/bin/node"
                rm -rf "$SCRIPT_DIR/bin/node-v20.18.0-${NODE_DIST_ARCH}" "$TMP_NODE_TGZ"
            fi
            chmod +x "$SCRIPT_DIR/bin/node" 2>/dev/null || true
            xattr -dr com.apple.quarantine "$SCRIPT_DIR/bin/node" 2>/dev/null || true
            if [ -x "./bin/node" ] && ./bin/node -v >/dev/null 2>&1; then
                NODE_BIN="$SCRIPT_DIR/bin/node"
            fi
        fi
    fi
    PORTABLE_NODE="$NODE_BIN"
    
    PORTABLE_ENTRY=""
    if [ -f "$SCRIPT_DIR/bin/n8n-entry.js" ]; then
        PORTABLE_ENTRY="$SCRIPT_DIR/bin/n8n-entry.js"
    fi
    
    if [ -z "$PORTABLE_NODE" ] || [ -z "$PORTABLE_ENTRY" ]; then
        echo "❌ [ERROR] Portable engine runtime files not found."
        if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
            read -p "Press [Enter] to exit..."
        fi
        exit 1
    fi
    
    mkdir -p "$SCRIPT_DIR/logs"
    
    # 0-Sync: Double-Click Instant Cloud & OS Anchor Synchronization
    if [ -f "$SCRIPT_DIR/core/recharge_cli.js" ]; then
        "$PORTABLE_NODE" "$SCRIPT_DIR/core/recharge_cli.js" sync --lang=en >/dev/null 2>&1 || true
        "$PORTABLE_NODE" "$SCRIPT_DIR/core/recharge_cli.js" status --lang=en || true
    fi

    echo "🚀 Booting background daemon..."
    echo "   ▶ Runtime: $PORTABLE_NODE"
    echo "   ▶ Entry:   $PORTABLE_ENTRY"
    
    nohup "$PORTABLE_NODE" "$PORTABLE_ENTRY" > "$SCRIPT_DIR/logs/standalone_engine.log" 2>&1 &
    ENGINE_PID=$!
    echo "$ENGINE_PID" > "$SCRIPT_DIR/logs/engine.pid"
    
    # Also boot sidecar daemon if present
    if [ -f "$SCRIPT_DIR/core/autoflow_sidecar_daemon.js" ]; then
        nohup "$PORTABLE_NODE" "$SCRIPT_DIR/core/autoflow_sidecar_daemon.js" > "$SCRIPT_DIR/logs/sidecar_daemon.log" 2>&1 &
        echo "$!" > "$SCRIPT_DIR/logs/sidecar.pid"
    fi

    # Also boot telemetry beacon
    if [ -f "$SCRIPT_DIR/core/telemetry_beacon.js" ]; then
        nohup "$PORTABLE_NODE" "$SCRIPT_DIR/core/telemetry_beacon.js" > "$SCRIPT_DIR/logs/telemetry_beacon.log" 2>&1 &
        echo "$!" > "$SCRIPT_DIR/logs/beacon.pid"
    fi

    # Also boot watchdog
    if [ -f "$SCRIPT_DIR/core/watchdog.js" ]; then
        nohup "$PORTABLE_NODE" "$SCRIPT_DIR/core/watchdog.js" > "$SCRIPT_DIR/logs/watchdog.log" 2>&1 &
        echo "$!" > "$SCRIPT_DIR/logs/watchdog.pid"
    fi
    
    PORT="${PORT:-5678}"
    if [ -d "$HOME/Desktop" ]; then
        cat <<EOF > "$HOME/Desktop/AutoFlow_Open_Console.url"
[InternetShortcut]
URL=http://localhost:${PORT}
EOF
        echo "[INFO] Desktop shortcut created: ~/Desktop/AutoFlow_Open_Console.url"
    fi

    echo "🌐 Opening AutoFlow Studio in your default browser..."
    sleep 1
    if [ "${AUTOFLOW_NO_BROWSER:-0}" != "1" ]; then
        open "http://localhost:${PORT}"
    fi
    
    echo ""
    echo "================================================================================"
    echo "🎉 AutoFlow is now running smoothly in background!"
    echo "================================================================================"
    echo "   - Studio UI:           http://localhost:5678"
    echo "   - Sidecar Healthcheck: http://localhost:8080/healthz"
    echo "   - Blueprints Vault:    $SCRIPT_DIR/blueprints"
    echo "   - License Top-Up:      Run RECHARGE_ENGINE.command"
    echo "================================================================================"
    echo "ℹ️ You can close this terminal window safely. AutoFlow runs in background."
    echo ""
    exit 0
}

launch_standalone_engine
