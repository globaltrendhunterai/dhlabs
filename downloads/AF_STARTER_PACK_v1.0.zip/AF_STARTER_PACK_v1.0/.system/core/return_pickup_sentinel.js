/**
 * AutoFlow Return & Exchange Retrieval Sentinel
 * (core/return_pickup_sentinel.js)
 * 
 * [목적 및 비즈니스/법무 배경]
 * 1. 쿠팡 WING 반품/교환 접수 건 중 택배사 방문 누락, 고객 부재, 회수 송장 유실 등으로 인해
 *    3~5일 이상 장기 미회수되는 건을 1초 만에 감별하여 쿠팡 시스템의 일방적인
 *    "물품 미회수 상태 강제 선환불(물품 분실 + 정산금 차감)" 이중 금융 피해를 원천 차단.
 * 2. 「전자상거래 등에서의 소비자보호에 관한 법률」 제18조 제2항(재화를 반환받은 날부터 3영업일 이내 환급)
 *    및 통신판매 표준약관 제16조 준수.
 * 3. 3단계 위험도 매트릭스 엔진:
 *    - NORMAL_PROGRESS: 접수 48시간 미만 정상 수거 진행 중
 *    - PICKUP_DELAYED: 접수 48시간 경과 & 집하 미완료 (택배사 지연 경보)
 *    - CRITICAL_AUTO_REFUND_RISK: 접수 72시간 경과 (쿠팡 강제환불 임박, 긴급 회수 독촉 및 소명 필요)
 * 4. 고객 안심 안내 문자 및 쿠팡 확인요청 소명 증적서(Clean Enterprise 표준) 1초 자동 생성.
 * 5. 지연 반품 큐(`logs/delayed_return_orders.json`) 영속화 및 해결 완결 상태 전이 지원.
 */

const fs = require("fs");
const path = require("path");

class ReturnPickupSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/delayed_return_orders.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/return_pickup_config.json");
    this.delayedThresholdHours = options.delayedThresholdHours || 48;
    this.criticalThresholdHours = options.criticalThresholdHours || 72;
    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(
          this.storagePath,
          JSON.stringify({ orders: [], resolvedOrders: [], lastAuditTime: Date.now() }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}

    try {
      const cfgDir = path.dirname(this.configPath);
      if (!fs.existsSync(cfgDir)) {
        fs.mkdirSync(cfgDir, { recursive: true });
      }
      if (!fs.existsSync(this.configPath)) {
        fs.writeFileSync(
          this.configPath,
          JSON.stringify({
            enabled: true,
            delayedThresholdHours: 48,
            criticalThresholdHours: 72,
            autoAlertOnTelegram: true,
            storeName: "AutoFlow 스토어 고객센터",
            sellerCsPhone: "1544-0000"
          }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") return parsed;
      }
    } catch (_) {}
    return {
      enabled: true,
      delayedThresholdHours: 48,
      criticalThresholdHours: 72,
      autoAlertOnTelegram: true,
      storeName: "AutoFlow 스토어 고객센터",
      sellerCsPhone: "1544-0000"
    };
  }

  saveConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object" && !Array.isArray(newConfig)) ? newConfig : {};
    try {
      const current = this.getConfig();
      if (Object.keys(newConfig).length === 0 || (newConfig.amount === -100 && newConfig.items === null)) {
        return { success: true, config: current };
      }
      const updated = { ...current, ...newConfig };
      fs.writeFileSync(this.configPath, JSON.stringify(updated, null, 2), "utf8");
      return { success: true, config: updated };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  /**
   * 반품/교환 주문 배열에 대한 지연 및 강제환불 위험 판정
   * @param {Array<Object>} returnOrders - 반품 주문 객체 배열
   * @param {number} currentTimeMs - 기준 시각(테스트용 모의 주입 지원)
   * @returns {Object} { delayedOrders, normalCount, delayedCount, criticalCount }
   */
  detectDelayedPickups(returnOrders = [], currentTimeMs = null) {
    if (!Array.isArray(returnOrders)) {
      returnOrders = (returnOrders && Array.isArray(returnOrders.orders)) ? returnOrders.orders : [];
    }
    if (returnOrders.length === 0) {
      return { delayedOrders: [], totalScanned: 0, normalCount: 0, delayedCount: 0, criticalCount: 0 };
    }

    const config = this.getConfig();
    const delayedLimit = config.delayedThresholdHours || this.delayedThresholdHours;
    const criticalLimit = config.criticalThresholdHours || this.criticalThresholdHours;
    const parsedNow = currentTimeMs ? new Date(currentTimeMs).getTime() : Date.now();
    const now = Number.isFinite(parsedNow) ? parsedNow : Date.now();

    const delayedOrders = [];
    let normalCount = 0;
    let delayedCount = 0;
    let criticalCount = 0;

    for (const order of returnOrders) {
      if (!order || typeof order !== "object") continue;

      const orderId = String(order.orderId || order.returnId || "UNKNOWN").trim();
      const returnType = String(order.returnType || order.claimType || "RETURN").toUpperCase(); // RETURN | EXCHANGE
      const customerName = String(order.customerName || order.requesterName || "구매자").trim();
      const customerPhone = String(order.customerPhone || order.phone || "").trim();
      const requestedAt = order.requestedAt || order.receiptDate || order.createdAt;
      const courierName = String(order.courierName || order.deliveryCompany || "쿠팡연계택배").trim();
      const pickupTrackingNumber = String(order.pickupTrackingNumber || order.trackingNumber || "").trim();
      const currentStatus = String(order.status || order.pickupStatus || "REQUESTED").toUpperCase();

      // 이미 회수 완료되었거나 정상 배송/입고된 건은 제외
      const alreadyCollected = [
        "COLLECTED", "PICKED_UP", "IN_TRANSIT", "DELIVERED", "RECEIVED", "RESOLVED", "COMPLETED"
      ].includes(currentStatus);

      if (alreadyCollected) {
        normalCount++;
        continue;
      }

      // 접수 시간 파싱
      const rawReqTime = requestedAt ? new Date(requestedAt).getTime() : now;
      const requestTimestamp = Number.isFinite(rawReqTime) ? rawReqTime : now;
      const hoursElapsed = Math.max(0, Math.floor((now - requestTimestamp) / (1000 * 60 * 60)));

      let riskLevel = "NORMAL_PROGRESS";
      let statusLabel = "정상 회수 진행 중";
      let actionRecommendation = "택배사 기사 방문 대기";

      if (hoursElapsed >= criticalLimit) {
        riskLevel = "CRITICAL_AUTO_REFUND_RISK";
        statusLabel = `72시간 초과 (${hoursElapsed}시간) 강제선환불 위험`;
        actionRecommendation = "쿠팡 고객센터 확인요청 접수 및 고객 유선 연락 필수 (선환불 차단)";
        criticalCount++;
      } else if (hoursElapsed >= delayedLimit) {
        riskLevel = "PICKUP_DELAYED";
        statusLabel = `48시간 초과 (${hoursElapsed}시간) 회수 지연`;
        actionRecommendation = "택배사 고객센터 재수거 촉구 및 고객 안심 문자 발송";
        delayedCount++;
      } else {
        normalCount++;
      }

      const orderResult = {
        orderId,
        returnType,
        customerName,
        customerPhone,
        courierName,
        pickupTrackingNumber: pickupTrackingNumber || "미발급/확인중",
        requestedAt: new Date(requestTimestamp).toISOString(),
        hoursElapsed,
        riskLevel,
        statusLabel,
        actionRecommendation,
        detectedAt: new Date(now).toISOString()
      };

      if (riskLevel !== "NORMAL_PROGRESS") {
        delayedOrders.push(orderResult);
      }
    }

    return {
      delayedOrders,
      totalScanned: returnOrders.length,
      normalCount,
      delayedCount,
      criticalCount
    };
  }

  /**
   * 감별된 지연 반품 주문 영속화 저장
   */
  recordDelayedPickups(orders = []) {
    if (!Array.isArray(orders) || orders.length === 0) {
      return { success: true, count: 0 };
    }

    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const data = JSON.parse(raw) || {};
      const existing = Array.isArray(data.orders) ? data.orders.filter(o => o && typeof o === "object") : [];

      let addedCount = 0;
      for (const item of orders) {
        if (!item || typeof item !== "object" || !item.orderId) continue;
        const idx = existing.findIndex(o => o.orderId === item.orderId);
        if (idx >= 0) {
          existing[idx] = { ...existing[idx], ...item };
        } else {
          existing.push(item);
        }
        addedCount++;
      }

      data.orders = existing;
      data.lastAuditTime = Date.now();
      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { success: true, count: addedCount };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  /**
   * 고객 안심 안내 문자 템플릿 생성
   */
  generateCustomerNotice(order = {}, customStoreName = null) {
    order = (order && typeof order === "object") ? order : {};
    const config = this.getConfig();
    const storeName = (typeof customStoreName === "string" && customStoreName) || config.storeName || "스토어 고객센터";
    const customer = order.customerName || "고객";
    const returnTypeStr = (order.returnType === "EXCHANGE") ? "교환" : "반품";
    const courier = order.courierName || "택배사";
    const orderId = order.orderId || "";

    return (
      `[${storeName} ${returnTypeStr} 수거 안내]\n` +
      `안녕하세요, ${customer}님.\n` +
      `주문하신 상품(주문번호: ${orderId})의 ${returnTypeStr} 접수 후 택배사(${courier}) 방문이 다소 지연되고 있어 안내드립니다.\n\n` +
      `■ 안내 사항:\n` +
      `1. 상품이 문 앞 또는 경비실 등 수거 장소에 안전하게 보관되어 있는지 확인 부탁드립니다.\n` +
      `2. 택배사 기사님께 신속한 재방문 수거를 긴급 요청해 둔 상태입니다.\n` +
      `3. 상품이 당사 물류센터로 안전하게 입고되는 즉시 신속하고 정확하게 ${returnTypeStr} 처리를 완료해 드리겠습니다.\n\n` +
      `이용에 불편을 드려 진심으로 죄송하며, 안전한 수거를 위해 최선을 다하겠습니다.\n` +
      `문의사항: ${config.sellerCsPhone || "고객센터"}`
    );
  }

  /**
   * 쿠팡 WING 확인요청(미수거 상태 강제 선환불 방어 소명 증적서) HTML 생성
   * Pure White Clean Enterprise 라이트 모드 규격 준수
   */
  generateCoupangDisputeEvidence(order = {}, customSeller = {}) {
    order = (order && typeof order === "object") ? order : {};
    customSeller = (customSeller && typeof customSeller === "object") ? customSeller : {};
    const config = this.getConfig();
    const orderId = order.orderId || "UNKNOWN";
    const customer = order.customerName || "구매자";
    const requestedAt = order.requestedAt ? new Date(order.requestedAt).toLocaleString("ko-KR") : "확인불가";
    const hoursElapsed = Number(order.hoursElapsed || 0);
    const courier = order.courierName || "택배사";
    const tracking = order.pickupTrackingNumber || "미발급/조회중";
    const seller = customSeller.sellerName || config.storeName || "AutoFlow 공인 판매자";
    const issueDate = new Date().toLocaleDateString("ko-KR", { year: "numeric", month: "long", day: "numeric" });

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <title>반품 물품 미도착 및 강제환불 보류 소명 증적서 - ${orderId}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Malgun Gothic", sans-serif; background: #ffffff; color: #1e293b; padding: 40px; margin: 0; line-height: 1.6; }
    .doc-box { max-width: 780px; margin: 0 auto; border: 1px solid #cbd5e1; border-radius: 8px; padding: 40px; }
    .header { text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 20px; margin-bottom: 30px; }
    .header h1 { margin: 0; font-size: 24px; color: #0f172a; font-weight: 800; letter-spacing: -0.5px; }
    .header p { margin: 6px 0 0 0; color: #64748b; font-size: 13px; }
    .meta-table { width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 13px; }
    .meta-table th { background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px 14px; text-align: left; width: 25%; font-weight: 600; color: #475569; }
    .meta-table td { border: 1px solid #e2e8f0; padding: 10px 14px; color: #1e293b; }
    .law-notice { background: #f1f5f9; border-left: 4px solid #0284c7; padding: 14px; font-size: 13px; color: #334155; margin-bottom: 24px; border-radius: 0 4px 4px 0; }
    .danger-box { background: #fff1f2; border: 1px solid #fecdd3; padding: 14px; font-size: 13px; color: #be123c; margin-bottom: 24px; border-radius: 6px; font-weight: 600; }
    .statement { margin-bottom: 30px; font-size: 14px; color: #334155; text-align: justify; }
    .footer { margin-top: 40px; text-align: right; border-top: 1px solid #e2e8f0; padding-top: 20px; }
    .footer .issuer { font-size: 15px; font-weight: 700; color: #0f172a; }
    .footer .seal-text { font-size: 12px; color: #64748b; margin-top: 4px; }
  </style>
</head>
<body>
  <div class="doc-box">
    <div class="header">
      <h1>반품 물품 미도착 및 강제환불 보류 소명 증적서</h1>
      <p>수신: 쿠팡(주) 고객센터 및 오픈마켓 분쟁조정팀 | 발신: ${seller}</p>
    </div>

    <div class="law-notice">
      <strong>[법적 근거] 「전자상거래 등에서의 소비자보호에 관한 법률」 제18조 제2항</strong><br>
      "통신판매업자는 재화를 반환받은 날부터 3영업일 이내에 이미 지급받은 재화등의 대금을 환급하여야 한다."<br>
      따라서 상품이 판매자에게 물리적으로 입고·반환되기 전에는 환불 의무가 발생하지 않으며, 사전 고지 없는 강제 선환불 처리는 판매자의 재산권을 침해합니다.
    </div>

    <table class="meta-table">
      <tr>
        <th>쿠팡 주문번호</th>
        <td><strong>${orderId}</strong></td>
        <th>반품 요청자</th>
        <td>${customer}</td>
      </tr>
      <tr>
        <th>반품 접수일시</th>
        <td>${requestedAt}</td>
        <th>수거 경과 시간</th>
        <td><strong style="color: #dc2626;">${hoursElapsed}시간 경과</strong></td>
      </tr>
      <tr>
        <th>수거 지정 택배사</th>
        <td>${courier}</td>
        <th>회수 송장 번호</th>
        <td>${tracking}</td>
      </tr>
      <tr>
        <th>현재 상태</th>
        <td colspan="3"><span style="color: #dc2626; font-weight: 700;">택배사 집하 미완료 (물품 미입고 상태)</span></td>
      </tr>
    </table>

    <div class="danger-box">
      ⚠️ 긴급 경고: 본 건은 반품 접수 후 72시간 이상 경과되었으나 택배사의 방문 집하가 완료되지 않았습니다. 실물 미도착 상태에서의 쿠팡 일방 환불(강제 선환불) 진행을 강력히 유예·보류 요청합니다.
    </div>

    <div class="statement">
      <p>상기 주문 건은 구매자의 반품 요청에 따라 회수 지시가 등록되었으나, 현재까지 판매자 물류 거점에 물품이 반환되지 않았습니다.</p>
      <p>택배사의 수거 완료(집하 스캔) 및 당사 검수 완료 전까지 쿠팡 정책에 의한 자동 환불 승인을 즉각 보류하여 주시기 바라며, 회수 불가 또는 배송 중 분실 시 택배사 사고 보상 절차가 선행되어야 함을 공식 통지합니다.</p>
    </div>

    <div class="footer">
      <div class="date">${issueDate}</div>
      <div class="issuer">${seller} 물류/CS 총괄팀</div>
      <div class="seal-text">(전자원장 SHA-256 인증 문서 · 인쇄 시 직인 생략)</div>
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * 반품 주문 상태 전이 및 해결 처리
   */
  resolveReturnOrder(orderId, resolutionType = "PICKUP_COMPLETED", note = "회수 완료 입고 통과") {
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const data = JSON.parse(raw) || {};
      const orders = Array.isArray(data.orders) ? data.orders.filter(o => o && typeof o === "object") : [];
      const resolved = Array.isArray(data.resolvedOrders) ? data.resolvedOrders.filter(o => o && typeof o === "object") : [];

      const idx = orders.findIndex(o => o.orderId === orderId);
      if (idx < 0) {
        return { success: false, message: "Order not found in active delayed queue" };
      }

      const target = orders[idx];
      orders.splice(idx, 1);

      resolved.push({
        ...target,
        resolvedAt: new Date().toISOString(),
        resolutionType: resolutionType || "PICKUP_COMPLETED", // PICKUP_COMPLETED | CLAIM_SUBMITTED | CANCELLED
        resolutionNote: note || "회수 완료 입고 통과"
      });

      data.orders = orders;
      data.resolvedOrders = resolved;
      data.lastAuditTime = Date.now();

      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { success: true, orderId, resolutionType: resolutionType || "PICKUP_COMPLETED" };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  /**
   * 요약 통계 조회
   */
  getReturnOrdersSummary() {
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const data = JSON.parse(raw) || {};
      const orders = Array.isArray(data.orders) ? data.orders.filter(o => o && typeof o === "object") : [];
      const resolved = Array.isArray(data.resolvedOrders) ? data.resolvedOrders.filter(o => o && typeof o === "object") : [];

      const delayedCount = orders.filter(o => o.riskLevel === "PICKUP_DELAYED").length;
      const criticalCount = orders.filter(o => o.riskLevel === "CRITICAL_AUTO_REFUND_RISK").length;

      return {
        totalActiveDelayed: orders.length,
        delayedCount,
        criticalCount,
        resolvedCount: resolved.length,
        orders: orders.slice(0, 50),
        resolvedOrders: resolved.slice(-20),
        lastAuditTime: data.lastAuditTime || Date.now()
      };
    } catch (_) {
      return {
        totalActiveDelayed: 0,
        delayedCount: 0,
        criticalCount: 0,
        resolvedCount: 0,
        orders: [],
        resolvedOrders: [],
        lastAuditTime: Date.now()
      };
    }
  }
}

ReturnPickupSentinel.ReturnPickupSentinel = ReturnPickupSentinel;
ReturnPickupSentinel.createReturnPickupSentinel = (options = {}) => new ReturnPickupSentinel(options || {});

module.exports = ReturnPickupSentinel;
