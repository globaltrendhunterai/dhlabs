/**
 * AutoFlow Special Delivery Notes & Door Code Sentinel
 * 
 * [설계 목적]
 * 구매자가 주문 시 기재한 배송 요청사항(공동현관 비밀번호, 출입 방법, 배송 장소 등)이
 * 복잡한 주문 데이터 속에서 묻혀 택배 기사님 오배송, 반송, 분실 및 고객 불만(CS)으로
 * 이어지는 것을 1초 만에 원천 차단하는 배송 특이사항 하이라이트 에어백 가드.
 * 
 * [주요 기능]
 * 1. 공동현관 비밀번호, 카드키, 경비실 호출 등 출입 특이사항 정밀 추출
 * 2. 수령 희망 장소(문 앞, 경비실, 무인택배함 등) 태그 분류
 * 3. 텔레그램/슬랙 주문 알림 내 시각적 하이라이트 블록 생성
 * 4. 셋업 마법사 1초 실시간 특이사항 조회 및 모의 파싱 엔진 지원
 */

const fs = require("fs");
const path = require("path");

class DeliveryNotesSentinel {
  constructor(options = {}) {
    this.historyPath = options.historyPath || path.join(__dirname, "..", "logs", "delivery_notes_history.json");
    this.maxHistory = options.maxHistory || 100;
  }

  _ensureStorage() {
    try {
      const dir = path.dirname(this.historyPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.historyPath)) {
        fs.writeFileSync(this.historyPath, JSON.stringify([], null, 2), "utf8");
      }
    } catch (e) {
      console.error("[DeliveryNotesSentinel] 저장소 초기화 실패 (non-fatal):", e.message);
    }
  }

  /**
   * 배송 메시지에서 공동현관 비번 및 배송 장소 정밀 추출
   * @param {string} rawMessage - 주문서에 포함된 원본 배송 메시지
   * @returns {Object} 추출된 특이사항 객체
   */
  parseInstructions(rawMessage = "") {
    const text = String(rawMessage || "").trim();
    if (!text) {
      return {
        hasSpecialNote: false,
        doorCode: null,
        locationTag: "일반 배송",
        highlightText: "(배송 특이사항 없음)",
        rawMessage: ""
      };
    }

    // 1. 공동현관 비밀번호 패턴 추출 (#1234, 1234*, 종1234열림, 비번: 1234 등)
    let doorCode = null;
    const doorPatterns = [
      /(?:공동현관|현관|비번|비밀번호|출입|호출)[^\d#*]*([#*]?\d{3,8}[#*]?)/i,
      /(?:[#*]\d{3,8}[#*]?)/,
      /(\d{3,8}[#*])/
    ];

    for (const pattern of doorPatterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        doorCode = match[1].trim();
        break;
      } else if (match && match[0]) {
        doorCode = match[0].trim();
        break;
      }
    }

    // 2. 수령 장소 분류
    let locationTag = "문 앞";
    if (/경비실/i.test(text)) {
      locationTag = "경비실 보관";
    } else if (/(?:택배함|보관함|무인)/i.test(text)) {
      locationTag = "무인택배함";
    } else if (/(?:직접|대면|전화|벨)/i.test(text)) {
      locationTag = "직접 수령/벨 호출";
    } else if (/(?:문 앞|문앞|현관 앞)/i.test(text)) {
      locationTag = "문 앞";
    }

    // 3. 하이라이트 문구 조합
    let highlightParts = [];
    if (doorCode) {
      highlightParts.push(`🔑 공동현관: ${doorCode}`);
    }
    highlightParts.push(`📍 수령장소: ${locationTag}`);

    return {
      hasSpecialNote: !!doorCode || locationTag !== "문 앞" || text.length > 5,
      doorCode,
      locationTag,
      highlightText: highlightParts.join(" | "),
      rawMessage: text
    };
  }

  /**
   * 텔레그램/슬랙 주문 알림에 삽입할 특이사항 하이라이트 블록 생성
   */
  formatDeliveryNoteBlock(rawMessage = "") {
    const parsed = this.parseInstructions(rawMessage);
    if (!parsed.hasSpecialNote && !parsed.rawMessage) {
      return "• 배송요청: (특이사항 없음)";
    }

    if (parsed.doorCode) {
      return [
        "🔑 [배송 특이사항 & 공동현관 출입 가드]",
        `   ↳ ${parsed.highlightText}`,
        `   ↳ 요청원문: "${parsed.rawMessage}"`
      ].join("\n");
    }

    return `• 배송요청 [${parsed.locationTag}]: "${parsed.rawMessage}"`;
  }

  /**
   * 분석 이력 저장
   */
  recordNote(orderId, rawMessage) {
    this._ensureStorage();
    const parsed = this.parseInstructions(rawMessage);
    const record = {
      orderId: String(orderId || `ORD-${Date.now()}`),
      timestamp: new Date().toISOString(),
      ...parsed
    };

    try {
      let list = [];
      if (fs.existsSync(this.historyPath)) {
        list = JSON.parse(fs.readFileSync(this.historyPath, "utf8"));
      }
      list.unshift(record);
      const trimmed = list.slice(0, this.maxHistory);
      fs.writeFileSync(this.historyPath, JSON.stringify(trimmed, null, 2), "utf8");
    } catch (e) {
      console.error("[DeliveryNotesSentinel] 이력 저장 실패 (non-fatal):", e.message);
    }

    return record;
  }

  /**
   * 최근 분석된 배송 특이사항 이력 조회
   */
  getRecentNotes() {
    this._ensureStorage();
    try {
      if (fs.existsSync(this.historyPath)) {
        const list = JSON.parse(fs.readFileSync(this.historyPath, "utf8"));
        if (Array.isArray(list)) return list;
      }
    } catch (e) {
      console.error("[DeliveryNotesSentinel] 이력 로드 실패 (non-fatal):", e.message);
    }
    return [];
  }
}

const defaultDeliveryNotesSentinel = new DeliveryNotesSentinel();

module.exports = {
  DeliveryNotesSentinel,
  deliveryNotesSentinel: defaultDeliveryNotesSentinel
};
