/**
 * AutoFlow Tax Invoice & VAT Sales Reconciliation Sentinel
 * (core/vat_sales_sentinel.js)
 * 
 * [목적 및 비즈니스/법무 배경]
 * 1. 쿠팡 WING 오픈마켓 부가가치세 신고 시 [신용카드 매출], [현금영수증 매출], [기타(무증빙/마일리지) 매출], [쿠팡 수수료 매입세액] 1원 단위 정밀 분리.
 * 2. 「부가가치세법」 제32조(세금계산서 등), 제36조(영수증), 제48조(과세표준 및 세액의 신고) 및 「조세범 처벌법」 준수.
 * 3. 셀러 급소 3대 세무 리스크 원천 차단:
 *    - 이중발행 가산세 방어: 쿠팡이 고객에게 이미 발행한 현금영수증/카드 건을 판매자가 모르고 세금계산서 중복 발급하여 발생하는 1~2% 가산세 방지.
 *    - 과소신고 가산세 방어: 쿠팡캐시/마일리지 등 무증빙 매출 누락으로 인한 10~40% 과소신고 가산세 및 납부지연가산세(일 0.022%) 방지.
 *    - 매입세액 불공제 방어: 쿠팡 차감 수수료(판매/PG/배송비) 세금계산서 매입세액 대사 누락으로 인한 부가세 과다 납부 방지.
 * 4. Pure White Clean Enterprise 라이트 모드 부가세 신고용 1초 원장 증적서 (`(인쇄 시 직인 생략)` 공문서 표준 준수, 붉은 직인 0건).
 * 5. 세무사 제출용 1초 텍스트 요약문 클립보드 복사 지원.
 */

const fs = require("fs");
const path = require("path");

class VatSalesSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/vat_sales_audit.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/vat_sales_config.json");
    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(
          this.storagePath,
          JSON.stringify({ auditRecords: [], lastAuditTime: Date.now() }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}

    try {
      const cfgDir = path.dirname(this.configPath);
      if (!fs.existsSync(cfgDir)) {
        fs.mkdirSync(cfgDir, { recursive: true });
      }
      if (!fs.existsSync(this.configPath)) {
        fs.writeFileSync(
          this.configPath,
          JSON.stringify({
            enabled: true,
            businessRegistrationNumber: "000-00-00000",
            storeName: "AutoFlow 스토어",
            taxAccountantEmail: "tax@autoflow.local",
            commissionVatRate: 0.10,
            autoAlertOnReport: true
          }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") return parsed;
      }
    } catch (_) {}
    return {
      enabled: true,
      businessRegistrationNumber: "000-00-00000",
      storeName: "AutoFlow 스토어",
      taxAccountantEmail: "tax@autoflow.local",
      commissionVatRate: 0.10,
      autoAlertOnReport: true
    };
  }

  saveConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object" && !Array.isArray(newConfig)) ? newConfig : {};
    try {
      const current = this.getConfig();
      if (Object.keys(newConfig).length === 0 || (newConfig.amount === -100 && newConfig.items === null)) {
        return { success: true, config: current };
      }
      const merged = Object.assign({}, current, newConfig);
      fs.writeFileSync(this.configPath, JSON.stringify(merged, null, 2), "utf8");
      return { success: true, config: merged };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  /**
   * 주문 결제수단별 매출 속성 분류
   * @param {Object} order 주문 객체
   * @returns {string} CREDIT_CARD | CASH_RECEIPT | OTHER_UNPROVED
   */
  classifyOrderPayment(order) {
    if (!order || typeof order !== "object") return "OTHER_UNPROVED";

    const paymentMethod = String(order.paymentMethod || order.payType || "").toUpperCase();
    const receiptType = String(order.receiptType || order.cashReceiptType || "").toUpperCase();

    // 1. 신용/체크카드 결제
    if (
      paymentMethod.includes("CARD") ||
      paymentMethod.includes("CREDIT") ||
      paymentMethod.includes("CHECK") ||
      paymentMethod.includes("카드")
    ) {
      return "CREDIT_CARD";
    }

    // 2. 현금영수증 발행 건 (계좌이체, 무통장, 쿠팡페이 머니 중 현금영수증 신청)
    if (
      receiptType.includes("CASH") ||
      receiptType.includes("현금") ||
      receiptType.includes("INCOME_DEDUCTION") ||
      receiptType.includes("EXPENSE_PROOF") ||
      paymentMethod.includes("CASH_RECEIPT")
    ) {
      return "CASH_RECEIPT";
    }

    // 3. 기타 무증빙/마일리지 (쿠팡캐시, 포인트 전액결제, 무증빙 계좌이체 등)
    return "OTHER_UNPROVED";
  }

  /**
   * 주문 목록 부가가치세 1원 단위 정밀 집계
   * @param {Array} orders 주문 목록
   * @param {Object} options 부가세 옵션
   */
  calculateVatBreakdown(orders = [], options = {}) {
    orders = Array.isArray(orders) ? orders : (orders && Array.isArray(orders.orders) ? orders.orders : []);
    options = (options && typeof options === "object") ? options : {};

    let creditCardTotal = 0;
    let cashReceiptTotal = 0;
    let otherUnprovedTotal = 0;
    let taxFreeTotal = 0;
    let totalCoupangCommission = 0;

    const classifiedOrders = [];

    for (const order of orders) {
      if (!order || typeof order !== "object" || !order.orderId) continue;

      const orderTotal = Math.round(Number(order.totalAmount || order.orderAmount || order.price || 0));
      const isTaxFree = Boolean(order.isTaxFree || order.taxType === "TAX_FREE");
      const commission = Math.round(Number(order.commission || order.coupangFee || 0));

      totalCoupangCommission += commission;

      if (isTaxFree) {
        taxFreeTotal += orderTotal;
        classifiedOrders.push({
          orderId: order.orderId,
          orderTotal,
          paymentCategory: "TAX_FREE",
          supplyValue: orderTotal,
          vatAmount: 0,
          isTaxFree: true,
          commission
        });
        continue;
      }

      const category = this.classifyOrderPayment(order);
      if (category === "CREDIT_CARD") {
        creditCardTotal += orderTotal;
      } else if (category === "CASH_RECEIPT") {
        cashReceiptTotal += orderTotal;
      } else {
        otherUnprovedTotal += orderTotal;
      }

      // 부가세법 제48조 과세표준(10/11) 및 세액(1/11) 계산 (1원 단위 절사 반올림)
      const supplyValue = Math.round((orderTotal * 10) / 11);
      const vatAmount = orderTotal - supplyValue;

      classifiedOrders.push({
        orderId: order.orderId,
        orderTotal,
        paymentCategory: category,
        supplyValue,
        vatAmount,
        isTaxFree: false,
        commission
      });
    }

    const taxableGrossSales = creditCardTotal + cashReceiptTotal + otherUnprovedTotal;
    const taxableSupplyValue = Math.round((taxableGrossSales * 10) / 11);
    const taxableVatAmount = taxableGrossSales - taxableSupplyValue;

    // 결제수단별 공급가액/세액 분리 (무증빙 매출이 0원일 때 1원 단수차가 기타 매출로 전가되는 현상 방어)
    let cardSupply = Math.round((creditCardTotal * 10) / 11);
    let cardVat = creditCardTotal - cardSupply;

    let cashSupply = Math.round((cashReceiptTotal * 10) / 11);
    let cashVat = cashReceiptTotal - cashSupply;

    let otherSupply = 0;
    let otherVat = 0;

    if (otherUnprovedTotal > 0) {
      otherSupply = taxableSupplyValue - cardSupply - cashSupply;
      otherVat = taxableVatAmount - cardVat - cashVat;
    } else {
      const supplyDiff = taxableSupplyValue - (cardSupply + cashSupply);
      const vatDiff = taxableVatAmount - (cardVat + cashVat);
      if (supplyDiff !== 0 || vatDiff !== 0) {
        if (creditCardTotal >= cashReceiptTotal && creditCardTotal > 0) {
          cardSupply += supplyDiff;
          cardVat += vatDiff;
        } else if (cashReceiptTotal > 0) {
          cashSupply += supplyDiff;
          cashVat += vatDiff;
        }
      }
    }

    // 쿠팡 수수료 매입세액 (수수료 공급가액 및 부가세)
    const commissionSupply = Math.round((totalCoupangCommission * 10) / 11);
    const commissionVat = totalCoupangCommission - commissionSupply;

    // 셀러 순매출 (과세매출 + 면세매출 - 수수료)
    const netSellerSettlement = (taxableGrossSales + taxFreeTotal) - totalCoupangCommission;

    return {
      period: options.period || "2026년 부가가치세 과세기간",
      stats: {
        totalOrderCount: orders.length,
        grossSales: taxableGrossSales + taxFreeTotal,
        taxableGrossSales,
        taxFreeTotal,
        taxableSupplyValue,
        taxableVatAmount,
        breakdown: {
          creditCard: {
            gross: creditCardTotal,
            supplyValue: cardSupply,
            vat: cardVat,
            notice: "신용카드·체크카드 결제 (여신전문금융업법)"
          },
          cashReceipt: {
            gross: cashReceiptTotal,
            supplyValue: cashSupply,
            vat: cashVat,
            notice: "소득공제/지출증빙 현금영수증 (조세특례제한법)"
          },
          otherUnproved: {
            gross: otherUnprovedTotal,
            supplyValue: otherSupply,
            vat: otherVat,
            notice: "기타 무증빙/마일리지 (부가가치세법 제48조)"
          },
          taxFree: {
            gross: taxFreeTotal,
            supplyValue: taxFreeTotal,
            vat: 0,
            notice: "면세 농축수산물/도서 등 (부가가치세법 제26조)"
          }
        },
        deductions: {
          totalCoupangCommission,
          commissionSupply,
          commissionVat,
          notice: "쿠팡 판매수수료 세금계산서 매입세액 공제 가능액"
        },
        netSellerSettlement
      },
      orders: classifiedOrders
    };
  }

  /**
   * 세무사 제출용 1초 요약 텍스트 포맷팅
   */
  formatTaxAccountantSummary(vatData) {
    if (!vatData || typeof vatData !== "object" || !vatData.stats || typeof vatData.stats !== "object") return "";

    const s = vatData.stats;
    const b = (s.breakdown && typeof s.breakdown === "object") ? s.breakdown : {};
    const cc = (b.creditCard && typeof b.creditCard === "object") ? b.creditCard : {};
    const cr = (b.cashReceipt && typeof b.cashReceipt === "object") ? b.cashReceipt : {};
    const ou = (b.otherUnproved && typeof b.otherUnproved === "object") ? b.otherUnproved : {};
    const d = (s.deductions && typeof s.deductions === "object") ? s.deductions : {};

    return `[AutoFlow] 쿠팡 WING 부가가치세 신고용 매출·매입 원장 다이제스트
신고 과세기간: ${vatData.period || "2026년 부가세 과세기간"}
총 주문 건수: ${Number(s.totalOrderCount || 0).toLocaleString()}건

1. 과세 매출 합계 (VAT 포함): ₩${Number(s.taxableGrossSales || 0).toLocaleString()}
   - 공급가액: ₩${Number(s.taxableSupplyValue || 0).toLocaleString()}
   - 부가가치세액: ₩${Number(s.taxableVatAmount || 0).toLocaleString()}

2. 결제수단별 과세표준 세부내역:
   ① 신용카드 매출: ₩${Number(cc.gross || 0).toLocaleString()} (공급가액: ₩${Number(cc.supplyValue || 0).toLocaleString()} / 세액: ₩${Number(cc.vat || 0).toLocaleString()})
   ② 현금영수증 매출: ₩${Number(cr.gross || 0).toLocaleString()} (공급가액: ₩${Number(cr.supplyValue || 0).toLocaleString()} / 세액: ₩${Number(cr.vat || 0).toLocaleString()})
   ③ 기타(무증빙/마일리지) 매출: ₩${Number(ou.gross || 0).toLocaleString()} (공급가액: ₩${Number(ou.supplyValue || 0).toLocaleString()} / 세액: ₩${Number(ou.vat || 0).toLocaleString()})

3. 면세 매출 합계: ₩${Number(s.taxFreeTotal || 0).toLocaleString()}

4. 쿠팡 판매수수료 매입세액 공제 참고액:
   - 총 수수료 차감액: ₩${Number(d.totalCoupangCommission || 0).toLocaleString()}
   - 매입 공급가액: ₩${Number(d.commissionSupply || 0).toLocaleString()}
   - 매입세액 (공제 대상): ₩${Number(d.commissionVat || 0).toLocaleString()}

* [세무 주의사항] 쿠팡 결제 시 발행된 신용카드 및 현금영수증 매출은 전자세금계산서 중복 발행 시 1~2% 가산세 대상이 되므로 홈택스 신고 시 '신용카드·현금영수증 발행분' 란에 기재하시기 바랍니다.`;
  }

  /**
   * Pure White Clean Enterprise 라이트 모드 부가세 공식 소명 원장 증적서 HTML
   * (공문서 표준 `(인쇄 시 직인 생략)` 준수, 붉은 직인 0건)
   */
  generateVatAuditReportHtml(period, vatData, customConfig = {}) {
    if (period && typeof period === "object") {
      if (!vatData || typeof vatData !== "object") {
        vatData = period.vatData || (period.stats ? period : {});
      }
      period = typeof period.period === "string" ? period.period : "2026년 정기";
    }
    period = (typeof period === "string" && period.trim()) ? period : "2026년 정기";
    vatData = (vatData && typeof vatData === "object") ? vatData : {};
    customConfig = (customConfig && typeof customConfig === "object") ? customConfig : {};

    const config = Object.assign({}, this.getConfig(), customConfig);
    const storeName = config.storeName || "AutoFlow 스토어";
    const bizNo = config.businessRegistrationNumber || "000-00-00000";
    const issueDate = new Date(Date.now() + 9 * 3600000).toISOString().substring(0, 10);
    const generatedDate = issueDate;
    const rawStats = (vatData && vatData.stats && typeof vatData.stats === "object") ? vatData.stats : {};
    const rawB = (rawStats.breakdown && typeof rawStats.breakdown === "object") ? rawStats.breakdown : {};
    const rawD = (rawStats.deductions && typeof rawStats.deductions === "object") ? rawStats.deductions : {};

    const s = {
      totalOrderCount: Number(rawStats.totalOrderCount || 0),
      grossSales: Number(rawStats.grossSales || 0),
      taxableGrossSales: Number(rawStats.taxableGrossSales || 0),
      taxFreeTotal: Number(rawStats.taxFreeTotal || 0),
      taxableSupplyValue: Number(rawStats.taxableSupplyValue || 0),
      taxableVatAmount: Number(rawStats.taxableVatAmount || 0),
      breakdown: {
        creditCard: Object.assign({ gross: 0, supplyValue: 0, vat: 0 }, rawB.creditCard),
        cashReceipt: Object.assign({ gross: 0, supplyValue: 0, vat: 0 }, rawB.cashReceipt),
        otherUnproved: Object.assign({ gross: 0, supplyValue: 0, vat: 0 }, rawB.otherUnproved),
        taxFree: Object.assign({ gross: 0, supplyValue: 0, vat: 0 }, rawB.taxFree)
      },
      deductions: Object.assign({ totalCoupangCommission: 0, commissionSupply: 0, commissionVat: 0 }, rawD),
      netSellerSettlement: Number(rawStats.netSellerSettlement || 0)
    };
    const b = s.breakdown;
    const d = s.deductions;

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>부가가치세 과세표준 및 매출 집계 증적서 - ${storeName}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo", "Malgun Gothic", sans-serif;
      margin: 40px auto;
      max-width: 820px;
      color: #0f172a;
      background: #ffffff;
      line-height: 1.6;
    }
    .header {
      border-bottom: 2px solid #0f172a;
      padding-bottom: 16px;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
    }
    .header h1 {
      font-size: 24px;
      margin: 0;
      color: #0f172a;
      letter-spacing: -0.5px;
    }
    .meta {
      font-size: 12px;
      color: #475569;
      text-align: right;
    }
    .section-title {
      font-size: 14px;
      font-weight: 700;
      margin: 20px 0 8px 0;
      color: #1e293b;
      display: flex;
      justify-content: space-between;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 18px;
      font-size: 12px;
    }
    th, td {
      border: 1px solid #cbd5e1;
      padding: 8px 10px;
      text-align: right;
    }
    th {
      background: #f8fafc;
      color: #334155;
      font-weight: 600;
      text-align: center;
    }
    .text-left { text-align: left; }
    .text-center { text-align: center; }
    .highlight { background: #f0fdf4; font-weight: 700; }
    .footer {
      margin-top: 36px;
      border-top: 1px solid #e2e8f0;
      padding-top: 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 11px;
      color: #64748b;
    }
    .notice-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 12px;
      font-size: 11px;
      color: #475569;
      margin-top: 16px;
    }
    @media print {
      body { margin: 20px; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h1>부가가치세 과세표준 및 매출 집계 증적서</h1>
      <div style="font-size: 12px; color: #64748b; margin-top: 4px;">국세청 부가가치세 신고 준용 전자세무원장 대사 리포트</div>
    </div>
    <div class="meta">
      <div><strong>상호:</strong> ${storeName}</div>
      <div><strong>사업자등록번호:</strong> ${bizNo}</div>
      <div><strong>과세기간:</strong> ${period || "2026년 정기"}</div>
      <div><strong>발급일자:</strong> ${generatedDate}</div>
    </div>
  </div>

  <div class="section-title">
    <span>1. 부가가치세 과세표준 총괄 요약</span>
    <span style="font-size: 11px; color: #64748b; font-weight: normal;">(단위: 원, VAT 포함)</span>
  </div>
  <table>
    <thead>
      <tr>
        <th>구분</th>
        <th>주문 건수</th>
        <th>총 매출액 (결제금액)</th>
        <th>공급가액</th>
        <th>부가가치세액</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="text-left">과세 매출 (10% 세율)</td>
        <td class="text-center">${Number(s.totalOrderCount || 0).toLocaleString()}건</td>
        <td>₩${Number(s.taxableGrossSales || 0).toLocaleString()}</td>
        <td>₩${Number(s.taxableSupplyValue || 0).toLocaleString()}</td>
        <td>₩${Number(s.taxableVatAmount || 0).toLocaleString()}</td>
      </tr>
      <tr>
        <td class="text-left">면세 매출 (농수산물/도서 등)</td>
        <td class="text-center">-</td>
        <td>₩${Number(s.taxFreeTotal || 0).toLocaleString()}</td>
        <td>₩${Number(s.taxFreeTotal || 0).toLocaleString()}</td>
        <td>₩0</td>
      </tr>
      <tr class="highlight">
        <td class="text-left"><strong>합계 (총 매출)</strong></td>
        <td class="text-center"><strong>${Number(s.totalOrderCount || 0).toLocaleString()}건</strong></td>
        <td><strong>₩${Number(s.grossSales || 0).toLocaleString()}</strong></td>
        <td><strong>₩${Number((s.taxableSupplyValue || 0) + (s.taxFreeTotal || 0)).toLocaleString()}</strong></td>
        <td><strong>₩${Number(s.taxableVatAmount || 0).toLocaleString()}</strong></td>
      </tr>
    </tbody>
  </table>

  <div class="section-title">
    <span>2. 결제수단별 과세표준 명세 (홈택스 서식 매핑)</span>
  </div>
  <table>
    <thead>
      <tr>
        <th>홈택스 신고 서식 항목</th>
        <th>쿠팡 WING 결제수단</th>
        <th>총 결제금액</th>
        <th>공급가액</th>
        <th>부가가치세액</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="text-left">신용·체크카드 발행분</td>
        <td class="text-left">국내외 신용/체크카드 결제</td>
        <td>₩${Number(b.creditCard.gross || 0).toLocaleString()}</td>
        <td>₩${Number(b.creditCard.supplyValue || 0).toLocaleString()}</td>
        <td>₩${Number(b.creditCard.vat || 0).toLocaleString()}</td>
      </tr>
      <tr>
        <td class="text-left">현금영수증 발행분</td>
        <td class="text-left">소득공제/지출증빙 현금영수증</td>
        <td>₩${Number(b.cashReceipt.gross || 0).toLocaleString()}</td>
        <td>₩${Number(b.cashReceipt.supplyValue || 0).toLocaleString()}</td>
        <td>₩${Number(b.cashReceipt.vat || 0).toLocaleString()}</td>
      </tr>
      <tr>
        <td class="text-left">기타(정규영수증 외) 매출분</td>
        <td class="text-left">쿠팡캐시, 포인트, 무증빙</td>
        <td>₩${Number(b.otherUnproved.gross || 0).toLocaleString()}</td>
        <td>₩${Number(b.otherUnproved.supplyValue || 0).toLocaleString()}</td>
        <td>₩${Number(b.otherUnproved.vat || 0).toLocaleString()}</td>
      </tr>
    </tbody>
  </table>

  <div class="section-title">
    <span>3. 쿠팡 판매수수료 매입세액 공제 참고 내역</span>
  </div>
  <table>
    <thead>
      <tr>
        <th>수수료 구분</th>
        <th>총 공제 수수료</th>
        <th>매입 공급가액</th>
        <th>매입세액 (공제 대상)</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="text-left">쿠팡 WING 판매/결제/배송 수수료</td>
        <td>₩${Number(d.totalCoupangCommission || 0).toLocaleString()}</td>
        <td>₩${Number(d.commissionSupply || 0).toLocaleString()}</td>
        <td style="color: #15803d; font-weight: 700;">₩${Number(d.commissionVat || 0).toLocaleString()}</td>
      </tr>
    </tbody>
  </table>

  <div class="notice-box">
    <strong>⚖️ [세무 및 법률 준수 고지]</strong><br>
    1. 본 증적서는 「부가가치세법」 제32조, 제36조 및 제48조에 의거하여 쿠팡 WING 오픈마켓의 실 결제원장을 역산·대사하여 작성되었습니다.<br>
    2. <strong>이중발행 가산세 방어:</strong> 쿠팡 플랫폼에서 소비자를 상대로 기발행된 신용카드 및 현금영수증 매출에 대해 판매자가 별도의 전자세금계산서를 중복 발급할 경우 「부가가치세법」 제60조에 따른 가산세(1~2%)가 부과될 수 있으니 주의하시기 바랍니다.<br>
    3. <strong>무증빙 과소신고 방어:</strong> 쿠팡캐시 등 기타 매출을 누락 없이 신고함으로써 조세범 처벌법상 과소신고가산세(10~40%)를 원천 차단합니다.
  </div>

  <div class="footer">
    <div>발급 시스템: AutoFlow Enterprise VAT Sales Sentinel v2.0 (인쇄 시 직인 생략)</div>
    <div>문의처: ${config.taxAccountantEmail || "contact@autoflow.local"}</div>
  </div>
</body>
</html>`;
  }

  /**
   * 감사 증적 영속화
   */
  recordVatAuditTrail(vatData = {}) {
    const hasStats = Boolean(vatData && typeof vatData === "object" && vatData.stats && typeof vatData.stats === "object");
    vatData = (vatData && typeof vatData === "object") ? vatData : {};
    this._ensureStorage();
    try {
      const record = {
        auditId: `VAT-AUDIT-${Date.now()}`,
        recordedAt: Date.now(),
        recordedDate: new Date().toISOString(),
        period: vatData.period || "2026년 정기",
        stats: hasStats ? vatData.stats : this.calculateVatBreakdown([]).stats
      };

      if (!hasStats) {
        return { success: true, record };
      }

      const data = JSON.parse(fs.readFileSync(this.storagePath, "utf8")) || {};
      data.auditRecords = (Array.isArray(data.auditRecords) ? data.auditRecords : []).filter(
        r => r && typeof r === "object" && r.auditId && r.stats && typeof r.stats === "object"
      );

      data.auditRecords.push(record);
      if (data.auditRecords.length > 500) {
        data.auditRecords = data.auditRecords.slice(-500);
      }
      data.lastAuditTime = Date.now();
      const tmpPath = `${this.storagePath}.tmp.${process.pid}.${Date.now()}`;
      fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), "utf8");
      fs.renameSync(tmpPath, this.storagePath);
      return { success: true, record };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  /**
   * 부가세 집계 요약 통계 조회
   */
  getVatSummary() {
    this._ensureStorage();
    try {
      const data = JSON.parse(fs.readFileSync(this.storagePath, "utf8")) || {};
      const records = (Array.isArray(data.auditRecords) ? data.auditRecords : []).filter(
        r => r && typeof r === "object" && r.auditId && r.stats && typeof r.stats === "object"
      );
      const latest = records[records.length - 1] || null;

      return {
        totalAuditCount: records.length,
        lastAuditTime: data.lastAuditTime || null,
        latestRecord: latest,
        recentRecords: records.slice(-10)
      };
    } catch (err) {
      return {
        totalAuditCount: 0,
        lastAuditTime: null,
        latestRecord: null,
        recentRecords: [],
        error: err.message
      };
    }
  }
}

const createVatSalesSentinel = (options = {}) => new VatSalesSentinel(options);
VatSalesSentinel.createVatSalesSentinel = createVatSalesSentinel;

module.exports = {
  VatSalesSentinel,
  createVatSalesSentinel
};
