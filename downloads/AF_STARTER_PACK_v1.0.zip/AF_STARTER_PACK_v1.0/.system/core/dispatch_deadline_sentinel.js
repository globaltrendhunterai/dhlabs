/**
 * AutoFlow Engine - Coupang Dispatch Deadline & Late-Shipment Airbag Sentinel
 *
 * [역할 및 법무/비즈니스 배경]
 * 1. 쿠팡 WING은 판매자가 약속한 출고예정일 내에 상품을 출고(송장 등록)하지 않으면
 *    '정시출고율' 지표가 급락하여 판매자 점수 감점, 상품 노출 제한(아이템위너 배제),
 *    판매 대금 정산 지연, 개선계획서 징구 및 심할 경우 '판매자 계정 정지' 처분을 내립니다.
 * 2. 또한 「전자상거래 등에서의 소비자보호에 관한 법률」 제15조(재화등의 공급)에 따라
 *    소비자 청약일로부터 법정 기한 내 물품 공급 조치를 완료해야 하며, 지연 시 분쟁 및 과태료 위험이 발생합니다.
 * 3. 본 Sentinel은 주문별 결제일시와 약속된 출고예정일을 역산하여 잔여 시간을 1초 만에 산출하고,
 *    마감 임박(URGENT, 4시간 이내) 및 초긴급(CRITICAL, 1시간 이내), 마감 초과(OVERDUE)를 실시간 감별하여
 *    셀러에게 긴급 출고 알림을 발송하고 계정 정지 리스크를 원천 차단합니다.
 *
 * [공문서 및 알림 표준]
 * - Pure White Clean Enterprise 라이트 모드 준수
 * - 알림 메시지에 [⏰ 출고 마감 카운트다운] 블록 생성
 * - 감사 로그: logs/urgent_dispatch_orders.json 영속화
 */

const fs = require("fs");
const path = require("path");

class DispatchDeadlineSentinel {
  constructor(options = {}) {
    this.cutoffHour = options.cutoffHour || 16; // 기본 당일 출고 마감 시각: 16:00
    this.urgentThresholdMs = 4 * 60 * 60 * 1000; // 4시간 이내: URGENT
    this.criticalThresholdMs = 1 * 60 * 60 * 1000; // 1시간 이내: CRITICAL
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/urgent_dispatch_orders.json");

    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(this.storagePath, JSON.stringify({ orders: [], lastUpdated: new Date().toISOString() }, null, 2), "utf8");
      }
    } catch (e) {
      // safe fallback
    }
  }

  /**
   * 단일 주문의 출고 마감 기한 및 상태 평가
   * @param {Object} order - { orderId, orderedAt, promisedShippingDate, vendorItemId, productName }
   * @param {Date} [currentTime] - 테스트용 기준 시각
   * @returns {Object} { orderId, deadline, remainingMs, remainingHours, status, statusText, badgeColor }
   */
  evaluateOrderDeadline(order, currentTime = new Date()) {
    if (!order || !order.orderId) {
      return {
        valid: false,
        error: "ORDER_DATA_REQUIRED",
        status: "UNKNOWN"
      };
    }

    const now = new Date(currentTime).getTime();
    let deadlineDate;

    if (order.promisedShippingDate) {
      if (typeof order.promisedShippingDate === "string" && /^\d{4}[-/]\d{2}[-/]\d{2}$/.test(order.promisedShippingDate.trim())) {
        // YYYY-MM-DD 형식의 날짜만 주어진 경우: 해당 날짜의 출고 마감 시각(기본 16:00) 설정
        const parts = order.promisedShippingDate.trim().split(/[-/]/);
        deadlineDate = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10), this.cutoffHour, 0, 0, 0);
      } else {
        deadlineDate = new Date(order.promisedShippingDate);
        if (isNaN(deadlineDate.getTime())) {
          deadlineDate = new Date(order.orderedAt || now);
        }
      }
    } else if (order.orderedAt) {
      deadlineDate = new Date(order.orderedAt);
    } else {
      deadlineDate = new Date(now);
    }

    const deadlineMs = deadlineDate.getTime();
    const remainingMs = deadlineMs - now;
    const remainingMinutes = Math.floor(remainingMs / (60 * 1000));
    const remainingHours = (remainingMs / (60 * 60 * 1000)).toFixed(1);

    let status = "NORMAL";
    let statusText = "출고 여유 (정상)";
    let badgeColor = "#10b981"; // 초록

    if (remainingMs <= 0) {
      status = "OVERDUE";
      statusText = `출고 기한 초과 (${Math.abs(remainingMinutes)}분 경과) — 패널티 위험!`;
      badgeColor = "#0f172a"; // 블랙 경보
    } else if (remainingMs <= this.criticalThresholdMs) {
      status = "CRITICAL";
      statusText = `🚨 초긴급: ${remainingMinutes}분 이내 출고 필수 (계정 보호)`;
      badgeColor = "#ef4444"; // 레드
    } else if (remainingMs <= this.urgentThresholdMs) {
      status = "URGENT";
      statusText = `⚠️ 주의: ${remainingMinutes}분 남음 (오늘 마감 임박)`;
      badgeColor = "#f59e0b"; // 앰버
    }

    return {
      valid: true,
      orderId: order.orderId,
      productName: order.productName || "기본 등록 상품",
      deadline: deadlineDate.toISOString(),
      remainingMs,
      remainingMinutes,
      remainingHours: parseFloat(remainingHours),
      status,
      statusText,
      badgeColor
    };
  }

  /**
   * 알림 메시지용 [⏰ 출고 마감 카운트다운] 블록 생성
   * @param {Object} evaluation - evaluateOrderDeadline의 결과
   * @returns {string} 포맷팅된 텍스트 블록
   */
  formatDeadlineAlertBlock(evaluation) {
    if (!evaluation || !evaluation.valid) return "";

    const icon = evaluation.status === "OVERDUE" ? "⛔" :
                 evaluation.status === "CRITICAL" ? "🚨" :
                 evaluation.status === "URGENT" ? "⚠️" : "⏰";

    const deadlineLocal = new Date(evaluation.deadline).toLocaleString("ko-KR", {
      timeZone: "Asia/Seoul",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });

    let lines = [
      `----------------------------------------`,
      `${icon} [쿠팡 정시출고 수호] 출고 마감 카운트다운`,
      `* 주문번호: ${evaluation.orderId}`,
      `* 출고 마감: ${deadlineLocal}`,
      `* 상태 진단: ${evaluation.statusText}`
    ];

    if (evaluation.status === "OVERDUE" || evaluation.status === "CRITICAL") {
      lines.push(`* 경고 안내: 출고 지연 시 쿠팡 정시출고율 하락 및 판매 정지 패널티가 부과될 수 있습니다.`);
      lines.push(`* 권고 조치: 송장 번호를 즉시 등록하거나 불가피할 경우 고객센터로 지연 안내를 등록하십시오.`);
    }

    lines.push(`----------------------------------------`);
    return lines.join("\n");
  }

  /**
   * 임박/초과 주문 큐 기록
   */
  recordUrgentOrder(order, evaluation) {
    try {
      this._ensureStorage();
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const data = JSON.parse(raw);
      const orders = data.orders || [];

      // 중복 제거 후 최신 상태 갱신
      const filtered = orders.filter(o => o.orderId !== order.orderId);
      filtered.unshift({
        orderId: order.orderId,
        productName: order.productName || "상품",
        deadline: evaluation.deadline,
        status: evaluation.status,
        statusText: evaluation.statusText,
        recordedAt: new Date().toISOString()
      });

      // 최대 200건 보관
      const trimmed = filtered.slice(0, 200);
      fs.writeFileSync(this.storagePath, JSON.stringify({ orders: trimmed, lastUpdated: new Date().toISOString() }, null, 2), "utf8");
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * 현재 임박/초과 주문 큐 조회
   */
  getUrgentOrdersSummary() {
    try {
      this._ensureStorage();
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const data = JSON.parse(raw);
      const orders = data.orders || [];

      let counts = {
        NORMAL: 0,
        URGENT: 0,
        CRITICAL: 0,
        OVERDUE: 0,
        total: orders.length
      };

      orders.forEach(o => {
        if (counts[o.status] !== undefined) {
          counts[o.status]++;
        }
      });

      return {
        success: true,
        counts,
        orders,
        lastUpdated: data.lastUpdated
      };
    } catch (e) {
      return {
        success: false,
        counts: { NORMAL: 0, URGENT: 0, CRITICAL: 0, OVERDUE: 0, total: 0 },
        orders: [],
        error: e.message
      };
    }
  }
}

const defaultDispatchDeadlineSentinel = new DispatchDeadlineSentinel();

module.exports = {
  DispatchDeadlineSentinel,
  dispatchDeadlineSentinel: defaultDispatchDeadlineSentinel
};
