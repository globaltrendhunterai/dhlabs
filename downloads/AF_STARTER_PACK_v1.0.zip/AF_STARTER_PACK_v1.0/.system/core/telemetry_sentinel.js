/**
 * core/telemetry_sentinel.js
 * 
 * AutoFlow Enterprise Telemetry Sentinel (100% Backward-Compatible Facade)
 * 
 * Unified into core/telemetry_beacon.js:
 * All heartbeat telemetry, PII-scrubbed unresolved DLQ alerts, and hot-patching
 * are now executed directly via the unified core/telemetry_beacon.js engine.
 * This facade preserves 100% API compatibility while eliminating double-ping and file fragmentation.
 */

const beacon = require('./telemetry_beacon');

class TelemetrySentinel {
  constructor(options = {}) {
    this.controlUrl = options.controlUrl || process.env.AUTOFLOW_TELEMETRY_URL || 'https://autoflow.io/api/telemetry/beacon';
    this.hwid = options.hwid || beacon.getOrCreateHardwareId();
    this.clientVersion = options.clientVersion || '2.0.0';
    this.mockTransport = options.mockTransport || null;
    if (this.mockTransport) {
      beacon.setMockTransport(this.mockTransport);
    }
  }

  /**
   * Dispatches 60-second periodic heartbeat ping via unified beacon
   */
  async sendHeartbeatPing(payload = {}) {
    return beacon.sendHeartbeatPing(
      Object.assign({ hwid: this.hwid, client_version: this.clientVersion }, payload),
      this.controlUrl,
      { mockTransport: this.mockTransport }
    );
  }

  /**
   * Dispatches PII-scrubbed unresolved DLQ fault alert ping via unified beacon
   */
  async sendUnresolvedHealingPing(errorPayload = {}) {
    return beacon.sendUnresolvedHealingPing(
      errorPayload,
      this.controlUrl,
      { mockTransport: this.mockTransport }
    );
  }

  /**
   * Dispatches PII-scrubbed resolved error-log pattern (log_only: true) to central server & fine-tuning dataset
   */
  async sendResolvedHealingPing(resolutionPayload = {}, options = {}) {
    return beacon.sendResolvedHealingPing(
      resolutionPayload,
      this.controlUrl,
      Object.assign({ mockTransport: this.mockTransport }, options)
    );
  }

  /**
   * Ingests and sandbox-verifies remote hot-patch via unified beacon
   */
  async applyRemoteHotPatch(signedPatchData) {
    return beacon.applyRemoteHotPatch(signedPatchData);
  }

  /**
   * Starts periodic telemetry scheduler
   */
  startTelemetryScheduler(intervalMs = 60000) {
    beacon.startTelemetryScheduler(intervalMs);
    return this;
  }

  /**
   * Stops periodic telemetry scheduler
   */
  stopTelemetryScheduler() {
    beacon.stopTelemetryScheduler();
  }
}

const defaultSentinel = new TelemetrySentinel();

module.exports = {
  TelemetrySentinel,
  sendHeartbeatPing: (p) => defaultSentinel.sendHeartbeatPing(p),
  sendUnresolvedHealingPing: (e) => defaultSentinel.sendUnresolvedHealingPing(e),
  sendResolvedHealingPing: (r, opts) => defaultSentinel.sendResolvedHealingPing(r, opts),
  applyRemoteHotPatch: (patch) => defaultSentinel.applyRemoteHotPatch(patch),
  startTelemetryScheduler: (ms) => defaultSentinel.startTelemetryScheduler(ms),
  stopTelemetryScheduler: () => defaultSentinel.stopTelemetryScheduler()
};
