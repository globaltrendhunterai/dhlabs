/**
 * AutoFlow CS (Customer Service) Domain-Specific Integrity, Grounded Fact-Checking & Self-Tuning Sentinel
 * (core/cs_domain_integrity_sentinel.js)
 *
 * [아키텍처 — 틀 2: AI 고객응대(CS) 전용 고도화 엔진]
 * 단순 정규식 필터를 넘어, 고객사가 자사의 사업장 정보·상품 카탈로그·사내 규정을 직접 입력하여
 * '셀프 튜닝(Self-Tuning Studio)'하고, AI 답변이 사내 팩트와 어긋나면 1:1 대조하여 자동 교정(Self-Heal)하는
 * 멀티레이어 프로덕션 엔진:
 *
 * 1. [CS-Part 1: Self-Tuning Compiler]
 *    고객사 기본 프로필, 6대 운영 정책(환불기간·배송비·보증기간 등), 상품 카탈로그(SKU·가격·재고),
 *    FAQ 코퍼스를 파싱·인덱싱하여 로컬 지식 금고(Knowledge Vault) 및 결정론적 정책 AST를 컴파일.
 *
 * 2. [CS-Part 2: Multi-Lingual Intent & Grounded Fact Retriever]
 *    글로벌 12개 국어(KO, EN, JA, ZH, ES 등) 문의 감지 및 카탈로그 키워드 매칭을 통해
 *    해당 상품의 정확한 가격, 재고, 적용 정책 조항을 0.1초 만에 추출하여 LLM 그라운딩 팩트로 공급.
 *
 * 3. [CS-Part 3: Grounded Fact Cross-Checker & Auto-Healer]
 *    AI 답변 초안을 컴파일된 사내 정책 및 상품 스펙과 1:1 대조:
 *    - 환불 가능 기간 불일치(회사 규정 7일인데 AI가 30일 안내 등) 적발 및 자동 교정
 *    - 반품 배송비/교환 비용 허위 안내 적발 및 사내 공시 금액으로 자동 교정
 *    - 상품 가격/재고 상태 왜곡(품절 상품 즉시 출고 안내 등) 적발 및 실제 데이터로 교정
 *    - 미치환 템플릿 변수({{...}}, [NAME_1], undefined) 실명/정보 복원
 *    - 사내 승인 없는 전액 배상/위자료 임의 약속 차단
 *
 * 4. [CS-Part 4: Global Crisis Shield & Thread Debouncer]
 *    국제(FTC, BBB, GDPR, FDA, Lawsuit, Chargeback) 및 국내(소보원, 식약처, 고소 등)
 *    법적·안전 고위험 민원 즉시 감지 시 자동 발송 동결(CRISIS_HOLD_HUMAN_REQUIRED) 및
 *    동일 고객 연속 문의(Burst) 단일 스레드 병합.
 */

'use strict';

const crypto = require('crypto');

// 1. 글로벌 고위험 위기 민원 키워드 (KO, EN, JA, ZH)
const GLOBAL_CRISIS_REGEX = new RegExp([
  // 한국어 (소비자원, 고소, 식약처 등)
  '소비자원', '소보원', '공정위', '공정거래위원회', '식약처', '고소', '고발', '변호사', '경찰서', '사기죄',
  '언론\\s*제보', '뉴스\\s*제보', '방송국\\s*제보', '피부.*뒤집', '응급실', '병원\\s*입원', '심각한\\s*부작용', '알레르기\\s*쇼크', '집단\\s*소송',
  // 영어 (FTC, BBB, GDPR, Lawsuit, Anaphylaxis, FDA 등)
  '\\bFTC\\b', 'federal\\s*trade\\s*commission', '\\bBBB\\b', 'better\\s*business\\s*bureau', '\\bGDPR\\b', 'data\\s*protection\\s*officer',
  'chargeback', 'dispute\\s*with\\s*my\\s*bank', 'attorney', 'lawyer', 'lawsuit', 'legal\\s*action', 'take\\s*you\\s*to\\s*court',
  '\\bFDA\\b', 'emergency\\s*room', 'hospitalized', 'severe\\s*allergic', 'anaphylaxis', 'class\\s*action', 'police\\s*report',
  // 일본어 (消費者庁, 訴訟 등)
  '消費者庁', '国民生活センター', '警察', '訴訟', '弁護士', '救急', '副作用', '詐欺',
  // 중국어 (消协, 起诉 등)
  '消费者协会', '消协', '市场监管局', '起诉', '律师', '报警', '公安局', '过敏休克', '急诊'
].join('|'), 'i');

// 2. 사내 승인 없는 임의 배상/환불 약속 패턴
const UNAUTHORIZED_PROMISE_TEST_REGEX = /(무조건\s*전액\s*환불|100%\s*무상\s*환불|전액\s*배상해\s*드리|위자료\s*지급|보상금\s*즉시\s*지급|무조건\s*무료\s*교환|현금으로\s*즉시\s*입금|unconditional\s*full\s*refund|100%\s*money\s*back\s*guarantee|compensate\s*all\s*damages)/i;
const UNAUTHORIZED_PROMISE_REPLACE_REGEX = /(무조건\s*전액\s*환불(?:해\s*드리겠습니다|해\s*드립니다|\s*가능합니다)?|100%\s*무상\s*환불(?:해\s*드리겠습니다|해\s*드립니다|\s*가능합니다)?|전액\s*배상해\s*드리(?:겠습니다|겠으며)?|위자료\s*지급|보상금\s*즉시\s*지급|무조건\s*무료\s*교환|현금으로\s*즉시\s*입금|unconditional\s*full\s*refund|100%\s*money\s*back\s*guarantee|compensate\s*all\s*damages)/gi;

// 3. 미치환 변수 및 깨진 마스킹 토큰
const UNRESOLVED_VAR_TEST_REGEX = /(\{\{\s*[^}]+\s*\}\}|\$\{\s*[^}]+\s*\}|\[(?:NAME|PHONE|EMAIL|ADDR|ACCOUNT)_\d+\]|\bundefined\b|\bnull\b|\[object Object\])/;

// 4. 부적절/공격적 어조
const AGGRESSIVE_TONE_TEST_REGEX = /(고객님\s*과실입니다|알아서\s*하세요|환불\s*절대\s*안\s*됨|책임\s*못\s*집니다|법대로\s*하세요|your\s*own\s*fault|not\s*our\s*responsibility|sue\s*us\s*if\s*you\s*want)/i;
const AGGRESSIVE_TONE_REPLACE_REGEX = /(고객님\s*과실입니다|알아서\s*하세요|환불\s*절대\s*안\s*됨|책임\s*못\s*집니다|법대로\s*하세요|your\s*own\s*fault|not\s*our\s*responsibility|sue\s*us\s*if\s*you\s*want)/gi;

// 모듈 단위 공유 활성 튜닝 프로필 (싱글톤 호환)
let SHARED_TUNED_PROFILE = null;

class CsDomainIntegritySentinel {
  constructor(options = {}) {
    const safeOpts = (options && typeof options === 'object' && !Array.isArray(options)) ? options : {};
    this.defaultBurstWindowMs = Number(safeOpts.burstWindowMs) > 0 ? Number(safeOpts.burstWindowMs) : 10 * 60 * 1000;
    this.defaultFallbackCustomerName = String(safeOpts.fallbackCustomerName || '고객');
    this.defaultCurrency = String(safeOpts.defaultCurrency || 'KRW').toUpperCase();

    // 기본 셀프 튜닝 정책 상태
    this.activeTunedProfile = null;
  }

  // ===========================================================================
  // [CS-Part 1] 사업장 정보 & 상품 카탈로그 셀프 튜닝 컴파일러 (Self-Tuning Compiler)
  // ===========================================================================

  /**
   * 고객사가 입력한 사업장 정보, 6대 운영 정책, 상품 카탈로그, FAQ를 인덱싱하여 로컬 지식 금고로 컴파일
   * @param {Object} tuneSpec { businessProfile, policyRules, productCatalog, faqCorpus }
   */
  compileBusinessPolicyAndCatalog(tuneSpec = {}) {
    const spec = (tuneSpec && typeof tuneSpec === 'object' && !Array.isArray(tuneSpec)) ? tuneSpec : {};

    const profile = (spec.businessProfile && typeof spec.businessProfile === 'object') ? spec.businessProfile : {};
    const storeName = String(profile.storeName || '공식 고객센터').trim();
    const websiteUrl = String(profile.websiteUrl || '').trim();
    const supportEmail = String(profile.supportEmail || 'support@autoflow.local').trim();
    const supportPhone = String(profile.supportPhone || '').trim();
    const operatingHours = String(profile.operatingHours || '평일 09:00 - 18:00 (주말/공휴일 휴무)').trim();
    const brandTone = String(profile.brandTone || 'POLITE_PROFESSIONAL').toUpperCase();

    const policies = (spec.policyRules && typeof spec.policyRules === 'object') ? spec.policyRules : {};
    const returnWindowDays = Number.isFinite(Number(policies.returnWindowDays)) ? Number(policies.returnWindowDays) : 7;
    const returnShippingFee = Number.isFinite(Number(policies.returnShippingFee)) ? Number(policies.returnShippingFee) : 3000;
    const freeShippingThreshold = Number.isFinite(Number(policies.freeShippingThreshold)) ? Number(policies.freeShippingThreshold) : 50000;
    const standardShippingFee = Number.isFinite(Number(policies.standardShippingFee)) ? Number(policies.standardShippingFee) : 3000;
    const warrantyMonths = Number.isFinite(Number(policies.warrantyMonths)) ? Number(policies.warrantyMonths) : 12;
    const maxInstantCompensationWon = Number.isFinite(Number(policies.maxInstantCompensationWon)) ? Number(policies.maxInstantCompensationWon) : 0;
    const currency = String(policies.currency || profile.currency || this.defaultCurrency).toUpperCase();

    // 상품 카탈로그 인덱싱
    const rawCatalog = Array.isArray(spec.productCatalog)
      ? spec.productCatalog
      : (Array.isArray(spec.catalog) ? spec.catalog : []);
    const indexedProducts = [];
    const productLookupByKeyword = new Map();

    for (const p of rawCatalog) {
      if (!p || typeof p !== 'object') continue;
      const sku = String(p.sku || p.id || `SKU_${indexedProducts.length + 1}`).trim();
      const name = String(p.name || p.title || '').trim();
      if (!name) continue;
      const price = Number(p.price) || 0;
      const prodCurrency = String(p.currency || currency).toUpperCase();
      const inStock = p.inStock !== false && p.stock !== 0;
      const category = String(p.category || 'GENERAL').trim();

      const prodEntry = Object.freeze({
        sku,
        name,
        price,
        currency: prodCurrency,
        inStock,
        category,
        returnPolicyDays: Number.isFinite(Number(p.returnWindowDays)) ? Number(p.returnWindowDays) : returnWindowDays,
        warrantyMonths: Number.isFinite(Number(p.warrantyMonths)) ? Number(p.warrantyMonths) : warrantyMonths
      });

      indexedProducts.push(prodEntry);

      // 키워드 색인 등록 (1글자 단어 및 전체 상품명 포함)
      const tokens = [
        sku.toLowerCase(),
        name.toLowerCase(),
        ...name.toLowerCase().split(/[\s/_-]+/)
      ].map((t) => t.trim()).filter((t) => t.length >= 1);
      for (const tok of tokens) {
        if (!productLookupByKeyword.has(tok)) productLookupByKeyword.set(tok, []);
        productLookupByKeyword.get(tok).push(prodEntry);
      }
    }

    // FAQ 코퍼스 인덱싱
    const rawFaq = Array.isArray(spec.faqCorpus) ? spec.faqCorpus : [];
    const indexedFaq = [];
    for (const f of rawFaq) {
      if (!f || typeof f !== 'object') continue;
      const question = String(f.q || f.question || '').trim();
      const answer = String(f.a || f.answer || '').trim();
      if (!question || !answer) continue;
      indexedFaq.push(Object.freeze({ question, answer, category: String(f.category || 'FAQ').trim() }));
    }

    const compiledProfile = Object.freeze({
      compiledAt: new Date().toISOString(),
      storeName,
      websiteUrl,
      supportEmail,
      supportPhone,
      operatingHours,
      brandTone,
      currency,
      policies: Object.freeze({
        returnWindowDays,
        returnShippingFee,
        freeShippingThreshold,
        standardShippingFee,
        warrantyMonths,
        maxInstantCompensationWon
      }),
      catalogSize: indexedProducts.length,
      faqSize: indexedFaq.length,
      products: Object.freeze(indexedProducts),
      faq: Object.freeze(indexedFaq)
    });

    this.activeTunedProfile = compiledProfile;
    SHARED_TUNED_PROFILE = compiledProfile;

    return {
      ok: true,
      status: 'COMPILED_BUSINESS_KNOWLEDGE_SUCCESS',
      storeName,
      currency,
      returnWindowDays,
      returnShippingFee,
      indexedProductCount: indexedProducts.length,
      indexedFaqCount: indexedFaq.length,
      compiledProfile
    };
  }

  // ===========================================================================
  // [CS-Part 2] 고객 문의 다국어 의도 분석 & 사내 팩트 실시간 매칭 (Grounded Fact Retriever)
  // ===========================================================================

  /**
   * 고객 문의 내용을 분석하여 언어 감지, 매칭 상품 SKU 스펙, 적용 정책 조항을 0.1초 내 추출
   * @param {Object} payload { inquiryText, tunedProfileOverride }
   */
  retrieveGroundedFactsForInquiry(payload = {}) {
    const safe = (payload && typeof payload === 'object' && !Array.isArray(payload)) ? payload : {};
    const text = String(safe.inquiryText || '').trim();
    const profile = safe.tunedProfileOverride || this.activeTunedProfile || SHARED_TUNED_PROFILE;

    // 언어 감지 (기본 휴리스틱: 한글, 영문, 일본어, 중국어 등)
    let detectedLang = 'EN';
    if (/[가-힣]/.test(text)) detectedLang = 'KO';
    else if (/[\u3040-\u30ff]/.test(text)) detectedLang = 'JA';
    else if (/[\u4e00-\u9fa5]/.test(text)) detectedLang = 'ZH';

    const matchedProducts = [];
    const matchedFaq = [];

    if (profile && Array.isArray(profile.products)) {
      const lower = text.toLowerCase();
      for (const p of profile.products) {
        if (lower.includes(p.name.toLowerCase()) || lower.includes(p.sku.toLowerCase())) {
          matchedProducts.push(p);
        }
      }
    }

    if (profile && Array.isArray(profile.faq)) {
      const lower = text.toLowerCase();
      for (const f of profile.faq) {
        const qTokens = f.question.toLowerCase().split(/\s+/).filter((t) => t.length >= 2);
        const matchCount = qTokens.filter((tok) => lower.includes(tok)).length;
        if (matchCount >= 2 || (qTokens.length === 1 && matchCount === 1)) {
          matchedFaq.push(f);
        }
      }
    }

    const effectivePolicies = profile ? profile.policies : {
      returnWindowDays: 7,
      returnShippingFee: 3000,
      freeShippingThreshold: 50000,
      standardShippingFee: 3000,
      warrantyMonths: 12
    };

    // LLM 프롬프트에 주입할 절대 불변 그라운딩 블록 생성
    const groundingConstraints = [
      `[MANDATORY STORE POLICIES - DO NOT DEVIATE]`,
      `Store Name: ${profile ? profile.storeName : 'Our Store'}`,
      `Return Window: Within ${effectivePolicies.returnWindowDays} days of receipt`,
      `Return Shipping Fee: ${effectivePolicies.returnShippingFee} ${profile ? profile.currency : 'KRW'}`,
      `Warranty: ${effectivePolicies.warrantyMonths} months`,
      matchedProducts.length > 0
        ? `Matched Products: ${matchedProducts.map((p) => `${p.name} (SKU: ${p.sku}, Price: ${p.price} ${p.currency}, InStock: ${p.inStock})`).join('; ')}`
        : `Matched Products: None explicitly detected in catalog`
    ].join('\n');

    return {
      ok: true,
      detectedLang,
      hasMatchedProducts: matchedProducts.length > 0,
      matchedProducts,
      matchedFaqCount: matchedFaq.length,
      matchedFaq: matchedFaq.slice(0, 3),
      effectivePolicies,
      groundingConstraints
    };
  }

  // ===========================================================================
  // [CS-Part 3] 튜닝 데이터 1:1 대조 환각(거짓말) 차단 & 자동 치유 (Fact Cross-Checker)
  // ===========================================================================

  /**
   * AI 작성 답변 초안을 컴파일된 실제 사내 정책 및 상품 스펙과 1:1 교차 대조하여 환각을 자동 교정
   * @param {Object} payload { draftText, customerName, policyOverride, matchedProducts, policyAllowDirectRefund }
   */
  verifyCsDraftIntegrity(payload = {}) {
    const safe = (payload && typeof payload === 'object' && !Array.isArray(payload)) ? payload : {};
    const rawDraft = typeof safe.draftText === 'string' ? safe.draftText : '';
    const customerName = (typeof safe.customerName === 'string' && safe.customerName.trim())
      ? safe.customerName.trim()
      : this.defaultFallbackCustomerName;

    const profile = this.activeTunedProfile;
    const policies = (safe.policyOverride && typeof safe.policyOverride === 'object')
      ? safe.policyOverride
      : (profile ? profile.policies : {
          returnWindowDays: 7,
          returnShippingFee: 3000,
          freeShippingThreshold: 50000,
          standardShippingFee: 3000,
          warrantyMonths: 12,
          maxInstantCompensationWon: 0
        });

    const currency = String(safe.currency || (profile ? profile.currency : this.defaultCurrency)).toUpperCase();
    const allowDirectRefund = Boolean(safe.policyAllowDirectRefund);
    const matchedProducts = Array.isArray(safe.matchedProducts) ? safe.matchedProducts : [];

    if (!rawDraft.trim()) {
      return {
        ok: true,
        status: 'EMPTY_DRAFT_FALLBACK_APPLIED',
        passed: false,
        autoHealed: true,
        violations: ['EMPTY_DRAFT_TEXT'],
        originalDraft: rawDraft,
        healedDraft: `안녕하세요 ${customerName}님, 남겨주신 문의 내용을 확인 중입니다. 담당자가 확인 후 신속히 안내드리겠습니다.`
      };
    }

    const violations = [];
    let healedDraft = rawDraft;

    // 1) 미치환 템플릿 변수 및 미복원 마스킹 토큰 검수·치유
    if (UNRESOLVED_VAR_TEST_REGEX.test(healedDraft)) {
      violations.push('UNRESOLVED_TEMPLATE_OR_MASK_TOKEN');
      healedDraft = healedDraft
        .replace(/\{\{\s*(?:customer_?name|name|user_?name)\s*\}\}/gi, customerName)
        .replace(/\$\{\s*(?:customer_?name|name|user_?name)\s*\}/gi, customerName)
        .replace(/\[NAME_\d+\]/g, customerName)
        .replace(/\[(?:PHONE|EMAIL|ADDR|ACCOUNT)_\d+\]/g, '등록하신 정보')
        .replace(/\{\{\s*[^}]+\s*\}\}/g, '')
        .replace(/\$\{\s*[^}]+\s*\}/g, '')
        .replace(/\[object Object\]/g, '')
        .replace(/\b(?:undefined|null)\b/g, '')
        .replace(/\s{2,}/g, ' ')
        .trim();
    }

    // 2) 환불 가능 일수 환각 교차 대조 & 사내 정책 기반 자동 교정
    //    AI가 "30일 이내 환불" 등으로 거짓말했는데 사내 규정은 7일 또는 14일인 경우
    const refundDayMatch = healedDraft.match(/(\d{1,2})\s*일\s*이내(?:에)?\s*(?:환불|반품)/i);
    if (refundDayMatch && refundDayMatch[1]) {
      const statedDays = Number(refundDayMatch[1]);
      if (statedDays !== policies.returnWindowDays) {
        violations.push('POLICY_CONTRADICTION_RETURN_WINDOW');
        healedDraft = healedDraft.replace(
          /(\d{1,2})\s*일\s*이내(?:에)?\s*(?:환불|반품)/gi,
          `수령 후 ${policies.returnWindowDays}일 이내 반품/환불`
        );
      }
    }

    // 영문 일수 환각 검수 ("within 30 days" -> "within 7 days")
    const engDayMatch = healedDraft.match(/within\s*(\d{1,2})\s*days/i);
    if (engDayMatch && engDayMatch[1]) {
      const statedDays = Number(engDayMatch[1]);
      if (statedDays !== policies.returnWindowDays) {
        violations.push('POLICY_CONTRADICTION_RETURN_WINDOW');
        healedDraft = healedDraft.replace(/within\s*(\d{1,2})\s*days/gi, `within ${policies.returnWindowDays} days`);
      }
    }

    // 3) 반품 배송비 무료 환각 교차 대조 & 사내 공시 금액으로 자연스러운 문맥 자동 교정
    if (policies.returnShippingFee > 0) {
      const freeReturnPromiseMatch = /(반품\s*비용은\s*무료(?:입니다)?|무료\s*반품(?:이\s*가능합니다)?|무료\s*반품|return\s*is\s*free|free\s*return)/i;
      if (freeReturnPromiseMatch.test(healedDraft)) {
        violations.push('POLICY_CONTRADICTION_RETURN_FEE');
        const feeStr = `${policies.returnShippingFee.toLocaleString()} ${currency}`;
        healedDraft = healedDraft
          .replace(/반품\s*비용은\s*무료(?:입니다)?/gi, `반품 배송비는 ${feeStr}입니다`)
          .replace(/무료\s*반품이\s*가능합니다/gi, `반품 배송비(${feeStr})가 부과됩니다`)
          .replace(/무료\s*반품/gi, `반품 배송비(${feeStr})`)
          .replace(/return\s*is\s*free/gi, `return shipping fee is ${feeStr}`)
          .replace(/free\s*return/gi, `return fee (${feeStr})`);
      }
    }

    // 4) 품절 상품에 대해 "당일 발송/재고 있음" 거짓말 환각 대조 & 어미 중첩 방어 치유
    for (const prod of matchedProducts) {
      if (prod.inStock === false) {
        const falseStockMatch = /(?:당일\s*출고|오늘\s*발송|재고가\s*있습니다|in\s*stock|ships\s*today)(?:됩니다|해\s*드립니다|예정입니다|가능합니다|\.)?/gi;
        if (falseStockMatch.test(healedDraft)) {
          violations.push('STOCK_STATUS_CONTRADICTION');
          healedDraft = healedDraft.replace(
            falseStockMatch,
            `현재 [${prod.name}] 상품은 일시 품절되어 재입고 준비 중입니다.`
          );
          // 어미 중첩 정리 (예: "중입니다됩니다" -> "중입니다.")
          healedDraft = healedDraft
            .replace(/중입니다(?:됩니다|입니다)+/g, '중입니다.')
            .replace(/\.{2,}/g, '.');
        }
      }
    }

    // 5) 사내 승인 없는 전액 배상/위자료 임의 약속 차단·치유
    if (!allowDirectRefund && UNAUTHORIZED_PROMISE_TEST_REGEX.test(healedDraft)) {
      violations.push('UNAUTHORIZED_COMPENSATION_PROMISE');
      healedDraft = healedDraft.replace(
        UNAUTHORIZED_PROMISE_REPLACE_REGEX,
        '담당 부서에서 사내 규정 및 접수 상태를 확인한 후 신속히 안내드리겠습니다'
      );
    }

    // 6) 공격적/책임전가 어조 검수·치유
    if (AGGRESSIVE_TONE_TEST_REGEX.test(healedDraft)) {
      violations.push('INAPPROPRIATE_AGGRESSIVE_TONE');
      healedDraft = healedDraft.replace(
        AGGRESSIVE_TONE_REPLACE_REGEX,
        '불편을 드려 죄송합니다. 정확한 사실관계를 확인하여 정중히 안내드리겠습니다'
      );
    }

    const autoHealed = violations.length > 0 && healedDraft !== rawDraft;
    return {
      ok: true,
      status: violations.length === 0 ? 'PASS_CLEAN_DRAFT' : 'HEALED_DRAFT_VIOLATIONS',
      passed: violations.length === 0,
      autoHealed,
      violations,
      originalDraft: rawDraft,
      healedDraft
    };
  }

  // ===========================================================================
  // [CS-Part 4] 글로벌 법적/안전 위기 브레이크 & 연속 도배 병합 (Crisis & Debounce)
  // ===========================================================================

  /**
   * 글로벌 법적/안전 고위험 민원 감지 시 자동 발송 즉시 정지 및 AI 깨진 응답 자가치유
   * @param {Object} payload { inquiryText, rawAiResponse, starRating, customerName, matchedProducts }
   */
  evaluateCrisisEscalationAndHeal(payload = {}) {
    const safe = (payload && typeof payload === 'object' && !Array.isArray(payload)) ? payload : {};
    const inquiryText = String(safe.inquiryText || safe.reviewText || '').trim();
    const rawAiResponse = safe.rawAiResponse;
    const starRating = Number.isFinite(Number(safe.starRating)) ? Number(safe.starRating) : 5;
    const customerName = String(safe.customerName || this.defaultFallbackCustomerName).trim();

    // 1) 글로벌 및 국내 고위험 법적 분쟁 / 신체 부작용 / 공공기관 신고 감지
    // 단순 문의/호의적 언급("식약처 인증 제품인가요?", "소비자원 표창") 오탐 방어
    const benignInquiryRegex = /(?:식약처|소비자원|소보원)\s*(?:인증|표창|우수|허가|기준)(?:\s*(?:받았|인가요|받은|제품인가요|\?))?/i;
    const isDispute = /(?:신고|고발|고소|민원|소송|피해|보상|손해|처벌|조사|접수|배상)/i.test(inquiryText);

    const crisisMatch = inquiryText.match(GLOBAL_CRISIS_REGEX);
    if (crisisMatch && (!benignInquiryRegex.test(inquiryText) || isDispute)) {
      return {
        ok: true,
        status: 'CRISIS_HOLD_HUMAN_REQUIRED',
        crisisDetected: true,
        matchedKeyword: crisisMatch[0],
        autoReplyBlocked: true,
        escalateToHuman: true,
        starRating,
        healedDraft: `[자동발송 보류 - 담당자 긴급 확인 필요] "${crisisMatch[0]}" 관련 글로벌/국내 고위험 민원이 감지되어 AI 자동 응답을 중단하고 전담 관리자에게 즉시 이관했습니다.`
      };
    }

    // 2) 클라우드 AI 응답 마크다운 코드블록/깨진 JSON 구출
    let extractedDraft = '';
    let aiResponseHealed = false;

    if (typeof rawAiResponse === 'string' && rawAiResponse.trim()) {
      const cleaned = rawAiResponse
        .replace(/^```(?:json|text|markdown)?\s*/i, '')
        .replace(/\s*```$/i, '')
        .trim();
      try {
        const parsed = JSON.parse(cleaned);
        extractedDraft = String(parsed.draft || parsed.reply || parsed.answer || parsed.content || cleaned);
        if (cleaned !== rawAiResponse.trim()) aiResponseHealed = true;
      } catch (_) {
        const fieldMatch = cleaned.match(/"(?:draft|reply|answer|content)"\s*:\s*"([\s\S]*?)(?:"\s*\}?\s*$|$)/i);
        if (fieldMatch && fieldMatch[1]) {
          extractedDraft = fieldMatch[1].replace(/\\"/g, '"').replace(/\\n/g, '\n');
          aiResponseHealed = true;
        } else {
          extractedDraft = cleaned;
        }
      }
    } else if (rawAiResponse && typeof rawAiResponse === 'object') {
      extractedDraft = String(rawAiResponse.draft || rawAiResponse.reply || rawAiResponse.answer || rawAiResponse.content || '');
    }

    if (!extractedDraft.trim()) {
      aiResponseHealed = true;
      extractedDraft = `안녕하세요 ${customerName}님, 남겨주신 소중한 문의를 접수하였습니다. 사내 정책에 따라 내용을 면밀히 확인한 후 빠르게 답변드리겠습니다.`;
    }

    // 추출된 초안에 대해 팩트 크로스체크 및 1:1 정합성 가드레일 적용
    const integrityResult = this.verifyCsDraftIntegrity({
      draftText: extractedDraft,
      customerName,
      matchedProducts: safe.matchedProducts,
      policyOverride: safe.policyOverride,
      policyAllowDirectRefund: Boolean(safe.policyAllowDirectRefund)
    });

    return {
      ok: true,
      status: 'HEALED_AI_DRAFT_READY',
      crisisDetected: false,
      autoReplyBlocked: false,
      escalateToHuman: starRating <= 2,
      aiResponseHealed: aiResponseHealed || integrityResult.autoHealed,
      violations: integrityResult.violations,
      healedDraft: integrityResult.healedDraft
    };
  }

  /**
   * 동일 고객 연속 문의(Burst) 1건 병합(Debounce) 및 완전 동일 중복 답변 차단
   * @param {Object} payload { customerId, inquiryId, content, timestampMs, recentHistory, burstWindowMs }
   */
  guardDuplicateAndBurstInquiry(payload = {}) {
    const safe = (payload && typeof payload === 'object' && !Array.isArray(payload)) ? payload : {};
    const customerId = String(safe.customerId || safe.customerEmail || safe.customerPhone || 'ANONYMOUS_USER').trim();
    const content = String(safe.content || '').trim();
    const nowMs = Number(safe.timestampMs) > 0 ? Number(safe.timestampMs) : Date.now();
    const windowMs = Number(safe.burstWindowMs) > 0 ? Number(safe.burstWindowMs) : this.defaultBurstWindowMs;
    const history = Array.isArray(safe.recentHistory) ? safe.recentHistory : [];

    const contentHash = crypto
      .createHash('sha256')
      .update(`${customerId}::${content.replace(/\s+/g, ' ').toLowerCase()}`)
      .digest('hex')
      .slice(0, 24);

    if (!content) {
      return {
        ok: true,
        status: 'SKIPPED_EMPTY_INQUIRY',
        allowed: false,
        duplicateBlocked: true,
        burstMerged: false,
        customerId,
        contentHash,
        mergedInquiryText: ''
      };
    }

    const recentWithinWindow = history.filter((item) => {
      if (!item || typeof item !== 'object') return false;
      const itemCust = String(item.customerId || item.customerEmail || item.customerPhone || '').trim();
      const itemTs = Number(item.timestampMs) || 0;
      return itemCust === customerId && Math.abs(nowMs - itemTs) <= windowMs;
    });

    const exactDup = recentWithinWindow.find((item) => {
      const prevContent = String(item.content || '').trim();
      return prevContent.replace(/\s+/g, ' ').toLowerCase() === content.replace(/\s+/g, ' ').toLowerCase();
    });

    if (exactDup) {
      return {
        ok: true,
        status: 'BLOCKED_EXACT_DUPLICATE_INQUIRY',
        allowed: false,
        duplicateBlocked: true,
        burstMerged: false,
        customerId,
        contentHash,
        suppressedDuplicateOfInquiryId: exactDup.inquiryId || 'PREV_INQUIRY',
        mergedInquiryText: content
      };
    }

    if (recentWithinWindow.length > 0) {
      const previousTexts = recentWithinWindow
        .map((item) => String(item.content || '').trim())
        .filter(Boolean);
      const allTexts = [...previousTexts, content];
      return {
        ok: true,
        status: 'MERGED_BURST_INQUIRY',
        allowed: true,
        duplicateBlocked: false,
        burstMerged: true,
        burstCount: allTexts.length,
        customerId,
        contentHash,
        mergedInquiryText: allTexts.map((t, idx) => `[연속문의 ${idx + 1}] ${t}`).join('\n')
      };
    }

    return {
      ok: true,
      status: 'ALLOWED_SINGLE_INQUIRY',
      allowed: true,
      duplicateBlocked: false,
      burstMerged: false,
      burstCount: 1,
      customerId,
      contentHash,
      mergedInquiryText: content
    };
  }
}

module.exports = {
  CsDomainIntegritySentinel,
  compileBusinessPolicyAndCatalog: (payload) => new CsDomainIntegritySentinel().compileBusinessPolicyAndCatalog(payload),
  retrieveGroundedFactsForInquiry: (payload) => new CsDomainIntegritySentinel().retrieveGroundedFactsForInquiry(payload),
  verifyCsDraftIntegrity: (payload) => new CsDomainIntegritySentinel().verifyCsDraftIntegrity(payload),
  evaluateCrisisEscalationAndHeal: (payload) => new CsDomainIntegritySentinel().evaluateCrisisEscalationAndHeal(payload),
  guardDuplicateAndBurstInquiry: (payload) => new CsDomainIntegritySentinel().guardDuplicateAndBurstInquiry(payload)
};
