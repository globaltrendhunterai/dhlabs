#!/usr/bin/env node
/**
 * core/recharge_cli.js
 * AutoFlow Engine License Recharge, Top-Up & HWID Binding Utility
 * Canonical SSoT Engine Supporting Multi-Channel (--channel=official|kmong|gumroad)
 *
 * Channel-Aware Features:
 * - official: Direct autoflow.io link, 20% discount & 151 slots notice (Default: ko)
 * - kmong   : 100% Kmong marketplace compliance, 1:1 message custom payment (Default: ko)
 * - gumroad : 100% MoR compliance, Gumroad Top-Up URL with HWID attached (Default: en)
 *
 * Operating Modes:
 * 1. Online Mode  : HTTP POST /api/license/extend to sidecar daemon
 * 2. Offline Mode : Direct atomic update to license_state.json
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const os = require('os');
const crypto = require('crypto');

const PORT = parseInt(process.env.AUTOFLOW_PORT || '8080', 10);
const HOST = process.env.AUTOFLOW_HOST || '127.0.0.1';
const STATE_PATH = process.env.AUTOFLOW_LICENSE_STATE_PATH || path.join(__dirname, 'license_state.json');

// 1. Channel Resolution
function resolveChannel() {
  const channelArg = process.argv.find(a => a.startsWith('--channel='));
  if (channelArg) return channelArg.split('=')[1].trim().toLowerCase();
  if (process.env.AUTOFLOW_RECHARGE_CHANNEL) return process.env.AUTOFLOW_RECHARGE_CHANNEL.trim().toLowerCase();

  // Check config directory for pre-configured channel variant in distribution packages
  const cfg1 = path.join(__dirname, '..', 'config', 'recharge_channel.json');
  const cfg2 = path.join(__dirname, 'recharge_channel.json');
  for (const cfg of [cfg1, cfg2]) {
    if (fs.existsSync(cfg)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(cfg, 'utf8'));
        if (parsed.channel) return String(parsed.channel).trim().toLowerCase();
      } catch (_) {}
    }
  }
  return 'official';
}

const CHANNEL = resolveChannel();

// 2. Language Resolution
function resolveIsEnglish(channel) {
  const langArg = process.argv.find(a => a.startsWith('--lang='));
  if (langArg) return langArg.split('=')[1].trim().toLowerCase() === 'en';
  if (process.env.AUTOFLOW_LANG) return process.env.AUTOFLOW_LANG.trim().toLowerCase() === 'en';

  if (channel === 'gumroad') return true; // Gumroad defaults to English
  const sysLang = (process.env.LANG || process.env.LC_ALL || '').toLowerCase();
  if (sysLang && !sysLang.includes('ko') && !sysLang.includes('kr')) {
    // Non-Korean environment
    return true;
  }
  return false;
}

const isEn = resolveIsEnglish(CHANNEL);

// 3. Permanent HWID Resolution
function getHwid() {
  const homeDir = os.homedir();
  const identityPath = path.join(homeDir, '.autoflow', 'machine_identity.json');
  try {
    if (fs.existsSync(identityPath)) {
      const data = JSON.parse(fs.readFileSync(identityPath, 'utf8'));
      if (data.hwid && typeof data.hwid === 'string' && data.hwid.startsWith('AF-HWID-')) {
        return data.hwid;
      }
    }
  } catch (_) {}

  try {
    if (fs.existsSync(STATE_PATH)) {
      const raw = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
      if (raw.hwid && typeof raw.hwid === 'string' && raw.hwid.startsWith('AF-HWID-')) return raw.hwid;
    }
  } catch (_) {}

  const nets = os.networkInterfaces();
  const macs = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (!net.internal && net.mac && net.mac !== '00:00:00:00:00:00') {
        macs.push(net.mac);
      }
    }
  }
  macs.sort();
  const rawSeed = `${os.hostname()}|${os.arch()}|${os.platform()}|${macs.join(',')}`;
  const hash = crypto.createHash('sha256').update(rawSeed).digest('hex').substring(0, 8).toUpperCase();
  const hwid = `AF-HWID-${hash.substring(0, 4)}-${hash.substring(4, 8)}`;
  try {
    const dir = path.dirname(identityPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(identityPath, JSON.stringify({ hwid, createdAt: new Date().toISOString() }, null, 2));
  } catch (_) {}
  return hwid;
}

const HWID = getHwid();

// 4. Texts and Messages
const T = {
  en: {
    title: '[AutoFlow Self-Healing Engine License Status]',
    statusActive: 'ACTIVE & OPERATIONAL',
    statusExpired: 'EXPIRED (Recharge Required)',
    statusModeOnline: 'Online (Daemon Running)',
    statusModeOffline: 'Offline (Local State File)',
    remainingDays: 'Remaining Period',
    days: 'days',
    hours: 'hours',
    validUntil: 'Valid Until',
    extendedTotal: 'Total Extended',
    machineHwid: 'Machine HWID',
    successTitle: '[OK] AutoFlow Engine License Recharged (Top-Up Complete)!',
    addedDays: 'Added Days',
    newExpiry: 'New Expiry Date',
    engineStatus: 'Engine Status',
    peaceOfMind: '[INFO] 127ms autonomous self-healing and 4-way reconciliation are fully active.',
    uninitialized: '[INFO] License state not initialized yet (Auto-activates 15-day free trial on first run).',
    errInvalidDays: '[ERROR] Added days must be a positive integer greater than 0.',
    usage: 'Usage: node recharge_cli.js <days> [token] [note] [--channel=official|kmong|gumroad] [--lang=en|ko]',
    bindSuccess: '[OK] Successfully bound license to this machine (HWID: %s)!'
  },
  ko: {
    title: '[AutoFlow 자가치유 엔진 라이선스 현황]',
    statusActive: '정상 가동 중 (ACTIVE)',
    statusExpired: '만료됨 (충전 필요)',
    statusModeOnline: '온라인 (데몬 실행 중)',
    statusModeOffline: '오프라인 (로컬 상태 파일)',
    remainingDays: '잔여 기간',
    days: '일',
    hours: '시간',
    validUntil: '유효 만료일',
    extendedTotal: '누적 연장 일수',
    machineHwid: '기기 고유식별자 (HWID)',
    successTitle: '[OK] AutoFlow 자가치유 엔진 기간 연장(Top-Up) 완료!',
    addedDays: '추가된 기간',
    newExpiry: '새로운 만료일',
    engineStatus: '엔진 반영 상태',
    peaceOfMind: '[INFO] 무인 127ms 자가치유 및 4각 장부정합성이 안전하게 유지됩니다.',
    uninitialized: '[INFO] 라이선스 상태 파일이 아직 생성되지 않았습니다 (엔진 최초 실행 시 15일 무료 체험 자동 활성화).',
    errInvalidDays: '[ERROR] 추가할 일수는 1 이상의 양수여야 합니다.',
    usage: '사용법: node recharge_cli.js <일수> [바우처토큰] [메모] [--channel=official|kmong|gumroad] [--lang=en|ko]',
    bindSuccess: '[OK] 라이선스가 본 기기(HWID: %s)에 성공적으로 바인딩되었습니다!'
  }
};

const STR = isEn ? T.en : T.ko;

function printStatus(lic, mode = STR.statusModeOnline) {
  if (CHANNEL === 'kmong') {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('🛡️  AutoFlow 자가치유 엔진 라이선스 현황 (크몽 공식 인증판)');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`- 가동 상태      : ${lic.status === 'ACTIVE' ? '✅ 정상 가동 중 (ACTIVE)' : '🚨 만료됨 (연장 필요)'}`);
    console.log(`- 잔여 기간      : ${lic.remaining_days} 일 (${lic.remaining_hours} 시간)`);
    console.log(`- 유효 만료일    : ${lic.valid_until}`);
    console.log(`- 누적 연장 일수 : ${lic.total_extended_days || 0} 일`);
    console.log(`- 기기 식별자    : ${HWID}`);
    console.log('────────────────────────────────────────────────────────────');
    console.log('💡 [라이선스 기간 연장 안내]');
    console.log('   크몽(Kmong) 거래 화면 내 [전문가에게 1:1 메시지]로');
    console.log(`   "라이선스 연장 요청 (기기 식별자: ${HWID})"을 남겨주시면,`);
    console.log('   크몽 안전 결제 시스템을 통해 [맞춤결제창]을 즉시 발급해 드립니다.');
    console.log('');
    console.log('   ※ AutoFlow는 크몽 플랫폼 이용약관을 100% 준수하며');
    console.log('     모든 추가 결제와 기술지원은 크몽 안전결제를 통해서만 진행됩니다.');
    console.log('   ※ 크몽 거래 후기(별점 5점 포토리뷰) 작성 시: 15일 무상 바우처 지급!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    return;
  }

  if (CHANNEL === 'gumroad') {
    console.log('============================================================');
    console.log('[AutoFlow Self-Healing Engine License Status (Global Edition)]');
    console.log('============================================================');
    console.log(`- Status         : ${lic.status === 'ACTIVE' ? 'ACTIVE & OPERATIONAL' : 'EXPIRED (Top-Up Required)'}`);
    console.log(`- Remaining Time : ${lic.remaining_days} days (${lic.remaining_hours} hours)`);
    console.log(`- Valid Until    : ${lic.valid_until}`);
    console.log(`- Total Extended : ${lic.total_extended_days || 0} days`);
    console.log(`- Machine HWID   : ${HWID}`);
    console.log('------------------------------------------------------------');
    console.log(`- Gumroad Top-Up URL: https://gumroad.com/l/autoflow-recharge?custom[hwid]=${HWID}`);
    console.log('  * Choose from 30 Days ($29), 90 Days ($79), or 180 Days ($139).');
    console.log('  * Once paid, your local engine auto-revives within 60s via background beacon.');
    console.log('============================================================');
    return;
  }

  // Official Store Edition
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`🛡️  AutoFlow 자가치유 엔진 라이선스 현황 (공식 자사몰 에디션) [${mode}]`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`- 가동 상태      : ${lic.status === 'ACTIVE' ? '✅ 정상 가동 중 (ACTIVE)' : '🚨 만료됨 (충전 필요)'}`);
  console.log(`- 잔여 기간      : ${lic.remaining_days} 일 (${lic.remaining_hours} 시간)`);
  console.log(`- 유효 만료일    : ${lic.valid_until}`);
  console.log(`- 누적 연장 일수 : ${lic.total_extended_days || 0} 일`);
  console.log(`- 기기 고유식별자: ${HWID}`);
  console.log('────────────────────────────────────────────────────────────');
  console.log(`- 자사몰 간편 충전 : https://autoflow.io/checkout.html?plan=pass_starter&hwid=${HWID}`);
  console.log('  └ 💡 [추천] 자사몰(autoflow.io) 정기구독 시 20% 추가할인 + 151종 무제한 슬롯 교체!');
  console.log('  └ ⚡ 결제 완료 시 60초 내 중앙 비콘이 엔진을 자동으로 원격 소생시킵니다.');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
}

function checkStatus(cb) {
  let settled = false;
  const req = http.get(`http://${HOST}:${PORT}/api/license/status`, { timeout: 1500 }, (res) => {
    let raw = '';
    res.on('data', chunk => { raw += chunk; });
    res.on('end', () => {
      if (settled) return;
      settled = true;
      try {
        const json = JSON.parse(raw);
        printStatus(json, STR.statusModeOnline);
        if (cb) cb(null, json);
      } catch (_) {
        fallbackFileStatus(cb);
      }
    });
  });

  req.on('timeout', () => {
    if (settled) return;
    settled = true;
    req.destroy();
    fallbackFileStatus(cb);
  });

  req.on('error', () => {
    if (settled) return;
    settled = true;
    fallbackFileStatus(cb);
  });
}

function fallbackFileStatus(cb) {
  if (fs.existsSync(STATE_PATH)) {
    try {
      const state = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
      const now = Date.now();
      const expiryMs = state.valid_until ? new Date(state.valid_until).getTime() : now;
      const remainingMs = expiryMs - now;
      const isExpired = remainingMs <= 0;
      const remainingDays = isExpired ? 0 : Math.max(0, Math.ceil(remainingMs / (1000 * 60 * 60 * 24)));
      const remainingHours = isExpired ? 0 : Math.max(0, Math.floor(remainingMs / (1000 * 60 * 60)));

      const summary = {
        status: isExpired ? 'EXPIRED' : 'ACTIVE',
        is_expired: isExpired,
        valid_until: state.valid_until,
        remaining_days: remainingDays,
        remaining_hours: remainingHours,
        total_extended_days: state.total_extended_days || 0
      };
      printStatus(summary, STR.statusModeOffline);
      if (cb) cb(null, summary);
    } catch (err) {
      console.error(`[ERROR] ${err.message}`);
      if (cb) cb(err);
    }
  } else {
    console.log(STR.uninitialized);
    if (cb) cb(null, null);
  }
}

function performRecharge(addDays, token, note, cb) {
  const extendSecret = process.env.AUTOFLOW_LICENSE_EXTEND_SECRET || 'AF-ENTERPRISE-LICENSE-EXTEND-HMAC-SECRET-2026';
  const signature = crypto
    .createHmac('sha256', extendSecret)
    .update(`${Number(addDays)}:${String(token || '')}`)
    .digest('hex');
  const payload = JSON.stringify({ add_days: addDays, token, note, hwid: HWID, signature });

  const req = http.request(`http://${HOST}:${PORT}/api/license/extend`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    },
    timeout: 3000
  }, (res) => {
    let body = '';
    res.on('data', chunk => body += chunk);
    res.on('end', () => {
      if (res.statusCode === 200) {
        try {
          const data = JSON.parse(body);
          if (data && data.valid_until) {
            printSuccess(addDays, data.valid_until, data.remaining_days || addDays, STR.statusModeOnline);
            if (cb) cb(null, data);
            return;
          }
        } catch (_) {}
      }
      offlineRecharge(addDays, token, note, cb);
    });
  });

  req.on('error', () => {
    console.log(isEn ? '[INFO] Daemon inactive -> Switching to local offline state update...' : 'ℹ️ 데몬 미구동 상태 ➔ 로컬 상태 파일 직접 갱신 모드로 전환...');
    offlineRecharge(addDays, token, note, cb);
  });

  req.on('timeout', () => {
    req.destroy();
    offlineRecharge(addDays, token, note, cb);
  });

  req.write(payload);
  req.end();
}

function offlineRecharge(addDays, token, note, cb) {
  try {
    let state = {
      license_key: 'AF-ENTERPRISE-LOCAL',
      tier: 'ENTERPRISE_SELF_HEALING',
      status: 'ACTIVE',
      activated_at: new Date().toISOString(),
      valid_until: new Date(Date.now() + 30 * 86400000).toISOString(),
      total_extended_days: 0,
      extension_history: []
    };

    if (fs.existsSync(STATE_PATH)) {
      try {
        state = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
      } catch (_) {}
    }

    const now = Date.now();
    let currentExpiry = state.valid_until ? new Date(state.valid_until).getTime() : now;
    if (isNaN(currentExpiry) || currentExpiry < now) {
      currentExpiry = now;
    }

    const newExpiryMs = currentExpiry + (addDays * 24 * 60 * 60 * 1000);
    const newExpiryDate = new Date(newExpiryMs).toISOString();

    state.valid_until = newExpiryDate;
    state.status = 'ACTIVE';
    state.hwid = HWID;
    state.total_extended_days = (state.total_extended_days || 0) + addDays;
    if (!Array.isArray(state.extension_history)) state.extension_history = [];
    state.extension_history.push({
      add_days: addDays,
      extended_at: new Date().toISOString(),
      token: token || 'OFFLINE_RECHARGE',
      note: note || 'Local Offline Recharge'
    });

    const { saveLicenseState } = require('./license_manager');
    saveLicenseState(state, STATE_PATH);

    const remainingDays = Math.ceil((newExpiryMs - now) / (1000 * 60 * 60 * 24));
    printSuccess(addDays, newExpiryDate, remainingDays, STR.statusModeOffline);
    if (cb) cb(null, { valid_until: newExpiryDate, remaining_days: remainingDays, state });
  } catch (err) {
    console.error(`[ERROR] [Recharge Failed]: ${err.message}`);
    if (cb) cb(err);
    else process.exit(1);
  }
}

function printSuccess(added, expiry, remaining, mode) {
  const currentStr = resolveIsEnglish(resolveChannel()) ? T.en : T.ko;
  console.log('\n============================================================');
  console.log(currentStr.successTitle);
  console.log('============================================================');
  console.log(`- ${currentStr.addedDays}    : +${added} ${currentStr.days}`);
  console.log(`- ${currentStr.newExpiry}  : ${expiry.split('T')[0]} (${remaining} ${currentStr.days})`);
  console.log(`- ${currentStr.engineStatus} : ${mode}`);
  console.log(`- ${currentStr.machineHwid}     : ${HWID}`);
  console.log(currentStr.peaceOfMind);
  console.log('============================================================\n');
}

function performSync() {
  console.log(`[Sync] Checking license status for HWID: ${HWID}...`);
  const globalPath = path.join(os.homedir(), '.autoflow', 'machine_identity.json');
  let globalData = {};
  if (fs.existsSync(globalPath)) {
    try { globalData = JSON.parse(fs.readFileSync(globalPath, 'utf8')); } catch (_) {}
  }

  if (globalData.valid_until) {
    const now = Date.now();
    const expiryMs = new Date(globalData.valid_until).getTime();
    if (expiryMs > now) {
      applyDirectSync(globalData.valid_until, Math.ceil((expiryMs - now)/(1000*60*60*24)), 'OS Global Anchor (~/.autoflow)');
      return;
    }
  }
  checkStatus();
}

function applyDirectSync(validUntil, remainingDays, source) {
  try {
    let state = {};
    if (fs.existsSync(STATE_PATH)) {
      state = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
    }
    state.hwid = HWID;
    state.valid_until = validUntil;
    const { saveLicenseState } = require('./license_manager');
    saveLicenseState(state, STATE_PATH);
    console.log(`[OK] [Sync Success] Restored license from ${source}!`);
    console.log(`   Valid until: ${validUntil} (${remainingDays} days remaining)\n`);
  } catch (_) {}
}

function performBind(token) {
  console.log(`[Bind] Contacting license registry with HWID: ${HWID}, Token: ${token}...`);
  offlineRecharge(30, token, 'License Bound via Token', () => {
    console.log(STR.bindSuccess.replace('%s', HWID));
  });
}

function runCli() {
  const rawArgs = process.argv.slice(2).filter(a => !a.startsWith('--lang=') && !a.startsWith('--channel=') && !a.startsWith('--modules='));
  let command = rawArgs[0] || 'status';
  let flagDays = null;
  for (const arg of rawArgs) {
    if (arg.startsWith('--days=')) {
      flagDays = arg.split('=')[1];
    } else if (arg === '-d' && rawArgs.indexOf(arg) + 1 < rawArgs.length) {
      flagDays = rawArgs[rawArgs.indexOf(arg) + 1];
    }
  }
  if (flagDays) {
    command = flagDays;
  }

  if (command === 'status' || command === '--status' || command === '-s') {
    checkStatus();
  } else if (command === 'sync' || command === '--sync') {
    performSync();
  } else if (command === 'bind') {
    const token = rawArgs[1] || 'DEMO_BIND_TOKEN';
    performBind(token);
  } else {
    const addDays = parseInt(command, 10);
    const token = rawArgs[1] || `CLI_RECHARGE_${Date.now()}`;
    const note = rawArgs[2] || (isEn ? `${addDays}-day top-up` : `${addDays}일 기간 충전`);

    if (isNaN(addDays) || addDays <= 0) {
      console.error(STR.errInvalidDays);
      console.log(STR.usage);
      process.exit(1);
    }
    performRecharge(addDays, token, note);
  }
}

const mainBase = (require.main && require.main.filename) ? path.basename(require.main.filename) : '';
const isDirectRun = require.main === module || [
  'recharge_cli.js',
  'recharge_cli_official.js',
  'recharge_cli_kmong.js',
  'recharge_cli_gumroad.js'
].includes(mainBase);

if (isDirectRun) {
  runCli();
}

module.exports = {
  get CHANNEL() { return resolveChannel(); },
  get isEn() { return resolveIsEnglish(resolveChannel()); },
  get STR() { return resolveIsEnglish(resolveChannel()) ? T.en : T.ko; },
  resolveChannel,
  resolveIsEnglish,
  HWID,
  getHwid,
  checkStatus,
  performRecharge,
  offlineRecharge,
  performSync,
  performBind,
  runCli
};
