#!/usr/bin/env node
/**
 * core/recharge_cli.js
 * AutoFlow Engine License Recharge, Top-Up & HWID Binding Utility
 * Dual Language Support: English / Korean
 * 
 * Works in two modes seamlessly:
 * 1. Online Mode (Daemon running): Sends HTTP POST to http://127.0.0.1:8080/api/license/extend
 * 2. Offline Mode (Daemon stopped): Directly reads and updates license_state.json atomically
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const os = require('os');
const crypto = require('crypto');

const PORT = parseInt(process.env.AUTOFLOW_PORT || '8080', 10);
const HOST = process.env.AUTOFLOW_HOST || '127.0.0.1';
const STATE_PATH = process.env.AUTOFLOW_LICENSE_STATE_PATH || path.join(__dirname, 'license_state.json');

// Language detection
const sysLang = (process.env.LANG || process.env.LC_ALL || '').toLowerCase();
const isEn = process.argv.includes('--lang=en') || (!sysLang.includes('ko') && !sysLang.includes('kr'));

const T = {
  en: {
    title: '[AutoFlow Self-Healing Engine License Status]',
    statusActive: 'ACTIVE & OPERATIONAL',
    statusExpired: 'EXPIRED (Recharge Required)',
    statusModeOnline: 'Online (Daemon Running)',
    statusModeOffline: 'Offline (Local State File)',
    remainingDays: 'Remaining Period',
    days: 'days',
    hours: 'hours',
    validUntil: 'Valid Until',
    extendedTotal: 'Total Extended',
    machineHwid: 'Machine HWID',
    rechargeUrl: 'Top-Up URL',
    successTitle: '[OK] AutoFlow Engine License Recharged (Top-Up Complete)!',
    addedDays: 'Added Days',
    newExpiry: 'New Expiry Date',
    engineStatus: 'Engine Status',
    peaceOfMind: '[INFO] 127ms autonomous self-healing and 4-way reconciliation are fully active.',
    uninitialized: '[INFO] License state not initialized yet (Auto-activates 15-day free trial on first run).',
    errInvalidDays: '[ERROR] Added days must be a positive integer greater than 0.',
    usage: 'Usage: node recharge_cli.js <days> [token] [note] [--lang=en|ko]',
    bindSuccess: '[OK] Successfully bound license to this machine (HWID: %s)!'
  },
  ko: {
    title: '[AutoFlow 자가치유 엔진 라이선스 현황]',
    statusActive: '정상 가동 중 (ACTIVE)',
    statusExpired: '만료됨 (충전 필요)',
    statusModeOnline: '온라인 (데몬 실행 중)',
    statusModeOffline: '오프라인 (로컬 상태 파일)',
    remainingDays: '잔여 기간',
    days: '일',
    hours: '시간',
    validUntil: '유효 만료일',
    extendedTotal: '누적 연장 일수',
    machineHwid: '기기 고유식별자 (HWID)',
    rechargeUrl: '간편 충전 링크',
    successTitle: '[OK] AutoFlow 자가치유 엔진 기간 연장(Top-Up) 완료!',
    addedDays: '추가된 기간',
    newExpiry: '새로운 만료일',
    engineStatus: '엔진 반영 상태',
    peaceOfMind: '[INFO] 무인 127ms 자가치유 및 4각 장부정합성이 안전하게 유지됩니다.',
    uninitialized: '[INFO] 라이선스 상태 파일이 아직 생성되지 않았습니다 (엔진 최초 실행 시 15일 무료 체험 자동 활성화).',
    errInvalidDays: '[ERROR] 추가할 일수는 1 이상의 양수여야 합니다.',
    usage: '사용법: node recharge_cli.js <일수> [바우처토큰] [메모] [--lang=en|ko]',
    bindSuccess: '[OK] 라이선스가 본 기기(HWID: %s)에 성공적으로 바인딩되었습니다!'
  }
};

const STR = isEn ? T.en : T.ko;

function getHwid() {
  try {
    if (fs.existsSync(STATE_PATH)) {
      const raw = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
      if (raw.hwid) return raw.hwid;
    }
  } catch (e) {}

  const nets = os.networkInterfaces();
  const macs = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (!net.internal && net.mac && net.mac !== '00:00:00:00:00:00') {
        macs.push(net.mac);
      }
    }
  }
  macs.sort();
  const seed = [os.hostname(), os.platform(), os.arch(), macs.join(':')].join('|');
  const hash = crypto.createHash('sha256').update(seed).digest('hex').substring(0, 16).toUpperCase();
  return `AF-HWID-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`;
}

const HWID = getHwid();

const modulesArg = process.argv.find(a => a.startsWith('--modules='));
const requestedModules = modulesArg
  ? modulesArg.split('=')[1].split(',').map(m => m.trim().toUpperCase()).filter(Boolean)
  : [];

// Parse CLI Arguments
const rawArgs = process.argv.slice(2).filter(a => !a.startsWith('--lang=') && !a.startsWith('--modules='));

// 지원: node recharge_cli.js 30, node recharge_cli.js --days=30, node recharge_cli.js -d 30
let command = rawArgs[0] || '30';
let flagDays = null;
for (const arg of rawArgs) {
  if (arg.startsWith('--days=')) {
    flagDays = arg.split('=')[1];
  } else if (arg === '-d' && rawArgs.indexOf(arg) + 1 < rawArgs.length) {
    flagDays = rawArgs[rawArgs.indexOf(arg) + 1];
  }
}
if (flagDays) {
  command = flagDays;
}

if (command === 'status' || command === '--status' || command === '-s') {
  checkStatus();
} else if (command === 'sync' || command === '--sync') {
  performSync();
} else if (command === 'bind') {
  const token = rawArgs[1] || 'DEMO_BIND_TOKEN';
  performBind(token);
} else {
  const addDays = parseInt(command, 10);
  const token = rawArgs[1] || `CLI_RECHARGE_${Date.now()}`;
  const note = rawArgs[2] || (isEn ? `${addDays}-day top-up` : `${addDays}일 기간 충전`);
  
  if (isNaN(addDays) || addDays <= 0) {
    console.error(STR.errInvalidDays);
    console.log(STR.usage);
    process.exit(1);
  }

  performRecharge(addDays, token, note);
}


function checkStatus() {
  const req = http.get(`http://${HOST}:${PORT}/api/license/status`, (res) => {
    let raw = '';
    res.on('data', chunk => { raw += chunk; });
    res.on('end', () => {
      try {
        const json = JSON.parse(raw);
        printStatus(json, STR.statusModeOnline);
      } catch (e) {
        fallbackFileStatus();
      }
    });
  });

  req.on('error', () => {
    fallbackFileStatus();
  });
}

function fallbackFileStatus() {
  if (fs.existsSync(STATE_PATH)) {
    try {
      const state = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
      const now = Date.now();
      const expiryMs = state.valid_until ? new Date(state.valid_until).getTime() : now;
      const remainingMs = expiryMs - now;
      const isExpired = remainingMs <= 0;
      const remainingDays = isExpired ? 0 : Math.max(0, Math.ceil(remainingMs / (1000 * 60 * 60 * 24)));
      const remainingHours = isExpired ? 0 : Math.max(0, Math.floor(remainingMs / (1000 * 60 * 60)));

      printStatus({
        status: isExpired ? 'EXPIRED' : 'ACTIVE',
        is_expired: isExpired,
        valid_until: state.valid_until,
        remaining_days: remainingDays,
        remaining_hours: remainingHours,
        total_extended_days: state.total_extended_days || 0
      }, STR.statusModeOffline);
    } catch (err) {
      console.error(`[ERROR] ${err.message}`);
    }
  } else {
    console.log(STR.uninitialized);
  }
}

function printStatus(lic, mode) {
  console.log('============================================================');
  console.log(`${STR.title} [${mode}]`);
  console.log('============================================================');
  console.log(`- Status         : ${lic.status === 'ACTIVE' ? STR.statusActive : STR.statusExpired}`);
  console.log(`- ${STR.remainingDays} : ${lic.remaining_days} ${STR.days} (${lic.remaining_hours} ${STR.hours})`);
  console.log(`- ${STR.validUntil}    : ${lic.valid_until}`);
  console.log(`- ${STR.extendedTotal} : ${lic.total_extended_days || 0} ${STR.days}`);
  console.log(`- ${STR.machineHwid}     : ${HWID}`);
  console.log('------------------------------------------------------------');
  console.log(`- [Modular Pick] Module A-1 (BYOK 30d ₩29,000)      : https://autoflow.io/checkout.html?modules=MODULE_A1_BYOK&period=d30&hwid=${HWID}`);
  console.log(`- [Modular Pick] Module A-2 (Managed AI 30d ₩49,000): https://autoflow.io/checkout.html?modules=MODULE_A2_MANAGED_AI&period=d30&hwid=${HWID}`);
  console.log(`- [Modular Pick] Module B (Branch Recon 30d ₩29,000): https://autoflow.io/checkout.html?modules=MODULE_B_BRANCH_RECON&period=d30&hwid=${HWID}`);
  console.log(`- [Full Combo]   Module A-2 + B (30d ₩78,000)       : https://autoflow.io/checkout.html?modules=MODULE_A2_MANAGED_AI,MODULE_B_BRANCH_RECON&period=d30&hwid=${HWID}`);
  console.log(isEn
    ? `  * [Guaranteed] Purchased workflow (WF_ENTRY/WF_STANDARD/WF_COMPLEX) runs 24/7 forever even after module expiry.`
    : `  * [영구 가동 보장] 구매하신 워크플로우 단품은 모듈 만료 후에도 멈추지 않고 평생 무료로 24시간 가동됩니다.`);
  console.log('============================================================');
}

function performRecharge(addDays, token, note) {
  const extendSecret = process.env.AUTOFLOW_LICENSE_EXTEND_SECRET || 'AF-ENTERPRISE-LICENSE-EXTEND-HMAC-SECRET-2026';
  const signature = crypto
    .createHmac('sha256', extendSecret)
    .update(`${Number(addDays)}:${String(token || '')}`)
    .digest('hex');
  const payload = JSON.stringify({ add_days: addDays, token, note, hwid: HWID, signature, modules: requestedModules });
  const req = http.request(`http://${HOST}:${PORT}/api/license/extend`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    }
  }, (res) => {
    let raw = '';
    res.on('data', chunk => { raw += chunk; });
    res.on('end', () => {
      try {
        const json = JSON.parse(raw);
        if (res.statusCode === 200 && json.success) {
          printSuccess(addDays, json.valid_until, json.remaining_days, isEn ? 'Daemon Live (Online)' : '데몬 즉시 반영 (Online)');
        } else {
          performDirectFileRecharge(addDays, token, note);
        }
      } catch (e) {
        performDirectFileRecharge(addDays, token, note);
      }
    });
  });

  req.on('error', () => {
    performDirectFileRecharge(addDays, token, note);
  });

  req.write(payload);
  req.end();
}

function performDirectFileRecharge(addDays, token, note) {
  try {
    let state = {};
    if (fs.existsSync(STATE_PATH)) {
      state = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
    }
    state.hwid = HWID;
    state.workflow_perpetual_owned = state.workflow_perpetual_owned !== false;
    if (requestedModules.length > 0) {
      state.selected_modules = requestedModules;
      const hasA2 = requestedModules.some(m => m.includes('A2') || m.includes('MANAGED'));
      const hasA1 = !hasA2 && requestedModules.some(m => m.includes('A1') || m.includes('BYOK'));
      const hasB = requestedModules.some(m => m.includes('MODULE_B') || m.includes('RECON'));
      state.enabled_modules = {
        self_healing: Boolean(hasA1 || hasA2),
        ai_mode: hasA2 ? 'MANAGED' : (hasA1 ? 'BYOK' : 'NONE'),
        branch_reconciliation: Boolean(hasB)
      };
    }
    const now = Date.now();
    const currentExpiryMs = state.valid_until ? new Date(state.valid_until).getTime() : now;
    const baseMs = currentExpiryMs > now ? currentExpiryMs : now;
    const newExpiryMs = baseMs + addDays * 24 * 60 * 60 * 1000;
    const newExpiryDate = new Date(newExpiryMs).toISOString();

    state.valid_until = newExpiryDate;
    state.total_extended_days = (state.total_extended_days || 0) + addDays;
    state.extension_history = state.extension_history || [];
    state.extension_history.push({
      add_days: addDays,
      extended_at: new Date().toISOString(),
      token: token,
      note: note,
      selected_modules: requestedModules.length > 0 ? requestedModules : undefined,
      new_expiry: newExpiryDate
    });

    const tmpPath = `${STATE_PATH}.tmp.${Date.now()}`;
    fs.writeFileSync(tmpPath, JSON.stringify(state, null, 2), 'utf8');
    fs.renameSync(tmpPath, STATE_PATH);

    const remainingDays = Math.ceil((newExpiryMs - now) / (1000 * 60 * 60 * 24));
    printSuccess(addDays, newExpiryDate, remainingDays, isEn ? 'Direct Local File Update (Offline)' : '로컬 상태 파일 직접 갱신 (Offline)');
  } catch (err) {
    console.error(`[ERROR] [Recharge Failed]: ${err.message}`);
    process.exit(1);
  }
}

function performSync() {
  console.log(`[Sync] Checking license status for HWID: ${HWID}...`);
  const globalPath = path.join(os.homedir(), '.autoflow', 'machine_identity.json');
  let globalData = {};
  if (fs.existsSync(globalPath)) {
    try { globalData = JSON.parse(fs.readFileSync(globalPath, 'utf8')); } catch (e) {}
  }

  if (globalData.valid_until) {
    const now = Date.now();
    const expiryMs = new Date(globalData.valid_until).getTime();
    if (expiryMs > now) {
      applyDirectSync(globalData.valid_until, Math.ceil((expiryMs - now)/(1000*60*60*24)), 'OS Global Anchor (~/.autoflow)');
      return;
    }
  }

  // Fallback to checking local state
  checkStatus();
}

function applyDirectSync(validUntil, remainingDays, source) {
  try {
    let state = {};
    if (fs.existsSync(STATE_PATH)) {
      state = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
    }
    state.hwid = HWID;
    state.valid_until = validUntil;
    fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2), 'utf8');
    console.log(`[OK] [Sync Success] Restored license from ${source}!`);
    console.log(`   Valid until: ${validUntil} (${remainingDays} days remaining)\n`);
  } catch (e) {}
}

function performBind(token) {
  console.log(`[Bind] Contacting license registry with HWID: ${HWID}, Token: ${token}...`);
  performDirectFileRecharge(30, token, 'License Bound via Token');
  console.log(STR.bindSuccess.replace('%s', HWID));
}

function printSuccess(added, expiry, remaining, mode) {
  console.log('\n============================================================');
  console.log(STR.successTitle);
  console.log('============================================================');
  console.log(`- ${STR.addedDays}    : +${added} ${STR.days}`);
  console.log(`- ${STR.newExpiry}  : ${expiry.split('T')[0]} (${remaining} ${STR.days})`);
  console.log(`- ${STR.engineStatus} : ${mode}`);
  console.log(`- ${STR.machineHwid}     : ${HWID}`);
  console.log(STR.peaceOfMind);
  console.log('============================================================\n');
}
