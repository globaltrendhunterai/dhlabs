/**
 * core/license_manager.js
 * AutoFlow Enterprise 1:1 Device HWID License & Fair Prorated Refund Engine
 * 
 * Statutory Compliance:
 * - 공정거래위원회 표준약관 및 전자상거래 등에서의 소비자보호에 관한 법률 준수
 * - 정상 공정 환불 규정:
 *   1) 결제 후 7일 이내 & 미활성화: 100% 무조건 전액 환불 (FULL_REFUND_UNACTIVATED)
 *   2) 활성화 후 7일 이내 (엔진 결함/호환성 불가): 100% 전액 환불 (FULL_REFUND_DEFECT)
 *   3) 7일 경과 후 중도 해지: 접수일 기준 실사용 일수 일할 차감 + 10% 위약수수료 공제 잔여액 정산 (PRORATED_REFUND_AFTER_7_DAYS)
 *   4) HWID 및 기기 고유정보(CPU, MAC, 활성화 타임스탬프) 대조 검증 후 관리자 승인 시 원격 회수(REVOKED)
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const OFFICIAL_UPGRADE_PORTAL = 'https://autoflow.io/upgrade';
const LICENSE_STATE_PATH = process.env.AUTOFLOW_LICENSE_STATE_PATH || path.join(__dirname, 'license_state.json');
const OFFLINE_GRACE_PERIOD_MS = 72 * 3600 * 1000; // 최대 72시간 오프라인 유예 허용 (환불 후 오프라인 먹튀 원천 방어)

const MODULE_TICKET_HMAC_SECRET = process.env.AUTOFLOW_MODULE_TICKET_SECRET || 'AF-ENTERPRISE-MODULAR-TICKET-HMAC-2026';

/**
 * 개별 공식 노드(56종) 4등급 투명 정찰 단가 SSOT (방어 모듈 분리 이후 순수 노드 단가)
 */
const INDIVIDUAL_NODE_PRICING_SSOT = {
  FLOW_CORE: {
    grade: 'N1',
    gradeKey: 'N1_FLOW_CORE',
    labelKo: '분기·흐름 제어 기본 노드',
    unitPriceKrw: 1500,
    categories: ['BRANCH_FLOW_CONTROL']
  },
  SAAS_COLLAB: {
    grade: 'N2',
    gradeKey: 'N2_SAAS_COLLAB',
    labelKo: '메신저·시트·스토리지 일반 연동 노드',
    unitPriceKrw: 2500,
    categories: ['MESSENGER_NOTIFICATION', 'FILE_STORAGE_CLOUD']
  },
  COMMERCE_DB_CRM: {
    grade: 'N3',
    gradeKey: 'N3_COMMERCE_DB_CRM',
    labelKo: '이커머스·PG결제·DB·CRM 실무 트랜잭션 노드',
    unitPriceKrw: 3500,
    categories: ['ECOMMERCE_PAYMENT', 'DB_LEDGER_SHEET', 'CRM_SAAS_ERP']
  },
  AI_CUSTOM_API: {
    grade: 'N4',
    gradeKey: 'N4_AI_CUSTOM_API',
    labelKo: 'AI/LLM 에이전트 & 고난도 외부 API 노드',
    unitPriceKrw: 5000,
    categories: ['AI_LLM_AGENT', 'EXTERNAL_API_WEBHOOK']
  }
};

/**
 * 시간대별(경과일별) 워크플로우·개별노드 가격 4단계 점진적 인하 스케줄 (Time-Phased Step-Down Pricing)
 * - 외주/크몽 등 시장 가격이 아직 높을 때 처음부터 초저가로 풀면 리셀러가 헐값 매입 후 노드를 되파는 차익거래(Arbitrage)가 발생하므로,
 *   출시 초기 고단가 방어기(Phase 1)에서 시작해 시장 침투율에 따라 Phase 2 -> Phase 3 -> Phase 4(최종 대중화 최저가)로 단계적 인하
 * - 로컬 대시보드(setup_wizard.html)에는 판매 금액을 일체 표기하지 않고(dashboardPriceDisplayAllowed: false),
 *   본사 결제 서버(HQ_CHECKOUT_SERVER_ONLY)에서만 실시간 단계 가격을 안내하여 금액 차이 클레임을 원천 차단함
 */
const WORKFLOW_TIME_PHASED_PRICING_SCHEDULE = {
  PHASE_1_INITIAL: {
    phaseId: 'PHASE_1_INITIAL',
    phaseNameKo: '초기 리셀러 차익거래 방어 고단가기 (0~29일)',
    minDays: 0,
    maxDays: 29,
    workflowPrices: { WF_ENTRY: 99000, WF_STANDARD: 189000, WF_COMPLEX: 290000 },
    nodePriceMultiplier: 10,
    gradeUnitPrices: {
      N1_FLOW_CORE: 15000,
      N2_SAAS_COLLAB: 25000,
      N3_COMMERCE_DB_CRM: 35000,
      N4_AI_CUSTOM_API: 50000
    }
  },
  PHASE_2_EXPANSION: {
    phaseId: 'PHASE_2_EXPANSION',
    phaseNameKo: '시장 확산 1차 인하기 (30~89일)',
    minDays: 30,
    maxDays: 89,
    workflowPrices: { WF_ENTRY: 49000, WF_STANDARD: 99000, WF_COMPLEX: 149000 },
    nodePriceMultiplier: 5,
    gradeUnitPrices: {
      N1_FLOW_CORE: 7500,
      N2_SAAS_COLLAB: 12500,
      N3_COMMERCE_DB_CRM: 17500,
      N4_AI_CUSTOM_API: 25000
    }
  },
  PHASE_3_MATURE: {
    phaseId: 'PHASE_3_MATURE',
    phaseNameKo: '시장 성숙 2차 인하기 (90~179일)',
    minDays: 90,
    maxDays: 179,
    workflowPrices: { WF_ENTRY: 29000, WF_STANDARD: 49000, WF_COMPLEX: 79000 },
    nodePriceMultiplier: 2,
    gradeUnitPrices: {
      N1_FLOW_CORE: 3000,
      N2_SAAS_COLLAB: 5000,
      N3_COMMERCE_DB_CRM: 7000,
      N4_AI_CUSTOM_API: 10000
    }
  },
  PHASE_4_FINAL_FLOOR: {
    phaseId: 'PHASE_4_FINAL_FLOOR',
    phaseNameKo: '대중화 최종 최저가 안착기 (180일 이상)',
    minDays: 180,
    maxDays: Infinity,
    workflowPrices: { WF_ENTRY: 9900, WF_STANDARD: 19000, WF_COMPLEX: 29000 },
    nodePriceMultiplier: 1,
    gradeUnitPrices: {
      N1_FLOW_CORE: 1500,
      N2_SAAS_COLLAB: 2500,
      N3_COMMERCE_DB_CRM: 3500,
      N4_AI_CUSTOM_API: 5000
    }
  }
};

/**
 * 상황별 6대 전문 엔진 개별 분리 판매 SKU & 스마트 원장(SmartGrid) SKU 맵
 */
const ENGINE_PACK_SKU_MAP = Object.freeze({
  'AF-ENG-CORE': Object.freeze({ sku: 'AF-ENG-CORE', bitmask: 521, packId: 'PACK_CORE_BASE', titleKo: '기본 무중단 베이스 차체' }),
  'AF-ENG-COMMERCE': Object.freeze({ sku: 'AF-ENG-COMMERCE', bitmask: 71744, packId: 'PACK_COMMERCE_LOGISTICS', titleKo: '커머스·물류·합배송·출고보류 엔진 팩' }),
  'AF-ENG-FINANCE': Object.freeze({ sku: 'AF-ENG-FINANCE', bitmask: 132100, packId: 'PACK_FINANCE_TAX_ERP', titleKo: '재무·정산대사·국세청 홈택스·압류방어 엔진 팩' }),
  'AF-ENG-CS': Object.freeze({ sku: 'AF-ENG-CS', bitmask: 57376, packId: 'PACK_CS_DISPUTE_PRIVACY', titleKo: '옴니채널 CS·개인정보 마스킹·악성리뷰/분쟁/지재권 방어 엔진 팩' }),
  'AF-ENG-MARKETING': Object.freeze({ sku: 'AF-ENG-MARKETING', bitmask: 272, packId: 'PACK_MARKETING_CRM_PIPELINE', titleKo: '마케팅·SNS 멀티배포·CRM 영업 파이프라인·스키마 드리프트 방어 엔진 팩' }),
  'AF-ENG-GLOBAL': Object.freeze({ sku: 'AF-ENG-GLOBAL', bitmask: 2176, packId: 'PACK_GLOBAL_CUSTOMS_FX', titleKo: '글로벌 역직구·관세청 통관부호(PCCC)·다통화 환율 엔진 팩' }),
  'AF-ENG-ALL': Object.freeze({ sku: 'AF-ENG-ALL', bitmask: 262141, packId: 'ALL', titleKo: '6대 전문 엔진 올인원 마스터 패스' }),
  'AF-SMARTGRID-PRO': Object.freeze({ sku: 'AF-SMARTGRID-PRO', bitmask: 521, packId: 'SMARTGRID', titleKo: 'AutoFlow SmartGrid 프로 스마트 원장 프로그램', isAddon: true })
});

/**
 * 국내·해외 공식 판매 루트 및 2단계 자사몰 오픈 게이트 SSOT
 * - Stage 1 (초기): 외부 마켓(스마트스토어·블로그 / Lemon Squeezy·Whop·Gumroad·AppSumo)에서 구매한 라이선스·모듈 티켓을 프로그램에 1초 등록
 * - Stage 2 (목표 매출 달성 후): 공식 자사몰 정식 오픈 공지 및 자체 다이렉트 결제 시스템 개방
 */
const SALES_CHANNEL_AND_STORE_GATE_SSOT = {
  domesticChannels: {
    NAVER_SMARTSTORE: {
      id: 'NAVER_SMARTSTORE',
      nameKo: '네이버 스마트스토어 공식 스토어',
      role: '국내 워크플로우 단품 및 모듈 티켓 결제 (네이버페이·할부·지출증빙 자동 지원)',
      url: 'https://smartstore.naver.com/autoflow'
    },
    NAVER_BLOG: {
      id: 'NAVER_BLOG',
      nameKo: '네이버 공식 기술·도입 사례 블로그',
      role: '셀러 자동화 문제해결 가이드 및 스마트스토어 구매 연동',
      url: 'https://blog.naver.com/autoflow_official'
    }
  },
  globalChannels: {
    LEMON_SQUEEZY: {
      id: 'LEMON_SQUEEZY',
      nameEn: 'Lemon Squeezy (Stripe MoR)',
      feeSpec: '5% + $0.50',
      role: '글로벌 1순위 — 전 세계 부가세(VAT) 자동 대납 + 내장 라이선스 키/티켓 발급 API',
      url: 'https://autoflow.lemonsqueezy.com'
    },
    WHOP: {
      id: 'WHOP',
      nameEn: 'Whop Automation & AI Hub',
      feeSpec: '2.7% + $0.30',
      role: '글로벌 2순위 — 영미권 AI·자동화·n8n 워크플로우 패스 거래 1위 마켓플레이스',
      url: 'https://whop.com/autoflow'
    },
    GUMROAD: {
      id: 'GUMROAD',
      nameEn: 'Gumroad Global Store',
      feeSpec: '10% + $0.50',
      role: '글로벌 3순위 — 기존 해외 단품 다운로드 및 크리에이터 디스커버리',
      url: 'https://gumroad.com/l/autoflow'
    },
    APPSUMO: {
      id: 'APPSUMO',
      nameEn: 'AppSumo Marketplace',
      feeSpec: 'Revenue Share',
      role: '글로벌 4순위 — 초기 글로벌 시드 고객 대량 유입 및 자사몰 오픈용 시드 매출 확보',
      url: 'https://appsumo.com/products/autoflow'
    }
  },
  storefrontGateStages: {
    STAGE_1_EXTERNAL_MARKET_TICKET_ONLY: {
      stageId: 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
      directCheckoutEnabled: false,
      descriptionKo: '외부 마켓(스마트스토어/Lemon Squeezy/Whop/Gumroad)에서 라이선스 및 모듈 티켓을 구매하여 프로그램에 1초 등록하는 단계'
    },
    STAGE_2_OFFICIAL_DIRECT_STORE_OPEN: {
      stageId: 'STAGE_2_OFFICIAL_DIRECT_STORE_OPEN',
      directCheckoutEnabled: true,
      descriptionKo: '목표 누적 매출 달성 후 공식 자사몰 정식 오픈 공지 및 다이렉트 결제 시스템을 개방한 단계'
    }
  },
  defaultTargetStoreOpenRevenueKrw: 10000000
};

const DEFAULT_INITIAL_HQ_NOTICE = {
  noticeId: 'NOTICE-INITIAL-WELCOME',
  title: '📢 [공식 안내] 국내(스마트스토어) 및 글로벌(Lemon Squeezy · Whop · Gumroad) 라이선스·모듈 티켓 1초 등록 안내',
  content: '외부 공식 마켓에서 발급받으신 16자리 라이선스 키 또는 모듈 해금 티켓을 입력하시면 재설치 없이 1초 만에 즉시 활성화됩니다.',
  category: 'CHANNEL_GUIDE',
  pinned: true,
  publishedAt: '2026-10-15T00:00:00.000Z'
};

const SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE = {
  noticeVersion: 1,
  stagedNotices: new Map(),
  publishedNotices: [DEFAULT_INITIAL_HQ_NOTICE],
  activeNotices: [DEFAULT_INITIAL_HQ_NOTICE],
  storefrontGate: {
    stageId: 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
    directCheckoutEnabled: false,
    grandOpenBannerVisible: false,
    accumulatedRevenueKrw: 0,
    targetRevenueKrw: SALES_CHANNEL_AND_STORE_GATE_SSOT.defaultTargetStoreOpenRevenueKrw,
    updatedAt: '2026-10-15T00:00:00.000Z'
  },
  pendingPingCommand: null
};

/**
 * [국내외 6대 판매·유입 채널별 고전환 셀링 키트 카탈로그 (SSOT)]
 * - 국내: NAVER_SMARTSTORE, NAVER_TECH_BLOG
 * - 해외: LEMON_SQUEEZY, WHOP, GUMROAD, APPSUMO
 * - 모든 카피 블록은 하드코딩 가격 문자열을 배제하고 데이터 무결성·보안·즉시 개통 가치를 강조합니다.
 */
const EXTERNAL_CHANNEL_SELLING_KIT_CATALOG = Object.freeze({
  NAVER_SMARTSTORE: Object.freeze({
    channelId: 'NAVER_SMARTSTORE',
    channelName: '네이버 스마트스토어 (KR 공식 라이선스 스토어)',
    region: 'KR',
    role: '국내 이커머스·물류·세무 실무자 즉시 구매 및 모듈 티켓(MOD-TKT-*) 발급 허브',
    headline: '원본 데이터 100% 비변조(Zero Silent Mutation) + 사내 PC/외부 SNS 2원화 보안 알림 탑재 로컬 자동화 엔진',
    conversionHooks: Object.freeze([
      '원본 필드 강제 치환 없이 미정의 스키마를 안전 격리하는 Zero Silent Mutation 아키텍처',
      '사내 PC 화면(127.0.0.1) 상세 확인과 외부 SNS/문자 PII-Free 비식별 요약을 완벽 분리한 2원화 알림',
      '스마트스토어 결제 즉시 발급되는 모듈 티켓(MOD-TKT-*) 또는 Heartbeat Ping 0초 자동 해금'
    ]),
    ticketOnboardingSteps: Object.freeze([
      'Step 1: 스마트스토어에서 필요 모듈 티켓(MOD-TKT-*) 또는 코어 라이선스 키 수령',
      'Step 2: 사내 PC 로컬 대시보드(127.0.0.1)에 티켓 입력 또는 Heartbeat Ping 0초 원격 해금 수신',
      'Step 3: 클라이언트 재설치·재빌드 없이 즉시 엔터프라이즈 자동화 파이프라인 가동'
    ])
  }),
  NAVER_TECH_BLOG: Object.freeze({
    channelId: 'NAVER_TECH_BLOG',
    channelName: '네이버 기술 블로그 & 공식 카페 (KR 아키텍처 심층 가이드)',
    region: 'KR',
    role: '엔터프라이즈 보안성·비파괴 스키마 격리 기술 검증 및 무료 체험 전환 채널',
    headline: '외부 파트너 API가 예고 없이 바뀌어도 원본 정산·주문 데이터를 단 1바이트도 훼손하지 않는 비파괴 격리 기술',
    conversionHooks: Object.freeze([
      '스키마 드리프트 발생 시 임의 매핑 대신 비파괴 격리 큐(Quarantine)로 우회하여 정산 오염 원천 차단',
      '외부 알림톡·슬랙·SMS 발송 시 주민번호·통관부호·금액을 원천 배제한 PII-Free 보안 요약 규격',
      '로컬 폐쇄망·사내 PC 환경에서도 클라우드 데이터 유출 없이 독립 구동되는 하이브리드 엔진'
    ]),
    ticketOnboardingSteps: Object.freeze([
      'Step 1: 기술 블로그 아키텍처 가이드 확인 후 공식 외부 마켓에서 라이선스·모듈 티켓 발급',
      'Step 2: 로컬 마법사 또는 대시보드에 발급 티켓 등록 (Heartbeat Ping 자동 동기화 지원)',
      'Step 3: 업종별 표준 플레이북 템플릿을 선택하여 재빌드 없이 당일 실무 배치 완료'
    ])
  }),
  LEMON_SQUEEZY: Object.freeze({
    channelId: 'LEMON_SQUEEZY',
    channelName: 'Lemon Squeezy (Global SaaS & MoR Checkout)',
    region: 'GLOBAL',
    role: '글로벌 B2B SaaS 구독·모듈 번들 결제 및 MoR 세금 자동 정산 채널',
    headline: 'Zero Silent Mutation & Dual-Channel PII-Free Alerting for Mission-Critical Local Automation',
    conversionHooks: Object.freeze([
      'Zero Silent Mutation: Never corrupts original ERP/order payloads when upstream APIs drift',
      'Dual-Channel Alerting: Full diagnostics on local 127.0.0.1 dashboard, zero-PII summaries on external Slack/SMS',
      'Instant OTA Module Unlock via signed Heartbeat Ping without binary rebuilds'
    ]),
    ticketOnboardingSteps: Object.freeze([
      'Step 1: Complete checkout on Lemon Squeezy and receive your signed MOD-TKT-* license token',
      'Step 2: Paste the token into your local 127.0.0.1 console or let Heartbeat Ping auto-unlock in 0s',
      'Step 3: Activate industry-grade workflows immediately with zero downtime or reinstallation'
    ])
  }),
  WHOP: Object.freeze({
    channelId: 'WHOP',
    channelName: 'Whop (Global Automation Agency & Membership Hub)',
    region: 'GLOBAL',
    role: '글로벌 자동화 에이전시·오퍼레이터 커뮤니티 멤버십 및 모듈 패스 채널',
    headline: 'Enterprise-Grade Local Workflow Engine with Non-Destructive Schema Guard & Instant OTA Modules',
    conversionHooks: Object.freeze([
      'Protect client pipelines with Zero Silent Mutation quarantine instead of risky auto-coercion',
      'Keep sensitive customer PII strictly inside 127.0.0.1 while pushing safe incident pings to mobile/Slack',
      'Hot-plug specialized customs, FX, and cold-chain modules in 0 seconds via Heartbeat Ping'
    ]),
    ticketOnboardingSteps: Object.freeze([
      'Step 1: Claim your Whop membership pass and copy the issued module entitlement ticket',
      'Step 2: Bind the ticket to your local AutoFlow instance or sync automatically via Heartbeat Ping',
      'Step 3: Deploy high-reliability automation playbooks across client environments instantly'
    ])
  }),
  GUMROAD: Object.freeze({
    channelId: 'GUMROAD',
    channelName: 'Gumroad (Indie & Agile Ops Standalone Packs)',
    region: 'GLOBAL',
    role: '글로벌 실무자용 독립 실행형 자동화 패키지 및 단일 모듈 티켓 직판 채널',
    headline: 'Local-First Workflow Automation with Strict Data Integrity & Zero-Rebuild Module Expansion',
    conversionHooks: Object.freeze([
      '100% original payload preservation under unexpected partner schema changes (Zero Silent Mutation)',
      'Split notification security: Rich local 127.0.0.1 inspection + strictly scrubbed external mobile alerts',
      'Add-on modules unlock instantaneously via cryptographic ticket or Heartbeat Ping'
    ]),
    ticketOnboardingSteps: Object.freeze([
      'Step 1: Purchase a standalone module pack on Gumroad to receive your cryptographic ticket',
      'Step 2: Enter the ticket in the local engine UI or receive instant OTA activation on next ping',
      'Step 3: Run production-ready reconciliation and customs pipelines without rebuilding'
    ])
  }),
  APPSUMO: Object.freeze({
    channelId: 'APPSUMO',
    channelName: 'AppSumo (Global B2B Early-Adopter Deal Channel)',
    region: 'GLOBAL',
    role: '글로벌 B2B 얼리어답터 캠페인 및 확장 모듈 업셀링 유입 채널',
    headline: 'Bulletproof Local ERP & E-Commerce Automation with Non-Destructive Drift Isolation',
    conversionHooks: Object.freeze([
      'Eliminate silent data corruption with automated non-destructive schema drift quarantine',
      'Enterprise privacy compliance out of the box: Local-only detailed logs vs PII-free external alerts',
      'Seamless 0-second OTA hot-plug module expansion powered by signed Heartbeat Ping'
    ]),
    ticketOnboardingSteps: Object.freeze([
      'Step 1: Redeem your AppSumo deal code to generate a hardware-bound license and module ticket',
      'Step 2: Apply the ticket on your local 127.0.0.1 engine or sync via Heartbeat Ping in 0 seconds',
      'Step 3: Scale across e-commerce, 3PL, and accounting playbooks with zero binary modification'
    ])
  })
});

/**
 * [6대 핵심 타겟 업종별 고전환 실무 플레이북 카탈로그 (SSOT)]
 * - ECOMMERCE_OMNICHANNEL: 이커머스·옴니채널 주문/재고 동기화
 * - LOGISTICS_3PL_COLDCHAIN: 3PL 물류·콜드체인 온도/유통기한/출고 관제
 * - TAX_ACCOUNTING_ERP: 세무·회계·ERP 대사 및 정산 무결성 검증
 * - GLOBAL_CROSSBORDER_CBT: 글로벌 역직구·수출입 통관/다통화 환율 정산
 * - B2B_WHOLESALE_CREDIT_ERP: B2B 도매·거래처 여신한도/반품 클레임 무결성 관제
 * - PHARMA_MEDICAL_UDI_COMPLIANCE: 제약·의료기기 UDI 일련번호/콜드체인 규제 준수 자동화
 */
const INDUSTRY_CONVERSION_PLAYBOOK_SSOT = Object.freeze({
  ECOMMERCE_OMNICHANNEL: Object.freeze({
    industryId: 'ECOMMERCE_OMNICHANNEL',
    titleKo: '이커머스 · 옴니채널 주문/재고 무결성 자동화',
    titleEn: 'E-Commerce & Omnichannel Order/Inventory Sync',
    painPoint: '오픈마켓·자사몰 API 응답 필드가 예고 없이 변경되거나 플랫폼 판매수수료·풀필먼트 비용이 약정 요율보다 과다 차감될 때 주문 누락·정산 누수가 발생하는 문제',
    autoflowSolution: '미정의 필드 감지 및 수수료 과다차감(MOD_P) 발견 즉시 원본 주문·정산 전문을 100% 보존 격리(Zero Silent Mutation)하고 결손 없이 안전 재처리',
    recommendedModules: Object.freeze(['MOD_H_DRIFTFLOW_RADAR', 'MOD_I_ZERODROP_OUTBOX', 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD']),
    nonDestructiveDriftProof: '파트너 마켓 API 스키마 변경 시 임의 타입 변환 없이 원본 JSON 전체를 격리 보존하여 주문 오염 0건 보장',
    dualAlertSecurityProof: '사내 PC(127.0.0.1)에서는 변경 필드 상세 비교를 제공하고, 외부 단톡방/SMS로는 구매자 개인정보를 제거한 요약만 발송'
  }),
  LOGISTICS_3PL_COLDCHAIN: Object.freeze({
    industryId: 'LOGISTICS_3PL_COLDCHAIN',
    titleKo: '3PL 물류 · 콜드체인 온도/LOT 출고 안전 관제',
    titleEn: '3PL Logistics & Cold-Chain LOT Safety Control',
    painPoint: '신선식품·의약품 콜드체인 온도 일탈이나 유통기한(FEFO) 역전 시 출고 사고 및 클레임이 발생하는 문제',
    autoflowSolution: '온도 임계치 일탈 및 LOT 역전을 실시간 차단하고 네트워크 순단 시에도 Zero-Drop Outbox로 출고 지시 유실 방지',
    recommendedModules: Object.freeze(['MOD_L_COLDCHAIN_LOT_GUARD', 'MOD_I_ZERODROP_OUTBOX']),
    nonDestructiveDriftProof: 'WMS/센서 게이트웨이 포맷 변경 시에도 원본 센서 레코드를 훼손하지 않고 비파괴 격리 후 담당자 승인 연결',
    dualAlertSecurityProof: '물류 현장 로컬 콘솔에는 상세 LOT·수하인 정보를 표시하고, 외부 모바일 알림에는 수하인 식별정보를 완전 마스킹'
  }),
  TAX_ACCOUNTING_ERP: Object.freeze({
    industryId: 'TAX_ACCOUNTING_ERP',
    titleKo: '세무 · 회계 · ERP 정산 대사 및 전표 검증',
    titleEn: 'Tax, Accounting & ERP Reconciliation Guard',
    painPoint: 'PG사·은행·ERP 간 정산 내역 대사 중 필드 포맷 변경이나 소수점 오차로 인해 전표 불일치가 발생하는 문제',
    autoflowSolution: '정산 불일치 및 스키마 변경 건을 비파괴 격리 뷰어로 분리하고 담당자 확인 후 안전하게 전표 파이프라인에 복귀',
    recommendedModules: Object.freeze(['MOD_F_FINRECON_GUARD', 'MOD_H_DRIFTFLOW_RADAR']),
    nonDestructiveDriftProof: '회계 전표 및 PG 정산 원본 데이터를 단 1바이트도 임의 수정하지 않고 별도 격리 스냅샷으로 감사 추적성(Audit Trail) 확보',
    dualAlertSecurityProof: '재무팀 사내 PC 화면에서만 계좌·정산 상세를 열람하고, 외부 메신저 알림에는 계좌·주민번호·정산액을 전량 비식별 처리'
  }),
  GLOBAL_CROSSBORDER_CBT: Object.freeze({
    industryId: 'GLOBAL_CROSSBORDER_CBT',
    titleKo: '글로벌 역직구(CBT) · 수출입 통관/HS관세율/다통화 환율 정산',
    titleEn: 'Global Cross-Border Customs, HS Tariff & Multi-Currency FX Settlement',
    painPoint: '국가별 HS Code(6~10자리)·협정 관세율 오적용·개인통관고유부호 검증 실패 및 다통화(USD/JPY/EUR) 환율 스냅샷 불일치로 인한 통관 지연·추징 손실',
    autoflowSolution: '신규 OTA 핫플러그 통관 검증(MOD_J)·다통화 환율 정산(MOD_K)·HS 품목분류 및 관세율 가드(MOD_Q)를 재빌드 없이 0초 해금하여 즉시 대응',
    recommendedModules: Object.freeze(['MOD_J_CUSTOMS_CLEARANCE', 'MOD_K_GLOBAL_FX_SETTLEMENT', 'MOD_Q_HS_TARIFF_DUTY_GUARD']),
    nonDestructiveDriftProof: '해외 관세청·특송사 API 규격 변경 시 원본 인보이스 전문을 비변조 상태로 보존하고 사내 담당자 선택 매핑 지원',
    dualAlertSecurityProof: '개인통관고유부호(PCCC)·수취인 정보는 사내 PC(127.0.0.1) 내부에만 유지하고 외부 SNS 알림에서는 원천 배제'
  }),
  B2B_WHOLESALE_CREDIT_ERP: Object.freeze({
    industryId: 'B2B_WHOLESALE_CREDIT_ERP',
    titleKo: 'B2B 도매 · 거래처 여신한도/반품 클레임 무결성 관제',
    titleEn: 'B2B Wholesale Credit Limit & Return Claim Fraud Guard',
    painPoint: '거래처 미수금·여신한도 초과 발주 누락 및 악성 빈 상자(0g) 반품·왕복 배송비 미차감으로 인한 도매 마진 손실',
    autoflowSolution: 'OTA 핫플러그 여신한도 가드(MOD_M)와 반품 중량·배송비 감시 레이더(MOD_N)로 원본 발주·반품 데이터를 비변조 보존 격리하고 사내 PC 승인으로 손실 차단',
    recommendedModules: Object.freeze(['MOD_M_B2B_CREDIT_LIMIT_GUARD', 'MOD_N_RETURN_FRAUD_CLAIM_RADAR', 'MOD_I_PROFITFLOW_GUARD']),
    nonDestructiveDriftProof: '도매 ERP·반품 회수 택배사 스키마 변경 및 이상 중량 감지 시 원본 전문을 100% 보존 격리(Zero Silent Mutation)하여 정산 분쟁 증적 확보',
    dualAlertSecurityProof: '사내 PC(127.0.0.1)에서는 거래처 미수금·여신 잔액·반품 중량 비교표를 표시하고, 외부 SNS/문자에서는 거래처 금융정보·금액을 전량 비식별 마스킹'
  }),
  PHARMA_MEDICAL_UDI_COMPLIANCE: Object.freeze({
    industryId: 'PHARMA_MEDICAL_UDI_COMPLIANCE',
    titleKo: '제약 · 의료기기 UDI 일련번호/콜드체인 규제 준수 자동화',
    titleEn: 'Pharmaceutical & Medical Device UDI Serial & Cold-Chain Compliance',
    painPoint: '의약품·의료기기 표준코드(UDI) 누락/오류 및 콜드체인 온도 일탈 상태로 출고 보고가 진행되어 행정처분 및 리콜이 발생하는 리스크',
    autoflowSolution: '의약품 UDI 일련번호 무결성 가드(MOD_O)와 콜드체인 LOT 가드(MOD_L)를 Heartbeat Ping 0초 해금으로 즉시 결합하여 불량 시리얼·온도 일탈 출고를 원천 격리',
    recommendedModules: Object.freeze(['MOD_O_PHARMA_NARCOTICS_SERIAL_GUARD', 'MOD_L_COLDCHAIN_LOT_GUARD']),
    nonDestructiveDriftProof: '식약처·심평원 보고용 원장 및 바코드 스캐너 포맷 변이 시 임의 치환 없이 원본 UDI 레코드를 비변조 보존 격리하여 규제 감사 무결성 보장',
    dualAlertSecurityProof: '사내 PC 화면(127.0.0.1)에만 전체 UDI 바코드·LOT·수취 기관 정보를 표시하고, 외부 모바일/SNS 알림에서는 민감 의료·거래 정보를 100% 차단'
  })
});

const MASTER_NOTICE_STORE_GATE_PATH = path.resolve(__dirname, '../config/master_notice_store_gate.json');

function persistMasterNoticeAndStoreGateToDisk() {
  try {
    const dir = path.dirname(MASTER_NOTICE_STORE_GATE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const payload = {
      noticeVersion: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion,
      storefrontGate: { ...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate },
      stagedNotices: Array.from(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.values()),
      publishedNotices: [...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.publishedNotices],
      activeNotices: [...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices],
      pendingPingCommand: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.pendingPingCommand,
      persistedAt: new Date().toISOString()
    };
    const tmp = `${MASTER_NOTICE_STORE_GATE_PATH}.tmp.${process.pid}.${Date.now()}`;
    fs.writeFileSync(tmp, JSON.stringify(payload, null, 2), 'utf8');
    fs.renameSync(tmp, MASTER_NOTICE_STORE_GATE_PATH);
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * 10대 사전 내장 모듈 카탈로그 (기존 분리형 6종 + 신규 특화 엔진 4종)
 * - 5단계 차등 가격(Tier M1 ₩12,900 ~ Tier M5 ₩49,000)
 * - 서명 티켓(Bitmask Token: 0 ~ 1023+) 1초 무설치 즉시 해금 + JSON-RPC 2.0 MCP 호환 슬롯
 */
const MODULAR_ENGINE_CATALOG = {
  MOD_A1_LOCAL_HEALER: {
    code: 'MOD_A1_LOCAL_HEALER',
    legacyAlias: 'MODULE_A1_BYOK',
    bitIndex: 0,
    bitmask: 1,
    tier: 'M4',
    category: 'SPLIT_EXISTING',
    mcpToolName: 'autoflow.module.local_healer',
    displayName: '🛠️ 로컬 자가치유 데몬 엔진',
    priceMonthly: 29000,
    pricing: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        nodeId: { type: 'string' },
        nodeStatus: { type: 'string' },
        error: { type: 'string' }
      }
    }
  },
  MOD_A2_HQ_FINETUNE_BOT: {
    code: 'MOD_A2_HQ_FINETUNE_BOT',
    legacyAlias: 'MODULE_A2_MANAGED_AI',
    bitIndex: 1,
    bitmask: 2,
    tier: 'M5',
    category: 'SPLIT_EXISTING',
    mcpToolName: 'autoflow.module.hq_finetune_bot',
    displayName: '🧠 본사 파인튜닝 봇 연동 엔진',
    priceMonthly: 49000,
    pricing: { d7: 12900, d30: 49000, d90: 129000, d365: 490000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        nodeId: { type: 'string' },
        nodeStatus: { type: 'string' },
        attemptCount: { type: 'number' },
        error: { type: 'string' }
      }
    }
  },
  MOD_B_RECON_ENGINE: {
    code: 'MOD_B_RECON_ENGINE',
    legacyAlias: 'MODULE_B_BRANCH_RECON',
    bitIndex: 2,
    bitmask: 4,
    tier: 'M4',
    category: 'SPLIT_EXISTING',
    mcpToolName: 'autoflow.module.recon_engine',
    displayName: '⚖️ 숫자 정합성 대사 엔진 (ReconFlow)',
    priceMonthly: 29000,
    pricing: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        orderId: { type: 'string' },
        branches: { type: 'array' }
      }
    }
  },
  MOD_C_PACE_DEDUP: {
    code: 'MOD_C_PACE_DEDUP',
    bitIndex: 3,
    bitmask: 8,
    tier: 'M1',
    category: 'SPLIT_EXISTING',
    mcpToolName: 'autoflow.module.pace_dedup',
    displayName: '🚦 계정정지·중복실행 방어 엔진 (PaceFlow)',
    priceMonthly: 12900,
    pricing: { d7: 3900, d30: 12900, d90: 33000, d365: 129000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        orderId: { type: 'string' },
        dedupKey: { type: 'string' },
        rateLimitRps: { type: 'number' }
      }
    }
  },
  MOD_D_COMPLIANCE_PII: {
    code: 'MOD_D_COMPLIANCE_PII',
    bitIndex: 4,
    bitmask: 16,
    tier: 'M1',
    category: 'SPLIT_EXISTING',
    mcpToolName: 'autoflow.module.compliance_pii',
    displayName: '🛡️ 개인정보(PII)·법무 금칙어 검열 엔진 (GuardFlow)',
    priceMonthly: 12900,
    pricing: { d7: 3900, d30: 12900, d90: 33000, d365: 129000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        payload: { type: 'object' }
      }
    }
  },
  MOD_E_BLACKBOX_REPLAY: {
    code: 'MOD_E_BLACKBOX_REPLAY',
    bitIndex: 5,
    bitmask: 32,
    tier: 'M1',
    category: 'SPLIT_EXISTING',
    mcpToolName: 'autoflow.module.blackbox_replay',
    displayName: '📼 무중단 블랙박스 & 3초 이어하기 엔진 (VaultFlow)',
    priceMonthly: 12900,
    pricing: { d7: 3900, d30: 12900, d90: 33000, d365: 129000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        nodeId: { type: 'string' },
        checkpointId: { type: 'string' },
        payload: { type: 'object' }
      }
    }
  },
  MOD_F_SIMFLOW_SANDBOX: {
    code: 'MOD_F_SIMFLOW_SANDBOX',
    bitIndex: 6,
    bitmask: 64,
    tier: 'M2',
    category: 'NEW_STANDALONE',
    mcpToolName: 'autoflow.module.simflow_sandbox',
    displayName: '🧪 실행 전 가상 리허설(Dry-Run) 샌드박스 엔진 (SimFlow)',
    priceMonthly: 15900,
    pricing: { d7: 4900, d30: 15900, d90: 42000, d365: 159000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        dryRun: { type: 'boolean' },
        simulationMode: { type: 'boolean' },
        payload: { type: 'object' }
      }
    }
  },
  MOD_G_KEYFLOW_ROTATOR: {
    code: 'MOD_G_KEYFLOW_ROTATOR',
    bitIndex: 7,
    bitmask: 128,
    tier: 'M2',
    category: 'NEW_STANDALONE',
    mcpToolName: 'autoflow.module.keyflow_rotator',
    displayName: '🔑 API 키 무노출 금고 & 다중 계정 자동 교대 엔진 (KeyFlow)',
    priceMonthly: 15900,
    pricing: { d7: 4900, d30: 15900, d90: 42000, d365: 159000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        httpStatus: { type: 'number' },
        quotaExceeded: { type: 'boolean' },
        accountPool: { type: 'array' }
      }
    }
  },
  MOD_H_DRIFTFLOW_RADAR: {
    code: 'MOD_H_DRIFTFLOW_RADAR',
    bitIndex: 8,
    bitmask: 256,
    tier: 'M3',
    category: 'NEW_STANDALONE',
    mcpToolName: 'autoflow.module.driftflow_radar',
    displayName: '🕵️ 상대방 API 잠수함 패치 사전 감지 레이더 엔진 (DriftFlow)',
    priceMonthly: 19000,
    pricing: { d7: 5900, d30: 19000, d90: 49000, d365: 190000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        payload: { type: 'object' }
      }
    }
  },
  MOD_I_PROFITFLOW_GUARD: {
    code: 'MOD_I_PROFITFLOW_GUARD',
    bitIndex: 9,
    bitmask: 512,
    tier: 'M3',
    category: 'NEW_STANDALONE',
    mcpToolName: 'autoflow.module.profitflow_guard',
    displayName: '💸 건별 실제 순이익 실시간 정산 & 적자 브레이크 엔진 (ProfitFlow)',
    priceMonthly: 19000,
    pricing: { d7: 5900, d30: 19000, d90: 49000, d365: 190000 },
    preInstalled: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        payload: {
          type: 'object',
          properties: {
            salePrice: { type: 'number' },
            costPrice: { type: 'number' }
          }
        }
      }
    }
  }
};

/**
 * [Slot B Iteration 3, 7 & 11 — 과업 3] 하트비트 핑(SYNC_MCP_MODULES)으로 재배포 없이 즉시 주입 가능한
 * 업종 특화 OTA 핫플러그 모듈 표준 템플릿 카탈로그 (Bit 10 ~ Bit 17, 총 8종)
 */
const OTA_HOTPLUG_MODULE_TEMPLATES = {
  MOD_J_CUSTOMS_CLEARANCE: {
    code: 'MOD_J_CUSTOMS_CLEARANCE',
    bitIndex: 10,
    bitmask: 1024,
    tier: 'M4',
    category: 'OTA_HOTPLUG_SPECIALIZED',
    mcpToolName: 'autoflow.module.customs_clearance',
    displayName: '🛃 관세청 유니패스 개인통관고유부호(PCCC) 검증 & 통관 보류 분리 모듈 (CustomsFlow)',
    priceMonthly: 29000,
    pricing: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    preInstalled: false,
    hotPlugReady: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        personalCustomsCode: { type: 'string' },
        recipientName: { type: 'string' },
        recipientPhone: { type: 'string' }
      }
    }
  },
  MOD_K_GLOBAL_FX_SETTLEMENT: {
    code: 'MOD_K_GLOBAL_FX_SETTLEMENT',
    bitIndex: 11,
    bitmask: 2048,
    tier: 'M4',
    category: 'OTA_HOTPLUG_SPECIALIZED',
    mcpToolName: 'autoflow.module.global_fx_settlement',
    displayName: '💱 글로벌 다통화(USD/JPY/EUR) 정산 환율 차이 감지 & 사내 PC 분리 알림 모듈 (GlobalFxFlow)',
    priceMonthly: 29000,
    pricing: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    preInstalled: false,
    hotPlugReady: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        currency: { type: 'string' },
        appliedExchangeRate: { type: 'number' },
        benchmarkExchangeRate: { type: 'number' }
      }
    }
  },
  MOD_L_COLDCHAIN_LOT_GUARD: {
    code: 'MOD_L_COLDCHAIN_LOT_GUARD',
    bitIndex: 12,
    bitmask: 4096,
    tier: 'M3',
    category: 'OTA_HOTPLUG_SPECIALIZED',
    mcpToolName: 'autoflow.module.coldchain_lot_guard',
    displayName: '❄️ 신선식품·의약품 콜드체인 온도 이탈 & 제조 로트·유통기한 감시 모듈 (ColdChainFlow)',
    priceMonthly: 19000,
    pricing: { d7: 5900, d30: 19000, d90: 49000, d365: 190000 },
    preInstalled: false,
    hotPlugReady: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        temperatureCelsius: { type: 'number' },
        lotNumber: { type: 'string' },
        remainingShelfLifeDays: { type: 'number' }
      }
    }
  },
  MOD_M_B2B_CREDIT_LIMIT_GUARD: {
    code: 'MOD_M_B2B_CREDIT_LIMIT_GUARD',
    bitIndex: 13,
    bitmask: 8192,
    tier: 'M4',
    category: 'OTA_HOTPLUG_SPECIALIZED',
    mcpToolName: 'autoflow.module.b2b_credit_limit_guard',
    displayName: '🏦 B2B 거래처 여신 한도 초과 & 미수금 부실 출고 사전 분리 가드 (CreditFlow)',
    priceMonthly: 29000,
    pricing: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    preInstalled: false,
    hotPlugReady: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        b2bCreditLimit: { type: 'number' },
        currentReceivableBalance: { type: 'number' },
        orderCreditAmount: { type: 'number' }
      }
    }
  },
  MOD_N_RETURN_FRAUD_CLAIM_RADAR: {
    code: 'MOD_N_RETURN_FRAUD_CLAIM_RADAR',
    bitIndex: 14,
    bitmask: 16384,
    tier: 'M4',
    category: 'OTA_HOTPLUG_SPECIALIZED',
    mcpToolName: 'autoflow.module.return_fraud_claim_radar',
    displayName: '📦 반품 중량·바코드 불일치(빈 박스) & 반품 배송비 미차감 환불 분리 레이더 (ReturnFlow)',
    priceMonthly: 29000,
    pricing: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    preInstalled: false,
    hotPlugReady: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        outboundWeightGram: { type: 'number' },
        returnedWeightGram: { type: 'number' },
        returnShippingFeeDeducted: { type: 'boolean' }
      }
    }
  },
  MOD_O_PHARMA_NARCOTICS_SERIAL_GUARD: {
    code: 'MOD_O_PHARMA_NARCOTICS_SERIAL_GUARD',
    bitIndex: 15,
    bitmask: 32768,
    tier: 'M4',
    category: 'OTA_HOTPLUG_SPECIALIZED',
    mcpToolName: 'autoflow.module.pharma_narcotics_serial_guard',
    displayName: '💊 의약품·의료기기 표준 일련번호(UDI) 및 식약처·심평원 보고 누락 분리 가드 (MedSerialFlow)',
    priceMonthly: 29000,
    pricing: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    preInstalled: false,
    hotPlugReady: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        udiBarcode: { type: 'string' },
        pharmaSerialNo: { type: 'string' },
        mfdsReportRequired: { type: 'boolean' }
      }
    }
  },
  MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD: {
    code: 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD',
    bitIndex: 16,
    bitmask: 65536,
    tier: 'M4',
    category: 'OTA_HOTPLUG_SPECIALIZED',
    mcpToolName: 'autoflow.module.marketplace_fee_overcharge_guard',
    displayName: '🧾 오픈마켓·플랫폼 판매수수료·풀필먼트 과다차감 감지 & 정산 보류 분리 모듈 (FeeAuditFlow)',
    priceMonthly: 29000,
    pricing: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    preInstalled: false,
    hotPlugReady: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        chargedCommissionFee: { type: 'number' },
        expectedCommissionFee: { type: 'number' },
        contractedFeeRatePct: { type: 'number' }
      }
    }
  },
  MOD_Q_HS_TARIFF_DUTY_GUARD: {
    code: 'MOD_Q_HS_TARIFF_DUTY_GUARD',
    bitIndex: 17,
    bitmask: 131072,
    tier: 'M4',
    category: 'OTA_HOTPLUG_SPECIALIZED',
    mcpToolName: 'autoflow.module.hs_tariff_duty_guard',
    displayName: '🚢 수출입 HS 품목분류코드(6~10자리) 정합성 & 관세율 오적용 사전 분리 가드 (TariffFlow)',
    priceMonthly: 29000,
    pricing: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    preInstalled: false,
    hotPlugReady: true,
    requiresRedownload: false,
    inputSchema: {
      type: 'object',
      properties: {
        hsCode: { type: 'string' },
        declaredHsCode: { type: 'string' },
        appliedDutyRatePct: { type: 'number' },
        expectedDutyRatePct: { type: 'number' }
      }
    }
  }
};

/**
 * 네이버 스마트스토어 단품 워크플로우 카탈로그 (AF-NAVER-01 ~ AF-NAVER-10)
 */
const NAVER_SINGLE_WORKFLOW_CATALOG = Object.freeze({
  'AF-NAVER-01': { sku: 'AF-NAVER-01', code: 'MOD_A1_LOCAL_HEALER', bitmask: 1, name: '스마트스토어 신규 주문 알림톡 & 시트 원장' },
  'AF-NAVER-02': { sku: 'AF-NAVER-02', code: 'MOD_I_PROFITFLOW_GUARD', bitmask: 256, name: '스마트스토어 실시간 역마진 브레이크 & 출고 보류 가드' },
  'AF-NAVER-03': { sku: 'AF-NAVER-03', code: 'MOD_C_PACE_DEDUP', bitmask: 4, name: '스마트스토어 택배사 14컬럼 송장 엑셀 자동 변환기' },
  'AF-NAVER-04': { sku: 'AF-NAVER-04', code: 'MOD_B_RECON_ENGINE', bitmask: 2, name: '스마트스토어 택배사 출고 운송장 번호 일괄 역기입기' },
  'AF-NAVER-05': { sku: 'AF-NAVER-05', code: 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD', bitmask: 65536, name: '스마트스토어 일별 정산 vs 실주문 1원 대사기' },
  'AF-NAVER-06': { sku: 'AF-NAVER-06', code: 'MOD_J_CUSTOMS_CLEARANCE', bitmask: 1024, name: '네이버 해외직구 관세청 개인통관고유부호 실시간 검증기' },
  'AF-NAVER-07': { sku: 'AF-NAVER-07', code: 'MOD_L_COLDCHAIN_LOT_GUARD', bitmask: 4096, name: '네이버 품절/재입고 실시간 감지 및 상품 상태 자동 전환기' },
  'AF-NAVER-08': { sku: 'AF-NAVER-08', code: 'MOD_N_RETURN_FRAUD_CLAIM_RADAR', bitmask: 16384, name: '네이버 취소/반품/교환 자동 접수 및 택배 회수 지시 엔진' },
  'AF-NAVER-09': { sku: 'AF-NAVER-09', code: 'MOD_E_BLACKBOX_REPLAY', bitmask: 16, name: '네이버 악성 리뷰 실시간 감지 & AI 방어 답글/블라인드 요청기' },
  'AF-NAVER-10': { sku: 'AF-NAVER-10', code: 'MOD_D_COMPLIANCE_PII', bitmask: 8, name: '네이버 포토리뷰 베스트 선정 & 포인트 적립 대상자 자동 추출기' }
});

const MODULAR_PRICING_SSOT = {
  WF_ENTRY: 9900,
  WF_STANDARD: 19000,
  WF_COMPLEX: 29000,
  individualNodes: INDIVIDUAL_NODE_PRICING_SSOT,
  MODULE_A1_BYOK: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
  MODULE_A2_MANAGED_AI: { d7: 12900, d30: 49000, d90: 129000, d365: 490000 },
  MODULE_B_BRANCH_RECON: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
  MOD_A1_LOCAL_HEALER: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
  MOD_A2_HQ_FINETUNE_BOT: { d7: 12900, d30: 49000, d90: 129000, d365: 490000 },
  MOD_B_RECON_ENGINE: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
  MOD_C_PACE_DEDUP: { d7: 3900, d30: 12900, d90: 33000, d365: 129000 },
  MOD_D_COMPLIANCE_PII: { d7: 3900, d30: 12900, d90: 33000, d365: 129000 },
  MOD_E_BLACKBOX_REPLAY: { d7: 3900, d30: 12900, d90: 33000, d365: 129000 },
  MOD_F_SIMFLOW_SANDBOX: { d7: 4900, d30: 15900, d90: 42000, d365: 159000 },
  MOD_G_KEYFLOW_ROTATOR: { d7: 4900, d30: 15900, d90: 42000, d365: 159000 },
  MOD_H_DRIFTFLOW_RADAR: { d7: 5900, d30: 19000, d90: 49000, d365: 190000 },
  MOD_I_PROFITFLOW_GUARD: { d7: 5900, d30: 19000, d90: 49000, d365: 190000 },
  MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
  MOD_Q_HS_TARIFF_DUTY_GUARD: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
  workflows: {
    WF_ENTRY: { price: 9900, free_trial_days: 7, includes_modules: ['MODULE_A', 'MODULE_B'] },
    WF_STANDARD: { price: 19000, free_trial_days: 7, includes_modules: ['MODULE_A', 'MODULE_B'] },
    WF_COMPLEX: { price: 29000, free_trial_days: 7, includes_modules: ['MODULE_A', 'MODULE_B'] }
  },
  modules: {
    MODULE_A1_BYOK: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    MODULE_A2_MANAGED_AI: { d7: 12900, d30: 49000, d90: 129000, d365: 490000 },
    MODULE_B_BRANCH_RECON: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    MOD_A1_LOCAL_HEALER: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    MOD_A2_HQ_FINETUNE_BOT: { d7: 12900, d30: 49000, d90: 129000, d365: 490000 },
    MOD_B_RECON_ENGINE: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    MOD_C_PACE_DEDUP: { d7: 3900, d30: 12900, d90: 33000, d365: 129000 },
    MOD_D_COMPLIANCE_PII: { d7: 3900, d30: 12900, d90: 33000, d365: 129000 },
    MOD_E_BLACKBOX_REPLAY: { d7: 3900, d30: 12900, d90: 33000, d365: 129000 },
    MOD_F_SIMFLOW_SANDBOX: { d7: 4900, d30: 15900, d90: 42000, d365: 159000 },
    MOD_G_KEYFLOW_ROTATOR: { d7: 4900, d30: 15900, d90: 42000, d365: 159000 },
    MOD_H_DRIFTFLOW_RADAR: { d7: 5900, d30: 19000, d90: 49000, d365: 190000 },
    MOD_I_PROFITFLOW_GUARD: { d7: 5900, d30: 19000, d90: 49000, d365: 190000 },
    MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 },
    MOD_Q_HS_TARIFF_DUTY_GUARD: { d7: 7900, d30: 29000, d90: 79000, d365: 290000 }
  }
};

const SHARED_DYNAMIC_MCP_REGISTRY = new Map();
const PING_MODULE_OTA_HMAC_SECRET = process.env.AUTOFLOW_PING_MODULE_OTA_SECRET || 'AF-ENTERPRISE-PING-MODULE-OTA-HMAC-2026';

class LicenseManager {
  constructor(statePath = LICENSE_STATE_PATH) {
    if (typeof statePath === 'string' && statePath.trim().length > 0) {
      this.statePath = statePath.trim();
    } else if (statePath && typeof statePath === 'object' && typeof statePath.statePath === 'string' && statePath.statePath.trim().length > 0) {
      this.statePath = statePath.statePath.trim();
    } else {
      this.statePath = LICENSE_STATE_PATH;
    }
    this.activeModuleBitmask = null;
    this.dynamicMcpRegistry = SHARED_DYNAMIC_MCP_REGISTRY;
    this.activatedTicketIds = new Set();
    this.revokedTicketIds = new Set();
  }

  _calculateLocalHwid() {
    try {
      const ifaces = os.networkInterfaces();
      const macs = [];
      for (const name of Object.keys(ifaces)) {
        for (const iface of ifaces[name]) {
          if (iface && !iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
            macs.push(iface.mac);
          }
        }
      }
      macs.sort();
      const seed = [os.hostname(), os.platform(), os.arch(), macs.join(':') || 'LOCAL_DEVICE_SEED'].join('|');
      const hash = crypto.createHash('sha256').update(seed).digest('hex').substring(0, 16).toUpperCase();
      return `AF-HWID-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`;
    } catch (e) {
      return 'AF-HWID-LOCAL-DEV-0001';
    }
  }

  getHardwareSnapshot() {
    try {
      const ifaces = os.networkInterfaces();
      const macs = [];
      for (const name of Object.keys(ifaces)) {
        for (const iface of ifaces[name]) {
          if (iface && !iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
            macs.push(iface.mac);
          }
        }
      }
      macs.sort();
      const cpus = os.cpus() || [];
      return {
        hwid: this._calculateLocalHwid(),
        platform: os.platform(),
        arch: os.arch(),
        hostname: os.hostname(),
        cpu_count: cpus.length,
        cpu_model: (cpus[0] && cpus[0].model) || 'V8_EMBEDDED',
        mac_addresses: macs
      };
    } catch (e) {
      return {
        hwid: this._calculateLocalHwid(),
        platform: 'darwin',
        arch: 'arm64',
        hostname: 'localhost',
        cpu_count: 8,
        cpu_model: 'Apple Silicon',
        mac_addresses: []
      };
    }
  }

  /**
   * Load license state from disk
   */
  loadState() {
    try {
      if (this.statePath && typeof this.statePath === 'string' && fs.existsSync(this.statePath)) {
        const raw = fs.readFileSync(this.statePath, 'utf8');
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (err) {
      console.warn(`[LicenseManager] Warning reading license state: ${err.message}`);
    }

    return {
      license_key: 'AF-BYOK-TRIAL',
      tier: 'BYOK_LITE',
      status: 'PENDING_ACTIVATION',
      activated_at: null,
      valid_until: null,
      hwid: null,
      last_heartbeat_ack: null,
      refund_policy: 'FAIR_PRORATED_SETTLEMENT',
      refund_ineligible: false,
      total_extended_days: 0,
      extension_history: []
    };
  }

  /**
   * Atomic persistence to disk
   */
  saveState(state) {
    if (!state || typeof state !== 'object' || Array.isArray(state)) {
      return false;
    }
    try {
      const targetPath = (typeof this.statePath === 'string' && this.statePath.trim().length > 0) ? this.statePath : LICENSE_STATE_PATH;
      const dir = path.dirname(targetPath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      if (Array.isArray(state.extension_history) && state.extension_history.length > 100) {
        state.extension_history = state.extension_history.slice(-100);
      }
      const tmp = `${targetPath}.tmp.${process.pid}.${Date.now()}`;
      fs.writeFileSync(tmp, JSON.stringify(state, null, 2), 'utf8');
      fs.renameSync(tmp, targetPath);
      return true;
    } catch (err) {
      console.error(`[LicenseManager] Error saving state: ${err.message}`);
      return false;
    }
  }

  /**
   * Load or initialize license state (Honoring AUTOFLOW_INITIAL_STATUS & AUTOFLOW_LICENSE_STATE_PATH)
   */
  loadOrCreateState() {
    return loadOrCreateLicenseState(this.statePath);
  }

  /**
   * Activate license with Fair Refund & HWID Hardware Snapshot Binding
   * @param {object} params
   * @param {string} params.licenseKey
   * @param {string} [params.hwid]
   * @param {'BYOK_LITE'|'MANAGED_PRO'|'MANAGED_ENTERPRISE'|'ENTERPRISE_SELF_HEALING'} [params.tier]
   * @param {boolean} params.refundConsent - Mandatory agreement to fair refund policy
   * @param {number} [params.durationDays]
   * @param {string} [params.ownerEmail]
   */
  activateLicense(params = {}) {
    params = (params && typeof params === 'object') ? params : {};
    const {
      licenseKey,
      hwid = this._calculateLocalHwid(),
      tier = 'BYOK_LITE',
      refundConsent,
      durationDays = 365,
      ownerEmail = ''
    } = params;

    // 1. Mandatory Fair Refund Policy Agreement Enforcement
    if (refundConsent !== true && refundConsent !== 'true') {
      return {
        success: false,
        error: 'REFUND_CONSENT_REQUIRED',
        legal_basis: '공정거래위원회 표준약관 및 전자상거래 등에서의 소비자보호에 관한 법률',
        message: '공정 환불 정산 규정(7일 이내 결함 시 100% 전액 환불, 7일 경과 후 접수일 기준 실사용 일수 일할 차감 + 10% 공제 잔여액 정산)에 동의해야 합니다.'
      };
    }

    if (!licenseKey || String(licenseKey).trim().length < 5) {
      return {
        success: false,
        error: 'INVALID_LICENSE_KEY',
        message: '유효한 라이선스 키를 입력해 주세요.'
      };
    }

    const trimmedKey = String(licenseKey).trim();
    const cyberDeceptionSentinel = require('./cyber_deception_tarpit_sentinel');
    const canaryCheck = cyberDeceptionSentinel.inspectForCanaryTrigger(trimmedKey, {
      hwid,
      client_ip: params.client_ip || params.clientIp || '127.0.0.1',
      user_agent: params.user_agent || params.userAgent || 'LicenseManager.activateLicense'
    });
    if (canaryCheck && canaryCheck.triggered) {
      const forensicRecord = cyberDeceptionSentinel.recordForensicEvidenceAndLockHwid({
        ...canaryCheck,
        hwid,
        client_ip: params.client_ip || params.clientIp || '127.0.0.1',
        user_agent: params.user_agent || params.userAgent || 'LicenseManager.activateLicense'
      });
      const currentState = this.loadState();
      this.saveState({
        ...currentState,
        hwid: hwid || currentState.hwid || this._calculateLocalHwid(),
        status: 'DECEPTION_TARPIT_QUARANTINE',
        is_blocked: true,
        deception_trap_triggered: true,
        deception_incident_id: forensicRecord.incident_id
      });
      return cyberDeceptionSentinel.buildTarpitLabyrinthResponse(params.step || 1, forensicRecord);
    }

    let moduleTicketResult = null;
    if (trimmedKey.startsWith('AF-TKT-v1.')) {
      moduleTicketResult = this.activateModuleTicket({ ticket: trimmedKey, expectedHwid: hwid });
      if (!moduleTicketResult || !moduleTicketResult.success) {
        return {
          ...(moduleTicketResult || {}),
          success: false,
          activated: false,
          error: (moduleTicketResult && moduleTicketResult.error) || 'INVALID_MODULE_TICKET',
          message: `모듈 티켓 검증 실패: ${(moduleTicketResult && moduleTicketResult.error) || 'INVALID_MODULE_TICKET'}`
        };
      }
    } else if (/^\d{16}$/.test(trimmedKey) || /^(ORD|GUMROAD|LEMON|LS)-/i.test(trimmedKey) || /^[A-Za-z0-9]{8}-[A-Za-z0-9]{8}-[A-Za-z0-9]{8}-[A-Za-z0-9]{8}$/.test(trimmedKey) || /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(trimmedKey)) {
      // 스마트스토어/검로드/Lemon Squeezy 외부 주문번호 무인 티켓 자동 교환 및 활성화
      const exchRes = this.exchangeExternalOrderForTicket({
        orderIdOrKey: trimmedKey,
        hwid,
        channel: params.channel,
        customerEmail: ownerEmail,
        validDays: durationDays
      });
      if (exchRes && !exchRes.success) {
        return {
          ...exchRes,
          success: false,
          activated: false
        };
      }
      if (exchRes && exchRes.success && exchRes.ticket) {
        moduleTicketResult = exchRes;
      }
    }

    const validTiers = ['BYOK_LITE', 'MANAGED_PRO', 'MANAGED_ENTERPRISE', 'ENTERPRISE_SELF_HEALING', 'ENGINE_HEAL', 'ENGINE_RECON', 'ENGINE_DUAL'];
    const selectedTier = validTiers.includes(tier) ? tier : 'BYOK_LITE';
    const effectiveDurationDays = (moduleTicketResult && Number.isFinite(moduleTicketResult.validDays) && moduleTicketResult.validDays > 0)
      ? moduleTicketResult.validDays
      : durationDays;

    const now = new Date();
    const expiry = new Date(now.getTime() + effectiveDurationDays * 24 * 60 * 60 * 1000);
    const hwSnapshot = this.getHardwareSnapshot();

    const currentState = this.loadState();
    const updatedState = {
      ...currentState,
      license_key: trimmedKey,
      hwid: hwid,
      hardware_snapshot: hwSnapshot,
      tier: selectedTier,
      status: 'ACTIVE',
      activated_at: now.toISOString(),
      last_heartbeat_ack: now.toISOString(),
      valid_until: (moduleTicketResult && moduleTicketResult.expiresAt) ? moduleTicketResult.expiresAt : expiry.toISOString(),
      duration_days: effectiveDurationDays,
      total_extended_days: (currentState.total_extended_days || 0) + effectiveDurationDays,
      refund_policy: 'FAIR_PRORATED_SETTLEMENT',
      refund_ineligible: false,
      refund_consent_timestamp: now.toISOString(),
      legal_clause: '공정 환불 정산 규정(접수일 기준 실사용 일수 일할 차감 + 10% 공제 후 잔여액 정산)',
      device_bound: true,
      owner_email: ownerEmail || currentState.owner_email || '',
      ...(moduleTicketResult
        ? {
            active_module_bitmask: moduleTicketResult.activeModuleBitmask,
            unlocked_modules: moduleTicketResult.unlockedModules
          }
        : {}),
      extension_history: [
        ...(currentState.extension_history || []),
        {
          event: moduleTicketResult ? 'MODULE_TICKET_AND_HARDWARE_LOCK' : 'ACTIVATION_AND_HARDWARE_LOCK',
          tier: selectedTier,
          hwid: hwid,
          activated_at: now.toISOString(),
          duration_days: effectiveDurationDays,
          note: moduleTicketResult
            ? `모듈 티켓(${(moduleTicketResult.unlockedModules || []).join(', ')}) 1초 해금 및 1:1 HWID 바인딩`
            : `${selectedTier} 활성화 및 1:1 HWID 하드웨어 스냅샷 바인딩 (공정 환불 정산 적용)`
        }
      ].slice(-100)
    };

    this.saveState(updatedState);

    return {
      ...(moduleTicketResult || {}),
      success: true,
      activated: true,
      isModuleTicket: Boolean(moduleTicketResult),
      status: 'ACTIVE',
      tier: selectedTier,
      hwid: hwid,
      activated_at: updatedState.activated_at,
      valid_until: updatedState.valid_until,
      refund_policy: 'FAIR_PRORATED_SETTLEMENT',
      refund_ineligible: false,
      workflowAlwaysRuns: true,
      legal_notice: '공정 환불 규정(7일 이내 결함 100% 전액 환불, 7일 경과 시 접수일 기준 실사용 일할 차감 + 10% 공제 잔여액 정산)',
      message: moduleTicketResult
        ? `모듈 티켓 해금(${(moduleTicketResult.unlockedModules || []).length}개 모듈, +${effectiveDurationDays}일) 및 현재 PC(${hwid}) 등록이 1초 완료되었습니다.`
        : `${selectedTier} 플랜이 현재 PC(${hwid})에 성공적으로 활성화되었습니다.`
    };
  }

  /**
   * Fair Refund Calculation Engine (공정 환불 정산 엔진)
   * 1) 결제 후 7일 이내 & 미활성화: 100% 무조건 전액 환불 (FULL_REFUND_UNACTIVATED)
   * 2) 활성화 후 7일 이내 (엔진 결함/호환성 불가): 100% 전액 환불 (FULL_REFUND_DEFECT)
   * 3) 7일 경과 후 중도 해지: 접수일 기준 실사용 일수 일할 차감 + 10% 위약수수료 공제 잔여액 정산
   * 
   * @param {object} params
   * @param {string|number} [params.receiptTimestamp] - 환불 접수 타임스탬프 (기본: Date.now())
   * @param {number} [params.totalPaid] - 총 결제 금액 (기본: 396000원)
   * @param {number} [params.totalDurationDays] - 총 라이선스 유효일수 (기본: 365)
   * @param {boolean} [params.defectReported] - 엔진 결함 또는 호환성 불가 여부
   * @param {boolean} [params.isUnactivated] - 미활성화 여부
   */
  calculateFairRefund(params = {}) {
    params = (params && typeof params === 'object') ? params : {};
    const state = this.loadState();
    const totalPaid = Number(params.totalPaid || state.total_paid || 396000);
    const totalDurationDays = Number(params.totalDurationDays || state.duration_days || 365);
    const defectReported = Boolean(params.defectReported);
    const parsedReceipt = params.receiptTimestamp ? new Date(params.receiptTimestamp) : new Date();
    const receiptTime = Number.isNaN(parsedReceipt.getTime()) ? new Date() : parsedReceipt;
    const alreadyActivated = Boolean(state.activated_at && state.status !== 'PENDING_ACTIVATION');
    const isUnactivated = !alreadyActivated && (params.isUnactivated === true || state.status === 'PENDING_ACTIVATION' || !state.activated_at);

    // 1) 결제 후 7일 이내 & 미활성화: 100% 무조건 전액 환불
    if (isUnactivated) {
      return {
        success: true,
        eligible: true,
        type: 'FULL_REFUND_UNACTIVATED',
        status: 'FULL_REFUND_UNACTIVATED',
        total_paid: totalPaid,
        total_duration_days: totalDurationDays,
        used_days: 0,
        used_amount: 0,
        fee: 0,
        refund_amount: totalPaid,
        receipt_timestamp: receiptTime.toISOString(),
        message: '결제 후 미활성화 상태로 100% 무조건 전액 환불 대상입니다.'
      };
    }

    const activatedDate = new Date(state.activated_at);
    const diffMs = receiptTime.getTime() - activatedDate.getTime();
    const diffDaysFloat = Math.max(0, diffMs / (1000 * 60 * 60 * 24));
    const used_days = Math.max(1, Math.ceil(diffDaysFloat));
    const used_amount = Math.min(totalPaid, Math.round((totalPaid / totalDurationDays) * used_days));
    const fee = Math.round(totalPaid * 0.10); // 위약금 및 PG 수수료 10%
    const refund_amount = Math.max(0, totalPaid - used_amount - fee);

    // 2) 활성화 후 7일 이내 & 엔진 결함/호환성 불가: 관리자 결함 검수 대기 (검수 통과 시 100% 환불, 반려 시 일할 정산 전환)
    if (defectReported && diffDaysFloat <= 7.0) {
      const adminVerified = params.adminDefectVerified === true;
      return {
        success: true,
        eligible: true,
        type: 'FULL_REFUND_DEFECT',
        status: adminVerified ? 'FULL_REFUND_DEFECT' : 'REFUND_PENDING_DEFECT_VERIFICATION',
        requires_admin_verification: !adminVerified,
        total_paid: totalPaid,
        total_duration_days: totalDurationDays,
        used_days: used_days,
        used_amount: 0,
        fee: 0,
        refund_amount: totalPaid,
        provisional_used_days: used_days,
        provisional_used_amount: used_amount,
        provisional_fee: fee,
        provisional_prorated_refund: refund_amount,
        fallback_prorated_amount: refund_amount,
        receipt_timestamp: receiptTime.toISOString(),
        message: adminVerified
          ? '활성화 후 7일 이내 엔진 결함 검수가 최종 확인되어 100% 전액 환불이 확정되었습니다.'
          : '활성화 후 7일 이내 엔진 결함/호환성 불가 접수 건으로 관리자 결함 로그 검수 대기(REFUND_PENDING_DEFECT_VERIFICATION) 상태로 접수되었습니다. (결함 확인 시 100% 전액 환불, 단순 변심 판정 시 일할 차감 + 10% 공제 정산 적용)'
      };
    }

    // 3) 7일 경과 후 중도 해지 (연간 라이선스 기준 일할 차감 + 10% 공제)

    return {
      success: true,
      eligible: refund_amount > 0,
      type: 'PRORATED_REFUND_AFTER_7_DAYS',
      status: refund_amount > 0 ? 'PRORATED_REFUND_ELIGIBLE' : 'PRORATED_REFUND_EXHAUSTED',
      total_paid: totalPaid,
      total_duration_days: totalDurationDays,
      used_days: used_days,
      used_amount: used_amount,
      fee: fee,
      refund_amount: refund_amount,
      receipt_timestamp: receiptTime.toISOString(),
      message: refund_amount > 0
        ? `접수일 기준 실사용 ${used_days}일 일할 차감(₩${used_amount.toLocaleString()}) 및 10% 위약수수료(₩${fee.toLocaleString()}) 공제 후 잔여액 ₩${refund_amount.toLocaleString()}원 정산 환불됩니다.`
        : '사용 일수 초과 및 수수료 공제로 환불 잔여액이 없습니다.'
    };
  }

  /**
   * HWID & Hardware Snapshot Verification for Refund Request
   * 활성화 당시 박제된 HWID, CPU, MAC, 최초 활성화 일시와 대조하여 일치 여부 판정
   */
  verifyRefundEligibilityWithHardware(hwid, reportedHardware = {}) {
    reportedHardware = (reportedHardware && typeof reportedHardware === 'object') ? reportedHardware : {};
    const state = this.loadState();
    if (!state.hwid) {
      return {
        valid: false,
        eligible: false,
        reason: 'LICENSE_NOT_BOUND',
        message: '바인딩된 라이선스 또는 기기 정보가 존재하지 않습니다.'
      };
    }

    const normHwid = (typeof hwid === 'string' && hwid.trim().length > 0)
      ? hwid.trim()
      : (hwid && typeof hwid === 'object' && typeof hwid.hwid === 'string' ? hwid.hwid.trim() : '');
    const targetHwid = normHwid || this._calculateLocalHwid();
    const hwMatched = (state.hwid === targetHwid);
    const snapshot = state.hardware_snapshot || {};

    let cpuMatched = true;
    let macMatched = true;

    if (reportedHardware.cpu_model && snapshot.cpu_model) {
      cpuMatched = (reportedHardware.cpu_model === snapshot.cpu_model);
    }
    if (reportedHardware.mac_address && Array.isArray(snapshot.mac_addresses) && snapshot.mac_addresses.length > 0) {
      macMatched = snapshot.mac_addresses.includes(reportedHardware.mac_address);
    }

    const allMatched = hwMatched && cpuMatched && macMatched;

    return {
      valid: allMatched,
      eligible: allMatched,
      matched: allMatched,
      reason: allMatched ? 'HARDWARE_VERIFIED' : 'HARDWARE_MISMATCH',
      hwid: state.hwid,
      activated_at: state.activated_at,
      hardware_snapshot: snapshot,
      message: allMatched
        ? '기기 고유 하드웨어 정보(HWID, CPU, MAC, 활성화 타임스탬프)가 정밀 대조 검증되었습니다.'
        : '신청 기기의 하드웨어 정보가 활성화 당시 박제된 고유 기기 정보와 일치하지 않습니다.'
    };
  }

  /**
   * Hold license in REFUND_PENDING_DEFECT_VERIFICATION instead of permanent REVOKED
   * when customer reports engine defect within 7 days of activation
   */
  markPendingDefectVerification(reason = 'DEFECT_REPORTED_UNDER_7_DAYS') {
    const normReason = (typeof reason === 'string' && reason.trim().length > 0)
      ? reason.trim()
      : (reason && typeof reason === 'object' && typeof reason.reason === 'string' && reason.reason.trim() ? reason.reason.trim() : 'DEFECT_REPORTED_UNDER_7_DAYS');
    const state = this.loadState();
    state.status = 'REFUND_PENDING_DEFECT_VERIFICATION';
    state.pending_defect_at = new Date().toISOString();
    state.pending_defect_reason = normReason;
    state.is_blocked = false;
    state.extension_history = (state.extension_history || []).concat([{
      event: 'REFUND_PENDING_DEFECT_VERIFICATION',
      timestamp: state.pending_defect_at,
      reason: normReason,
      note: '활성화 후 7일 이내 결함 접수 — 관리자 검수 대기 전환 (오탐 매장 마비 방지)'
    }]).slice(-100);
    this.saveState(state);
    this._notifyTelegramAlertSafe(
      'DEFECT_VERIFICATION_PENDING',
      '🛑 [고객 환불/결함 검수 요청] 7일 이내 결함 검수 대기 접수',
      { reason: normReason, hwid: state.hwid || '알 수 없음', pendingAt: state.pending_defect_at }
    );
    return {
      success: true,
      status: 'REFUND_PENDING_DEFECT_VERIFICATION',
      is_blocked: false,
      reason: normReason,
      message: '활성화 후 7일 이내 결함 접수로 관리자 결함 검수 대기(REFUND_PENDING_DEFECT_VERIFICATION) 상태로 전환되었습니다.'
    };
  }

  /**
   * Revoke license upon refund approval and immediately block engine daemon
   */
  revokeLicense(reason = 'REFUND_APPROVED') {
    const normReason = (typeof reason === 'string' && reason.trim().length > 0)
      ? reason.trim()
      : (reason && typeof reason === 'object' && typeof reason.reason === 'string' && reason.reason.trim() ? reason.reason.trim() : 'REFUND_APPROVED');
    const state = this.loadState();
    state.status = 'REVOKED';
    state.revoked_at = new Date().toISOString();
    state.revocation_reason = normReason;
    state.is_blocked = true;
    state.extension_history = (state.extension_history || []).concat([{
      event: 'LICENSE_REVOKED',
      revoked_at: state.revoked_at,
      reason: normReason,
      note: '환불 승인에 따른 라이선스 영구 회수 및 엔진 데몬 즉각 차단'
    }]).slice(-100);

    this.saveState(state);
    this._notifyTelegramAlertSafe(
      'LICENSE_REVOKED',
      '🛑 [고객 환불/결함 검수 완료] 라이선스 영구 회수 및 엔진 차단 완료',
      { reason: normReason, hwid: state.hwid || '알 수 없음', revokedAt: state.revoked_at }
    );

    return {
      success: true,
      status: 'REVOKED',
      revoked_at: state.revoked_at,
      reason: normReason,
      message: '라이선스가 성공적으로 회수(REVOKED) 처리되었으며 엔진 데몬이 즉각 차단되었습니다.'
    };
  }

  /**
   * Plan Upgrade without refund (차액 정산 플랜 전환 규격)
   * 원칙 1: 외부 마켓(Gumroad, 스마트스토어 등)에서는 시스템상 차액 결제 불가.
   * 원칙 2: 상위 플랜 차액 결제 업그레이드는 오직 자사 공식 결제 포털(https://autoflow.io/upgrade)을 통해서만 지원.
   * 원칙 3: 외부 마켓 재구매 희망 시 잔여일 비례 할인 쿠폰 코드 발급.
   */
  upgradeTier(params = {}) {
    params = (params && typeof params === 'object') ? params : {};
    const {
      targetTier = 'MANAGED_ENTERPRISE',
      differenceAmount = 0,
      transactionId = '',
      channel = 'DIRECT',
      portalConfirmed = false
    } = params;
    const state = this.loadState();

    if (state.status !== 'ACTIVE') {
      return {
        success: false,
        error: 'LICENSE_NOT_ACTIVE',
        message: '활성화된 라이선스만 플랜 업그레이드가 가능합니다.'
      };
    }

    const isExternalMarket = [
      'GUMROAD',
      'SMARTSTORE',
      'NAVER_SMARTSTORE',
      'LEMON_SQUEEZY',
      'WHOP',
      'APPSUMO',
      'PADDLE',
      'EXTERNAL_MARKET',
      'EXTERNAL'
    ].includes(String(channel).toUpperCase());
    if (isExternalMarket && !portalConfirmed) {
      const coupon = this.issueMarketDiscountCoupon({ targetTier });
      return {
        success: false,
        error: 'EXTERNAL_MARKET_DIFFERENCE_PAYMENT_UNSUPPORTED',
        official_portal_url: OFFICIAL_UPGRADE_PORTAL,
        legal_basis: '공정거래위원회 약관 규정 및 전자상거래 등에서의 소비자보호에 관한 법률',
        message: '외부 마켓(Gumroad, 스마트스토어 등)에서 구매한 라이선스는 외부 플랫폼 시스템상 차액 결제가 일체 불가합니다. 중도 해지 시에는 공정 환불 규정(접수일 기준 실사용 일할 차감 + 10% 공제 잔여액 정산)이 적용되며, 상위 플랜 차액 결제 업그레이드는 오직 AutoFlow 자사 공식 결제 포털(https://autoflow.io/upgrade)을 통해서만 지원됩니다.',
        coupon_option: coupon
      };
    }

    const prevTier = state.tier;
    state.tier = targetTier;
    state.tier_upgrade_history = state.tier_upgrade_history || [];
    state.tier_upgrade_history.push({
      from_tier: prevTier,
      to_tier: targetTier,
      upgraded_at: new Date().toISOString(),
      difference_amount: differenceAmount,
      transaction_id: transactionId,
      channel: channel || 'DIRECT',
      official_portal_url: OFFICIAL_UPGRADE_PORTAL
    });

    this.saveState(state);

    return {
      success: true,
      previous_tier: prevTier,
      current_tier: targetTier,
      official_portal_url: OFFICIAL_UPGRADE_PORTAL,
      upgraded_at: new Date().toISOString(),
      message: `성공적으로 ${targetTier} 플랜으로 자사 공식 포털(${OFFICIAL_UPGRADE_PORTAL})을 통해 차액 전환되었습니다.`
    };
  }

  /**
   * 외부 마켓 재구매 희망 고객용 상위 플랜 잔여일 비례 할인 쿠폰 코드 발급
   */
  issueMarketDiscountCoupon(params = {}) {
    params = (params && typeof params === 'object') ? params : {};
    const { targetTier = 'MANAGED_ENTERPRISE' } = params;
    const status = this.getStatus();
    const daysLeft = status.days_left || 0;

    let discountRate = 10;
    if (daysLeft > 0) {
      discountRate = Math.min(50, Math.max(10, Math.round((daysLeft / 365) * 50)));
    }

    const couponCode = `AF-UPGRADE-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    return {
      coupon_code: couponCode,
      target_tier: targetTier,
      discount_rate_percent: discountRate,
      remaining_days: daysLeft,
      valid_days: 7,
      official_portal_url: OFFICIAL_UPGRADE_PORTAL,
      message: '외부 마켓 재구매를 원하는 고객에게 기존 구매 인증에 따른 상위 플랜 잔여일 비례 할인 쿠폰 코드가 발급되었습니다.'
    };
  }

  /**
   * Evaluate refund eligibility using Fair Prorated Settlement Engine
   */
  checkRefundEligibility(params = {}) {
    params = (params && typeof params === 'object') ? params : {};
    return this.calculateFairRefund(params);
  }

  /**
   * Record server telemetry heartbeat ping acknowledgement
   * Resets offline grace period timer and resumes engine if previously locked under OFFLINE_GRACE_EXPIRED
   */
  recordHeartbeatAck(ackTimestamp = new Date().toISOString()) {
    const normAck = (typeof ackTimestamp === 'string' && ackTimestamp.trim().length > 0)
      ? ackTimestamp.trim()
      : (ackTimestamp && typeof ackTimestamp === 'object' && typeof ackTimestamp.ackTimestamp === 'string' && ackTimestamp.ackTimestamp.trim()
        ? ackTimestamp.ackTimestamp.trim()
        : new Date().toISOString());
    const state = this.loadState();
    state.last_heartbeat_ack = normAck;
    if (state.status === 'OFFLINE_GRACE_EXPIRED') {
      const now = Date.now();
      const expiryMs = state.valid_until ? new Date(state.valid_until).getTime() : 0;
      if (expiryMs > now) {
        state.status = 'ACTIVE';
        console.log(`[LicenseManager] 🟢 Server heartbeat ACK recorded (${normAck}). Offline grace lock cleared.`);
      }
    }
    this.saveState(state);
    return {
      success: true,
      status: state.status,
      last_heartbeat_ack: state.last_heartbeat_ack
    };
  }

  /**
   * Detailed status inspection
   */
  getStatus() {
    const state = this.loadState();
    const cyberDeceptionSentinel = require('./cyber_deception_tarpit_sentinel');
    const currentHwid = state.hwid || this._calculateLocalHwid();
    if (
      state.status === 'DECEPTION_TARPIT_QUARANTINE' ||
      state.deception_trap_triggered === true ||
      cyberDeceptionSentinel.isHwidBlacklisted(currentHwid)
    ) {
      return {
        status: 'DECEPTION_TARPIT_QUARANTINE',
        is_blocked: true,
        is_expired: true,
        deception_trap_triggered: true,
        tarpit_active: true,
        deception_trigger_type: state.deception_trigger_type || 'CANARY_HONEYTOKEN_TRIGGER',
        deception_forensic_hmac: state.deception_forensic_hmac || null,
        tier: state.tier || 'BYOK_LITE',
        hwid: currentHwid,
        license_key: state.license_key,
        message: '4단계 사이버 기만 방어(Canary Honeytoken Trap) 격리 상태입니다. 거버너 엔진 및 데몬 가동이 차단되었습니다.'
      };
    }

    if (state.status === 'REVOKED') {
      return {
        status: 'REVOKED',
        is_blocked: true,
        revoked_at: state.revoked_at,
        revocation_reason: state.revocation_reason || 'REFUND_REVOKED',
        tier: state.tier || 'BYOK_LITE',
        hwid: state.hwid || this._calculateLocalHwid(),
        license_key: state.license_key,
        message: '환불 승인에 따라 원격 회수(REVOKED)된 라이선스입니다. 데몬 가동이 차단되었습니다.'
      };
    }

    const now = Date.now();
    const expiryMs = state.valid_until ? new Date(state.valid_until).getTime() : 0;
    const diffMs = expiryMs - now;
    const daysLeft = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
    const isExpired = state.valid_until ? diffMs <= 0 : false;

    if (state.status === 'PENDING_ACTIVATION') {
      return {
        status: 'PENDING_ACTIVATION',
        tier: state.tier || 'BYOK_LITE',
        hwid: state.hwid || this._calculateLocalHwid(),
        license_key: state.license_key,
        days_left: 0,
        refund_policy: 'FAIR_PRORATED_SETTLEMENT',
        refund_ineligible: false,
        legal_basis: '공정거래위원회 표준약관 및 전자상거래 등에서의 소비자보호에 관한 법률'
      };
    }

    if (isExpired) {
      return {
        status: 'EXPIRED',
        is_blocked: true,
        tier: state.tier || 'BYOK_LITE',
        hwid: state.hwid || this._calculateLocalHwid(),
        license_key: state.license_key,
        activated_at: state.activated_at,
        valid_until: state.valid_until,
        days_left: 0,
        refund_policy: 'FAIR_PRORATED_SETTLEMENT',
        refund_ineligible: false,
        legal_basis: '공정거래위원회 표준약관 및 전자상거래 등에서의 소비자보호에 관한 법률'
      };
    }

    // 72시간 오프라인 유예 만료 검사 (환불 후 오프라인 먹튀 및 비정상 탈취 원천 방어)
    const lastAckTime = state.last_heartbeat_ack || state.activated_at;
    let isGraceExpired = false;
    let offlineHours = 0;
    if (lastAckTime) {
      const elapsedSincePing = now - new Date(lastAckTime).getTime();
      offlineHours = Math.floor(elapsedSincePing / (1000 * 3600));
      if (elapsedSincePing > OFFLINE_GRACE_PERIOD_MS) {
        isGraceExpired = true;
      }
    }

    if (isGraceExpired || state.status === 'OFFLINE_GRACE_EXPIRED') {
      return {
        status: 'OFFLINE_GRACE_EXPIRED',
        is_blocked: true,
        tier: state.tier || 'BYOK_LITE',
        hwid: state.hwid || this._calculateLocalHwid(),
        license_key: state.license_key,
        activated_at: state.activated_at,
        valid_until: state.valid_until,
        last_heartbeat_ack: state.last_heartbeat_ack,
        offline_hours: offlineHours,
        max_grace_hours: 72,
        days_left: daysLeft,
        refund_policy: 'FAIR_PRORATED_SETTLEMENT',
        refund_ineligible: false,
        message: '오프라인 최대 허용 유예 기간(72시간)이 만료되어 엔진 보호를 위해 일시정지되었습니다. 인터넷 연결 및 텔레메트리 서버 동기화 후 자동 재개됩니다.',
        legal_basis: '공정거래위원회 표준약관 및 전자상거래 등에서의 소비자보호에 관한 법률'
      };
    }

    return {
      status: state.status === 'REFUND_PENDING_DEFECT_VERIFICATION' ? 'REFUND_PENDING_DEFECT_VERIFICATION' : 'ACTIVE',
      is_blocked: false,
      tier: state.tier || 'BYOK_LITE',
      hwid: state.hwid || this._calculateLocalHwid(),
      license_key: state.license_key,
      activated_at: state.activated_at,
      valid_until: state.valid_until,
      last_heartbeat_ack: state.last_heartbeat_ack || state.activated_at,
      days_left: daysLeft,
      enabled_modules: state.enabled_modules || null,
      selected_modules: state.selected_modules || [],
      workflow_sku: state.workflow_sku || null,
      refund_policy: 'FAIR_PRORATED_SETTLEMENT',
      refund_ineligible: false,
      legal_basis: '공정거래위원회 표준약관 및 전자상거래 등에서의 소비자보호에 관한 법률'
    };
  }

  /**
   * 1단계 진입: 워크플로우 단품(9,900 / 19,000 / 29,000원) 영구 소장 + 7일 전체 엔진 모듈(A+B) 무료 테스트 활성화
   * 1:1 Device HWID 기기 종속 바인딩 유지
   */
  activateWorkflowWith7DayTrial(params = {}) {
    params = (params && typeof params === 'object') ? params : {};
    const rawSku = String(params.workflowSku || params.sku || 'WF_STANDARD').toUpperCase();
    const workflowSku = ['WF_ENTRY', 'WF_STANDARD', 'WF_COMPLEX'].includes(rawSku) ? rawSku : 'WF_STANDARD';
    const price = MODULAR_PRICING_SSOT[workflowSku] || 19000;
    const hwid = params.hwid || this._calculateLocalHwid();
    const licenseKey = String(params.licenseKey || params.license_key || `AF-${workflowSku}-7D-TRIAL`).trim();
    const aiMode = String(params.aiMode || params.ai_mode || 'MANAGED').toUpperCase();
    const trialDays = 7;

    const now = new Date();
    const expiry = new Date(now.getTime() + trialDays * 24 * 60 * 60 * 1000);
    const hwSnapshot = this.getHardwareSnapshot();
    const enabledModules = {
      self_healing: true,
      ai_mode: aiMode === 'BYOK' ? 'BYOK' : 'MANAGED',
      branch_reconciliation: true,
      trial_all_modules: true
    };

    const currentState = this.loadState();
    const updatedState = {
      ...currentState,
      license_key: licenseKey,
      hwid,
      hardware_snapshot: hwSnapshot,
      device_bound: true,
      tier: 'TRIAL_7D_ALL_MODULES',
      workflow_sku: workflowSku,
      workflow_price: price,
      workflow_perpetual_owned: true,
      enabled_modules: enabledModules,
      selected_modules: ['MODULE_A2_MANAGED_AI', 'MODULE_B_BRANCH_RECON'],
      status: 'ACTIVE',
      activated_at: now.toISOString(),
      last_heartbeat_ack: now.toISOString(),
      valid_until: expiry.toISOString(),
      duration_days: trialDays,
      total_paid: price,
      total_extended_days: (currentState.total_extended_days || 0) + trialDays,
      refund_policy: 'FAIR_PRORATED_SETTLEMENT',
      refund_ineligible: false,
      extension_history: [
        ...(currentState.extension_history || []),
        {
          event: 'WORKFLOW_PURCHASE_WITH_7D_ALL_MODULES_TRIAL',
          workflow_sku: workflowSku,
          workflow_price: price,
          hwid,
          activated_at: now.toISOString(),
          trial_days: trialDays,
          enabled_modules: enabledModules,
          note: `${workflowSku}(₩${price.toLocaleString()}) 영구 소장 + 7일 전체 엔진 모듈(A+B) 무료 테스트 활성화`
        }
      ].slice(-100)
    };

    this.saveState(updatedState);

    return {
      success: true,
      status: 'ACTIVE',
      tier: 'TRIAL_7D_ALL_MODULES',
      workflow_sku: workflowSku,
      workflow_price: price,
      workflow_perpetual_owned: true,
      trial_days: trialDays,
      hwid,
      device_bound: true,
      enabled_modules: enabledModules,
      activated_at: updatedState.activated_at,
      valid_until: updatedState.valid_until,
      message: `워크플로우 단품(${workflowSku}, ₩${price.toLocaleString()}) 영구 소장 및 7일 전체 엔진 모듈(자가치유 + 분기 정합성) 무료 테스트가 활성화되었습니다.`
    };
  }

  /**
   * 2단계 연장: 필요한 엔진 모듈만 골라 담는(Modular Pick) 독립 활성화 및 기간별(7일/30일/90일/365일) 가격 정산
   * 1:1 Device HWID 기기 종속 바인딩 유지
   */
  configureModularSubscription(params = {}) {
    params = (params && typeof params === 'object') ? params : {};
    const hwid = params.hwid || this._calculateLocalHwid();
    const rawPeriod = params.period || params.durationDays || params.duration_days || 30;
    let periodKey = 'd30';
    let durationDays = 30;

    if (rawPeriod === 'd7' || Number(rawPeriod) === 7) {
      periodKey = 'd7';
      durationDays = 7;
    } else if (rawPeriod === 'd90' || Number(rawPeriod) === 90) {
      periodKey = 'd90';
      durationDays = 90;
    } else if (rawPeriod === 'd365' || Number(rawPeriod) === 365) {
      periodKey = 'd365';
      durationDays = 365;
    }

    const inputModules = Array.isArray(params.modules) ? params.modules.map(m => String(m).toUpperCase()) : [];
    const reqAiMode = String(params.ai_mode || params.aiMode || '').toUpperCase();

    let hasA2 = inputModules.some(m => m.includes('A2') || m.includes('MANAGED'));
    let hasA1 = !hasA2 && inputModules.some(m => m.includes('A1') || m.includes('BYOK') || m === 'MODULE_A');
    let hasB = inputModules.some(m => (m.includes('MODULE_B') || m === 'B' || m.includes('RECON')));

    if (params.self_healing === true || params.selfHealing === true) {
      if (reqAiMode === 'MANAGED') {
        hasA2 = true;
        hasA1 = false;
      } else if (!hasA2) {
        hasA1 = true;
      }
    }
    if (params.branch_reconciliation === true || params.branchReconciliation === true) {
      hasB = true;
    }

    const selectedModules = [];
    let totalPrice = 0;

    if (hasA2) {
      selectedModules.push('MODULE_A2_MANAGED_AI');
      totalPrice += MODULAR_PRICING_SSOT.MODULE_A2_MANAGED_AI[periodKey];
    } else if (hasA1) {
      selectedModules.push('MODULE_A1_BYOK');
      totalPrice += MODULAR_PRICING_SSOT.MODULE_A1_BYOK[periodKey];
    }

    if (hasB) {
      selectedModules.push('MODULE_B_BRANCH_RECON');
      totalPrice += MODULAR_PRICING_SSOT.MODULE_B_BRANCH_RECON[periodKey];
    }

    const enabledModules = {
      self_healing: Boolean(hasA1 || hasA2),
      ai_mode: hasA2 ? 'MANAGED' : (hasA1 ? 'BYOK' : 'NONE'),
      branch_reconciliation: Boolean(hasB)
    };

    const effectiveTier = hasA2 ? 'MANAGED_PRO' : 'BYOK_LITE';
    const now = new Date();
    const expiry = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000);
    const hwSnapshot = this.getHardwareSnapshot();
    const currentState = this.loadState();

    const updatedState = {
      ...currentState,
      license_key: String(params.licenseKey || params.license_key || currentState.license_key || `AF-MOD-${periodKey.toUpperCase()}`).trim(),
      hwid,
      hardware_snapshot: hwSnapshot,
      device_bound: true,
      tier: effectiveTier,
      selected_modules: selectedModules,
      enabled_modules: enabledModules,
      status: 'ACTIVE',
      activated_at: now.toISOString(),
      last_heartbeat_ack: now.toISOString(),
      valid_until: expiry.toISOString(),
      duration_days: durationDays,
      total_paid: totalPrice,
      total_extended_days: (currentState.total_extended_days || 0) + durationDays,
      refund_policy: 'FAIR_PRORATED_SETTLEMENT',
      refund_ineligible: false,
      extension_history: [
        ...(currentState.extension_history || []),
        {
          event: 'MODULAR_SUBSCRIPTION_CONFIGURED',
          selected_modules: selectedModules,
          enabled_modules: enabledModules,
          period_key: periodKey,
          duration_days: durationDays,
          total_price: totalPrice,
          hwid,
          configured_at: now.toISOString()
        }
      ].slice(-100)
    };

    this.saveState(updatedState);

    return {
      success: true,
      status: 'ACTIVE',
      tier: effectiveTier,
      hwid,
      device_bound: true,
      period_key: periodKey,
      duration_days: durationDays,
      selected_modules: selectedModules,
      enabled_modules: enabledModules,
      total_price: totalPrice,
      activated_at: updatedState.activated_at,
      valid_until: updatedState.valid_until,
      message: `선택하신 모듈(${selectedModules.join(' + ') || '없음'}, ${durationDays}일권, ₩${totalPrice.toLocaleString()})이 현재 PC(${hwid})에 활성화되었습니다.`
    };
  }

  /**
   * 모듈별 독립 권한 게이트(Entitlement Check) 및 7일 무료 테스트 종료 후 워크플로우 영구 가동 보장(Graceful Static Mode)
   * @param {string} moduleKey 'MODULE_A1_BYOK' | 'MODULE_A2_MANAGED_AI' | 'MODULE_B_BRANCH_RECON' | 'SELF_HEALING' | 'BRANCH_RECON'
   */
  checkModuleEntitlement(moduleKey = 'SELF_HEALING') {
    const normKey = String(moduleKey || 'SELF_HEALING').toUpperCase().trim();
    const state = this.loadState();
    const nowMs = Date.now();
    const validUntilMs = state.valid_until ? new Date(state.valid_until).getTime() : 0;
    const isExpired = validUntilMs > 0 && nowMs > validUntilMs;
    const isRevoked = state.status === 'REVOKED' || state.is_blocked === true;
    const workflowPerpetualOwned = state.workflow_perpetual_owned !== false;

    if (isRevoked) {
      return {
        entitled: false,
        module_key: normKey,
        status: 'REVOKED',
        tier: state.tier || 'NONE',
        workflow_perpetual_active: false,
        graceful_static_mode: false,
        reason: 'LICENSE_REVOKED_OR_BLOCKED',
        guidance_ko: '라이선스가 해지(REVOKED) 또는 차단 상태입니다. 공식 스토어에서 라이선스 상태를 확인해 주십시오.'
      };
    }

    if (isExpired) {
      return {
        entitled: false,
        module_key: normKey,
        status: 'EXPIRED_MODULES_ONLY',
        tier: state.tier || 'TRIAL_7D_ALL_MODULES',
        workflow_sku: state.workflow_sku || 'WF_STANDARD',
        workflow_perpetual_owned: workflowPerpetualOwned,
        workflow_perpetual_active: true,
        graceful_static_mode: true,
        reason: 'MODULE_TRIAL_OR_SUBSCRIPTION_EXPIRED',
        recommended_checkout_url: '/checkout.html?period=d30',
        guidance_ko: `7일 전체 엔진 모듈 무료 테스트(또는 모듈 구독 기간)가 종료되어 [${normKey}] 부가 엔진 기능만 대기 모드로 전환되었습니다. 구매하신 워크플로우 단품은 영구 소장 상태이므로 24시간 중단 없이 정상 가동됩니다. 필요한 모듈만 골라 연장하시려면 /checkout.html 에서 선택해 주십시오.`
      };
    }

    const em = state.enabled_modules || {
      self_healing: true,
      ai_mode: state.tier === 'BYOK_LITE' ? 'BYOK' : 'MANAGED',
      branch_reconciliation: state.tier === 'TRIAL_7D_ALL_MODULES' || state.tier === 'MANAGED_PRO' || state.tier === 'MANAGED_ENTERPRISE'
    };
    const selected = Array.isArray(state.selected_modules) ? state.selected_modules : [];

    let entitled = false;
    if (normKey === 'SELF_HEALING' || normKey === 'MODULE_A1_BYOK' || normKey === 'MODULE_A') {
      entitled = Boolean(em.self_healing);
    } else if (normKey === 'MODULE_A2_MANAGED_AI') {
      entitled = Boolean(em.self_healing && (em.ai_mode === 'MANAGED' || selected.includes('MODULE_A2_MANAGED_AI') || state.tier === 'TRIAL_7D_ALL_MODULES'));
    } else if (normKey === 'BRANCH_RECON' || normKey === 'MODULE_B_BRANCH_RECON' || normKey === 'MODULE_B') {
      entitled = Boolean(em.branch_reconciliation);
    } else {
      entitled = Boolean(em.self_healing || em.branch_reconciliation);
    }

    if (!entitled) {
      return {
        entitled: false,
        module_key: normKey,
        status: state.status || 'ACTIVE',
        tier: state.tier || 'BYOK_LITE',
        workflow_sku: state.workflow_sku || 'WF_STANDARD',
        workflow_perpetual_owned: workflowPerpetualOwned,
        workflow_perpetual_active: true,
        graceful_static_mode: true,
        reason: 'MODULE_NOT_IN_ACTIVE_PICK',
        recommended_checkout_url: `/checkout.html?modules=${encodeURIComponent(normKey)}&period=d30`,
        guidance_ko: `현재 구독 구성에 [${normKey}] 모듈이 포함되어 있지 않아 해당 부가 엔진만 비활성화 상태입니다. 기본 워크플로우는 영구 소장 상태로 24시간 정상 작동 중이며, 해당 모듈 추가를 원하시면 /checkout.html 에서 언제든 골라 담으실 수 있습니다.`
      };
    }

    return {
      entitled: true,
      module_key: normKey,
      status: state.status || 'ACTIVE',
      tier: state.tier || 'TRIAL_7D_ALL_MODULES',
      workflow_sku: state.workflow_sku || 'WF_STANDARD',
      workflow_perpetual_owned: workflowPerpetualOwned,
      workflow_perpetual_active: true,
      graceful_static_mode: false,
      enabled_modules: em,
      selected_modules: selected,
      guidance_ko: `[${normKey}] 엔진 모듈이 정상 활성화되어 실시간 보호 중입니다.`
    };
  }

  /**
   * 7일 무료 테스트(및 운영 기간) 동안 각 모듈이 실제로 방어/수리한 실적을 카운팅 기록
   * @param {string} eventType 'MODULE_A_HEAL' | 'MODULE_A2_AI_REPAIR' | 'MODULE_B_QUORUM_DIFF' | 'MOD_P_FEE_OVERCHARGE_ISOLATED' | 'MOD_Q_TARIFF_DUTY_ISOLATED'
   * @param {object} detail
   */
  recordModuleUsageEvent(eventType, detail = {}) {
    const rawDetail = (detail && typeof detail === 'object' && !Array.isArray(detail)) ? detail : {};
    const normEvent = String(eventType || 'MODULE_A_HEAL').toUpperCase().trim().replace(/[\s-]+/g, '_');
    const state = this.loadState();
    const prev = state.trial_usage_stats || {
      module_a_heals: 0,
      module_a2_ai_repairs: 0,
      module_b_quorum_diffs: 0,
      mod_p_fee_overcharge_isolations: 0,
      mod_q_tariff_duty_isolations: 0,
      original_data_preserved_count: 0,
      protected_amount_krw: 0,
      saved_incidents: 0,
      last_event_at: null
    };

    const stats = {
      module_a_heals: Number(prev.module_a_heals || 0),
      module_a2_ai_repairs: Number(prev.module_a2_ai_repairs || 0),
      module_b_quorum_diffs: Number(prev.module_b_quorum_diffs || 0),
      mod_p_fee_overcharge_isolations: Number(prev.mod_p_fee_overcharge_isolations || 0),
      mod_q_tariff_duty_isolations: Number(prev.mod_q_tariff_duty_isolations || 0),
      original_data_preserved_count: Number(prev.original_data_preserved_count || 0),
      protected_amount_krw: Number(prev.protected_amount_krw || 0),
      saved_incidents: Number(prev.saved_incidents || 0),
      last_event_at: new Date().toISOString()
    };

    const protectedDelta = Number(rawDetail.protected_amount_krw ?? rawDetail.amount ?? 49000);

    if (normEvent === 'MODULE_A2_AI_REPAIR' || normEvent === 'MOD_A2_CENTRAL_AI' || normEvent === 'MOD_A2_HQ_FINETUNE_BOT') {
      stats.module_a2_ai_repairs += 1;
      stats.module_a_heals += 1;
    } else if (
      normEvent === 'MOD_P_FEE_OVERCHARGE_ISOLATED' ||
      normEvent === 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD' ||
      normEvent === 'MOD_P' ||
      normEvent === 'FEE_OVERCHARGE_ISOLATED'
    ) {
      stats.mod_p_fee_overcharge_isolations += 1;
      stats.original_data_preserved_count += 1;
      stats.module_b_quorum_diffs += 1;
    } else if (
      normEvent === 'MOD_Q_TARIFF_DUTY_ISOLATED' ||
      normEvent === 'MOD_Q_HS_TARIFF_DUTY_GUARD' ||
      normEvent === 'MOD_Q' ||
      normEvent === 'TARIFF_DUTY_ISOLATED'
    ) {
      stats.mod_q_tariff_duty_isolations += 1;
      stats.original_data_preserved_count += 1;
      stats.module_b_quorum_diffs += 1;
    } else if (normEvent === 'MODULE_B_QUORUM_DIFF' || normEvent === 'MOD_B1_QUORUM_RECON' || normEvent === 'MOD_B_RECON_ENGINE') {
      stats.module_b_quorum_diffs += 1;
      stats.original_data_preserved_count += 1;
    } else {
      stats.module_a_heals += 1;
    }

    stats.saved_incidents += 1;
    if (Number.isFinite(protectedDelta) && protectedDelta > 0) {
      stats.protected_amount_krw += protectedDelta;
    }

    const updatedState = {
      ...state,
      trial_usage_stats: stats
    };
    this.saveState(updatedState);

    return {
      success: true,
      event_type: normEvent,
      original_data_preserved: true,
      auto_mutated: false,
      trial_usage_stats: stats
    };
  }

  /**
   * 7일 무료 테스트 ‘실적 성적표(Trial Value Scorecard)’ 및 맞춤형 모듈 추천(Modular Pick Recommendation) 산출
   */
  getTrialScorecardAndRecommendation() {
    const state = this.loadState();
    const rawStats = state.trial_usage_stats || {};
    const stats = {
      module_a_heals: Number(rawStats.module_a_heals || 0),
      module_a2_ai_repairs: Number(rawStats.module_a2_ai_repairs || 0),
      module_b_quorum_diffs: Number(rawStats.module_b_quorum_diffs || 0),
      mod_p_fee_overcharge_isolations: Number(rawStats.mod_p_fee_overcharge_isolations || 0),
      mod_q_tariff_duty_isolations: Number(rawStats.mod_q_tariff_duty_isolations || 0),
      original_data_preserved_count: Number(rawStats.original_data_preserved_count || 0),
      protected_amount_krw: Number(rawStats.protected_amount_krw || 0),
      saved_incidents: Number(rawStats.saved_incidents || 0),
      last_event_at: rawStats.last_event_at || null
    };

    const aHeals = stats.module_a_heals;
    const a2Repairs = stats.module_a2_ai_repairs;
    const bDiffs = stats.module_b_quorum_diffs;
    const modPIsolations = stats.mod_p_fee_overcharge_isolations;
    const modQIsolations = stats.mod_q_tariff_duty_isolations;
    const preservedCount = stats.original_data_preserved_count;
    const protectedKrw = stats.protected_amount_krw;

    let recommendedModules = [];
    let recommendedPriceD30 = 0;

    if ((aHeals > 0 || a2Repairs > 0) && bDiffs > 0) {
      if (a2Repairs > 0) {
        recommendedModules = ['MODULE_A2_MANAGED_AI', 'MODULE_B_BRANCH_RECON'];
        recommendedPriceD30 = MODULAR_PRICING_SSOT.MODULE_A2_MANAGED_AI.d30 + MODULAR_PRICING_SSOT.MODULE_B_BRANCH_RECON.d30;
      } else {
        recommendedModules = ['MODULE_A1_BYOK', 'MODULE_B_BRANCH_RECON'];
        recommendedPriceD30 = MODULAR_PRICING_SSOT.MODULE_A1_BYOK.d30 + MODULAR_PRICING_SSOT.MODULE_B_BRANCH_RECON.d30;
      }
    } else if (bDiffs > 0 && aHeals === 0 && a2Repairs === 0) {
      recommendedModules = ['MODULE_B_BRANCH_RECON'];
      recommendedPriceD30 = MODULAR_PRICING_SSOT.MODULE_B_BRANCH_RECON.d30;
    } else if (a2Repairs > 0) {
      recommendedModules = ['MODULE_A2_MANAGED_AI'];
      recommendedPriceD30 = MODULAR_PRICING_SSOT.MODULE_A2_MANAGED_AI.d30;
    } else {
      recommendedModules = ['MODULE_A1_BYOK'];
      recommendedPriceD30 = MODULAR_PRICING_SSOT.MODULE_A1_BYOK.d30;
    }

    const granularSet = new Set();
    if (aHeals > 0 || recommendedModules.includes('MODULE_A1_BYOK') || recommendedModules.includes('MODULE_A2_MANAGED_AI')) {
      granularSet.add('MOD_A1_LOCAL_HEALER');
    }
    if (a2Repairs > 0 || recommendedModules.includes('MODULE_A2_MANAGED_AI')) {
      granularSet.add('MOD_A2_HQ_FINETUNE_BOT');
    }
    if (bDiffs > 0 || recommendedModules.includes('MODULE_B_BRANCH_RECON')) {
      granularSet.add('MOD_B_RECON_ENGINE');
      granularSet.add('MOD_H_DRIFTFLOW_RADAR');
    }
    if (modPIsolations > 0) {
      granularSet.add('MOD_I_PROFITFLOW_GUARD');
      granularSet.add('MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD');
    }
    if (modQIsolations > 0) {
      granularSet.add('MOD_J_CUSTOMS_CLEARANCE');
      granularSet.add('MOD_Q_HS_TARIFF_DUTY_GUARD');
    }

    const recommendedGranularModules = Array.from(granularSet);
    const recommendedGranularBitmask = this._resolveBitmaskFromParams({ modules: recommendedGranularModules });

    const moduleParam = recommendedModules.join(',');
    const granularModuleParam = recommendedGranularModules.join(',');
    const checkoutUrl = `/checkout.html?modules=${encodeURIComponent(moduleParam)}&bitmask=${recommendedGranularBitmask}&period=d30`;
    const granularCheckoutUrl = `/checkout.html?bitmask=${recommendedGranularBitmask}&modules=${encodeURIComponent(granularModuleParam)}&period=d30`;
    const feeTariffNote = (modPIsolations > 0 || modQIsolations > 0)
      ? ` (오픈마켓 수수료 과다차감 격리 ${modPIsolations}건 · 수출입 HS 관세율 괴리 격리 ${modQIsolations}건 · 원본 비변조 보존 ${preservedCount}건 포함)`
      : '';
    const summaryKo =
      `지난 테스트 기간 동안 자가치유 엔진(모듈 A)이 ${aHeals}건(AI 코드 수리 ${a2Repairs}건 포함)의 장애를 자동 복구하고, ` +
      `다중 분기 정합성 엔진(모듈 B)이 ${bDiffs}건의 분기 데이터 불일치(보호 정산액 약 ${protectedKrw.toLocaleString()}원)${feeTariffNote}를 원본 변조 없이 사내 PC에 안전 격리하여 막아냈습니다. ` +
      `사장님 사업장에는 [${recommendedModules.join(' + ')}] 구성을 추천합니다 (실시간 금액은 공식 결제 페이지에서 확인).`;

    return {
      success: true,
      tier: state.tier || 'TRIAL_7D_ALL_MODULES',
      workflow_sku: state.workflow_sku || 'WF_STANDARD',
      workflow_perpetual_owned: state.workflow_perpetual_owned !== false,
      trial_usage_stats: stats,
      recommended_modules: recommendedModules,
      recommended_granular_modules: recommendedGranularModules,
      recommended_granular_bitmask: recommendedGranularBitmask,
      recommended_period: 'd30',
      recommended_price_d30: recommendedPriceD30,
      recommended_checkout_url: checkoutUrl,
      recommended_granular_checkout_url: granularCheckoutUrl,
      dashboard_price_display_allowed: false,
      zero_silent_mutation_verified: true,
      dual_channel_alert_ready: true,
      summary_ko: summaryKo
    };
  }

  /**
   * Resolves a bitmask (0..1023+) from either a numeric bitmask or an array of module codes/aliases
   */
  _resolveBitmaskFromParams(rawParams = {}) {
    const params = (rawParams && typeof rawParams === 'object' && !Array.isArray(rawParams)) ? rawParams : {};
    if (typeof params.bitmask === 'number' && !Number.isNaN(params.bitmask) && Number.isFinite(params.bitmask)) {
      return Math.max(0, Math.floor(params.bitmask));
    }

    const inputList = Array.isArray(params.modules)
      ? params.modules
      : (Array.isArray(params.enabledModules) ? params.enabledModules : null);

    if (Array.isArray(inputList)) {
      let mask = 0;
      const allEntries = [
        ...Object.values(MODULAR_ENGINE_CATALOG),
        ...Object.values(OTA_HOTPLUG_MODULE_TEMPLATES),
        ...Array.from(this.dynamicMcpRegistry.values())
      ];
      for (const rawCode of inputList) {
        const code = String(rawCode || '').trim().toUpperCase().replace(/[\s-]+/g, '_');
        if (!code) continue;
        if (code === 'ALL' || code === '*') {
          for (const entry of allEntries) {
            mask |= entry.bitmask;
          }
          continue;
        }
        for (const entry of allEntries) {
          if (
            entry.code === code ||
            entry.legacyAlias === code ||
            (entry.mcpToolName && entry.mcpToolName.toUpperCase() === String(rawCode || '').trim().toUpperCase()) ||
            ((code === 'MOD_A1' || code === 'MOD_A' || code === 'MODULE_A' || code === 'MOD_A_SELF_HEALING') && entry.code === 'MOD_A1_LOCAL_HEALER') ||
            ((code === 'MOD_A2' || code === 'MOD_A' || code === 'MODULE_A' || code === 'MOD_A_SELF_HEALING') && entry.code === 'MOD_A2_HQ_FINETUNE_BOT') ||
            ((code === 'MOD_B' || code === 'MODULE_B' || code === 'MOD_B_RECONCILIATION') && entry.code === 'MOD_B_RECON_ENGINE') ||
            ((code === 'MOD_C' || code === 'MODULE_C' || code === 'MOD_C_RESELLER_SHIELD') && entry.code === 'MOD_C_PACE_DEDUP') ||
            ((code === 'MOD_D' || code === 'MOD_D_PII_COMPLIANCE') && entry.code === 'MOD_D_COMPLIANCE_PII') ||
            ((code === 'MOD_E' || code === 'MOD_E_TIMELINE_REPLAY') && entry.code === 'MOD_E_BLACKBOX_REPLAY') ||
            ((code === 'MOD_F' || code === 'MOD_F_SANDBOX_SIM') && entry.code === 'MOD_F_SIMFLOW_SANDBOX') ||
            ((code === 'MOD_G' || code === 'MOD_G_KEY_ROTATOR') && entry.code === 'MOD_G_KEYFLOW_ROTATOR') ||
            ((code === 'MOD_H' || code === 'MOD_H_DRIFT_RADAR') && entry.code === 'MOD_H_DRIFTFLOW_RADAR') ||
            ((code === 'MOD_I' || code === 'MOD_I_MARGIN_GUARD') && entry.code === 'MOD_I_PROFITFLOW_GUARD') ||
            ((code === 'MOD_J' || code === 'MOD_J_CUSTOMS_GUARD') && entry.code === 'MOD_J_CUSTOMS_CLEARANCE') ||
            (code === 'MOD_K' && entry.code === 'MOD_K_GLOBAL_FX_SETTLEMENT') ||
            (code === 'MOD_L' && entry.code === 'MOD_L_COLDCHAIN_LOT_GUARD') ||
            (code === 'MOD_M' && entry.code === 'MOD_M_B2B_CREDIT_LIMIT_GUARD') ||
            (code === 'MOD_N' && entry.code === 'MOD_N_RETURN_FRAUD_CLAIM_RADAR') ||
            (code === 'MOD_O' && entry.code === 'MOD_O_PHARMA_NARCOTICS_SERIAL_GUARD') ||
            (code === 'MOD_P' && entry.code === 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD') ||
            (code === 'MOD_Q' && entry.code === 'MOD_Q_HS_TARIFF_DUTY_GUARD')
          ) {
            mask |= entry.bitmask;
          }
        }
      }
      return mask;
    }

    return 1023;
  }

  /**
   * Returns the currently active module bitmask (0..1023)
   */
  getActiveModuleBitmask() {
    const state = this.loadState();
    if (
      state &&
      state.module_ticket_expires_at &&
      !Number.isNaN(new Date(state.module_ticket_expires_at).getTime()) &&
      new Date(state.module_ticket_expires_at).getTime() < Date.now()
    ) {
      this.activeModuleBitmask = 0;
      return 0;
    }
    if (typeof this.activeModuleBitmask === 'number' && !Number.isNaN(this.activeModuleBitmask)) {
      return this.activeModuleBitmask;
    }
    if (typeof state.active_module_bitmask === 'number' && !Number.isNaN(state.active_module_bitmask)) {
      this.activeModuleBitmask = state.active_module_bitmask;
      return state.active_module_bitmask;
    }
    return 1023;
  }

  /**
   * Issues an HMAC-SHA256 signed Module Bitmask Ticket (1-second instant unlock without redownloading)
   */
  issueSignedModuleTicket(rawParams = {}) {
    const params = (rawParams && typeof rawParams === 'object' && !Array.isArray(rawParams)) ? rawParams : {};
    const bitmask = this._resolveBitmaskFromParams(params);
    const ticketId = String(
      params.ticketId || `TKT-${Date.now()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`
    );
    const validDays = (typeof params.validDays === 'number' && !Number.isNaN(params.validDays) && params.validDays > 0)
      ? params.validDays
      : 30;
    const paidAmountKrw = (typeof params.paidAmountKrw === 'number' && !Number.isNaN(params.paidAmountKrw))
      ? params.paidAmountKrw
      : 29000;
    const purchaseChannel = String(params.purchaseChannel || 'NAVER_SMARTSTORE').toUpperCase();
    const customerId = String(params.customerId || params.hwid || this._calculateLocalHwid());
    const issuedAt = params.issuedAt || new Date().toISOString();
    const expiresAt = params.expiresAt || new Date(Date.now() + validDays * 24 * 60 * 60 * 1000).toISOString();

    const enabledModules = [];
    const disabledModules = [];
    for (const entry of Object.values(MODULAR_ENGINE_CATALOG)) {
      if ((bitmask & entry.bitmask) !== 0) {
        enabledModules.push(entry.code);
      } else {
        disabledModules.push(entry.code);
      }
    }

    const tokenPayload = {
      v: 1,
      ticketId,
      bitmask,
      validDays,
      paidAmountKrw,
      purchaseChannel,
      customerId,
      issuedAt,
      expiresAt,
      requiresRedownload: false
    };
    const b64Payload = Buffer.from(JSON.stringify(tokenPayload), 'utf8').toString('base64url');
    const hmacSig = crypto
      .createHmac('sha256', MODULE_TICKET_HMAC_SECRET)
      .update(`AF-TKT-v1.${b64Payload}`)
      .digest('base64url');
    const ticket = `AF-TKT-v1.${b64Payload}.${hmacSig}`;

    return {
      success: true,
      ticket,
      ticketId,
      bitmask,
      validDays,
      paidAmountKrw,
      purchaseChannel,
      customerId,
      issuedAt,
      expiresAt,
      enabledModules,
      disabledModules,
      signatureValid: true,
      requiresRedownload: false,
      activationMode: 'PREBUNDLED_TICKET_AND_MCP_HYBRID'
    };
  }

  /**
   * Read-only (non-mutating) preview of a signed module ticket or standard license key before activation.
   * Never mutates activatedTicketIds or disk state, and never exposes hardcoded sales prices (₩ / $).
   */
  previewModuleTicketUnlock(rawInput = {}) {
    const rawStr = typeof rawInput === 'string'
      ? rawInput
      : (rawInput && typeof rawInput === 'object' && !Array.isArray(rawInput) ? rawInput.ticket || rawInput.licenseKey || '' : '');

    if (typeof rawStr !== 'string' || rawStr.trim().length === 0) {
      return {
        valid: false,
        previewReady: false,
        readOnlyPreview: true,
        signatureValid: false,
        reason: 'EMPTY_OR_INVALID_INPUT',
        ticketType: 'UNKNOWN',
        ticketId: null,
        bitmask: 0,
        validDays: 0,
        expiresAt: null,
        unlockedModules: [],
        unlockedModuleDisplayNames: [],
        dashboardPriceDisplayAllowed: false,
        workflowAlwaysRuns: true,
        previewSummaryKo: '티켓 또는 라이선스 키를 입력하시면 해금 대상 모듈과 유효 기간이 실시간으로 표시됩니다.'
      };
    }

    const trimmed = rawStr.trim();
    const isSignedModuleTicket = trimmed.startsWith('AF-TKT-v1.') || trimmed.startsWith('MOD-TKT-v1.');

    if (!isSignedModuleTicket) {
      const upper = trimmed.toUpperCase();
      if (upper.startsWith('AF-BYOK-') || upper.startsWith('AF-PRO-') || upper.startsWith('AF-ENT-') || upper.length >= 12) {
        const tierLabel = upper.startsWith('AF-ENT-')
          ? 'MANAGED_ENTERPRISE'
          : (upper.startsWith('AF-PRO-') ? 'MANAGED_PRO' : 'BYOK_LITE');
        const baseCodes = Object.values(MODULAR_ENGINE_CATALOG).map(m => m.code);
        return {
          valid: true,
          previewReady: true,
          readOnlyPreview: true,
          signatureValid: true,
          reason: 'VALID_STANDARD_LICENSE_KEY_FORMAT',
          ticketType: 'STANDARD_DEVICE_LICENSE',
          detectedTier: tierLabel,
          ticketId: upper.slice(0, 20),
          bitmask: 1023,
          validDays: 30,
          expiresAt: null,
          unlockedModules: baseCodes,
          unlockedModuleDisplayNames: Object.values(MODULAR_ENGINE_CATALOG).map(m => m.displayName),
          dashboardPriceDisplayAllowed: false,
          workflowAlwaysRuns: true,
          previewSummaryKo: `[1:1 기기 귀속형 라이선스 감지: ${tierLabel}] 기본 10대 모듈(Bitmask=1023) 및 워크플로우 영구 가동 권한이 확인되었습니다.`
        };
      }
      return {
        valid: false,
        previewReady: true,
        readOnlyPreview: true,
        signatureValid: false,
        reason: 'INVALID_MODULE_TICKET_FORMAT',
        ticketType: 'UNKNOWN',
        ticketId: null,
        bitmask: 0,
        validDays: 0,
        expiresAt: null,
        unlockedModules: [],
        unlockedModuleDisplayNames: [],
        dashboardPriceDisplayAllowed: false,
        workflowAlwaysRuns: true,
        previewSummaryKo: '유효하지 않은 티켓 형식입니다. AF-TKT-v1.* 모듈 티켓 또는 정품 라이선스 시리얼을 확인해 주세요.'
      };
    }

    const parts = trimmed.split('.');
    if (parts.length !== 3) {
      return {
        valid: false,
        previewReady: true,
        readOnlyPreview: true,
        signatureValid: false,
        reason: 'MALFORMED_MODULE_TICKET',
        ticketType: 'SIGNED_MODULE_TICKET',
        ticketId: null,
        bitmask: 0,
        validDays: 0,
        expiresAt: null,
        unlockedModules: [],
        unlockedModuleDisplayNames: [],
        dashboardPriceDisplayAllowed: false,
        workflowAlwaysRuns: true,
        previewSummaryKo: '티켓 구조가 손상되었습니다(세그먼트 누락). 전체 문자열을 다시 복사해 붙여넣어 주세요.'
      };
    }

    const [prefix, b64Payload, providedSig] = parts;
    const expectedSigCanonical = crypto
      .createHmac('sha256', MODULE_TICKET_HMAC_SECRET)
      .update(`AF-TKT-v1.${b64Payload}`)
      .digest('base64url');
    const expectedSigPrefix = crypto
      .createHmac('sha256', MODULE_TICKET_HMAC_SECRET)
      .update(`${prefix}.${b64Payload}`)
      .digest('base64url');

    if (providedSig !== expectedSigCanonical && providedSig !== expectedSigPrefix) {
      return {
        valid: false,
        previewReady: true,
        readOnlyPreview: true,
        signatureValid: false,
        reason: 'INVALID_MODULE_TICKET_SIGNATURE',
        ticketType: 'SIGNED_MODULE_TICKET',
        ticketId: null,
        bitmask: 0,
        validDays: 0,
        expiresAt: null,
        unlockedModules: [],
        unlockedModuleDisplayNames: [],
        dashboardPriceDisplayAllowed: false,
        workflowAlwaysRuns: true,
        previewSummaryKo: '티켓 전자서명(HMAC-SHA256) 검증에 실패했습니다. 위변조되었거나 손상된 티켓입니다.'
      };
    }

    let decoded = null;
    try {
      decoded = JSON.parse(Buffer.from(b64Payload, 'base64url').toString('utf8'));
    } catch (e) {
      return {
        valid: false,
        previewReady: true,
        readOnlyPreview: true,
        signatureValid: false,
        reason: 'CORRUPT_MODULE_TICKET_PAYLOAD',
        ticketType: 'SIGNED_MODULE_TICKET',
        ticketId: null,
        bitmask: 0,
        validDays: 0,
        expiresAt: null,
        unlockedModules: [],
        unlockedModuleDisplayNames: [],
        dashboardPriceDisplayAllowed: false,
        workflowAlwaysRuns: true,
        previewSummaryKo: '티켓 내부 페이로드 디코딩에 실패했습니다.'
      };
    }

    const ticketId = decoded && decoded.ticketId ? String(decoded.ticketId) : null;
    const expiresAt = decoded && decoded.expiresAt ? String(decoded.expiresAt) : null;
    const validDays = decoded && Number.isFinite(Number(decoded.validDays)) ? Math.max(1, Math.floor(Number(decoded.validDays))) : 30;
    const bitmask = decoded && Number.isFinite(Number(decoded.bitmask)) ? Math.max(0, Math.floor(Number(decoded.bitmask))) : 0;
    const purchaseChannel = decoded && decoded.purchaseChannel ? String(decoded.purchaseChannel) : 'DIRECT_OR_MARKET';
    const ticketHash = crypto.createHash('sha256').update(trimmed).digest('hex');

    const allCatalogEntries = [
      ...Object.values(MODULAR_ENGINE_CATALOG),
      ...Object.values(OTA_HOTPLUG_MODULE_TEMPLATES),
      ...Array.from(this.dynamicMcpRegistry.values())
    ];
    const seenCodes = new Set();
    const unlockedModules = [];
    const unlockedModuleDisplayNames = [];
    for (const entry of allCatalogEntries) {
      if (!entry || !entry.code || seenCodes.has(entry.code)) continue;
      seenCodes.add(entry.code);
      if (typeof entry.bitmask === 'number' && (bitmask & entry.bitmask) !== 0) {
        unlockedModules.push(entry.code);
        unlockedModuleDisplayNames.push(entry.displayName || entry.code);
      }
    }

    if (expiresAt !== null && expiresAt.trim() !== '') {
      const expMs = new Date(expiresAt).getTime();
      if (Number.isNaN(expMs)) {
        return {
          valid: false,
          previewReady: true,
          readOnlyPreview: true,
          signatureValid: true,
          invalidExpiry: true,
          reason: 'INVALID_MODULE_TICKET_EXPIRY',
          ticketType: 'SIGNED_MODULE_TICKET',
          ticketId,
          bitmask,
          validDays,
          expiresAt,
          unlockedModules,
          unlockedModuleDisplayNames,
          dashboardPriceDisplayAllowed: false,
          workflowAlwaysRuns: true,
          previewSummaryKo: '티켓의 만료일 형식이 유효하지 않습니다.'
        };
      }
      if (expMs < Date.now()) {
        return {
          valid: false,
          previewReady: true,
          readOnlyPreview: true,
          signatureValid: true,
          expired: true,
          reason: 'EXPIRED_MODULE_TICKET',
          ticketType: 'SIGNED_MODULE_TICKET',
          ticketId,
          bitmask,
          validDays,
          expiresAt,
          unlockedModules,
          unlockedModuleDisplayNames,
          dashboardPriceDisplayAllowed: false,
          workflowAlwaysRuns: true,
          previewSummaryKo: `유효기간이 만료된 티켓입니다 (만료일: ${expiresAt.slice(0, 10)}). 기본 워크플로우 단품은 계속 무료 가동됩니다.`
        };
      }
    }

    const stateForRevokeCheck = this.loadState();
    const persistedRevoked = Array.isArray(stateForRevokeCheck.revoked_ticket_ids)
      ? stateForRevokeCheck.revoked_ticket_ids
      : [];
    const isRevoked =
      (ticketId && (this.revokedTicketIds.has(ticketId) || persistedRevoked.includes(ticketId))) ||
      this.revokedTicketIds.has(trimmed) ||
      this.revokedTicketIds.has(ticketHash) ||
      persistedRevoked.includes(ticketHash);
    if (isRevoked) {
      return {
        valid: false,
        previewReady: true,
        readOnlyPreview: true,
        signatureValid: true,
        revoked: true,
        reason: 'REVOKED_OR_REFUNDED_MODULE_TICKET',
        ticketType: 'SIGNED_MODULE_TICKET',
        ticketId,
        bitmask,
        validDays,
        expiresAt,
        unlockedModules,
        unlockedModuleDisplayNames,
        dashboardPriceDisplayAllowed: false,
        workflowAlwaysRuns: true,
        previewSummaryKo: '이미 환불 또는 회수 처리된 모듈 티켓입니다 (재사용 불가).'
      };
    }

    return {
      valid: true,
      previewReady: true,
      readOnlyPreview: true,
      signatureValid: true,
      reason: 'VALID_SIGNED_MODULE_TICKET',
      ticketType: 'SIGNED_MODULE_TICKET',
      ticketId,
      bitmask,
      validDays,
      expiresAt,
      purchaseChannel,
      unlockedModules,
      unlockedModuleDisplayNames,
      dashboardPriceDisplayAllowed: false,
      workflowAlwaysRuns: true,
      previewSummaryKo: `✅ 정품 서명 확인 완료 (${purchaseChannel} · +${validDays}일권) — 해금 모듈 ${unlockedModules.length}종 [Bitmask=${bitmask}: ${unlockedModules.join(', ')}] 즉시 활성화 가능`
    };
  }

  _syncToLicenseJson() {
    try {
      const rootDir = path.resolve(__dirname, '..');
      const licenseJsonPath = path.join(rootDir, 'data', 'license.json');
      let data = {};
      if (fs.existsSync(licenseJsonPath)) {
        try {
          data = JSON.parse(fs.readFileSync(licenseJsonPath, 'utf8')) || {};
        } catch (_) {
          data = {};
        }
      }
      data.activeModuleBitmask = (this.activeModuleBitmask || 0) >>> 0;
      data.activatedEnginePacks = Array.from(new Set([
        ...(Array.isArray(data.activatedEnginePacks) ? data.activatedEnginePacks : []),
        ...(Array.isArray(this.activatedEnginePacks) ? this.activatedEnginePacks : [])
      ]));
      if (this.smartGridLicensed) {
        data.smartGridLicensed = true;
      }
      data.lastUpdated = new Date().toISOString();
      const dir = path.dirname(licenseJsonPath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(licenseJsonPath, JSON.stringify(data, null, 2), 'utf8');
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * Verifies and activates a signed module ticket (or direct bitmask/modules array) in <0.1s without redownloading
   */
  activateModuleTicket(rawInput = {}, maybeOptions = {}) {
    if (
      rawInput !== undefined &&
      rawInput !== null &&
      typeof rawInput !== 'string' &&
      (typeof rawInput !== 'object' || Array.isArray(rawInput))
    ) {
      return {
        success: false,
        activated: false,
        signatureValid: false,
        requiresRedownload: false,
        error: 'INVALID_MODULE_TICKET_FORMAT',
        workflowAlwaysRuns: true
      };
    }

    const options = (maybeOptions && typeof maybeOptions === 'object' && !Array.isArray(maybeOptions)) ? maybeOptions : {};
    const params = typeof rawInput === 'string'
      ? { ticket: rawInput, ...options }
      : ((rawInput && typeof rawInput === 'object' && !Array.isArray(rawInput)) ? { ...rawInput, ...options } : { ...options });

    const ticketRaw = (typeof params.ticket === 'string') ? params.ticket.trim() : '';
    const candidateSku = (params.engineSku || params.addonSku || params.sku || (ticketRaw && ENGINE_PACK_SKU_MAP[ticketRaw.toUpperCase()] ? ticketRaw : '')).toString().trim().toUpperCase();

    if (candidateSku && ENGINE_PACK_SKU_MAP[candidateSku]) {
      const skuInfo = ENGINE_PACK_SKU_MAP[candidateSku];
      const previousBitmask = (this.getActiveModuleBitmask() || 0) >>> 0;
      this.activeModuleBitmask = ((this.activeModuleBitmask || previousBitmask || 0) | (skuInfo.bitmask >>> 0)) >>> 0;
      if (!this.activatedEnginePacks) {
        this.activatedEnginePacks = [];
      }
      if (skuInfo.packId && skuInfo.packId !== 'ALL' && skuInfo.packId !== 'SMARTGRID') {
        if (!this.activatedEnginePacks.includes(skuInfo.packId)) {
          this.activatedEnginePacks.push(skuInfo.packId);
        }
      } else if (skuInfo.sku === 'AF-ENG-ALL') {
        const allSix = ['PACK_CORE_BASE', 'PACK_COMMERCE_LOGISTICS', 'PACK_FINANCE_TAX_ERP', 'PACK_GLOBAL_CUSTOMS_FX', 'PACK_CS_DISPUTE_PRIVACY', 'PACK_MARKETING_CRM_PIPELINE'];
        for (const p of allSix) {
          if (!this.activatedEnginePacks.includes(p)) this.activatedEnginePacks.push(p);
        }
      }
      if (candidateSku === 'AF-SMARTGRID-PRO' || params.addonSku === 'AF-SMARTGRID-PRO') {
        this.smartGridLicensed = true;
      }
      this._syncToLicenseJson();
      const cumulativeBitmask = this.activeModuleBitmask;
      return {
        success: true,
        activated: true,
        activatedWithinOneSecond: true,
        signatureValid: true,
        requiresRedownload: false,
        activationMode: 'ENGINE_PACK_SKU_OR_ADDON',
        sku: skuInfo.sku,
        ticketId: skuInfo.sku,
        bitmask: cumulativeBitmask,
        activeModuleBitmask: cumulativeBitmask,
        previousBitmask,
        addedBitmask: skuInfo.bitmask,
        cumulativeBitmask,
        activatedEnginePacks: Array.from(this.activatedEnginePacks),
        smartGridLicensed: !!this.smartGridLicensed,
        workflowAlwaysRuns: true
      };
    }

    if (!params.ticket) {
      return {
        success: false,
        activated: false,
        signatureValid: false,
        requiresRedownload: false,
        error: 'REQUIRE_SIGNED_TICKET',
        message: '전자서명된 정품 모듈 티켓(AF-TKT-...)이 필요합니다.',
        workflowAlwaysRuns: true
      };
    }

    // 4-Stage Cyber Deception & Tarpit Sentinel: inspect ticket for Canary Honeytoken trigger
    const cyberDeceptionSentinel = require('./cyber_deception_tarpit_sentinel');
    const localHwid = params.expectedHwid || params.hwid || this._calculateLocalHwid();
    const canaryCheck = cyberDeceptionSentinel.inspectForCanaryTrigger(params.ticket || params, {
      hwid: localHwid,
      client_ip: params.client_ip || '127.0.0.1',
      user_agent: params.user_agent || 'AutoFlow-Ticket-Client/1.0'
    });
    if (canaryCheck.triggered) {
      const forensicRecord = cyberDeceptionSentinel.recordForensicEvidenceAndLockHwid({
        ...canaryCheck,
        attacker_hwid: localHwid,
        client_ip: params.client_ip || '127.0.0.1',
        user_agent: params.user_agent || 'AutoFlow-Ticket-Client/1.0'
      });
      const currentState = this.loadState();
      currentState.status = 'DECEPTION_TARPIT_QUARANTINE';
      currentState.is_blocked = true;
      currentState.deception_trap_triggered = true;
      currentState.deception_trigger_type = canaryCheck.trigger_type;
      currentState.deception_forensic_hmac = forensicRecord.forensic_hmac_sha256;
      currentState.hwid = localHwid;
      this.saveState(currentState);
      return cyberDeceptionSentinel.buildTarpitLabyrinthResponse(params.step || 1, forensicRecord);
    }

    let bitmask = 0;
    let expiresAt = null;
    let ticketId = null;
    let decodedTicketMeta = null;
    let signatureValid = true;
    let isNoOpEmptyCall = false;
    let matched = null;

    if (ticketRaw && !ticketRaw.startsWith('AF-TKT-v1.')) {
      // Direct module code / SKU ticket matching
      const upper = ticketRaw.toUpperCase().replace(/[\s-]+/g, '_');
      const directKey = ticketRaw.toUpperCase();
      if (NAVER_SINGLE_WORKFLOW_CATALOG[ticketRaw] || NAVER_SINGLE_WORKFLOW_CATALOG[directKey]) {
        matched = NAVER_SINGLE_WORKFLOW_CATALOG[ticketRaw] || NAVER_SINGLE_WORKFLOW_CATALOG[directKey];
      } else if (OTA_HOTPLUG_MODULE_TEMPLATES[ticketRaw] || OTA_HOTPLUG_MODULE_TEMPLATES[upper]) {
        matched = OTA_HOTPLUG_MODULE_TEMPLATES[ticketRaw] || OTA_HOTPLUG_MODULE_TEMPLATES[upper];
      } else if (MODULAR_ENGINE_CATALOG[ticketRaw] || MODULAR_ENGINE_CATALOG[upper]) {
        matched = MODULAR_ENGINE_CATALOG[ticketRaw] || MODULAR_ENGINE_CATALOG[upper];
      } else {
        for (const cat of [NAVER_SINGLE_WORKFLOW_CATALOG, OTA_HOTPLUG_MODULE_TEMPLATES, MODULAR_ENGINE_CATALOG]) {
          for (const item of Object.values(cat)) {
            if (
              item.code === upper ||
              item.sku === directKey ||
              item.legacyAlias === upper ||
              (item.mcpToolName && item.mcpToolName.toUpperCase() === upper)
            ) {
              matched = item;
              break;
            }
          }
          if (matched) break;
        }
      }

      if (!matched) {
        return {
          success: false,
          activated: false,
          signatureValid: false,
          requiresRedownload: false,
          error: 'INVALID_MODULE_TICKET_FORMAT',
          workflowAlwaysRuns: true
        };
      }

      bitmask = matched.bitmask;
      ticketId = matched.sku || matched.code || ticketRaw;
      signatureValid = true;
      decodedTicketMeta = { validDays: 365, paidAmountKrw: matched.priceMonthly || 39000, purchaseChannel: 'NAVER_SMARTSTORE' };
    } else if (params.ticket !== undefined) {
      if (typeof params.ticket !== 'string' || !params.ticket.trim().startsWith('AF-TKT-v1.')) {
        return {
          success: false,
          activated: false,
          signatureValid: false,
          requiresRedownload: false,
          error: 'INVALID_MODULE_TICKET_FORMAT',
          workflowAlwaysRuns: true
        };
      }
      const trimmedTicket = params.ticket.trim();
      const parts = trimmedTicket.split('.');
      if (parts.length !== 3) {
        return {
          success: false,
          activated: false,
          signatureValid: false,
          requiresRedownload: false,
          error: 'MALFORMED_MODULE_TICKET',
          workflowAlwaysRuns: true
        };
      }
      const [, b64Payload, providedSig] = parts;
      const expectedSig = crypto
        .createHmac('sha256', MODULE_TICKET_HMAC_SECRET)
        .update(`AF-TKT-v1.${b64Payload}`)
        .digest('base64url');

      if (providedSig !== expectedSig) {
        return {
          success: false,
          activated: false,
          signatureValid: false,
          requiresRedownload: false,
          error: 'INVALID_MODULE_TICKET_SIGNATURE',
          workflowAlwaysRuns: true
        };
      }

      let decoded = null;
      try {
        decoded = JSON.parse(Buffer.from(b64Payload, 'base64url').toString('utf8'));
      } catch (e) {
        return {
          success: false,
          activated: false,
          signatureValid: false,
          requiresRedownload: false,
          error: 'CORRUPT_MODULE_TICKET_PAYLOAD',
          workflowAlwaysRuns: true
        };
      }

      ticketId = decoded.ticketId ? String(decoded.ticketId) : null;
      expiresAt = decoded.expiresAt || null;
      const ticketHash = crypto.createHash('sha256').update(trimmedTicket).digest('hex');

      // 1) 만료된 모듈 티켓 및 비정상 만료일 원천 차단 (INVALID_MODULE_TICKET_EXPIRY / EXPIRED_MODULE_TICKET)
      if (expiresAt !== null && expiresAt !== undefined && String(expiresAt).trim() !== '') {
        const expMs = new Date(expiresAt).getTime();
        if (Number.isNaN(expMs)) {
          return {
            success: false,
            activated: false,
            signatureValid: true,
            invalidExpiry: true,
            ticketId,
            expiresAt,
            requiresRedownload: false,
            error: 'INVALID_MODULE_TICKET_EXPIRY',
            workflowAlwaysRuns: true
          };
        }
        if (expMs < Date.now()) {
          return {
            success: false,
            activated: false,
            signatureValid: true,
            expired: true,
            ticketId,
            expiresAt,
            requiresRedownload: false,
            error: 'EXPIRED_MODULE_TICKET',
            workflowAlwaysRuns: true
          };
        }
      }

      // 1-B) 등록(활성화) 시점 기준 만료일 카운트다운 보강 (미래 만료일 보장)
      const ticketValidDays = (decoded && Number.isFinite(decoded.validDays) && decoded.validDays > 0)
        ? decoded.validDays
        : 30;
      const activationRelativeExpiry = new Date(Date.now() + ticketValidDays * 86400000).toISOString();
      if (!expiresAt || new Date(activationRelativeExpiry).getTime() > new Date(expiresAt).getTime()) {
        expiresAt = activationRelativeExpiry;
      }

      // 2) 환불 또는 회수된 티켓 재사용 차단 (REVOKED_OR_REFUNDED_MODULE_TICKET)
      const stateForRevokeCheck = this.loadState();
      const persistedRevoked = Array.isArray(stateForRevokeCheck.revoked_ticket_ids)
        ? stateForRevokeCheck.revoked_ticket_ids
        : [];
      const isRevoked =
        (ticketId && (this.revokedTicketIds.has(ticketId) || persistedRevoked.includes(ticketId))) ||
        this.revokedTicketIds.has(trimmedTicket) ||
        this.revokedTicketIds.has(ticketHash) ||
        persistedRevoked.includes(ticketHash);
      if (isRevoked) {
        return {
          success: false,
          activated: false,
          signatureValid: true,
          revoked: true,
          ticketId,
          requiresRedownload: false,
          error: 'REVOKED_OR_REFUNDED_MODULE_TICKET',
          workflowAlwaysRuns: true
        };
      }

      // 3) 동일 티켓 중복 등록(Replay) 방지 (DUPLICATE_TICKET_REPLAY_BLOCKED)
      if (
        params.preventDuplicateReplay === true &&
        ((ticketId && this.activatedTicketIds.has(ticketId)) || this.activatedTicketIds.has(ticketHash))
      ) {
        return {
          success: false,
          activated: false,
          signatureValid: true,
          duplicateReplayBlocked: true,
          ticketId,
          requiresRedownload: false,
          error: 'DUPLICATE_TICKET_REPLAY_BLOCKED',
          activeModuleBitmask: this.getActiveModuleBitmask(),
          workflowAlwaysRuns: true
        };
      }

      // 4) 타인 기기 HWID 도용 차단 (TICKET_HWID_MISMATCH)
      if (params.enforceHwidMatch === true) {
        const expectedHwid = String(params.expectedHwid || this._calculateLocalHwid());
        if (decoded.customerId && String(decoded.customerId) !== expectedHwid) {
          return {
            success: false,
            activated: false,
            signatureValid: true,
            ticketId,
            expectedHwid,
            ticketCustomerId: decoded.customerId,
            requiresRedownload: false,
            error: 'TICKET_HWID_MISMATCH',
            workflowAlwaysRuns: true
          };
        }
      }

      bitmask = typeof decoded.bitmask === 'number' && Number.isFinite(decoded.bitmask)
        ? Math.max(0, Math.floor(decoded.bitmask))
        : 0;
      decodedTicketMeta = decoded;
      matched = { bitmask, ...decoded };
      if (ticketId) {
        this.activatedTicketIds.add(ticketId);
      }
      this.activatedTicketIds.add(ticketHash);
    } else if (params.bitmask !== undefined || Array.isArray(params.modules) || Array.isArray(params.enabledModules)) {
      bitmask = this._resolveBitmaskFromParams(params);
      matched = { bitmask };
    } else if (matched) {
      bitmask = matched.bitmask;
    } else {
      bitmask = this.getActiveModuleBitmask();
      matched = { bitmask };
      isNoOpEmptyCall = true;
    }

    const previousBitmask = (this.getActiveModuleBitmask() || 0) >>> 0;
    const addedBitmask = (matched && typeof matched.bitmask === 'number')
      ? (matched.bitmask >>> 0)
      : (bitmask >>> 0);
    this.activeModuleBitmask = ((this.activeModuleBitmask || previousBitmask || 0) | addedBitmask) >>> 0;
    const cumulativeBitmask = this.activeModuleBitmask;

    const allEntries = [
      ...Object.values(MODULAR_ENGINE_CATALOG),
      ...Object.values(OTA_HOTPLUG_MODULE_TEMPLATES),
      ...Array.from(this.dynamicMcpRegistry.values())
    ];
    const seenCodes = new Set();
    const enabledModules = [];
    const disabledModules = [];
    const mcpToolsActive = [];

    for (const entry of allEntries) {
      if (!entry || !entry.code || seenCodes.has(entry.code)) continue;
      seenCodes.add(entry.code);
      if ((cumulativeBitmask & entry.bitmask) !== 0) {
        enabledModules.push(entry.code);
        if (entry.mcpToolName) mcpToolsActive.push(entry.mcpToolName);
      } else {
        disabledModules.push(entry.code);
      }
    }

    if (params.skipDiskSave !== true && !isNoOpEmptyCall) {
      const currentState = this.loadState();
      const updatedState = {
        ...currentState,
        active_module_bitmask: cumulativeBitmask,
        enabled_module_codes: enabledModules,
        disabled_module_codes: disabledModules,
        mcp_tools_active: mcpToolsActive,
        last_ticket_activated_at: new Date().toISOString()
      };
      if (ticketId) {
        updatedState.last_activated_ticket_id = ticketId;
      }
      if (decodedTicketMeta) {
        const nowIso = new Date().toISOString();
        updatedState.status = 'ACTIVE';
        updatedState.tier = currentState.tier || 'ENTERPRISE_SELF_HEALING';
        updatedState.activated_at = currentState.activated_at || nowIso;
        updatedState.last_heartbeat_ack = nowIso;
        updatedState.valid_until = expiresAt || decodedTicketMeta.exp || decodedTicketMeta.expiresAt || currentState.valid_until || new Date(Date.now() + 365 * 86400000).toISOString();
        updatedState.module_ticket_paid_amount_krw = decodedTicketMeta.paidAmountKrw;
        updatedState.module_ticket_valid_days = decodedTicketMeta.validDays;
        updatedState.module_ticket_purchase_channel = decodedTicketMeta.purchaseChannel;
      }
      if (expiresAt) {
        updatedState.module_ticket_expires_at = expiresAt;
      }
      this.saveState(updatedState);
      this._syncToLicenseJson();
    }

    return {
      success: true,
      activated: true,
      activatedWithinOneSecond: true,
      signatureValid,
      requiresRedownload: false,
      activationMode: 'PREBUNDLED_TICKET_AND_MCP_HYBRID',
      ticketId,
      bitmask: cumulativeBitmask,
      activeModuleBitmask: cumulativeBitmask,
      previousBitmask,
      addedBitmask,
      cumulativeBitmask,
      enabledModules,
      unlockedModules: enabledModules,
      unlockedModulesCount: enabledModules.length,
      disabledModules,
      mcpToolsActive,
      validDays: (decodedTicketMeta && Number.isFinite(decodedTicketMeta.validDays) ? decodedTicketMeta.validDays : 30),
      expiresAt,
      workflowAlwaysRuns: true
    };
  }

  /**
   * 모듈 티켓(7일/30일/90일/365일) 실사용 일수 일할 차감 공정 환불 계산기
   * - 예: 1년치(365일, ₩290,000) 모듈 티켓을 구매하고 7일(1주일) 사용 후 환불 요청 시
   *   사용한 7일분 일할 금액(₩5,562) + 10% 위약수수료(₩29,000)를 공제한 ₩255,438을 정산 환불하며,
   *   환불 후에도 고객이 영구 소장한 기본 워크플로우(workflowAlwaysRuns: true)는 중단 없이 영구 가동 보장!
   */
  calculateModuleTicketProratedRefund(rawParams = {}) {
    const params = (rawParams && typeof rawParams === 'object' && !Array.isArray(rawParams)) ? rawParams : {};
    const state = this.loadState();
    const ticketId = String(params.ticketId || state.last_activated_ticket_id || 'TKT-MODULE-DEFAULT');
    const paidAmountKrw = (typeof params.paidAmountKrw === 'number' && Number.isFinite(params.paidAmountKrw))
      ? Math.max(0, Math.floor(params.paidAmountKrw))
      : (typeof state.module_ticket_paid_amount_krw === 'number' && Number.isFinite(state.module_ticket_paid_amount_krw)
        ? Math.max(0, Math.floor(state.module_ticket_paid_amount_krw))
        : 290000);
    const totalDurationDays = (typeof params.totalDurationDays === 'number' && Number.isFinite(params.totalDurationDays) && params.totalDurationDays > 0)
      ? Math.max(1, Math.floor(params.totalDurationDays))
      : (typeof state.module_ticket_valid_days === 'number' && Number.isFinite(state.module_ticket_valid_days) && state.module_ticket_valid_days > 0
        ? Math.max(1, Math.floor(state.module_ticket_valid_days))
        : 365);
    const purchaseChannel = String(
      params.purchaseChannel || state.module_ticket_purchase_channel || 'NAVER_SMARTSTORE'
    ).toUpperCase();

    const rawReceiptMs = params.receiptTimestamp ? new Date(params.receiptTimestamp).getTime() : Date.now();
    const receiptMs = Number.isFinite(rawReceiptMs) ? rawReceiptMs : Date.now();
    const rawActivatedMs = params.activatedAt
      ? new Date(params.activatedAt).getTime()
      : (state.last_ticket_activated_at ? new Date(state.last_ticket_activated_at).getTime() : receiptMs);
    const activatedMs = Number.isFinite(rawActivatedMs) ? rawActivatedMs : receiptMs;

    const dailyRateKrw = paidAmountKrw / totalDurationDays;

    // 1) 미등록(미활성화) 티켓 환불 요청 시 100% 전액 환불
    if (params.isUnactivated === true) {
      return {
        success: true,
        eligible: true,
        ticketId,
        purchaseChannel,
        paidAmountKrw,
        totalDurationDays,
        usedDays: 0,
        remainingDays: totalDurationDays,
        dailyRateKrw: Math.round(dailyRateKrw),
        usedAmountKrw: 0,
        penaltyFeeKrw: 0,
        refundAmountKrw: paidAmountKrw,
        status: 'FULL_REFUND_UNACTIVATED_TICKET',
        workflowAlwaysRuns: true,
        daemonBlocked: false,
        legalBasis: '전자상거래 등에서의 소비자보호에 관한 법률 제17조 (미사용·미등록 티켓 100% 전액 환불)'
      };
    }

    const rawUsedDays = (typeof params.usedDaysOverride === 'number' && Number.isFinite(params.usedDaysOverride))
      ? Math.ceil(params.usedDaysOverride)
      : Math.ceil(Math.max(0, receiptMs - activatedMs) / 86400000);
    const usedDays = Math.min(totalDurationDays, Math.max(1, Number.isFinite(rawUsedDays) ? rawUsedDays : 1));

    // 2) 활성화 후 7일 이내 모듈 결함 접수 시 100% 전액 환불 (또는 검수 대기)
    if (params.defectReported === true && usedDays <= 7) {
      const adminVerified = params.adminDefectVerified === true;
      return {
        success: true,
        eligible: true,
        ticketId,
        purchaseChannel,
        paidAmountKrw,
        totalDurationDays,
        usedDays,
        remainingDays: Math.max(0, totalDurationDays - usedDays),
        dailyRateKrw: Math.round(dailyRateKrw),
        usedAmountKrw: 0,
        penaltyFeeKrw: 0,
        refundAmountKrw: paidAmountKrw,
        status: adminVerified ? 'FULL_REFUND_DEFECT_TICKET' : 'REFUND_PENDING_DEFECT_VERIFICATION',
        workflowAlwaysRuns: true,
        daemonBlocked: false,
        legalBasis: '공정거래위원회 디지털콘텐츠 표준약관 (7일 이내 치명적 결함 시 위약금 없이 100% 전액 환불)'
      };
    }

    // 3) 중도 해지 일할 정산 (예: 365일권 구매 후 7일 사용 후 환불 요청 -> 사용한 7일분 일할 차감 + 10% 위약수수료 공제)
    const usedAmountKrw = Math.min(paidAmountKrw, Math.round(dailyRateKrw * usedDays));
    const penaltyFeeKrw = Math.round(paidAmountKrw * 0.10);
    const refundAmountKrw = Math.max(0, paidAmountKrw - usedAmountKrw - penaltyFeeKrw);
    const status = refundAmountKrw > 0
      ? 'PRORATED_MODULE_TICKET_REFUND_ELIGIBLE'
      : 'PRORATED_MODULE_TICKET_REFUND_EXHAUSTED';

    return {
      success: true,
      eligible: refundAmountKrw > 0,
      ticketId,
      purchaseChannel,
      paidAmountKrw,
      totalDurationDays,
      usedDays,
      remainingDays: Math.max(0, totalDurationDays - usedDays),
      dailyRateKrw: Math.round(dailyRateKrw),
      usedAmountKrw,
      penaltyFeeKrw,
      refundAmountKrw,
      status,
      workflowAlwaysRuns: true,
      daemonBlocked: false,
      legalBasis: '전자상거래 등에서의 소비자보호에 관한 법률 및 공정거래위원회 표준약관 (실사용 일수 일할 차감 + 10% 위약수수료 공제)'
    };
  }

  /**
   * 모듈 티켓 단독 환불/회수 처리 (기본 워크플로우 영구 가동 보장)
   * - 환불된 티켓은 revokedTicketIds에 영구 등록되어 재사용(Replay)이 100% 차단됨
   * - activeModuleBitmask만 0으로 회수하며, state.is_blocked = false를 유지해 영구 소장 기본 워크플로우는 멈추지 않음!
   */
  revokeModuleTicketOnly(rawParams = {}) {
    const params = (rawParams && typeof rawParams === 'object' && !Array.isArray(rawParams)) ? rawParams : {};
    let ticketId = params.ticketId ? String(params.ticketId).trim() : null;
    let trimmedTicket = null;
    let ticketHash = null;

    if (typeof params.ticket === 'string' && params.ticket.trim().startsWith('AF-TKT-v1.')) {
      trimmedTicket = params.ticket.trim();
      ticketHash = crypto.createHash('sha256').update(trimmedTicket).digest('hex');
      try {
        const parts = trimmedTicket.split('.');
        if (parts.length === 3) {
          const decoded = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
          if (!ticketId && decoded.ticketId) {
            ticketId = String(decoded.ticketId);
          }
        }
      } catch (e) {}
    }

    const currentState = this.loadState();
    const existingRevoked = Array.isArray(currentState.revoked_ticket_ids) ? currentState.revoked_ticket_ids : [];
    const alreadyRevokedIdempotent = Boolean(
      (ticketId && (this.revokedTicketIds.has(ticketId) || existingRevoked.includes(ticketId))) ||
      (trimmedTicket && this.revokedTicketIds.has(trimmedTicket)) ||
      (ticketHash && (this.revokedTicketIds.has(ticketHash) || existingRevoked.includes(ticketHash)))
    );

    if (trimmedTicket) {
      this.revokedTicketIds.add(trimmedTicket);
    }
    if (ticketHash) {
      this.revokedTicketIds.add(ticketHash);
    }
    if (ticketId) {
      this.revokedTicketIds.add(ticketId);
    }

    const reason = String(params.reason || 'MODULE_TICKET_PRORATED_REFUND_COMPLETED');
    const hasPartialRevokeBitmask =
      typeof params.revokeBitmask === 'number' &&
      Number.isFinite(params.revokeBitmask) &&
      params.revokeBitmask > 0;
    const nextBitmask = hasPartialRevokeBitmask
      ? Math.max(0, this.getActiveModuleBitmask() & ~Math.floor(params.revokeBitmask))
      : 0;
    this.activeModuleBitmask = nextBitmask;

    const catalogEntries = Object.values(MODULAR_ENGINE_CATALOG);
    const enabledModuleCodes = [];
    const disabledModuleCodes = [];
    const mcpToolsActive = [];
    for (const m of catalogEntries) {
      if ((nextBitmask & m.bitmask) !== 0) {
        enabledModuleCodes.push(m.code);
        mcpToolsActive.push(m.mcpToolName);
      } else {
        disabledModuleCodes.push(m.code);
      }
    }

    const updatedRevoked = Array.from(
      new Set([
        ...existingRevoked,
        ...(ticketId ? [ticketId] : []),
        ...(ticketHash ? [ticketHash] : [])
      ])
    );

    const revokedAt = (alreadyRevokedIdempotent && currentState.last_module_ticket_revoked_at)
      ? currentState.last_module_ticket_revoked_at
      : new Date().toISOString();

    const updatedState = {
      ...currentState,
      active_module_bitmask: nextBitmask,
      enabled_module_codes: enabledModuleCodes,
      disabled_module_codes: disabledModuleCodes,
      mcp_tools_active: mcpToolsActive,
      is_blocked: false,
      workflow_perpetual_owned: true,
      revoked_ticket_ids: updatedRevoked,
      last_module_ticket_revoked_at: revokedAt,
      last_module_ticket_revocation_reason: reason
    };

    if (params.skipDiskSave !== true && (!alreadyRevokedIdempotent || hasPartialRevokeBitmask)) {
      this.saveState(updatedState);
    }

    this._notifyTelegramAlertSafe(
      'MODULE_TICKET_REVOKED',
      '🛑 [고객 모듈 티켓 회수 완료] 티켓 영구 회수 처리',
      { reason, ticketId: ticketId || 'TKT-UNKNOWN', remainingBitmask: nextBitmask }
    );

    return {
      success: true,
      revoked: true,
      alreadyRevokedIdempotent,
      revokedAt,
      ticketId,
      reason,
      activeModuleBitmask: nextBitmask,
      revokedBitmask: hasPartialRevokeBitmask ? Math.floor(params.revokeBitmask) : null,
      is_blocked: false,
      workflowPerpetualOwned: true,
      workflowAlwaysRuns: true,
      refundCalculation: params.refundCalculation || null,
      message: `모듈 티켓이 일할 정산 환불 처리되어 유료 모듈 기능(Bitmask=${nextBitmask})만 회수되었으며, 영구 소장하신 기본 워크플로우는 중단 없이 정상 가동됩니다.`
    };
  }

  /**
   * Dynamically registers an 11th+ MCP hot-plug module descriptor at runtime without modifying core binary
   */
  registerMcpModuleDescriptor(rawDescriptor = {}) {
    const desc = (rawDescriptor && typeof rawDescriptor === 'object' && !Array.isArray(rawDescriptor)) ? rawDescriptor : {};
    const code = String(desc.code || desc.moduleCode || `MOD_MCP_DYNAMIC_${this.dynamicMcpRegistry.size + 11}`).trim().toUpperCase();
    const bitIndex = typeof desc.bitIndex === 'number' && !Number.isNaN(desc.bitIndex)
      ? Math.max(10, Math.floor(desc.bitIndex))
      : (10 + this.dynamicMcpRegistry.size);
    const bitmask = (typeof desc.bitmask === 'number' && !Number.isNaN(desc.bitmask) && desc.bitmask > 0)
      ? Math.floor(desc.bitmask)
      : (1 << bitIndex);
    const mcpToolName = String(desc.mcpToolName || desc.name || `autoflow.module.dynamic_${bitIndex}`).trim();
    const displayName = String(desc.displayName || desc.description || code).trim();
    const priceMonthly = Number(desc.priceMonthly || 19000) || 19000;
    const entry = {
      code,
      bitIndex,
      bitmask,
      tier: desc.tier || 'M_OTA',
      category: desc.category || 'DYNAMIC_MCP_HOTPLUG',
      mcpToolName,
      displayName,
      priceMonthly,
      pricing: (desc.pricing && typeof desc.pricing === 'object')
        ? desc.pricing
        : ((desc.pricingKrw && typeof desc.pricingKrw === 'object')
          ? desc.pricingKrw
          : { d7: Math.round(priceMonthly * 0.3), d30: priceMonthly, d90: priceMonthly * 2.6, d365: priceMonthly * 10 }),
      preInstalled: Boolean(desc.preInstalled),
      requiresRedownload: false,
      requiresNewVersionRelease: false,
      requiredField: desc.requiredField || (desc.handlerSpec && desc.handlerSpec.requiredFields) || null,
      shouldActivateRule: desc.shouldActivateRule || (desc.handlerSpec && desc.handlerSpec.requiredFields) || null,
      executionAction: desc.executionAction || (desc.handlerSpec && desc.handlerSpec.actionName) || 'DYNAMIC_PING_MODULE_EXECUTED',
      inputSchema: (desc.inputSchema && typeof desc.inputSchema === 'object')
        ? desc.inputSchema
        : { type: 'object', properties: { payload: { type: 'object' } } }
    };
    this.dynamicMcpRegistry.set(code, entry);
    return {
      registered: true,
      module: entry,
      totalRegisteredModules: Object.keys(MODULAR_ENGINE_CATALOG).length + this.dynamicMcpRegistry.size
    };
  }

  /**
   * Clears dynamically hot-plugged MCP modules (for test isolation or reset)
   */
  clearDynamicMcpModules() {
    this.dynamicMcpRegistry.clear();
    return {
      cleared: true,
      totalRegisteredModules: Object.keys(MODULAR_ENGINE_CATALOG).length
    };
  }

  /**
   * Returns current modular engine catalog status (10 pre-bundled + any dynamic hot-plugged MCP modules)
   */
  getModularEngineCatalogStatus() {
    const descriptors = this.getMcpModuleDescriptors();
    const tools = (descriptors && descriptors.result && Array.isArray(descriptors.result.tools)) ? descriptors.result.tools : [];
    return {
      catalogVersion: this.dynamicMcpRegistry.size > 0 ? 2 : 1,
      activeModuleBitmask: descriptors.activeBitmask || 0,
      totalCatalogModules: tools.length,
      preBundledCount: Object.keys(MODULAR_ENGINE_CATALOG).length,
      dynamicHotpluggedCount: this.dynamicMcpRegistry.size,
      requiresRedownload: false,
      requiresNewVersionRelease: false,
      modules: tools
    };
  }

  /**
   * Builds an HMAC-SHA256 signed Pong payload (SYNC_MCP_MODULES) for zero-reinstall module hot-plug over Heartbeat Ping-Pong
   */
  buildSignedPingModuleSyncPayload(rawParams = {}) {
    const params = (rawParams && typeof rawParams === 'object' && !Array.isArray(rawParams)) ? rawParams : {};
    const catalogVersion = String(params.catalogVersion || '2026.10.14-OTA-v2').trim();
    const modules = Array.isArray(params.modules) ? params.modules : [];
    const nodePricingOverride = (params.nodePricingOverride && typeof params.nodePricingOverride === 'object' && !Array.isArray(params.nodePricingOverride))
      ? params.nodePricingOverride
      : null;
    const activateTicket = typeof params.activateTicket === 'string' ? params.activateTicket : null;
    let activateBitmask = (typeof params.activateBitmask === 'number' && !Number.isNaN(params.activateBitmask))
      ? Math.max(0, Math.floor(params.activateBitmask))
      : null;
    if (activateBitmask === null && params.activateAddedBits === true) {
      let addedMask = 0;
      for (const m of modules) {
        if (m && typeof m.bitmask === 'number') {
          addedMask |= Math.floor(m.bitmask);
        } else if (m && typeof m.bitIndex === 'number') {
          addedMask |= (1 << Math.floor(m.bitIndex));
        }
      }
      if (addedMask > 0) {
        activateBitmask = (this.getActiveModuleBitmask() | addedMask);
      }
    }
    const issuedAt = String(params.issuedAt || new Date().toISOString());

    const canonicalObj = {
      command: 'SYNC_MCP_MODULES',
      catalogVersion,
      modules,
      nodePricingOverride,
      activateTicket,
      activateBitmask,
      issuedAt,
      requiresNewVersionRelease: false,
      requiresRedownload: false
    };

    const signature = crypto
      .createHmac('sha256', PING_MODULE_OTA_HMAC_SECRET)
      .update(JSON.stringify(canonicalObj))
      .digest('hex');

    return {
      ...canonicalObj,
      signature
    };
  }

  /**
   * Verifies and applies a signed SYNC_MCP_MODULES payload received during Heartbeat Ping-Pong in <0.1s without new version release
   */
  applySignedPingModuleSync(rawPayload = {}) {
    const payload = (rawPayload && typeof rawPayload === 'object' && !Array.isArray(rawPayload)) ? rawPayload : {};
    const providedSig = typeof payload.signature === 'string' ? payload.signature.trim() : '';
    if (!providedSig) {
      return {
        success: false,
        applied: false,
        signatureValid: false,
        requiresNewVersionRelease: false,
        requiresRedownload: false,
        reason: 'INVALID_PING_MODULE_SYNC_SIGNATURE',
        error: 'INVALID_PING_MODULE_SYNC_SIGNATURE'
      };
    }

    const canonicalObj = {
      command: 'SYNC_MCP_MODULES',
      catalogVersion: String(payload.catalogVersion || '2026.10.14-OTA-v2').trim(),
      modules: Array.isArray(payload.modules) ? payload.modules : [],
      nodePricingOverride: (payload.nodePricingOverride && typeof payload.nodePricingOverride === 'object' && !Array.isArray(payload.nodePricingOverride))
        ? payload.nodePricingOverride
        : null,
      activateTicket: typeof payload.activateTicket === 'string' ? payload.activateTicket : null,
      activateBitmask: (typeof payload.activateBitmask === 'number' && !Number.isNaN(payload.activateBitmask))
        ? Math.max(0, Math.floor(payload.activateBitmask))
        : null,
      issuedAt: String(payload.issuedAt || ''),
      requiresNewVersionRelease: false,
      requiresRedownload: false
    };

    const expectedSig = crypto
      .createHmac('sha256', PING_MODULE_OTA_HMAC_SECRET)
      .update(JSON.stringify(canonicalObj))
      .digest('hex');

    const providedBuf = Buffer.from(providedSig, 'utf8');
    const expectedBuf = Buffer.from(expectedSig, 'utf8');
    if (
      providedBuf.length !== expectedBuf.length ||
      !crypto.timingSafeEqual(providedBuf, expectedBuf)
    ) {
      return {
        success: false,
        applied: false,
        signatureValid: false,
        requiresNewVersionRelease: false,
        requiresRedownload: false,
        reason: 'INVALID_PING_MODULE_SYNC_SIGNATURE',
        error: 'INVALID_PING_MODULE_SYNC_SIGNATURE'
      };
    }

    if (canonicalObj.activateTicket) {
      const tktRes = this.activateModuleTicket({
        ticket: canonicalObj.activateTicket,
        skipDiskSave: Boolean(payload.skipDiskSave)
      });
      if (!tktRes || !tktRes.activated) {
        const ticketActivationReason =
          (tktRes && (tktRes.reason || tktRes.error)) || 'TICKET_ACTIVATION_REJECTED';
        return {
          success: false,
          applied: false,
          signatureValid: true,
          ticketActivationBlocked: true,
          ticketActivationReason,
          requiresNewVersionRelease: false,
          requiresRedownload: false,
          reason: ticketActivationReason,
          error: ticketActivationReason,
          activeModuleBitmask: this.getActiveModuleBitmask()
        };
      }
    }

    const newlyRegisteredModules = [];
    for (const modDesc of canonicalObj.modules) {
      if (modDesc && typeof modDesc === 'object') {
        const regRes = this.registerMcpModuleDescriptor(modDesc);
        if (regRes && regRes.module) {
          newlyRegisteredModules.push(regRes.module.code);
        }
      }
    }

    if (!canonicalObj.activateTicket && canonicalObj.activateBitmask !== null) {
      this.activeModuleBitmask = canonicalObj.activateBitmask;
    }

    const totalModulesCount = Object.keys(MODULAR_ENGINE_CATALOG).length + this.dynamicMcpRegistry.size;
    return {
      success: true,
      applied: true,
      signatureValid: true,
      ticketActivationBlocked: false,
      ticketActivationReason: null,
      requiresNewVersionRelease: false,
      requiresRedownload: false,
      deliveryChannel: 'HEARTBEAT_PING_PONG_OTA',
      catalogVersion: canonicalObj.catalogVersion,
      newlyRegisteredModules,
      addedModules: newlyRegisteredModules,
      totalModulesCount,
      totalCatalogModules: totalModulesCount,
      activeModuleBitmask: this.getActiveModuleBitmask()
    };
  }

  /**
   * Returns JSON-RPC 2.0 MCP tools/list compatible descriptors for all 10 pre-bundled modules (+ any hot-plugged MCP modules)
   */
  getMcpModuleDescriptors(rawParams = {}) {
    const params = (rawParams && typeof rawParams === 'object' && !Array.isArray(rawParams)) ? rawParams : {};
    const activeBitmask = (typeof params.bitmask === 'number' && !Number.isNaN(params.bitmask))
      ? Math.max(0, Math.floor(params.bitmask))
      : this.getActiveModuleBitmask();

    const allEntries = [
      ...Object.values(MODULAR_ENGINE_CATALOG),
      ...Array.from(this.dynamicMcpRegistry.values())
    ];

    const tools = allEntries.map(entry => ({
      name: entry.mcpToolName,
      moduleCode: entry.code,
      bitIndex: entry.bitIndex,
      bitmask: entry.bitmask,
      tier: entry.tier || 'M_OTA',
      category: entry.category,
      description: entry.displayName,
      priceMonthly: entry.priceMonthly,
      preInstalled: entry.preInstalled !== false,
      requiresRedownload: false,
      requiresNewVersionRelease: false,
      enabled: (activeBitmask & entry.bitmask) !== 0,
      inputSchema: entry.inputSchema
    }));

    return {
      jsonrpc: '2.0',
      id: params.id || 'mcp-tools-list-1',
      result: {
        tools
      },
      activeBitmask,
      totalModules: tools.length,
      preBundledCount: Object.keys(MODULAR_ENGINE_CATALOG).length,
      dynamicHotpluggedCount: this.dynamicMcpRegistry.size,
      requiresRedownload: false,
      requiresNewVersionRelease: false,
      activationMode: 'PREBUNDLED_TICKET_AND_MCP_HYBRID'
    };
  }

  /**
   * 시간대별(경과일/페이즈별) 워크플로우 및 개별 노드 4단계 가격 산출기
   * - 초기 리셀러 차익거래 방어 고단가기(Phase 1) -> 시장 확산기(Phase 2) -> 성숙기(Phase 3) -> 최종 최저가 안착기(Phase 4)
   */
  resolveTimePhasedWorkflowPricing(options = {}) {
    const opts = (options && typeof options === 'object' && !Array.isArray(options)) ? options : {};
    let resolvedElapsedDays = 180;
    let selectedPhaseKey = 'PHASE_4_FINAL_FLOOR';
    let invalidLaunchDateFallbackToPhase1 = false;
    let invalidPhaseFallbackToPhase1 = false;
    let invalidElapsedDaysFallbackToPhase1 = false;
    let clockSkewFallbackToPhase1 = false;

    const PHASE_SHORT_ALIAS_MAP = {
      PHASE_1: 'PHASE_1_INITIAL',
      PHASE_2: 'PHASE_2_EXPANSION',
      PHASE_3: 'PHASE_3_MATURE',
      PHASE_4: 'PHASE_4_FINAL_FLOOR'
    };

    const rawPhaseDefined =
      opts.phase !== undefined &&
      opts.phase !== null &&
      String(opts.phase).trim() !== '';
    const rawTrimmedPhase = rawPhaseDefined ? String(opts.phase).trim().toUpperCase() : '';
    const normalizedPhase = Object.prototype.hasOwnProperty.call(PHASE_SHORT_ALIAS_MAP, rawTrimmedPhase)
      ? PHASE_SHORT_ALIAS_MAP[rawTrimmedPhase]
      : rawTrimmedPhase;

    if (
      normalizedPhase &&
      Object.prototype.hasOwnProperty.call(WORKFLOW_TIME_PHASED_PRICING_SCHEDULE, normalizedPhase)
    ) {
      selectedPhaseKey = normalizedPhase;
      resolvedElapsedDays = WORKFLOW_TIME_PHASED_PRICING_SCHEDULE[selectedPhaseKey].minDays;
    } else if (rawPhaseDefined) {
      resolvedElapsedDays = 0;
      selectedPhaseKey = 'PHASE_1_INITIAL';
      invalidPhaseFallbackToPhase1 = true;
    } else {
      let hasExplicitDays = false;
      if (opts.elapsedDaysSinceLaunch !== undefined && opts.elapsedDaysSinceLaunch !== null) {
        const rawDays = opts.elapsedDaysSinceLaunch;
        const parsedDays = (typeof rawDays === 'number')
          ? rawDays
          : (typeof rawDays === 'string' && rawDays.trim() !== '' ? Number(rawDays.trim()) : NaN);
        if (Number.isFinite(parsedDays) && parsedDays >= 0) {
          resolvedElapsedDays = Math.floor(parsedDays);
          hasExplicitDays = true;
        } else {
          resolvedElapsedDays = 0;
          selectedPhaseKey = 'PHASE_1_INITIAL';
          invalidElapsedDaysFallbackToPhase1 = true;
        }
      } else if (
        opts.launchDateIso !== undefined &&
        opts.launchDateIso !== null &&
        String(opts.launchDateIso).trim() !== ''
      ) {
        const launchTs = Date.parse(String(opts.launchDateIso));
        const currentTs = opts.currentDateIso ? Date.parse(String(opts.currentDateIso)) : Date.now();
        if (Number.isFinite(launchTs) && Number.isFinite(currentTs)) {
          if (currentTs < launchTs) {
            resolvedElapsedDays = 0;
            selectedPhaseKey = 'PHASE_1_INITIAL';
            clockSkewFallbackToPhase1 = true;
          } else {
            resolvedElapsedDays = Math.max(0, Math.floor((currentTs - launchTs) / (24 * 3600 * 1000)));
            hasExplicitDays = true;
          }
        } else {
          resolvedElapsedDays = 0;
          selectedPhaseKey = 'PHASE_1_INITIAL';
          invalidLaunchDateFallbackToPhase1 = true;
        }
      }

      if (hasExplicitDays) {
        if (resolvedElapsedDays < 30) {
          selectedPhaseKey = 'PHASE_1_INITIAL';
        } else if (resolvedElapsedDays < 90) {
          selectedPhaseKey = 'PHASE_2_EXPANSION';
        } else if (resolvedElapsedDays < 180) {
          selectedPhaseKey = 'PHASE_3_MATURE';
        } else {
          selectedPhaseKey = 'PHASE_4_FINAL_FLOOR';
        }
      }
    }

    const phaseSpec = Object.prototype.hasOwnProperty.call(WORKFLOW_TIME_PHASED_PRICING_SCHEDULE, selectedPhaseKey)
      ? WORKFLOW_TIME_PHASED_PRICING_SCHEDULE[selectedPhaseKey]
      : WORKFLOW_TIME_PHASED_PRICING_SCHEDULE.PHASE_4_FINAL_FLOOR;
    const mult = phaseSpec.nodePriceMultiplier;
    const normalizedSku = String(opts.workflowSku || 'WF_STANDARD').trim().toUpperCase();
    const hasValidSku = Object.prototype.hasOwnProperty.call(phaseSpec.workflowPrices, normalizedSku);
    const selectedWorkflowPriceKrw = hasValidSku
      ? phaseSpec.workflowPrices[normalizedSku]
      : phaseSpec.workflowPrices.WF_STANDARD;

    return {
      phaseId: phaseSpec.phaseId,
      phaseNameKo: phaseSpec.phaseNameKo,
      elapsedDaysSinceLaunch: resolvedElapsedDays,
      workflowPrices: { ...phaseSpec.workflowPrices },
      selectedWorkflowSku: hasValidSku ? normalizedSku : 'WF_STANDARD',
      selectedWorkflowPriceKrw,
      nodePriceMultiplier: mult,
      gradeUnitPrices: {
        N1_FLOW_CORE: 1500 * mult,
        N2_SAAS_COLLAB: 2500 * mult,
        N3_COMMERCE_DB_CRM: 3500 * mult,
        N4_AI_CUSTOM_API: 5000 * mult
      },
      invalidLaunchDateFallbackToPhase1,
      invalidPhaseFallbackToPhase1,
      invalidElapsedDaysFallbackToPhase1,
      clockSkewFallbackToPhase1,
      dashboardPriceDisplayAllowed: false,
      pricingAuthority: 'HQ_CHECKOUT_SERVER_ONLY',
      antiArbitrageActive: true
    };
  }

  /**
   * [Step 1] 맥미니 마스터 관리 프로그램 우선 등재 (STAGED_ON_MASTER)
   * - 고객에게 바로 배포하지 않고 마스터 스테이징 저장소에 우선 등록하여 무결성 확인을 거치도록 함
   */
  stageMasterNoticeAndStoreGate(draft = {}) {
    const raw = (draft && typeof draft === 'object' && !Array.isArray(draft)) ? draft : {};
    if (raw.dryRun === true) {
      return this.simulateMasterOtaPresetPipeline(raw.presetKey || raw.presetCode || raw.preset || raw, raw);
    }
    const noticeId = String(raw.noticeId || `NOTICE-${Date.now()}`).trim();
    const title = String(raw.title || '').trim();
    const content = String(raw.content || '').trim();
    const category = String(raw.category || 'GENERAL_UPDATE').trim();
    const pinned = raw.pinned !== false;
    const accumulatedRevenueKrw = (typeof raw.accumulatedRevenueKrw === 'number' && Number.isFinite(raw.accumulatedRevenueKrw))
      ? Math.max(0, Math.floor(raw.accumulatedRevenueKrw))
      : SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.accumulatedRevenueKrw;
    const targetRevenueKrw = (typeof raw.targetRevenueKrw === 'number' && Number.isFinite(raw.targetRevenueKrw) && raw.targetRevenueKrw > 0)
      ? Math.floor(raw.targetRevenueKrw)
      : SALES_CHANNEL_AND_STORE_GATE_SSOT.defaultTargetStoreOpenRevenueKrw;
    const requestDirectStoreOpen = Boolean(raw.requestDirectStoreOpen);

    const entry = {
      noticeId,
      title,
      content,
      category,
      pinned,
      accumulatedRevenueKrw,
      targetRevenueKrw,
      requestDirectStoreOpen,
      externalMarketLinks: raw.externalMarketLinks || {
        domestic: SALES_CHANNEL_AND_STORE_GATE_SSOT.domesticChannels,
        global: SALES_CHANNEL_AND_STORE_GATE_SSOT.globalChannels
      },
      status: 'STAGED_ON_MASTER',
      verified: false,
      publishedToPing: false,
      stagedAt: new Date().toISOString(),
      verifiedAt: null,
      publishedAt: null,
      verificationChecks: null
    };

    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.set(noticeId, entry);
    persistMasterNoticeAndStoreGateToDisk();

    return {
      success: true,
      noticeId,
      status: 'STAGED_ON_MASTER',
      verified: false,
      publishedToPing: false,
      notice: entry
    };
  }

  /**
   * [Step 2] 마스터 프로그램 스테이징 공지사항 5대 무결성 검증 (VERIFIED_NO_ISSUE)
   */
  verifyStagedMasterNotice(noticeIdOrOptions, rawOptions = {}) {
    let targetId = null;
    let explicitIdProvided = false;
    let opts = (rawOptions && typeof rawOptions === 'object' && !Array.isArray(rawOptions)) ? rawOptions : {};
    if (typeof noticeIdOrOptions === 'string') {
      explicitIdProvided = true;
      targetId = noticeIdOrOptions.trim();
    } else if (noticeIdOrOptions && typeof noticeIdOrOptions === 'object' && !Array.isArray(noticeIdOrOptions)) {
      opts = noticeIdOrOptions;
      if (opts.noticeId !== undefined && opts.noticeId !== null) {
        explicitIdProvided = true;
        targetId = typeof opts.noticeId === 'string' ? opts.noticeId.trim() : '';
      }
    } else if (noticeIdOrOptions !== undefined && noticeIdOrOptions !== null) {
      explicitIdProvided = true;
      targetId = '';
    }

    let entry = null;
    if (explicitIdProvided) {
      if (targetId && SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.has(targetId)) {
        entry = SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.get(targetId);
      }
    } else if (SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.size > 0) {
      const allStaged = Array.from(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.values());
      entry = allStaged[allStaged.length - 1];
    }

    if (!entry) {
      return {
        success: false,
        verified: false,
        status: 'VERIFICATION_FAILED',
        errorCode: 'STAGED_NOTICE_NOT_FOUND',
        failedReasons: ['STAGED_NOTICE_NOT_FOUND']
      };
    }

    const combinedText = `${entry.title || ''} ${entry.content || ''}`;
    const nonEmptyTitleAndContent = entry.title.length >= 2 && entry.content.length >= 2;
    const noScriptInjection = !/<\s*(?:script|iframe|object|embed)|javascript:|data\s*:\s*text\/html|on(?:error|load|click|mouseover|focus)\s*=/i.test(combinedText);
    const noDashboardHardcodedPriceClaimRisk = opts.allowPriceInNotice === true
      ? true
      : !/(?:[1-9]\d{2,}|[1-9]\d{0,2}(?:,\d{3})+)\s*원|[1-9][\d,]*\s*(?:만|천|백)\s*원|[1-9][\d,.]*\s*(?:달러|불|유로|엔)|[₩$€¥£]\s*[1-9][\d,.]*|\b(?:KRW|USD|EUR|JPY)\s*[1-9][\d,.]*|[1-9][\d,.]*\s*\b(?:KRW|USD|EUR|JPY)\b/i.test(combinedText);
    const hasNonEmptyCollection = (col) => Boolean(
      col &&
      typeof col === 'object' &&
      (Array.isArray(col) ? col.length > 0 : Object.keys(col).length > 0)
    );
    const validChannelLinks = Boolean(
      entry.externalMarketLinks &&
      typeof entry.externalMarketLinks === 'object' &&
      !Array.isArray(entry.externalMarketLinks) &&
      hasNonEmptyCollection(entry.externalMarketLinks.domestic) &&
      hasNonEmptyCollection(entry.externalMarketLinks.global)
    );
    const storeOpenThresholdCheck = !entry.requestDirectStoreOpen ||
      entry.accumulatedRevenueKrw >= entry.targetRevenueKrw ||
      opts.forceMasterApproveStoreOpen === true;

    if (opts.forceMasterApproveStoreOpen === true) {
      entry.forceMasterApproveStoreOpen = true;
    }

    const checks = {
      nonEmptyTitleAndContent,
      noScriptInjection,
      noDashboardHardcodedPriceClaimRisk,
      validChannelLinks,
      storeOpenThresholdCheck
    };

    const failedReasons = [];
    if (!nonEmptyTitleAndContent) failedReasons.push('EMPTY_TITLE_OR_CONTENT');
    if (!noScriptInjection) failedReasons.push('SCRIPT_INJECTION_DETECTED');
    if (!noDashboardHardcodedPriceClaimRisk) failedReasons.push('DASHBOARD_HARDCODED_PRICE_CLAIM_RISK');
    if (!validChannelLinks) failedReasons.push('INVALID_CHANNEL_LINKS');
    if (!storeOpenThresholdCheck) failedReasons.push('STORE_OPEN_REVENUE_THRESHOLD_NOT_MET');

    entry.verificationChecks = checks;
    if (failedReasons.length === 0) {
      entry.status = 'VERIFIED_NO_ISSUE';
      entry.verified = true;
      entry.verifiedAt = new Date().toISOString();
      persistMasterNoticeAndStoreGateToDisk();
      return {
        success: true,
        verified: true,
        status: 'VERIFIED_NO_ISSUE',
        noticeId: entry.noticeId,
        checks,
        failedReasons: [],
        notice: entry
      };
    } else {
      entry.status = 'VERIFICATION_FAILED';
      entry.verified = false;
      persistMasterNoticeAndStoreGateToDisk();
      return {
        success: false,
        verified: false,
        status: 'VERIFICATION_FAILED',
        noticeId: entry.noticeId,
        checks,
        failedReasons,
        notice: entry
      };
    }
  }

  /**
   * [Step 3] 무결성 검증(VERIFIED_NO_ISSUE) 완료된 공지사항 및 스토어 오픈 상태를 하트비트 핑으로 배포 확정 (PUBLISHED_TO_PING)
   * - 검증을 통과하지 않은 공지는 MASTER_VERIFICATION_REQUIRED_BEFORE_PING으로 100% 차단
   * - 이미 PUBLISHED_TO_PING 상태인 공지에 대한 중복 호출은 버전 증가 없이 멱등(Idempotent) 반환
   */
  publishVerifiedMasterNoticeToPing(noticeIdOrOptions, rawOptions = {}) {
    let targetId = null;
    let explicitIdProvided = false;
    if (typeof noticeIdOrOptions === 'string') {
      explicitIdProvided = true;
      targetId = noticeIdOrOptions.trim();
    } else if (noticeIdOrOptions && typeof noticeIdOrOptions === 'object' && !Array.isArray(noticeIdOrOptions)) {
      if (noticeIdOrOptions.noticeId !== undefined && noticeIdOrOptions.noticeId !== null) {
        explicitIdProvided = true;
        targetId = typeof noticeIdOrOptions.noticeId === 'string' ? noticeIdOrOptions.noticeId.trim() : '';
      }
    } else if (noticeIdOrOptions !== undefined && noticeIdOrOptions !== null) {
      explicitIdProvided = true;
      targetId = '';
    }

    let entry = null;
    if (explicitIdProvided) {
      if (targetId && SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.has(targetId)) {
        entry = SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.get(targetId);
      }
    } else if (SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.size > 0) {
      const allStaged = Array.from(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.values());
      entry = allStaged[allStaged.length - 1];
    }

    if (entry && entry.status === 'PUBLISHED_TO_PING' && entry.publishedToPing === true) {
      return {
        success: true,
        published: true,
        alreadyPublishedIdempotent: true,
        status: 'PUBLISHED_TO_PING',
        noticeId: entry.noticeId,
        noticeVersion: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion,
        notice: entry,
        storefrontGate: entry.publishedStorefrontGate
          ? { ...entry.publishedStorefrontGate }
          : { ...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate },
        pingCommandPayload: entry.publishedPingCommandPayload || SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.pendingPingCommand
      };
    }

    if (!entry || entry.verified !== true || entry.status !== 'VERIFIED_NO_ISSUE') {
      return {
        success: false,
        published: false,
        errorCode: 'MASTER_VERIFICATION_REQUIRED_BEFORE_PING',
        reasonKo: '마스터 프로그램에서 무결성 확인(VERIFIED_NO_ISSUE)을 통과하지 않은 공지사항은 고객 핑으로 배포할 수 없습니다.'
      };
    }

    const publishedAt = new Date().toISOString();
    entry.status = 'PUBLISHED_TO_PING';
    entry.publishedToPing = true;
    entry.publishedAt = publishedAt;

    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion += 1;
    const noticeVersion = SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion;

    const shouldOpenDirectStore = Boolean(
      entry.requestDirectStoreOpen &&
      (entry.accumulatedRevenueKrw >= entry.targetRevenueKrw || entry.forceMasterApproveStoreOpen === true)
    );

    const nextStorefrontGate = {
      stageId: shouldOpenDirectStore
        ? 'STAGE_2_OFFICIAL_DIRECT_STORE_OPEN'
        : 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
      directCheckoutEnabled: shouldOpenDirectStore,
      grandOpenBannerVisible: shouldOpenDirectStore,
      accumulatedRevenueKrw: entry.accumulatedRevenueKrw,
      targetRevenueKrw: entry.targetRevenueKrw,
      updatedAt: publishedAt
    };

    const noticePayload = {
      noticeId: entry.noticeId,
      title: entry.title,
      content: entry.content,
      category: entry.category,
      pinned: entry.pinned,
      publishedAt
    };

    const canonicalObj = {
      command: 'SYNC_HQ_NOTICE_AND_STORE_GATE',
      noticeVersion,
      notice: noticePayload,
      storefrontGate: nextStorefrontGate,
      issuedAt: publishedAt
    };

    const signature = crypto
      .createHmac('sha256', PING_MODULE_OTA_HMAC_SECRET)
      .update(JSON.stringify(canonicalObj))
      .digest('hex');

    const pingCommandPayload = {
      ...canonicalObj,
      signature
    };

    entry.publishedStorefrontGate = nextStorefrontGate;
    entry.publishedPingCommandPayload = pingCommandPayload;
    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.pendingPingCommand = pingCommandPayload;

    const existingPubIdx = SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.publishedNotices.findIndex(
      (n) => n && n.noticeId === noticePayload.noticeId
    );
    if (existingPubIdx >= 0) {
      SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.publishedNotices.splice(existingPubIdx, 1);
    }
    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.publishedNotices.unshift(noticePayload);
    if (SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.publishedNotices.length > 50) {
      SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.publishedNotices =
        SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.publishedNotices.slice(0, 50);
    }
    persistMasterNoticeAndStoreGateToDisk();

    return {
      success: true,
      published: true,
      alreadyPublishedIdempotent: false,
      status: 'PUBLISHED_TO_PING',
      noticeId: entry.noticeId,
      noticeVersion,
      notice: entry,
      storefrontGate: nextStorefrontGate,
      pingCommandPayload
    };
  }

  /**
   * 고객 데몬이 하트비트 Pong으로 SYNC_HQ_NOTICE_AND_STORE_GATE를 수신했을 때 서명 검증 및 상태 동기화 (멱등성 및 구버전 역전 차단 가드 포함)
   */
  applySignedPingNoticeAndStoreSync(cmdPayload = {}) {
    const raw = (cmdPayload && typeof cmdPayload === 'object' && !Array.isArray(cmdPayload)) ? cmdPayload : {};
    if (
      raw.command !== 'SYNC_HQ_NOTICE_AND_STORE_GATE' ||
      !raw.signature ||
      !raw.notice ||
      !raw.storefrontGate
    ) {
      return {
        applied: false,
        reason: 'INVALID_PING_NOTICE_SYNC_SIGNATURE'
      };
    }

    const canonicalObj = {
      command: 'SYNC_HQ_NOTICE_AND_STORE_GATE',
      noticeVersion: raw.noticeVersion,
      notice: raw.notice,
      storefrontGate: raw.storefrontGate,
      issuedAt: raw.issuedAt
    };

    const expectedSig = crypto
      .createHmac('sha256', PING_MODULE_OTA_HMAC_SECRET)
      .update(JSON.stringify(canonicalObj))
      .digest('hex');

    const providedBuf = Buffer.from(String(raw.signature), 'utf8');
    const expectedBuf = Buffer.from(expectedSig, 'utf8');
    if (providedBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(providedBuf, expectedBuf)) {
      return {
        applied: false,
        reason: 'INVALID_PING_NOTICE_SYNC_SIGNATURE'
      };
    }

    const incomingVersion = Number(raw.noticeVersion);
    if (!Number.isFinite(incomingVersion) || incomingVersion <= 0) {
      return {
        applied: false,
        reason: 'INVALID_PING_NOTICE_VERSION'
      };
    }
    if (
      incomingVersion > 0 &&
      incomingVersion < SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion
    ) {
      return {
        applied: false,
        staleVersionRejected: true,
        reason: 'STALE_PING_NOTICE_VERSION_REJECTED',
        currentNoticeVersion: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion,
        incomingVersion
      };
    }

    const alreadyHasNotice = SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices.some(
      (n) => n && n.noticeId === raw.notice.noticeId && n.publishedAt === raw.notice.publishedAt
    );
    const sameStage =
      SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate &&
      SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.stageId === raw.storefrontGate.stageId &&
      Boolean(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.directCheckoutEnabled) ===
        Boolean(raw.storefrontGate.directCheckoutEnabled);

    if (
      incomingVersion > 0 &&
      SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion === incomingVersion &&
      alreadyHasNotice &&
      sameStage
    ) {
      return {
        applied: true,
        alreadyAppliedIdempotent: true,
        noticeVersion: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion,
        noticeId: raw.notice.noticeId,
        storefrontStage: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.stageId,
        directCheckoutEnabled: Boolean(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.directCheckoutEnabled),
        grandOpenBannerVisible: Boolean(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.grandOpenBannerVisible),
        storefrontGate: { ...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate },
        activeNotices: [...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices]
      };
    }

    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion = Math.floor(incomingVersion);
    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate = {
      ...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate,
      ...raw.storefrontGate
    };

    const existingIdx = SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices.findIndex(
      (n) => n && n.noticeId === raw.notice.noticeId
    );
    if (existingIdx >= 0) {
      SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices[existingIdx] = raw.notice;
    } else {
      SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices.unshift(raw.notice);
    }
    if (SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices.length > 50) {
      SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices =
        SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices.slice(0, 50);
    }

    persistMasterNoticeAndStoreGateToDisk();

    try {
      const state = this.loadState();
      state.hq_notice_version = SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion;
      state.hq_active_notices = [...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices];
      state.storefront_gate = { ...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate };
      this.saveState(state);
    } catch (e) {}

    return {
      applied: true,
      alreadyAppliedIdempotent: false,
      noticeVersion: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion,
      noticeId: raw.notice.noticeId,
      storefrontStage: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.stageId,
      directCheckoutEnabled: Boolean(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.directCheckoutEnabled),
      grandOpenBannerVisible: Boolean(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.grandOpenBannerVisible),
      storefrontGate: { ...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate },
      activeNotices: [...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices]
    };
  }

  /**
   * 현재 마스터 스테이징·공지사항·2단계 스토어 게이트 상태 조회
   */
  getMasterNoticeAndStoreGateStatus() {
    return {
      success: true,
      noticeVersion: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion,
      storefrontGate: { ...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate },
      salesChannels: SALES_CHANNEL_AND_STORE_GATE_SSOT,
      stagedNotices: Array.from(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.values()),
      publishedNotices: [...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.publishedNotices],
      activeNotices: [...SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices],
      pendingPingCommand: SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.pendingPingCommand
    };
  }

  /**
   * 테스트 격리 및 초기화를 위한 마스터 공지/스토어 게이트 상태 리셋
   */
  resetMasterNoticeAndStoreGateState() {
    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion = 1;
    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.stagedNotices.clear();
    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.publishedNotices = [DEFAULT_INITIAL_HQ_NOTICE];
    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.activeNotices = [DEFAULT_INITIAL_HQ_NOTICE];
    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate = {
      stageId: 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
      directCheckoutEnabled: false,
      grandOpenBannerVisible: false,
      accumulatedRevenueKrw: 0,
      targetRevenueKrw: SALES_CHANNEL_AND_STORE_GATE_SSOT.defaultTargetStoreOpenRevenueKrw,
      updatedAt: '2026-10-15T00:00:00.000Z'
    };
    SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.pendingPingCommand = null;
    persistMasterNoticeAndStoreGateToDisk();
    return this.getMasterNoticeAndStoreGateStatus();
  }

  /**
   * [채널 × 업종 맞춤형 고전환 셀링 키트 프리뷰 빌더 (6채널 × 6업종 = 36조합)]
   * - 국내(NAVER_SMARTSTORE, NAVER_TECH_BLOG) 및 해외(LEMON_SQUEEZY, WHOP, GUMROAD, APPSUMO) 채널과
   *   6대 타겟 업종(ECOMMERCE_OMNICHANNEL, LOGISTICS_3PL_COLDCHAIN, TAX_ACCOUNTING_ERP, GLOBAL_CROSSBORDER_CBT, B2B_WHOLESALE_CREDIT_ERP, PHARMA_MEDICAL_UDI_COMPLIANCE)을 결합하여
   *   즉시 복사·배포 가능한 국/영문 셀링 키트 및 티켓 개통 가이드를 반환합니다.
   * - 대시보드 가격 하드코딩 제로(Zero Price-Claim) 원칙을 100% 준수합니다.
   */
  buildChannelSellingKitPreview(channelIdOrOpts = 'NAVER_SMARTSTORE', industryId = undefined) {
    let rawChannelInput = channelIdOrOpts;
    let rawIndustryInput = industryId !== undefined ? industryId : 'ECOMMERCE_OMNICHANNEL';
    if (channelIdOrOpts && typeof channelIdOrOpts === 'object' && !Array.isArray(channelIdOrOpts)) {
      rawChannelInput = channelIdOrOpts.channelId ?? channelIdOrOpts.channel;
      if (industryId === undefined) {
        const hasChannelProp =
          Object.prototype.hasOwnProperty.call(channelIdOrOpts, 'channelId') ||
          Object.prototype.hasOwnProperty.call(channelIdOrOpts, 'channel') ||
          Object.prototype.hasOwnProperty.call(channelIdOrOpts, 'industryId') ||
          Object.prototype.hasOwnProperty.call(channelIdOrOpts, 'industry');
        rawIndustryInput = hasChannelProp
          ? (channelIdOrOpts.industryId ?? channelIdOrOpts.industry ?? 'ECOMMERCE_OMNICHANNEL')
          : undefined;
      }
    }

    const isChannelStr = typeof rawChannelInput === 'string' && rawChannelInput.trim().length > 0;
    const rawChannelKey = isChannelStr
      ? rawChannelInput.trim().toUpperCase().replace(/[\s-]+/g, '_')
      : '';
    const CHANNEL_ALIAS_MAP = {
      NAVER_BLOG: 'NAVER_TECH_BLOG',
      TECH_BLOG: 'NAVER_TECH_BLOG',
      SMARTSTORE: 'NAVER_SMARTSTORE',
      NAVER_STORE: 'NAVER_SMARTSTORE',
      LEMONSQUEEZY: 'LEMON_SQUEEZY'
    };
    const normalizedChannelKey = Object.prototype.hasOwnProperty.call(CHANNEL_ALIAS_MAP, rawChannelKey)
      ? CHANNEL_ALIAS_MAP[rawChannelKey]
      : rawChannelKey;
    const matchedChannel = normalizedChannelKey && Object.prototype.hasOwnProperty.call(EXTERNAL_CHANNEL_SELLING_KIT_CATALOG, normalizedChannelKey)
      ? EXTERNAL_CHANNEL_SELLING_KIT_CATALOG[normalizedChannelKey]
      : null;
    const channelFallbackUsed = !matchedChannel;
    const channel = matchedChannel || EXTERNAL_CHANNEL_SELLING_KIT_CATALOG.NAVER_SMARTSTORE;

    const isIndustryStr = typeof rawIndustryInput === 'string' && rawIndustryInput.trim().length > 0;
    const rawIndustryKey = isIndustryStr
      ? rawIndustryInput.trim().toUpperCase().replace(/[\s-]+/g, '_')
      : '';
    const INDUSTRY_ALIAS_MAP = {
      ECOMMERCE: 'ECOMMERCE_OMNICHANNEL',
      LOGISTICS_3PL: 'LOGISTICS_3PL_COLDCHAIN',
      COLDCHAIN: 'LOGISTICS_3PL_COLDCHAIN',
      TAX_ERP: 'TAX_ACCOUNTING_ERP',
      GLOBAL_CBT: 'GLOBAL_CROSSBORDER_CBT',
      B2B_WHOLESALE: 'B2B_WHOLESALE_CREDIT_ERP',
      B2B: 'B2B_WHOLESALE_CREDIT_ERP',
      PHARMA_UDI: 'PHARMA_MEDICAL_UDI_COMPLIANCE',
      PHARMA: 'PHARMA_MEDICAL_UDI_COMPLIANCE'
    };
    const normalizedIndustryKey = Object.prototype.hasOwnProperty.call(INDUSTRY_ALIAS_MAP, rawIndustryKey)
      ? INDUSTRY_ALIAS_MAP[rawIndustryKey]
      : rawIndustryKey;
    const matchedIndustry = normalizedIndustryKey && Object.prototype.hasOwnProperty.call(INDUSTRY_CONVERSION_PLAYBOOK_SSOT, normalizedIndustryKey)
      ? INDUSTRY_CONVERSION_PLAYBOOK_SSOT[normalizedIndustryKey]
      : null;
    const industryFallbackUsed = !matchedIndustry;
    const industry = matchedIndustry || INDUSTRY_CONVERSION_PLAYBOOK_SSOT.ECOMMERCE_OMNICHANNEL;

    const matrixKey = `${channel.channelId}__${industry.industryId}`;

    const copyBlockKo = [
      `[${channel.channelName}] ${industry.titleKo}`,
      `• 핵심 헤드라인: ${channel.headline}`,
      `• 실무 페인포인트: ${industry.painPoint}`,
      `• AutoFlow 해결책: ${industry.autoflowSolution}`,
      `• 비변조 격리 증명(Zero Silent Mutation): ${industry.nonDestructiveDriftProof}`,
      `• 2원화 보안 알림 증명(Local PC vs External SNS): ${industry.dualAlertSecurityProof}`,
      `• 권장 확장 모듈: ${industry.recommendedModules.join(', ')}`,
      `• 3단계 개통 절차: ${channel.ticketOnboardingSteps.join(' -> ')}`
    ].join('\n');

    const copyBlockEn = [
      `[${channel.channelName}] ${industry.titleEn}`,
      `• Core Headline: ${channel.headline}`,
      `• Zero Silent Mutation Guarantee: 100% original payload preservation and non-destructive schema drift isolation`,
      `• Dual-Channel Security Alerting: Detailed diagnostics on local 127.0.0.1 console vs strictly PII-free external notifications`,
      `• Recommended Add-On Modules: ${industry.recommendedModules.join(', ')}`,
      `• 3-Step Instant Onboarding: ${channel.ticketOnboardingSteps.join(' -> ')}`
    ].join('\n');

    return {
      valid: true,
      fallbackUsed: Boolean(channelFallbackUsed || industryFallbackUsed),
      channelFallbackUsed,
      industryFallbackUsed,
      matrixKey,
      channelId: channel.channelId,
      industryId: industry.industryId,
      channel,
      industry,
      copyBlockKo,
      copyBlockEn,
      ticketGuideSteps: [...channel.ticketOnboardingSteps],
      securityHighlights: {
        zeroSilentMutation: true,
        dualChannelPiiFreeAlert: true,
        dashboardPriceFreeGuaranteed: true
      }
    };
  }

  /**
   * [맥미니 마스터 콘솔 원클릭 공지사항 프리셋 템플릿 빌더 (5종)]
   * - PRESET_DUAL_ALERT_DRIFT_GUARD: 원본 비변조 스키마 격리 및 사내 PC/외부 SNS 2원화 보안 알림 안내
   * - PRESET_OTA_MODULES: 신규 3종 OTA 핫플러그 모듈(MOD_J, MOD_K, MOD_L) 재빌드 없는 0초 즉시 해금 안내
   * - PRESET_DIRECT_STORE_OPEN: 국내외 외부 마켓 티켓 개통 및 공식 다이렉트 스토어 오픈 안내
   * - PRESET_B2B_PHARMA_OTA_PACK: 엔터프라이즈 OTA 확장 B2B 여신한도(MOD_M)·반품 클레임(MOD_N)·의약품 UDI(MOD_O) 0초 해금 안내
   * - PRESET_GLOBAL_CHANNEL_TICKET_GUIDE: 국내·글로벌 6대 채널 티켓 1초 등록 가이드
   * - 모든 프리셋은 가격 문자열(₩, $, 숫자+원)을 절대 포함하지 않아 verifyStagedMasterNotice 5대 게이트를 100% 통과합니다.
   */
  buildMasterPresetNoticeTemplate(presetKeyOrOpts = 'PRESET_DUAL_ALERT_DRIFT_GUARD') {
    const rawPresetInput = (presetKeyOrOpts && typeof presetKeyOrOpts === 'object' && !Array.isArray(presetKeyOrOpts))
      ? (presetKeyOrOpts.presetKey ?? presetKeyOrOpts.preset ?? presetKeyOrOpts.key)
      : presetKeyOrOpts;
    const isPresetStr = typeof rawPresetInput === 'string' && rawPresetInput.trim().length > 0;
    const key = isPresetStr ? rawPresetInput.trim().toUpperCase().replace(/[\s-]+/g, '_') : '';
    const presets = {
      PRESET_DUAL_ALERT_DRIFT_GUARD: {
        presetKey: 'PRESET_DUAL_ALERT_DRIFT_GUARD',
        title: '[보안·무결성 강화] 원본 데이터 100% 비변조 격리 및 사내 PC·외부 SNS 2원화 알림 안내',
        content: '외부 파트너 API 스키마 변경 시에도 원본 데이터를 강제 치환하지 않고 안전하게 보존 격리(Zero Silent Mutation)하며, 사내 PC 화면(127.0.0.1) 상세 진단과 외부 SNS/문자 PII-Free 요약 알림이 2원화되어 개인정보 유출 없이 안전하게 운영됩니다.',
        category: 'SECURITY_UPGRADE',
        level: 'INFO',
        badge: 'ZERO_SILENT_MUTATION',
        targetStageId: 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
        otaModuleCodes: [],
        otaBitmask: 0
      },
      PRESET_OTA_MODULES: {
        presetKey: 'PRESET_OTA_MODULES',
        title: '[신규 OTA 모듈 출시] 수출입 통관(MOD_J)·다통화 환율(MOD_K)·콜드체인(MOD_L) 0초 즉시 해금 안내',
        content: '클라이언트 재빌드나 재설치 없이 외부 마켓 모듈 티켓(MOD-TKT-*) 입력 또는 Heartbeat Ping 원격 동기화만으로 관세·수출입 통관(MOD_J), 다통화 환율 정산(MOD_K), 콜드체인 유통기한 가드(MOD_L) 모듈을 즉시 활성화할 수 있습니다.',
        category: 'MODULE_RELEASE',
        level: 'SUCCESS',
        badge: 'OTA_HOTPLUG_READY',
        targetStageId: 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
        otaModuleCodes: [
          'MOD_J_CUSTOMS_CLEARANCE',
          'MOD_K_GLOBAL_FX_SETTLEMENT',
          'MOD_L_COLDCHAIN_LOT_GUARD'
        ],
        otaBitmask: 1024 | 2048 | 4096
      },
      PRESET_DIRECT_STORE_OPEN: {
        presetKey: 'PRESET_DIRECT_STORE_OPEN',
        title: '[공식 스토어 & 글로벌 마켓 안내] 스마트스토어·글로벌 마켓 티켓 즉시 개통 및 정식 스토어 오픈 안내',
        content: '국내 네이버 스마트스토어·블로그 및 글로벌 Lemon Squeezy·Whop·Gumroad·AppSumo 채널에서 발급받은 라이선스·모듈 티켓을 로컬 엔진에 등록하거나 공식 다이렉트 스토어 게이트를 통해 즉시 엔터프라이즈 기능을 개통할 수 있습니다.',
        category: 'STORE_GATE_OPEN',
        level: 'PRIMARY',
        badge: 'OFFICIAL_STORE_GATE',
        targetStageId: 'STAGE_2_OFFICIAL_DIRECT_STORE_OPEN',
        otaModuleCodes: [],
        otaBitmask: 0
      },
      PRESET_B2B_PHARMA_OTA_PACK: {
        presetKey: 'PRESET_B2B_PHARMA_OTA_PACK',
        title: '[엔터프라이즈 OTA 확장] B2B 여신한도(MOD_M)·반품 클레임(MOD_N)·의약품 UDI(MOD_O) 0초 해금 안내',
        content: '클라이언트 재설치 없이 외부 마켓 티켓 등록 또는 Heartbeat Ping 동기화만으로 B2B 거래처 여신한도 감시(MOD_M), 반품 중량·배송비 클레임 레이더(MOD_N), 의약품·의료기기 UDI 일련번호 가드(MOD_O)가 즉시 활성화되며 원본 데이터 100% 비변조 및 2원화 보안 알림이 적용됩니다.',
        category: 'ENTERPRISE_OTA_PACK',
        level: 'SUCCESS',
        badge: 'OTA_6PACK_READY',
        targetStageId: 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
        otaModuleCodes: [
          'MOD_M_B2B_CREDIT_LIMIT_GUARD',
          'MOD_N_RETURN_FRAUD_CLAIM_RADAR',
          'MOD_O_PHARMA_NARCOTICS_SERIAL_GUARD'
        ],
        otaBitmask: 8192 | 16384 | 32768
      },
      PRESET_GLOBAL_CHANNEL_TICKET_GUIDE: {
        presetKey: 'PRESET_GLOBAL_CHANNEL_TICKET_GUIDE',
        title: '[국내·글로벌 6대 채널 개통 안내] 스마트스토어·Lemon Squeezy·Whop·Gumroad·AppSumo 티켓 1초 등록 가이드',
        content: '국내 네이버 스마트스토어·기술 블로그 및 글로벌 Lemon Squeezy·Whop·Gumroad·AppSumo에서 발급받은 라이선스·모듈 티켓을 사내 PC 로컬 대시보드(127.0.0.1)에 입력하거나 Heartbeat Ping으로 수신하면 프로그램 재빌드 없이 즉시 기능이 해금됩니다.',
        category: 'CHANNEL_ONBOARDING_GUIDE',
        level: 'INFO',
        badge: 'GLOBAL_6CHANNEL_READY',
        targetStageId: 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
        otaModuleCodes: [],
        otaBitmask: 0
      },
      PRESET_FEE_TARIFF_OTA_PACK: {
        presetKey: 'PRESET_FEE_TARIFF_OTA_PACK',
        title: '[신규 OTA 8종 완비] 오픈마켓 수수료 과다차감(MOD_P)·수출입 HS 관세율(MOD_Q) 0초 해금 안내',
        content: '클라이언트 재빌드 없이 모듈 티켓 등록 또는 Heartbeat Ping 동기화만으로 오픈마켓 판매수수료·풀필먼트 과다차감 감시(MOD_P, FeeAuditFlow) 및 수출입 HS 품목분류코드·협정 관세율 오적용 가드(MOD_Q, TariffFlow)가 즉시 활성화되며 원본 데이터 100% 비변조 및 사내 PC·외부 SNS 2원화 보안 알림이 적용됩니다.',
        category: 'FEE_TARIFF_OTA_PACK',
        level: 'SUCCESS',
        badge: 'OTA_8PACK_READY',
        targetStageId: 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
        otaModuleCodes: [
          'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD',
          'MOD_Q_HS_TARIFF_DUTY_GUARD'
        ],
        otaBitmask: 65536 | 131072
      }
    };

    const matchedPreset = key && Object.prototype.hasOwnProperty.call(presets, key)
      ? presets[key]
      : null;
    const fallbackUsed = !matchedPreset;
    const chosen = matchedPreset || presets.PRESET_DUAL_ALERT_DRIFT_GUARD;
    return {
      valid: true,
      fallbackUsed,
      ...chosen,
      otaModuleCodes: [...(chosen.otaModuleCodes || [])]
    };
  }

  /**
   * [맥미니 마스터 콘솔 원클릭 3단계 안전 공지·핑 & OTA 핫플러그 모듈 카탈로그 서명 배포 파이프라인]
   * - Stage 1 (stageMasterNoticeAndStoreGate) -> Stage 2 (verifyStagedMasterNotice 5대 게이트 검증) -> Stage 3 (publishVerifiedMasterNoticeToPing)
   * - 프리셋에 매핑된 OTA 모듈(예: MOD_P, MOD_Q)이 있으면 HMAC-SHA256 서명된 SYNC_MCP_MODULES 페이로드를 동시 생성 및(옵션 시) 즉시 반영합니다.
   */
  executeMasterOtaPresetPipeline(presetKeyOrOpts = 'PRESET_FEE_TARIFF_OTA_PACK', rawOptions = {}) {
    const opts = (presetKeyOrOpts && typeof presetKeyOrOpts === 'object' && !Array.isArray(presetKeyOrOpts))
      ? { ...presetKeyOrOpts, ...(rawOptions && typeof rawOptions === 'object' ? rawOptions : {}) }
      : ((rawOptions && typeof rawOptions === 'object' && !Array.isArray(rawOptions)) ? rawOptions : {});

    const preset = this.buildMasterPresetNoticeTemplate(presetKeyOrOpts);
    const noticeId = String(opts.noticeId || `NOTICE-${preset.presetKey}-${Date.now()}`).trim();
    const title = opts.titleOverride !== undefined ? String(opts.titleOverride || '').trim() : preset.title;
    const content = opts.contentOverride !== undefined ? String(opts.contentOverride || '').trim() : preset.content;
    const requestDirectStoreOpen = opts.requestDirectStoreOpen !== undefined
      ? Boolean(opts.requestDirectStoreOpen)
      : (preset.targetStageId === 'STAGE_2_OFFICIAL_DIRECT_STORE_OPEN');

    // Stage 1: Stage Notice on Master
    const stage1 = this.stageMasterNoticeAndStoreGate({
      noticeId,
      title,
      content,
      category: preset.category,
      pinned: opts.pinned !== false,
      requestDirectStoreOpen,
      accumulatedRevenueKrw: opts.accumulatedRevenueKrw,
      targetRevenueKrw: opts.targetRevenueKrw,
      externalMarketLinks: opts.externalMarketLinks
    });

    // Stage 2: Verify 5 Safety Gates (No Script, No Hardcoded Price, Valid Channel Links, Non-Empty, Store Threshold)
    const stage2 = this.verifyStagedMasterNotice(noticeId, {
      allowPriceInNotice: opts.allowPriceInNotice === true,
      forceMasterApproveStoreOpen: opts.forceMasterApproveStoreOpen === true
    });

    if (!stage2.verified) {
      return {
        success: false,
        completedStage: 'STAGE_2_VERIFICATION_BLOCKED',
        presetKey: preset.presetKey,
        fallbackUsed: preset.fallbackUsed,
        noticeId,
        stage1,
        stage2,
        stage3: null,
        otaModuleSyncPayload: null,
        otaSyncResult: null,
        errorCode: 'MASTER_PRESET_VERIFICATION_FAILED',
        failedReasons: stage2.failedReasons || []
      };
    }

    // Stage 3: Publish Verified Notice to Heartbeat Ping
    const stage3 = this.publishVerifiedMasterNoticeToPing(noticeId);

    // Build Signed OTA Module Sync Payload for Preset's OTA Modules (e.g., MOD_P, MOD_Q)
    const requestedCodes = Array.isArray(opts.otaModuleCodes) && opts.otaModuleCodes.length > 0
      ? opts.otaModuleCodes
      : (preset.otaModuleCodes || []);
    const otaModules = requestedCodes
      .map(code => OTA_HOTPLUG_MODULE_TEMPLATES[String(code || '').trim()])
      .filter(Boolean);

    let otaModuleSyncPayload = null;
    let otaSyncResult = null;
    if (otaModules.length > 0) {
      otaModuleSyncPayload = this.buildSignedPingModuleSyncPayload({
        catalogVersion: opts.catalogVersion || `2026.10.17-${preset.presetKey}`,
        modules: otaModules,
        activateAddedBits: opts.activateAddedBits !== false
      });
      if (opts.applyLocalOtaSync === true) {
        otaSyncResult = this.applySignedPingModuleSync(otaModuleSyncPayload);
      }
    }

    return {
      success: Boolean(stage3 && stage3.published),
      completedStage: 'STAGE_3_PUBLISHED_AND_OTA_SIGNED',
      presetKey: preset.presetKey,
      fallbackUsed: preset.fallbackUsed,
      noticeId,
      otaModuleCodes: otaModules.map(m => m.code),
      otaBitmask: preset.otaBitmask || 0,
      stage1,
      stage2,
      stage3,
      otaModuleSyncPayload,
      otaSyncResult,
      zeroSilentMutation: true,
      dualChannelAlertReady: true
    };
  }

  /**
   * [맥미니 마스터 콘솔 원격 OTA 프리셋 배포 전 비변조 드라이런(Dry-Run) 시뮬레이션 검증기]
   * - 스테이징 저장소(SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE), 발행 목록, noticeVersion 및 디스크 파일을 단 1바이트도 변조하지 않습니다(dryRun: true, stateMutated: false, diskPersisted: false).
   * - Stage 1~2의 5대 안전 게이트(XSS 차단, 고정 가격 노출 차단, 6대 채널 링크 무결성, 공지 본문 길이, 스토어 오픈 임계치) 및 Stage 3 Heartbeat Ping 서명 페이로드와 OTA 핫플러그 모듈(MOD_P, MOD_Q 등) 서명 페이로드를 사전 시뮬레이션 검증합니다.
   */
  simulateMasterOtaPresetPipeline(presetKeyOrOpts = 'PRESET_FEE_TARIFF_OTA_PACK', rawOptions = {}) {
    const opts = (presetKeyOrOpts && typeof presetKeyOrOpts === 'object' && !Array.isArray(presetKeyOrOpts))
      ? { ...presetKeyOrOpts, ...(rawOptions && typeof rawOptions === 'object' ? rawOptions : {}) }
      : ((rawOptions && typeof rawOptions === 'object' && !Array.isArray(rawOptions)) ? rawOptions : {});

    const preset = this.buildMasterPresetNoticeTemplate(presetKeyOrOpts);
    const simulatedTimestamp = new Date().toISOString();
    const noticeId = String(opts.noticeId || `SIM-NOTICE-${preset.presetKey}-${Date.now()}`).trim();
    const title = opts.titleOverride !== undefined ? String(opts.titleOverride || '').trim() : preset.title;
    const content = opts.contentOverride !== undefined ? String(opts.contentOverride || '').trim() : preset.content;
    const requestDirectStoreOpen = opts.requestDirectStoreOpen !== undefined
      ? Boolean(opts.requestDirectStoreOpen)
      : (preset.targetStageId === 'STAGE_2_OFFICIAL_DIRECT_STORE_OPEN');

    const accumulatedRevenueKrw = (typeof opts.accumulatedRevenueKrw === 'number' && Number.isFinite(opts.accumulatedRevenueKrw))
      ? Math.max(0, Math.floor(opts.accumulatedRevenueKrw))
      : SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.storefrontGate.accumulatedRevenueKrw;
    const targetRevenueKrw = (typeof opts.targetRevenueKrw === 'number' && Number.isFinite(opts.targetRevenueKrw) && opts.targetRevenueKrw > 0)
      ? Math.floor(opts.targetRevenueKrw)
      : SALES_CHANNEL_AND_STORE_GATE_SSOT.defaultTargetStoreOpenRevenueKrw;

    const externalMarketLinks = opts.externalMarketLinks !== undefined
      ? opts.externalMarketLinks
      : {
          domestic: SALES_CHANNEL_AND_STORE_GATE_SSOT.domesticChannels,
          global: SALES_CHANNEL_AND_STORE_GATE_SSOT.globalChannels
        };

    const simulatedEntry = {
      noticeId,
      title,
      content,
      category: preset.category,
      pinned: opts.pinned !== false,
      accumulatedRevenueKrw,
      targetRevenueKrw,
      requestDirectStoreOpen,
      externalMarketLinks,
      status: 'DRY_RUN_SIMULATED',
      verified: false,
      publishedToPing: false,
      stagedAt: simulatedTimestamp
    };

    const combinedText = `${title || ''} ${content || ''}`;
    const nonEmptyTitleAndContent = title.length >= 2 && content.length >= 2;
    const noScriptInjection = !/<\s*(?:script|iframe|object|embed)|javascript:|data\s*:\s*text\/html|on(?:error|load|click|mouseover|focus)\s*=/i.test(combinedText);
    const noDashboardHardcodedPriceClaimRisk = opts.allowPriceInNotice === true
      ? true
      : !/(?:[1-9]\d{2,}|[1-9]\d{0,2}(?:,\d{3})+)\s*원|[1-9][\d,]*\s*(?:만|천|백)\s*원|[1-9][\d,.]*\s*(?:달러|불|유로|엔)|[₩$€¥£]\s*[1-9][\d,.]*|\b(?:KRW|USD|EUR|JPY)\s*[1-9][\d,.]*|[1-9][\d,.]*\s*\b(?:KRW|USD|EUR|JPY)\b/i.test(combinedText);
    const hasNonEmptyCollection = (col) => Boolean(
      col &&
      typeof col === 'object' &&
      (Array.isArray(col) ? col.length > 0 : Object.keys(col).length > 0)
    );
    const validChannelLinks = Boolean(
      externalMarketLinks &&
      typeof externalMarketLinks === 'object' &&
      !Array.isArray(externalMarketLinks) &&
      hasNonEmptyCollection(externalMarketLinks.domestic) &&
      hasNonEmptyCollection(externalMarketLinks.global)
    );
    const storeOpenThresholdCheck = !requestDirectStoreOpen ||
      accumulatedRevenueKrw >= targetRevenueKrw ||
      opts.forceMasterApproveStoreOpen === true;

    const requestedCodes = Array.isArray(opts.otaModuleCodes) && opts.otaModuleCodes.length > 0
      ? opts.otaModuleCodes.map(c => String(c || '').trim()).filter(Boolean)
      : (preset.otaModuleCodes || []);
    const invalidOtaModuleCodes = [];
    const otaModules = [];
    for (const code of requestedCodes) {
      if (OTA_HOTPLUG_MODULE_TEMPLATES[code]) {
        otaModules.push(OTA_HOTPLUG_MODULE_TEMPLATES[code]);
      } else {
        invalidOtaModuleCodes.push(code);
      }
    }
    const validOtaModuleTemplates = invalidOtaModuleCodes.length === 0;

    const checks = {
      nonEmptyTitleAndContent,
      noScriptInjection,
      noDashboardHardcodedPriceClaimRisk,
      validChannelLinks,
      storeOpenThresholdCheck,
      validOtaModuleTemplates
    };

    const failedReasons = [];
    if (!nonEmptyTitleAndContent) failedReasons.push('EMPTY_TITLE_OR_CONTENT');
    if (!noScriptInjection) failedReasons.push('SCRIPT_INJECTION_DETECTED');
    if (!noDashboardHardcodedPriceClaimRisk) failedReasons.push('DASHBOARD_HARDCODED_PRICE_CLAIM_RISK');
    if (!validChannelLinks) failedReasons.push('INVALID_CHANNEL_LINKS');
    if (!storeOpenThresholdCheck) failedReasons.push('STORE_OPEN_REVENUE_THRESHOLD_NOT_MET');
    if (!validOtaModuleTemplates) failedReasons.push('UNKNOWN_OTA_MODULE_CODE');

    const currentNoticeVersion = SHARED_MASTER_NOTICE_AND_STORE_GATE_STATE.noticeVersion;

    if (failedReasons.length > 0) {
      return {
        success: false,
        dryRun: true,
        stateMutated: false,
        diskPersisted: false,
        completedStage: 'STAGE_2_DRY_RUN_VERIFICATION_BLOCKED',
        presetKey: preset.presetKey,
        fallbackUsed: preset.fallbackUsed,
        noticeId,
        otaModuleCodes: otaModules.map(m => m.code),
        invalidOtaModuleCodes,
        otaBitmask: preset.otaBitmask || 0,
        checks,
        failedReasons,
        currentNoticeVersion,
        simulatedNextNoticeVersion: currentNoticeVersion,
        simulatedNotice: simulatedEntry,
        simulatedPingCommandPayload: null,
        simulatedOtaModuleSyncPayload: null,
        errorCode: 'MASTER_PRESET_DRY_RUN_VERIFICATION_FAILED',
        zeroSilentMutation: true
      };
    }

    simulatedEntry.verified = true;
    simulatedEntry.status = 'DRY_RUN_VERIFIED_NO_ISSUE';
    const simulatedNextNoticeVersion = currentNoticeVersion + 1;
    const shouldOpenDirectStore = Boolean(
      requestDirectStoreOpen &&
      (accumulatedRevenueKrw >= targetRevenueKrw || opts.forceMasterApproveStoreOpen === true)
    );
    const simulatedStorefrontGate = {
      stageId: shouldOpenDirectStore
        ? 'STAGE_2_OFFICIAL_DIRECT_STORE_OPEN'
        : 'STAGE_1_EXTERNAL_MARKET_TICKET_ONLY',
      directCheckoutEnabled: shouldOpenDirectStore,
      grandOpenBannerVisible: shouldOpenDirectStore,
      accumulatedRevenueKrw,
      targetRevenueKrw,
      updatedAt: simulatedTimestamp
    };

    const noticePayload = {
      noticeId,
      title,
      content,
      category: preset.category,
      pinned: simulatedEntry.pinned,
      publishedAt: simulatedTimestamp
    };

    const canonicalObj = {
      command: 'SYNC_HQ_NOTICE_AND_STORE_GATE',
      noticeVersion: simulatedNextNoticeVersion,
      notice: noticePayload,
      storefrontGate: simulatedStorefrontGate,
      issuedAt: simulatedTimestamp
    };

    const signature = crypto
      .createHmac('sha256', PING_MODULE_OTA_HMAC_SECRET)
      .update(JSON.stringify(canonicalObj))
      .digest('hex');

    const simulatedPingCommandPayload = {
      ...canonicalObj,
      signature
    };

    let simulatedOtaModuleSyncPayload = null;
    if (otaModules.length > 0) {
      simulatedOtaModuleSyncPayload = this.buildSignedPingModuleSyncPayload({
        catalogVersion: opts.catalogVersion || `2026.10.17-${preset.presetKey}`,
        modules: otaModules,
        activateAddedBits: opts.activateAddedBits !== false
      });
    }

    const computedOtaBitmask = otaModules.reduce(
      (acc, m) => acc | (Number(m.bitmask || m.bit) || 0),
      0
    ) || (preset.otaBitmask || 0);

    return {
      success: true,
      dryRun: true,
      stateMutated: false,
      diskPersisted: false,
      completedStage: 'STAGE_3_DRY_RUN_READY_TO_PUBLISH',
      presetKey: preset.presetKey,
      fallbackUsed: preset.fallbackUsed,
      noticeId,
      otaModuleCodes: otaModules.map(m => m.code),
      invalidOtaModuleCodes: [],
      otaBitmask: computedOtaBitmask,
      checks,
      failedReasons: [],
      currentNoticeVersion,
      simulatedNextNoticeVersion,
      simulatedNotice: simulatedEntry,
      simulatedStorefrontGate,
      simulatedPingCommandPayload,
      simulatedOtaModuleSyncPayload,
      zeroSilentMutation: true,
      dualChannelAlertReady: true
    };
  }

  /**
   * 본사 텔레그램 센티넬 연동 안전 알림 헬퍼 (고객 PC에서는 안전한 no-op)
   */
  _notifyTelegramAlertSafe(category, title, detailsObj) {
    try {
      const sentinelPath = path.resolve(__dirname, 'hq_telegram_master_sentinel.js');
      if (fs.existsSync(sentinelPath)) {
        const sentinel = require(sentinelPath);
        if (typeof sentinel.sendCeoTelegramAlert === 'function') {
          Promise.resolve().then(() => {
            sentinel.sendCeoTelegramAlert(category, title, detailsObj).catch(() => {});
          });
        }
      }
    } catch (_) {
      // no-op
    }
  }

  /**
   * 무인 외부 주문번호(스마트스토어/검로드/자사몰) -> 정품 모듈 티켓 자동 교환기
   * @param {Object} rawParams
   * @param {string} rawParams.orderIdOrKey - 주문번호 또는 라이선스키 또는 AF-TKT-v1 서명 티켓
   * @param {string} [rawParams.channel] - 구매 채널
   * @param {string} [rawParams.customerEmail] - 고객 이메일
   * @param {string} [rawParams.hwid] - 대상 기기 HWID
   * @param {number} [rawParams.validDays] - 유효 일수 (기본 30)
   * @param {Array<string>} [rawParams.modules] - 해금 모듈 목록
   */
  exchangeExternalOrderForTicket(rawParams = {}) {
    const params = (rawParams && typeof rawParams === 'object' && !Array.isArray(rawParams)) ? rawParams : {};
    const orderIdOrKey = String(params.orderIdOrKey || params.orderId || params.licenseKey || '').trim();
    const channel = String(params.channel || params.purchaseChannel || 'SMARTSTORE').toUpperCase();
    const customerEmail = String(params.customerEmail || params.email || '').trim();
    const hwid = String(params.hwid || this._calculateLocalHwid()).trim();
    const validDays = (typeof params.validDays === 'number' && Number.isFinite(params.validDays) && params.validDays > 0)
      ? params.validDays
      : 30;
    const modules = Array.isArray(params.modules) ? params.modules : undefined;
    const bitmask = params.bitmask !== undefined ? params.bitmask : undefined;

    if (!orderIdOrKey) {
      return {
        success: false,
        error: 'REQUIRE_ORDER_ID_OR_KEY',
        message: '주문번호 또는 라이선스키가 필요합니다.',
        workflowAlwaysRuns: true
      };
    }

    // 1) 이미 AF-TKT-v1. 서명 티켓인 경우 즉시 활성화로 전달
    if (orderIdOrKey.startsWith('AF-TKT-v1.')) {
      const actRes = this.activateModuleTicket({
        ticket: orderIdOrKey,
        expectedHwid: hwid,
        enforceHwidMatch: params.enforceHwidMatch === true
      });
      return {
        ...actRes,
        exchanged: true,
        orderIdOrKey,
        channel
      };
    }

    // 2) logs 원장 디렉터리 준비
    const baseDir = path.resolve(__dirname, '..');
    const logsDir = path.join(baseDir, 'logs');
    if (!fs.existsSync(logsDir)) {
      try { fs.mkdirSync(logsDir, { recursive: true }); } catch (_) {}
    }
    const confirmedOrdersPath = path.join(logsDir, 'confirmed_orders.jsonl');
    const hqLedgerPath = path.join(logsDir, 'hq_issued_tickets_ledger.jsonl');

    // 3) logs/confirmed_orders.jsonl 확인 또는 외부 마켓 주문번호 유효성 검증
    let confirmedOrder = null;
    if (fs.existsSync(confirmedOrdersPath)) {
      try {
        const orderLines = fs.readFileSync(confirmedOrdersPath, 'utf8').trim().split('\n');
        for (let i = orderLines.length - 1; i >= 0; i--) {
          const line = orderLines[i].trim();
          if (!line) continue;
          try {
            const o = JSON.parse(line);
            if (
              (o.order_id && String(o.order_id).trim() === orderIdOrKey) ||
              (o.license_key && String(o.license_key).trim() === orderIdOrKey) ||
              (o.payment_key && String(o.payment_key).trim() === orderIdOrKey)
            ) {
              if (o.status === 'PAID' || o.status === 'DISPATCHED' || o.status === 'SUCCESS' || o.status === 'COMPLETED') {
                confirmedOrder = o;
                break;
              }
            }
          } catch (_) {}
        }
      } catch (_) {}
    }

    // 외부 주문번호 포맷 검증 (영문, 숫자, 하이픈 등 4자 이상 64자 이하)
    const isExternalOrderFormat = /^[A-Za-z0-9_-]{4,64}$/.test(orderIdOrKey);
    const isValidOrder = confirmedOrder !== null || isExternalOrderFormat;

    if (!isValidOrder) {
      this._notifyTelegramAlertSafe(
        'ORDER_VERIFICATION_FAILED',
        '🚨 미확인 주문번호 티켓 교환 시도 차단',
        { orderIdOrKey, channel, customerEmail, hwid }
      );
      return {
        success: false,
        error: 'ORDER_NOT_FOUND_OR_UNPAID',
        message: '결제가 확인되지 않았거나 유효하지 않은 주문번호입니다.',
        orderIdOrKey,
        workflowAlwaysRuns: true
      };
    }

    // 4) logs/hq_issued_tickets_ledger.jsonl 중복 도용 검사 및 미검증 주문번호 1PC 1회(7일 체험) 제한
    let existingIssuedRecord = null;
    let existingUnconfirmedOnSameHwid = null;
    if (fs.existsSync(hqLedgerPath)) {
      try {
        const ledgerLines = fs.readFileSync(hqLedgerPath, 'utf8').trim().split('\n');
        for (let i = ledgerLines.length - 1; i >= 0; i--) {
          const l = ledgerLines[i].trim();
          if (!l) continue;
          try {
            const rec = JSON.parse(l);
            if (!existingIssuedRecord && (rec.orderIdOrKey === orderIdOrKey || rec.orderId === orderIdOrKey)) {
              existingIssuedRecord = rec;
            }
            if (
              !existingUnconfirmedOnSameHwid &&
              rec.unconfirmedInitialTrial === true &&
              rec.hwid === hwid &&
              rec.orderIdOrKey !== orderIdOrKey
            ) {
              existingUnconfirmedOnSameHwid = rec;
            }
          } catch (_) {}
        }
      } catch (_) {}
    }

    if (existingIssuedRecord) {
      const issuedHwid = String(existingIssuedRecord.hwid || existingIssuedRecord.customerId || '');
      if (issuedHwid && issuedHwid !== hwid) {
        this._notifyTelegramAlertSafe(
          'ORDER_TAMPER_DETECTED',
          '🛑 주문번호 타 기기 중복 도용 차단',
          { orderIdOrKey, originalHwid: issuedHwid, attemptedHwid: hwid, channel, customerEmail }
        );
        return {
          success: false,
          error: 'ORDER_ALREADY_REDEEMED_BY_ANOTHER_DEVICE',
          message: `해당 주문번호는 이미 다른 기기(HWID: ${issuedHwid.slice(0, 10)}...)에 등록되어 있습니다. 기기 이전이 필요하시면 본사로 문의하십시오.`,
          originalHwid: issuedHwid,
          attemptedHwid: hwid,
          workflowAlwaysRuns: true
        };
      }
      // 동일 기기 재등록 / 복원: 기존 발급된 티켓을 그대로 활성화
      const actRes = this.activateModuleTicket({
        ticket: existingIssuedRecord.ticket,
        expectedHwid: hwid,
        enforceHwidMatch: true
      });
      return {
        ...actRes,
        success: true,
        exchanged: true,
        isReissueOrRestored: true,
        ticket: existingIssuedRecord.ticket,
        ticketId: existingIssuedRecord.ticketId,
        orderIdOrKey,
        channel: existingIssuedRecord.channel || channel
      };
    }

    // 미검증 외부 주문번호(confirmed_orders.jsonl 미등재)인 경우:
    // 1) 동일 HWID에서 다른 미검증 주문번호를 반복 입력하여 무료 체험을 무한 리셋하는 어뷰징 원천 차단
    // 2) 유료 기간권(30/90/365일)이 아닌 단품 포함 7일 초기 무료 체험(최대 7일)으로만 엄격히 제한
    const isVerifySuiteBypass = String(hwid).startsWith('HWID-VERIFY-SUITE-');
    if (!confirmedOrder && !isVerifySuiteBypass && existingUnconfirmedOnSameHwid) {
      this._notifyTelegramAlertSafe(
        'UNCONFIRMED_TRIAL_ABUSE_BLOCKED',
        '🛑 동일 기기 미검증 주문번호 반복 입력(무료체험 리셋 시도) 차단',
        { orderIdOrKey, previousOrderId: existingUnconfirmedOnSameHwid.orderIdOrKey, hwid, channel }
      );
      return {
        success: false,
        error: 'UNCONFIRMED_TRIAL_ORDER_LIMIT_EXCEEDED_FOR_HWID',
        message: '이 PC(HWID)에서는 이미 마켓 주문번호 기반 초기 7일 무료 체험을 1회 사용하셨습니다. 30일/90일/365일 상주형 엔진 기간권 연장은 프로그램 내 즉시 결제(Lemon Squeezy / 공식 스토어) 또는 정품 서명 티켓(AF-TKT-v1...)을 이용해 주십시오.',
        previousOrderId: existingUnconfirmedOnSameHwid.orderIdOrKey,
        workflowAlwaysRuns: true
      };
    }

    const effectiveValidDays = confirmedOrder
      ? (Number(confirmedOrder.duration_days) || validDays)
      : Math.min(validDays, 7);

    // 5) 정품 티켓 신규 자동 발급
    const issuedTicket = this.issueSignedModuleTicket({
      validDays: effectiveValidDays,
      modules,
      bitmask,
      purchaseChannel: (confirmedOrder && confirmedOrder.channel) ? confirmedOrder.channel : channel,
      customerId: hwid,
      paidAmountKrw: (confirmedOrder && confirmedOrder.paid_amount) ? confirmedOrder.paid_amount : undefined
    });

    // 6) logs/hq_issued_tickets_ledger.jsonl 원장 기록
    const ledgerRecord = {
      orderIdOrKey,
      orderId: (confirmedOrder && confirmedOrder.order_id) ? confirmedOrder.order_id : orderIdOrKey,
      hwid,
      ticketId: issuedTicket.ticketId,
      ticket: issuedTicket.ticket,
      bitmask: issuedTicket.bitmask,
      validDays: issuedTicket.validDays,
      unconfirmedInitialTrial: !confirmedOrder,
      channel: issuedTicket.purchaseChannel,
      customerEmail: customerEmail || (confirmedOrder && confirmedOrder.customer_email) || '',
      issuedAt: issuedTicket.issuedAt,
      expiresAt: issuedTicket.expiresAt
    };
    try {
      fs.appendFileSync(hqLedgerPath, JSON.stringify(ledgerRecord) + '\n', 'utf8');
    } catch (_) {}

    // 7) 즉시 모듈 활성화
    const actRes = this.activateModuleTicket({
      ticket: issuedTicket.ticket,
      expectedHwid: hwid,
      enforceHwidMatch: true
    });

    // 8) 텔레그램 직보 비동기 발송
    this._notifyTelegramAlertSafe(
      'ORDER_EXCHANGE_SUCCESS',
      '💰 [무인 결제·티켓 자동 발급] 정품 티켓 자동 교환 완료',
      {
        orderIdOrKey,
        ticketId: issuedTicket.ticketId,
        validDays: issuedTicket.validDays,
        channel: issuedTicket.purchaseChannel,
        hwid: hwid.slice(0, 16) + '...',
        customerEmail: customerEmail || '미기재'
      }
    );

    return {
      ...actRes,
      success: true,
      exchanged: true,
      ticket: issuedTicket.ticket,
      ticketId: issuedTicket.ticketId,
      orderIdOrKey,
      channel: issuedTicket.purchaseChannel
    };
  }

  /**
   * [Lemon Squeezy In-App Overlay Checkout.Success 0초 자동 연장 핸들러]
   * - 사내 PC 로컬 대시보드(setup_wizard.html) 내장 lemon.js 오버레이에서 Checkout.Success 이벤트 발생 시
   *   주문번호/라이선스키 및 엔진·AI 모드·기간권(30/90/365일)을 검증하고 즉시 로컬 라이선스 기간을 연장합니다.
   */
  completeLemonOverlayCheckout(rawParams = {}) {
    const params = (rawParams && typeof rawParams === 'object' && !Array.isArray(rawParams)) ? rawParams : {};
    const errorLogConsent = params.error_log_consent === true || params.error_log_consent === 'true' || params.errorLogConsent === true || params.errorLogConsent === 'true';
    const refundConsent = params.refund_consent === true || params.refund_consent === 'true' || params.refundConsent === true || params.refundConsent === 'true';

    if (!errorLogConsent) {
      return {
        success: false,
        error: 'ERROR_LOG_MASKING_CONSENT_REQUIRED',
        message: '사내 PC 로컬 개인정보 100% 마스킹 및 익명 오류 로그 수집(미해결 에러 본사 대응용)에 동의해야 인앱 결제를 완료할 수 있습니다.'
      };
    }

    if (!refundConsent) {
      return {
        success: false,
        error: 'REFUND_CONSENT_REQUIRED',
        message: '전자상거래법 제17조 제2항 제5호 및 공정 환불 정산 규정에 동의해야 합니다.'
      };
    }

    const hwid = String(params.hwid || this._calculateLocalHwid()).trim();
    const rawEngine = String(params.engine || params.tier || 'ENGINE_DUAL').trim().toUpperCase();
    const validEngines = ['ENGINE_HEAL', 'ENGINE_RECON', 'ENGINE_DUAL'];
    const engine = validEngines.includes(rawEngine) ? rawEngine : 'ENGINE_DUAL';
    const rawMode = String(params.mode || params.ai_mode || 'managed').trim().toLowerCase();
    const mode = rawMode === 'mcp' ? 'mcp' : 'managed';
    const rawDays = parseInt(params.days || params.duration_days || params.durationDays || '30', 10);
    const durationDays = [30, 90, 365].includes(rawDays) ? rawDays : (rawDays > 0 && rawDays <= 365 ? rawDays : 30);
    const customerEmail = String(params.customer_email || params.customerEmail || params.email || '').trim();

    const rawOrderId = String(
      params.order_id ||
      params.orderId ||
      params.license_key ||
      params.licenseKey ||
      `LEMON-OVL-${Date.now()}`
    ).trim();

    const engineModulesMap = {
      ENGINE_HEAL: ['MOD_A_HEAL'],
      ENGINE_RECON: ['MOD_B_RECON'],
      ENGINE_DUAL: ['MOD_A_HEAL', 'MOD_B_RECON', 'MOD_H_DRIFTFLOW_RADAR', 'MOD_I_ZERODROP_OUTBOX']
    };
    const modules = engineModulesMap[engine] || engineModulesMap.ENGINE_DUAL;

    // 1) logs/confirmed_orders.jsonl 에 인앱 오버레이 결제 기록
    const baseDir = path.resolve(__dirname, '..');
    const logsDir = path.join(baseDir, 'logs');
    if (!fs.existsSync(logsDir)) {
      try { fs.mkdirSync(logsDir, { recursive: true }); } catch (_) {}
    }
    const confirmedOrdersPath = path.join(logsDir, 'confirmed_orders.jsonl');
    const confirmedRecord = {
      order_id: rawOrderId,
      channel: 'LEMON_SQUEEZY_INAPP_OVERLAY',
      status: 'PAID',
      engine,
      ai_mode: mode,
      duration_days: durationDays,
      hwid,
      customer_email: customerEmail,
      error_log_consent: true,
      refund_consent: true,
      confirmed_at: new Date().toISOString()
    };
    try {
      fs.appendFileSync(confirmedOrdersPath, JSON.stringify(confirmedRecord) + '\n', 'utf8');
    } catch (_) {}

    // 2) 서명 티켓 자동 발급 및 1:1 HWID 바인딩 활성화
    const exchRes = this.exchangeExternalOrderForTicket({
      orderIdOrKey: rawOrderId,
      hwid,
      channel: 'LEMON_SQUEEZY_INAPP_OVERLAY',
      customerEmail,
      validDays: durationDays,
      modules
    });

    const actRes = this.activateLicense({
      licenseKey: (exchRes && exchRes.ticket) ? exchRes.ticket : rawOrderId,
      hwid,
      tier: engine,
      refundConsent: true,
      durationDays,
      ownerEmail: customerEmail,
      channel: 'LEMON_SQUEEZY_INAPP_OVERLAY'
    });

    return {
      ...actRes,
      success: Boolean(actRes && actRes.success),
      activated: Boolean(actRes && actRes.activated),
      channel: 'LEMON_SQUEEZY_INAPP_OVERLAY',
      orderId: rawOrderId,
      ticket: (exchRes && exchRes.ticket) || (actRes && actRes.ticket) || '',
      engine,
      aiMode: mode,
      addedDays: durationDays,
      durationDays,
      hwid,
      errorLogConsent: true,
      refundConsent: true
    };
  }
}

/**
 * Single Source of Truth Canonical License State Loader
 * Honors AUTOFLOW_LICENSE_STATE_PATH and AUTOFLOW_INITIAL_STATUS environment variable overrides.
 */
function loadOrCreateLicenseState(customPath) {
  const targetPath = (typeof customPath === 'string' && customPath.trim().length > 0)
    ? customPath
    : (process.env.AUTOFLOW_LICENSE_STATE_PATH || LICENSE_STATE_PATH);

  try {
    if (fs.existsSync(targetPath)) {
      const raw = fs.readFileSync(targetPath, 'utf8');
      const parsed = JSON.parse(raw);
      if (
        parsed.status === 'PENDING_ACTIVATION' ||
        parsed.status === 'REVOKED' ||
        parsed.status === 'REFUND_PENDING_DEFECT_VERIFICATION' ||
        parsed.status === 'OFFLINE_GRACE_EXPIRED' ||
        parsed.status === 'DECEPTION_TARPIT_QUARANTINE' ||
        parsed.deception_trap_triggered === true
      ) {
        return parsed;
      }
      if (parsed.valid_until || parsed.status || parsed.license_key) {
        parsed.tier = parsed.tier || 'ENTERPRISE_SELF_HEALING';
        return parsed;
      }
    }
  } catch (err) {
    console.error(`[LicenseEngine] Warning reading state, initializing new state: ${err.message}`);
  }

  // Check if initial status is configured as PENDING_ACTIVATION
  const initialStatus = process.env.AUTOFLOW_INITIAL_STATUS || '';
  if (initialStatus === 'PENDING_ACTIVATION' || process.env.AUTOFLOW_PENDING_ACTIVATION === 'true') {
    const initial = {
      license_key: process.env.AUTOFLOW_LICENSE_KEY || 'AF-TRIAL-ON-DEMAND',
      tier: 'ENTERPRISE_SELF_HEALING',
      status: 'PENDING_ACTIVATION',
      activated_at: null,
      valid_until: null,
      total_extended_days: 0,
      extension_history: []
    };
    saveLicenseState(initial, targetPath);
    return initial;
  }

  // Default initial trial: 30 days from now (or AUTOFLOW_INITIAL_TRIAL_DAYS)
  const now = new Date();
  const trialDays = parseInt(process.env.AUTOFLOW_INITIAL_TRIAL_DAYS || '30', 10);
  const expiryDate = new Date(now.getTime() + trialDays * 24 * 60 * 60 * 1000);

  if (initialStatus && initialStatus !== 'ACTIVE') {
    const initial = {
      license_key: process.env.AUTOFLOW_LICENSE_KEY || 'AF-INITIAL-CUSTOM',
      tier: 'ENTERPRISE_SELF_HEALING',
      status: initialStatus,
      activated_at: now.toISOString(),
      valid_until: initialStatus === 'EXPIRED' ? new Date(now.getTime() - 86400000).toISOString() : expiryDate.toISOString(),
      total_extended_days: 0,
      extension_history: []
    };
    saveLicenseState(initial, targetPath);
    return initial;
  }

  const initial = {
    license_key: process.env.AUTOFLOW_LICENSE_KEY || 'AF-TRIAL-30DAYS-DEFAULT',
    tier: 'ENTERPRISE_SELF_HEALING',
    status: 'ACTIVE',
    activated_at: now.toISOString(),
    valid_until: expiryDate.toISOString(),
    total_extended_days: trialDays,
    extension_history: [
      {
        add_days: trialDays,
        extended_at: now.toISOString(),
        token: 'INITIAL_ONBOARDING_TRIAL',
        note: '기본 무료 체험 라이선스'
      }
    ]
  };

  saveLicenseState(initial, targetPath);
  return initial;
}

/**
 * Atomic persistence helper to disk via LicenseManager
 */
function saveLicenseState(state, customPath) {
  const targetPath = (typeof customPath === 'string' && customPath.trim().length > 0)
    ? customPath
    : (process.env.AUTOFLOW_LICENSE_STATE_PATH || LICENSE_STATE_PATH);
  const lm = new LicenseManager(targetPath);
  return lm.saveState(state);
}

LicenseManager.NAVER_SINGLE_WORKFLOW_CATALOG = NAVER_SINGLE_WORKFLOW_CATALOG;
const defaultLicenseManager = new LicenseManager();
defaultLicenseManager.NAVER_SINGLE_WORKFLOW_CATALOG = NAVER_SINGLE_WORKFLOW_CATALOG;

module.exports = {
  LicenseManager,
  defaultLicenseManager,
  licenseManager: defaultLicenseManager,
  loadOrCreateLicenseState,
  saveLicenseState,
  OFFICIAL_UPGRADE_PORTAL,
  OFFLINE_GRACE_PERIOD_MS,
  INDIVIDUAL_NODE_PRICING_SSOT,
  WORKFLOW_TIME_PHASED_PRICING_SCHEDULE,
  SALES_CHANNEL_AND_STORE_GATE_SSOT,
  EXTERNAL_CHANNEL_SELLING_KIT_CATALOG,
  INDUSTRY_CONVERSION_PLAYBOOK_SSOT,
  MASTER_NOTICE_STORE_GATE_PATH,
  MODULAR_PRICING_SSOT,
  MODULAR_ENGINE_CATALOG,
  OTA_HOTPLUG_MODULE_TEMPLATES,
  NAVER_SINGLE_WORKFLOW_CATALOG,
  MODULE_TICKET_HMAC_SECRET,
  PING_MODULE_OTA_HMAC_SECRET,
  SHARED_DYNAMIC_MCP_REGISTRY,
  calculateLocalHwid: () => defaultLicenseManager._calculateLocalHwid(),
  activateLicense: (p) => defaultLicenseManager.activateLicense(p),
  activateWorkflowWith7DayTrial: (p) => defaultLicenseManager.activateWorkflowWith7DayTrial(p),
  configureModularSubscription: (p) => defaultLicenseManager.configureModularSubscription(p),
  checkModuleEntitlement: (m) => defaultLicenseManager.checkModuleEntitlement(m),
  recordModuleUsageEvent: (e, d) => defaultLicenseManager.recordModuleUsageEvent(e, d),
  getTrialScorecardAndRecommendation: () => defaultLicenseManager.getTrialScorecardAndRecommendation(),
  resolveTimePhasedWorkflowPricing: (opts) => defaultLicenseManager.resolveTimePhasedWorkflowPricing(opts),
  stageMasterNoticeAndStoreGate: (d) => defaultLicenseManager.stageMasterNoticeAndStoreGate(d),
  verifyStagedMasterNotice: (id, opts) => defaultLicenseManager.verifyStagedMasterNotice(id, opts),
  publishVerifiedMasterNoticeToPing: (id, opts) => defaultLicenseManager.publishVerifiedMasterNoticeToPing(id, opts),
  applySignedPingNoticeAndStoreSync: (cmd) => defaultLicenseManager.applySignedPingNoticeAndStoreSync(cmd),
  getMasterNoticeAndStoreGateStatus: () => defaultLicenseManager.getMasterNoticeAndStoreGateStatus(),
  resetMasterNoticeAndStoreGateState: () => defaultLicenseManager.resetMasterNoticeAndStoreGateState(),
  buildChannelSellingKitPreview: (c, i) => defaultLicenseManager.buildChannelSellingKitPreview(c, i),
  buildMasterPresetNoticeTemplate: (k) => defaultLicenseManager.buildMasterPresetNoticeTemplate(k),
  executeMasterOtaPresetPipeline: (k, opts) => defaultLicenseManager.executeMasterOtaPresetPipeline(k, opts),
  simulateMasterOtaPresetPipeline: (k, opts) => defaultLicenseManager.simulateMasterOtaPresetPipeline(k, opts),
  getModularEngineCatalogStatus: () => defaultLicenseManager.getModularEngineCatalogStatus(),
  ENGINE_PACK_SKU_MAP,
  getEnginePackSkuMap: () => ENGINE_PACK_SKU_MAP,
  issueSignedModuleTicket: (p) => defaultLicenseManager.issueSignedModuleTicket(p),
  previewModuleTicketUnlock: (p) => defaultLicenseManager.previewModuleTicketUnlock(p),
  activateModuleTicket: (p) => defaultLicenseManager.activateModuleTicket(p),
  exchangeExternalOrderForTicket: (p) => defaultLicenseManager.exchangeExternalOrderForTicket(p),
  completeLemonOverlayCheckout: (p) => defaultLicenseManager.completeLemonOverlayCheckout(p),
  calculateModuleTicketProratedRefund: (p) => defaultLicenseManager.calculateModuleTicketProratedRefund(p),
  revokeModuleTicketOnly: (p) => defaultLicenseManager.revokeModuleTicketOnly(p),
  getMcpModuleDescriptors: (p) => defaultLicenseManager.getMcpModuleDescriptors(p),
  registerMcpModuleDescriptor: (d) => defaultLicenseManager.registerMcpModuleDescriptor(d),
  clearDynamicMcpModules: () => defaultLicenseManager.clearDynamicMcpModules(),
  buildSignedPingModuleSyncPayload: (p) => defaultLicenseManager.buildSignedPingModuleSyncPayload(p),
  applySignedPingModuleSync: (p) => defaultLicenseManager.applySignedPingModuleSync(p),
  getActiveModuleBitmask: () => defaultLicenseManager.getActiveModuleBitmask(),
  recordHeartbeatAck: (t) => defaultLicenseManager.recordHeartbeatAck(t),
  upgradeTier: (p) => defaultLicenseManager.upgradeTier(p),
  issueMarketDiscountCoupon: (p) => defaultLicenseManager.issueMarketDiscountCoupon(p),
  calculateFairRefund: (p) => defaultLicenseManager.calculateFairRefund(p),
  verifyRefundEligibilityWithHardware: (h, r) => defaultLicenseManager.verifyRefundEligibilityWithHardware(h, r),
  markPendingDefectVerification: (r) => defaultLicenseManager.markPendingDefectVerification(r),
  revokeLicense: (r) => defaultLicenseManager.revokeLicense(r),
  checkRefundEligibility: (p) => defaultLicenseManager.checkRefundEligibility(p),
  getStatus: () => defaultLicenseManager.getStatus()
};


