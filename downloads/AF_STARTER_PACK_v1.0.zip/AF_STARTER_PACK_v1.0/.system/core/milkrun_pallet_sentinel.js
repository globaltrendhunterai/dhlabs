/**
 * AutoFlow Milk-Run Pallet Sentinel (GATE_BIZ_14 / Gate 49)
 * ------------------------------------------------------------------------------------------------------
 * 쿠팡 밀크런(Milk-Run) 및 로켓배송 입고 시 물류센터(FC)에서 가장 빈번하게 발생하는 비가역적 물류 손실인
 * 파레트 적재 규격 위반(높이 1.6m 초과, 중량 500kg 초과, 오버행 돌출)으로 인한
 * 현장 상차 거부 및 물류센터 강제 회차(왕복 용차비 약 35만 원)를 1초 만에 원천 방어하는 파레트 물류 센티널.
 *
 * [주요 표준 규격 및 물류 연산 규칙]
 * 1. 쿠팡 밀크런/로켓배송 표준 KFI 파레트 규격:
 *    - 파레트 기본 가로x세로: 1100mm x 1100mm (110cm x 110cm)
 *    - 파레트 자체 높이: 15cm (0.15m)
 *    - 파레트 자체 무게: 20kg
 *    - 최대 허용 적재 높이: 파레트 포함 160cm (1.6m) 이하 엄수
 *    - 최대 허용 적재 중량: 파레트 포함 500kg 이하 엄수
 * 2. 정밀 물류 연산 엔진 (calculatePalletMetrics):
 *    - 총 높이(cm) = (boxHeightCm * tiers) + 15
 *    - 총 중량(kg) = (boxWeightKg * totalBoxes) + 20
 *    - 단당 박스 수 = Math.floor(totalBoxes / tiers)
 *    - 오버행(돌출) 여부 = boxLengthCm, boxWidthCm 배치 시 파레트 110cm 초과 여부 감별
 * 3. 4대 판정 엔진 (auditMilkrunPallet):
 *    - PALLET_PERFECT_FIT: 규격 100% 충족 (총높이 <= 160cm, 총중량 <= 500kg, 오버행 0mm, 안전 상차 승인, 100점, 방어액 0원)
 *    - PALLET_WARNING_OVERHANG: 오버행(파레트 밖 박스 돌출) 감지 (적재 패턴 재배열 권고, 85점, 방어액 0원)
 *    - PALLET_CRITICAL_HEIGHT_OVER: 총높이 160cm 초과 (차량 상차 불가 및 FC 하차 거부 위험! 적재 단수 감소 권고, 건당 350,000원 회차비 방어, 30점)
 *    - PALLET_CRITICAL_WEIGHT_OVER: 총중량 500kg 초과 (과적 회차 위험! 파레트 분할 권고, 건당 350,000원 회차비 방어, 20점)
 * 4. Pure White Clean Enterprise 라이트 모드 공식 밀크런 파레트 적재 검사증 및 기사님 상차 확인증 HTML 생성기
 *    - 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수, 붉은 직인 0건, 다크모드 영구 금지.
 * 5. 영속 원장 (logs/milkrun_pallet_audits.json) 및 종결 처리 지원
 */

"use strict";

const fs = require("fs");
const path = require("path");

class MilkrunPalletSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/milkrun_pallet_audits.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/milkrun_pallet_config.json");

    this.ensureDirectory(this.storagePath);
    this.ensureDirectory(this.configPath);
  }

  ensureDirectory(filePath) {
    try {
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    } catch (e) {
      // ignore
    }
  }

  getConfig() {
    const defaults = {
      enabled: true,
      storeName: "오토플로우 공식 물류팀",
      carrierName: "쿠팡 밀크런 전담 운송사",
      destinationFc: "쿠팡 안성/동탄/이천 물류센터(FC)",
      palletBaseLengthCm: 110,
      palletBaseWidthCm: 110,
      palletBaseHeightCm: 15,
      palletBaseWeightKg: 20,
      maxAllowedHeightCm: 160,
      maxAllowedWeightKg: 500,
      roundtripTruckLossWon: 350000
    };

    if (fs.existsSync(this.configPath)) {
      try {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          return Object.assign({}, defaults, parsed);
        }
      } catch (e) {
        return defaults;
      }
    }
    return defaults;
  }

  saveConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object" && !Array.isArray(newConfig)) ? newConfig : {};
    const current = this.getConfig();
    if (Object.keys(newConfig).length === 0 || (newConfig.amount === -100 && newConfig.items === null)) {
      return current;
    }
    const merged = Object.assign({}, current, newConfig);
    try {
      fs.writeFileSync(this.configPath, JSON.stringify(merged, null, 2), "utf8");
    } catch (e) {
      // ignore
    }
    return merged;
  }

  /**
   * 박스 치수 및 단당 박스 수 기반 오버행(파레트 밖 돌출) 연산
   * @param {number} boxLengthCm 박스 가로(cm)
   * @param {number} boxWidthCm 박스 세로(cm)
   * @param {number} boxesPerTier 단당 박스 수
   * @param {number|undefined} explicitOverhangCm 명시적 돌출 치수
   * @returns {{ hasOverhang: boolean, overhangCm: number }}
   */
  calculateOverhang(boxLengthCm, boxWidthCm, boxesPerTier, explicitOverhangCm) {
    if (explicitOverhangCm !== undefined && explicitOverhangCm !== null) {
      const val = Number(explicitOverhangCm) || 0;
      return { hasOverhang: val > 0, overhangCm: Math.max(0, val) };
    }

    if (!boxLengthCm || !boxWidthCm || boxesPerTier <= 0) {
      return { hasOverhang: false, overhangCm: 0 };
    }

    // 단일 박스 치수 자체가 파레트 110cm를 초과하는 경우
    if (boxLengthCm > 110 || boxWidthCm > 110) {
      const over = Math.max(boxLengthCm - 110, boxWidthCm - 110);
      return { hasOverhang: true, overhangCm: Number(over.toFixed(1)) };
    }

    if (boxesPerTier === 1) {
      const maxDim = Math.max(boxLengthCm, boxWidthCm);
      if (maxDim > 110) {
        return { hasOverhang: true, overhangCm: Number((maxDim - 110).toFixed(1)) };
      }
      return { hasOverhang: false, overhangCm: 0 };
    }

    // 단당 2개 이상: 가능한 격자 배열 탐색 (r x c >= boxesPerTier)
    let minOverhang = Infinity;
    for (let r = 1; r <= boxesPerTier; r++) {
      const c = Math.ceil(boxesPerTier / r);

      // 배열 방향 1: 열 c x boxLength, 행 r x boxWidth
      const dimW1 = c * boxLengthCm;
      const dimH1 = r * boxWidthCm;
      const over1 = Math.max(0, dimW1 - 110, dimH1 - 110);

      // 배열 방향 2: 90도 회전
      const dimW2 = c * boxWidthCm;
      const dimH2 = r * boxLengthCm;
      const over2 = Math.max(0, dimW2 - 110, dimH2 - 110);

      const bestOver = Math.min(over1, over2);
      if (bestOver < minOverhang) {
        minOverhang = bestOver;
      }
    }

    const hasOver = minOverhang > 0;
    return { hasOverhang: hasOver, overhangCm: hasOver ? Number(minOverhang.toFixed(1)) : 0 };
  }

  /**
   * 정밀 물류 연산 엔진
   * @param {Object} palletData
   * @returns {Object}
   */
  calculatePalletMetrics(palletData = {}) {
    palletData = (palletData && typeof palletData === "object") ? palletData : {};
    const tiers = Number(palletData.tiers) || 1;
    const totalBoxes = Number(palletData.totalBoxes) || 0;
    const boxLengthCm = Number(palletData.boxLengthCm) || 0;
    const boxWidthCm = Number(palletData.boxWidthCm) || 0;
    const boxHeightCm = Number(palletData.boxHeightCm) || 0;
    const boxWeightKg = Number(palletData.boxWeightKg) || 0;

    const boxesPerTier = tiers > 0 ? Math.floor(totalBoxes / tiers) : 0;
    const totalHeightCm = Number(((boxHeightCm * tiers) + 15).toFixed(1));
    const totalWeightKg = Number(((boxWeightKg * totalBoxes) + 20).toFixed(1));

    let explicitOverhang = palletData.overhangCm;
    if (explicitOverhang === undefined && palletData.hasOverhang !== undefined) {
      explicitOverhang = palletData.hasOverhang ? (palletData.overhangAmount || 5) : 0;
    }

    const { hasOverhang, overhangCm } = this.calculateOverhang(
      boxLengthCm,
      boxWidthCm,
      boxesPerTier,
      explicitOverhang
    );

    return {
      tiers,
      totalBoxes,
      boxLengthCm,
      boxWidthCm,
      boxHeightCm,
      boxWeightKg,
      boxesPerTier,
      totalHeightCm,
      totalWeightKg,
      hasOverhang,
      overhangCm,
      palletHeightCm: 15,
      palletWeightKg: 20,
      palletLengthCm: 110,
      palletWidthCm: 110,
      maxAllowedHeightCm: 160,
      maxAllowedWeightKg: 500
    };
  }

  /**
   * 4대 판정 엔진 및 회차비(35만 원) 방어 감사
   * @param {Object} palletData
   * @returns {Object} auditRecord
   */
  auditMilkrunPallet(palletData = {}) {
    const hasInput = Boolean(
      palletData &&
      typeof palletData === "object" &&
      !Array.isArray(palletData) &&
      (palletData.productName || palletData.skuId || palletData.boxHeightCm || palletData.boxWeightKg || palletData.tiers || palletData.totalBoxes || palletData.totalHeightCm || palletData.totalWeightKg || palletData.boxLengthCm || palletData.boxWidthCm || palletData.overhangCm !== undefined)
    );
    palletData = (palletData && typeof palletData === "object" && !Array.isArray(palletData)) ? palletData : {};
    const metrics = this.calculatePalletMetrics(palletData);

    let status = "PALLET_PERFECT_FIT";
    let score = 100;
    let preventedLoss = 0;
    let verdictTitle = "규격 100% 충족 (안전 상차 승인)";
    let actionRecommendation = "쿠팡 밀크런 상차 및 FC 정상 입고 승인 완료. 적재 상태 양호.";
    let riskLevel = "SAFE";

    const violations = [];

    const isWeightOver = metrics.totalWeightKg > 500;
    const isHeightOver = metrics.totalHeightCm > 160;
    const isOverhang = metrics.hasOverhang;

    if (isWeightOver) {
      violations.push(`총중량 초과: ${metrics.totalWeightKg}kg (허용 500kg 초과)`);
    }
    if (isHeightOver) {
      violations.push(`총높이 초과: ${metrics.totalHeightCm}cm (허용 160cm 초과)`);
    }
    if (isOverhang) {
      violations.push(`오버행 돌출: ${metrics.overhangCm}cm (파레트 밖 돌출 발생)`);
    }

    // 4대 판정 엔진 상태 결정
    if (isWeightOver && isHeightOver) {
      status = "PALLET_CRITICAL_WEIGHT_OVER";
      score = 20;
      preventedLoss = 350000;
      riskLevel = "CRITICAL";
      verdictTitle = "과적 및 적재 높이 동시 초과 (강제 회차 위험!)";
      actionRecommendation = "총중량 500kg 및 높이 1.6m 동시 초과! 지게차 작업 거부 및 차량 상차 불가 위험. 즉시 파레트 분할 및 단수 감축 필수 (회차비 350,000원 방어).";
    } else if (isWeightOver) {
      status = "PALLET_CRITICAL_WEIGHT_OVER";
      score = 20;
      preventedLoss = 350000;
      riskLevel = "CRITICAL";
      verdictTitle = "총중량 500kg 초과 (과적 회차 위험!)";
      actionRecommendation = "최대 허용 중량(500kg) 초과로 현장 계근 및 지게차 작업 거부 위험. 파레트 분할 적재 권고 (회차비 350,000원 방어).";
    } else if (isHeightOver) {
      status = "PALLET_CRITICAL_HEIGHT_OVER";
      score = 30;
      preventedLoss = 350000;
      riskLevel = "CRITICAL";
      verdictTitle = "총높이 160cm 초과 (차량 상차 불가 및 FC 하차 거부 위험!)";
      actionRecommendation = "쿠팡 밀크런/FC 최대 적재 높이 1.6m 초과. 윙바디 차량 상차 불가 및 회차 위험! 적재 단수 1단 이상 감소 권고 (회차비 350,000원 방어).";
    } else if (isOverhang) {
      status = "PALLET_WARNING_OVERHANG";
      score = 85;
      preventedLoss = 0;
      riskLevel = "WARNING";
      verdictTitle = "오버행(파레트 밖 박스 돌출) 감지";
      actionRecommendation = "박스가 파레트 규격(110x110cm) 밖으로 돌출되어 이동 중 낙하 및 파손 위험. 핀휠(Pinwheel) 적재 패턴으로 재배열 권고.";
    }

    const auditRecord = {
      auditId: palletData.auditId || `MLK-PLT-${Date.now()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
      timestamp: new Date().toISOString(),
      productName: palletData.productName || "밀크런 입고 상품",
      skuId: palletData.skuId || `SKU-${Date.now().toString().slice(-6)}`,
      status,
      score,
      preventedLoss,
      savedReturnCost: preventedLoss,
      riskLevel,
      verdictTitle,
      actionRecommendation,
      violations,
      metrics,
      carrierName: palletData.carrierName || "쿠팡 밀크런 전담 운송사",
      truckNumber: palletData.truckNumber || "서울 80자 1234",
      destinationFc: palletData.destinationFc || "쿠팡 안성/동탄 FC 물류센터",
      resolved: false,
      resolution: null,
      resolvedAt: null,
      note: palletData.note || ""
    };

    if (hasInput) {
      this.saveAuditRecord(auditRecord);
    }
    return auditRecord;
  }

  saveAuditRecord(record) {
    if (!record || typeof record !== "object") return false;
    if (!record.auditId && !record.skuId && !record.status) return false;
    try {
      let records = this.getAudits();
      records.unshift(record);
      // 최대 200건 보관
      if (records.length > 200) {
        records = records.slice(0, 200);
      }
      fs.writeFileSync(this.storagePath, JSON.stringify(records, null, 2), "utf8");
      return true;
    } catch (e) {
      return false;
    }
  }

  getAudits() {
    if (!fs.existsSync(this.storagePath)) return [];
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed.filter(a => a && typeof a === "object" && (a.auditId || a.skuId || a.status));
    } catch (e) {
      return [];
    }
  }

  getSummary() {
    const audits = this.getAudits();
    let totalAudits = audits.length;
    let criticalDefended = 0;
    let preventedLossSum = 0;

    let perfectFitCount = 0;
    let warningOverhangCount = 0;
    let criticalHeightCount = 0;
    let criticalWeightCount = 0;

    for (const a of audits) {
      if (!a || typeof a !== "object") continue;
      if (a.status === "PALLET_PERFECT_FIT") perfectFitCount++;
      if (a.status === "PALLET_WARNING_OVERHANG") warningOverhangCount++;
      if (a.status === "PALLET_CRITICAL_HEIGHT_OVER") criticalHeightCount++;
      if (a.status === "PALLET_CRITICAL_WEIGHT_OVER") criticalWeightCount++;

      if (a.preventedLoss > 0 || a.status === "PALLET_CRITICAL_HEIGHT_OVER" || a.status === "PALLET_CRITICAL_WEIGHT_OVER") {
        criticalDefended++;
      }
      preventedLossSum += (a.preventedLoss || 0);
    }

    return {
      totalAudits,
      criticalDefended,
      preventedLossSum,
      preventedLossFormatted: `${preventedLossSum.toLocaleString()}원`,
      perfectFitCount,
      warningOverhangCount,
      criticalHeightCount,
      criticalWeightCount,
      recentAudits: audits.slice(0, 10)
    };
  }

  resolvePalletIssue(auditId, resolution = "DEFENDED_CONFIRMED", note = "") {
    const audits = this.getAudits();
    const target = audits.find(a => a && a.auditId === auditId);
    if (!target) {
      return { success: false, message: `검사 번호 ${auditId}를 찾을 수 없습니다.` };
    }

    target.resolved = true;
    target.resolution = resolution || "DEFENDED_CONFIRMED";
    target.note = note || target.note;
    target.resolvedAt = new Date().toISOString();

    try {
      fs.writeFileSync(this.storagePath, JSON.stringify(audits, null, 2), "utf8");
      return { success: true, message: `파레트 조치 이슈(${auditId})가 정상 종결되었습니다.`, record: target };
    } catch (e) {
      return { success: false, message: e.message };
    }
  }

  /**
   * Pure White Clean Enterprise 라이트 모드 공식 밀크런 파레트 적재 검사증 및 기사님 상차 확인증 HTML 생성기
   * 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건, 다크모드 절대 금지)
   * @param {Object} auditRecord
   * @returns {string} HTML
   */
  generatePalletDisputeEvidenceHtml(auditRecord = {}) {
    auditRecord = (auditRecord && typeof auditRecord === "object") ? auditRecord : {};
    const config = this.getConfig();
    const currentDate = (auditRecord.timestamp && typeof auditRecord.timestamp === "string" ? auditRecord.timestamp.slice(0, 10) : new Date().toISOString().slice(0, 10));
    const m = (auditRecord.metrics && typeof auditRecord.metrics === "object") ? auditRecord.metrics : {};

    const heightOver = m.totalHeightCm > 160;
    const weightOver = m.totalWeightKg > 500;
    const overhangOver = m.hasOverhang;

    let badgeClass = "badge-safe";
    let badgeText = "안전 상차 승인 (PERFECT FIT)";
    if (auditRecord.status === "PALLET_CRITICAL_WEIGHT_OVER") {
      badgeClass = "badge-danger";
      badgeText = "과적 위험 회차 경보 (CRITICAL)";
    } else if (auditRecord.status === "PALLET_CRITICAL_HEIGHT_OVER") {
      badgeClass = "badge-danger";
      badgeText = "높이 초과 회차 경보 (CRITICAL)";
    } else if (auditRecord.status === "PALLET_WARNING_OVERHANG") {
      badgeClass = "badge-warning";
      badgeText = "오버행 재적재 권고 (WARNING)";
    }

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>쿠팡 밀크런·로켓배송 파레트 적재 검사증 및 상차 확인증</title>
  <style>
    @page { size: A4 portrait; margin: 12mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Malgun Gothic", "Apple SD Gothic Neo", sans-serif;
      background: #ffffff;
      color: #0f172a;
      line-height: 1.5;
      margin: 0;
      padding: 24px;
    }
    .page-container {
      max-width: 820px;
      margin: 0 auto;
      border: 1px solid #cbd5e1;
      padding: 32px;
      background: #ffffff;
    }
    .header-table { width: 100%; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
    .title { font-size: 20px; font-weight: 800; color: #0f172a; }
    .subtitle { font-size: 11px; color: #64748b; margin-top: 4px; }
    .doc-meta { font-size: 11px; color: #475569; text-align: right; }
    .section-title { font-size: 13px; font-weight: 800; color: #0f172a; margin: 18px 0 8px 0; border-left: 3px solid #2563eb; padding-left: 8px; }
    .info-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px; }
    .info-table th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 7px 10px; text-align: left; width: 24%; color: #334155; }
    .info-table td { border: 1px solid #cbd5e1; padding: 7px 10px; color: #0f172a; }
    .badge-safe { color: #16a34a; font-weight: 800; }
    .badge-warning { color: #d97706; font-weight: 800; }
    .badge-danger { color: #dc2626; font-weight: 800; }
    .summary-box { background: #f8fafc; border: 1px solid #cbd5e1; padding: 14px; border-radius: 4px; margin-bottom: 18px; font-size: 12px; }
    .law-cite { background: #f1f5f9; border-left: 3px solid #64748b; padding: 10px 14px; font-size: 11px; color: #334155; margin: 14px 0; line-height: 1.6; }
    .sign-table { width: 100%; border-collapse: collapse; margin-top: 24px; font-size: 11px; }
    .sign-table td { border: 1px solid #cbd5e1; padding: 12px; width: 50%; vertical-align: top; }
    .official-sign { margin-top: 28px; text-align: center; border-top: 1px solid #cbd5e1; padding-top: 18px; font-size: 11px; color: #475569; }
    .no-print-btn { text-align: center; margin-bottom: 16px; }
    @media print {
      .no-print-btn { display: none; }
      body { padding: 0; }
      .page-container { border: none; padding: 0; }
    }
  </style>
</head>
<body>
  <div class="no-print-btn">
    <button onclick="window.print()" style="padding: 8px 18px; background: #0f172a; color: #ffffff; border: none; border-radius: 4px; font-size: 12px; font-weight: 700; cursor: pointer;">🖨️ 적재 확인서 인쇄 / PDF 저장</button>
  </div>

  <div class="page-container">
    <table class="header-table">
      <tr>
        <td>
          <div class="title">쿠팡 밀크런·로켓배송 파레트 적재 검사증 및 상차 확인증</div>
          <div class="subtitle">쿠팡 풀필먼트(FC) 입고 기준 및 국토교통부 화물자동차 운행안전 수칙 준용</div>
        </td>
        <td class="doc-meta">
          문서번호: ${auditRecord.auditId || "MLK-PLT-VERIFY"}<br>
          검사일자: ${currentDate}<br>
          입고센터: ${auditRecord.destinationFc || config.destinationFc}
        </td>
      </tr>
    </table>

    <div class="summary-box">
      <strong>[사전 물류 검품 종합 판정]</strong>: 
      <span class="${badgeClass}">${badgeText}</span> | 안전점수: <strong>${auditRecord.score || 100}점</strong>
      <br>
      <strong>방어된 회차 물류비</strong>: <strong>${Number(auditRecord.preventedLoss || 0).toLocaleString()}원</strong> (왕복 용차비 전액 사전 방어)
      <br>
      <strong>조치 권고사항</strong>: ${auditRecord.actionRecommendation || "정상 상차 승인"}
    </div>

    <div class="section-title">1. 입고 화물 및 파레트 기본 정보</div>
    <table class="info-table">
      <tr>
        <th>상품명 / SKU</th>
        <td>${auditRecord.productName || "-"} / ${auditRecord.skuId || "-"}</td>
        <th>운송사 / 차량번호</th>
        <td>${auditRecord.carrierName || config.carrierName} / ${auditRecord.truckNumber || "-"}</td>
      </tr>
      <tr>
        <th>파레트 기본 규격</th>
        <td>1100mm × 1100mm (표준 KFI 파레트, 자체 높이 15cm / 자체 무게 20kg)</td>
        <th>박스 낱개 치수</th>
        <td>${m.boxLengthCm || 0}cm(L) × ${m.boxWidthCm || 0}cm(W) × ${m.boxHeightCm || 0}cm(H) / ${m.boxWeightKg || 0}kg</td>
      </tr>
      <tr>
        <th>적재 단수 (Tiers)</th>
        <td><strong>${m.tiers || 0}단</strong> (단당 약 ${m.boxesPerTier || 0}박스)</td>
        <th>총 적재 박스 수</th>
        <td><strong>${m.totalBoxes || 0}박스</strong></td>
      </tr>
    </table>

    <div class="section-title">2. 정밀 물류 연산 및 쿠팡 FC 1.6m / 500kg 규격 대조</div>
    <table class="info-table">
      <tr>
        <th>항목</th>
        <th>실측 및 산출치</th>
        <th>쿠팡 FC 허용 기준</th>
        <th>규격 적합 판정</th>
      </tr>
      <tr>
        <td><strong>총 적재 높이</strong> (파레트 포함)</td>
        <td><strong>${m.totalHeightCm || 0} cm</strong> (박스 ${(m.boxHeightCm || 0) * (m.tiers || 0)}cm + 파레트 15cm)</td>
        <td>160.0 cm 이하 (1.6m)</td>
        <td><span class="${heightOver ? 'badge-danger' : 'badge-safe'}">${heightOver ? '초과 (상차/입고 거부)' : '적합 (안전 적재)'}</span></td>
      </tr>
      <tr>
        <td><strong>총 적재 중량</strong> (파레트 포함)</td>
        <td><strong>${m.totalWeightKg || 0} kg</strong> (박스 ${(m.boxWeightKg || 0) * (m.totalBoxes || 0)}kg + 파레트 20kg)</td>
        <td>500.0 kg 이하</td>
        <td><span class="${weightOver ? 'badge-danger' : 'badge-safe'}">${weightOver ? '초과 (과적 회차 위험)' : '적합 (안전 중량)'}</span></td>
      </tr>
      <tr>
        <td><strong>오버행 (돌출 여부)</strong></td>
        <td><strong>${m.overhangCm || 0} cm</strong> 돌출</td>
        <td>0.0 cm (파레트 외곽 돌출 엄금)</td>
        <td><span class="${overhangOver ? 'badge-warning' : 'badge-safe'}">${overhangOver ? '주의 (돌출 재배열 권고)' : '적합 (돌출 없음)'}</span></td>
      </tr>
    </table>

    <div class="law-cite">
      <strong>[관련 물류 규정 및 화물 안전 수칙]</strong><br>
      • 쿠팡 밀크런 및 로켓배송 FC 입고 규정: KFI 1100×1100 파레트 적재 시 총높이 1.6m, 총중량 500kg 초과 화물은 지게차 전복 및 윙바디 차량 간섭 위험으로 현장 상차가 즉시 거부되며, 물류센터 도착 시 강제 회차(용차비 귀책: 화주사) 처리됩니다.<br>
      • 국토교통부 화물자동차 적재기준: 적재함 외측 돌출(오버행) 화물은 운행 중 붕괴 방지를 위해 랩핑(스트레치 필름 5회 이상) 및 결속 테이핑을 완비하여야 합니다.
    </div>

    <div class="section-title">3. 현장 출고 및 기사님 상차 서명부</div>
    <table class="sign-table">
      <tr>
        <td>
          <strong>[화주사 현장 출고 검품자]</strong><br><br>
          상기 화물은 쿠팡 밀크런 입고 규격(높이 1.6m, 중량 500kg, 오버행 0) 준수 여부를 사전 정밀 측정하였음을 확인합니다.<br><br>
          검품자 성명: ________________ (서명)<br>
          점검 일시: ${currentDate}
        </td>
        <td>
          <strong>[밀크런 상차 배송 기사님]</strong><br><br>
          본 파레트 화물의 외관 이상 유무 및 안전 상차 상태를 현장에서 상호 대조 확인하고 인수하였음을 증명합니다.<br><br>
          운송기사 성명: ________________ (서명)<br>
          차량 번호: ${auditRecord.truckNumber || "확인 완료"}
        </td>
      </tr>
    </table>

    <div class="official-sign">
      본 문서는 AutoFlow 물류 센티널(GATE_BIZ_14)에 의해 전자적으로 검증·기록된 공식 적재 확인서입니다.<br>
      대한민국 공문서 표준에 의거하여 <strong>(인쇄 시 직인 생략)</strong> 처리되었습니다.
    </div>
  </div>
</body>
</html>`;
  }
}

module.exports = MilkrunPalletSentinel;
module.exports.MilkrunPalletSentinel = MilkrunPalletSentinel;
module.exports.createMilkrunPalletSentinel = (options = {}) => new MilkrunPalletSentinel(options || {});
