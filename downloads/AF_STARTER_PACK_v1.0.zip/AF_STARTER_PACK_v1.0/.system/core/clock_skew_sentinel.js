/**
 * core/clock_skew_sentinel.js
 * 
 * AutoFlow Coupang API Clock Skew Sentinel & Autonomous Time Drift Compensator
 * 
 * Objectives:
 * 1. Automatically computes time difference (Date.now() - remoteDate) from external HTTP Date headers (Coupang WING, Telemetry).
 * 2. Stores global clock skew in globalClockSkewMs to compensate for CMOS battery discharge or inaccurate local OS clocks.
 * 3. Formats Coupang YYMMDD'T'HHMMSS'Z' timestamps and HMAC-SHA256 signatures with compensated time, 100% preventing 401 Unauthorized clock errors.
 * 4. Provides diagnostic status API for health monitoring.
 */

const crypto = require("crypto");

class ClockSkewSentinel {
  constructor() {
    this.globalClockSkewMs = 0;
    this.lastSyncTimestamp = null;
    this.lastRemoteDate = null;
    this.lastLocalNow = null;
  }

  /**
   * HTTP 응답 Date 헤더 또는 원격 시각을 수신하여 시계 오차(Skew)를 계산하고 보존
   * @param {string|number|Date} remoteDateHeaderOrMs 
   * @returns {number} 산출된 skewMs
   */
  recordRemoteDate(remoteDateHeaderOrMs) {
    if (remoteDateHeaderOrMs && typeof remoteDateHeaderOrMs === "object" && !(remoteDateHeaderOrMs instanceof Date)) {
      remoteDateHeaderOrMs =
        remoteDateHeaderOrMs.remoteDate ||
        remoteDateHeaderOrMs.date ||
        (remoteDateHeaderOrMs.headers && (remoteDateHeaderOrMs.headers["date"] || remoteDateHeaderOrMs.headers["Date"])) ||
        null;
    }
    if (!remoteDateHeaderOrMs) return this.globalClockSkewMs;

    try {
      const remoteMs = new Date(remoteDateHeaderOrMs).getTime();
      if (isNaN(remoteMs) || remoteMs <= 0) return this.globalClockSkewMs;

      const localNow = Date.now();
      // remoteMs - localNow: 로컬 시계가 느리면 양수, 빠르면 음수
      // Date.now() + globalClockSkewMs = 정확한 원격 서버 시각
      const calculatedSkewMs = remoteMs - localNow;
      this.globalClockSkewMs = calculatedSkewMs;
      this.lastSyncTimestamp = new Date().toISOString();
      this.lastRemoteDate = new Date(remoteMs).toISOString();
      this.lastLocalNow = new Date(localNow).toISOString();

      if (Math.abs(calculatedSkewMs) > 5000) {
        console.log(`[ClockSkewSentinel] ⏱️ Clock drift detected: ${calculatedSkewMs}ms (${(calculatedSkewMs / 1000).toFixed(2)}s). Compensated automatically.`);
      }

      return this.globalClockSkewMs;
    } catch (e) {
      console.warn("[AutoFlow Safety] Failed to record remote date for clock skew:", e.message);
      return this.globalClockSkewMs;
    }
  }

  /**
   * HTTP 응답 객체(headers)를 전달받아 Date 헤더를 자동 추출 및 동기화
   * @param {object} res 
   */
  interceptHttpResponse(res) {
    if (!res || !res.headers) return this.globalClockSkewMs;
    const dateHeader = res.headers["date"] || res.headers["Date"];
    if (dateHeader) {
      return this.recordRemoteDate(dateHeader);
    }
    return this.globalClockSkewMs;
  }

  /**
   * 시계 오차가 보정된 현재 에포크 밀리초 반환
   * @returns {number}
   */
  getCorrectedNow() {
    return Date.now() + this.globalClockSkewMs;
  }

  /**
   * 시계 오차가 보정된 Date 객체 반환
   * @returns {Date}
   */
  getCorrectedDate() {
    return new Date(this.getCorrectedNow());
  }

  /**
   * 현재 보정 오프셋(ms) 반환
   * @returns {number}
   */
  getSkewMs() {
    return this.globalClockSkewMs;
  }

  /**
   * 쿠팡 WING Open API 규격 타임스탬프 (YYMMDD'T'HHMMSS'Z' UTC)
   * CMOS 배터리 방전 시에도 보정된 시각을 사용하여 401 차단 방지
   * @param {Date|number|null} customDate 
   * @returns {string} YYMMDD'T'HHMMSS'Z'
   */
  formatCoupangDate(customDate = null) {
    if (customDate && typeof customDate === "object" && !(customDate instanceof Date)) {
      customDate = customDate.customDate || customDate.date || null;
    }
    let d = customDate ? new Date(customDate) : this.getCorrectedDate();
    if (isNaN(d.getTime())) {
      d = this.getCorrectedDate();
    }
    const yy = String(d.getUTCFullYear()).slice(-2);
    const MM = String(d.getUTCMonth() + 1).padStart(2, "0");
    const dd = String(d.getUTCDate()).padStart(2, "0");
    const hh = String(d.getUTCHours()).padStart(2, "0");
    const mm = String(d.getUTCMinutes()).padStart(2, "0");
    const ss = String(d.getUTCSeconds()).padStart(2, "0");
    return `${yy}${MM}${dd}T${hh}${mm}${ss}Z`;
  }

  /**
   * 쿠팡 WING HMAC-SHA256 서명 및 Authorization 헤더 생성
   * @param {string|object} method HTTP Method (GET, POST 등) 또는 옵션 객체
   * @param {string} [path] API Endpoint Path
   * @param {string} [secretKey] Coupang Secret Key
   * @param {string} [accessKey] Coupang Access Key
   * @param {Date|number|null} [customDate] 
   */
  generateCoupangSignature(method, path, secretKey, accessKey, customDate = null) {
    if (method && typeof method === "object") {
      const opts = method;
      customDate = opts.customDate !== undefined ? opts.customDate : path;
      path = opts.path || opts.url || "/";
      secretKey = opts.secretKey || "";
      accessKey = opts.accessKey || "";
      method = opts.method || "GET";
    }
    const safeMethod = String(method || "GET").toUpperCase();
    const safePath = String(path || "/");
    const safeSecretKey = String(secretKey || "");
    const safeAccessKey = String(accessKey || "");
    const signedDate = this.formatCoupangDate(customDate);
    const message = `${signedDate}${safeMethod}${safePath}`;
    const signature = crypto.createHmac("sha256", safeSecretKey).update(message).digest("hex");
    const authorization = `CEA algorithm=HmacSHA256, access-key=${safeAccessKey}, signed-date=${signedDate}, signature=${signature}`;
    return {
      signedDate,
      signature,
      authorization,
      skewMs: this.globalClockSkewMs
    };
  }

  /**
   * 진단용 상태 정보 반환
   */
  getStatus() {
    const now = Date.now();
    const correctedNow = this.getCorrectedNow();
    const absSkew = Math.abs(this.globalClockSkewMs);
    let healthStatus = "HEALTHY";
    if (absSkew >= 60000) {
      healthStatus = "SKEW_COMPENSATED";
    }

    return {
      status: healthStatus,
      skew_ms: this.globalClockSkewMs,
      skew_seconds: parseFloat((this.globalClockSkewMs / 1000).toFixed(3)),
      local_time: new Date(now).toISOString(),
      corrected_time: new Date(correctedNow).toISOString(),
      last_sync_at: this.lastSyncTimestamp,
      last_remote_date: this.lastRemoteDate,
      is_synchronized: this.lastSyncTimestamp !== null
    };
  }

  /**
   * 오프셋 초기화
   */
  reset() {
    this.globalClockSkewMs = 0;
    this.lastSyncTimestamp = null;
    this.lastRemoteDate = null;
    this.lastLocalNow = null;
  }
}

const defaultClockSkewSentinel = new ClockSkewSentinel();

module.exports = {
  ClockSkewSentinel,
  clockSkewSentinel: defaultClockSkewSentinel
};
