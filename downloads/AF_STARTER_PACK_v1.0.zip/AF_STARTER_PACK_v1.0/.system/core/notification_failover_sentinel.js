/**
 * AutoFlow Notification Failover Sentinel (다중 알림 채널 자동 페일오버 센티널)
 * 
 * [목적]
 * 1. 주 채널(텔레그램 API) 일시 장애, 429 레이트 리밋, 또는 해외망 통신 타임아웃 발생 시
 *    보조 채널(Slack, Discord, Custom Webhook)로 1초 만에 자동 전환하여 주문 알림 침묵 유실 0건 보장.
 * 2. 페일오버 발송 시 [🚨 알림 채널 페일오버 가드 작동] 안심 배너를 자동 부착하여
 *    판매자가 텔레그램 일시 지연 상태임을 명확히 인지하도록 안내.
 * 3. 셋업 마법사 1초 모의 테스트(POST /api/system/test-failover) 및 이력 조회(GET /api/system/failover-status) 제공.
 */

const https = require("https");
const http = require("http");
const fs = require("fs");
const path = require("path");

class NotificationFailoverSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.historyPath = (typeof options.historyPath === "string" && options.historyPath.trim())
      ? options.historyPath.trim()
      : path.join(__dirname, "..", "logs", "failover_events.json");
    this.history = this._loadHistory();
  }

  _loadHistory() {
    try {
      if (this.historyPath && typeof this.historyPath === "string" && fs.existsSync(this.historyPath)) {
        const raw = fs.readFileSync(this.historyPath, "utf8");
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (e) {
      console.error("[NotificationFailoverSentinel] 이력 로드 실패 (non-fatal):", e.message);
    }
    return [];
  }

  _saveHistory() {
    try {
      if (!Array.isArray(this.history)) {
        this.history = [];
      }
      const dir = path.dirname(this.historyPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(this.historyPath, JSON.stringify(this.history.slice(-50), null, 2), "utf8");
    } catch (e) {
      console.error("[NotificationFailoverSentinel] 이력 저장 실패 (non-fatal):", e.message);
    }
  }

  /**
   * 보조 채널(Slack, Discord, 또는 Custom Webhook) URL 추출
   * @param {object} config - notification_settings.json 객체
   */
  getSecondaryWebhookUrl(config = {}) {
    config = (config && typeof config === "object") ? config : {};
    if (config.secondaryWebhookUrl && typeof config.secondaryWebhookUrl === "string") {
      const trimmed = config.secondaryWebhookUrl.trim();
      if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
        return trimmed;
      }
    }
    if (config.slackWebhookUrl && typeof config.slackWebhookUrl === "string") {
      const trimmed = config.slackWebhookUrl.trim();
      if (trimmed.startsWith("https://hooks.slack.com/")) {
        return trimmed;
      }
    }
    if (config.discordWebhookUrl && typeof config.discordWebhookUrl === "string") {
      const trimmed = config.discordWebhookUrl.trim();
      if (trimmed.startsWith("https://discord.com/api/webhooks/")) {
        return trimmed;
      }
    }
    return null;
  }

  /**
   * 페일오버 메시지 포맷팅
   */
  formatFailoverMessage(originalMessage = "", errorReason = "TELEGRAM_TIMEOUT") {
    const safeMsg = typeof originalMessage === "string" ? originalMessage : JSON.stringify(originalMessage ?? "");
    const safeReason = (typeof errorReason === "string" && errorReason.trim()) ? errorReason.trim() : "TELEGRAM_TIMEOUT";
    const timestamp = new Date().toISOString().replace("T", " ").substring(0, 19) + " KST";
    return [
      "🚨 [AutoFlow 알림 채널 페일오버 가드 작동]",
      "주 채널(텔레그램)의 일시 통신 지연이 감지되어, 주문 누락을 방지하기 위해 보조 채널로 안전하게 즉시 전달되었습니다.",
      "",
      `• 전환 일시: ${timestamp}`,
      `• 주 채널 상태: ${safeReason}`,
      "------------------------------------------",
      safeMsg,
      "------------------------------------------",
      "👉 셋업 마법사 접속: http://localhost:5678"
    ].join("\n");
  }

  /**
   * 보조 웹훅으로 HTTP POST 전송 (Slack, Discord, 범용 JSON 호환)
   * @param {string} webhookUrl 
   * @param {string} messageText 
   */
  sendWebhook(webhookUrl, messageText) {
    if (typeof webhookUrl !== "string" || !webhookUrl.trim()) {
      return Promise.resolve({ success: false, error: "INVALID_WEBHOOK_URL" });
    }
    const safeText = typeof messageText === "string" ? messageText : JSON.stringify(messageText ?? "");
    return new Promise((resolve) => {
      try {
        const urlObj = new URL(webhookUrl);
        const isHttps = urlObj.protocol === "https:";
        const transport = isHttps ? https : http;

        let payload;
        if (webhookUrl.includes("discord.com")) {
          payload = JSON.stringify({ content: safeText });
        } else {
          // Slack 및 범용 웹훅 표준
          payload = JSON.stringify({ text: safeText });
        }

        const reqOptions = {
          hostname: urlObj.hostname,
          port: urlObj.port || (isHttps ? 443 : 80),
          path: urlObj.pathname + urlObj.search,
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(payload)
          },
          timeout: 4000
        };

        const req = transport.request(reqOptions, (res) => {
          let resData = "";
          res.on("data", chunk => { resData += chunk; });
          res.on("end", () => {
            if (res.statusCode >= 200 && res.statusCode < 300) {
              resolve({ success: true, statusCode: res.statusCode });
            } else {
              resolve({ success: false, statusCode: res.statusCode, response: resData });
            }
          });
        });

        req.on("error", (err) => {
          resolve({ success: false, error: err.message });
        });

        req.on("timeout", () => {
          req.destroy();
          resolve({ success: false, error: "WEBHOOK_REQUEST_TIMEOUT" });
        });

        req.write(payload);
        req.end();
      } catch (err) {
        resolve({ success: false, error: err.message });
      }
    });
  }

  /**
   * 텔레그램 발송 실패 시 보조 채널로 지능형 페일오버 실행
   * @param {object} config - notification_settings.json 객체
   * @param {string} originalMessage - 원본 주문 알림 메시지
   * @param {string} primaryError - 주 채널 에러 사유
   * @returns {Promise<{failedOver: boolean, channel: string, success: boolean, reason?: string}>}
   */
  async executeFailover(config = {}, originalMessage = "", primaryError = "TELEGRAM_FAILED") {
    config = (config && typeof config === "object") ? config : {};
    const secondaryUrl = this.getSecondaryWebhookUrl(config);
    if (!secondaryUrl) {
      return {
        failedOver: false,
        reason: "NO_SECONDARY_WEBHOOK_CONFIGURED",
        message: "보조 알림 채널(Slack/Discord/Webhook)이 등록되지 않아 페일오버를 수행하지 못했습니다."
      };
    }

    const failoverMsg = this.formatFailoverMessage(originalMessage, primaryError);
    const sendResult = await this.sendWebhook(secondaryUrl, failoverMsg);

    const safePrimaryErr = (typeof primaryError === "string" && primaryError.trim()) ? primaryError.trim() : "TELEGRAM_FAILED";
    const eventRecord = {
      timestamp: new Date().toISOString(),
      primaryError: safePrimaryErr,
      secondaryUrlMasked: secondaryUrl.replace(/(hooks\.slack\.com\/services\/[^\/]+\/[^\/]+\/)[^/]+/, "$1***").replace(/(discord\.com\/api\/webhooks\/[^\/]+\/)[^/]+/, "$1***"),
      success: sendResult.success,
      details: sendResult.error || `HTTP ${sendResult.statusCode}`
    };

    if (!Array.isArray(this.history)) {
      this.history = [];
    }
    this.history.push(eventRecord);
    this._saveHistory();

    return {
      failedOver: true,
      channel: secondaryUrl.includes("discord.com") ? "DISCORD" : (secondaryUrl.includes("slack.com") ? "SLACK" : "CUSTOM_WEBHOOK"),
      success: sendResult.success,
      details: eventRecord.details
    };
  }

  /**
   * 페일오버 상태 및 이력 조회
   */
  getFailoverStatus(config = {}) {
    config = (config && typeof config === "object") ? config : {};
    const secondaryUrl = this.getSecondaryWebhookUrl(config);
    const list = Array.isArray(this.history) ? this.history : [];
    return {
      isConfigured: !!secondaryUrl,
      configuredChannel: secondaryUrl ? (secondaryUrl.includes("discord.com") ? "DISCORD" : (secondaryUrl.includes("slack.com") ? "SLACK" : "CUSTOM_WEBHOOK")) : "NONE",
      totalFailoverEvents: list.length,
      recentEvents: list.slice(-5).reverse()
    };
  }
}

const defaultNotificationFailoverSentinel = new NotificationFailoverSentinel();

module.exports = {
  NotificationFailoverSentinel,
  notificationFailoverSentinel: defaultNotificationFailoverSentinel
};
