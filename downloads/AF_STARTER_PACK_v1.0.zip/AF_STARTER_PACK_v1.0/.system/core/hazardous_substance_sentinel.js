/**
 * AutoFlow Enterprise Hazardous Substance & Overseas Direct Purchase Screening Sentinel (GATE_LEGAL_14)
 * ------------------------------------------------------------------------------------------------------
 * 식품위생법 제4조(10년 이하 징역 또는 1억 원 이하 벌금) 및 수입식품안전관리 특별법 제25조
 * 형사처벌 리스크를 1초 만에 원천 차단하는 유해물질·해외직구 반입금지성분 스크리닝 센티널.
 *
 * [주요 기능]
 * 1. 식약처 부정·불량식품/해외직구 반입차단 원료 DB 110여 종 구축
 *    - 발기부전치료제 및 유사물질, 비만치료제, 중추신경계/최음/각성(요힘빈, 마황, 멜라토닌 등),
 *      배변유도(센나잎 등), 스테로이드/호르몬, 마약/환각, 화장품 배합금지, 광우병(BSE) 동물성 원료 등.
 * 2. 식품표시광고법 기준 알레르기 유발물질 19종 감별 맵
 *    - 난류, 우유, 메밀, 땅콩, 대두, 밀, 고등어, 게, 새우, 돼지고기, 복숭아, 토마토,
 *      아황산류, 호두, 닭고기, 쇠고기, 오징어, 조개류, 잣
 * 3. 4대 판정 엔진 (auditHazardousSubstances):
 *    - SUBSTANCE_SAFE (100점, 적합)
 *    - SUBSTANCE_CAUTION_ALLERGEN (85점, 알레르기 안내 권고)
 *    - SUBSTANCE_QUARANTINE_WARNING (50점, 통관보류/검역주의, 건당 100만 원 사전방어)
 *    - SUBSTANCE_CRITICAL_BANNED (10점, 식약처 반입금지 위해성분, 건당 500만 원 벌금/과징금 사전방어)
 * 4. Pure White Clean Enterprise 라이트 모드 공식 성분 검토 증적서 및 식약처 소명서 HTML 발급
 *    - (인쇄 시 직인 생략) 공문서 표준 준수, 붉은 직인 0건, 다크모드 영구 금지
 * 5. 영속 원장 관리 (logs/hazardous_substance_audits.json) 및 종결 처리 지원
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

/**
 * 1. 식약처 지정 위해성분 / 해외직구 반입금지 및 검역주의 원료 데이터베이스 (110종)
 */
const HAZARDOUS_SUBSTANCE_DATABASE = [
  // --- [발기부전치료제 및 유사물질 / 신종 부정물질] (CRITICAL) ---
  {
    id: "SILDENAFIL",
    nameKo: "실데나필",
    nameEn: "Sildenafil",
    aliases: ["비아그라", "viagra", "sildenafil citrate", "구연산실데나필"],
    category: "부정물질(발기부전)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조 (10년 이하 징역 또는 1억 원 이하 벌금)",
    penaltyWon: 5000000,
    description: "발기부전치료 전문의약품 성분. 식품 배합 절대 불가 부정물질."
  },
  {
    id: "TADALAFIL",
    nameKo: "타다라필",
    nameEn: "Tadalafil",
    aliases: ["시알리스", "cialis", "tadalafil", "타다라필유사체"],
    category: "부정물질(발기부전)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조 (10년 이하 징역 또는 1억 원 이하 벌금)",
    penaltyWon: 5000000,
    description: "장시간 지속형 발기부전치료 전문의약품 성분. 심혈관계 부작용 치명적 위험."
  },
  {
    id: "VARDENAFIL",
    nameKo: "바데나필",
    nameEn: "Vardenafil",
    aliases: ["레비트라", "levitra", "vardenafil hcl"],
    category: "부정물질(발기부전)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "발기부전치료 성분. 무허가 혼입 시 식품위생법상 형사처벌 대상."
  },
  {
    id: "UDENAFIL",
    nameKo: "유데나필",
    nameEn: "Udenafil",
    aliases: ["자이데나", "zydena"],
    category: "부정물질(발기부전)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "합성 발기부전치료 의약품 성분."
  },
  {
    id: "AVANAFIL",
    nameKo: "아바나필",
    nameEn: "Avanafil",
    aliases: ["스텐드라", "stendra", "zepeed", "제피드"],
    category: "부정물질(발기부전)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "발기부전치료제 전문의약품 성분."
  },
  {
    id: "MIRODENAFIL",
    nameKo: "미로데나필",
    nameEn: "Mirodenafil",
    aliases: ["엠빅스", "mvix"],
    category: "부정물질(발기부전)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "발기부전치료 의약품 성분."
  },
  {
    id: "HOMOSILDENAFIL",
    nameKo: "호모실데나필",
    nameEn: "Homosildenafil",
    aliases: ["homosildenafil", "호모 실데나필"],
    category: "부정물질(유사체)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "실데나필 유사 합성 부정물질."
  },
  {
    id: "DIMETHYLSILDENAFIL",
    nameKo: "디메틸실데나필",
    nameEn: "Dimethylsildenafil",
    aliases: ["dimethylsildenafil", "디메틸 실데나필"],
    category: "부정물질(유사체)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "단속 회피 목적 실데나필 구조 변형 유사체."
  },
  {
    id: "DIMETHYLTADALAFIL",
    nameKo: "디메틸타다라필",
    nameEn: "Dimethyltadalafil",
    aliases: ["dimethyltadalafil"],
    category: "부정물질(유사체)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "타다라필 유사 합성 신종 부정물질."
  },
  {
    id: "CHLOROPRETADALAFIL",
    nameKo: "클로로프레타다라필",
    nameEn: "Chloropretadalafil",
    aliases: ["chloropretadalafil"],
    category: "부정물질(유사체)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "타다라필 유사 합성 신종 부정물질."
  },
  {
    id: "NORNEOSILDENAFIL",
    nameKo: "노르네오실데나필",
    nameEn: "Norneosildenafil",
    aliases: ["norneosildenafil"],
    category: "부정물질(유사체)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "실데나필 신종 합성 유사체."
  },
  {
    id: "OXOHONGDENAFIL",
    nameKo: "옥소홍데나필",
    nameEn: "Oxohongdenafil",
    aliases: ["oxohongdenafil"],
    category: "부정물질(유사체)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "홍데나필 산화 신종 불법 합성물."
  },
  {
    id: "HONGDENAFIL",
    nameKo: "홍데나필",
    nameEn: "Hongdenafil",
    aliases: ["hongdenafil"],
    category: "부정물질(유사체)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "불법 혼입 발기유사 합성물질."
  },
  {
    id: "THIOSILDENAFIL",
    nameKo: "티오실데나필",
    nameEn: "Thiosildenafil",
    aliases: ["thiosildenafil"],
    category: "부정물질(유사체)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "황 치환 실데나필 유사체."
  },

  // --- [비만치료제 / 식욕억제제 / 다이어트 부정물질] (CRITICAL) ---
  {
    id: "SIBUTRAMINE",
    nameKo: "시부트라민",
    nameEn: "Sibutramine",
    aliases: ["리덕틸", "reductil", "meridia", "시부트라민염산염"],
    category: "부정물질(비만치료)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조 (10년 이하 징역 또는 1억 원 이하 벌금)",
    penaltyWon: 5000000,
    description: "뇌졸중 및 심근경색 사망 위험으로 전 세계 퇴출된 비만치료제 성분."
  },
  {
    id: "DESMETHYLSIBUTRAMINE",
    nameKo: "데스메틸시부트라민",
    nameEn: "Desmethylsibutramine",
    aliases: ["desmethylsibutramine", "n-desmethylsibutramine"],
    category: "부정물질(비만치료)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "시부트라민 대사체 기반 불법 다이어트 혼입물질."
  },
  {
    id: "DIDESMETHYLSIBUTRAMINE",
    nameKo: "디데스메틸시부트라민",
    nameEn: "Didesmethylsibutramine",
    aliases: ["didesmethylsibutramine"],
    category: "부정물질(비만치료)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "시부트라민 유도체 불법 성분."
  },
  {
    id: "LORCASERIN",
    nameKo: "로카세린",
    nameEn: "Lorcaserin",
    aliases: ["벨빅", "belviq"],
    category: "부정물질(비만치료)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "암 발생 위험성 증가로 판매 중단된 비만치료 성분."
  },
  {
    id: "MAZINDOL",
    nameKo: "마진돌",
    nameEn: "Mazindol",
    aliases: ["사노렉스", "sanorex"],
    category: "부정물질(식욕억제)",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률 / 식품위생법 제4조",
    penaltyWon: 5000000,
    description: "향정신성의약품 식욕억제제."
  },
  {
    id: "PHENTERMINE",
    nameKo: "펜터민",
    nameEn: "Phentermine",
    aliases: ["디에타민", "dietamin", "아디펙스", "adipex", "나비약"],
    category: "부정물질(식욕억제)",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률 향정의약품",
    penaltyWon: 5000000,
    description: "중추신경 흥분 향정신성 식욕억제제. 식품 혼입 절대 금지."
  },
  {
    id: "PHENDIMETRAZINE",
    nameKo: "펜디메트라진",
    nameEn: "Phendimetrazine",
    aliases: ["푸리민", "bontril", "본트릴"],
    category: "부정물질(식욕억제)",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률 향정의약품",
    penaltyWon: 5000000,
    description: "향정신성 식욕억제제 의약품 성분."
  },
  {
    id: "DIETHYLPROPION",
    nameKo: "디에틸프로피온",
    nameEn: "Diethylpropion",
    aliases: ["테뉴에이트", "tenuate", "amfepramone", "암페프라몬"],
    category: "부정물질(식욕억제)",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률 향정의약품",
    penaltyWon: 5000000,
    description: "중추신경계 자극 식욕억제제."
  },
  {
    id: "FENFLURAMINE",
    nameKo: "펜플루라민",
    nameEn: "Fenfluramine",
    aliases: ["fenfluramine", "fen-phen", "펜펜"],
    category: "부정물질(식욕억제)",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "심장 판막증 유발로 전세계 퇴출된 위험 성분."
  },

  // --- [중추신경계 / 최음 / 각성 / 수면 / 신경전달물질] (CRITICAL) ---
  {
    id: "YOHIMBINE",
    nameKo: "요힘빈",
    nameEn: "Yohimbine",
    aliases: ["yohimbine", "yohimbe", "요힘베", "염산요힘빈", "yohimbine hcl", "pausinystalia yohimbe"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조 / 식품위생법 제4조",
    penaltyWon: 5000000,
    description: "중추신경 흥분제, 혈압급상승, 어지럼증, 환각 유발. 해외직구 최우선 차단 성분."
  },
  {
    id: "EPHEDRA",
    nameKo: "마황",
    nameEn: "Ephedra",
    aliases: ["마황추출물", "ephedra sinica", "ephedra extract", "ma huang"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조 / 약사법",
    penaltyWon: 5000000,
    description: "에페드린을 함유하여 뇌졸중, 부정맥, 돌연사 위험이 높은 한약재/원료."
  },
  {
    id: "EPHEDRINE",
    nameKo: "에페드린",
    nameEn: "Ephedrine",
    aliases: ["ephedrine", "ephedrine hcl", "염산에페드린"],
    category: "부정물질(각성제)",
    riskLevel: "CRITICAL",
    legalRef: "마약류 전구물질 / 식품위생법 제4조",
    penaltyWon: 5000000,
    description: "마약류(필로폰) 전구물질 및 중추신경 흥분제."
  },
  {
    id: "PSEUDOEPHEDRINE",
    nameKo: "슈도에페드린",
    nameEn: "Pseudoephedrine",
    aliases: ["pseudoephedrine", "의사에페드린"],
    category: "부정물질(각성제)",
    riskLevel: "CRITICAL",
    legalRef: "마약류 전구물질 / 약사법",
    penaltyWon: 5000000,
    description: "마약류 원료물질 및 비충혈제거 의약품 성분."
  },
  {
    id: "MELATONIN",
    nameKo: "멜라토닌",
    nameEn: "Melatonin",
    aliases: ["melatonin", "멜라토닌합성", "서카딘", "circadin", "수면호르몬"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조 / 약사법(국내 전문의약품)",
    penaltyWon: 5000000,
    description: "국내 전문의약품 성분으로 지정. 해외직구 건기식 통관 반입 전면 금지."
  },
  {
    id: "5_HTP",
    nameKo: "5-HTP",
    nameEn: "5-Hydroxytryptophan",
    aliases: ["5-htp", "5-하이드록시트립토판", "5 hydroxytryptophan", "griffonia seed"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "세로토닌 증후군 및 호산구과다근육통증후군(EMS) 유발 우려 성분."
  },
  {
    id: "DHEA",
    nameKo: "DHEA",
    nameEn: "Dehydroepiandrosterone",
    aliases: ["dhea", "디하이드로에피안드로스테론", "prasterone", "프라스테론"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조 / 약사법",
    penaltyWon: 5000000,
    description: "스테로이드 호르몬 전구체. 호르몬 불균형 및 종양 촉진 우려 반입 금지."
  },
  {
    id: "KAVA_KAVA",
    nameKo: "카바카바",
    nameEn: "Kava Kava",
    aliases: ["kava", "카바", "piper methysticum", "kava extract"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "중증 간독성 및 급성 간부전 유발로 전면 사용 금지."
  },
  {
    id: "GABA_HIGH",
    nameKo: "고농도 가바",
    nameEn: "Gamma-Aminobutyric Acid High",
    aliases: ["pharma gaba", "합성가바", "gaba 500mg", "gaba 750mg"],
    category: "식약처 규제의약품",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "식품원료 미등재 고농도 합성 신경전달물질 해외직구 반입제한."
  },
  {
    id: "THEOBROMINE_HIGH",
    nameKo: "테오브로민",
    nameEn: "Theobromine",
    aliases: ["theobromine", "테오브로민추출물"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "심혈관계 자극 및 부정맥 유발 우려 고농도 알칼로이드."
  },
  {
    id: "PHENIBUT",
    nameKo: "페니벗",
    nameEn: "Phenibut",
    aliases: ["phenibut", "페니부트", "noofen", "노오펜"],
    category: "향정신성의약품",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률",
    penaltyWon: 5000000,
    description: "의존성 및 금단 증상이 극심한 뇌신경 억제제."
  },
  {
    id: "TIANEPTINE",
    nameKo: "티아넵틴",
    nameEn: "Tianeptine",
    aliases: ["tianeptine", "스타브론", "stablon", "가스스테이션헤로인"],
    category: "향정신성의약품",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률 / 식품위생법 제4조",
    penaltyWon: 5000000,
    description: "오피오이드 유사 중독을 일으키는 전문 항우울제 성분."
  },
  {
    id: "PICAMILON",
    nameKo: "피카밀론",
    nameEn: "Picamilon",
    aliases: ["picamilon", "pikamilon"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "니코틴산과 GABA를 결합한 합성 뇌혈관 치료제 성분."
  },

  // --- [배변유도 / 설사제 / 장청소 부정물질] (CRITICAL) ---
  {
    id: "SENNA",
    nameKo: "센나엽",
    nameEn: "Senna",
    aliases: ["센나", "센나잎", "senna alexandrina", "sennoside", "센노사이드", "senna leaf"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조 / 약사법(의약품 전용)",
    penaltyWon: 5000000,
    description: "대장흑색증 유발 및 장신경 손상. 식품 배합 불가 의약품 성분."
  },
  {
    id: "CASCARA_SAGRADA",
    nameKo: "카스카라사그라다",
    nameEn: "Cascara Sagrada",
    aliases: ["cascara sagrada", "카스카라", "rhamnus purshiana"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "발암성 안트라퀴논 함유로 식품 및 일반의약품 퇴출 원료."
  },
  {
    id: "ALOE_EMODIN",
    nameKo: "알로에에모딘",
    nameEn: "Aloe-Emodin",
    aliases: ["aloe emodin", "알로에 에모딘"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "유전독성 및 장기 손상 우려 고농도 추출물."
  },
  {
    id: "BISACODYL",
    nameKo: "비사코딜",
    nameEn: "Bisacodyl",
    aliases: ["bisacodyl", "둘코락스성분"],
    category: "부정물질(설사제)",
    riskLevel: "CRITICAL",
    legalRef: "약사법 / 식품위생법 제4조",
    penaltyWon: 5000000,
    description: "자극성 완화제 전문의약품 성분. 다이어트 식품 불법 혼입 금지."
  },
  {
    id: "PHENOLPHTHALEIN",
    nameKo: "페놀프탈레인",
    nameEn: "Phenolphthalein",
    aliases: ["phenolphthalein"],
    category: "발암물질/부정물질",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "인체 발암물질로 전 세계 사용 금지된 과거 하제 성분."
  },

  // --- [남성활력 / 한약재 / 최음 유해물질] (CRITICAL) ---
  {
    id: "ICARIIN",
    nameKo: "이카린",
    nameEn: "Icariin",
    aliases: ["icariin", "음양곽", "삼지구엽초", "epimedium", "horny goat weed", "음양곽추출물"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조 / 식품위생법 제4조",
    penaltyWon: 5000000,
    description: "PDE5 억제 활성을 가진 음양곽 주성분. 심장마비 및 급성 저혈압 위험."
  },
  {
    id: "TONGKAT_ALI",
    nameKo: "통캇알리",
    nameEn: "Tongkat Ali",
    aliases: ["tongkat ali", "유리카마 롱기폴리아", "eurycoma longifolia", "롱잭", "longjack"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "세포독성 및 유전독성 안전성 미입증으로 국내 반입 전면 금지."
  },
  {
    id: "DAMIANA",
    nameKo: "다미아나",
    nameEn: "Damiana",
    aliases: ["damiana", "turnera diffusa", "다미아나잎"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "최음/환각 유발 우려 생약 원료."
  },
  {
    id: "MUIRA_PUAMA",
    nameKo: "무이라푸아마",
    nameEn: "Muira Puama",
    aliases: ["muira puama", "ptychopetalum olacoides"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "남성 최음 목적으로 유통되는 수입금지 식물원료."
  },
  {
    id: "CANTHARIDIN",
    nameKo: "칸타리딘",
    nameEn: "Cantharidin",
    aliases: ["cantharidin", "스패니시플라이", "spanish fly"],
    category: "맹독성 물질",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조 / 형법",
    penaltyWon: 5000000,
    description: "신장 괴사 및 치사율이 높은 맹독성 최음 부정물질."
  },

  // --- [근육강화 / 아나볼릭 스테로이드 / SARMs / 펩타이드] (CRITICAL) ---
  {
    id: "ANDROSTENEDIONE",
    nameKo: "안드로스텐디온",
    nameEn: "Androstenedione",
    aliases: ["androstenedione", "andro"],
    category: "아나볼릭스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "도핑금지약물 / 약사법 / 식품위생법 제4조",
    penaltyWon: 5000000,
    description: "체내 테스토스테론 전환 스테로이드 호르몬제."
  },
  {
    id: "TESTOSTERONE",
    nameKo: "테스토스테론",
    nameEn: "Testosterone",
    aliases: ["testosterone", "테스토스테론에난테이트", "cypionate"],
    category: "아나볼릭스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "전문오남용우려의약품",
    penaltyWon: 5000000,
    description: "합성 남성호르몬 전문의약품. 불법 반입 시 엄중 처벌."
  },
  {
    id: "NANDROLONE",
    nameKo: "난드롤론",
    nameEn: "Nandrolone",
    aliases: ["nandrolone", "데카듀라보린", "deca-durabolin"],
    category: "아나볼릭스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "오남용우려의약품",
    penaltyWon: 5000000,
    description: "단백동화 스테로이드."
  },
  {
    id: "STANOZOLOL",
    nameKo: "스타노조롤",
    nameEn: "Stanozolol",
    aliases: ["stanozolol", "윈스트롤", "winstrol"],
    category: "아나볼릭스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "도핑금지물질",
    penaltyWon: 5000000,
    description: "간독성이 매우 치명적인 동화작용 스테로이드."
  },
  {
    id: "BOLDENONE",
    nameKo: "볼데논",
    nameEn: "Boldenone",
    aliases: ["boldenone", "이퀴포이즈", "equipoise"],
    category: "아나볼릭스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "동물용 아나볼릭 스테로이드."
  },
  {
    id: "OXANDROLONE",
    nameKo: "옥산드롤론",
    nameEn: "Oxandrolone",
    aliases: ["oxandrolone", "아나바", "anavar"],
    category: "아나볼릭스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "단백동화제 불법 의약품 성분."
  },
  {
    id: "TRENBOLONE",
    nameKo: "트렌볼론",
    nameEn: "Trenbolone",
    aliases: ["trenbolone", "트렌", "tren"],
    category: "아나볼릭스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "최고위험도 합성 스테로이드."
  },
  {
    id: "OSTARINE",
    nameKo: "오스타린",
    nameEn: "Ostarine (MK-2866)",
    aliases: ["ostarine", "mk-2866", "enobosarm", "에노보삼"],
    category: "SARMs(선택적안드로겐수용체조절제)",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조 / 식품위생법 제4조",
    penaltyWon: 5000000,
    description: "FDA 경고 및 식약처 해외직구 반입차단 1순위 SARMs 성분."
  },
  {
    id: "LIGANDROL",
    nameKo: "리간드롤",
    nameEn: "Ligandrol (LGD-4033)",
    aliases: ["ligandrol", "lgd-4033", "lgd4033"],
    category: "SARMs",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "간 손상 및 심근경색 유발 경고 SARMs."
  },
  {
    id: "IBUTAMOREN",
    nameKo: "이부타모렌",
    nameEn: "Ibutamoren (MK-677)",
    aliases: ["ibutamoren", "mk-677", "mk677", "성장호르몬분비촉진제"],
    category: "성장호르몬촉진제",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "임상 중단된 성장호르몬 분비촉진 미승인 약물."
  },
  {
    id: "CARDARINE",
    nameKo: "카다린",
    nameEn: "Cardarine (GW-501516)",
    aliases: ["cardarine", "gw-501516", "gw501516", "endurobol"],
    category: "PPARδ작용제",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "동물실험 전신 다발성 종양 발생으로 개발 중단된 발암 약물."
  },
  {
    id: "RAD_140",
    nameKo: "라드-140",
    nameEn: "Testolone (RAD-140)",
    aliases: ["rad-140", "rad140", "testolone", "테스토론"],
    category: "SARMs",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "간부전 유발 SARMs 불법 약물."
  },
  {
    id: "DMAA",
    nameKo: "디메틸아밀아민",
    nameEn: "DMAA (1,3-Dimethylamylamine)",
    aliases: ["dmaa", "1,3-dimethylamylamine", "geranamine", "제라나민"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "부정맥, 심장마비 및 뇌출혈 유발 강력 각성 부스터 원료."
  },
  {
    id: "DMBA",
    nameKo: "디메틸부틸아민",
    nameEn: "DMBA (1,3-Dimethylbutylamine)",
    aliases: ["dmba", "1,3-dimethylbutylamine", "amp citrate", "엠프시트레이트"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "DMAA 유사 합성 각성제."
  },
  {
    id: "DMHA",
    nameKo: "옥토드린",
    nameEn: "DMHA / Octodrine",
    aliases: ["dmha", "octodrine", "2-amino-6-methylheptane"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "중추신경 자극 합성 아민."
  },
  {
    id: "SYNEPHRINE_HIGH",
    nameKo: "고농도 시네프린",
    nameEn: "Synephrine High Dose",
    aliases: ["synephrine", "bitter orange extract", "시트러스 아우란티움", "citrus aurantium"],
    category: "식약처 규제성분",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "에페드린 유사 심혈관계 혈압 급상승 부작용 유발."
  },
  {
    id: "HORDENINE",
    nameKo: "호르데닌",
    nameEn: "Hordenine",
    aliases: ["hordenine", "hordenine hcl"],
    category: "식약처 반입금지원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "중추신경 흥분 알칼로이드."
  },

  // --- [마약류 / 환각 / 오피오이드 / 향정 성분] (CRITICAL) ---
  {
    id: "THC",
    nameKo: "THC / 대마성분",
    nameEn: "Tetrahydrocannabinol",
    aliases: ["thc", "tetrahydrocannabinol", "대마", "마리화나", "weed", "marijuana"],
    category: "마약류",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률 제2조 (무기 또는 5년 이상 징역)",
    penaltyWon: 5000000,
    description: "대마 환각 주성분. 젤리/오일 형태 직구 시 징역형 형사입건."
  },
  {
    id: "CBD_UNAPPROVED",
    nameKo: "미승인 CBD",
    nameEn: "Cannabidiol Unapproved",
    aliases: ["cbd gummy", "cbd 오일", "cbd oil", "cannabidiol"],
    category: "마약류(해외직구차단)",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률",
    penaltyWon: 5000000,
    description: "식약처 수입 승인 외 CBD 일반직구 전면 불법 반입금지."
  },
  {
    id: "KRATOM",
    nameKo: "크라톰",
    nameEn: "Kratom",
    aliases: ["kratom", "mitragyna speciosa", "mitragynine", "미트라지닌"],
    category: "마약류",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률 향정의약품",
    penaltyWon: 5000000,
    description: "오피오이드 수용체 결합 강력 마약성 식물."
  },
  {
    id: "OPIUM_ALKALOIDS",
    nameKo: "양귀비/아편",
    nameEn: "Papaver Somniferum / Opium",
    aliases: ["양귀비종자 미열처리", "papaver somniferum", "opium", "모르핀원료"],
    category: "마약류",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률",
    penaltyWon: 5000000,
    description: "아편 알칼로이드 함유 천연 마약 원료."
  },
  {
    id: "PSILOCYBIN",
    nameKo: "실로시빈 (환각버섯)",
    nameEn: "Psilocybin",
    aliases: ["psilocybin", "magic mushroom", "환각버섯"],
    category: "마약류",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률",
    penaltyWon: 5000000,
    description: "강력한 중추신경 환각 유발 버섯 성분."
  },
  {
    id: "SALVIA_DIVINORUM",
    nameKo: "살비아 디비노룸",
    nameEn: "Salvia Divinorum",
    aliases: ["salvia divinorum", "salvinorin a"],
    category: "마약류",
    riskLevel: "CRITICAL",
    legalRef: "마약류 관리에 관한 법률",
    penaltyWon: 5000000,
    description: "초단기 강력 환각 유발 허브."
  },

  // --- [독성 한약재 / 천연독소 / 수입금지 식물원료] (CRITICAL) ---
  {
    id: "ARISTOLOCHIC_ACID",
    nameKo: "아리스토로크산",
    nameEn: "Aristolochic Acid",
    aliases: ["마두령", "관목통", "청목향", "aristolochia", "아리스토로키아"],
    category: "1급발암물질/신장독성",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "비가역적 신부전 및 비뇨기암 유발 1급 발암물질."
  },
  {
    id: "ACONITINE",
    nameKo: "아코니틴 (부자/초오)",
    nameEn: "Aconitine",
    aliases: ["부자", "초오", "천오", "aconitum", "aconitine"],
    category: "맹독성 생약",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "심장마비 치사 맹독성 알칼로이드."
  },
  {
    id: "STRYCHNINE",
    nameKo: "스트리크닌 (마전/호미카)",
    nameEn: "Strychnine",
    aliases: ["마전자", "strychnos nux-vomica", "호미카"],
    category: "맹독성 물질",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "전신 경련 및 호흡마비 치사 맹독 물질."
  },
  {
    id: "BETEL_NUT",
    nameKo: "빈랑자",
    nameEn: "Betel Nut / Areca Catechu",
    aliases: ["빈랑", "areca nut", "arecoline", "아레콜린"],
    category: "1급발암물질",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조 / 관세법",
    penaltyWon: 5000000,
    description: "구강암 유발 1급 발암물질. 식약처 전면 반입 금지."
  },
  {
    id: "BLACK_COHOSH_RISK",
    nameKo: "블랙 코호시",
    nameEn: "Black Cohosh (Actaea racemosa)",
    aliases: ["black cohosh", "승마추출물 미승인", "actaea racemosa"],
    category: "식약처 규제생약",
    riskLevel: "CRITICAL",
    legalRef: "수입식품안전관리 특별법 제25조",
    penaltyWon: 5000000,
    description: "급성 간독성 위험으로 일반 수입식품 배합 불가."
  },
  {
    id: "COMFREY",
    nameKo: "컴프리",
    nameEn: "Comfrey (Symphytum officinale)",
    aliases: ["comfrey", "컴프리잎", "피롤리지딘 알칼로이드"],
    category: "간독성/발암원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "간정맥폐쇄질환 및 간암 유발 원료."
  },
  {
    id: "CHAPARRAL",
    nameKo: "차파랄",
    nameEn: "Chaparral (Larrea tridentata)",
    aliases: ["chaparral", "크레오소트 관목"],
    category: "간독성 식물",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "간부전 유발 식품원료 사용 금지."
  },
  {
    id: "GERMANDER",
    nameKo: "저맨더",
    nameEn: "Germander (Teucrium chamaedrys)",
    aliases: ["germander", "저먼더"],
    category: "간독성 식물",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "급성 간염 유발로 퇴출된 허브."
  },
  {
    id: "PENNYROYAL",
    nameKo: "페니로열",
    nameEn: "Pennyroyal (Mentha pulegium)",
    aliases: ["pennyroyal", "풀레곤", "pulegone"],
    category: "치명적 독성식물",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "유산 유도 및 다발성 장기부전 유발 독성 물질."
  },
  {
    id: "COLTSFOOT",
    nameKo: "관동화",
    nameEn: "Coltsfoot (Tussilago farfara)",
    aliases: ["coltsfoot", "관동포", "tussilago farfara"],
    category: "간독성 원료",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "발암성 피롤리지딘 함유 미승인 수입식물."
  },
  {
    id: "RAUWOLFIA",
    nameKo: "라우볼피아",
    nameEn: "Rauwolfia Serpentina",
    aliases: ["rauwolfia", "reserpine", "레세르핀"],
    category: "의약품 전용식물",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "중증 우울증 및 서맥 유발 전문의약품 추출물."
  },
  {
    id: "GINKGO_RAW",
    nameKo: "은행엽 무정제 추출물",
    nameEn: "Raw Ginkgo Biloba Leaf",
    aliases: ["은행잎조추출물", "징코톡신", "ginkgotoxin"],
    category: "신경독소",
    riskLevel: "CRITICAL",
    legalRef: "식품위생법 제4조",
    penaltyWon: 5000000,
    description: "정제되지 않은 은행엽의 징코톡신 경련 독소 유발."
  },

  // --- [화장품 배합금지 및 유해 화학물질] (CRITICAL) ---
  {
    id: "HYDROQUINONE",
    nameKo: "하이드로퀴논",
    nameEn: "Hydroquinone",
    aliases: ["hydroquinone", "히드로퀴논", "미백연고성분"],
    category: "화장품배합금지",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조 (배합금지)",
    penaltyWon: 5000000,
    description: "백반증 및 외인성 갈색증 유발. 화장품 배합 절대 금지 전문의약품."
  },
  {
    id: "MERCURY",
    nameKo: "수은 및 수은화합물",
    nameEn: "Mercury and Compounds",
    aliases: ["수은", "mercury", "calomel", "염화제일수은"],
    category: "화장품배합금지/중금속",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조 / 보건범죄단속에 관한 특별조치법",
    penaltyWon: 5000000,
    description: "신장 손상 및 중추신경계 마비 유발 치명적 맹독 중금속."
  },
  {
    id: "CLOBETASOL",
    nameKo: "클로베타솔",
    nameEn: "Clobetasol Propionate",
    aliases: ["clobetasol", "더모베이트", "초강력스테로이드"],
    category: "화장품배합금지/스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조 / 약사법",
    penaltyWon: 5000000,
    description: "피부 위축 및 부신 억제 유발 1등급 스테로이드."
  },
  {
    id: "BETAMETHASONE",
    nameKo: "베타메타손",
    nameEn: "Betamethasone",
    aliases: ["betamethasone", "베타메타손디프로피오네이트"],
    category: "화장품배합금지/스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조",
    penaltyWon: 5000000,
    description: "화장품 불법 배합 시 형사처벌 대상 전문의약품."
  },
  {
    id: "DEXAMETHASONE",
    nameKo: "덱사메타손",
    nameEn: "Dexamethasone",
    aliases: ["dexamethasone"],
    category: "화장품배합금지/스테로이드",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조",
    penaltyWon: 5000000,
    description: "면역 억제 스테로이드."
  },
  {
    id: "MINOXIDIL",
    nameKo: "미녹시딜",
    nameEn: "Minoxidil",
    aliases: ["minoxidil", "로게인", "rogaine"],
    category: "화장품배합금지/의약품",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조",
    penaltyWon: 5000000,
    description: "탈모치료 전문/일반의약품. 화장품 배합 엄격 금지."
  },
  {
    id: "TRETINOIN",
    nameKo: "트레티노인 (레틴-A)",
    nameEn: "Tretinoin",
    aliases: ["tretinoin", "스티바에이", "retin-a", "레티노익산"],
    category: "화장품배합금지/의약품",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조",
    penaltyWon: 5000000,
    description: "기형아 출산 기형유발성 비타민A 유도체 전문의약품."
  },
  {
    id: "PHENOXYETHANOL_HIGH",
    nameKo: "고농도 페녹시에탄올",
    nameEn: "Phenoxyethanol > 1.0%",
    aliases: ["페녹시에탄올 1% 초과", "고함량 페녹시에탄올", "high phenoxyethanol"],
    category: "화장품배합한도초과",
    riskLevel: "CRITICAL",
    legalRef: "화장품 안전기준 등에 관한 규정 (1.0% 이하 제한)",
    penaltyWon: 5000000,
    description: "중추신경계 억제 및 피부 알레르기 유발. 1.0% 초과 배합 불가."
  },
  {
    id: "BITHIONOL",
    nameKo: "비티오놀",
    nameEn: "Bithionol",
    aliases: ["bithionol"],
    category: "화장품배합금지",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조",
    penaltyWon: 5000000,
    description: "광독성 및 광알레르기 피부염 유발로 배합 금지."
  },
  {
    id: "CHLOROFORM",
    nameKo: "클로로포름",
    nameEn: "Chloroform",
    aliases: ["chloroform", "트리클로로메탄"],
    category: "화장품배합금지",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조",
    penaltyWon: 5000000,
    description: "간독성 및 마취성 발암 우려 용제 배합 금지."
  },
  {
    id: "HEXACHLOROPHENE",
    nameKo: "헥사클로로펜",
    nameEn: "Hexachlorophene",
    aliases: ["hexachlorophene"],
    category: "화장품배합금지",
    riskLevel: "CRITICAL",
    legalRef: "화장품법 제8조",
    penaltyWon: 5000000,
    description: "뇌부종 및 신경독성 유발 살균제."
  },

  // --- [통관 보류 및 검역 정밀 대상 주의 원료] (QUARANTINE_WARNING: 100만 원 방어) ---
  {
    id: "BOVINE_GELATIN_BSE",
    nameKo: "소 젤라틴 (BSE 우려 미인증)",
    nameEn: "Bovine Gelatin (Uncertified BSE Risk)",
    aliases: ["bovine gelatin", "소 젤라틴", "우골 젤라틴", "bovine capsule", "소 유래 캡슐"],
    category: "동물성/BSE검역위험",
    riskLevel: "QUARANTINE",
    legalRef: "가축전염병예방법 제31조 / 광우병우려국가 수입금지기준",
    penaltyWon: 1000000,
    description: "광우병(BSE) 발생 국가산 소 유래 젤라틴 캡슐 원료 미인증 시 통관 전량 폐기/반송."
  },
  {
    id: "BOVINE_PLACENTA",
    nameKo: "소 태반 추출물",
    nameEn: "Bovine Placenta",
    aliases: ["우태반", "bovine placenta", "소태반추출물"],
    category: "동물성/BSE검역위험",
    riskLevel: "QUARANTINE",
    legalRef: "가축전염병예방법 제31조",
    penaltyWon: 1000000,
    description: "BSE 우려 가축 태반 원료 통관 보류 대상."
  },
  {
    id: "PORCINE_PLACENTA_UNCERT",
    nameKo: "돈태반 미인증",
    nameEn: "Porcine Placenta Uncertified",
    aliases: ["돈태반", "돼지태반", "porcine placenta extract"],
    category: "동물성/검역위험",
    riskLevel: "QUARANTINE",
    legalRef: "수입축산물 검역기준",
    penaltyWon: 1000000,
    description: "ASF(아프리카돼지열병) 우려 국가 검역증명서 미구비 시 통관 폐기."
  },
  {
    id: "BEEF_JERKY_RAW",
    nameKo: "가공육포 / 쇠고기 원료 가공품",
    nameEn: "Uncertified Beef Jerky / Meat Processing",
    aliases: ["소고기육포", "beef jerky", "비프저키", "우육포", "beef sticks"],
    category: "축산물검역정밀대상",
    riskLevel: "QUARANTINE",
    legalRef: "가축전염병예방법 제32조",
    penaltyWon: 1000000,
    description: "정부 지정 수출국 정부 검역증명서 미부착 축산가공품 해외직구 통관 폐기."
  },
  {
    id: "PORK_SALAMI_RAW",
    nameKo: "돈육 살라미 / 가공햄",
    nameEn: "Raw Pork Salami / Sausage",
    aliases: ["돼지고기소시지", "pork sausage", "살라미", "salami", "하몽", "jamon"],
    category: "축산물검역정밀대상",
    riskLevel: "QUARANTINE",
    legalRef: "가축전염병예방법 제32조",
    penaltyWon: 1000000,
    description: "ASF 우려 미열처리 돈육 가공품 통관 반입 전면 차단."
  },
  {
    id: "POULTRY_UNCERT",
    nameKo: "가금육류 / 닭·오리 가공식품",
    nameEn: "Uncertified Poultry Meat",
    aliases: ["닭가슴살육포", "chicken jerky", "오리육포", "duck jerky"],
    category: "축산물검역정밀대상",
    riskLevel: "QUARANTINE",
    legalRef: "가축전염병예방법 제32조",
    penaltyWon: 1000000,
    description: "고병원성 조류인플루엔자(AI) 방역 대상 미승인 가공육 통관 불합격."
  },
  {
    id: "RAW_CITRUS_DRIED",
    nameKo: "미열처리 생과실 건조품",
    nameEn: "Unprocessed Raw Citrus Dried",
    aliases: ["생감귤 건조편", "생오렌지칩", "dried citrus raw"],
    category: "식물검역정밀대상",
    riskLevel: "QUARANTINE",
    legalRef: "식물방역법 제10조",
    penaltyWon: 1000000,
    description: "과실파리류 등 금지병해충 우려 미열처리 과실류 직구 통관 폐기."
  },
  {
    id: "DAIRY_COLOSTRUM",
    nameKo: "미승인 초유 분말",
    nameEn: "Uncertified Colostrum Powder",
    aliases: ["초유단백질", "colostrum powder", "우유초유", "bovine colostrum"],
    category: "유가공품검역정밀대상",
    riskLevel: "QUARANTINE",
    legalRef: "수입식품안전관리 특별법 제20조",
    penaltyWon: 1000000,
    description: "수출국 정부 위생증명서 미제출 유가공품 통관 보류."
  },
  {
    id: "ASHWAGANDHA_HIGH",
    nameKo: "아슈와간다 고농도",
    nameEn: "Ashwagandha High Potency Extract",
    aliases: ["withania somnifera", "아쉬와간다", "위드아놀라이드", "withanolides"],
    category: "통관주의성분",
    riskLevel: "QUARANTINE",
    legalRef: "관세청 해외직구 위해의심물질 모니터링 품목",
    penaltyWon: 1000000,
    description: "간손상 및 임산부 유산 위험 보고로 관세청 정밀 검역 주의 통보 품목."
  },
  {
    id: "ECHINACEA_HERB",
    nameKo: "에키네시아",
    nameEn: "Echinacea Purpurea Herb",
    aliases: ["echinacea", "에키네시아추출물", "coneflower"],
    category: "통관주의성분",
    riskLevel: "QUARANTINE",
    legalRef: "식약처 건기식공전 미등재 생약원료",
    penaltyWon: 1000000,
    description: "자가면역질환 악화 우려로 단일 의약품 목적 직구 통관 심사 강화."
  }
];

/**
 * 2. 식품표시광고법 기준 알레르기 유발물질 19종 데이터베이스
 */
const ALLERGEN_19_DATABASE = [
  { id: "EGG", nameKo: "난류(달걀)", keywords: ["난류", "달걀", "계란", "알부민", "egg", "eggs", "albumen", "난백", "난황"] },
  { id: "MILK", nameKo: "우유", keywords: ["우유", "유제품", "분유", "탈지분유", "유청", "카제인", "casein", "whey", "milk", "dairy", "치즈", "버터"] },
  { id: "BUCKWHEAT", nameKo: "메밀", keywords: ["메밀", "buckwheat", "메밀묵", "메밀가루"] },
  { id: "PEANUT", nameKo: "땅콩", keywords: ["땅콩", "peanut", "peanuts", "땅콩버터", "피넛"] },
  { id: "SOYBEAN", nameKo: "대두(콩)", keywords: ["대두", "콩단백", "두유", "대두유", "soy", "soybean", "soya", "간장", "된장"] },
  { id: "WHEAT", nameKo: "밀", keywords: ["밀", "밀가루", "소맥", "글루텐", "gluten", "wheat", "밀배아"] },
  { id: "MACKEREL", nameKo: "고등어", keywords: ["고등어", "mackerel"] },
  { id: "CRAB", nameKo: "게", keywords: ["게", "crab", "게살", "꽃게", "대게", "키토산(게)"] },
  { id: "SHRIMP", nameKo: "새우", keywords: ["새우", "shrimp", "prawn", "새우분말", "건새우"] },
  { id: "PORK", nameKo: "돼지고기", keywords: ["돼지고기", "돈육", "pork", "라드", "돈지", "돼지젤라틴"] },
  { id: "PEACH", nameKo: "복숭아", keywords: ["복숭아", "peach", "백도", "황도"] },
  { id: "TOMATO", nameKo: "토마토", keywords: ["토마토", "tomato", "토마토페이스트", "케첩"] },
  { id: "SULFITE", nameKo: "아황산류", keywords: ["아황산류", "이산화황", "아황산나트륨", "sulfite", "sulfites", "so2", "메타중아황산나트륨"] },
  { id: "WALNUT", nameKo: "호두", keywords: ["호두", "walnut", "walnuts", "호두오일"] },
  { id: "CHICKEN", nameKo: "닭고기", keywords: ["닭고기", "계육", "chicken", "닭가슴살", "치킨추출물"] },
  { id: "BEEF", nameKo: "쇠고기", keywords: ["쇠고기", "소고기", "우육", "beef", "우지", "소고기분말"] },
  { id: "SQUID", nameKo: "오징어", keywords: ["오징어", "squid", "calamari", "오징어먹물"] },
  { id: "SHELLFISH", nameKo: "조개류(굴/전복/홍합 포함)", keywords: ["조개", "굴", "전복", "홍합", "바지락", "가리비", "shellfish", "oyster", "mussel", "abalone", "clam", "scallop"] },
  { id: "PINE_NUT", nameKo: "잣", keywords: ["잣", "pine nut", "pine nuts"] }
];

/**
 * 센티널 클래스 구현
 */
class HazardousSubstanceSentinel {
  constructor(customStoragePath = null, customConfigPath = null) {
    if (customStoragePath && typeof customStoragePath === "object") {
      this.storagePath = customStoragePath.storagePath || path.join(__dirname, "..", "logs", "hazardous_substance_audits.json");
      this.configPath = customStoragePath.configPath || path.join(__dirname, "..", "config", "setup_config.json");
    } else {
      this.storagePath = customStoragePath || path.join(__dirname, "..", "logs", "hazardous_substance_audits.json");
      this.configPath = customConfigPath || path.join(__dirname, "..", "config", "setup_config.json");
    }
    this.database = HAZARDOUS_SUBSTANCE_DATABASE;
    this.allergenMap = ALLERGEN_19_DATABASE;
    this.ensureStorage();
  }

  ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(this.storagePath, "[]", "utf8");
      }
    } catch (e) {
      // storage init fallback
    }
  }

  _loadAudits() {
    try {
      if (!fs.existsSync(this.storagePath)) return [];
      const data = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(data || "[]");
      return Array.isArray(parsed)
        ? parsed.filter(x => x && typeof x === "object")
        : (parsed && Array.isArray(parsed.audits) ? parsed.audits.filter(x => x && typeof x === "object") : []);
    } catch (e) {
      return [];
    }
  }

  loadAudits() {
    return this._loadAudits();
  }

  _saveAudits(audits) {
    try {
      if (!Array.isArray(audits)) return false;
      const clean = audits.filter(x => x && typeof x === "object");
      this.ensureStorage();
      fs.writeFileSync(this.storagePath, JSON.stringify(clean, null, 2), "utf8");
      return true;
    } catch (e) {
      return false;
    }
  }

  saveAudits(audits) {
    return this._saveAudits(audits);
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsedRaw = JSON.parse(raw || "{}");
        const parsed = (parsedRaw && typeof parsedRaw === "object" && !Array.isArray(parsedRaw)) ? parsedRaw : {};
        return {
          storeName: parsed.storeName || parsed.mallName || "AutoFlow 안심스토어",
          sellerName: parsed.sellerName || parsed.representative || "대표관리자",
          sellerPhone: parsed.sellerPhone || parsed.csPhone || "1544-0000",
          sellerEmail: parsed.sellerEmail || "compliance@autoflow.engine"
        };
      }
    } catch (e) {
      // ignore
    }
    return {
      storeName: "AutoFlow 안심스토어",
      sellerName: "대표관리자",
      sellerPhone: "1544-0000",
      sellerEmail: "compliance@autoflow.engine"
    };
  }

  /**
   * 텍스트 정규화 및 검색
   */
  normalizeText(text) {
    if (!text) return "";
    return String(text).toLowerCase().replace(/[\s\-_/\\,.;:()[\]{}'"+]+/g, "");
  }

  /**
   * 1초 유해물질 및 해외직구 금지성분 스크리닝 엔진 (auditHazardousSubstances)
   */
  auditHazardousSubstances(productData = {}, options = {}) {
    productData = (productData && typeof productData === "object") ? productData : {};
    options = (options && typeof options === "object") ? options : {};
    const productName = String(productData.productName || "").trim();
    const category = String(productData.category || "건강기능식품").trim();
    const rawIngredients = String(productData.ingredients || productData.rawMaterials || "").trim();
    const description = String(productData.description || "").trim();
    const marketplace = String(productData.marketplace || "쿠팡 (Coupang Wing)").trim();
    const countryOfOrigin = String(productData.countryOfOrigin || "해외직구 (미국/일본/유럽)").trim();

    const fullInspectText = `${productName} ${rawIngredients} ${description}`.toLowerCase();
    const normalizedFullText = this.normalizeText(fullInspectText);

    const matchedCriticalBanned = [];
    const matchedQuarantineWarnings = [];
    const matchedAllergens = [];

    // 1. 유해/금지 성분 전수 대사
    for (const item of this.database) {
      const searchTerms = [item.nameKo, item.nameEn, ...(item.aliases || [])];
      let found = false;

      for (const term of searchTerms) {
        if (!term) continue;
        const normTerm = this.normalizeText(term);
        if (normTerm.length < 2) continue;

        // 원문 직접 포함 또는 정규화 텍스트 포함 확인
        if (fullInspectText.includes(term.toLowerCase()) || normalizedFullText.includes(normTerm)) {
          found = true;
          break;
        }
      }

      if (found) {
        if (item.riskLevel === "CRITICAL") {
          matchedCriticalBanned.push(item);
        } else if (item.riskLevel === "QUARANTINE") {
          matchedQuarantineWarnings.push(item);
        }
      }
    }

    // 2. 알레르기 유발물질 19종 대사
    for (const allergen of this.allergenMap) {
      let allergenFound = false;
      for (const kw of allergen.keywords) {
        const normKw = this.normalizeText(kw);
        if (normKw.length < 1) continue;

        // 1글자 키워드는 단어 경계 또는 괄호/쉼표 분리 패턴 매칭
        if (kw.length === 1) {
          const singleRegex = new RegExp(`(^|[\\s,;()/\\[\\]+])${kw}([\\s,;()/\\[\\]+]|$)`, "i");
          if (singleRegex.test(fullInspectText)) {
            allergenFound = true;
            break;
          }
        } else if (fullInspectText.includes(kw.toLowerCase()) || normalizedFullText.includes(normKw)) {
          allergenFound = true;
          break;
        }
      }

      if (allergenFound) {
        matchedAllergens.push(allergen);
      }
    }

    // 3. 4대 판정 엔진 판정 도출
    let verdict = "SUBSTANCE_SAFE";
    let verdictLabel = "✅ 유해/금지성분 미검출 (정상 판매/통관 적합)";
    let complianceScore = 100;
    let riskLevel = "LOW";
    let penaltySavedWon = 0;
    const violationPoints = [];
    let actionRecommendation = "";
    let allergenNoticeText = "";

    if (matchedCriticalBanned.length > 0) {
      // 1순위: 형사처벌 리스크 즉각 차단
      verdict = "SUBSTANCE_CRITICAL_BANNED";
      verdictLabel = "🛑 식약처 반입금지·위해성분 검출 (형사처벌 위험! 즉시 중단)";
      complianceScore = 10;
      riskLevel = "CRITICAL";
      penaltySavedWon = 5000000;

      for (const b of matchedCriticalBanned) {
        violationPoints.push(`식약처 반입금지/부정물질 검출: [${b.nameKo} / ${b.nameEn}] (${b.category} - ${b.legalRef})`);
      }

      actionRecommendation = `식품위생법 제4조(10년 이하 징역 또는 1억 원 이하 벌금) 및 수입식품안전관리 특별법 제25조에 의거, 해당 상품은 즉각적인 소싱 차단 및 판매 페이지 삭제 조치가 필수적입니다. 적발 시 영업소 폐쇄 및 형사입건 대상이 되므로 상품 등록을 엄격히 금지하십시오. (사전 방어액: ₩5,000,000원)`;
    } else if (matchedQuarantineWarnings.length > 0) {
      // 2순위: 통관 보류 및 검역 손실 방어
      verdict = "SUBSTANCE_QUARANTINE_WARNING";
      verdictLabel = "🚨 통관 보류·검역 정밀대상 주의 (반송 리스크 경고)";
      complianceScore = 50;
      riskLevel = "HIGH";
      penaltySavedWon = 1000000;

      for (const w of matchedQuarantineWarnings) {
        violationPoints.push(`검역정밀·통관보류 주의 원료: [${w.nameKo} / ${w.nameEn}] (${w.category} - ${w.legalRef})`);
      }

      actionRecommendation = `가축전염병예방법 및 식물방역법에 따른 정부 검역증명서 미제출 시 세관 통관 보류 및 전량 폐기/반송 처분 위험이 매우 높습니다. 공급처의 공식 BSE 불검출 인증서 또는 검역승인서를 확보하거나 소싱을 보류하십시오. (사전 방어액: ₩1,000,000원)`;
    } else if (matchedAllergens.length > 0) {
      // 3순위: 알레르기 안내 권고
      verdict = "SUBSTANCE_CAUTION_ALLERGEN";
      verdictLabel = "⚠️ 알레르기 유발물질 포함 (소비자 고지 준수 권고)";
      complianceScore = 85;
      riskLevel = "MEDIUM";
      penaltySavedWon = 0;

      const allergenNames = matchedAllergens.map(a => a.nameKo).join(", ");
      violationPoints.push(`알레르기 유발물질 19종 감지: [${allergenNames}]`);

      allergenNoticeText = `[소비자 안전 안내] 본 제품은 알레르기 유발물질인 [${allergenNames}]을(를) 사용(또는 혼용 제조 시설)하여 생산되었습니다. 해당 성분에 민감한 소비자는 섭취/사용 전 주의하시기 바랍니다.`;
      actionRecommendation = `식품 등의 표시·광고에 관한 법률 제4조에 의거하여, 상세페이지 상단에 알레르기 고지 문구를 명시해야 합니다. 추천 표기 문구: "${allergenNoticeText}"`;
    } else {
      // 정상
      verdict = "SUBSTANCE_SAFE";
      verdictLabel = "✅ 유해/금지성분 미검출 (정상 판매/통관 적합)";
      complianceScore = 100;
      riskLevel = "LOW";
      penaltySavedWon = 0;
      violationPoints.push("식약처 반입차단 110여 종 및 알레르기 유발물질 미검출. 통관 및 판매 적합.");
      actionRecommendation = "식약처·관세청 규제 유해성분이 일체 검출되지 않았으므로 정상 등록 및 판매가 가능합니다.";
    }

    const auditId = "HAZ-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7).toUpperCase();
    const auditTime = new Date().toISOString();

    const auditRecord = {
      auditId,
      auditTime,
      productName,
      category,
      rawIngredients,
      marketplace,
      countryOfOrigin,
      verdict,
      verdictLabel,
      complianceScore,
      riskLevel,
      penaltySavedWon,
      matchedCriticalBanned: matchedCriticalBanned.map(m => ({ id: m.id, nameKo: m.nameKo, nameEn: m.nameEn, category: m.category })),
      matchedQuarantineWarnings: matchedQuarantineWarnings.map(m => ({ id: m.id, nameKo: m.nameKo, nameEn: m.nameEn, category: m.category })),
      matchedAllergens: matchedAllergens.map(m => ({ id: m.id, nameKo: m.nameKo })),
      allergenNoticeText,
      violationPoints,
      actionRecommendation,
      status: (verdict === "SUBSTANCE_CRITICAL_BANNED" || verdict === "SUBSTANCE_QUARANTINE_WARNING") ? "PENDING_ACTION" : "RESOLVED",
      resolution: verdict === "SUBSTANCE_SAFE" ? "AUTO_CLEARED" : (verdict === "SUBSTANCE_CAUTION_ALLERGEN" ? "ALLERGEN_NOTICED" : null),
      resolvedAt: (verdict === "SUBSTANCE_SAFE" || verdict === "SUBSTANCE_CAUTION_ALLERGEN") ? auditTime : null,
      notes: ""
    };

    return auditRecord;
  }

  /**
   * 감사 결과 원장 영속화
   */
  recordAudit(auditRecord) {
    if (!auditRecord || typeof auditRecord !== "object" || !auditRecord.auditId) return false;
    const audits = this._loadAudits();
    // 중복 제거 후 최신 항목 맨 앞 삽입
    const filtered = audits.filter(a => a && a.auditId !== auditRecord.auditId);
    filtered.unshift(auditRecord);
    // 최대 500개 보존
    return this._saveAudits(filtered.slice(0, 500));
  }

  /**
   * Pure White Clean Enterprise 라이트 모드 공식 성분 검토 증적서 및 식약처 소명서 HTML 생성
   * - (인쇄 시 직인 생략) 공문서 표준 준수, 붉은 직인 0건, 다크모드 영구 금지.
   */
  generateSubstanceDisputeEvidenceHtml(auditRecord = {}, customConfig = {}) {
    if (typeof auditRecord === "string" && auditRecord.trim()) {
      const found = this._loadAudits().find(a => a && a.auditId === auditRecord.trim());
      auditRecord = found || { productName: auditRecord.trim() };
    }
    auditRecord = (auditRecord && typeof auditRecord === "object") ? auditRecord : {};
    customConfig = (customConfig && typeof customConfig === "object") ? customConfig : {};
    const config = Object.assign({}, this.getConfig(), customConfig);
    const record = (auditRecord.auditId && Array.isArray(auditRecord.violationPoints))
      ? auditRecord
      : this.auditHazardousSubstances(auditRecord);

    const issueDate = new Date().toISOString().replace("T", " ").substring(0, 19) + " KST";
    const certSerial = "MFDS-SEC-" + crypto.createHash("md5").update((record.auditId || "") + issueDate).digest("hex").toUpperCase().substring(0, 16);

    let badgeBg = "#10b981";
    let badgeText = "#ffffff";
    if (record.verdict === "SUBSTANCE_CAUTION_ALLERGEN") {
      badgeBg = "#f59e0b";
      badgeText = "#ffffff";
    } else if (record.verdict === "SUBSTANCE_QUARANTINE_WARNING") {
      badgeBg = "#ea580c";
      badgeText = "#ffffff";
    } else if (record.verdict === "SUBSTANCE_CRITICAL_BANNED") {
      badgeBg = "#dc2626";
      badgeText = "#ffffff";
    }

    const violationsHtml = (record.violationPoints || []).map(vp => `
      <li style="margin-bottom: 8px; color: #1e293b; font-size: 12px; line-height: 1.5;">
        • ${vp}
      </li>
    `).join("");

    const criticalListText = (record.matchedCriticalBanned && record.matchedCriticalBanned.length > 0)
      ? record.matchedCriticalBanned.filter(m => m && typeof m === "object").map(m => `<span style="color: #b91c1c; font-weight: 700;">${m.nameKo || "-"}(${m.nameEn || "-"})</span>`).join(", ")
      : "해당 없음 (검출 성분 0건)";

    const quarantineListText = (record.matchedQuarantineWarnings && record.matchedQuarantineWarnings.length > 0)
      ? record.matchedQuarantineWarnings.filter(m => m && typeof m === "object").map(m => `<span style="color: #ea580c; font-weight: 700;">${m.nameKo || "-"}(${m.nameEn || "-"})</span>`).join(", ")
      : "해당 없음 (검역 이상 0건)";

    const allergenListText = (record.matchedAllergens && record.matchedAllergens.length > 0)
      ? record.matchedAllergens.filter(m => m && typeof m === "object").map(m => `<span style="color: #0284c7; font-weight: 700;">${m.nameKo || "-"}</span>`).join(", ")
      : "알레르기 유발물질 없음";

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>식품위생법 및 수입식품안전관리 특별법 성분 검토 증적서 (${certSerial})</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Pretendard", "Segoe UI", Roboto, sans-serif;
      background: #f8fafc;
      color: #0f172a;
      margin: 0;
      padding: 40px 20px;
    }
    .doc-container {
      max-width: 900px;
      margin: 0 auto;
      background: #ffffff;
      border: 2px solid #0f172a;
      border-radius: 8px;
      padding: 44px 50px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }
    .doc-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 2px solid #0f172a;
      padding-bottom: 20px;
      margin-bottom: 28px;
    }
    .doc-title-group h1 {
      margin: 0;
      font-size: 22px;
      font-weight: 900;
      color: #0f172a;
      letter-spacing: -0.5px;
    }
    .doc-title-group p {
      margin: 6px 0 0 0;
      font-size: 12px;
      color: #64748b;
    }
    .print-btn {
      padding: 8px 16px;
      background: #0f172a;
      color: #ffffff;
      border: none;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
    }
    .meta-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px 24px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 18px 22px;
      margin-bottom: 26px;
    }
    .meta-item {
      display: flex;
      font-size: 13px;
    }
    .meta-item .label {
      width: 150px;
      color: #64748b;
      font-weight: 600;
    }
    .meta-item .value {
      flex: 1;
      color: #0f172a;
      font-weight: 700;
    }
    .legal-box {
      background: #eff6ff;
      border-left: 4px solid #2563eb;
      padding: 14px 18px;
      border-radius: 4px;
      font-size: 12px;
      color: #1e40af;
      line-height: 1.6;
      margin-bottom: 26px;
    }
    .verdict-banner {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      padding: 16px 20px;
      margin-bottom: 26px;
    }
    .verdict-pill {
      display: inline-block;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 800;
      background: ${badgeBg};
      color: ${badgeText};
    }
    .detail-section {
      margin-bottom: 26px;
    }
    .detail-section h2 {
      font-size: 14px;
      font-weight: 800;
      color: #0f172a;
      margin: 0 0 12px 0;
      padding-bottom: 8px;
      border-bottom: 1px solid #e2e8f0;
    }
    .violation-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    .statement-box {
      background: #fffbeb;
      border-left: 4px solid #f59e0b;
      padding: 14px 18px;
      border-radius: 4px;
      font-size: 12px;
      color: #92400e;
      line-height: 1.6;
      margin-bottom: 28px;
    }
    .doc-footer {
      border-top: 1px solid #e2e8f0;
      padding-top: 24px;
      margin-top: 24px;
    }
    .signature-area {
      text-align: right;
      font-size: 13px;
      font-weight: 700;
      color: #0f172a;
      line-height: 1.8;
      margin-bottom: 16px;
    }
    .system-badge {
      font-size: 11px;
      color: #64748b;
      display: flex;
      justify-content: space-between;
    }
    @media print {
      body {
        padding: 0;
        background: #ffffff;
      }
      .doc-container {
        border: none;
        box-shadow: none;
        padding: 0;
        max-width: 100%;
      }
      .print-btn {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="doc-container">
    <div class="doc-header">
      <div class="doc-title-group">
        <h1>📋 식약처·환경부 법정 유해성분 검토 증적서 및 소명서</h1>
        <p>Official Statutory Evidence of Hazardous Substance Screening & Food Sanitation Compliance</p>
      </div>
      <div class="doc-actions">
        <button type="button" class="print-btn" onclick="window.print()">🖨️ 증적 인쇄 / PDF 저장</button>
      </div>
    </div>

    <div class="meta-grid">
      <div class="meta-item"><span class="label">소명서 일련번호:</span><span class="value" style="font-family: monospace;">${certSerial}</span></div>
      <div class="meta-item"><span class="label">감사 발급 일시:</span><span class="value">${issueDate}</span></div>
      <div class="meta-item"><span class="label">대상 상품명:</span><span class="value">${record.productName || '미기재'}</span></div>
      <div class="meta-item"><span class="label">상품 품목 분류:</span><span class="value">${record.category || '건강기능식품'}</span></div>
      <div class="meta-item"><span class="label">원산지/수입경로:</span><span class="value">${record.countryOfOrigin || '해외직구'}</span></div>
      <div class="meta-item"><span class="label">판매 플랫폼:</span><span class="value">${record.marketplace || '쿠팡 (Coupang Wing)'}</span></div>
      <div class="meta-item"><span class="label">금지 성분 검출:</span><span class="value">${criticalListText}</span></div>
      <div class="meta-item"><span class="label">검역 주의 원료:</span><span class="value">${quarantineListText}</span></div>
      <div class="meta-item" style="grid-column: 1 / -1;"><span class="label">알레르기 19종 감지:</span><span class="value">${allergenListText}</span></div>
    </div>

    <div class="legal-box">
      <strong>⚖️ 관련 법률 및 행정처분 기준:</strong><br>
      1. <strong>「식품위생법」 제4조(위해식품등의 판매 등 금지):</strong> 유독·유해물질이 들어 있거나 묻어 있는 것 또는 그러할 염려가 있는 것은 판매하거나 판매할 목적으로 채취·제조·수입·가공·사용·조리·저장·소분·운반 또는 진열하지 못하며, 위반 시 10년 이하의 징역 또는 1억 원 이하의 벌금에 처해집니다.<br>
      2. <strong>「수입식품안전관리 특별법」 제25조(수입신고 및 통관보류):</strong> 국민 건강에 위해가 발생할 우려가 있는 물질이 함유된 수입식품등에 대하여 식약처장은 관세청장에게 통관보류를 요청할 수 있으며 즉각 폐기 처분됩니다.<br>
      3. <strong>「식품 등의 표시·광고에 관한 법률」 제4조:</strong> 알레르기 유발물질 19종을 원재료로 사용하는 경우 소비자가 쉽게 알아볼 수 있도록 명확히 표시하여야 합니다.
    </div>

    <div class="verdict-banner">
      <div>
        <div style="font-size: 11px; font-weight: 700; color: #64748b; margin-bottom: 4px;">성분 안전성 종합 판정</div>
        <div style="font-size: 18px; font-weight: 800; color: #0f172a;">
          안전성 점수: <span style="color: ${record.complianceScore >= 80 ? '#059669' : '#b91c1c'};">${record.complianceScore}점 / 100점</span>
        </div>
      </div>
      <div style="text-align: right;">
        <span class="verdict-pill">${record.verdictLabel}</span>
        <div style="margin-top: 6px; font-size: 11px; font-weight: 700; color: ${record.penaltySavedWon > 0 ? '#b91c1c' : '#059669'};">
          ${record.penaltySavedWon > 0 ? `🛡️ 형사벌금/과징금/검역손실 사전 방어액: ₩${Number(record.penaltySavedWon).toLocaleString()}원` : '✅ 법적 규제 위해위험 0원 (안전 통관)'}
        </div>
      </div>
    </div>

    <div class="detail-section">
      <h2>📋 세부 성분 검토 및 감별 사항</h2>
      <ul class="violation-list">
        ${violationsHtml}
      </ul>
    </div>

    <div class="statement-box">
      <strong>📝 식품안전 컴플라이언스 의견 및 조치 가이드:</strong><br>
      ${record.actionRecommendation}
    </div>

    <div class="doc-footer">
      <div class="signature-area">
        ${issueDate.substring(0, 10)}<br><br>
        책임판매사업자: ${config.storeName} (${config.sellerName}) (인쇄 시 직인 생략)
      </div>
      <div class="system-badge">
        <span>발급 엔진: AutoFlow Enterprise Hazardous Substance Sentinel v2.0 (인쇄 시 직인 생략)</span>
        <span>식품안전/컴플라이언스 지원: ${config.sellerPhone} | ${config.sellerEmail}</span>
      </div>
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * 누적 통계 집계
   */
  getSummary() {
    const audits = this._loadAudits();
    let totalAudits = audits.length;
    let safeCount = 0;
    let allergenCautionCount = 0;
    let quarantineWarningCount = 0;
    let criticalBannedCount = 0;
    let totalPreventedFinesWon = 0;
    let resolvedCount = 0;
    let pendingIssuesCount = 0;

    for (const a of audits) {
      if (!a || typeof a !== "object") continue;
      if (a.verdict === "SUBSTANCE_SAFE") safeCount++;
      else if (a.verdict === "SUBSTANCE_CAUTION_ALLERGEN") allergenCautionCount++;
      else if (a.verdict === "SUBSTANCE_QUARANTINE_WARNING") quarantineWarningCount++;
      else if (a.verdict === "SUBSTANCE_CRITICAL_BANNED") criticalBannedCount++;

      totalPreventedFinesWon += Number(a.penaltySavedWon || 0);

      if (a.status === "RESOLVED") {
        resolvedCount++;
      } else if (a.status === "PENDING_ACTION") {
        pendingIssuesCount++;
      }
    }

    return {
      totalAudits,
      safeCount,
      allergenCautionCount,
      quarantineWarningCount,
      criticalBannedCount,
      totalPreventedFinesWon,
      resolvedCount,
      pendingIssuesCount,
      totalMonitoredSubstances: this.database.length,
      latestAudits: audits.slice(0, 50)
    };
  }

  /**
   * 유해성분 이슈 종결 처리
   */
  resolveSubstanceIssue(auditId, resolution = "SOURCING_BLOCKED", notes = "") {
    if (auditId && typeof auditId === "object") {
      resolution = auditId.resolution || resolution;
      notes = auditId.notes || auditId.note || notes;
      auditId = auditId.auditId || "";
    }
    resolution = resolution || "SOURCING_BLOCKED";
    const audits = this._loadAudits();
    const target = audits.find(a => a && a.auditId === auditId);
    if (!target) {
      return { success: false, message: `감사 ID [${auditId || "N/A"}]를 찾을 수 없습니다.` };
    }

    target.status = "RESOLVED";
    target.resolution = resolution;
    target.resolvedAt = new Date().toISOString();
    target.notes = String(notes || "판매자가 소싱을 중단하거나 상세페이지 알레르기 안내를 등록 완료함.");

    this._saveAudits(audits);
    return { success: true, audit: target };
  }

  /**
   * 특정 감사에 대한 HTML 보고서 발급
   */
  generateDisputeResponseDoc(auditId, customConfig = {}) {
    customConfig = (customConfig && typeof customConfig === "object") ? customConfig : {};
    const audits = this._loadAudits();
    let target = null;
    if (auditId && typeof auditId === "object") {
      if (auditId.auditId) {
        target = audits.find(a => a && a.auditId === auditId.auditId) || auditId;
      } else {
        target = auditId;
      }
    } else if (typeof auditId === "string" && auditId.trim()) {
      target = audits.find(a => a && a.auditId === auditId.trim());
    }
    if (!target) {
      target = this.auditHazardousSubstances({});
      if (typeof auditId === "string" && auditId.trim()) {
        target.auditId = auditId.trim();
      }
    }
    return this.generateSubstanceDisputeEvidenceHtml(target, customConfig);
  }
}

function createHazardousSubstanceSentinel(options = {}) {
  return new HazardousSubstanceSentinel((options && typeof options === "object") ? options : {});
}

const defaultHazardousSubstanceSentinel = new HazardousSubstanceSentinel();

module.exports = {
  HAZARDOUS_SUBSTANCE_DATABASE,
  ALLERGEN_19_DATABASE,
  HazardousSubstanceSentinel,
  createHazardousSubstanceSentinel,
  hazardousSubstanceSentinel: defaultHazardousSubstanceSentinel
};
