#!/usr/bin/env node
/**
 * AutoFlow Pure Node.js V8 Non-Language Defender CLI
 * ==================================================
 * 100% 순수 Node.js 네이티브 비언어 자가치유봇 진입점.
 * Python 완전 배제: 외부 종속성 없이 순수 JS로 동작.
 * 
 * 사용법:
 *   /opt/homebrew/bin/node core/v8_non_lang_defender.js --attacks /tmp/findings.json
 *   /opt/homebrew/bin/node core/v8_non_lang_defender.js --learn /tmp/patches.json
 *   /opt/homebrew/bin/node core/v8_non_lang_defender.js --reverify --attacks /tmp/findings.json
 *   /opt/homebrew/bin/node core/v8_non_lang_defender.js --stats
 */

const fs = require('fs');
const path = require('path');

const REPO_ROOT = '/Volumes/Mac_SSD/Projects/AutoFlowEngine';
const ONLINE_LOG = path.join(REPO_ROOT, 'core/non_lang_v4_online_learning.jsonl');
const GT_PATCHES = path.join(REPO_ROOT, 'core/chaos_ground_truth_patches.json');
const SEED_PATCHES = path.join(REPO_ROOT, 'core/v8_corpus_seed_r1_r33.json');

let nonLangCorpus = [];

function initCorpus() {
    nonLangCorpus = [];
    // 1. Ground truth
    if (fs.existsSync(GT_PATCHES)) {
        try {
            const arr = JSON.parse(fs.readFileSync(GT_PATCHES, 'utf8'));
            arr.forEach(item => nonLangCorpus.push({ ...item, source: 'GROUND_TRUTH', priority: 100 }));
        } catch (e) {}
    }
    // 2. V8 Seed
    if (fs.existsSync(SEED_PATCHES)) {
        try {
            const arr = JSON.parse(fs.readFileSync(SEED_PATCHES, 'utf8'));
            arr.forEach(item => nonLangCorpus.push({ ...item, source: 'V8_SEED', priority: 50 }));
        } catch (e) {}
    }
    // 3. Online learning entries
    if (fs.existsSync(ONLINE_LOG)) {
        try {
            const lines = fs.readFileSync(ONLINE_LOG, 'utf8').trim().split('\n');
            lines.forEach(line => {
                if (!line.trim()) return;
                try {
                    const parsed = JSON.parse(line);
                    nonLangCorpus.push({ ...parsed, source: 'ONLINE_LOG', priority: 70 });
                } catch (err) {}
            });
        } catch (e) {}
    }
}

const CATEGORY_RULES = [
    [['429', 'rate limit', 'too many'], 'RATE_LIMIT'],
    [['eaddrinuse', '5678', 'port'], 'PORT_CONFLICT'],
    [['undefined', 'null', 'cannot read', 'is not defined'], 'UNDEFINED_GUARD'],
    [['json', 'syntaxerror', 'unexpected token'], 'JSON_SYNTAX'],
    [['oom', 'memory', 'heap', 'enomem'], 'OOM_GUARD'],
    [['bigint', 'circular', 'circular structure'], 'V8_RUNTIME'],
    [['결제', 'payment', 'amount', 'price', 'exponential', 'negative', '-1e', 'fraud', '사기 결제'], 'PAYMENT'],
    [['phone', '전화', '010', 'buyer_phone', '+82'], 'PHONE_FORMAT'],
    [['null byte', '\\x00', '\\u0000', 'zero-width', '\\u200b', '\\u200c', '\\ufeff', 'sanitization'], 'SANITIZATION'],
    [['replay', 'idempotency', 'duplicate', 'storm', 'xss', 'injection'], 'SECURITY'],
    [['식약처', '보건소', '구청', '위생과', '영업정지', '경찰', '장염', '노로바이러스', '배째라'], 'CRISIS_KEYWORDS'],
];

function classifyCategory(errorMsg, codeCtx) {
    const text = (String(errorMsg || '') + ' ' + String(codeCtx || '')).toLowerCase();
    for (const [keywords, cat] of CATEGORY_RULES) {
        if (keywords.some(k => text.includes(k))) return cat;
    }
    return 'GENERAL';
}

function tokenize(str) {
    if (!str) return new Set();
    const tokens = String(str)
        .toLowerCase()
        .replace(/[^\w\uAC00-\uD7A3\x00-\x1F-]/g, ' ')
        .split(/\s+/)
        .filter(t => t.length > 1);
    return new Set(tokens);
}

function jaccardSimilarity(setA, setB) {
    if (setA.size === 0 || setB.size === 0) return 0;
    let intersection = 0;
    for (const item of setA) {
        if (setB.has(item)) intersection++;
    }
    const union = setA.size + setB.size - intersection;
    return union === 0 ? 0 : intersection / union;
}

function defendSingle(errorMsg, codeCtx, threshold = 0.45) {
    if (errorMsg && typeof errorMsg === 'object') {
        codeCtx = (typeof codeCtx === 'string' && codeCtx) ? codeCtx : (errorMsg.code_context || errorMsg.codeCtx || '');
        errorMsg = errorMsg.error_message || errorMsg.errorMsg || '';
    }
    const safeErr = typeof errorMsg === 'string' ? errorMsg : '';
    const safeCtx = typeof codeCtx === 'string' ? codeCtx : '';
    const safeThreshold = (typeof threshold === 'number' && Number.isFinite(threshold)) ? threshold : 0.45;

    const targetCategory = classifyCategory(safeErr, safeCtx);
    const queryTokens = tokenize(safeErr + ' ' + safeCtx);

    let bestMatch = null;
    let bestScore = -1;

    for (const item of nonLangCorpus) {
        if (!item._tokens) {
            item._tokens = tokenize((item.error_message || item.error_sig || '') + ' ' + (item.code_context || ''));
        }
        let score = jaccardSimilarity(queryTokens, item._tokens);

        if (item.category === targetCategory) score += 0.45;
        if (item.priority) score += (item.priority / 1000);

        if (score > bestScore) {
            bestScore = score;
            bestMatch = item;
        }
    }

    const confidence = Math.min(100, Math.round(bestScore * 100));

    if (bestScore >= safeThreshold && bestMatch) {
        return {
            status: 'DEFENDED',
            confidence: confidence,
            patch: (bestMatch.patch_code || bestMatch.patch || '').substring(0, 300),
            category: targetCategory,
            matched_error: (bestMatch.error_message || bestMatch.error_sig || '').substring(0, 150)
        };
    }

    return {
        status: 'ESCALATE',
        confidence: confidence,
        category: targetCategory,
        reason: `신뢰도 ${confidence}% < 임계값 ${Math.round(safeThreshold * 100)}%. 블루팀 에스컬레이션 필요.`
    };
}

function defendWithCegarLoop(errorMsg, codeCtx) {
    if (errorMsg && typeof errorMsg === 'object') {
        codeCtx = (typeof codeCtx === 'string' && codeCtx) ? codeCtx : (errorMsg.code_context || errorMsg.codeCtx || '');
        errorMsg = errorMsg.error_message || errorMsg.errorMsg || '';
    }
    const safeErr = typeof errorMsg === 'string' ? errorMsg : '';
    const safeCtx = typeof codeCtx === 'string' ? codeCtx : '';

    const thresholds = [0.60, 0.50, 0.45, 0.40, 0.35];
    const history = [];

    for (let round = 1; round <= thresholds.length; round++) {
        const th = thresholds[round - 1];
        const res = defendSingle(safeErr, safeCtx, th);
        res.round = round;
        history.push(res);

        if (res.status === 'DEFENDED') {
            return {
                status: 'DEFENDED_BY_CEGAR',
                final_round: round,
                resolution: res,
                cegar_history: history
            };
        }
    }

    return {
        status: 'ESCALATE_TO_BLUE_TEAM',
        reason: 'CEGAR 5 라운드 전부 실패. 블루팀 패치 필요.',
        cegar_payload: {
            error_message: safeErr,
            code_context: safeCtx,
            category: classifyCategory(safeErr, safeCtx),
            cegar_history: history
        }
    };
}

function defendAttacks(attacks = []) {
    const attackList = Array.isArray(attacks)
        ? attacks
        : (attacks && typeof attacks === 'object' && Array.isArray(attacks.attacks) ? attacks.attacks : []);
    const defended = [];
    const escalated = [];

    attackList.forEach((rawAtk, idx) => {
        const atk = (rawAtk && typeof rawAtk === 'object') ? rawAtk : {};
        const errorMsg = atk.error_message || atk.vulnerability || atk.evidence || '';
        const codeCtx = atk.code_context || atk.payload || atk.location || '';
        const attackId = atk.id || `ATK_${Date.now()}_${idx}`;

        const t0 = Date.now();
        const res = defendWithCegarLoop(errorMsg, codeCtx);
        const latencyMs = Date.now() - t0;

        if (res.status === 'DEFENDED_BY_CEGAR') {
            defended.push({
                id: attackId,
                status: 'DEFENDED',
                confidence: res.resolution.confidence,
                round: res.final_round,
                patch: res.resolution.patch,
                category: res.resolution.category,
                latency_ms: latencyMs
            });
        } else {
            escalated.push({
                id: attackId,
                status: 'ESCALATE',
                error_message: errorMsg,
                code_context: codeCtx,
                category: res.cegar_payload.category,
                reason: res.reason
            });
        }
    });

    const total = attackList.length;
    const defenseRate = total > 0 ? ((defended.length / total) * 100).toFixed(1) + '%' : '0.0%';

    return {
        summary: {
            total,
            defended: defended.length,
            escalated: escalated.length,
            defense_rate: defenseRate
        },
        defended,
        escalated
    };
}

function learnPatches(patches = []) {
    const patchList = Array.isArray(patches)
        ? patches
        : (patches && typeof patches === 'object' && Array.isArray(patches.patches) ? patches.patches : []);
    let learnedCount = 0;
    patchList.forEach(rawPatch => {
        const p = (rawPatch && typeof rawPatch === 'object') ? rawPatch : {};
        const patchObj = {
            id: `ONLINE_${Date.now()}_${Math.random().toString(36).substring(7)}`,
            instruction: 'Fix vulnerability found by autonomous penetration',
            error_sig: p.error_message || '',
            error_message: p.error_message || '',
            code_context: p.code_context || '',
            patch_code: p.patch_code || '',
            category: p.category || classifyCategory(p.error_message, p.code_context),
            source: 'ONLINE_LEARNING',
            priority: 90,
            learned_at: Date.now()
        };
        nonLangCorpus.push(patchObj);
        fs.appendFileSync(ONLINE_LOG, JSON.stringify(patchObj) + '\n', 'utf8');
        learnedCount++;
    });

    return {
        learned_count: learnedCount,
        corpus_total: nonLangCorpus.length
    };
}

function main() {
    initCorpus();
    const args = process.argv.slice(2);

    if (args.includes('--stats')) {
        console.log(JSON.stringify({
            engine: 'AutoFlow Pure Node.js V8 Non-Language Defender v4.0',
            corpus_total: nonLangCorpus.length,
            runtime: 'Node.js ' + process.version,
            python_used: false
        }, null, 2));
        return;
    }

    const learnIdx = args.indexOf('--learn');
    if (learnIdx !== -1 && args[learnIdx + 1]) {
        const patchFile = args[learnIdx + 1];
        if (fs.existsSync(patchFile)) {
            const raw = JSON.parse(fs.readFileSync(patchFile, 'utf8'));
            const patches = Array.isArray(raw) ? raw : [raw];
            const res = learnPatches(patches);
            console.log('[LEARN_RESULT]');
            console.log(JSON.stringify(res, null, 2));
            console.log('[LEARN_RESULT_END]');
        }
    }

    const attacksIdx = args.indexOf('--attacks');
    if (attacksIdx !== -1 && args[attacksIdx + 1]) {
        const attackFile = args[attacksIdx + 1];
        if (fs.existsSync(attackFile)) {
            const raw = JSON.parse(fs.readFileSync(attackFile, 'utf8'));
            const attacks = Array.isArray(raw) ? raw : [raw];
            if (args.includes('--reverify')) {
                console.log('[REVERIFY_MODE] 학습 후 재방어 시도');
            }
            const res = defendAttacks(attacks);
            console.log('[DEFENSE_RESULT]');
            console.log(JSON.stringify(res, null, 2));
            console.log('[DEFENSE_RESULT_END]');
        }
    }
}

if (require.main === module) {
    main();
}

module.exports = { defendAttacks, learnPatches, initCorpus };
