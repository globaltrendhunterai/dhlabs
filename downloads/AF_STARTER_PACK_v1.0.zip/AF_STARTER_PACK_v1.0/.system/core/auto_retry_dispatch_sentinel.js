/**
 * AutoFlow WING Auto-Retry Dispatch Sentinel (core/auto_retry_dispatch_sentinel.js)
 * 
 * [목적 및 법무/비즈니스 배경]
 * 1. 쿠팡 마켓플레이스 판매자 이용약관 제19조(상품의 배송) 및 전자상거래법 제15조(재화등의 공급 등) 준수.
 * 2. 쿠팡 WING Open API 서버의 일시적 500/502/503/504 장애, 초당 레이트리밋(429), 네트워크 타임아웃으로 인한
 *    "침묵의 송장 등록 실패(Silent Dispatch Failure)"를 1초 만에 원천 차단.
 * 3. 출고 마감 시한(D-Day 16:00)을 넘겨 정시출고율이 폭락하고 아이템위너 박탈 및 계정 정지(Suspension)를 당하는 비가역적 참사 방어.
 * 4. 3단계 지수 백오프 (1차 30초, 2차 120초, 3차 300초) 자동 재시도 큐 및 영속화(`logs/dispatch_retry_queue.json`).
 * 5. 3회 최종 실패 시 텔레그램/슬랙 긴급 경보 및 쿠팡 WING 출고 대기 페이지 1초 직통 딥링크 제공.
 */

const fs = require("fs");
const path = require("path");

class AutoRetryDispatchSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/dispatch_retry_queue.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/dispatch_retry_config.json");
    this.maxRetries = options.maxRetries || 3;
    // 백오프 간격 (초 단위): 1차 30초, 2차 120초(2분), 3차 300초(5분)
    this.backoffIntervals = Array.isArray(options.backoffIntervals) && options.backoffIntervals.length > 0
      ? options.backoffIntervals
      : [30, 120, 300];
    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(
          this.storagePath,
          JSON.stringify({ queue: [], history: [], lastAuditTime: Date.now() }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}

    try {
      const cfgDir = path.dirname(this.configPath);
      if (!fs.existsSync(cfgDir)) {
        fs.mkdirSync(cfgDir, { recursive: true });
      }
      if (!fs.existsSync(this.configPath)) {
        fs.writeFileSync(
          this.configPath,
          JSON.stringify({
            enabled: true,
            maxRetries: 3,
            autoRetryActive: true,
            alertOnDeadLetter: true,
            wingDirectLink: "https://wing.coupang.com/tenants/seller-web/vendor/order/list/delivery-ready"
          }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const parsed = JSON.parse(fs.readFileSync(this.configPath, "utf8"));
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (_) {}
    return {
      enabled: true,
      maxRetries: 3,
      autoRetryActive: true,
      alertOnDeadLetter: true,
      wingDirectLink: "https://wing.coupang.com/tenants/seller-web/vendor/order/list/delivery-ready"
    };
  }

  updateConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object") ? newConfig : {};
    const current = this.getConfig();
    const updated = { ...current, ...newConfig };
    try {
      fs.writeFileSync(this.configPath, JSON.stringify(updated, null, 2), "utf8");
    } catch (_) {}
    return updated;
  }

  /**
   * 송장 등록 실패 시 즉시 호출하여 재시도 큐에 적재하거나 재시도 대상인지 판별
   * @param {Object} order - { orderId, vendorId, deliveryCompanyCode, invoiceNumber, receiverName }
   * @param {Object} error - { statusCode, errorMessage, rawResponse }
   * @returns {Object} 큐 적재 결과
   */
  enqueueFailedDispatch(order = {}, error = {}) {
    order = (order && typeof order === "object") ? order : {};
    error = (error && typeof error === "object") ? error : {};
    const orderId = String(order.orderId || "").trim();
    if (!orderId) {
      return { success: false, message: "orderId is required" };
    }

    const statusCode = Number(error.statusCode) || 500;
    const errorMessage = String(error.errorMessage || "Unknown dispatch error");
    const rawResponse = String(error.rawResponse || "");

    // Edge Case 1: 이미 배송 완료된 경우 -> 실패 큐 적재 대신 즉시 성공 간주
    if (
      errorMessage.includes("ALREADY_IN_DELIVERY") ||
      errorMessage.includes("ALREADY_SHIPPED") ||
      errorMessage.includes("이미 배송") ||
      rawResponse.includes("ALREADY_")
    ) {
      return {
        success: true,
        orderId,
        status: "RESOLVED_EXTERNAL",
        message: "이미 쿠팡에 배송 처리된 주문입니다. (외부 해결 감지)"
      };
    }

    // Edge Case 2: 주문 취소/반품된 경우 -> 재시도 중단
    if (
      errorMessage.includes("ORDER_CANCELLED") ||
      errorMessage.includes("취소된 주문") ||
      errorMessage.includes("CANCEL_REQUEST")
    ) {
      return {
        success: true,
        orderId,
        status: "ABORTED_BY_CANCEL",
        message: "주문이 취소되어 송장 등록이 영구 중단되었습니다."
      };
    }

    // Edge Case 3: 송장번호 자체의 유효성 오류(400 Bad Request) -> 재시도 없이 즉시 Dead Letter
    const isBadTracking = statusCode === 400 || errorMessage.includes("INVALID_INVOICE") || errorMessage.includes("송장번호 오류");

    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : {};
      data.queue = Array.isArray(data.queue) ? data.queue.filter(x => x && typeof x === "object") : [];
      data.history = Array.isArray(data.history) ? data.history.filter(x => x && typeof x === "object") : [];

      const existingIndex = data.queue.findIndex(item => item.orderId === orderId);
      const now = Date.now();

      if (existingIndex >= 0) {
        // 기존 큐 항목 업데이트
        const currentItem = data.queue[existingIndex];
        currentItem.attempts = (currentItem.attempts || 0) + 1;
        currentItem.lastError = errorMessage;
        currentItem.lastStatusCode = statusCode;
        currentItem.lastAttemptAt = new Date(now).toISOString();

        if (isBadTracking || currentItem.attempts >= this.maxRetries) {
          currentItem.status = "DEAD_LETTER";
          currentItem.nextRetryAt = null;
          currentItem.isDeadLetter = true;
        } else {
          const delaySec = this.backoffIntervals[Math.min(currentItem.attempts - 1, this.backoffIntervals.length - 1)];
          currentItem.status = "RETRY_PENDING";
          currentItem.nextRetryAt = new Date(now + delaySec * 1000).toISOString();
        }

        fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
        return {
          success: true,
          orderId,
          status: currentItem.status,
          attempts: currentItem.attempts,
          nextRetryAt: currentItem.nextRetryAt,
          isDeadLetter: !!currentItem.isDeadLetter
        };
      }

      // 신규 큐 등록
      const attempts = 1;
      let nextRetryAt = null;
      let status = "RETRY_PENDING";
      let isDeadLetter = false;

      if (isBadTracking) {
        status = "DEAD_LETTER";
        isDeadLetter = true;
      } else {
        const delaySec = this.backoffIntervals[0];
        nextRetryAt = new Date(now + delaySec * 1000).toISOString();
      }

      const queueItem = {
        orderId,
        vendorId: order.vendorId || "",
        deliveryCompanyCode: order.deliveryCompanyCode || "",
        invoiceNumber: order.invoiceNumber || "",
        receiverName: order.receiverName || "고객",
        initialError: errorMessage,
        lastError: errorMessage,
        lastStatusCode: statusCode,
        attempts,
        maxRetries: this.maxRetries,
        enqueuedAt: new Date(now).toISOString(),
        lastAttemptAt: new Date(now).toISOString(),
        nextRetryAt,
        status,
        isDeadLetter
      };

      data.queue.unshift(queueItem);
      // 최대 200건 보존
      if (data.queue.length > 200) data.queue = data.queue.slice(0, 200);

      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");

      return {
        success: true,
        orderId,
        status,
        attempts,
        nextRetryAt,
        isDeadLetter
      };
    } catch (e) {
      return { success: false, message: e.message };
    }
  }

  /**
   * 재시도가 필요한 주문 목록 반환 (현재 시각 기준으로 nextRetryAt 도달 건)
   */
  getDueRetries() {
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : {};
      if (!Array.isArray(data.queue)) return [];

      const now = Date.now();
      return data.queue.filter(item => {
        if (!item || typeof item !== "object") return false;
        if (item.status !== "RETRY_PENDING") return false;
        if (!item.nextRetryAt) return false;
        return new Date(item.nextRetryAt).getTime() <= now;
      });
    } catch (_) {
      return [];
    }
  }

  /**
   * 수동 또는 스케줄러에 의한 즉시 1초 재전송 결과 반영
   * @param {string} orderId 
   * @param {boolean} isSuccess 
   * @param {Object} outcomeDetails 
   */
  recordRetryOutcome(orderId, isSuccess, outcomeDetails = {}) {
    outcomeDetails = (outcomeDetails && typeof outcomeDetails === "object") ? outcomeDetails : {};
    if (orderId && typeof orderId === "object") {
      orderId = orderId.orderId || "";
    }
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : {};
      data.queue = Array.isArray(data.queue) ? data.queue.filter(x => x && typeof x === "object") : [];
      data.history = Array.isArray(data.history) ? data.history.filter(x => x && typeof x === "object") : [];
      if (data.queue.length === 0) return { success: false, message: "Queue is empty" };

      const index = data.queue.findIndex(i => i.orderId === String(orderId ?? ""));
      if (index === -1) return { success: false, message: "Order not found in queue" };

      const item = data.queue[index];
      const now = Date.now();

      if (isSuccess) {
        item.status = "SUCCESS_RESOLVED";
        item.resolvedAt = new Date(now).toISOString();
        item.isDeadLetter = false;
        item.nextRetryAt = null;

        // history로 이동
        data.queue.splice(index, 1);
        data.history.unshift(item);
        if (data.history.length > 200) data.history = data.history.slice(0, 200);

        fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
        return { success: true, orderId, status: "SUCCESS_RESOLVED", message: "송장 등록 재시도 성공 완결" };
      }

      // 실패한 경우 카운트 증가
      item.attempts = (item.attempts || 0) + 1;
      item.lastError = outcomeDetails.errorMessage || item.lastError;
      item.lastStatusCode = outcomeDetails.statusCode || item.lastStatusCode;
      item.lastAttemptAt = new Date(now).toISOString();

      if (item.attempts >= this.maxRetries) {
        item.status = "DEAD_LETTER";
        item.isDeadLetter = true;
        item.nextRetryAt = null;
      } else {
        const delaySec = this.backoffIntervals[Math.min(item.attempts - 1, this.backoffIntervals.length - 1)];
        item.status = "RETRY_PENDING";
        item.nextRetryAt = new Date(now + delaySec * 1000).toISOString();
      }

      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return {
        success: true,
        orderId,
        status: item.status,
        attempts: item.attempts,
        nextRetryAt: item.nextRetryAt,
        isDeadLetter: !!item.isDeadLetter
      };
    } catch (e) {
      return { success: false, message: e.message };
    }
  }

  /**
   * 셀러 수동 해결 처리 (웹에서 직접 처리했거나 송장 수정 완료 시)
   */
  resolveDispatchRetryOrder(orderId, resolutionNote = "수동 확인 완결") {
    if (orderId && typeof orderId === "object") {
      resolutionNote = orderId.resolutionNote || resolutionNote;
      orderId = orderId.orderId || "";
    }
    resolutionNote = resolutionNote ? String(resolutionNote) : "수동 확인 완결";
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : {};
      data.queue = Array.isArray(data.queue) ? data.queue.filter(x => x && typeof x === "object") : [];
      data.history = Array.isArray(data.history) ? data.history.filter(x => x && typeof x === "object") : [];
      if (data.queue.length === 0) return { success: false, message: "Queue is empty" };

      const index = data.queue.findIndex(i => i.orderId === String(orderId ?? ""));
      if (index === -1) return { success: false, message: "Order not found in queue" };

      const item = data.queue.splice(index, 1)[0];
      item.status = "MANUALLY_RESOLVED";
      item.resolvedAt = new Date().toISOString();
      item.resolutionNote = resolutionNote;

      data.history.unshift(item);
      if (data.history.length > 200) data.history = data.history.slice(0, 200);

      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { success: true, orderId, status: "MANUALLY_RESOLVED" };
    } catch (e) {
      return { success: false, message: e.message };
    }
  }

  /**
   * 텔레그램 / 슬랙 경보 블록 포맷팅
   */
  formatDispatchRetryAlert(item = {}) {
    item = (item && typeof item === "object") ? item : {};
    const orderId = item.orderId || "N/A";
    const attempts = item.attempts || 1;
    const maxRetries = item.maxRetries || this.maxRetries;
    const isDeadLetter = item.isDeadLetter || attempts >= maxRetries;
    const invoiceNumber = item.invoiceNumber || "미기재";
    const courier = item.deliveryCompanyCode || "택배사";
    const error = item.lastError || "API 오류";
    const wingUrl = "https://wing.coupang.com/tenants/seller-web/vendor/order/list/delivery-ready";

    if (isDeadLetter) {
      return [
        "🚨 [쿠팡 송장 등록 최종 실패 — 1초 수동 조치 요망]",
        "───────────────────────────────────",
        `• 주문번호: ${orderId}`,
        `• 송장정보: [${courier}] ${invoiceNumber}`,
        `• 수령인: ${item.receiverName || "고객"}`,
        `• 실패원인: ${error}`,
        `• 시도횟수: ${attempts}/${maxRetries}회 (자동 재시도 소진)`,
        "⚠️ 마감 시한(16:00) 전 쿠팡 WING 관리자에서 즉시 수동 발송 등록하십시오!",
        `🔗 WING 직통링크: ${wingUrl}`,
        "───────────────────────────────────",
        "※ AutoFlow 정시출고율 수호 센티널 가동 중"
      ].join("\n");
    }

    return [
      "⚠️ [쿠팡 송장 등록 일시 지연 — 자동 재시도 대기]",
      "───────────────────────────────────",
      `• 주문번호: ${orderId}`,
      `• 송장정보: [${courier}] ${invoiceNumber}`,
      `• 오류사유: ${error}`,
      `• 현재시도: ${attempts}/${maxRetries}회`,
      `• 다음재시도: ${item.nextRetryAt || "곧 재시도"}`,
      "───────────────────────────────────",
      "※ 지수 백오프 기반 무인 자동 재전송 큐 가동 중"
    ].join("\n");
  }

  /**
   * 재시도 큐 통계 및 현황 요약
   */
  getDispatchRetrySummary() {
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : {};
      const queue = Array.isArray(data.queue) ? data.queue.filter(x => x && typeof x === "object") : [];
      const history = Array.isArray(data.history) ? data.history.filter(x => x && typeof x === "object") : [];

      const pendingCount = queue.filter(i => i.status === "RETRY_PENDING").length;
      const deadLetterCount = queue.filter(i => i.status === "DEAD_LETTER" || i.isDeadLetter).length;
      const resolvedCount = history.length;

      return {
        totalQueued: queue.length,
        pendingCount,
        deadLetterCount,
        resolvedCount,
        queue: queue.slice(0, 50),
        recentHistory: history.slice(0, 10),
        lastAuditTime: data.lastAuditTime || Date.now()
      };
    } catch (_) {
      return {
        totalQueued: 0,
        pendingCount: 0,
        deadLetterCount: 0,
        resolvedCount: 0,
        queue: [],
        recentHistory: [],
        lastAuditTime: Date.now()
      };
    }
  }
}

module.exports = AutoRetryDispatchSentinel;
