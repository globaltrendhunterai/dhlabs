#!/usr/bin/env node
/**
 * core/recharge_cli_official.js
 * AutoFlow Engine License Recharge Forwarder (Official Store Edition)
 * Ponytail Ultra-Lightweight SSoT Forwarder (< 20 lines)
 */
process.env.AUTOFLOW_RECHARGE_CHANNEL = 'official';
module.exports = require('./recharge_cli.js');
