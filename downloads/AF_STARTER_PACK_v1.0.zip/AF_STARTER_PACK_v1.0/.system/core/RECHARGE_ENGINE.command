#!/bin/bash
# AutoFlow Engine - Interactive License Recharge Launcher (macOS)
xattr -dr com.apple.quarantine "$(cd "$(dirname "$0")" && pwd)" 2>/dev/null || true
cd "$(dirname "$0")"
chmod +x ./bin/node ../bin/node 2>/dev/null || true

# Resolve node executable (./bin/node -> ../bin/node -> /opt/homebrew/bin/node -> /usr/local/bin/node -> command -v node)
NODE_BIN=""
for candidate in "./bin/node" "../bin/node" "/opt/homebrew/bin/node" "/usr/local/bin/node"; do
  if [ -x "$candidate" ] && "$candidate" -v >/dev/null 2>&1; then
    NODE_BIN="$candidate"
    break
  fi
done
if [ -z "$NODE_BIN" ] && command -v node >/dev/null 2>&1; then
  CANDIDATE_CMD="$(command -v node)"
  if "$CANDIDATE_CMD" -v >/dev/null 2>&1; then
    NODE_BIN="$CANDIDATE_CMD"
  fi
fi

if [ -z "$NODE_BIN" ]; then
  echo "❌ Node.js 런타임을 찾을 수 없습니다. Node.js를 설치해 주세요."
  if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
    read -p "엔터를 누르면 창이 닫힙니다..."
  fi
  exit 1
fi

SCRIPT_FILE="recharge_cli.js"
if [ ! -f "$SCRIPT_FILE" ] && [ -f "./core/recharge_cli.js" ]; then
  SCRIPT_FILE="./core/recharge_cli.js"
fi

if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  clear 2>/dev/null || true
fi
echo "============================================================"
echo "⚡ AutoFlow Enterprise Engine 라이선스 관리 & 충전 런처"
echo "============================================================"
echo ""
"$NODE_BIN" "$SCRIPT_FILE" status
echo ""
echo "원하시는 작업을 선택하세요:"
echo " [1] 1개월(30일) 기간 충전팩 적용"
echo " [2] 3개월(90일) 기간 충전팩 적용"
echo " [3] 1년(365일) 엔터프라이즈 충전팩 적용"
echo " [4] 직접 일수 입력 (Custom)"
echo " [5] 라이선스 상태 새로고침"
echo " [q] 종료"
echo ""
choice="1"
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "선택 (1-5, q): " choice
fi

case "$choice" in
  1)
    "$NODE_BIN" "$SCRIPT_FILE" 30 "TOPUP_30DAYS_$(date +%s)" "1개월 충전팩 수동 적용"
    ;;
  2)
    "$NODE_BIN" "$SCRIPT_FILE" 90 "TOPUP_90DAYS_$(date +%s)" "3개월 충전팩 수동 적용"
    ;;
  3)
    "$NODE_BIN" "$SCRIPT_FILE" 365 "TOPUP_365DAYS_$(date +%s)" "1년 충전팩 수동 적용"
    ;;
  4)
    read -p "추가할 일수를 입력하세요 (예: 15): " custom_days
    "$NODE_BIN" "$SCRIPT_FILE" "$custom_days" "TOPUP_CUSTOM_$(date +%s)" "직접 입력 충전팩 적용"
    ;;
  5)
    clear 2>/dev/null || true
    "$NODE_BIN" "$SCRIPT_FILE" status
    ;;
  q|Q)
    echo "종료합니다."
    exit 0
    ;;
  *)
    echo "잘못된 입력입니다."
    ;;
esac

echo ""
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "창을 닫으려면 엔터(Enter) 키를 누르세요..."
fi
