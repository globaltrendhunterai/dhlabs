@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title AutoFlow Self-Healing Engine 30-Day Free Trial Activation
cd /d "%~dp0"

echo ============================================================
echo [AutoFlow Self-Healing Engine 30-Day Free Trial Activation]
echo ============================================================

set "NODE_BIN="
if exist "%~dp0bin\node.exe" (
    set "NODE_BIN=%~dp0bin\node.exe"
) else if exist "%~dp0..\bin\node.exe" (
    set "NODE_BIN=%~dp0..\bin\node.exe"
) else (
    where node >nul 2>nul
    if !errorlevel! equ 0 set "NODE_BIN=node"
)

if "!NODE_BIN!"=="" (
    echo [*] Auto-downloading portable Node.js runtime ^(node-v20.18.0-win-x64^)...
    if not exist "%~dp0bin" mkdir "%~dp0bin"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference = 'SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $zipUrl = 'https://nodejs.org/dist/v20.18.0/node-v20.18.0-win-x64.zip'; $zipPath = Join-Path '%~dp0' 'bin\node_win_x64.zip'; $extractDir = Join-Path '%~dp0' 'bin\node_extract_tmp'; Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing; if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }; Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force; Copy-Item -Path (Join-Path $extractDir 'node-v20.18.0-win-x64\node.exe') -Destination (Join-Path '%~dp0' 'bin\node.exe') -Force; Remove-Item $zipPath -Force -ErrorAction SilentlyContinue; Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue"
    if exist "%~dp0bin\node.exe" (
        set "NODE_BIN=%~dp0bin\node.exe"
    ) else (
        echo [ERROR] Failed to download portable Node.js runtime. Please check your internet connection.
        pause
        exit /b 1
    )
)

set "SCRIPT_FILE=%~dp0activate_trial_cli.js"
if not exist "!SCRIPT_FILE!" (
    if exist "%~dp0core\activate_trial_cli.js" set "SCRIPT_FILE=%~dp0core\activate_trial_cli.js"
)

"!NODE_BIN!" "!SCRIPT_FILE!" 30 "GUMROAD_FREE_TRIAL" "30-Day Complimentary Engine Trial" --lang=en

echo.
pause
