/**
 * AutoFlow Engine — 본사 맥미니 전용 양방향 마스터 관제 및 무인 자동화 데몬
 *
 * [보안 원칙 — Rule V8]
 * - 대표님 봇 토큰 및 chat_id는 소스코드에 절대 하드코딩되지 않음.
 * - 본사 로컬 보안 경로(~/.autoflow_hq/hq_master_config.json)가 존재하는 맥미니 환경에서만 작동.
 * - 일반 고객 PC에서는 no-op으로 안전하게 무시됨.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');
const http = require('http');

/**
 * 본사 마스터 보안 설정 로드 (고객 PC에서는 null 반환)
 */
function loadHqMasterConfig() {
  const configPath = path.join(os.homedir(), '.autoflow_hq', 'hq_master_config.json');
  if (fs.existsSync(configPath)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      const token = process.env.AUTOFLOW_HQ_TG_TOKEN || parsed.telegramBotToken;
      const chatId = String(process.env.AUTOFLOW_HQ_TG_CHAT_ID || parsed.ceoChatId || '');
      if (token && chatId) {
        return {
          token,
          chatId,
          ceoName: parsed.ceoName || '대표님',
          raw: parsed
        };
      }
    } catch (_) {}
  }
  if (process.env.AUTOFLOW_HQ_TG_TOKEN && process.env.AUTOFLOW_HQ_TG_CHAT_ID) {
    return {
      token: process.env.AUTOFLOW_HQ_TG_TOKEN,
      chatId: String(process.env.AUTOFLOW_HQ_TG_CHAT_ID),
      ceoName: '대표님',
      raw: {}
    };
  }
  return null;
}

/**
 * 텔레그램 Bot API 비동기 HTTPS 호출 유틸리티 (순수 Node.js 내장 모듈)
 */
function telegramApiCall(token, method, payload = {}) {
  return new Promise((resolve) => {
    if (!token) return resolve({ ok: false, error: 'NO_TOKEN' });
    const postData = JSON.stringify(payload);
    const options = {
      hostname: 'api.telegram.org',
      port: 443,
      path: `/bot${token}/${method}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      },
      timeout: 35000
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve({ ok: false, error: e.message, raw: data });
        }
      });
    });

    req.on('error', (err) => resolve({ ok: false, error: err.message }));
    req.on('timeout', () => {
      req.destroy();
      resolve({ ok: false, error: 'TIMEOUT' });
    });
    req.write(postData);
    req.end();
  });
}

/**
 * HTML 안전 이스케이프 헬퍼
 */
function escapeHtml(text) {
  if (text === null || text === undefined) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/**
 * 대표님 텔레그램 직관적 한국어 레이블 매핑 사전
 */
const CEO_FIELD_LABELS = {
  orderIdOrKey: '📦 주문번호',
  orderId: '📦 주문번호',
  attemptedOrder: '🚫 입력된 번호',
  ticketId: '🎟 발급 티켓 번호',
  channel: '🛒 구매처',
  validDays: '⏳ 이용 기간',
  hwid: '💻 고객 PC 식별번호',
  clientHwid: '💻 고객 PC 식별번호',
  customerEmail: '📧 고객 이메일',
  customerMessage: '💬 고객 문의 내용',
  error: '⚠️ 차단 사유',
  targetNode: '🔌 발생 위치',
  errorName: '⚠️ 오류 종류',
  errorMessage: '📄 오류 내용',
  usedModel: '🤖 수리 담당 AI',
  fineTuningModel: '🤖 수리 담당 AI',
  ruleId: '🛡 자동 생성된 방어규칙',
  newRuleInjected: '🛡 자동 생성된 방어규칙',
  patchStatus: '✅ 수리 결과',
  totalRules: '📚 누적 방어규칙 수',
  issuedTicketCount: '🎫 티켓 발급 점검',
  kbEntries: '📖 CS 자동응답 사전',
  status: '🟢 작동 상태',
  test: '🟢 작동 상태',
  host: '🖥 본사 서버',
  platform: '⚙️ 운영체제',
  nodeVersion: '🔧 엔진 버전',
  uptime: '⏱ 연속 가동 시간',
  commands: '⌨️ 사용 가능 명령어',
  intruderChatId: '🚫 차단된 외부 ID',
  intruderUsername: '👤 외부 사용자명',
  text: '📝 시도한 메시지',
  reason: '⚠️ 사유',
  action: '⚡️ 조치 내용',
  activeBitmask: '🔢 활성 모듈',
  bitmask: '🔢 활성 모듈'
};

/**
 * 대표님용 필드값 한국어 친화형 포맷터
 */
function formatCeoFieldValue(key, val) {
  if (val === null || val === undefined) return '없음';
  const str = String(val).trim();

  // 채널 값 한국어 변환
  if (key === 'channel') {
    const uc = str.toUpperCase();
    if (uc.includes('SMARTSTORE') || uc.includes('NAVER')) return '네이버 스마트스토어';
    if (uc.includes('GUMROAD')) return '검로드(해외결제)';
    if (uc.includes('TELEGRAM_DIRECT')) return '대표님 직권 발급';
    return str;
  }

  // 차단 사유 변환
  if (key === 'error' || key === 'reason') {
    if (str.includes('ORDER_ALREADY_REDEEMED_BY_ANOTHER_DEVICE')) {
      return '다른 PC에서 이미 사용된 주문번호 (도용 차단)';
    }
    if (str.includes('UNVERIFIED_EXTERNAL_ORDER')) {
      return '결제 내역이 없는 미확인 번호 차단';
    }
  }

  // 수리 모델명 변환
  if (key === 'usedModel' || key === 'fineTuningModel') {
    if (str.includes('gemma3')) return '본사 수리봇 (Gemma-3)';
    if (str.includes('dolphin3')) return '본사 수리봇 (Dolphin-3)';
    return str;
  }

  // 누적 룰 수
  if (key === 'totalRules') {
    if (/^\d+$/.test(str)) return `${str}개`;
  }

  // 이용 기간
  if (key === 'validDays') {
    if (/^\d+$/.test(str)) return `${str}일권`;
  }

  // HWID 축약 표시
  if (key === 'hwid' || key === 'clientHwid') {
    if (str.length > 20) {
      return `${str.slice(0, 16)}...`;
    }
  }

  return str;
}

/**
 * 대표님 텔레그램 고시인성 직보 전송 함수
 * @param {string} category 알림 분류 (예: '💰 [무인 결제·티켓 자동 발급]')
 * @param {string} title 알림 제목
 * @param {Object} detailsObj 세부 항목 키-값 객체
 */
async function sendCeoTelegramAlert(category, title, detailsObj = {}) {
  const cfg = loadHqMasterConfig();
  if (!cfg || !cfg.token || !cfg.chatId) {
    return { success: false, reason: 'HQ_CONFIG_OR_TOKEN_NOT_FOUND', noOp: true };
  }

  const kstTime = new Date(Date.now() + 9 * 3600 * 1000).toISOString().replace('T', ' ').substring(0, 19) + ' KST';
  const combinedContext = `${category} ${title}`.toLowerCase();
  const requiresCeoAction = /환불|상담|직접|확인\s*필요|에스컬레이션|수동|신고|고소/.test(combinedContext);
  const actionBadge = requiresCeoAction
    ? `🔴 <b>[대표님 확인 필요 — 고객 1:1 응대 요청]</b>`
    : `🟢 <b>[자동 처리 완료 — 대표님 조치 불필요]</b>`;

  const detailLines = Object.entries(detailsObj)
    .map(([k, v]) => {
      const label = CEO_FIELD_LABELS[k] || `• ${escapeHtml(k)}`;
      const formattedVal = formatCeoFieldValue(k, v);
      const isCodeLike = /^[A-Za-z0-9_-]{8,}$/.test(String(v)) || k.toLowerCase().includes('ticket') || k.toLowerCase().includes('order') || k.toLowerCase().includes('hwid');
      const valHtml = isCodeLike ? `<code>${escapeHtml(formattedVal)}</code>` : `<b>${escapeHtml(formattedVal)}</b>`;
      return `${label}: ${valHtml}`;
    })
    .join('\n');

  const text =
    `<b>${escapeHtml(title)}</b>\n` +
    `${actionBadge}\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `${detailLines || '• 세부 정보 없음'}\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `🕒 ${escapeHtml(kstTime)}`;

  const res = await telegramApiCall(cfg.token, 'sendMessage', {
    chat_id: cfg.chatId,
    text,
    parse_mode: 'HTML'
  });

  return { success: Boolean(res && res.ok), response: res };
}

/**
 * Zone 3 미학습 에러 수신 및 파인튜닝 수리 봇 실시간 추론 & 자가면역 규칙 자동 패치 & 텔레그램 직보
 */
async function handleZone3Escalation(errorData = {}) {
  try {
    const { HqLiveRepairRunner } = require('./fine_tuning_bot/hq_live_repair_runner');
    const runner = new HqLiveRepairRunner();
    return await runner.repairAndSynthesizeRule(errorData);
  } catch (err) {
    const errName = String(errorData.errorName || errorData.name || 'UNKNOWN_ERROR');
    const errMsg = String(errorData.errorMessage || errorData.message || 'No error message provided');
    const clientHwid = String(errorData.clientHwid || errorData.hwid || 'UNKNOWN_HWID');
    const targetNode = String(errorData.targetNode || errorData.node || 'External Market Connector');
    const platform = String(errorData.platform || 'AUTOFLOW_CORE');

    const baseDir = path.resolve(__dirname, '..');
    const configDir = path.join(baseDir, 'config');
    const rulesPath = path.join(configDir, 'dynamic_healing_rules.json');
    let currentRules = [];
    if (fs.existsSync(rulesPath)) {
      try {
        currentRules = JSON.parse(fs.readFileSync(rulesPath, 'utf8'));
      } catch (_) {}
    }

    const ruleId = `RULE-HEAL-AUTO-${Date.now().toString(36).toUpperCase()}`;
    const safeRegexPattern = errName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const newRule = {
      rule_id: ruleId,
      target_node: targetNode,
      regex: `(${safeRegexPattern})`,
      action: 'INJECT_BACKOFF_RETRY',
      max_retries: 3,
      platform: platform,
      description_ko: `고객사 [${clientHwid.slice(0, 10)}...] 신종 에러 자동 면역 학습 규칙: ${errName}`,
      inserted_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    currentRules.push(newRule);
    try {
      fs.writeFileSync(rulesPath, JSON.stringify(currentRules, null, 2), 'utf8');
      const coreRulesPath = path.join(baseDir, 'core', 'dynamic_healing_rules.json');
      let coreRulesObj = { rules: {} };
      if (fs.existsSync(coreRulesPath)) {
        try {
          const raw = JSON.parse(fs.readFileSync(coreRulesPath, 'utf8'));
          if (raw && raw.rules && typeof raw.rules === 'object') {
            coreRulesObj = raw;
          } else if (Array.isArray(raw)) {
            for (const r of raw) {
              if (r && r.rule_id) coreRulesObj.rules[r.rule_id] = { ...r, symptom: r.symptom || r.description_ko || r.regex };
            }
          }
        } catch (_) {}
      }
      coreRulesObj.rules[ruleId] = {
        ...newRule,
        symptom: newRule.description_ko || newRule.regex
      };
      fs.writeFileSync(coreRulesPath, JSON.stringify(coreRulesObj, null, 2), 'utf8');
    } catch (_) {}

    await sendCeoTelegramAlert(
      '🚨 [고객 Zone 3 미학습 에러 에스컬레이션]',
      '🚨 고객 미학습 에러 수신 & 면역 규칙 자동 패치 완료',
      {
        clientHwid: clientHwid.slice(0, 16) + '...',
        errorName: errName,
        errorMessage: errMsg.slice(0, 150),
        ruleId,
        totalRules: currentRules.length
      }
    );

    return {
      success: true,
      escalated: true,
      ruleId,
      totalRules: currentRules.length,
      message: 'Zone 3 에러 에스컬레이션 접수 및 면역 규칙 자동 패치가 완료되었습니다.'
    };
  }
}

/**
 * 로컬 포트 활성 여부 비동기 검사
 */
function checkPortActive(port) {
  return new Promise((resolve) => {
    const req = http.request({
      hostname: '127.0.0.1',
      port,
      path: '/healthz',
      method: 'GET',
      timeout: 1000
    }, (res) => {
      resolve(true);
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
    req.end();
  });
}

/**
 * 텔레그램 명령어 핸들러
 */
async function handleTelegramCommand(command, args, fromChatId, cfg, rawMsg = null) {
  const baseDir = path.resolve(__dirname, '..');
  const licenseManager = require('./license_manager');

  const rawText = rawMsg && rawMsg.text ? String(rawMsg.text).trim() : '';
  const isPwDirect = /^비밀번호\s*[:：]\s*(.+)$/i.test(rawText);
  const isPlainPasswordCandidate = Boolean(rawText && !rawText.startsWith('/') && !isPwDirect && rawText.split(/\s+/).length === 1 && rawText.length >= 6);
  const cmdLower = (isPwDirect || isPlainPasswordCandidate) ? '/pw' : command.toLowerCase();

  switch (cmdLower) {
    case '/pw':
    case '/sns_pw': {
      let pwVal = '';
      if (isPwDirect) {
        const m = rawText.match(/^비밀번호\s*[:：]\s*(.+)$/i);
        pwVal = m ? m[1].trim() : '';
      } else if (isPlainPasswordCandidate) {
        pwVal = rawText;
      } else {
        pwVal = args.join(' ').trim();
      }

      if (!pwVal) {
        await telegramApiCall(cfg.token, 'sendMessage', {
          chat_id: fromChatId,
          text: `🔐 <b>[SNS 비밀번호 로컬 메모장 직통 저장]</b>\n사용법: <code>/pw 사용할비밀번호</code> 또는 <code>비밀번호: 사용할비밀번호</code> 형태로 보내주시면 클라우드를 거치지 않고 맥미니 바탕화면 메모장과 로컬 금고에 즉시 저장합니다.`,
          parse_mode: 'HTML'
        });
        break;
      }

      const vaultDir = path.join(os.homedir(), '.autoflow_vault');
      const secretFile = path.join(vaultDir, 'sns_password.secret');
      const desktopNote = path.join(os.homedir(), 'Desktop', 'DH_LABS_SNS_계정정보_로컬전용.txt');
      try {
        fs.mkdirSync(vaultDir, { recursive: true, mode: 0o700 });
        fs.writeFileSync(secretFile, pwVal, { encoding: 'utf8', mode: 0o600 });
        fs.chmodSync(secretFile, 0o600);

        const noteContent =
          `===================================================================\n` +
          `[DH Labs 공식 SNS & 외부 채널 계정 마스터 메모 — 맥미니 로컬 전용]\n` +
          `※ 클라우드 AI는 이 파일을 직접 읽지 않으며, 로컬 스크립트(set_local_sns_password.sh)가\n` +
          `   아래 '비밀번호:' 옆에 적힌 값만 클라우드 노출 0% 상태로 블라인드 복사해 사용합니다.\n` +
          `===================================================================\n` +
          `이메일 아이디: dhlabs_biz@naver.com\n` +
          `공식 핸들(ID): @dhlabs_autoflow\n` +
          `비밀번호: ${pwVal}\n` +
          `===================================================================\n`;
        fs.writeFileSync(desktopNote, noteContent, { encoding: 'utf8', mode: 0o600 });
        fs.chmodSync(desktopNote, 0o600);
      } catch (e) {
        await telegramApiCall(cfg.token, 'sendMessage', {
          chat_id: fromChatId,
          text: `⚠️ 로컬 금고 저장 중 오류 발생: <code>${escapeHtml(e.message)}</code>`,
          parse_mode: 'HTML'
        });
        break;
      }

      // 보안을 위해 텔레그램 대화창에 남은 비밀번호 원문 메시지 즉시 삭제 시도
      let deletedInTg = false;
      if (rawMsg && rawMsg.message_id) {
        try {
          const delRes = await telegramApiCall(cfg.token, 'deleteMessage', {
            chat_id: fromChatId,
            message_id: rawMsg.message_id
          });
          deletedInTg = Boolean(delRes && delRes.ok);
        } catch (_) {}
      }

      const pwLen = pwVal.length;
      pwVal = ''; // 메모리 즉시 소거

      const confirmMsg =
        `🔐 <b>[맥미니 로컬 메모장 & 보안 금고 자동 기록 완료]</b>\n` +
        `🟢 <b>[클라우드 노출 0% · 블라인드 사용 준비 완료]</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `📧 <b>공식 이메일</b>: <code>dhlabs_biz@naver.com</code>\n` +
        `🔑 <b>저장된 비밀번호 길이</b>: <b>${pwLen}자</b> (원문 비노출)\n` +
        `📝 <b>바탕화면 메모장</b>: <code>~/Desktop/DH_LABS_SNS_계정정보_로컬전용.txt</code>\n` +
        `🛡 <b>로컬 금고</b>: <code>~/.autoflow_vault/sns_password.secret</code>\n` +
        `🧹 <b>텔레그램 원문 삭제</b>: <b>${deletedInTg ? '자동 삭제 완료' : '수동 삭제 권장'}</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `이제 채팅창에서 에이전트에게 <b>"보냈어"</b>라고만 말씀해 주시면 즉시 SNS 계정 생성에 사용합니다.`;

      await telegramApiCall(cfg.token, 'sendMessage', {
        chat_id: fromChatId,
        text: confirmMsg,
        parse_mode: 'HTML'
      });
      break;
    }

    case '/start':
    case '/help': {
      const helpMsg =
        `🤖 <b>[AutoFlow HQ 마스터 관제 센터]</b>\n` +
        `본사 무인 관제 센터가 정상 가동 중입니다.\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `<b>사용 가능한 마스터 명령어:</b>\n` +
        `• <code>/status</code> : 서버 리소스, 데몬 포트, 발급/면역 현황 보고\n` +
        `• <code>/issue &lt;일수&gt;</code> : 정품 티켓 즉시 발급 (예: <code>/issue 30</code>)\n` +
        `• <code>/orders</code> : 최근 주문/발급 내역 상위 5건 요약\n` +
        `• <code>/revoke &lt;티켓ID&gt;</code> : 해당 티켓 즉시 영구 회수\n` +
        `• <code>/pw &lt;비밀번호&gt;</code> : 클라우드 무노출 맥미니 로컬 메모장·금고 직통 비밀번호 저장\n` +
        `━━━━━━━━━━━━━━━━━━`;

      await telegramApiCall(cfg.token, 'sendMessage', {
        chat_id: fromChatId,
        text: helpMsg,
        parse_mode: 'HTML'
      });
      break;
    }

    case '/status': {
      const freeMemGb = (os.freemem() / (1024 * 1024 * 1024)).toFixed(2);
      const totalMemGb = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(2);
      const uptimeHrs = (os.uptime() / 3600).toFixed(1);
      const [port5678, port5679] = await Promise.all([checkPortActive(5678), checkPortActive(5679)]);

      const ledgerPath = path.join(baseDir, 'logs', 'hq_issued_tickets_ledger.jsonl');
      let issuedCount = 0;
      if (fs.existsSync(ledgerPath)) {
        try {
          issuedCount = fs.readFileSync(ledgerPath, 'utf8').trim().split('\n').filter(Boolean).length;
        } catch (_) {}
      }

      const rulesPath = path.join(baseDir, 'config', 'dynamic_healing_rules.json');
      let rulesCount = 0;
      if (fs.existsSync(rulesPath)) {
        try {
          const parsed = JSON.parse(fs.readFileSync(rulesPath, 'utf8'));
          rulesCount = Array.isArray(parsed) ? parsed.length : (parsed.rules ? Object.keys(parsed.rules).length : 0);
        } catch (_) {}
      }

      const kstTime = new Date(Date.now() + 9 * 3600 * 1000).toISOString().replace('T', ' ').substring(0, 19) + ' KST';
      const statusMsg =
        `📊 <b>[AutoFlow HQ 본사 마스터 상태 보고]</b>\n` +
        `🟢 <b>[정상 가동 중 — 모든 서비스 안정]</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `🖥 <b>본사 서버</b>: <code>${os.hostname()}</code> (${os.platform()} ${os.arch()})\n` +
        `⏱ <b>가동 시간</b>: <code>${uptimeHrs}시간</code>\n` +
        `💾 <b>메모리</b>: <code>${freeMemGb} GB 가용 / ${totalMemGb} GB 전체</code>\n` +
        `🌐 <b>데몬 포트</b>: 5678(${port5678 ? '🟢정상' : '⚪️대기'}) · 5679(${port5679 ? '🟢정상' : '⚪️대기'})\n` +
        `🎫 <b>누적 발급 티켓</b>: <b>${issuedCount}건</b>\n` +
        `🛡 <b>자가면역 규칙(SSOT)</b>: <b>${rulesCount}개</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `🕒 <code>${kstTime}</code>`;

      await telegramApiCall(cfg.token, 'sendMessage', {
        chat_id: fromChatId,
        text: statusMsg,
        parse_mode: 'HTML'
      });
      break;
    }

    case '/issue': {
      const validDays = parseInt(args[0], 10) || 30;
      const targetChannel = (args[1] || 'TELEGRAM_DIRECT').toUpperCase();
      const issued = licenseManager.issueSignedModuleTicket({
        validDays,
        bitmask: 1023,
        purchaseChannel: targetChannel,
        customerId: `HQ_DIRECT_ISSUE_${Date.now()}`
      });

      // 원장 기록
      const ledgerPath = path.join(baseDir, 'logs', 'hq_issued_tickets_ledger.jsonl');
      const rec = {
        orderIdOrKey: issued.ticketId,
        orderId: `DIRECT-${Date.now()}`,
        hwid: issued.customerId,
        ticketId: issued.ticketId,
        ticket: issued.ticket,
        bitmask: issued.bitmask,
        validDays: issued.validDays,
        channel: targetChannel,
        customerEmail: 'ceo@autoflow.io',
        issuedAt: issued.issuedAt,
        expiresAt: issued.expiresAt
      };
      try {
        fs.appendFileSync(ledgerPath, JSON.stringify(rec) + '\n', 'utf8');
      } catch (_) {}

      const issueMsg =
        `🎟 <b>[정품 모듈 티켓 즉시 발급 완료]</b>\n` +
        `🟢 <b>[발급 완료 — 고객 전달 가능]</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `🎟 <b>티켓 번호</b>: <code>${issued.ticketId}</code>\n` +
        `⏳ <b>이용 기간</b>: <b>${issued.validDays}일권</b>\n` +
        `📦 <b>해금 모듈</b>: <b>전체 10종 완제품 풀 패키지</b>\n` +
        `📅 <b>만료 예정</b>: <code>${issued.expiresAt}</code>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `📋 <b>서명 티켓 코드 (복사용):</b>\n` +
        `<code>${issued.ticket}</code>`;

      await telegramApiCall(cfg.token, 'sendMessage', {
        chat_id: fromChatId,
        text: issueMsg,
        parse_mode: 'HTML'
      });
      break;
    }

    case '/orders': {
      const ledgerPath = path.join(baseDir, 'logs', 'hq_issued_tickets_ledger.jsonl');
      let orders = [];
      if (fs.existsSync(ledgerPath)) {
        try {
          const lines = fs.readFileSync(ledgerPath, 'utf8').trim().split('\n').filter(Boolean);
          orders = lines.slice(-5).reverse().map(l => JSON.parse(l));
        } catch (_) {}
      }

      if (orders.length === 0) {
        await telegramApiCall(cfg.token, 'sendMessage', {
          chat_id: fromChatId,
          text: `📦 <b>[최근 발급 내역]</b>\n현재 기록된 발급 내역이 없습니다.`,
          parse_mode: 'HTML'
        });
        break;
      }

      const orderList = orders.map((o, idx) => {
        const ch = formatCeoFieldValue('channel', o.channel || 'SMARTSTORE');
        const days = o.validDays ? `${o.validDays}일권` : '30일권';
        return `${idx + 1}. <b>${escapeHtml(o.ticketId || o.orderId)}</b>\n` +
          `   • 구매처: ${ch} (${days})\n` +
          `   • 기기: <code>${escapeHtml((o.hwid || '').slice(0, 16))}...</code>\n` +
          `   • 발급: <code>${escapeHtml((o.issuedAt || '').slice(0, 19))}</code>`;
      }).join('\n\n');

      const msg =
        `📦 <b>[최근 주문/발급 내역 상위 ${orders.length}건]</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `${orderList}\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `총 ${orders.length}건 조회됨`;

      await telegramApiCall(cfg.token, 'sendMessage', {
        chat_id: fromChatId,
        text: msg,
        parse_mode: 'HTML'
      });
      break;
    }

    case '/revoke': {
      const targetTicketId = args[0];
      if (!targetTicketId) {
        await telegramApiCall(cfg.token, 'sendMessage', {
          chat_id: fromChatId,
          text: `⚠️ 회수할 티켓 ID를 입력하십시오. 예: <code>/revoke TKT-12345</code>`,
          parse_mode: 'HTML'
        });
        break;
      }

      const res = licenseManager.revokeModuleTicketOnly({
        ticketId: targetTicketId,
        reason: 'CEO_TELEGRAM_COMMAND_REVOCATION'
      });

      const revokeMsg =
        `🛑 <b>[티켓 영구 회수 처리 완료]</b>\n` +
        `🔴 <b>[티켓 즉시 무효화 완료]</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `🎟 <b>대상 티켓 ID</b>: <code>${escapeHtml(targetTicketId)}</code>\n` +
        `✅ <b>회수 결과</b>: ${res.success ? '<b>정상 회수됨</b>' : '<b>회수 실패</b>'}\n` +
        `🔢 <b>남은 활성 비트마스크</b>: <code>${res.activeModuleBitmask}</code>\n` +
        `🔒 <b>기본 워크플로우</b>: <b>${res.workflowPerpetualOwned ? '영구 가동 유지' : '종료'}</b>\n` +
        `━━━━━━━━━━━━━━━━━━`;

      await telegramApiCall(cfg.token, 'sendMessage', {
        chat_id: fromChatId,
        text: revokeMsg,
        parse_mode: 'HTML'
      });
      break;
    }

    default: {
      await telegramApiCall(cfg.token, 'sendMessage', {
        chat_id: fromChatId,
        text: `알 수 없는 명령어입니다: <code>${escapeHtml(command)}</code>\n도움말은 <code>/help</code>를 입력하십시오.`,
        parse_mode: 'HTML'
      });
      break;
    }
  }
}

/**
 * 대표님 전용 양방향 롱 폴링 데몬 루프
 */
async function startMasterSentinelDaemon() {
  const cfg = loadHqMasterConfig();
  if (!cfg || !cfg.token || !cfg.chatId) {
    console.log('[HQ Sentinel] No master config found. Running in customer no-op mode.');
    return;
  }

  console.log(`[HQ Sentinel] Starting Master Telegram Sentinel Daemon for CEO (chat_id: ${cfg.chatId})...`);

  // 기동 알림 1회 발송
  await sendCeoTelegramAlert(
    '🔥 [맥미니 본사 서버 자가진단]',
    '🚀 [본사 마스터 데몬 상시 가동 완료 & 명령어 안내]',
    {
      host: os.hostname(),
      platform: `${os.platform()} (${os.arch()})`,
      nodeVersion: process.version,
      commands: '/status, /issue 30, /orders, /revoke',
      uptime: `${(os.uptime() / 3600).toFixed(1)}시간`
    }
  );

  let lastUpdateId = 0;
  let isRunning = true;

  process.on('SIGINT', () => { isRunning = false; });
  process.on('SIGTERM', () => { isRunning = false; });

  while (isRunning) {
    try {
      const updatesRes = await telegramApiCall(cfg.token, 'getUpdates', {
        offset: lastUpdateId + 1,
        timeout: 25,
        allowed_updates: ['message']
      });

      if (updatesRes && updatesRes.ok && Array.isArray(updatesRes.result)) {
        for (const update of updatesRes.result) {
          lastUpdateId = update.update_id;
          const msg = update.message;
          if (!msg || !msg.text) continue;

          const senderChatId = String(msg.chat.id);
          // 오직 대표님 chat_id만 허용 (보안 차단)
          if (senderChatId !== String(cfg.chatId)) {
            console.warn(`[HQ Sentinel] Blocked unauthorized message from chat_id: ${senderChatId}`);
            await sendCeoTelegramAlert(
              '⚠️ [비인가 접근 차단]',
              '🚨 타인 텔레그램 봇 접근 시도 감지 및 즉시 차단',
              {
                intruderChatId: senderChatId,
                intruderUsername: msg.from ? (msg.from.username || msg.from.first_name || 'unknown') : 'unknown',
                text: msg.text.slice(0, 100)
              }
            );
            continue;
          }

          const parts = msg.text.trim().split(/\s+/);
          const command = parts[0];
          const args = parts.slice(1);

          await handleTelegramCommand(command, args, senderChatId, cfg, msg);
        }
      }
    } catch (err) {
      console.error('[HQ Sentinel] Polling error:', err.message);
      await new Promise(r => setTimeout(r, 5000));
    }
  }

  console.log('[HQ Sentinel] Sentinel daemon stopped gracefully.');
}

module.exports = {
  loadHqMasterConfig,
  sendCeoTelegramAlert,
  handleZone3Escalation,
  startMasterSentinelDaemon
};

// CLI 직접 실행 시 (--daemon 플래그 시 상시 폴링)
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.includes('--daemon')) {
    startMasterSentinelDaemon();
  } else if (args.includes('--test-alert')) {
    sendCeoTelegramAlert('🔥 [맥미니 본사 서버 자가진단]', '자가진단 테스트 알림', { test: 'OK' })
      .then(res => console.log('Test alert result:', res))
      .catch(console.error);
  } else {
    console.log('Usage: node core/hq_telegram_master_sentinel.js [--daemon | --test-alert]');
  }
}
