/**
 * core/timeline_recorder.js
 * AutoFlow 10-Minute Blackbox Timeline Flight Recorder (Ring Buffer)
 * 
 * 대표님 공학적 직관 반영:
 * "이상 감지되면 메시지를 보내고 직전 몇분(5분)부터 이후 몇분(5분)까지 로그를 핀포인트 수집한다."
 * 
 * [동작 원리]
 * 1. 평상시: 메모리 내 5분(300초) 원형 버퍼(Ring Buffer)에만 로그 롤링 보관 (디스크 I/O 0, 트래픽 0 Byte).
 * 2. 이상/에러 감지 순간 (T0):
 *    - 직전 5분치 버퍼를 즉각 동결(Freeze) 스냅샷으로 확보.
 *    - 직후 5분 동안 발생하는 모든 후속 징후 및 2차 공격 패턴을 추가 큐에 수집.
 * 3. T0+5분 후: 총 10분간의 단일 압축 블랙박스 캡슐(logs/incidents/TIMELINE_{trace_id}.jsonl)로 디스크 각인.
 * 4. 원격 인출 지원: 중앙 관제 서버 요청 시 단 1장의 0.1MB 포렌식 스냅샷으로 1초 만에 덤프 전송.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const LOGS_DIR = path.resolve(__dirname, '../logs');
const INCIDENTS_DIR = path.join(LOGS_DIR, 'incidents');

if (!fs.existsSync(INCIDENTS_DIR)) {
  try {
    fs.mkdirSync(INCIDENTS_DIR, { recursive: true });
  } catch (e) {
    console.error(`[TimelineRecorder] Could not create incidents directory:`, e.message);
  }
}

const PRE_BUFFER_MS = parseInt(process.env.AUTOFLOW_PRE_BUFFER_MS || '300000', 10); // 5분
const POST_BUFFER_MS = parseInt(process.env.AUTOFLOW_POST_BUFFER_MS || '300000', 10); // 5분
const MAX_MEMORY_LOGS = parseInt(process.env.AUTOFLOW_MAX_RING_LOGS || '1000', 10);

class TimelineRecorder {
  constructor(preMs = PRE_BUFFER_MS, postMs = POST_BUFFER_MS) {
    if (preMs && typeof preMs === 'object') {
      postMs = preMs.postMs !== undefined ? preMs.postMs : postMs;
      preMs = preMs.preMs;
    }
    this.preMs = (typeof preMs === 'number' && Number.isFinite(preMs) && preMs > 0) ? preMs : PRE_BUFFER_MS;
    this.postMs = (typeof postMs === 'number' && Number.isFinite(postMs) && postMs > 0) ? postMs : POST_BUFFER_MS;
    this.ringBuffer = [];
    this.activeIncidents = new Map(); // traceId -> { snapshotPre, postLogs, freezeUntil, timer }
  }

  /**
   * 평상시 모든 런타임 로그를 메모리 원형 버퍼에 밀어 넣음
   */
  pushLog(level, topic, message, details = {}) {
    const now = Date.now();
    const normLevel = (typeof level === 'string' && level.trim()) ? level.trim() : 'INFO';
    const normTopic = (typeof topic === 'string' && topic.trim()) ? topic.trim() : 'RUNTIME';
    const normDetails = (details && typeof details === 'object') ? details : {};
    const entry = {
      timestamp: new Date(now).toISOString(),
      timestamp_ms: now,
      level: normLevel,
      topic: normTopic,
      message: typeof message === 'string' ? message : JSON.stringify(message ?? ''),
      details: normDetails
    };

    this.ringBuffer.push(entry);

    // 원형 버퍼 크기 및 유효기간(5분) 관리
    const cutoff = now - this.preMs;
    while (this.ringBuffer.length > MAX_MEMORY_LOGS || (this.ringBuffer.length > 0 && this.ringBuffer[0].timestamp_ms < cutoff)) {
      this.ringBuffer.shift();
    }

    // 현재 활성화된 사후(Post-5분) 수집 세션이 있다면 해당 세션에도 기록
    for (const [traceId, session] of this.activeIncidents.entries()) {
      if (now <= session.freezeUntil) {
        session.postLogs.push(entry);
      }
    }

    return entry;
  }

  /**
   * 이상/해킹/크래시 감지 즉시 호출: 직전 5분 동결 & 직후 5분 수집 예약
   */
  triggerIncident(traceId, reason = 'ANOMALY_DETECTED', postWindowMs = null) {
    if (traceId && typeof traceId === 'object') {
      if (reason === 'ANOMALY_DETECTED' || (reason && typeof reason === 'object')) {
        reason = traceId.reason || 'ANOMALY_DETECTED';
      }
      if (postWindowMs === null || (postWindowMs && typeof postWindowMs === 'object')) {
        postWindowMs = traceId.postWindowMs !== undefined ? traceId.postWindowMs : traceId.postMs;
      }
      traceId = traceId.traceId || traceId.trace_id || traceId.incidentId || traceId.id || '';
    }
    const now = Date.now();
    const incidentTraceId = (typeof traceId === 'string' && traceId.trim().length > 0)
      ? traceId.trim()
      : `INCIDENT-${crypto.randomUUID().substring(0, 8)}`;
    const normReason = (typeof reason === 'string' && reason.trim().length > 0)
      ? reason.trim()
      : 'ANOMALY_DETECTED';
    const effectivePostMs = (typeof postWindowMs === 'number' && Number.isFinite(postWindowMs) && postWindowMs > 0)
      ? postWindowMs
      : ((typeof this.postMs === 'number' && Number.isFinite(this.postMs) && this.postMs > 0) ? this.postMs : POST_BUFFER_MS);

    if (this.activeIncidents.has(incidentTraceId)) {
      return this.activeIncidents.get(incidentTraceId);
    }

    // 1. 직전 5분치 버퍼 스냅샷 복사
    const cutoff = now - this.preMs;
    const preSnapshot = this.ringBuffer.filter(log => log.timestamp_ms >= cutoff);

    // 2. 사건 발생 마커 삽입
    const incidentMarker = {
      timestamp: new Date(now).toISOString(),
      timestamp_ms: now,
      level: 'FATAL_INCIDENT',
      topic: 'TIMELINE_TRIGGER',
      message: `[T=0] Incident triggered: ${normReason}`,
      trace_id: incidentTraceId
    };

    const session = {
      traceId: incidentTraceId,
      triggeredAt: now,
      freezeUntil: now + effectivePostMs,
      reason: normReason,
      snapshotPre: preSnapshot,
      incidentMarker,
      postLogs: []
    };

    // 직후 5분(postMs) 만료 시 1장의 완성된 캡슐로 플러시
    session.timer = setTimeout(() => {
      this.flushIncidentCapsule(incidentTraceId);
    }, effectivePostMs);

    // 테스트 환경 또는 강제 종료 대비 unref
    if (session.timer.unref) session.timer.unref();

    this.activeIncidents.set(incidentTraceId, session);
    console.log(`[TimelineRecorder] ⏱️ 10-Minute Blackbox triggered for: ${incidentTraceId} (Pre: ${preSnapshot.length} logs, Post-recording started)`);

    return session;
  }

  triggerBlackbox(traceId, reason = 'ANOMALY_DETECTED', postWindowMs = null) {
    return this.triggerIncident(traceId, reason, postWindowMs);
  }

  /**
   * 10분 타임라인 캡슐을 디스크에 원자적으로 저장 (JSON 및 JSONL 동시 각인)
   */
  flushIncidentCapsule(traceId) {
    const normTraceId = (typeof traceId === 'string' && traceId.trim().length > 0)
      ? traceId.trim()
      : (traceId && typeof traceId === 'object' ? String(traceId.traceId || traceId.trace_id || '').trim() : '');
    if (!normTraceId) return null;
    const session = this.activeIncidents.get(normTraceId);
    if (!session) return null;

    if (session.timer) clearTimeout(session.timer);
    this.activeIncidents.delete(normTraceId);

    const fullTimeline = [
      ...session.snapshotPre,
      session.incidentMarker,
      ...session.postLogs
    ];

    const capsulePath = path.join(INCIDENTS_DIR, `TIMELINE_${normTraceId}.json`);
    const capsuleJsonlPath = path.join(INCIDENTS_DIR, `TIMELINE_${normTraceId}.jsonl`);
    const tempPath = `${capsulePath}.tmp.${Date.now()}`;
    const tempJsonlPath = `${capsuleJsonlPath}.tmp.${Date.now()}`;

    const manifest = {
      trace_id: normTraceId,
      reason: session.reason,
      triggered_at: new Date(session.triggeredAt).toISOString(),
      pre_log_count: session.snapshotPre.length,
      post_log_count: session.postLogs.length,
      total_log_count: fullTimeline.length,
      timeline: fullTimeline
    };

    try {
      fs.writeFileSync(tempPath, JSON.stringify(manifest, null, 2), 'utf8');
      fs.renameSync(tempPath, capsulePath);

      // JSONL 포맷: 1행 메타데이터 매니페스트, 2행부터 각 타임라인 이벤트
      const jsonlLines = [
        JSON.stringify(manifest),
        ...fullTimeline.map(item => JSON.stringify(item))
      ].join('\n') + '\n';
      fs.writeFileSync(tempJsonlPath, jsonlLines, 'utf8');
      fs.renameSync(tempJsonlPath, capsuleJsonlPath);

      console.log(`[TimelineRecorder] 📦 10-Minute Flight Capsule Sealed: ${capsulePath} & ${capsuleJsonlPath} (Total ${fullTimeline.length} events)`);
      return capsulePath;
    } catch (err) {
      console.error(`[TimelineRecorder] ❌ Failed to seal capsule: ${err.message}`);
      return null;
    }
  }

  /**
   * Trace ID 기준으로 타임라인 캡슐 인출 (디스크 JSON/JSONL, 활성 세션, 또는 링 버퍼)
   */
  getCapsuleByTraceId(traceId) {
    const normTraceId = (typeof traceId === 'string' && traceId.trim().length > 0)
      ? traceId.trim()
      : (traceId && typeof traceId === 'object' ? String(traceId.traceId || traceId.trace_id || '').trim() : '');
    if (!normTraceId) return null;

    const candidateFiles = [
      path.join(INCIDENTS_DIR, `TIMELINE_${normTraceId}.json`),
      path.join(INCIDENTS_DIR, `TIMELINE_${normTraceId}.jsonl`),
      path.join(INCIDENTS_DIR, `${normTraceId}.json`),
      path.join(INCIDENTS_DIR, `${normTraceId}.jsonl`),
      path.join(INCIDENTS_DIR, normTraceId)
    ];

    for (const filePath of candidateFiles) {
      if (fs.existsSync(filePath)) {
        try {
          const raw = fs.readFileSync(filePath, 'utf8').trim();
          if (raw.startsWith('{') && raw.endsWith('}')) {
            try {
              const parsed = JSON.parse(raw);
              if (parsed && (parsed.timeline || parsed.trace_id)) {
                return parsed;
              }
            } catch (jsonErr) {
              // Fallback to line-by-line parsing if not standard JSON object
            }
          }
          const lines = raw.split('\n').filter(Boolean);
          if (lines.length > 0) {
            const firstObj = JSON.parse(lines[0]);
            if (firstObj && firstObj.timeline) {
              return firstObj;
            }
            const allItems = lines.map(line => JSON.parse(line));
            const marker = allItems.find(e => e.topic === 'TIMELINE_TRIGGER' || (e.message && e.message.includes('Incident triggered')));
            return {
              trace_id: normTraceId,
              reason: marker ? marker.message.replace(/.*Incident triggered:\s*/, '') : 'SEALED_INCIDENT',
              status: 'SEALED_CAPSULE',
              total_log_count: allItems.length,
              timeline: allItems
            };
          }
        } catch (err) {
          console.error(`[TimelineRecorder] ❌ Error parsing capsule from ${filePath}:`, err.message);
        }
      }
    }

    // 아직 수집 진행 중인 활성 세션 스냅샷 반환
    if (this.activeIncidents.has(normTraceId)) {
      const s = this.activeIncidents.get(normTraceId);
      const timeline = [...s.snapshotPre, s.incidentMarker, ...s.postLogs];
      return {
        trace_id: normTraceId,
        reason: s.reason,
        status: 'RECORDING_POST_BUFFER',
        triggered_at: new Date(s.triggeredAt).toISOString(),
        pre_log_count: s.snapshotPre.length,
        current_post_count: s.postLogs.length,
        total_log_count: timeline.length,
        timeline: timeline
      };
    }

    return null;
  }

  /**
   * 디스크 또는 메모리에서 가장 최근의 캡슐 인출
   * options.force_ring_buffer: true 인 경우 디스크 검사 없이 즉시 현재 링 버퍼 스냅샷 반환
   */
  getLatestCapsule(options = {}) {
    options = (options && typeof options === 'object') ? options : {};
    if (options.force_ring_buffer || options.live_buffer) {
      return {
        trace_id: `RING_BUFFER_SNAPSHOT_${Date.now()}`,
        status: 'REALTIME_BUFFER_SNAPSHOT',
        timestamp: new Date().toISOString(),
        total_log_count: this.ringBuffer.length,
        timeline: [...this.ringBuffer]
      };
    }

    try {
      if (fs.existsSync(INCIDENTS_DIR)) {
        const files = fs.readdirSync(INCIDENTS_DIR)
          .filter(f => f.startsWith('TIMELINE_') && (f.endsWith('.json') || f.endsWith('.jsonl')))
          .map(f => {
            const p = path.join(INCIDENTS_DIR, f);
            try {
              const stat = fs.statSync(p);
              return { name: f, path: p, mtimeMs: stat.mtimeMs };
            } catch (statErr) {
              console.error(`[TimelineRecorder] Could not stat ${p}:`, statErr.message);
              return null;
            }
          })
          .filter(Boolean)
          .sort((a, b) => b.mtimeMs - a.mtimeMs);

        if (files.length > 0) {
          for (const file of files) {
            const cleanTraceId = file.name.replace(/^TIMELINE_/, '').replace(/\.(json|jsonl)$/, '');
            const parsed = this.getCapsuleByTraceId(cleanTraceId);
            if (parsed) return parsed;
          }
        }
      }
    } catch (err) {
      console.error(`[TimelineRecorder] ❌ Error finding latest capsule on disk:`, err.message);
    }

    // 활성 인시던트 세션 존재 시 해당 세션 반환
    if (this.activeIncidents.size > 0) {
      const activeEntries = Array.from(this.activeIncidents.values());
      const latestSession = activeEntries[activeEntries.length - 1];
      const timeline = [...latestSession.snapshotPre, latestSession.incidentMarker, ...latestSession.postLogs];
      return {
        trace_id: latestSession.traceId,
        reason: latestSession.reason,
        status: 'RECORDING_POST_BUFFER',
        triggered_at: new Date(latestSession.triggeredAt).toISOString(),
        pre_log_count: latestSession.snapshotPre.length,
        current_post_count: latestSession.postLogs.length,
        total_log_count: timeline.length,
        timeline: timeline
      };
    }

    // 디스크 파일 및 활성 세션이 없을 경우 실시간 메모리 링 버퍼 덤프
    return {
      trace_id: `RING_BUFFER_SNAPSHOT_${Date.now()}`,
      status: 'REALTIME_BUFFER_SNAPSHOT',
      timestamp: new Date().toISOString(),
      total_log_count: this.ringBuffer.length,
      timeline: [...this.ringBuffer]
    };
  }

  /**
   * 하위 호환 캡슐 인출 메서드
   */
  getCapsule(traceId) {
    return this.getCapsuleByTraceId(traceId);
  }
}

// Global Singleton Instance
const globalRecorder = new TimelineRecorder();

// Standalone Helper Functions
function getLatestCapsule(options) {
  return globalRecorder.getLatestCapsule(options);
}

function getCapsuleByTraceId(traceId) {
  return globalRecorder.getCapsuleByTraceId(traceId);
}

function triggerIncident(traceId, reason, postWindowMs) {
  return globalRecorder.triggerIncident(traceId, reason, postWindowMs);
}

function triggerBlackbox(traceId, reason, postWindowMs) {
  return globalRecorder.triggerBlackbox(traceId, reason, postWindowMs);
}

function flushIncidentCapsule(traceId) {
  return globalRecorder.flushIncidentCapsule(traceId);
}

function pushLog(level, topic, message, details) {
  return globalRecorder.pushLog(level, topic, message, details);
}

module.exports = {
  TimelineRecorder,
  timelineRecorder: globalRecorder,
  getLatestCapsule,
  getCapsuleByTraceId,
  triggerIncident,
  triggerBlackbox,
  flushIncidentCapsule,
  pushLog
};
