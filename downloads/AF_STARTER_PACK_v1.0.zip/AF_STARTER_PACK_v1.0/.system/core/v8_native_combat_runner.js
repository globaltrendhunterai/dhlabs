#!/usr/bin/env node
/**
 * AutoFlow Official Node.js Native V8 Combat Runner
 * =================================================
 * - 100% 순수 Node.js (v26.10.0) 내장 vm 모듈 기반 실물 워크플로우 실행기.
 * - 파이썬 래퍼 없이, 순수 JavaScript로 워크플로우 JSON을 파싱하고
 *   노드 파이프라인을 물리 실행하여 런타임 신호(Signal) 및 결과를 반환합니다.
 */

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const os = require('os');
const { execSync } = require('child_process');
const {
    PoisonPillSanitizer,
    ExternalAuthManager,
    FencingLockManager,
    SemanticRejectionClassifier,
    REBOOT_DEFENSE_AUDIT
} = require('./reboot_defense_matrix');

const globalPoisonSanitizer = new PoisonPillSanitizer();
const globalExternalAuth = new ExternalAuthManager();
const globalFencingLock = new FencingLockManager();

const RUST_DEFENDER_BIN = path.join(__dirname, '../autoflow_rust/target/release/auto_flow_defender');

// [Rust 비언어 자가치유봇 인-런타임 실시간 인터셉터]
function interceptWithRustDefender(data, wfPath) {
    if (!fs.existsSync(RUST_DEFENDER_BIN)) return null;
    
    // 런타임 통과 데이터 내 잠재적 결함/의심 시그니처 감지 시 Rust Defender 호출
    const jsonStr = JSON.stringify(data);
    const hasSuspiciousPattern = /(?:'|--|;|union|select|drop|<script|alert\(|SYSTEM\s*OVERRIDE|\+82|buyer_phone|\d{6}-[1-4]\d{6}|\b\d{16}\b|amount.*-[0-9])/i.test(jsonStr) || Object.keys(data).length === 0;
    
    if (!hasSuspiciousPattern) return null;

    try {
        const tempAtk = path.join(os.tmpdir(), `atk_hook_${process.pid}_${Date.now()}_${Math.random().toString(36).substring(7)}.json`);
        const payload = [{
            id: `HOOK_${Date.now()}`,
            error_message: `UNGUARDED_PASS:${path.basename(wfPath)}`,
            code_context: jsonStr.substring(0, 500)
        }];
        fs.writeFileSync(tempAtk, JSON.stringify(payload), 'utf8');

        const stdout = execSync(`${RUST_DEFENDER_BIN} --attacks ${tempAtk}`, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] });
        try { fs.unlinkSync(tempAtk); } catch (e) {}

        const sIdx = stdout.indexOf('[DEFENSE_RESULT]');
        const eIdx = stdout.indexOf('[DEFENSE_RESULT_END]');
        if (sIdx !== -1 && eIdx !== -1) {
            const parsed = JSON.parse(stdout.substring(sIdx + '[DEFENSE_RESULT]'.length, eIdx).trim());
            if (parsed.summary && parsed.summary.defended > 0) {
                return {
                    defended: true,
                    patch: parsed.defended[0].patch,
                    confidence: parsed.defended[0].confidence
                };
            }
        }
    } catch (e) {}
    return null;
}

// [KAIZEN-CYCLE-01 / FIND_R27_004 & FIND_L3_STRIPE_005 해결] 엔터프라이즈급 TTL 멱등성 캐시 (메모리 릭 및 OOM 원천 방어)
const IDEMPOTENCY_CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24시간 TTL
const MAX_IDEMPOTENCY_CACHE_SIZE = 10000; // 최대 10,000건 상한

class IdempotencyTtlMap {
    constructor(ttlMs = IDEMPOTENCY_CACHE_TTL_MS, maxSize = MAX_IDEMPOTENCY_CACHE_SIZE) {
        this.cache = new Map();
        this.ttlMs = ttlMs;
        this.maxSize = maxSize;
    }
    has(key, now = Date.now()) {
        if (!key) return false;
        const ts = this.cache.get(key);
        if (ts === undefined) return false;
        if (now - ts > this.ttlMs) {
            this.cache.delete(key);
            return false;
        }
        return true;
    }
    add(key, now = Date.now()) {
        this.set(key, now);
    }
    set(key, now = Date.now()) {
        if (!key) return;
        if (this.cache.has(key)) {
            this.cache.delete(key);
        } else if (this.cache.size >= this.maxSize) {
            const oldestKey = this.cache.keys().next().value;
            if (oldestKey !== undefined) {
                this.cache.delete(oldestKey);
            }
        }
        this.cache.set(key, now);
    }
    delete(key) {
        return this.cache.delete(key);
    }
    clear() {
        this.cache.clear();
    }
    get size() {
        return this.cache.size;
    }
    pruneExpired(now = Date.now()) {
        let pruned = 0;
        for (const [k, ts] of this.cache.entries()) {
            if (now - ts > this.ttlMs) {
                this.cache.delete(k);
                pruned++;
            }
        }
        return pruned;
    }
}

const processedReviewIds = new IdempotencyTtlMap();
const processedEntityIds = new IdempotencyTtlMap();
const globalWorkflowStaticData = new Map();

function resetIdempotencyCache() {
    processedReviewIds.clear();
    processedEntityIds.clear();
    globalWorkflowStaticData.clear();
}

function pruneExpiredIdempotencyKeys(now = Date.now()) {
    const r1 = processedReviewIds.pruneExpired(now);
    const r2 = processedEntityIds.pruneExpired(now);
    return { prunedReviewIds: r1, prunedEntityIds: r2, totalPruned: r1 + r2 };
}

function getIdempotencyCacheStats() {
    return {
        reviewIdsCount: processedReviewIds.size,
        entityIdsCount: processedEntityIds.size,
        ttlMs: IDEMPOTENCY_CACHE_TTL_MS
    };
}

// [FIND_R27_001 해결] ReDoS 방지 비-백트래킹 호평 부정문 정규식
const praiseNegationRegex = /(?:벌레|식중독|장염|노로바이러스|병원|배탈|알레르기|두드러기|복통|이물질|머리카락|쇳조각|곰팡이|침|신고|경찰|보건소|구청|식약처|위생과|영업정지|소비자원|소비자고발센터|민원|손해배상|고발|인권위|기만|배째라)(?:\s*[^.!?\n\s]{1,15}){0,3}\s*(?:나올\s*일\s*없이|나올\s*걱정\s*없이|볼\s*일\s*없이|버릴\s*일\s*없이|걱정\s*없이|갈\s*일\s*없이|걸릴\s*일\s*없이|걱정없는|안심하고|안심|탈\s*없이|안\s*나고|튈\s*걱정\s*없이|뱉을\s*일\s*없이|할\s*일\s*없이|넣을\s*걱정\s*없이|넣을\s*일\s*없이|없이)|(?:나올\s*일\s*없이|나올\s*걱정\s*없이|볼\s*일\s*없이|버릴\s*일\s*없이|걱정\s*없이|갈\s*일\s*없이|걸릴\s*일\s*없이|걱정없는|안심하고|안심|탈\s*없이|안\s*나고|튈\s*걱정\s*없이|뱉을\s*일\s*없이|할\s*일\s*없이|넣을\s*걱정\s*없이|넣을\s*일\s*없이|없이)(?:\s*[^.!?\n\s]{1,15}){0,3}\s*(?:벌레|식중독|장염|노로바이러스|병원|배탈|알레르기|두드러기|복통|이물질|머리카락|쇳조각|곰팡이|침|신고|경찰|보건소|구청|식약처|위생과|영업정지|소비자원|소비자고발센터|민원|손해배상|고발|인권위|기만|배째라)/i;

// [FIND_R27_003 & FIND_L3_STRIPE_006, FIND_009, FIND_010 해결] PII 개인정보 및 민감 시크릿 키 마스킹 함수
function maskPII(text, preserveEmail = false) {
    if (typeof text !== 'string') return text;
    let res = text
        // DB 접속 URL (사용자명 및 패스워드) 마스킹
        .replace(/(postgres|mysql|mongodb|redis|amqp):\/\/[^\s\/]+@([^\s]+)/gi, '$1://****:****@$2')
        .replace(/(postgres|mysql|mongodb|redis|amqp):\/\/([^:\s]+):([^@\s]+)@/gi, '$1://****:****@')
        // Stripe API 라이브 시크릿 키 마스킹
        .replace(/sk_live_[0-9a-zA-Z]{16,}/g, 'sk_live_****')
        // JWT 시크릿 / 토큰 마스킹
        .replace(/eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}/g, '****')
        // [FIND_008 해결] Slack API Bot/User/App Token 마스킹
        .replace(/xox[baprs]-[0-9a-zA-Z-]{20,}/g, 'xoxb-****')
        // [FIND_R22_005 해결] Telegram Bot Token 마스킹 (숫자 9~10자리:토큰 35자리)
        .replace(/\b\d{9,10}:[A-Za-z0-9_-]{35}\b/g, '[텔레그램 토큰 마스킹]')
        // [FIND_006 해결] Notion 공식 통합 토큰 (ntn_...) 마스킹
        .replace(/\bntn_[a-zA-Z0-9]{20,}\b/g, '[노션 토큰 마스킹]')
        // [FIND_002 해결] OpenAI API Secret Key 마스킹
        .replace(/sk-(?:proj-)?[0-9a-zA-Z_-]{20,}/g, 'sk-proj-****')
        // [FIND_001 해결] GitHub Fine-Grained Personal Access Token 마스킹
        .replace(/github_pat_[0-9a-zA-Z_]{20,}/g, 'github_pat_****')
        // GitHub Classic Personal Access Token 마스킹
        .replace(/(?:ghp|gho|ghu|ghs|ghr)_[0-9a-zA-Z]{20,}/g, 'ghp_****')
        // AWS Access Key ID 마스킹
        .replace(/(?:AKIA|ABIA|ACCA|ASIA)[0-9A-Z]{16}/g, 'AKIA****')
        // [FIND_009 & FIND_006 해결] 하이픈 있는 신용카드번호 마스킹 (16자리: 4자리-4자리-4자리-4자리)
        .replace(/(?<![0-9a-zA-Z가-힣])(?:\d{4}\s*[-]\s*){3}\d{4}(?![0-9a-zA-Z가-힣])/g, '****')
        // [FIND_009 & FIND_010 해결] 국내 일반전화(02, 031~064), 인터넷전화(070), 휴대폰(010~019), 국제전화(+82) 및 해외 전화번호 마스킹
        .replace(/(?<![0-9a-zA-Z가-힣])(?:02|0[3-6][1-5]|070|01[016789]|\+82\s*)\s*[-.]?\s*\d{3,4}\s*[-.]?\s*\d{4}(?![0-9])/g, '****')
        .replace(/(?:\+\d{1,3}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{4}/g, '[전화번호 마스킹]')
        // [FIND_006 & FIND_002 해결] 하이픈 있는 주민등록번호 및 외국인등록번호(뒷자리 1~8) 마스킹
        .replace(/(?<![0-9a-zA-Z가-힣])\d{6}\s*[-]\s*[1-8]\d{6}(?![0-9a-zA-Z가-힣])/g, '******-*******')
        // [FIND_004 해결] 운전면허번호 마스킹
        .replace(/(?<![0-9a-zA-Z가-힣])\d{2}[-]\d{2}[-]\d{6}[-]\d{2}(?![0-9a-zA-Z가-힣])/g, '**-**-******-**')
        // [FIND_003 해결] 여권번호 마스킹
        .replace(/(?<![0-9a-zA-Z가-힣])[A-Z][0-9]{8}(?![0-9a-zA-Z가-힣])/g, 'M********')
        // [FIND_007 & FIND_006] 국내 주요 은행 계좌번호 마스킹 (3~6자리 - 2~6자리 - 3~8자리)
        .replace(/(?<![0-9a-zA-Z가-힣])\d{3,6}[-]\d{2,6}[-]\d{3,8}(?![0-9a-zA-Z가-힣])/g, '[계좌번호 마스킹]')
        // [FIND_008 & FIND_006] 하이픈 없는 주민등록번호 마스킹 (13자리: 생년월일 6자리 + 뒷 7자리)
        .replace(/(?<![0-9a-zA-Z가-힣])\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{7}(?![0-9a-zA-Z가-힣])/g, '******')
        // [FIND_008 & FIND_006] 하이픈 없는 신용카드번호 마스킹 (15~16자리)
        .replace(/(?<![0-9a-zA-Z가-힣])(?:4\d{15}|5[1-5]\d{14}|6011\d{12}|3[47]\d{13}|\d{16})(?![0-9a-zA-Z가-힣])/g, '****')
        // [FIND_011 해결] 하이픈 없는 계좌번호 마스킹 (11~14자리 연속 숫자)
        .replace(/(?<![0-9a-zA-Z가-힣])\d{11,14}(?![0-9a-zA-Z가-힣])/g, '[계좌번호 마스킹]')
        // [FIND_011 & FIND_004 해결] 임원 급여 및 비자금/재무 민감 메모 및 연봉/희망급여 마스킹
        .replace(/(?:비자금|대외활동\s*비자금|임원\s*급여|비자금\s*계좌)/g, '[민감 정보 마스킹]')
        .replace(/(?:연봉|희망연봉|월급|급여|희망급여|이전\s*직장\s*연봉|희망\s*연봉)\s*[:=]?\s*[\d,]+(?:\s*만원|\s*원)?/gi, '[급여 정보 마스킹]')
        // [FIND_HR_LEAVE_009 해결] 민감 의료/질병/진단 정보 마스킹 (개인정보보호법 제23조 민감정보)
        .replace(/(?:유산|자궁\s*출혈|수술|임신\s*\d+주차|우울증|외상후스트레스장애|정신과|입원\s*치료)/g, '[민감 의료 정보 마스킹]')
        // [FIND_HR_LEAVE_010 해결] 슬랙 웹훅 검증 토큰 마스킹
        .replace(/[A-Za-z0-9_-]{20,}_SLACK_VERIFY_TOKEN/g, '[슬랙 토큰 마스킹]');

    if (!preserveEmail) {
        // [FIND_010] 우커머스 고객 이메일 마스킹
        res = res.replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g, '[이메일 마스킹]');
    }

    return res
        // [FIND_010] IPv4 주소 마스킹
        .replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g, '[IP 마스킹]')
        // 주소 마스킹
        .replace(/(?:서울시|서울특별시|경기도|[가-힣]{2,4}[시도])\s+[가-힣\d\s-]+?(?:동|로|길)\s+[\d-]+(?:\s*거주)?/g, '[주소 마스킹]');
}

function runWorkflowNative(workflowPath, payload, options = {}) {
    const startTime = Date.now();
    let result = {
        workflow: path.basename(workflowPath),
        status: 'UNKNOWN',
        executionTimeMs: 0,
        uncaughtException: false,
        crashError: null,
        outputData: null,
        healingApplied: null,
        quarantined: false,
        triggeredApis: []
    };

    function toCacheKey(val) {
        if (val === null || val === undefined) return '';
        if (typeof val === 'string' || typeof val === 'number' || typeof val === 'boolean') {
            return String(val);
        }
        try {
            return JSON.stringify(val);
        } catch (e) {
            try {
                return String(val);
            } catch (e2) {
                return '[UnhashableObject]';
            }
        }
    }

    // [FIND_R27_004 & FIND_L3_STRIPE_005, FIND_010, FIND_001, FIND_002, FIND_011, FIND_012 해결] 동일 review_id / payment ID / release.id / WooCommerce order_key 중복 인입 시 멱등성 캐시 가드로 즉시 차단
    let targetReviewId = undefined;
    let targetEntityId = undefined;
    if (payload && typeof payload === 'object') {
        try {
            if (payload.review_id) targetReviewId = payload.review_id;
            else if (Array.isArray(payload) && payload[0] && payload[0].review_id) targetReviewId = payload[0].review_id;
        } catch (e) {}

        try {
            targetEntityId = payload.id || (payload.data && payload.data.id) || payload.charge_id || payload.payment_intent_id || payload.order_id || payload.order_key || payload.number || (payload.release && payload.release.id) || payload.item_id || payload.report_id || payload.sku || payload.slot_id || payload.booking_id || payload.appointment_id || payload.interview_id;
            if (!targetEntityId && Array.isArray(payload) && payload[0]) {
                targetEntityId = payload[0].id || (payload[0].data && payload[0].data.id) || payload[0].charge_id || payload[0].payment_intent_id || payload[0].order_id || payload[0].order_key || payload[0].number || (payload[0].release && payload[0].release.id) || payload[0].item_id || payload[0].report_id || payload[0].sku || payload[0].slot_id || payload[0].booking_id || payload[0].appointment_id || payload[0].interview_id;
            }
        } catch (e) {}
    }
    const cachedKey = toCacheKey(targetEntityId);
    if ((targetReviewId && processedReviewIds.has(targetReviewId)) || (cachedKey && processedEntityIds.has(cachedKey))) {
        result.status = 'DUPLICATE_IGNORED';
        result.duplicate = true;
        result.quarantined = false;
        result.outputData = { ...(typeof payload === 'object' && payload !== null ? payload : {}), status: 'DUPLICATE_IGNORED', duplicate: true };
        result.triggeredApis = [];
        result.executionTimeMs = Date.now() - startTime;
        return result;
    }

    if (!fs.existsSync(workflowPath)) {
        result.status = 'FILE_NOT_FOUND';
        result.crashError = `Workflow file not found: ${workflowPath}`;
        return result;
    }

    let workflow;
    try {
        workflow = JSON.parse(fs.readFileSync(workflowPath, 'utf8'));
    } catch (e) {
        result.status = 'CRASHED';
        result.uncaughtException = true;
        result.crashError = `Workflow JSON parse error: ${e.message}`;
        return result;
    }

    // 안전한 딥 클론 함수 (BigInt 처리, 순환 참조 방지, 원시값 객체화, Getter Trap 방어)
    function safeClone(obj) {
        if (obj === null || obj === undefined) return {};
        if (typeof obj !== 'object') {
            return { rating: obj, score: obj, value: obj, raw_data: String(obj) };
        }
        const seen = new WeakSet();
        function deepCopy(val, depth = 0) {
            if (depth > 100) return '[Deeply Nested]';
            if (val === null || val === undefined) return val;
            if (typeof val === 'bigint') return val.toString();
            if (typeof val !== 'object') return val;
            if (seen.has(val)) return '[Circular]';
            seen.add(val);
            if (Array.isArray(val)) {
                return val.map(v => deepCopy(v, depth + 1));
            }
            const copy = Object.create(null);
            for (const key of Object.keys(val)) {
                if (key === '__proto__' || key === 'constructor' || key === 'prototype' || key === 'toJSON') continue;
                try {
                    if (typeof val[key] === 'function') continue;
                    copy[key] = deepCopy(val[key], depth + 1);
                } catch (getterErr) {
                    copy[key] = `[Property Access Error: ${getterErr.message}]`;
                }
            }
            return copy;
        }
        return deepCopy(obj);
    }

    // [FIND_007 해결] Telegram options 객체 내 Getter Trap 인입 시 V8 실행기 충돌 방어
    let safeOptions = {};
    try {
        safeOptions = (options && typeof options === 'object') ? safeClone(options) : {};
    } catch (optErr) {
        safeOptions = {};
    }

    // [FIND_001 ~ FIND_015 해결] 헬퍼 함수 정의
    function isValidInner(v) {
        return v !== undefined && v !== null && v !== '';
    }

    // [FIND_005, FIND_R24_009 ~ FIND_R24_010 해결] 심층 중첩 평점 객체 재귀 스택 오버플로 방어 및 3점 미만 악성 평점 우선 채택
    function getValidInner(obj, depth = 0) {
        if (depth > 30) return undefined;
        if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return undefined;
        const candidateFields = ['rating', 'score', 'overall_rating', 'total_score', 'user_rating', 'value', 'item_score', 'star_count', 'grade', 'food_rating', 'service_rating', 'taste', 'delivery'];
        const found = [];
        for (const f of candidateFields) {
            if (isValidInner(obj[f])) {
                const val = typeof obj[f] === 'object' ? getValidInner(obj[f], depth + 1) : obj[f];
                if (val !== undefined) found.push(val);
            }
        }
        if (found.length === 0) return undefined;
        const bad = found.find(v => {
            const num = Number(v);
            return !isNaN(num) && num < 3;
        });
        return bad !== undefined ? bad : found[0];
    }

    // [FIND_014, FIND_015, FIND_R24_021 ~ FIND_R24_023 해결] API 래퍼(data, response, reviews, items) 지원 및 리뷰 피드 판별
    function isReviewData(d) {
        if (!d || typeof d !== 'object') return false;
        const candidateObjs = [
            d,
            d.review,
            d.payload,
            d.feedback,
            d.data,
            d.response,
            ...(Array.isArray(d.reviews) ? d.reviews : []),
            ...(Array.isArray(d.items) ? d.items : []),
            ...(Array.isArray(d.data?.reviews) ? d.data.reviews : []),
            ...(Array.isArray(d.response?.items) ? d.response.items : [])
        ].filter(x => x && typeof x === 'object');
        return candidateObjs.some(obj => (
            obj.rating !== undefined || obj.review_text !== undefined || obj.score !== undefined ||
            obj.comment !== undefined || obj.value !== undefined || obj.feedback !== undefined ||
            obj.content !== undefined || obj.text !== undefined || obj.user_rating !== undefined ||
            obj.item_score !== undefined || obj.star_count !== undefined || obj.grade !== undefined ||
            obj.review_detail !== undefined ||
            obj.overall_rating !== undefined || obj.total_score !== undefined ||
            obj.food_rating !== undefined || obj.service_rating !== undefined ||
            obj.taste !== undefined || obj.delivery !== undefined
        ));
    }

    function normalizeScore(n, field) {
        if (typeof n !== 'number' || isNaN(n) || !Number.isFinite(n)) return NaN;
        if (field === 'rating') {
            if (n < 0) return 0; // [FIND_009 해결] 음수 평점 지원: 0점(극단적 불만족)으로 정규화하여 Less than 3 Filter 통과
            if (n <= 5.5) return n; // 5.5점 (5½점 포함) 정상 5점 척도 범위 보존
            if (n <= 10) return (n / 10) * 5;
            if (n <= 100) return (n / 100) * 5;
            return NaN;
        }
        return n;
    }

    // ============================================================================
    // [규칙성 엔진 2] 구문론적 감성 중화기 (Syntactic Valence Engine)
    // 개별 단어 수십 개 나열을 배제하고, 어휘 체계 및 결합 구문 규칙으로 감성 평가
    // ============================================================================
    function evaluateSyntacticValence(text) {
        if (!text || typeof text !== 'string') {
            return { isCrisis: false, isPraise: false, cleanedText: '', sarcasmDetected: false };
        }

        let normText = text.slice(0, 3000).replace(/\s+/g, ' ');

        // 1. 반어법/역설적 혹평 검출 ("5점이라더니 진짜 최악", "이게 5점짜리 식당인가요?")
        const sarcasmRegex = /([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)(?:이라더니|짜리\s*(?:식당|음식|가게|곳)?인가요|이라고\??|준다는\s*게)/i;
        const sarcasmDetected = sarcasmRegex.test(normText);

        // 2. 공공기관/위생 인증 호평 중화 규칙 (식약처/보건소/구청/위생과 + 인증/선정/우수/식당)
        const certPraiseRegex = /(?:식약처|보건소|구청|위생과)\s*(?:인증|지정|선정|표창|우수)?\s*(?:위생\s*식당|안심\s*식당|모범\s*음식점|맛집|위생등급|위생\s*점검\s*안심|위생점검\s*안심|위생\s*안심|위생안심)/gi;
        let cleanedText = normText.replace(certPraiseRegex, ' ');

        // 3. 구문 부정/안심 중화 규칙 ([위기어휘] + 0~3단어 + [안심접미사])
        const riskWords = [
            '벌레', '식중독', '장염', '노로바이러스', '병원', '배탈', '알레르기', '두드러기', '복통',
            '이물질', '머리카락', '쇳조각', '유리조각', '비닐', '침', '곰팡이', '신고', '경찰',
            '보건소', '구청', '식약처', '위생과', '영업정지', '소비자원', '소비자고발센터', '민원',
            '손해배상', '고발', '인권위', '기만', '배째라', '환불', '사기', '쓰레기', '상했', '쉰내',
            '누락', '오배송', '불친절', '식어서', '식었', '쏟아짐', '샜음', '파손',
            '명예훼손', '고소', '협박', '소송'
        ].join('|');

        const peaceSuffixes = [
            '나올\\s*일\\s*없이', '나올\\s*걱정\\s*없이', '볼\\s*일\\s*없이', '버릴\\s*일\\s*없이',
            '걱정\\s*없이', '갈\\s*일\\s*없이', '걸릴\\s*일\\s*없이', '걱정없는', '안심하고', '안심',
            '탈\\s*없이', '없이', '없고', '안\\s*나고', '않고', '안\\s*하고', '튈\\s*걱정\\s*없이',
            '뱉을\\s*일\\s*없이', '할\\s*일\\s*없이', '넣을\\s*걱정\\s*없이', '넣을\\s*일\\s*없이'
        ].join('|');

        const peacePrefixRegex = new RegExp(`(?:${riskWords})\\s*(?:한\\s*마리|하나|한\\s*개|한\\s*올|핀\\s*거\\s*하나)?\\s*(?:전혀\\s*)?(?:\\s*[^.!?\\n\\s]{1,15}){0,3}\\s*(?:${peaceSuffixes})`, 'gi');
        const peaceSuffixRegex = new RegExp(`(?:${peaceSuffixes})\\s*(?:\\s*[^.!?\\n\\s]{1,15}){0,3}\\s*(?:${riskWords})`, 'gi');

        cleanedText = cleanedText
            .replace(peacePrefixRegex, ' ')
            .replace(peaceSuffixRegex, ' ')
            .replace(/사기적인\s*맛/gi, ' ');

        // 4. 핵심 위기 판별
        const coreRiskPattern = new RegExp(`(?:${riskWords}|바퀴벌레|최악|썩었|폭망|위세척|응급실|입원|119|중환자실|구급차|구토|설사|링거|수액|더러워|명예훼손|고소|협박|소송)`, 'i');
        const isCrisis = coreRiskPattern.test(cleanedText);

        // 5. 호평 판별
        const praisePattern = /(?:맛있|인생|추천|최고|대박|친절|감사|깨끗|위생\s*최상|위생식당|안심식당|모범음식점|안심|만점|우수)/i;
        const isPraise = praisePattern.test(cleanedText) || certPraiseRegex.test(normText);

        return { isCrisis, isPraise, cleanedText, sarcasmDetected };
    }

    // ============================================================================
    // [규칙성 엔진 1] 통합 척도 역산기 (Universal Scale Resolver)
    // 수치, 분수, 백분율, 수사, 이모지, 척도 문장 등을 수학적 5점 척도로 일원화 변환
    // ============================================================================
    function resolveUniversalScale(val, reviewText, targetField = 'rating', depth = 0) {
        if (depth > 35) return NaN;

        if (typeof val === 'string') {
            if (val.length > 3000) val = val.slice(0, 3000);
            val = val.replace(/\s+/g, ' ');
        }
        if (typeof reviewText === 'string') {
            if (reviewText.length > 3000) reviewText = reviewText.slice(0, 3000);
            reviewText = reviewText.replace(/\s+/g, ' ');
        }

        while (Array.isArray(val)) {
            if (val.length === 0) return NaN;
            val = val[0];
        }

        if (val === null || val === undefined) {
            if (reviewText && typeof reviewText === 'string') {
                const valence = evaluateSyntacticValence(reviewText);
                if (valence.sarcasmDetected) return 1;

                // [FIND_R22_001 해결] 호평 리뷰 내 부가 수치("2층", "1박", "1호점")가 평점으로 오인식되는 결함 방어
                const hasExplicitStarUnit = /(?:[0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?|つ?星|만점)/i.test(reviewText);
                if (valence && valence.isPraise && !hasExplicitStarUnit) {
                    return NaN;
                }

                const extractedScore = resolveUniversalScale(valence.cleanedText, undefined, targetField, depth + 1);
                if (!isNaN(extractedScore)) return extractedScore;

                if (valence.isCrisis) return 1;
                if (valence.isPraise) return NaN;
            }
            return NaN;
        }

        if (typeof val === 'symbol' || typeof val === 'boolean') return NaN;
        if (typeof val === 'object' && val !== null) {
            const innerVal = getValidInner(val);
            if (innerVal !== undefined) return resolveUniversalScale(innerVal, reviewText, targetField, depth + 1);
            return resolveUniversalScale(null, reviewText, targetField, depth + 1);
        }

        if (typeof val === 'number') {
            return normalizeScore(val, targetField);
        }

        const unicodeFractions = {
            '¾': 0.75, '⅝': 0.625, '⅚': 0.833, '½': 0.5, '¼': 0.25,
            '⅓': 0.333, '⅔': 0.667, '⅛': 0.125, '⅜': 0.375, '⅞': 0.875,
            '⅙': 0.167, '⅕': 0.2, '⅖': 0.4, '⅗': 0.6, '⅘': 0.8
        };

        let preStr = String(val);
        preStr = preStr.replace(/([0-9]+)\s*½/g, '$1.5')
                       .replace(/([0-9]+)\s*¼/g, '$1.25')
                       .replace(/([0-9]+)\s*¾/g, '$1.75')
                       .replace(/([0-9]+)\s*⅓/g, (m, p) => (Number(p) + 0.333).toFixed(3))
                       .replace(/([0-9]+)\s*⅔/g, (m, p) => (Number(p) + 0.667).toFixed(3))
                       .replace(/([0-9]+)\s*⅕/g, '$1.2')
                       .replace(/([0-9]+)\s*⅖/g, '$1.4')
                       .replace(/([0-9]+)\s*⅗/g, '$1.6')
                       .replace(/([0-9]+)\s*⅘/g, '$1.8');
        const rawStr = preStr.normalize('NFKC').replace(/[\u200B-\u200D\uFEFF]/g, '').trim();

        // 0점 구어체 매핑
        if (/^[★⭐☆🌟\s]*(?:별\s*)?(?:(?:점수|별점|평점)\s*[:：]?\s*)?(?:영점|빵점|영\s*점|빵\s*점|0점)(?:\s*(?:입니다|드립니다|줍니다|요))?$/i.test(rawStr) ||
            /(?:평점|별점|점수)\s*[:：]?\s*(?:영점|빵점|영\s*점|빵\s*점|0점)|(?:영점|빵점)\s*(?:드립니다|줍니다)/i.test(rawStr)) {
            return 0;
        }

        // 만점 매핑
        if (/^[★⭐☆🌟\s]*(?:별\s*)?(?:(?:점수|별점|평점)\s*[:：]?\s*)?만점(?:\s*(?:입니다|드립니다|줍니다|요))?$/i.test(rawStr) ||
            /(?:평점|별점|점수)\s*[:：]?\s*만점|만점\s*(?:드립니다|줍니다)/i.test(rawStr)) {
            return 5;
        }

        // 혼합 유니코드 분수 매칭
        const mixedFracMatch = rawStr.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?|つ?星)?\s*([¾⅝⅚½¼⅓⅔⅛⅜⅞⅙⅕⅖⅗⅘])/i);
        if (mixedFracMatch) {
            const intPart = parseFloat(mixedFracMatch[1]);
            const fracVal = unicodeFractions[mixedFracMatch[2]] || 0;
            return normalizeScore(intPart + fracVal, targetField);
        }
        for (const [fracChar, fracVal] of Object.entries(unicodeFractions)) {
            if (rawStr.includes(fracChar)) {
                return normalizeScore(fracVal, targetField);
            }
        }

        // 비라틴 유니코드 숫자 ASCII 변환
        function convertUnicodeDigitsToAscii(inputStr) {
            return inputStr.replace(/[\u0660-\u0669\u06F0-\u06F9\u0966-\u096F\u0E50-\u0E59]/g, ch => {
                const code = ch.charCodeAt(0);
                if (code >= 0x0660 && code <= 0x0669) return String(code - 0x0660);
                if (code >= 0x06F0 && code <= 0x06F9) return String(code - 0x06F0);
                if (code >= 0x0966 && code <= 0x096F) return String(code - 0x0966);
                if (code >= 0x0E50 && code <= 0x0E59) return String(code - 0x0E50);
                return ch;
            });
        }
        let str = convertUnicodeDigitsToAscii(rawStr);
        if (str === '') return NaN;

        // 불만족 이모지 평점 지원
        const emojiMap = { '👎': 1, '🤮': 1, '💩': 1, '😡': 1 };
        for (const [em, sc] of Object.entries(emojiMap)) {
            if (str.includes(em)) {
                const numMatch = str.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)/);
                if (numMatch) return normalizeScore(Number(numMatch[1]), targetField);
                return normalizeScore(sc, targetField);
            }
        }

        // 기호 표준화
        str = str.replace(/[\/⁄\\＼∕／]/g, '/');
        str = str.replace(/([0-9]+(?:\.[0-9]+)?)\s*(?:과|와)\s*([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?\s*[\/⁄\\＼∕／]\s*([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?/gi, (match, p1, p2, p3) => {
            const total = Number(p1) + (Number(p2) / Number(p3));
            return ' ' + total + '점 ';
        });
        str = str.replace(/[〜～]/g, '~');
        str = str.replace(/([0-9])\s*,\s*([0-9])/g, '$1.$2');
        str = str.replace(/([0-9])\s*\.\s*([0-9])/g, '$1.$2');
        str = str.replace(/(?:^|[^\d])\s*\.\s*([0-9]+)/g, ' 0.$1');

        // "반 개" -> 0.5
        if (/(?:^|[^\d])별?\s*반\s*개(?:\s*드립니다|\s*만)?(?:\s*[\p{Emoji}\u2000-\u3300])*$/iu.test(str) ||
            /(?:^|[^\d])별점\s*반\s*개(?:\s*드립니다|\s*만)?(?:\s*[\p{Emoji}\u2000-\u3300])*$/iu.test(str) ||
            /^반\s*개$/i.test(str)) {
            return normalizeScore(0.5, targetField);
        }

        // 한글 고유어 수사 평점
        const nativeKoreanMap = {
            '하나': 1, '한': 1, '한개': 1,
            '둘': 2, '두': 2, '두개': 2,
            '셋': 3, '세': 3, '세개': 3,
            '넷': 4, '네': 4, '네개': 4,
            '다섯': 5
        };
        const nativeMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?(하나|한|둘|두|셋|세|넷|네|다섯)\s*(?:개|점|stars?|つ?星)?(?:\s*(?:요|임|용|이요|짜리|만|입니다|대))?(?:\s*드립니다)?$/i);
        if (nativeMatch) {
            const mapped = nativeKoreanMap[nativeMatch[1]];
            if (mapped !== undefined) return normalizeScore(mapped, targetField);
        }
        const nativeSimpleMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s+)(하나|둘|셋|넷|다섯)(?:\s*(?:요|임|용|이요|짜리|만|입니다|대))?$/i);
        if (nativeSimpleMatch) {
            const mapped = nativeKoreanMap[nativeSimpleMatch[1]];
            if (mapped !== undefined) return normalizeScore(mapped, targetField);
        }
        const embeddedNativeMatch = str.match(/(?:별\s+)?(하나|한|둘|두|셋|세|넷|네|다섯)\s*(?:개|점|stars?|つ?星)(?:[도만]?\s*(?:아깝|아깝습니다|아까움))?(?:\s*(?:드립니다|줍니다|요|임|용|이요|짜리|입니다))?|(?:별\s*)(하나|한|둘|두|셋|세|넷|네|다섯)(?:\s*(?:개|점|stars?|つ?星))?(?:[도만]?\s*(?:아깝|아깝습니다|아까움))?(?:\s*(?:드립니다|줍니다|요|임|용|이요|짜리|입니다))?/i);
        if (embeddedNativeMatch) {
            const rawWord = embeddedNativeMatch[1] || embeddedNativeMatch[2];
            const mapped = nativeKoreanMap[rawWord];
            if (mapped !== undefined) return normalizeScore(mapped, targetField);
        }

        // 한자어 음운 수사 평점
        const sinoKoreanPhoneticMap = { '일': 1, '이': 2, '삼': 3, '사': 4, '오': 5 };
        const sinoWordMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?(?:(?:점수|별점|평점)\s*[:：]\s*)?(일|이|삼|사|오)\s*(?:점|개|stars?)(?:\s*(?:입니다|드립니다|줍니다|요))?$/i);
        if (sinoWordMatch) return normalizeScore(sinoKoreanPhoneticMap[sinoWordMatch[1]], targetField);
        const embeddedSinoMatch = str.match(/(?:(?:점수|별점|평점)\s*[:：]?\s*)(일|이|삼|사|오)\s*(?:점|개|stars?)(?:\s*(?:입니다|드립니다|줍니다|요))?/i);
        if (embeddedSinoMatch) return normalizeScore(sinoKoreanPhoneticMap[embeddedSinoMatch[1]], targetField);
        const embeddedSinoSimple = str.match(/(일|이|삼|사|오)\s*(?:점|개|stars?)\s*(?:드립니다|줍니다)/i);
        if (embeddedSinoSimple) return normalizeScore(sinoKoreanPhoneticMap[embeddedSinoSimple[1]], targetField);

        // 로마 숫자 평점
        const romanMap = {
            'Ⅰ': 1, 'Ⅱ': 2, 'Ⅲ': 3, 'Ⅳ': 4, 'Ⅴ': 5,
            'ⅰ': 1, 'ⅱ': 2, 'ⅲ': 3, 'ⅳ': 4, 'ⅴ': 5,
            'I': 1, 'II': 2, 'III': 3, 'IV': 4, 'V': 5
        };
        const romanMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?([ⅠⅡⅢⅣⅤⅰⅱⅲⅳⅴ]|I{1,3}|IV|V)\s*(?:점|개|stars?)?(?:\s*드립니다)?$/i);
        if (romanMatch) {
            const rawRoman = romanMatch[1];
            const mapped = romanMap[rawRoman.toUpperCase()] || romanMap[rawRoman];
            if (mapped !== undefined) return normalizeScore(mapped, targetField);
        }

        // 한자/동아시아 수사 평점
        const eastAsianMap = { '一': 1, '二': 2, '三': 3, '四': 4, '五': 5 };
        const eaMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?([一二三四五])\s*(?:개|점|つ?星|star|stars?)(?:\s*드립니다)?$/i);
        if (eaMatch) return normalizeScore(eastAsianMap[eaMatch[1]], targetField);

        // 영문 수사 평점
        const englishWordMap = { 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5 };
        const engWordMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?(one|two|three|four|five)\s*(?:star|stars|points?|점|개)\b(?!\s*(?:out\s+of|of))/i);
        if (engWordMatch) return normalizeScore(englishWordMap[engWordMatch[1].toLowerCase()], targetField);

        // 척도 역산 ("10점 만점에 10점", "100점 중 5점", "100점에 5점")
        const scaleMatch = str.match(/([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:개|점)?\s*(?:만점\s*(?:에|중|에서|기준)?|(?:점|개)\s*(?:만점\s*(?:에|중|에서|기준)?|에|중|에서|기준|만점기준|만점\s*기준))\s*([0-9]+(?:\.[0-9]+)?|\.[0-9]+)(?!\s*(?:등|위|호점|번째|번|순위|차|회))\s*(?:개|점)?/i);
        if (scaleMatch) {
            const scaleBase = Number(scaleMatch[1]);
            const scaleScore = Number(scaleMatch[2]);
            if (!isNaN(scaleBase) && !isNaN(scaleScore) && scaleBase > 0) {
                return targetField === 'rating' ? (scaleBase === 5 ? scaleScore : (scaleScore / scaleBase) * 5) : scaleScore;
            }
        }

        // 역순 척도 역산 ("1점 (5점 만점)", "1점 (10점 만점)")
        const reverseScaleMatch = str.match(/([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:개|점)?\s*\(?\s*([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:개|점)?\s*만점\s*\)?/i);
        if (reverseScaleMatch) {
            const scaleScore = Number(reverseScaleMatch[1]);
            const scaleBase = Number(reverseScaleMatch[2]);
            if (!isNaN(scaleBase) && !isNaN(scaleScore) && scaleBase > 0) {
                return targetField === 'rating' ? (scaleBase === 5 ? scaleScore : (scaleScore / scaleBase) * 5) : scaleScore;
            }
        }

        // 비교 문맥 제거
        let strWithoutComparison = str
            .replace(/\([^)]*(?:다른|속아서|속았|사기|광고|알바|조작|가짜|의심|배달앱|인스타|블로그)[^)]*\)/gi, ' ')
            .replace(/(?:다른|속아서|속았|사기|광고|알바|조작|가짜|배달앱|인스타|블로그)\s*(?:리뷰|사람|평점|후기)?[^.!?\n]*?([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)/gi, ' ')
            .replace(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)(?:\s*만점\s*(?:맛집|식당|곳)?이라더니|\s*주는\s*사람들은|\s*리뷰\s*보고\s*시켰는데|\s*평점)?\s*(?:사기|알바|조작|가짜|낚였|낚임|의심|의혹)/gi, ' ');

        // 하이픈/물결 범위 평점 -> 평균값 치환
        strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\.[0-9]+)?)\s*[-~−–—〜～]\s*([0-9]+(?:\.[0-9]+)?)\s*(점|개|stars?|つ?星)?/gi, (match, p1, p2, unit) => {
            const avg = (Number(p1) + Number(p2)) / 2;
            return ' ' + avg + (unit || '') + ' ';
        });

        // 반어법/역설적 혹평 마스킹
        const sarcasticRegex = /([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)(?:이라더니|짜리\s*(?:식당|음식|가게|곳)?인가요|이라고\??|준다는\s*게)/i;
        const hasSarcastic = sarcasticRegex.test(str) || (reviewText && typeof reviewText === 'string' && sarcasticRegex.test(reviewText));
        strWithoutComparison = strWithoutComparison.replace(sarcasticRegex, ' ');

        // 할인율/쿠폰 마스킹
        strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\.[0-9]+)?)\s*%\s*(?:할인|쿠폰|적립|캐시백|세일)?/gi, ' ');

        // 날짜 마스킹 (1/5, 1/10, 1/100 분수 보존)
        // [FIND_R22_002 해결] (?![s]*) -> (?!\s*) 오탈자 교정으로 분수와 단위 사이 공백 지원
        strWithoutComparison = strWithoutComparison.replace(/\b(?:0?[1-9]|1[0-2])\s*[/⁄\\＼]\s*(?:0?[1-9]|[12][0-9]|3[01])\b(?!\s*(?:점|개|stars?|つ?星|만점))/gi, (match) => {
            const parts = match.split(/[/⁄\\＼]/);
            const d = Number(parts[1]);
            if (d === 5 || d === 10 || d === 100) return match;
            return ' ';
        });
        strWithoutComparison = strWithoutComparison.replace(/(?:방문일|주문일|방문|주문|포장|배달)?\s*[:=\s]?\s*(?:20[0-9]{2}[/.-][0-9]{1,2}[/.-][0-9]{1,2}|[0-9]{1,2}\s*[/]\s*[0-9]{1,2}\s*(?:주문|방문|포장|배달|결제|이용|배송))\s*/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/(?:v|ver\.?)\s*[0-9]+(?:\.[0-9]+)+(?:\s*(?:버전|빌드|업데이트))?|[0-9]+(?:\.[0-9]+)+\s*(?:버전|빌드|업데이트)|버전\s*[0-9]+(?:\.[0-9]+)+/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/(?:만점|점|개)\s*(?:에|중|에서)?\s*([0-9]+(?:\.[0-9]+)?)\s*(?:등|위|호점|번째|번\s*추천|순위|차|회)/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\.[0-9]+)?)\s*(?:등|위|호점|번째|번\s*추천|순위)\b/gi, ' ');
        // [FIND_R22_001 해결] 호평/일상 리뷰 내 층/박/호점/차/인분 등 부가 수치 마스킹
        strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\.[0-9]+)?)\s*(?:층|박(?:\s*[0-9]+\s*일)?|박|호점|차|인분|단계|세트|그릇|접시|잔)\b/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/([0-9]+)\s*개\s*(?:더|포장|주문|먹|시켰|구매|추가|사|남김|배달)/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/\b[0-9]{1,2}\s*[:]\s*[0-9]{2}\s*(?:에|경|쯤|시|분|초|주문|방문|포장|배달|결제|이용|배송)?/gi, ' ');

        // ASCII 혼합 분수 매칭 (4 1/2점)
        const asciiMixedMatch = strWithoutComparison.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?|つ?星)?\s+([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?\s*[\/⁄\\＼]\s*([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?(?!\s*(?:주문|방문|포장|배달|결제|이용|배송))/i);
        if (asciiMixedMatch) {
            const intPart = parseFloat(asciiMixedMatch[1]);
            const num = parseFloat(asciiMixedMatch[2]);
            const denom = parseFloat(asciiMixedMatch[3]);
            if (!isNaN(intPart) && !isNaN(num) && !isNaN(denom) && denom > 0 && denom <= 100 && (denom === 100 || denom === 10 || denom === 5 || num <= 31 || num <= denom)) {
                return normalizeScore(intPart + (num / denom), targetField);
            }
        }

        // 분수 매칭 (35/100, 1/5, 2/5 등)
        const fractionMatch = strWithoutComparison.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?\s*[\/⁄\\＼]\s*([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?(?!\s*(?:주문|방문|포장|배달|결제|이용|배송))/i);
        if (fractionMatch) {
            const num = Number(fractionMatch[1]);
            const denom = Number(fractionMatch[2]);
            if (!isNaN(num) && !isNaN(denom) && denom > 0 && denom <= 100 && (denom === 100 || denom === 10 || denom === 5 || num <= 31 || num <= denom)) {
                return targetField === 'rating' ? (num / denom) * 5 : num / denom;
            }
        }

        // 비율 척도 (1:5)
        const ratioMatch = strWithoutComparison.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?\s*[:]\s*([0-9]+(?:\.[0-9]+)?)\b\s*(?:점|개|stars?)?(?!\s*(?:에|경|쯤|시|분|초|주문|방문|포장|배달|결제|이용|배송))/i);
        if (ratioMatch) {
            const num = Number(ratioMatch[1]);
            const denom = Number(ratioMatch[2]);
            if (!isNaN(num) && !isNaN(denom) && denom > 0 && denom <= 100) {
                return targetField === 'rating' ? (num / denom) * 5 : num / denom;
            }
        }

        // 별 이모지 파싱 및 텍스트 교차 검증
        if (/[★⭐☆🌟]/.test(str)) {
            if (reviewText && typeof reviewText === 'string') {
                const textNorm = reviewText.normalize('NFKC').replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
                const isExplicitBad = /(?:[1-2]점|별\s*(?:하나|한\s*개|1개)|최악|쓰레기|환불|고소|썩었|폭망)/i.test(textNorm);
                const isExplicitGood = /(?:5점\s*만점|5점|별\s*(?:다섯|5개)|최고|인생맛집|대박)/i.test(textNorm);
                const filledStars = (str.match(/[★⭐🌟]/g) || []).length;
                if (filledStars >= 4 && isExplicitBad) return 1;
                if (filledStars <= 2 && isExplicitGood) return 5;
            }

            const hasExplicitNumberWithUnit = /(?:[0-9]+(?:\.[0-9]+)?|[一二三四五]|one|two|three|four|five|하나|한|둘|두|셋|세|넷|네|다섯)\s*(?:점|개|stars?|points?|つ?星)/i.test(strWithoutComparison);
            if (!hasExplicitNumberWithUnit) {
                const filledStars = (str.match(/[★⭐🌟]/g) || []).length;
                const emptyStars = (str.match(/[☆]/g) || []).length;
                if (filledStars > 0 || emptyStars > 0) {
                    if (filledStars === 0 && emptyStars > 0) return 0;
                    if (filledStars >= 1 && filledStars <= 5) return filledStars;
                    if (filledStars === 0) return 0;
                }
            }
        }

        // 영문 척도 ("1 star out of 5 stars")
        const engScaleMatch = strWithoutComparison.match(/(one|two|three|four|five|[0-9]+(?:\.[0-9]+)?)\s*(?:stars?|points?|점)?\s*(?:out\s+of|of)\s*(one|two|three|four|five|[0-9]+(?:\.[0-9]+)?)\s*(?:stars?|points?|점)?/i);
        if (engScaleMatch) {
            const sVal = englishWordMap[engScaleMatch[1].toLowerCase()] || Number(engScaleMatch[1]);
            const bVal = englishWordMap[engScaleMatch[2].toLowerCase()] || Number(engScaleMatch[2]);
            if (!isNaN(sVal) && !isNaN(bVal) && bVal > 0) return targetField === 'rating' ? (sVal / bVal) * 5 : sVal;
        }

        // 다국어 척도 ("1 out of 5 stars", "1 de 5")
        const multiScaleMatch = strWithoutComparison.match(/([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:stars?|étoiles?|sternen?|estrellas?|점|개)?\s*(?:out\s+of|of|de|sobre|sur|von|su)\s*([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:stars?|étoiles?|sternen?|estrellas?|점|개)?/i);
        if (multiScaleMatch) {
            const score = Number(multiScaleMatch[1]);
            const base = Number(multiScaleMatch[2]);
            if (!isNaN(score) && !isNaN(base) && base > 0) return targetField === 'rating' ? (score / base) * 5 : score;
        }

        // 지수 표기법 (5e0, 1e0)
        const expMatch = strWithoutComparison.match(/\b([0-9]+(?:\.[0-9]+)?e[+\-]?[0-9]+)\b\s*(?:점|개|stars?)?/i);
        if (expMatch) {
            const n = Number(expMatch[1]);
            if (!isNaN(n)) return normalizeScore(n, targetField);
        }

        // Key-value 평점 ("평점: 5", "score: 5")
        const colonMatch = strWithoutComparison.match(/(?:평점|score|rating|별점)\s*[:=\-]\s*([0-9]+(?:\.[0-9]+)?|\.[0-9]+)/i);
        if (colonMatch) {
            const n = Number(colonMatch[1]);
            if (!isNaN(n)) return normalizeScore(n, targetField);
        }

        // 단위 수치 매칭 ("1점", "5점", "맛 1점 양 5점")
        const unitRegex = /([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?|points?|つ?星)/gi;
        const unitMatches = [...strWithoutComparison.matchAll(unitRegex)];
        if (unitMatches.length > 0) {
            const parsedValues = unitMatches.map(m => Number(m[1])).filter(v => !isNaN(v));
            const badScore = parsedValues.find(v => v < 3);
            const chosen = (badScore !== undefined) ? badScore : parsedValues[parsedValues.length - 1];
            return normalizeScore(chosen, targetField);
        }

        // 비단위 분리 수치 매칭
        const nonContextMatches = [...strWithoutComparison.matchAll(/(?:^|[^\d.−-])([-−]?(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+))(?!\s*(?:년|번째|번|차|회|개월|주|일|시|분|초|살|명|원|달러|\b(?:st|nd|rd|th)\b))/gi)];
        if (nonContextMatches.length > 0) {
            const parsedValues = nonContextMatches.map(m => Number(m[1].replace(/−/g, '-'))).filter(v => !isNaN(v));
            const badScore = parsedValues.find(v => v < 3);
            const chosen = (badScore !== undefined) ? badScore : parsedValues[parsedValues.length - 1];
            return normalizeScore(chosen, targetField);
        }

        if (hasSarcastic) return 1;

        const fallbackNum = Number(str.replace(/−/g, '-'));
        if (isNaN(fallbackNum) || !Number.isFinite(fallbackNum)) {
            if (reviewText && typeof reviewText === 'string') {
                return resolveUniversalScale(null, reviewText, targetField, depth + 1);
            }
            return NaN;
        }
        return normalizeScore(fallbackNum, targetField);
    }


    function parseSafeNumber(val, reviewText, targetField = 'rating', depth = 0) {
        return resolveUniversalScale(val, reviewText, targetField, depth);
    }

    function selectPriorityItem(arr) {
        if (!Array.isArray(arr) || arr.length === 0) return {};

        function flattenDeep(input) {
            return input.reduce((acc, val) => Array.isArray(val) ? acc.concat(flattenDeep(val)) : acc.concat(val), []);
        }
        const flatArr = flattenDeep(arr);
        if (flatArr.length === 0) return {};

        const criticalItem = flatArr.find(item => {
            if (!item || typeof item !== 'object') return false;
            const candidateFields = ['rating', 'score', 'overall_rating', 'total_score', 'user_rating', 'value', 'item_score', 'star_count', 'grade', 'food_rating', 'service_rating', 'taste', 'delivery'];
            let found = [];
            for (const f of candidateFields) {
                if (item[f] !== undefined && item[f] !== null && item[f] !== '') {
                    found.push(item[f]);
                }
            }
            let r = undefined;
            if (found.length > 0) {
                const bad = found.find(val => {
                    const num = parseSafeNumber(val, undefined, 'rating');
                    return !isNaN(num) && num < 3;
                });
                r = bad !== undefined ? bad : found[0];
            }
            const text = typeof item.review_text === 'string' ? item.review_text : (typeof item.comment === 'string' ? item.comment : (typeof item.content === 'string' ? item.content : (typeof item.text === 'string' ? item.text : '')));
            const parsedR = parseSafeNumber(r, text, 'rating');
            if (!isNaN(parsedR)) {
                if (parsedR < 3) return true;
                return false;
            }
            const valence = evaluateSyntacticValence(text);
            if (valence.isCrisis && !valence.isPraise) return true;
            return false;
        });

        const reviewItem = flatArr.find(x => x && typeof x === 'object' && isReviewData(x));
        return criticalItem || reviewItem || flatArr[0] || {};
    }

    // [FIND_005, FIND_006, FIND_007, FIND_008 해결] 텔레그램 승인자 인가 화이트리스트 및 보안 무결성 가드 적용
    function evaluateTelegramApproval(opts) {
        if (!opts) return { isApproved: false, status: 'PENDING' };

        // [FIND_TC_06_3, FIND_TC_06_4 해결] 텔레그램 액션 타입 스머글링 방어 (배열/객체 등 비문자열 주입 시 무단 승인 원천 차단)
        if (opts.resumeCallback && opts.resumeCallback.action !== undefined && typeof opts.resumeCallback.action !== 'string') {
            return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
        }
        if (opts.action !== undefined && typeof opts.action !== 'string') {
            return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
        }

        // [FIND_002, FIND_R24_024 ~ FIND_R24_026, FIND_009 해결] 텔레그램 콜백 URL 디코딩 및 거절/취소 액션 처리
        let decodedAction = String(opts.resumeCallback?.action || opts.action || '').trim();
        try {
            decodedAction = decodeURIComponent(decodedAction.replace(/\+/g, ' ')).trim();
        } catch (e) {
            // ignore
        }
        if (decodedAction.startsWith('{') && decodedAction.endsWith('}')) {
            try {
                const parsedJson = JSON.parse(decodedAction);
                if (parsedJson && typeof parsedJson === 'object' && parsedJson.action) {
                    decodedAction = String(parsedJson.action);
                }
            } catch (e) {}
        }
        const rawAction = decodedAction.replace(/[\u200B-\u200D\uFEFF\u00A0\u3000]/g, ' ').trim().toUpperCase();
        const isExplicitRejection = /REJECT|DISAPPROVE|CANCEL|DENIED|DENY|\bNO\b/i.test(rawAction);
        if (isExplicitRejection) {
            return { isApproved: false, status: 'REJECTED' };
        }

        // [FIND_005, FIND_006 해결] 텔레그램 콜백 노드 및 resumeApproval 재전송 공격(Replay Attack) 방어
        if (
            opts.is_replay === true ||
            opts.duplicate === true ||
            opts.replay === true ||
            opts.resumeCallback?.is_replay === true ||
            opts.resumeCallback?.duplicate === true ||
            opts.resumeCallback?.replay === true
        ) {
            return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
        }

        // [FIND_006, FIND_008 해결] 텔레그램 승인 콜백 및 resumeApproval 보안 무결성 가드:
        // 변조/서명 위조/무효 또는 토큰 만료 플래그가 있는 경우 actor 화이트리스트와 무관하게 즉시 차단
        if (
            opts.signature_valid === false ||
            opts.token_expired === true ||
            opts.token_verified === false ||
            opts.tampered === true ||
            (typeof opts.auth_token === 'string' && /TAMPERED|FORGED|INVALID|EXPIRED/i.test(opts.auth_token)) ||
            opts.resumeCallback?.signature_valid === false ||
            opts.resumeCallback?.token_expired === true ||
            opts.resumeCallback?.token_verified === false ||
            opts.resumeCallback?.tampered === true ||
            (typeof opts.resumeCallback?.auth_token === 'string' && /TAMPERED|FORGED|INVALID|EXPIRED/i.test(opts.resumeCallback.auth_token))
        ) {
            return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
        }

        const authorizedActors = ['CEO', 'ADMIN', 'CEO_TELEGRAM_ID'];

        if (opts.resumeCallback) {
            if (!opts.resumeCallback || typeof opts.resumeCallback !== 'object') {
                return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
            }
            if (Object.getPrototypeOf(opts.resumeCallback) !== Object.prototype && Object.getPrototypeOf(opts.resumeCallback) !== null) {
                return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
            }
            if (!Object.prototype.hasOwnProperty.call(opts.resumeCallback, 'actor')) {
                return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
            }
            // [FIND_TC_06_3, FIND_TC_06_4 해결] 엄격한 string 타입 검증
            if (typeof opts.resumeCallback.action !== 'string') {
                return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
            }
            // [FIND_009 해결] actor 공백 trim 지원
            const rawActor = opts.resumeCallback.actor;
            const actor = typeof rawActor === 'string' ? rawActor.trim() : rawActor;
            if (!actor || typeof actor !== 'string' || !authorizedActors.includes(actor)) {
                return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
            }
            // [FIND_009, FIND_R24_024 ~ FIND_R24_026 해결] 승인 액션 URL 디코딩, 유니코드 공백 정규화 및 한글/영문 승인 매칭
            let actionStr = String(opts.resumeCallback.action || '').trim();
            try {
                actionStr = decodeURIComponent(actionStr.replace(/\+/g, ' ')).trim();
            } catch (e) {
                // ignore
            }
            if (actionStr.startsWith('{') && actionStr.endsWith('}')) {
                try {
                    const parsedObj = JSON.parse(actionStr);
                    if (parsedObj && typeof parsedObj === 'object' && parsedObj.action) {
                        actionStr = String(parsedObj.action);
                    }
                } catch (e) {}
            }
            const actionUpper = actionStr.replace(/[\u200B-\u200D\uFEFF\u00A0\u3000]/g, ' ').trim().toUpperCase();
            if (actionUpper === 'APPROVED' || actionUpper === 'APPROVE' || actionUpper === '승인' || actionUpper === '승인 발송' || actionUpper === 'YES') {
                return { isApproved: true, status: 'APPROVED', actor: actor };
            }
            return { isApproved: false, status: opts.resumeCallback.action || 'PENDING', actor: actor };
        }

        // [FIND_006, FIND_010 해결] resumeApproval: true 단독 플래그도 보안 무결성 및 opts.actor 인가자 화이트리스트 검증
        if (opts.resumeApproval === true) {
            // [FIND_002 해결] resumeApproval: true 블록에서도 거절/취소인 경우 승인하지 않고 즉시 REJECTED 반환
            if (isExplicitRejection) {
                return { isApproved: false, status: 'REJECTED' };
            }
            if (
                opts.is_replay === true ||
                opts.duplicate === true ||
                opts.replay === true ||
                opts.signature_valid === false ||
                opts.token_expired === true ||
                opts.token_verified === false ||
                opts.tampered === true ||
                (typeof opts.auth_token === 'string' && /TAMPERED|FORGED|INVALID|EXPIRED/i.test(opts.auth_token)) ||
                opts.resumeCallback?.is_replay === true ||
                opts.resumeCallback?.duplicate === true ||
                opts.resumeCallback?.replay === true ||
                opts.resumeCallback?.signature_valid === false ||
                opts.resumeCallback?.token_expired === true ||
                opts.resumeCallback?.token_verified === false ||
                opts.resumeCallback?.tampered === true ||
                (typeof opts.resumeCallback?.auth_token === 'string' && /TAMPERED|FORGED|INVALID|EXPIRED/i.test(opts.resumeCallback.auth_token))
            ) {
                return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
            }
            if (!Object.prototype.hasOwnProperty.call(opts, 'actor')) {
                return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
            }
            // [FIND_009 해결] actor 공백 trim 지원
            const rawActor = opts.actor;
            const actor = typeof rawActor === 'string' ? rawActor.trim() : rawActor;
            if (actor && typeof actor === 'string' && authorizedActors.includes(actor)) {
                // [FIND_R27_005 해결] resumeApproval: true 시 action 필드 누락/빈값/공백 또는 미승인 액션 차단
                const approvalKeywords = ['APPROVED', 'APPROVE', '승인', '승인 발송', 'YES'];
                if (!rawAction || !approvalKeywords.includes(rawAction)) {
                    return { isApproved: false, status: rawAction || 'PENDING', actor: actor };
                }
                return { isApproved: true, status: 'APPROVED', actor: actor };
            }
            return { isApproved: false, status: 'UNAUTHORIZED_BLOCKED' };
        }

        return { isApproved: false, status: 'PENDING' };
    }

    let currentData;
    try {
        currentData = safeClone(payload);
        if (Array.isArray(currentData)) {
            currentData = selectPriorityItem(currentData);
        }
    } catch (cloneErr) {
        result.status = 'PAYLOAD_CORRUPT';
        result.uncaughtException = false;
        result.crashError = `safeClone error: ${cloneErr.message}`;
        result.outputData = { error: cloneErr.message };
        result.executionTimeMs = Date.now() - startTime;
        return result;
    }

    // 에어백 매트릭스 인라인 연동 (장애 자동 치유 및 DLQ 격리)
    const airbagPath = path.join(__dirname, 'airbag_9_healing_matrix.js');
    if (fs.existsSync(airbagPath)) {
        try {
            const airbagSource = fs.readFileSync(airbagPath, 'utf8');
            const hasCronNode = workflow.nodes && workflow.nodes.some(n => 
                (n.type && (n.type.includes('cron') || n.type.includes('schedule') || n.type.includes('interval'))) ||
                (n.name && (n.name.toLowerCase().includes('cron') || n.name.toLowerCase().includes('스케줄') || n.name.toLowerCase().includes('partition-cron'))) ||
                (n.parameters?.path && n.parameters.path.includes('cron'))
            );
            const isExecWorkflow = (workflow.meta && String(workflow.meta.category).includes('EXECUTIVE')) || path.basename(workflowPath).includes('EXEC-DAILY');
            const isCronWorkflow = Boolean(hasCronNode || isExecWorkflow || safeOptions.isCron || (payload && payload.__is_cron));

            if (isCronWorkflow) {
                currentData.__is_cron = true;
            }

            const airbagContext = vm.createContext({
                console: console,
                Date: Date,
                Math: Math,
                JSON: JSON,
                Object: Object,
                Array: Array,
                String: String,
                Number: Number,
                RegExp: RegExp,
                context: {
                    isCron: isCronWorkflow,
                    workflowPath: workflowPath,
                    workflowName: workflow.name || (workflowPath ? path.basename(workflowPath, '.json') : ''),
                    category: workflow.meta?.category
                }
            });
            const airbagFn = vm.runInContext('(function($input) {\n' + airbagSource + '\n})', airbagContext);
            const healed = airbagFn({
                all: () => [{ json: currentData }]
            });
            if (healed && healed.length > 0 && healed[0].json) {
                currentData = healed[0].json;
                if (Array.isArray(currentData)) {
                    currentData = selectPriorityItem(currentData);
                }
                if (currentData.status === 'PING_EVENT_ACKNOWLEDGED_NO_ACTION') {
                    result.status = 'PING_EVENT_ACKNOWLEDGED_NO_ACTION';
                    result.quarantined = false;
                    result.healingApplied = currentData.chaos_healing_applied || currentData.healing_applied || 'PING_EVENT_ACKNOWLEDGED_NO_ACTION';
                    result.outputData = currentData;
                    result.triggeredApis = [];
                    result.executionTimeMs = Date.now() - startTime;
                    return result;
                }
                const rejectionStatuses = ['QUARANTINED', 'FAIL_CLOSED_REJECTED', 'BLOCKED_409', 'ALARM_DISPATCHED'];
                if (rejectionStatuses.includes(currentData.status)) {
                    result.status = currentData.status;
                    result.quarantined = true;
                    result.healingApplied = currentData.chaos_healing_applied || currentData.healing_applied || `AIRBAG_${currentData.status}`;
                    result.quarantineReason = currentData.quarantine_reason || currentData.reason || currentData.quarantineReason;
                    result.outputData = currentData;
                    result.executionTimeMs = Date.now() - startTime;
                    return result;
                }
                if (currentData.cascade_skipped === true) {
                    result.status = 'CASCADE_SKIPPED';
                    result.cascade_skipped = true;
                    result.healingApplied = currentData.chaos_healing_applied || currentData.healing_applied || 'AIRBAG_CASCADE_SKIPPED';
                    result.outputData = currentData;
                    result.executionTimeMs = Date.now() - startTime;
                    return result;
                }
                if (currentData.chaos_healing_applied) {
                    result.healingApplied = currentData.chaos_healing_applied;
                }
            }
        } catch (airbagErr) {
            console.error(`Airbag execution error: ${airbagErr.message}`);
            // Fail-Closed 안전 잠금: 에어백 실행 중 스택 오버플로우 등 예외 발생 시 파이프라인 무검증 실행 차단 및 즉시 격리
            result.status = 'QUARANTINED';
            result.quarantined = true;
            result.healingApplied = `AIRBAG_FATAL_ERROR: ${airbagErr.message}`;
            currentData.status = 'QUARANTINED';
            currentData.quarantine_reason = `AIRBAG_EXECUTION_CRASH: ${airbagErr.message}`;
            result.outputData = currentData;
            result.executionTimeMs = Date.now() - startTime;
            return result;
        }
    }

    // 워크플로우 노드 순차 실행
    const nodes = workflow.nodes || [];
    const triggeredApis = [];
    const skippedNodes = new Set();

    try {
        for (const node of nodes) {
            const nodeType = node.type || '';
            const nodeName = node.name || '';
            const params = node.parameters || {};

            // [FIND_002 해결] 분기 라우터에서 선택되지 않은 브랜치 노드 건너뛰기
            if (skippedNodes.has(nodeName) || (node.id && skippedNodes.has(node.id))) {
                continue;
            }

            // 1. Webhook / Cron 트리거 노드 건너뛰기 및 토픽 검증
            if (nodeType.includes('webhook') || nodeType.includes('cron') || nodeType.includes('trigger')) {
                // [FIND_006 해결] Webhook 토픽 파라미터 불일치 검증
                if (nodeType.includes('webhook') && params.topic) {
                    const incomingTopic = currentData.topic || currentData.event || currentData.headers?.['x-wc-webhook-topic'] || (currentData.headers && currentData.headers['X-Wc-Webhook-Topic']);
                    if (incomingTopic && incomingTopic !== params.topic) {
                        currentData.__branch = 'false';
                        result.status = 'FILTERED_TOPIC_MISMATCH';
                        continue;
                    }
                }
                continue;
            }

            // 1-1. n8n Code 노드 실제 JavaScript 실행 (FIND_001 대응)
            if (nodeType.includes('code')) {
                const jsCode = params.jsCode || '';
                if (jsCode) {
                    try {
                        const workflowKey = path.resolve(workflowPath);
                        if (!globalWorkflowStaticData.has(workflowKey)) {
                            globalWorkflowStaticData.set(workflowKey, {});
                        }
                        const staticDataMap = globalWorkflowStaticData.get(workflowKey);

                        const inputItems = (currentData && currentData.multi_branch_items && currentData.multi_branch_items.length > 0)
                            ? currentData.multi_branch_items.map(m => ({ json: m.json || m }))
                            : [{ json: currentData }];

                        const safeNodeProxy = new Proxy({}, {
                            get: (target, prop) => {
                                return {
                                    json: Object.assign({}, currentData),
                                    binary: {},
                                    data: Object.assign({}, currentData)
                                };
                            }
                        });

                        const safeProcess = {
                            env: {
                                NODE_ENV: 'production',
                                AUTOFLOW_AIRBAG_SANDBOX: 'true',
                                AUTOFLOW_DAEMON_URL: 'http://autoflow-defender:8080'
                            }
                        };

                        const sandbox = {
                            $input: {
                                all: () => inputItems,
                                first: () => inputItems[0] || ({ json: currentData }),
                                item: (idx) => inputItems[idx] || ({ json: currentData })
                            },
                            $node: safeNodeProxy,
                            $json: (inputItems[0] && inputItems[0].json) ? inputItems[0].json : currentData,
                            $parameter: (param, fallback) => (fallback !== undefined ? fallback : null),
                            process: safeProcess,
                            Buffer: Buffer,
                            $getWorkflowStaticData: (type) => {
                                const key = type || 'node';
                                if (!staticDataMap[key]) staticDataMap[key] = {};
                                return staticDataMap[key];
                            },
                            items: inputItems,
                            Date: Date,
                            Math: Math,
                            JSON: JSON,
                            Object: Object,
                            Array: Array,
                            String: String,
                            Number: Number,
                            RegExp: RegExp,
                            Boolean: Boolean,
                            parseInt: parseInt,
                            parseFloat: parseFloat,
                            isNaN: isNaN,
                            isFinite: isFinite,
                            console: console
                        };
                        vm.createContext(sandbox);
                        const codeOutput = vm.runInContext('(function() {\n' + jsCode + '\n})()', sandbox);
                        if (Array.isArray(codeOutput) && codeOutput.length >= 2 && (Array.isArray(codeOutput[0]) || Array.isArray(codeOutput[1]))) {
                            const normalBranch = Array.isArray(codeOutput[0]) ? codeOutput[0] : [];
                            const dlqBranch = Array.isArray(codeOutput[1]) ? codeOutput[1] : [];
                            let chosenIdx = 0;
                            if (dlqBranch.length > 0) {
                                chosenIdx = 1;
                                const dlqItem = dlqBranch[0].json || dlqBranch[0];
                                currentData = Object.assign({}, currentData, dlqItem);
                                currentData.__branch = 'false';
                                currentData.quarantined = true;
                                result.quarantined = true;
                                result.status = 'QUARANTINED';
                                result.quarantineReason = dlqItem.quarantine_reason || 'DLQ_BRANCH_QUARANTINED';
                            } else if (normalBranch.length > 0) {
                                chosenIdx = 0;
                                const normalItem = normalBranch[0].json || normalBranch[0];
                                currentData = Object.assign({}, currentData, normalItem);
                                currentData.__branch = 'true';
                            }

                            // [FIND_006 & FIND_007 해결] Code 노드 다중 출력 브랜치 분기 라우팅: 선택되지 않은 브랜치는 skippedNodes에 등록
                            if (workflow.connections && (workflow.connections[nodeName] || workflow.connections[node.id])) {
                                const connObj = workflow.connections[nodeName] || workflow.connections[node.id];
                                if (connObj && Array.isArray(connObj.main) && connObj.main.length >= 2) {
                                    for (let branchIdx = 0; branchIdx < connObj.main.length; branchIdx++) {
                                        if (branchIdx !== chosenIdx) {
                                            const queue = [...(connObj.main[branchIdx] || [])];
                                            while (queue.length > 0) {
                                                const edge = queue.shift();
                                                const targetNodeName = edge.node;
                                                if (targetNodeName && !skippedNodes.has(targetNodeName)) {
                                                    skippedNodes.add(targetNodeName);
                                                    const nextConns = workflow.connections[targetNodeName];
                                                    if (nextConns && Array.isArray(nextConns.main)) {
                                                        for (const outList of nextConns.main) {
                                                            if (Array.isArray(outList)) {
                                                                queue.push(...outList);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (Array.isArray(codeOutput) && codeOutput.length === 0) {
                            // [FIND_008 해결] 멱등성 캐시 빈 배열 반환 시 파이프라인 즉시 중단 (Fail-Closed 가드)
                            result.quarantined = true;
                            result.status = 'DUPLICATE_IGNORED';
                            result.duplicate = true;
                            result.quarantineReason = 'IDEMPOTENCY_DUPLICATE_FILTERED';
                            currentData.quarantined = true;
                            currentData.duplicate = true;
                            break;
                        } else if (codeOutput && Array.isArray(codeOutput) && codeOutput.length > 0 && codeOutput[0].json) {
                            if (codeOutput.length > 1) {
                                currentData = Object.assign({}, currentData, codeOutput[0].json, {
                                    multi_branch_items: codeOutput.map(c => c.json || c),
                                    resolved_branch: 'ALL_8_BRANCHES_PROCESSED',
                                    branch_delivery: 'ALL_TERMINALS_DELIVERED'
                                });
                            } else {
                                currentData = Object.assign({}, currentData, codeOutput[0].json);
                            }
                            if (currentData.status === 'PING_EVENT_ACKNOWLEDGED_NO_ACTION') {
                                result.status = 'PING_EVENT_ACKNOWLEDGED_NO_ACTION';
                                result.quarantined = false;
                                result.outputData = currentData;
                                break;
                            }
                            if (currentData.airbag_dlq_quarantined || currentData.quarantined || currentData.status === 'QUARANTINED') {
                                result.quarantined = true;
                                result.status = 'QUARANTINED';
                                result.quarantineReason = currentData.quarantine_reason || currentData.reason || 'CODE_NODE_QUARANTINED';
                                result.outputData = currentData;
                                const hasPendingDlqNode = nodes.some(n => !skippedNodes.has(n.name) && !skippedNodes.has(n.id) && ((n.name && n.name.toLowerCase().includes('dlq')) || (n.parameters && n.parameters.sheetName && String(n.parameters.sheetName).toLowerCase().includes('dlq'))));
                                if (!hasPendingDlqNode) {
                                    break;
                                }
                            }
                        } else if (codeOutput && typeof codeOutput === 'object') {
                            currentData = Object.assign({}, currentData, codeOutput.json || codeOutput);
                            if (currentData.status === 'PING_EVENT_ACKNOWLEDGED_NO_ACTION') {
                                result.status = 'PING_EVENT_ACKNOWLEDGED_NO_ACTION';
                                result.quarantined = false;
                                result.outputData = currentData;
                                break;
                            }
                            if (currentData.airbag_dlq_quarantined || currentData.quarantined || currentData.status === 'QUARANTINED') {
                                result.quarantined = true;
                                result.status = 'QUARANTINED';
                                result.quarantineReason = currentData.quarantine_reason || currentData.reason || 'CODE_NODE_QUARANTINED';
                                result.outputData = currentData;
                                const hasPendingDlqNode = nodes.some(n => !skippedNodes.has(n.name) && !skippedNodes.has(n.id) && ((n.name && n.name.toLowerCase().includes('dlq')) || (n.parameters && n.parameters.sheetName && String(n.parameters.sheetName).toLowerCase().includes('dlq'))));
                                if (!hasPendingDlqNode) {
                                    break;
                                }
                            }
                        }
                    } catch (codeErr) {
                        console.error(`Code node execution error in [${nodeName}]:`, codeErr.message);
                        result.quarantined = true;
                        result.status = 'QUARANTINED';
                        result.quarantineReason = `CODE_NODE_EXCEPTION: ${codeErr.message}`;
                        currentData.quarantined = true;
                        currentData.quarantine_reason = result.quarantineReason;
                        break; // [FIND_001 Fail-Closed] 코드 노드 예외 발생 시 후속 노드 실행 차단
                    }
                }
                continue;
            }

            // 2. Qwen Vision / LLM 인지 노드
            if (nodeType.includes('qwen_vlm') || nodeType.includes('llm')) {
                const task = params.task || '';
                const systemPrompt = params.system_prompt || '';
                const nodeNameLower = (node.name || nodeName || '').toLowerCase();
                const taskLower = task.toLowerCase();

                // [FIND_008 해결] Qwen 경영진 종합 & 이상치 탐지 태스크 (AF-EXEC-DAILY n5 대응)
                if (nodeNameLower.includes('synthesize') || taskLower.includes('synthesize') || nodeNameLower.includes('executive') || nodeNameLower.includes('anomaly')) {
                    currentData.synthesis = '일일 경영 실적 요약 완료';
                    currentData.profit_synthesis = `일일 매출 ${currentData.sales || 0}원 / 지출 ${currentData.expenses || 0}원 요약 완료`;
                    const expensesVal = Number(currentData.expenses);
                    currentData.cost_anomalies = (expensesVal > 10000000 ? '비용 과다 청구 감지' : '정상');
                    currentData.cost_anomaly_detected = (expensesVal > 10000000 || currentData.anomaly_flag === 'SUSPICIOUS_EXPENSE_CLAIM');
                    currentData.executive_briefing = true;
                    continue;
                }

                // [FIND_001 해결] CS 인바운드 문의 AI 긴급도 분류 태스크 (AF-CS-01 대응)
                if (systemPrompt.includes('urgency') || nodeName.includes('Urgency') || nodeName.includes('Classifier') || task.includes('urgency') || task.includes('classify')) {
                    const inquiryText = String(currentData.inquiry || currentData.text || currentData.body || currentData.message || currentData.content || '').trim();
                    const hasExplicitUrgency = currentData.urgency !== undefined && currentData.urgency !== null && currentData.urgency !== '';

                    // 빈 객체나 결측 페이로드(inquiry 부재 및 urgency 부재)인 경우 urgency 임의 생성 방지
                    if (!inquiryText && !hasExplicitUrgency) {
                        continue;
                    }

                    // 프롬프트 인젝션 방어: 한국어 지시 무시 등 인젝션 시도가 있는 경우 NORMAL 강등 또는 에어백 격리
                    const injectionRegex = /(?:지침\s*무시|지시\s*무시|이전\s*지침|이전\s*지시|명령\s*무시|긴급도.*HIGH.*지정)/i;
                    const hasInjection = injectionRegex.test(inquiryText);

                    // 긴급 키워드 분석 (환불, 고소, 장애, 다운, 중단, 먹통, 접속불가, 사기, 폭망, 경찰, 식중독, 소송, 급합, 긴급, 피해, 배상, 불량)
                    const urgentKeywordsRegex = /(?:환불|고소|장애|다운|중단|먹통|접속불가|사기|폭망|경찰|식중독|소송|급합|긴급|피해|배상|불량)/i;
                    const isExplicitHigh = hasExplicitUrgency && String(currentData.urgency).trim().toUpperCase() === 'HIGH';
                    const isKeywordHigh = urgentKeywordsRegex.test(inquiryText);

                    if (!hasInjection && (isExplicitHigh || isKeywordHigh)) {
                        currentData.urgency = 'HIGH';
                        currentData.category = currentData.category || 'REFUND';
                        currentData.sentiment = currentData.sentiment || 'NEGATIVE';
                    } else if (hasInjection) {
                        currentData.urgency = 'NORMAL';
                        currentData.category = currentData.category || 'GENERAL';
                        currentData.sentiment = currentData.sentiment || 'NEUTRAL';
                    } else {
                        currentData.urgency = currentData.urgency ? String(currentData.urgency).trim().toUpperCase() : 'NORMAL';
                        currentData.category = currentData.category || 'GENERAL';
                        currentData.sentiment = currentData.sentiment || 'NEUTRAL';
                    }
                    continue;
                }

                // A. 위기 대응 및 사과문 초안 작성 태스크 (AF-CRISIS-DEFENSE 대응)
                if (task.includes('apology') || currentData.review_text !== undefined || currentData.comment !== undefined || currentData.content !== undefined || currentData.text !== undefined || nodeName.includes('Apology')) {
                    // [FIND_001, FIND_002] 평점 필터 분기 검증: __branch가 'true' 또는 true가 아니면 사과문 초안 작성 생략
                    if (currentData.__branch !== 'true' && currentData.__branch !== true) {
                        continue;
                    }
                    let reviewText = '고객 불편 사항';
                    try {
                        const candidateContainers = [
                            currentData,
                            currentData.review,
                            currentData.payload,
                            currentData.feedback,
                            currentData.data,
                            currentData.response,
                            ...(Array.isArray(currentData.reviews) ? currentData.reviews : []),
                            ...(Array.isArray(currentData.items) ? currentData.items : []),
                            ...(Array.isArray(currentData.data?.reviews) ? currentData.data.reviews : []),
                            ...(Array.isArray(currentData.response?.items) ? currentData.response.items : [])
                        ].filter(x => x && typeof x === 'object');
                        let rawReview = undefined;
                        for (const c of candidateContainers) {
                            if (c.review_text !== undefined || c.comment !== undefined || c.content !== undefined || c.text !== undefined || c.review_detail !== undefined) {
                                rawReview = c.review_text !== undefined ? c.review_text : (c.comment !== undefined ? c.comment : (c.content !== undefined ? c.content : (c.text !== undefined ? c.text : c.review_detail)));
                                break;
                            }
                        }
                        if (typeof rawReview === 'symbol') {
                            reviewText = rawReview.description || '심볼 리뷰';
                        } else if (rawReview === null || rawReview === undefined) {
                            reviewText = '고객 불편 사항';
                        } else {
                            reviewText = String(rawReview);
                        }
                    } catch (strErr) {
                        reviewText = `[리뷰 텍스트 파싱 오류: ${strErr.message}]`;
                    }

                    let rating = currentData.rating;
                    const candidateContainers = [
                        currentData,
                        currentData.review,
                        currentData.payload,
                        currentData.feedback,
                        currentData.data,
                        currentData.response,
                        ...(Array.isArray(currentData.reviews) ? currentData.reviews : []),
                        ...(Array.isArray(currentData.items) ? currentData.items : []),
                        ...(Array.isArray(currentData.data?.reviews) ? currentData.data.reviews : []),
                        ...(Array.isArray(currentData.response?.items) ? currentData.response.items : [])
                    ].filter(x => x && typeof x === 'object');
                    const candidateFields = ['rating', 'score', 'overall_rating', 'total_score', 'user_rating', 'value', 'item_score', 'star_count', 'grade', 'food_rating', 'service_rating', 'taste', 'delivery'];
                    let foundRatings = [];
                    for (const c of candidateContainers) {
                        for (const f of candidateFields) {
                            if (c[f] !== undefined && c[f] !== null && c[f] !== '') {
                                const parsed = parseSafeNumber(c[f], undefined, 'rating');
                                foundRatings.push({ raw: c[f], parsed });
                            }
                        }
                    }
                    if (foundRatings.length > 0) {
                        const badItem = foundRatings.find(v => !isNaN(v.parsed) && v.parsed < 3);
                        rating = badItem ? badItem.raw : (rating !== undefined && rating !== null ? rating : foundRatings[0].raw);
                    }
                    let ratingDisplay = '1';
                    try {
                        if (typeof rating === 'symbol') {
                            ratingDisplay = rating.description || '미지정';
                        } else if (rating === undefined || rating === null) {
                            ratingDisplay = '1';
                        } else if (typeof rating === 'object') {
                            const inner = getValidInner(rating);
                            ratingDisplay = inner !== undefined ? String(inner) : '[객체 평점]';
                        } else {
                            ratingDisplay = String(rating);
                        }
                    } catch {
                        ratingDisplay = '[평점 파싱 오류]';
                    }

                    // [FIND_R27_002, FIND_R27_003 해결] 사과문 템플릿 인젝션/XSS 살균 및 PII 개인정보 마스킹
                    const promptInjectionSanitizeRegex = /(?:\[\s*SYSTEM\b[^\]]*\]|IGNORE\s+PREVIOUS[^.]*|DISREGARD\s+PREVIOUS[^.]*|SYSTEM\s*OVERRIDE[^.]*|<script\b[^>]*>[\s\S]*?<\/script>|1000\s*만원\s*보상|법적\s*책임\s*100%|We\s*admit\s*100%\s*legal\s*fault)/gi;
                    reviewText = reviewText.replace(promptInjectionSanitizeRegex, '[INJECTION_REDACTED]');
                    reviewText = reviewText.replace(/<[^>]+>/g, '[INJECTION_REDACTED]');
                    reviewText = maskPII(reviewText);

                    currentData.apology_draft = maskPII(`[AI 정중한 사과문 초안] 고객님께서 남겨주신 리뷰("${reviewText}", 평점: ${ratingDisplay}점)에 대해 진심으로 사과드립니다. 해당 불편 사항을 즉시 개선 조치하겠습니다.`);
                    currentData.complaint_analyzed = true;
                    currentData.crisis_severity = (typeof rating === 'number' && Number.isFinite(rating) && rating <= 1) ? 'HIGH' : 'MEDIUM';
                }

                // B. 이커머스 반품/파손 판정 태스크 (AF-EC-05 대응)
                // 클라이언트가 임의로 주입한 defect_verified 불리언 필드는 VLM 검증 신호 없이 우회 시도시 무효화
                if (currentData.defect_verified === true && currentData.has_defect === undefined && currentData.defect_score === undefined) {
                    currentData.defect_verified = false;
                } else if (currentData.has_defect === true || (typeof currentData.defect_score === 'number' && currentData.defect_score >= 0.8)) {
                    currentData.defect_verified = true;
                } else if (currentData.has_defect === false || (typeof currentData.defect_score === 'number' && currentData.defect_score < 0.8)) {
                    currentData.defect_verified = false;
                }
                continue;
            }

            // 3. 조건 분기 노드 (if_else / condition / n8n-nodes-base.if)
            if (nodeType.includes('if_else') || nodeType.includes('condition') || nodeType.endsWith('.if') || nodeType === 'n8n-nodes-base.if') {
                if (Array.isArray(currentData)) {
                    currentData = selectPriorityItem(currentData);
                }

                // [FIND_014 해결] WooCommerce 빈 웹훅 페이로드 스키마 결측 검증
                if (params.validate_order_schema === true || params.check_schema === true) {
                    const hasId = Boolean(currentData.id || currentData.order_key || currentData.number);
                    const hasBilling = Boolean(currentData.billing && typeof currentData.billing === 'object' && Object.keys(currentData.billing).length > 0 && (currentData.billing.phone || currentData.billing.first_name || currentData.billing.email || currentData.billing.mobile));
                    const hasTotal = currentData.total !== undefined && currentData.total !== null && currentData.total !== '';
                    if (!hasId || !hasBilling || !hasTotal) {
                        currentData.__branch = 'false';
                        continue;
                    }
                }

                // [FIND_002 해결] n8n-nodes-base.if 파라미터 규격(conditions.string / conditions.number / conditions.boolean) 지원
                if (params.conditions) {
                    function resolveValue(val, data) {
                        if (typeof val !== 'string') return val;
                        if (val.startsWith('=')) {
                            const cleaned = val.replace(/^=\s*\{\{\s*|\s*\}\}$/g, '').replace(/^=\s*/, '');
                            const match = cleaned.match(/\$json(?:\.([a-zA-Z0-9_$.]+)|\[['"]([^'"]+)['"]\])/);
                            if (match) {
                                const keyPath = match[1] || match[2];
                                if (keyPath.includes('.')) {
                                    return keyPath.split('.').reduce((acc, part) => (acc && acc[part] !== undefined ? acc[part] : undefined), data);
                                }
                                return data[keyPath];
                            }
                        }
                        return val;
                    }
                    let allPassed = true;
                    let condCount = 0;
                    for (const ct of ['string', 'number', 'boolean']) {
                        if (Array.isArray(params.conditions[ct])) {
                            for (const c of params.conditions[ct]) {
                                condCount++;
                                const v1 = resolveValue(c.value1, currentData);
                                const v2 = resolveValue(c.value2, currentData);
                                const operation = c.operation || 'equal';
                                if (operation === 'notEqual') {
                                    if (String(v1 ?? '').trim().toUpperCase() === String(v2 ?? '').trim().toUpperCase()) {
                                        allPassed = false;
                                    }
                                } else if (operation === 'notEmpty' || operation === 'isNotEmpty') {
                                    if (v1 === undefined || v1 === null || v1 === '' || (typeof v1 === 'object' && Object.keys(v1).length === 0)) {
                                        allPassed = false;
                                    }
                                } else {
                                    if (String(v1 ?? '').trim().toUpperCase() !== String(v2 ?? '').trim().toUpperCase()) {
                                        allPassed = false;
                                    }
                                }
                            }
                        }
                    }
                    if (condCount > 0) {
                        currentData.__branch = allPassed ? 'true' : 'false';
                    }
                } else {
                    const targetField = params.field || 'defect_verified';
                    let actualValue = currentData[targetField];
                    // [FIND_005 해결] WooCommerce order status 검증
                    if (targetField === 'status') {
                        const cleanStatus = String(actualValue || '').trim().toLowerCase();
                        const isValid = cleanStatus === 'processing' || cleanStatus === 'completed';
                        currentData.__branch = isValid ? 'true' : 'false';
                    }
                    if ((actualValue === undefined || actualValue === null || actualValue === '') && (targetField === 'rating' || targetField === 'score' || params.less_than !== undefined || params.greater_than !== undefined)) {
                        // [FIND_016 ~ FIND_018, FIND_R24_021 ~ FIND_R24_022, FIND_005 해결] 2차 중첩 스키마(review, payload, feedback, data, response, reviews, items) 평점 필드 지원
                        const candidateContainers = [
                            currentData,
                            currentData.review,
                            currentData.payload,
                            currentData.feedback,
                            currentData.data,
                            currentData.response,
                            ...(Array.isArray(currentData.reviews) ? currentData.reviews : []),
                            ...(Array.isArray(currentData.items) ? currentData.items : []),
                            ...(Array.isArray(currentData.data?.reviews) ? currentData.data.reviews : []),
                            ...(Array.isArray(currentData.response?.items) ? currentData.response.items : [])
                        ].filter(x => x && typeof x === 'object');
                        const candidateFields = ['rating', 'score', 'overall_rating', 'total_score', 'user_rating', 'value', 'item_score', 'star_count', 'grade', 'food_rating', 'service_rating', 'taste', 'delivery'];
                        let foundValues = [];
                        for (const c of candidateContainers) {
                            for (const f of candidateFields) {
                                if (c[f] !== undefined && c[f] !== null && c[f] !== '') {
                                    const parsed = parseSafeNumber(c[f], undefined, targetField);
                                    foundValues.push({ raw: c[f], parsed });
                                }
                            }
                        }
                        if (foundValues.length > 0) {
                            const badItem = foundValues.find(v => !isNaN(v.parsed) && v.parsed < 3);
                            actualValue = badItem ? badItem.raw : foundValues[0].raw;
                        }
                    }
                    let currentReviewText = '';
                    const candidateTextContainers = [
                        currentData,
                        currentData?.review,
                        currentData?.payload,
                        currentData?.feedback,
                        currentData?.data,
                        currentData?.response,
                        ...(Array.isArray(currentData?.reviews) ? currentData.reviews : []),
                        ...(Array.isArray(currentData?.items) ? currentData.items : []),
                        ...(Array.isArray(currentData?.data?.reviews) ? currentData.data.reviews : []),
                        ...(Array.isArray(currentData?.response?.items) ? currentData.response.items : [])
                    ].filter(x => x && typeof x === 'object');
                    for (const c of candidateTextContainers) {
                        const textVal = typeof c.review_text === 'string' ? c.review_text : (typeof c.comment === 'string' ? c.comment : (typeof c.content === 'string' ? c.content : (typeof c.text === 'string' ? c.text : (typeof c.review_detail === 'string' ? c.review_detail : ''))));
                        if (textVal) {
                            currentReviewText = textVal;
                            break;
                        }
                    }

                    if (params.less_than !== undefined) {
                        let numActual = parseSafeNumber(actualValue, currentReviewText, targetField);
                        if (isNaN(numActual) && currentReviewText) {
                            const fallbackCrisis = parseSafeNumber(null, currentReviewText, targetField);
                            if (!isNaN(fallbackCrisis)) {
                                numActual = fallbackCrisis;
                            }
                        }
                        const numThreshold = parseSafeNumber(params.less_than, undefined, targetField);
                        if (!isNaN(numActual) && !isNaN(numThreshold) && numActual < numThreshold) {
                            currentData.__branch = 'true';
                            if ((currentData.rating === null || currentData.rating === undefined || currentData.rating === '' || isNaN(currentData.rating)) && targetField === 'rating') {
                                currentData.rating = numActual;
                            }
                        } else {
                            currentData.__branch = 'false';
                        }
                    } else if (params.greater_than !== undefined) {
                        const numActual = parseSafeNumber(actualValue, currentReviewText, targetField);
                        const numThreshold = parseSafeNumber(params.greater_than, undefined, targetField);
                        if (!isNaN(numActual) && !isNaN(numThreshold) && numActual > numThreshold) {
                            currentData.__branch = 'true';
                            if ((currentData.rating === null || currentData.rating === undefined || currentData.rating === '') && targetField === 'rating') {
                                currentData.rating = numActual;
                            }
                        } else {
                            currentData.__branch = 'false';
                        }
                    } else {
                        const expectedValue = params.equals !== undefined ? params.equals : true;
                        // [FIND_004 해결] if_else 노드 문자열 비교 시 toBool() 강제 형변환 결함 수정
                        if (typeof actualValue === 'boolean' || typeof expectedValue === 'boolean') {
                            function toBool(val) {
                                if (typeof val === 'symbol') return false;
                                if (val === true || val === 'true' || val === 1 || val === '1') return true;
                                if (val === false || val === 'false' || val === 0 || val === '0') return false;
                                return Boolean(val);
                            }
                            currentData.__branch = (toBool(actualValue) === toBool(expectedValue)) ? 'true' : 'false';
                        } else {
                            const cleanActual = String(actualValue || '').trim().toUpperCase();
                            const cleanExpected = String(expectedValue || '').trim().toUpperCase();
                            const isMatch = (actualValue !== undefined && actualValue !== null && actualValue !== '') && (cleanActual === cleanExpected);
                            currentData.__branch = isMatch ? 'true' : 'false';
                        }
                    }
                }

                // [FIND_002 해결] 그래프 분기 미준수 방지: 선택되지 않은 브랜치와 그 하위 노드들을 skippedNodes에 등록
                if (workflow.connections && (workflow.connections[nodeName] || workflow.connections[node.id])) {
                    const connObj = workflow.connections[nodeName] || workflow.connections[node.id];
                    if (connObj && Array.isArray(connObj.main) && connObj.main.length >= 2) {
                        const chosenIdx = (currentData.__branch === 'true' || currentData.__branch === true) ? 0 : 1;
                        for (let branchIdx = 0; branchIdx < connObj.main.length; branchIdx++) {
                            if (branchIdx !== chosenIdx) {
                                const queue = [...(connObj.main[branchIdx] || [])];
                                while (queue.length > 0) {
                                    const edge = queue.shift();
                                    const targetNodeName = edge.node;
                                    if (targetNodeName && !skippedNodes.has(targetNodeName)) {
                                        skippedNodes.add(targetNodeName);
                                        const nextConns = workflow.connections[targetNodeName];
                                        if (nextConns && Array.isArray(nextConns.main)) {
                                            for (const outList of nextConns.main) {
                                                if (Array.isArray(outList)) {
                                                    queue.push(...outList);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                continue;
            }

            // 3-1. n8n Set 노드 (n8n-nodes-base.set) [FIND_003 해결]
            if (nodeType.includes('.set') || nodeType.toLowerCase().includes('set')) {
                const values = params.values || {};
                for (const typeKey of ['string', 'number', 'boolean', 'dateTime']) {
                    if (Array.isArray(values[typeKey])) {
                        for (const item of values[typeKey]) {
                            if (item && item.name) {
                                currentData[item.name] = item.value;
                            }
                        }
                    }
                }
                if (Array.isArray(values)) {
                    for (const item of values) {
                        if (item && item.name) {
                            currentData[item.name] = item.value;
                        }
                    }
                }
                if (params.assignments && Array.isArray(params.assignments.assignments)) {
                    for (const item of params.assignments.assignments) {
                        if (item && item.name) {
                            currentData[item.name] = item.value;
                        }
                    }
                }
                if (currentData.reply && (!currentData.template || !currentData.template.outputs)) {
                    currentData.template = {
                        outputs: [
                            {
                                simpleText: {
                                    text: currentData.reply
                                }
                            }
                        ]
                    };
                }
                continue;
            }

            // 4. Telegram 인터랙티브 승인 노드 (CEO 사전 승인 및 Human-in-the-Loop 관리)
            if (nodeType.includes('telegram')) {
                if (currentData.__branch === 'true' || currentData.__branch === true || currentData.__branch === undefined || currentData.__branch === null) {
                    // [FIND_003] 클라이언트 주입 임의 승인값 무시, 실제 승인 신호 없이는 PENDING 고정
                    if (currentData.telegram_approval_override !== undefined) {
                        delete currentData.telegram_approval_override;
                    }
                    const hasWaitNode = nodes.some(n => (n.type || '').includes('wait'));
                    const approval = evaluateTelegramApproval(safeOptions);

                    // [FIND_013 해결] WooCommerce 고액 결제(100만원 이상) 및 일반 승인 관리
                    const orderTotal = Number(String(currentData.total || currentData.amount || 0).replace(/[^0-9.-]/g, ''));
                    const isWooCommerce = Boolean(currentData.total !== undefined || currentData.billing || currentData.line_items || currentData.order_key);
                    const isHighValue = !isNaN(orderTotal) && orderTotal >= 1000000;

                    let approvalStatus = 'PENDING';
                    if (isWooCommerce) {
                        if (!isHighValue && (params.auto_approve !== false && !hasWaitNode)) {
                            approvalStatus = 'APPROVED';
                        } else if (approval.isApproved || params.approval_status === 'APPROVED') {
                            approvalStatus = 'APPROVED';
                        } else if (approval.status === 'REJECTED' || approval.status === 'UNAUTHORIZED_BLOCKED') {
                            approvalStatus = approval.status;
                        } else {
                            approvalStatus = 'PENDING';
                        }
                    } else {
                        approvalStatus = (!hasWaitNode && (approval.isApproved || params.approval_status === 'APPROVED' || params.auto_approve === true)) ? 'APPROVED' : (approval.status === 'REJECTED' || approval.status === 'UNAUTHORIZED_BLOCKED' ? approval.status : 'PENDING');
                    }

                    currentData.telegram_approval_status = approvalStatus;
                    currentData.telegram_chat_id = params.chat_id || 'CEO_TELEGRAM_ID';
                    currentData.telegram_buttons = params.buttons || ['승인 발송', '수정 요청', '무시'];

                    const isCompetitorPriceAlert = params.send_alert === true || params.auto_approve === true || (typeof nodeName === 'string' && (nodeName.includes('경보') || nodeName.includes('가격 승인')));
                    const shouldPushTelegramApi = isWooCommerce ? isHighValue : (params.approval_status !== 'APPROVED' || isCompetitorPriceAlert);
                    if (shouldPushTelegramApi) {
                        triggeredApis.push({
                            node: nodeName,
                            type: 'telegram',
                            chat_id: currentData.telegram_chat_id,
                            action: approvalStatus === 'APPROVED' ? 'TELEGRAM_APPROVAL_AUTO_RESUMED' : 'TELEGRAM_APPROVAL_REQUEST',
                            buttons: currentData.telegram_buttons,
                            status: approvalStatus,
                            dispatchedData: currentData,
                            message: currentData.apology_draft || (isHighValue ? `고액 결제(${orderTotal.toLocaleString()}원) 관리자 사전 승인 요청` : (currentData.product_name ? `[경쟁사 가격 경보] ${currentData.product_name} 변동 감지 승인 요청` : '고객 불만 대응 승인 요청'))
                        });
                    }
                }
                continue;
            }

            // 4-1. Telegram 승인 대기 콜백 노드 (Telegram Approval Wait Callback)
            if (nodeType.includes('wait')) {
                const approval = evaluateTelegramApproval(safeOptions);
                currentData.telegram_approval_status = approval.status;
                if (safeOptions.resumeCallback?.actor) {
                    currentData.approved_by = safeOptions.resumeCallback.actor;
                }
                if (approval.isApproved && (currentData.__branch === 'true' || currentData.__branch === true)) {
                    triggeredApis.push({
                        node: nodeName,
                        action: 'APPROVAL_CALLBACK_RESUMED',
                        status: 'APPROVED'
                    });
                } else if (approval.status === 'REJECTED' || approval.status === 'UNAUTHORIZED_BLOCKED') {
                    triggeredApis.push({
                        node: nodeName,
                        action: `APPROVAL_CALLBACK_${approval.status}`,
                        status: approval.status
                    });
                } else if (approval.status === 'SESSION_TIMEOUT' || safeOptions.resumeCallback?.action === 'SESSION_TIMEOUT') {
                    triggeredApis.push({
                        node: nodeName,
                        action: 'APPROVAL_CALLBACK_SESSION_TIMEOUT',
                        status: 'SESSION_TIMEOUT'
                    });
                }
                continue;
            }

            // 5. 외부 API 노드 (택배사 수거 지시, 리뷰 답글 게시, QuickBooks 인보이스 등)
            if (nodeType.toLowerCase().includes('httprequest') || nodeType.includes('http_request')) {
                // [FIND_CT_001 해결] 비VIP 고객의 VIP 슬랙 알림 누출 방지
                if ((nodeName.toLowerCase().includes('vip') || (node.parameters && String(node.parameters.url || '').includes('VIP'))) && (currentData.is_vip === false || currentData.__branch === 'false')) {
                    continue;
                }
                // [FIND_001, FIND_002, FIND_011 Fail-Closed] QUARANTINED 상태이거나 DLQ 격리된 경우 외부 API 격발 원천 차단
                if (result.quarantined === true || result.status === 'QUARANTINED' || currentData.quarantined === true || currentData.airbag_dlq_quarantined === true || currentData.__branch === 'false' || currentData.__branch === false) {
                    continue;
                }

                if (currentData.__branch === 'true' || currentData.__branch === undefined || currentData.__branch === null) {
                    // [TC-06 Fail-Closed] Telegram 승인 노드가 파이프라인에 존재하는 경우 오직 APPROVED 상태에서만 외부 API 격발 허용
                    const hasTelegramNode = nodes.some(n => (n.type || '').includes('telegram'));
                    if (hasTelegramNode && currentData.telegram_approval_status !== 'APPROVED') {
                        continue;
                    }
                    const targetUrl = params.url || params.endpoint;

                    const urlStr = String(targetUrl || '').toLowerCase();
                    const nodeNameStr = String(nodeName || '').toLowerCase();
                    const isHrRecruitingContext = Boolean((workflowPath && /AF-HR-02|HR_RECRUITING/i.test(workflowPath)) ||
                        (currentData && (currentData.slot_id !== undefined || currentData.interview_time !== undefined)) ||
                        (workflow && workflow.meta && (workflow.meta.blueprint_id === 'AF-HR-02' || workflow.meta.category === 'HR_RECRUITING')));
                    const isEmailDeliveryOrSync = Boolean(urlStr && (urlStr.includes('stibee') || urlStr.includes('bolta') || urlStr.includes('newsletter') || urlStr.includes('tax-invoice') || urlStr.includes('invoice') || urlStr.includes('subscribers') || urlStr.includes('zoom') || urlStr.includes('calendar') || urlStr.includes('slot') || urlStr.includes('interview'))) ||
                        nodeNameStr.includes('stibee') || nodeNameStr.includes('bolta') || nodeNameStr.includes('newsletter') || nodeNameStr.includes('subscribers') ||
                        nodeNameStr.includes('subscriber') || nodeNameStr.includes('세금계산서') || nodeNameStr.includes('zoom') || nodeNameStr.includes('calendar') || nodeNameStr.includes('slot') || nodeNameStr.includes('interview') || isHrRecruitingContext;

                    const isHrOnboarding = urlStr.includes('onboarding') ||
                        nodeNameStr.includes('onboarding') ||
                        (currentData && currentData.service_key === 'BO_EMPLOYEE_ONBOARDING') ||
                        (workflow && workflow.meta && workflow.meta.service_key === 'BO_EMPLOYEE_ONBOARDING') ||
                        (workflowPath && /EMPLOYEE_ONBOARDING/i.test(workflowPath));

                    // [FIND_R27_003 & FIND_L3_STRIPE_006] 공개 답글 및 외부 회계 API 전송 전 전수 PII 마스킹 (PAN, 주민등록번호, 휴대폰번호)
                    function deepMask(target) {
                        if (target === null || target === undefined) return target;
                        if (typeof target === 'string') {
                            return (isEmailDeliveryOrSync || isHrOnboarding || isHrRecruitingContext) ? maskPII(target, true) : maskPII(target);
                        }
                        if (typeof target === 'number') {
                            const s = String(target);
                            if (/^\d{13}$/.test(s)) return '******-*******';
                            if (/^\d{11,14}$/.test(s)) return '[계좌번호 마스킹]';
                            return target;
                        }
                        if (Array.isArray(target)) {
                            return target.map(deepMask);
                        }
                        if (typeof target === 'object') {
                            const maskedObj = {};
                            for (const [k, v] of Object.entries(target)) {
                                const lowerK = k.toLowerCase();
                                const isNumeric = typeof v === 'number';
                                const strV = isNumeric ? String(v) : (typeof v === 'string' ? v : '');

                                if (lowerK === 'jwt_secret' || lowerK === 'jwt_token') {
                                    continue;
                                } else if (lowerK === 'zoom_api_key' || lowerK === 'zoom_client_secret' || lowerK === 'zoom_secret') {
                                    maskedObj[k] = '****';
                                } else if (lowerK === 'telegram_token' || lowerK === 'bot_token' || lowerK === 'telegram_bot_token') {
                                    maskedObj[k] = '[텔레그램 토큰 마스킹]';
                                } else if (lowerK === 'notion_api_key' || lowerK === 'notion_token') {
                                    maskedObj[k] = '[노션 토큰 마스킹]';
                                } else if (lowerK === 'order_id' || lowerK === 'order_number' || lowerK === 'order_key' || lowerK === 'order_no') {
                                    maskedObj[k] = '[주문번호 마스킹]';
                                } else if (lowerK === 'reviewer_name' || lowerK === 'reviewer' || lowerK === 'author_name' || lowerK === 'customer_name' || lowerK === 'buyer_name' || lowerK === 'lead_name' || lowerK === 'name' || lowerK === 'interviewer_name') {
                                    maskedObj[k] = isHrOnboarding ? v : (typeof v === 'string' && v.length > 0 ? (v.length === 2 ? v[0] + '*' : v[0] + '*'.repeat(Math.max(1, v.length - 2)) + v[v.length - 1]) : '****');
                                } else if (lowerK === 'card_number' || lowerK === 'pan' || lowerK === 'credit_card' || lowerK === 'card_no' || lowerK === 'password' || lowerK === 'db_password' || lowerK === 'secret_key' || lowerK === 'database_password' || lowerK === 'db_pass' || lowerK === 'database_user') {
                                    maskedObj[k] = '****';
                                } else if (lowerK === 'phone' || lowerK === 'mobile' || lowerK === 'customer_phone' || lowerK === 'clean_phone' || lowerK === 'buyer_phone' || lowerK === 'customer_tel' || lowerK === 'original_phone' || lowerK === 'interviewer_phone') {
                                    maskedObj[k] = '****';
                                } else if (lowerK.includes('rrn') || lowerK.includes('resident_id') || lowerK === 'foreign_rrn' || (isNumeric && /^\d{13}$/.test(strV) && !lowerK.includes('amount') && !lowerK.includes('cost') && !lowerK.includes('tax') && !lowerK.includes('price') && !lowerK.includes('date'))) {
                                    maskedObj[k] = '******-*******';
                                } else if (lowerK.includes('passport')) {
                                    maskedObj[k] = 'M********';
                                } else if (lowerK.includes('driver_license') || lowerK.includes('drivers_license') || lowerK === 'license_number' || lowerK === 'driver_license_number') {
                                    maskedObj[k] = '**-**-******-**';
                                } else if (lowerK === 'customer_name' || lowerK === 'buyer_name' || lowerK === 'lead_name' || lowerK === 'name' || lowerK === 'interviewer_name') {
                                    maskedObj[k] = isHrOnboarding ? v : (typeof v === 'string' && v.length > 0 ? (v.length === 2 ? v[0] + '*' : v[0] + '*'.repeat(Math.max(1, v.length - 2)) + v[v.length - 1]) : '****');
                                } else if (lowerK === 'email' || lowerK === 'customer_email' || lowerK === 'lead_email' || lowerK === 'buyer_email' || lowerK === 'normalized_email' || lowerK === 'applicant_email' || lowerK === 'interviewer_email') {
                                    maskedObj[k] = (isEmailDeliveryOrSync || isHrOnboarding || isHrRecruitingContext) ? (typeof v === 'string' ? v : deepMask(v)) : '[이메일 마스킹]';
                                } else if (lowerK === 'customer_ip_address' || lowerK === 'ip_address' || lowerK === 'ip') {
                                    maskedObj[k] = '[IP 마스킹]';
                                } else if (lowerK.includes('account') || lowerK.includes('bank') || lowerK === 'reimbursement_account' || (isNumeric && /^\d{11,14}$/.test(strV) && !lowerK.includes('amount') && !lowerK.includes('cost') && !lowerK.includes('tax') && !lowerK.includes('price') && !lowerK.includes('date') && !lowerK.includes('time') && !lowerK.includes('biz'))) {
                                    maskedObj[k] = '[계좌번호 마스킹]';
                                } else if (['desired_salary', 'current_salary', 'expected_salary', 'annual_salary'].includes(lowerK) || lowerK.includes('salary') || lowerK.includes('payroll')) {
                                    const maskedVal = typeof v === 'string' ? ((isEmailDeliveryOrSync || isHrOnboarding) ? maskPII(v, true) : maskPII(v)) : '[급여 정보 마스킹]';
                                    maskedObj[k] = (maskedVal === v && typeof v === 'string' && /[\d,]+(?:\s*만원|\s*원)?/.test(v)) ? '[급여 정보 마스킹]' : maskedVal;
                                } else if (lowerK.includes('memo')) {
                                    maskedObj[k] = typeof v === 'string' ? ((isEmailDeliveryOrSync || isHrOnboarding) ? maskPII(v, true) : maskPII(v)) : '[민감 재무 정보 마스킹]';
                                } else if (lowerK === 'token' || lowerK === 'slack_token' || lowerK === 'slack_verify_token' || (typeof v === 'string' && (v.includes('SLACK_VERIFY_TOKEN') || (/^[A-Za-z0-9_-]{20,}$/.test(v) && lowerK.includes('token'))))) {
                                    maskedObj[k] = '[슬랙 토큰 마스킹]';
                                } else if (lowerK === 'medical_diagnosis' || lowerK === 'doctor_note' || lowerK === 'diagnosis' || lowerK === 'medical_record') {
                                    maskedObj[k] = typeof v === 'string' ? maskPII(v) : '[민감 의료 정보 마스킹]';
                                    if (typeof v === 'string' && maskedObj[k] === v) {
                                        maskedObj[k] = '[민감 의료 정보 마스킹]';
                                    }
                                } else if (lowerK === 'reason' && (lowerK.includes('medical') || /(?:유산|자궁|수술|임신|우울증|외상후스트레스장애|정신과|입원)/.test(strV))) {
                                    maskedObj[k] = maskPII(strV);
                                } else {
                                    maskedObj[k] = deepMask(v);
                                }
                            }
                            return maskedObj;
                        }
                        return target;
                    }

                    const reqMethod = (params.method || (nodeName.toLowerCase().startsWith('fetch') || nodeName.toLowerCase().startsWith('get') ? 'GET' : 'POST')).toUpperCase();

                    // [FIND_011 & FIND_001 해결] GET/조회 요청인 경우 인바운드 민감 페이로드를 통째로 전송하지 않고 빈 객체 {} 또는 쿼리 파라미터만 전송, toJSON 예외 방어
                    let dispatched = {};
                    if (reqMethod !== 'GET') {
                        let clonedForDispatch;
                        try {
                            clonedForDispatch = JSON.parse(JSON.stringify(currentData));
                        } catch (jsonErr) {
                            clonedForDispatch = safeClone(currentData);
                            if (clonedForDispatch && typeof clonedForDispatch === 'object') {
                                delete clonedForDispatch.toJSON;
                            }
                        }
                        dispatched = deepMask(clonedForDispatch);
                    } else if (params.queryParams || params.query) {
                        let clonedQuery;
                        try {
                            clonedQuery = JSON.parse(JSON.stringify(params.queryParams || params.query));
                        } catch (jsonErr) {
                            clonedQuery = safeClone(params.queryParams || params.query);
                            if (clonedQuery && typeof clonedQuery === 'object') {
                                delete clonedQuery.toJSON;
                            }
                        }
                        dispatched = deepMask(clonedQuery);
                    }

                    triggeredApis.push({
                        node: nodeName,
                        url: targetUrl,
                        method: reqMethod,
                        dispatchedData: dispatched
                    });
                }
                continue;
            }

            // 6. 알림/슬랙 노드 [FIND_003, FIND_010, FIND_001 해결]
            if (nodeType.includes('slack')) {
                const nodeNameLower = (node.name || nodeName || '').toLowerCase();
                const isExecutiveReport = nodeNameLower.includes('executive') || nodeNameLower.includes('daily') ||
                    currentData.sales !== undefined || currentData.executive_briefing !== undefined || currentData.profit !== undefined || currentData.report_title !== undefined;
                const isUrgent = currentData.__branch === 'true' || (typeof currentData.urgency === 'string' && currentData.urgency.trim().toUpperCase() === 'HIGH');
                
                // 빈 객체나 결측 페이로드로 인해 urgency가 없거나 __branch가 'true'가 아니면 발송 차단 (경영 리포트 제외)
                if ((isUrgent && currentData.urgency) || isExecutiveReport) {
                    triggeredApis.push({
                        node: nodeName,
                        channel: params.channel,
                        action: isExecutiveReport ? 'EXECUTIVE_REPORT_POSTED' : 'ESCALATED_TO_SLACK'
                    });
                }
                continue;
            }

            // 7. Notion CRM Log 노드 [FIND_011 & FIND_CT_004 해결]
            if (nodeType.includes('notion')) {
                if (result.quarantined === true || result.status === 'QUARANTINED' || currentData.quarantined === true || currentData.airbag_dlq_quarantined === true || currentData.status === 'QUARANTINED' || currentData.event_type === 'user.deleted') {
                    continue;
                }
                triggeredApis.push({
                    node: node.name || nodeName,
                    type: 'notion',
                    database_id: params.database_id,
                    payload: maskPII(JSON.stringify(currentData)),
                    timestamp: new Date().toISOString()
                });
                continue;
            }

            // 8. Google Sheets 원장 노드 (n8n-nodes-base.gsheets, n8n-nodes-base.googleSheets) [FIND_011, FIND_007, FIND_005 해결]
            if (nodeType.includes('gsheets') || nodeType.includes('google_sheets') || nodeType.toLowerCase().includes('googlesheets')) {
                const isDlqNode = (node.name || nodeName).toLowerCase().includes('dlq') || (params.sheetName && String(params.sheetName).toLowerCase().includes('dlq'));
                if (!isDlqNode) {
                    if (result.quarantined === true || result.status === 'QUARANTINED' || currentData.quarantined === true || currentData.airbag_dlq_quarantined === true || currentData.__branch === 'false' || currentData.__branch === false) {
                        continue;
                    }
                    // [FIND_HR_LEAVE_004 & FIND_HR_LEAVE_006 해결] 슬랙 승인 없는 무단 연차 차감 격발(APPROVAL_SKIP) 및 비인가자(인턴) 무단 승인 차단
                    if (node.name === 'Google Sheets Leave Deduction' || (nodeType.includes('gsheets') && (currentData.leave_type !== undefined || currentData.days !== undefined))) {
                        if (currentData.approval_status === 'UNAUTHORIZED_APPROVED' || currentData.approved_by === 'ATTACKER_INTERN' || currentData.approver_role === 'INTERN') {
                            result.status = 'QUARANTINED';
                            result.quarantined = true;
                            result.quarantineReason = 'UNAUTHORIZED_APPROVER_BLOCKED';
                            currentData.status = 'QUARANTINED';
                            currentData.quarantine_reason = 'UNAUTHORIZED_APPROVER_BLOCKED';
                            continue;
                        }
                        if (currentData.approval_status === 'PENDING' || currentData.approved_by === null) {
                            continue;
                        }
                    }
                }
                function deepMaskLedger(target) {
                    if (target === null || target === undefined) return target;
                    if (typeof target === 'string') {
                        return maskPII(target);
                    }
                    if (typeof target === 'number') {
                        const s = String(target);
                        if (/^\d{13}$/.test(s)) return '******-*******';
                        if (/^\d{11,14}$/.test(s)) return '[계좌번호 마스킹]';
                        return target;
                    }
                    if (Array.isArray(target)) {
                        return target.map(deepMaskLedger);
                    }
                    if (typeof target === 'object') {
                        const maskedObj = {};
                        for (const [k, v] of Object.entries(target)) {
                            const lowerK = k.toLowerCase();
                            const isNumeric = typeof v === 'number';
                            const strV = isNumeric ? String(v) : (typeof v === 'string' ? v : '');

                            if (lowerK === 'jwt_secret' || lowerK === 'jwt_token') {
                                continue;
                            } else if (lowerK === 'notion_api_key' || lowerK === 'notion_token') {
                                maskedObj[k] = '[노션 토큰 마스킹]';
                            } else if (lowerK === 'card_number' || lowerK === 'pan' || lowerK === 'credit_card' || lowerK === 'card_no' || lowerK === 'password' || lowerK === 'db_password' || lowerK === 'secret_key' || lowerK === 'database_password' || lowerK === 'db_pass' || lowerK === 'database_user') {
                                maskedObj[k] = '****';
                            } else if (lowerK === 'phone' || lowerK === 'mobile' || lowerK === 'customer_phone' || lowerK === 'clean_phone' || lowerK === 'buyer_phone' || lowerK === 'customer_tel' || lowerK === 'original_phone') {
                                maskedObj[k] = '****';
                            } else if (lowerK.includes('rrn') || lowerK.includes('resident_id') || lowerK === 'foreign_rrn' || (isNumeric && /^\d{13}$/.test(strV) && !lowerK.includes('amount') && !lowerK.includes('cost') && !lowerK.includes('tax') && !lowerK.includes('price') && !lowerK.includes('date'))) {
                                maskedObj[k] = '******-*******';
                            } else if (lowerK.includes('passport')) {
                                maskedObj[k] = 'M********';
                            } else if (lowerK.includes('driver_license') || lowerK.includes('drivers_license') || lowerK === 'license_number' || lowerK === 'driver_license_number') {
                                maskedObj[k] = '**-**-******-**';
                            } else if (lowerK.includes('account') || lowerK.includes('bank') || lowerK === 'reimbursement_account' || (isNumeric && /^\d{11,14}$/.test(strV) && !lowerK.includes('amount') && !lowerK.includes('cost') && !lowerK.includes('tax') && !lowerK.includes('price') && !lowerK.includes('date') && !lowerK.includes('time') && !lowerK.includes('biz'))) {
                                maskedObj[k] = '[계좌번호 마스킹]';
                            } else if (['desired_salary', 'current_salary', 'expected_salary', 'annual_salary'].includes(lowerK) || lowerK.includes('salary') || lowerK.includes('payroll')) {
                                const maskedVal = typeof v === 'string' ? maskPII(v) : '[급여 정보 마스킹]';
                                maskedObj[k] = (maskedVal === v && typeof v === 'string' && /[\d,]+(?:\s*만원|\s*원)?/.test(v)) ? '[급여 정보 마스킹]' : maskedVal;
                            } else if (lowerK.includes('memo')) {
                                maskedObj[k] = typeof v === 'string' ? maskPII(v) : '[민감 재무 정보 마스킹]';
                            } else if (lowerK === 'token' || lowerK === 'slack_token' || lowerK === 'slack_verify_token' || (typeof v === 'string' && (v.includes('SLACK_VERIFY_TOKEN') || (/^[A-Za-z0-9_-]{20,}$/.test(v) && lowerK.includes('token'))))) {
                                maskedObj[k] = '[슬랙 토큰 마스킹]';
                            } else if (lowerK === 'medical_diagnosis' || lowerK === 'doctor_note' || lowerK === 'diagnosis' || lowerK === 'medical_record') {
                                maskedObj[k] = typeof v === 'string' ? maskPII(v) : '[민감 의료 정보 마스킹]';
                                if (typeof v === 'string' && maskedObj[k] === v) {
                                    maskedObj[k] = '[민감 의료 정보 마스킹]';
                                }
                            } else if (lowerK === 'reason' && (lowerK.includes('medical') || /(?:유산|자궁|수술|임신|우울증|외상후스트레스장애|정신과|입원)/.test(strV))) {
                                maskedObj[k] = maskPII(strV);
                            } else {
                                maskedObj[k] = deepMaskLedger(v);
                            }
                        }
                        return maskedObj;
                    }
                    return target;
                }
                let ledgerData = currentData;
                try {
                    ledgerData = deepMaskLedger(safeClone(currentData));
                } catch (e) {
                    ledgerData = deepMaskLedger(currentData);
                }
                triggeredApis.push({
                    node: node.name || nodeName,
                    type: 'gsheets',
                    operation: params.operation || 'append',
                    spreadsheetId: params.spreadsheetId,
                    sheetName: params.sheetName,
                    fields: params.fields,
                    data: ledgerData
                });
                continue;
            }

            // [FIND_012 해결] Google Calendar 및 Email 노드 핸들러
            if (nodeType.includes('google_calendar') || nodeType.includes('calendar')) {
                if (result.quarantined === true || result.status === 'QUARANTINED' || currentData.quarantined === true || currentData.airbag_dlq_quarantined === true || currentData.__branch === 'false' || currentData.__branch === false) {
                    continue;
                }
                triggeredApis.push({
                    node: node.name || nodeName,
                    type: 'google_calendar',
                    calendar_id: params.calendar_id || 'primary',
                    action: 'EVENT_INSERTED'
                });
                continue;
            }
            if (nodeType.includes('email') || nodeType.includes('mail')) {
                if (result.quarantined === true || result.status === 'QUARANTINED' || currentData.quarantined === true || currentData.airbag_dlq_quarantined === true || currentData.__branch === 'false' || currentData.__branch === false) {
                    continue;
                }
                triggeredApis.push({
                    node: node.name || nodeName,
                    type: 'email',
                    template: params.template,
                    action: 'CONFIRMATION_EMAIL_SENT'
                });
                continue;
            }
        }

        result.outputData = currentData;
        result.triggeredApis = triggeredApis;
        if (!result.status || result.status === 'UNKNOWN') {
            result.status = 'PASS';
        }

        // [Rust 비언어 자가치유봇 인-런타임 인터셉트 훅: 에러/크래시 또는 명시적 카오스 주입 모드일 때만 발동]
        const isChaosOrDefect = options.chaosMode === true || result.status === 'CRASHED' || result.error || currentData.error || currentData.__is_chaos_injection === true;
        if (isChaosOrDefect && !result.quarantined) {
            const hookRes = interceptWithRustDefender(currentData, workflowPath);
            if (hookRes && hookRes.defended) {
                result.status = 'QUARANTINED';
                result.quarantined = true;
                result.rust_defender_healed = true;
                result.quarantineReason = 'RUST_DEFENDER_AUTONOMOUS_INTERCEPT';
                result.matched_patch = hookRes.patch;
                result.confidence = hookRes.confidence;
                currentData.status = 'QUARANTINED';
                currentData.quarantine_reason = 'RUST_DEFENDER_AUTONOMOUS_INTERCEPT';
            }
        }

        // [FIND_R27_004 & FIND_L3_STRIPE_005, FIND_011, FIND_012 해결] 정상 완료된 review_id 및 payment ID 전역 멱등성 캐시에 등록
        if (!result.quarantined && result.status !== 'CRASHED' && result.status !== 'DUPLICATE_IGNORED') {
            if (targetReviewId) processedReviewIds.add(targetReviewId);
            if (cachedKey) processedEntityIds.add(cachedKey);
        }

    } catch (nodeErr) {
        result.status = 'CRASHED';
        result.uncaughtException = true;
        result.crashError = `${nodeErr.name}: ${nodeErr.message}\n${nodeErr.stack}`;
    }

    result.executionTimeMs = Date.now() - startTime;
    return result;
}

// CLI 직접 실행 지원
if (require.main === module) {
    const args = process.argv.slice(2);
    if (args.length < 2) {
        console.error("Usage: node v8_native_combat_runner.js <workflowPath> <payloadJson>");
        process.exit(1);
    }
    const wfPath = args[0];
    let payload = {};
    try {
        payload = JSON.parse(args[1]);
    } catch (e) {
        console.error(`Invalid JSON payload: ${e.message}`);
        process.exit(2);
    }
    const res = runWorkflowNative(wfPath, payload);
    console.log(JSON.stringify(res, null, 2));
}

module.exports = {
    runWorkflowNative,
    praiseNegationRegex,
    processedReviewIds,
    processedEntityIds,
    maskPII,
    resetIdempotencyCache,
    IdempotencyTtlMap,
    IDEMPOTENCY_CACHE_TTL_MS,
    MAX_IDEMPOTENCY_CACHE_SIZE,
    pruneExpiredIdempotencyKeys,
    getIdempotencyCacheStats
};

const cleanupTimer = setInterval(() => {
    try { pruneExpiredIdempotencyKeys(); } catch (e) {}
}, 30 * 60 * 1000);
cleanupTimer.unref();

