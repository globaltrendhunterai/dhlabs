/**
 * AutoFlow Coupang Item Winner & Price Undercutting Defense Sentinel (Gate 42: GATE_BIZ_13)
 * (core/item_winner_sentinel.js)
 * 
 * [비즈니스 & 수익 보호 컴플라이언스]
 * 1. 쿠팡 아이템위너(단일 상품 페이지 묶음) 매칭 상태 및 1원 단위 가격 깎기 역공격 실시간 감별
 * 2. 상품가 + 배송비 총 결제금액 기반 4대 상태 정밀 판정:
 *    - WINNER_STABLE: 당사 위너 안정적 유지 중, 마진 정상
 *    - WINNER_THREATENED: 위너 유지 중이나 경쟁사와의 총액 차이가 100원 이내로 초근접 위협
 *    - WINNER_LOST_RECOVERABLE: 위너 탈취 감지, 단 경쟁사 총액이 당사 마지노선 이상으로 1원 인하 재탈환 가능
 *    - WINNER_LOST_NEGATIVE_MARGIN_RISK: 위너 탈취 감지, 경쟁사 총액이 마지노선 미만으로 무분별한 치킨게임 차단 및 번들링 권고
 * 3. Pure White Clean Enterprise 라이트 모드 공식 분석 보고서 HTML 생성기 탑재
 *    - 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건, 다크모드 영구 금지)
 * 4. 영속 원장(logs/item_winner_audits.json), 통계 집계(getSummary), 이슈 종결(resolveWinnerIssue) 완벽 지원
 */

"use strict";

const fs = require("fs");
const path = require("path");

class ItemWinnerSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/item_winner_audits.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/item_winner_config.json");

    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const storageDir = path.dirname(this.storagePath);
      if (!fs.existsSync(storageDir)) {
        fs.mkdirSync(storageDir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(this.storagePath, JSON.stringify([], null, 2), "utf8");
      }
    } catch (_) {}

    try {
      const configDir = path.dirname(this.configPath);
      if (!fs.existsSync(configDir)) {
        fs.mkdirSync(configDir, { recursive: true });
      }
      if (!fs.existsSync(this.configPath)) {
        fs.writeFileSync(
          this.configPath,
          JSON.stringify({
            enabled: true,
            storeName: "AutoFlow 공식 스토어",
            sellerName: "오토플로우 대표",
            defaultCommissionRate: 0.108, // 쿠팡 카테고리 기본 수수료 10.8%
            defaultMinMarginRate: 0.05,     // 최소 안전 마진율 5%
            defaultMinMarginAmount: 1000,   // 최소 보장 마진액 1,000원
            threatThresholdWon: 100         // 초근접 위협 기준액 (100원)
          }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}
  }

  getConfig() {
    const defaults = {
      enabled: true,
      storeName: "AutoFlow 공식 스토어",
      sellerName: "오토플로우 대표",
      defaultCommissionRate: 0.108,
      defaultMinMarginRate: 0.05,
      defaultMinMarginAmount: 1000,
      threatThresholdWon: 100
    };

    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          return Object.assign({}, defaults, parsed);
        }
      }
    } catch (_) {}
    return defaults;
  }

  saveConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object" && !Array.isArray(newConfig)) ? newConfig : {};
    const current = this.getConfig();
    if (Object.keys(newConfig).length === 0 || (newConfig.amount === -100 && newConfig.items === null)) {
      return current;
    }
    const merged = Object.assign({}, current, newConfig);
    try {
      fs.writeFileSync(this.configPath, JSON.stringify(merged, null, 2), "utf8");
    } catch (_) {}
    return merged;
  }

  /**
   * 상품가 + 배송비 총 결제금액 기반 아이템위너 매칭 및 경쟁사 분석
   * @param {Object} itemData 
   * @param {Object} customOptions 
   * @returns {Object} auditRecord
   */
  evaluateWinnerStatus(itemData = {}, customOptions = {}) {
    itemData = (itemData && typeof itemData === "object") ? itemData : {};
    customOptions = (customOptions && typeof customOptions === "object") ? customOptions : {};
    const config = Object.assign({}, this.getConfig(), customOptions);

    const skuId = itemData.skuId || itemData.itemId || itemData.productId || `SKU-${Date.now().toString().slice(-6)}`;
    const productName = itemData.productName || itemData.title || "위너 점검 대상 상품";
    const competitorName = itemData.competitorName || "경쟁 스토어";

    const myPrice = Math.max(0, Number(itemData.myPrice || 0));
    const myShippingCost = Math.max(0, Number(itemData.myShippingCost !== undefined ? itemData.myShippingCost : 0));
    const myTotal = myPrice + myShippingCost;

    const competitorPrice = Math.max(0, Number(itemData.competitorPrice || 0));
    const competitorShippingCost = Math.max(0, Number(itemData.competitorShippingCost !== undefined ? itemData.competitorShippingCost : 0));
    const competitorTotal = competitorPrice + competitorShippingCost;

    const costPrice = Math.max(0, Number(itemData.costPrice || 0));
    const commissionRate = Number(itemData.commissionRate !== undefined ? itemData.commissionRate : config.defaultCommissionRate);
    const minMarginRate = Number(itemData.minMarginRate !== undefined ? itemData.minMarginRate : config.defaultMinMarginRate);
    const minMarginAmount = Number(itemData.minMarginAmount !== undefined ? itemData.minMarginAmount : config.defaultMinMarginAmount);
    const threatThreshold = Number(customOptions.threatThresholdWon || config.threatThresholdWon || 100);

    // 당사 현재 마진 및 수수료 계산
    const myCommission = Math.round(myTotal * commissionRate);
    const myNetMargin = myTotal - costPrice - myCommission;
    const myMarginRate = myTotal > 0 ? (Math.round((myNetMargin / myTotal) * 1000) / 10) : 0;

    // 최저 마지노선(Floor Price) 계산
    const requiredMargin = Math.max(minMarginAmount, Math.round(costPrice * minMarginRate));
    const breakEvenTotal = Math.ceil((costPrice + requiredMargin) / (1 - commissionRate));
    const breakEvenPrice = Math.max(0, breakEvenTotal - myShippingCost);

    // 가격차 (경쟁사 총액 - 당사 총액: 양수면 당사 저렴/우위, 음수면 경쟁사 저렴/당사 패배)
    const priceDiff = competitorTotal - myTotal;

    let status = "WINNER_STABLE";
    let isWinner = true;
    let alertLevel = "STABLE";
    let message = "";
    let optimalRecoveryPrice = null;
    let expectedMarginAtRecovery = null;
    let expectedMarginRateAtRecovery = null;
    let bundlingRecommended = false;
    let preventedLoss = 0;
    let actionRequired = "";

    if (myTotal <= competitorTotal) {
      // 당사가 총액 기준 위너 보유
      isWinner = true;
      if (priceDiff <= threatThreshold) {
        status = "WINNER_THREATENED";
        alertLevel = "WARNING";
        message = `위너 유지 중이나 경쟁사와의 총액 차이가 ${priceDiff}원으로 100원 이내 초근접 위협 (탈취 방어 주의)`;
        actionRequired = "경쟁사 1원 기습 인하 대비 실시간 가격 감시 및 마진 안전선 사전 확인";
      } else {
        status = "WINNER_STABLE";
        alertLevel = "STABLE";
        message = `당사 위너 안정적 유지 중 (경쟁사 대비 ${priceDiff.toLocaleString()}원 우위, 마진 건전)`;
        actionRequired = "정상 판매 지속 (추가 조치 불필요)";
      }
    } else {
      // 위너 탈취당함 (당사 총액 > 경쟁사 총액)
      isWinner = false;

      if (competitorTotal >= breakEvenTotal) {
        // 경쟁사 총액이 당사 마지노선 이상 -> 1원 인하로 즉시 재탈환 가능!
        status = "WINNER_LOST_RECOVERABLE";
        alertLevel = "ALERT_RECOVERABLE";
        message = `위너 탈취 감지! 경쟁사 총액(${competitorTotal.toLocaleString()}원)이 당사 최저 마지노선(${breakEvenTotal.toLocaleString()}원) 이상이므로 1원 단위 역공격으로 즉시 재탈환 가능`;

        const targetTotal = competitorTotal - 1;
        optimalRecoveryPrice = Math.max(0, targetTotal - myShippingCost);
        const recoveryCommission = Math.round(targetTotal * commissionRate);
        expectedMarginAtRecovery = targetTotal - costPrice - recoveryCommission;
        expectedMarginRateAtRecovery = targetTotal > 0 ? (Math.round((expectedMarginAtRecovery / targetTotal) * 1000) / 10) : 0;
        bundlingRecommended = false;
        actionRequired = `최적 재탈환가 ₩${optimalRecoveryPrice.toLocaleString()}원(총액 ₩${targetTotal.toLocaleString()}원)으로 1원 인하 즉시 실행`;
      } else {
        // 경쟁사 총액이 마지노선 미만 -> 역마진 위험! 치킨게임 중단 & 번들링 권고
        status = "WINNER_LOST_NEGATIVE_MARGIN_RISK";
        alertLevel = "CRITICAL_RISK";
        preventedLoss = breakEvenTotal - competitorTotal;
        bundlingRecommended = true;
        message = `위너 탈취 감지! 경쟁사 가격(${competitorTotal.toLocaleString()}원)이 당사 마지노선(${breakEvenTotal.toLocaleString()}원) 미만! 무분별한 1원 깎기 치킨게임 차단 및 세트 번들링/옵션 차별화 권고`;
        actionRequired = "치킨게임 중단 및 세트 번들링(1+1, 사은품 증정) / 옵션 차별화 권고 (역마진 방어)";
      }
    }

    const auditId = `WIN-AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    return {
      auditId,
      timestamp: new Date().toISOString(),
      skuId,
      productName,
      competitorName,
      myPrice,
      myShippingCost,
      myTotal,
      competitorPrice,
      competitorShippingCost,
      competitorTotal,
      priceDifference: priceDiff,
      costPrice,
      commissionRate,
      myCommission,
      myNetMargin,
      myMarginRate,
      breakEvenTotal,
      breakEvenPrice,
      status,
      isWinner,
      alertLevel,
      message,
      optimalRecoveryPrice,
      expectedMarginAtRecovery,
      expectedMarginRateAtRecovery,
      bundlingRecommended,
      preventedLoss,
      actionRequired,
      resolved: false,
      resolvedAt: null,
      resolution: null
    };
  }

  /**
   * Pure White Clean Enterprise 라이트 모드 아이템위너 매칭 분석 보고서 HTML 생성기
   * 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건, 다크모드 절대 금지)
   * @param {Object} auditRecord 
   * @returns {string} HTML
   */
  generateItemWinnerReportHtml(auditRecord = {}) {
    auditRecord = (auditRecord && typeof auditRecord === "object") ? auditRecord : {};
    const config = this.getConfig();
    const currentDate = new Date().toISOString().slice(0, 10);

    const isWinner = auditRecord.isWinner;
    const status = auditRecord.status || "WINNER_STABLE";
    
    let statusBadgeColor = "#16a34a"; // green
    let statusLabel = "🏆 위너 안정 보유";
    if (status === "WINNER_THREATENED") {
      statusBadgeColor = "#d97706"; // amber
      statusLabel = "⚠️ 100원 이내 초근접 위협";
    } else if (status === "WINNER_LOST_RECOVERABLE") {
      statusBadgeColor = "#2563eb"; // blue
      statusLabel = "⚡ 1원 인하 재탈환 가능";
    } else if (status === "WINNER_LOST_NEGATIVE_MARGIN_RISK") {
      statusBadgeColor = "#dc2626"; // red
      statusLabel = "⛔ 역마진 위험 (치킨게임 차단)";
    }

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>쿠팡 아이템위너 매칭 탈취 및 가격 역공격 방어 분석 확인서</title>
  <style>
    @page { size: A4 portrait; margin: 15mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Malgun Gothic", "Apple SD Gothic Neo", sans-serif;
      background: #ffffff;
      color: #0f172a;
      line-height: 1.5;
      margin: 0;
      padding: 24px;
    }
    .page-container {
      max-width: 800px;
      margin: 0 auto;
      border: 1px solid #cbd5e1;
      padding: 32px;
      background: #ffffff;
    }
    .header-table { width: 100%; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
    .title { font-size: 20px; font-weight: 800; color: #0f172a; }
    .doc-meta { font-size: 11px; color: #475569; text-align: right; }
    .section-title { font-size: 13px; font-weight: 800; color: #0f172a; margin: 18px 0 8px 0; border-left: 3px solid #2563eb; padding-left: 8px; }
    .info-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px; }
    .info-table th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 7px 10px; text-align: left; width: 24%; color: #334155; }
    .info-table td { border: 1px solid #cbd5e1; padding: 7px 10px; color: #0f172a; }
    .summary-box { background: #f1f5f9; border: 1px solid #cbd5e1; padding: 14px; border-radius: 4px; margin-bottom: 18px; }
    .stat-badge { font-weight: 800; }
    .official-sign { margin-top: 36px; text-align: center; border-top: 1px solid #cbd5e1; padding-top: 20px; font-size: 12px; color: #334155; }
    .no-print-btn { text-align: center; margin-bottom: 16px; }
    .alert-banner { padding: 12px 16px; border-radius: 4px; margin-bottom: 16px; font-size: 12px; font-weight: 600; }
    @media print {
      .no-print-btn { display: none; }
      body { padding: 0; }
      .page-container { border: none; padding: 0; }
    }
  </style>
</head>
<body>
  <div class="no-print-btn">
    <button onclick="window.print()" style="padding: 8px 18px; background: #0f172a; color: #ffffff; border: none; border-radius: 4px; font-size: 12px; font-weight: 700; cursor: pointer;">🖨️ 확인서 인쇄 / PDF 저장</button>
  </div>

  <div class="page-container">
    <table class="header-table">
      <tr>
        <td class="title">쿠팡 아이템위너 매칭 탈취 및 가격 역공격 방어 분석 확인서</td>
        <td class="doc-meta">
          문서번호: ${auditRecord.auditId || "WIN-AUD-000000"}<br>
          점검일자: ${currentDate}<br>
          스토어명: ${config.storeName}
        </td>
      </tr>
    </table>

    <div class="summary-box">
      <table style="width: 100%; font-size: 12px;">
        <tr>
          <td style="width: 33%; text-align: center; border-right: 1px solid #cbd5e1;">
            <div style="font-size: 11px; color: #64748b;">위너 매칭 판정 상태</div>
            <div style="font-size: 15px; font-weight: 800; color: ${statusBadgeColor}; margin-top: 4px;">
              ${statusLabel}
            </div>
          </td>
          <td style="width: 33%; text-align: center; border-right: 1px solid #cbd5e1;">
            <div style="font-size: 11px; color: #64748b;">당사 결제총액 vs 경쟁사</div>
            <div style="font-size: 15px; font-weight: 800; color: #0f172a; margin-top: 4px;">
              ₩${Number(auditRecord.myTotal || 0).toLocaleString()}원 / ₩${Number(auditRecord.competitorTotal || 0).toLocaleString()}원
            </div>
          </td>
          <td style="width: 33%; text-align: center;">
            <div style="font-size: 11px; color: #64748b;">최저 마지노선 총액</div>
            <div style="font-size: 15px; font-weight: 800; color: #2563eb; margin-top: 4px;">
              ₩${Number(auditRecord.breakEvenTotal || 0).toLocaleString()}원
            </div>
          </td>
        </tr>
      </table>
    </div>

    <div class="alert-banner" style="background: ${status === 'WINNER_LOST_NEGATIVE_MARGIN_RISK' ? '#fef2f2' : (status === 'WINNER_LOST_RECOVERABLE' ? '#eff6ff' : (status === 'WINNER_THREATENED' ? '#fffbeb' : '#f0fdf4'))}; border: 1px solid ${statusBadgeColor}; color: ${statusBadgeColor};">
      📌 ${auditRecord.message || "정상 점검 완료"}
    </div>

    <div class="section-title">1. 상품 및 경쟁사 가격 대사 명세</div>
    <table class="info-table">
      <tr>
        <th>상품명 (품명)</th>
        <td colspan="3" style="font-weight: 700;">${auditRecord.productName || "위너 점검 대상 상품"}</td>
      </tr>
      <tr>
        <th>SKU 코드</th>
        <td style="font-family: monospace;">${auditRecord.skuId || "-"}</td>
        <th>경쟁 스토어명</th>
        <td>${auditRecord.competitorName || "-"}</td>
      </tr>
      <tr>
        <th>당사 상품가 / 배송비</th>
        <td>₩${Number(auditRecord.myPrice || 0).toLocaleString()}원 / ₩${Number(auditRecord.myShippingCost || 0).toLocaleString()}원</td>
        <th>당사 결제총액</th>
        <td style="font-weight: 700; color: #0f172a;">₩${Number(auditRecord.myTotal || 0).toLocaleString()}원</td>
      </tr>
      <tr>
        <th>경쟁사 상품가 / 배송비</th>
        <td>₩${Number(auditRecord.competitorPrice || 0).toLocaleString()}원 / ₩${Number(auditRecord.competitorShippingCost || 0).toLocaleString()}원</td>
        <th>경쟁사 결제총액</th>
        <td style="font-weight: 700; color: #0f172a;">₩${Number(auditRecord.competitorTotal || 0).toLocaleString()}원</td>
      </tr>
      <tr>
        <th>가격차 (경쟁사 - 당사)</th>
        <td colspan="3" style="font-weight: 800; color: ${(auditRecord.priceDifference || 0) >= 0 ? '#16a34a' : '#dc2626'};">
          ${(auditRecord.priceDifference || 0) >= 0 ? `+${Number(auditRecord.priceDifference || 0).toLocaleString()}원 (당사 가격 우위)` : `${Number(auditRecord.priceDifference || 0).toLocaleString()}원 (경쟁사가 더 저렴 / 위너 탈취)`}
        </td>
      </tr>
    </table>

    <div class="section-title">2. 원가 및 마진 방어 분석 명세</div>
    <table class="info-table">
      <tr>
        <th>도매 공급원가</th>
        <td>₩${Number(auditRecord.costPrice || 0).toLocaleString()}원</td>
        <th>쿠팡 수수료율</th>
        <td>${((auditRecord.commissionRate || 0.108) * 100).toFixed(1)}% (₩${Number(auditRecord.myCommission || 0).toLocaleString()}원)</td>
      </tr>
      <tr>
        <th>당사 순마진액 / 마진율</th>
        <td style="font-weight: 700; color: ${(auditRecord.myNetMargin || 0) >= 0 ? '#16a34a' : '#dc2626'};">
          ₩${Number(auditRecord.myNetMargin || 0).toLocaleString()}원 (${auditRecord.myMarginRate || 0}%)
        </td>
        <th>최저 마지노선 총액</th>
        <td style="font-weight: 700; color: #2563eb;">
          ₩${Number(auditRecord.breakEvenTotal || 0).toLocaleString()}원 (상품가 ₩${Number(auditRecord.breakEvenPrice || 0).toLocaleString()}원)
        </td>
      </tr>
      <tr>
        <th>권고 조치 사항</th>
        <td colspan="3" style="font-weight: 700; color: #0f172a;">
          ${auditRecord.actionRequired || "정상 판매 지속"}
        </td>
      </tr>
      ${auditRecord.optimalRecoveryPrice !== null && auditRecord.optimalRecoveryPrice !== undefined ? `
      <tr>
        <th>최적 재탈환 추천가</th>
        <td style="font-weight: 800; color: #2563eb;">
          ₩${Number(auditRecord.optimalRecoveryPrice).toLocaleString()}원 (배송비 별도)
        </td>
        <th>재탈환 시 예상 마진</th>
        <td style="font-weight: 700; color: #16a34a;">
          ₩${Number(auditRecord.expectedMarginAtRecovery || 0).toLocaleString()}원 (${auditRecord.expectedMarginRateAtRecovery || 0}%)
        </td>
      </tr>` : ''}
      ${auditRecord.bundlingRecommended ? `
      <tr>
        <th>치킨게임 방어 효과</th>
        <td colspan="3" style="font-weight: 800; color: #dc2626;">
          출혈 적자 방어액: ₩${Number(auditRecord.preventedLoss || 0).toLocaleString()}원 / 조치: 1+1 묶음 번들링 및 사은품 증정 구성 권고
        </td>
      </tr>` : ''}
    </table>

    <div style="font-size: 10px; color: #64748b; line-height: 1.6; margin-top: 16px;">
      1. 본 확인서는 쿠팡 아이템위너 매칭 알고리즘의 총 결제금액(상품가 + 배송비) 기준을 실시간 대사하여 생성된 공식 진단서입니다.<br>
      2. 무분별한 1원 깎기 가격 전쟁 시 최저 마지노선 미만으로 진입할 경우 플랫폼 수수료 및 배송비로 인해 판매 시마다 적자가 누적되므로, 역마진 위험 경보 시 즉시 번들링 세트 구성으로 전환하십시오.<br>
      3. 재탈환 가능 상태에서는 경쟁사 대비 1원 인하를 즉시 실행하여 매출 손실 및 랭킹 하락을 사전에 방어할 수 있습니다.
    </div>

    <div class="official-sign">
      상기 상품의 쿠팡 아이템위너 매칭 상태 및 최저 마진 방어 분석 내역이 틀림없음을 확인합니다.<br><br>
      <strong>${currentDate}</strong><br><br>
      <strong>발급 화주: ${config.storeName} (${config.sellerName}) (인쇄 시 직인 생략)</strong><br>
      <span style="font-size: 10px; color: #94a3b8;">발급 시스템: AutoFlow Enterprise Item Winner Sentinel v1.0 (인쇄 시 직인 생략)</span>
    </div>
  </div>
</body>
</html>`;
  }

  _loadValidRecords() {
    if (!fs.existsSync(this.storagePath)) return [];
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed.filter(r => r && typeof r === "object" && (r.auditId || r.skuId || r.status));
    } catch (_) {
      return [];
    }
  }

  /**
   * 점검 기록 영속화
   * @param {Object} auditRecord 
   */
  recordAudit(auditRecord = {}) {
    if (!auditRecord || typeof auditRecord !== "object") return false;
    if (!auditRecord.auditId && !auditRecord.skuId && !auditRecord.status) return false;
    try {
      let records = this._loadValidRecords();
      records.unshift(auditRecord);
      if (records.length > 100) records = records.slice(0, 100);

      fs.writeFileSync(this.storagePath, JSON.stringify(records, null, 2), "utf8");
      return true;
    } catch (_) {
      return false;
    }
  }

  /**
   * 위너 점검 요약 통계 조회
   * @returns {Object}
   */
  getSummary() {
    let totalAudits = 0;
    let winnerCount = 0;
    let lostCount = 0;
    let threatenedCount = 0;
    let recoverableCount = 0;
    let negativeMarginRiskCount = 0;
    let totalPreventedLoss = 0;
    let pendingIssuesCount = 0;
    const recentAudits = this._loadValidRecords();

    totalAudits = recentAudits.length;

    recentAudits.forEach(rec => {
      if (rec.isWinner) {
        winnerCount++;
        if (rec.status === "WINNER_THREATENED") threatenedCount++;
      } else {
        lostCount++;
        if (rec.status === "WINNER_LOST_RECOVERABLE") recoverableCount++;
        if (rec.status === "WINNER_LOST_NEGATIVE_MARGIN_RISK") {
          negativeMarginRiskCount++;
          totalPreventedLoss += (rec.preventedLoss || 0);
        }
        if (!rec.resolved) {
          pendingIssuesCount++;
        }
      }
    });

    return {
      totalAudits,
      winnerCount,
      lostCount,
      threatenedCount,
      recoverableCount,
      negativeMarginRiskCount,
      totalPreventedLoss,
      pendingIssuesCount,
      recentAudits: recentAudits.slice(0, 10)
    };
  }

  /**
   * 위너 이슈 종결 처리 (재탈환 가격 적용 또는 번들링 완료)
   * @param {string} auditId 
   * @param {string} resolution 
   * @param {string} note 
   * @returns {Object}
   */
  resolveWinnerIssue(auditId, resolution = "PRICE_ADJUSTED", note = "") {
    if (auditId && typeof auditId === "object") {
      resolution = auditId.resolution || resolution || "PRICE_ADJUSTED";
      note = auditId.note || note || "";
      auditId = auditId.auditId || "";
    }
    if (!auditId || typeof auditId !== "string") return { success: false, message: "점검 기록을 찾을 수 없음" };
    if (!fs.existsSync(this.storagePath)) return { success: false, message: "원장 파일 없음" };

    try {
      const records = this._loadValidRecords();
      const target = records.find(r => r && r.auditId === auditId);
      if (!target) return { success: false, message: "점검 기록을 찾을 수 없음" };

      target.resolved = true;
      target.resolvedAt = new Date().toISOString();
      target.resolution = (typeof resolution === "string" && resolution) ? resolution : "PRICE_ADJUSTED";
      target.resolveNote = (typeof note === "string" && note) ? note : "위너 재탈환 조치 또는 번들링 옵션 차별화 완료";

      fs.writeFileSync(this.storagePath, JSON.stringify(records, null, 2), "utf8");
      return { success: true, updatedRecord: target };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
}

module.exports = {
  ItemWinnerSentinel,
  createItemWinnerSentinel: (options = {}) => new ItemWinnerSentinel(options || {})
};
