/**
 * core/order_dedup_sentinel.js
 * 
 * AutoFlow CS 제로화 & 멱등성 수호 센티널 (Order Deduplication & Batch Rollup Sentinel)
 * 
 * 1. 2,000건 LRU 링 버퍼 기반 멱등성(Idempotency) 보장: 중복 주문 알림 100% 원천 차단
 * 2. 주문 폭주(Flash Sale) 스마트 묶음 요약(Smart Batch Rollup):
 *    1회 수집 시 주문 4건 이상 폭주 시 1건의 정갈한 롤업 요약으로 병합 발송하여
 *    메신저 429 Too Many Requests(차단) 및 고객 휴대폰 알림 폭탄 원천 방어.
 */

class OrderDedupSentinel {
  constructor(maxSize = 2000) {
    this.maxSize = maxSize;
    this.historyQueue = [];
    this.historySet = new Set();
  }

  /**
   * 주문번호 중복 검사 및 신규 주문 등록
   * @param {string|number} orderId 주문번호
   * @returns {boolean} true: 중복 주문 (이미 알림 발송됨), false: 신규 주문
   */
  isDuplicate(orderId) {
    if (!orderId) return false;
    const cleanId = String(orderId).trim();
    if (this.historySet.has(cleanId)) {
      return true;
    }

    // 신규 등록
    this.historySet.add(cleanId);
    this.historyQueue.push(cleanId);

    // 링 버퍼 크기 유지
    if (this.historyQueue.length > this.maxSize) {
      const oldest = this.historyQueue.shift();
      this.historySet.delete(oldest);
    }

    return false;
  }

  /**
   * 복수 주문 중 중복을 걸러낸 신규 주문 목록 추출
   * @param {Array} orders 주문 객체 배열 (orderId 필드 필수)
   * @returns {Array} 신규 주문 객체 배열
   */
  filterNewOrders(orders = []) {
    if (!Array.isArray(orders)) return [];
    return orders.filter(order => {
      const id = order.orderId || order.id || order.order_id;
      return !this.isDuplicate(id);
    });
  }

  /**
   * 주문 폭주 감지 및 스마트 묶음 포맷팅
   * @param {Array} newOrders 중복 제거된 신규 주문 목록
   * @param {Object} options 설정 (smartBatchThreshold: 4)
   * @returns {Object} { isBatchRollup: boolean, messageCount: number, messages: string[] }
   */
  formatBatchNotification(newOrders = [], options = {}) {
    const threshold = options.smartBatchThreshold || 4;

    if (!Array.isArray(newOrders) || newOrders.length === 0) {
      return { isBatchRollup: false, messageCount: 0, messages: [] };
    }

    // 1) 임계치 미만: 개별 주문 상세 알림
    if (newOrders.length < threshold) {
      const messages = newOrders.map(o => {
        const id = o.orderId || o.id || "ORD-UNKNOWN";
        const title = o.productName || o.title || "주문 상품";
        const amt = Number(o.orderPrice || o.amount || 0).toLocaleString();
        return `🛒 [쿠팡 신규 주문] ${title} (${amt}원) / 주문번호: ${id}`;
      });
      return { isBatchRollup: false, messageCount: messages.length, messages };
    }

    // 2) 임계치 이상: 주문 폭주 스마트 묶음 요약 알림 (1건으로 집약)
    const count = newOrders.length;
    let totalAmt = 0;
    const sampleItems = [];

    newOrders.forEach((o, idx) => {
      totalAmt += Number(o.orderPrice || o.amount || 0);
      if (idx < 2) {
        const t = o.productName || o.title || "주문 상품";
        sampleItems.push(`- ${t}`);
      }
    });

    const formattedTotal = totalAmt.toLocaleString();
    const rollupMessage = `⚡ [AutoFlow 주문 폭주 스마트 안심 요약]
대표님, 방금 신규 주문 ${count}건이 일시에 쇄도했습니다! 🎉
• 총 결제금액: ${formattedTotal}원
• 주요 상품:
${sampleItems.join("\n")}${count > 2 ? `\n- 외 ${count - 2}건` : ""}

💡 메신저 도배 방지 및 플랫폼 레이트리미트(429) 보호를 위해 1건으로 요약 발송되었습니다.
상세 주문 내역 및 송장 처리는 쿠팡 WING에서 확인해 주세요.`;

    return {
      isBatchRollup: true,
      messageCount: 1,
      messages: [rollupMessage]
    };
  }

  /**
   * 메모리 캐시 초기화 (테스트 또는 공장 초기화 시 호출)
   */
  clear() {
    this.historyQueue = [];
    this.historySet.clear();
  }
}

const defaultSentinel = new OrderDedupSentinel(2000);

module.exports = {
  OrderDedupSentinel,
  orderDedupSentinel: defaultSentinel
};
