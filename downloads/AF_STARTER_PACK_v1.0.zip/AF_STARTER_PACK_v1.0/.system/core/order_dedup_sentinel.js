/**
 * core/order_dedup_sentinel.js
 *
 * AutoFlow 범용 워크플로우 무중단·충돌 중재 엔진 커널
 * (Universal Workflow Arbitration & Non-Stop Engine / Enterprise Cross-Workflow Arbitration Kernel)
 *
 * [핵심 본질 (Core Identity)]
 * 당사가 판매하는 제품은 단순 쇼핑몰 전용 툴이 아니라,
 * **"전 산업·전 업무 도메인(마케팅·영업/CRM·회계/세금계산서·인사/백오피스·고객CS·콘텐츠/SNS·커머스 등)의 n8n 워크플로우 완제품 +
 *   한 기업 내에서 수십 개의 워크플로우가 동시에 돌아갈 때 발생하는 충돌을 중재하고 무중단 가동을 보장하는 상주형 엔진(AutoFlow Engine)"**이다.
 *
 * 1. 범용 엔티티 식별자 정규화 (`entityKey` / `eventId`):
 *    - 쇼핑몰의 `orderId`는 수많은 도메인 중 하나의 사례일 뿐이며,
 *      `lead_id`(영업 리드), `invoice_id`/`voucher_id`(세금계산서·회계전표), `ticket_id`/`inquiry_id`(CS 문의),
 *      `post_id`/`campaign_id`(마케팅·SNS 발행), `employee_id`/`contract_id`(인사·백오피스), `order_id`(커머스) 등
 *      모든 도메인 식별자를 단일 `entityKey`로 수용 (기존 `orderId` 100% 하위 호환).
 * 2. 전 도메인 다중 워크플로우 충돌 매트릭스 (Universal Cross-Workflow Conflict Matrix):
 *    - ① [동일 대상 중복 발송·연락 충돌 (`OUTBOUND_MESSAGE_DEDUP & PRIORITY`)]:
 *      영업 리드 인입 시 `[워크플로우 A: 기본 문자/이메일]`과 `[워크플로우 B: 알림톡/맞춤 제안서]`가 겹치거나,
 *      사내 슬랙/텔레그램 경보가 여러 워크플로우에서 동시에 터질 때 `(domain + entityKey + recipient + intentType)` 기준으로
 *      상위 우선순위 채널만 1회 발송하고 하위/중복 발송은 자동 Skip.
 *    - ② [상반된 비즈니스 의도 상호 배타 (`CONTRA_INTENT_MUTEX`)]:
 *      • CRM/마케팅: 고객·리드가 `[수신거부/해지/환불/클레임(OPT_OUT / CHURN / DISPUTE)]` 상태일 때 다른 마케팅 워크플로우의 `[프로모션/리뷰독려/업셀링/콜드메일]` 발송 원천 차단.
 *      • 회계/재무/인사/출고: `[결제미승인/전표오류/정산불일치/독소조항/보류(HOLD / QUARANTINE / UNAPPROVED / RECON_MISMATCH)]` 상태인 건에 대해 다른 자동화 워크플로우의 `[세금계산서 자동발행 / 자동송금 / 장부확정 / 권한부여 / 자동출고]` 실행 차단 & 이미 확정·발행·출고된 건의 단순 삭제/취소 차단(수정세금계산서·역분개·반품회수 보상 플로우 전환).
 *      • 콘텐츠/SNS: 동일 소스 글·영상을 여러 발행 워크플로우가 동시에 같은 채널에 중복 업로드하려는 충돌 차단.
 *    - ③ [공유 리소스/DB/시트 동시 쓰기 충돌 (`SHARED_RESOURCE_WRITE_LOCK`)]:
 *      회계·영업·인사·재고 워크플로우가 동일한 구글 시트/노션/에어테이블/DB 테이블의 같은 행·셀을 동시에 수정할 때 원자적 직렬화(Mutex Queue) 및 비파괴 병합(빈값 덮어쓰기 방지)으로 데이터 유실 원천 차단.
 *    - ④ [공유 API 쿼터 및 70% 무중단 스풀 댐 (`GLOBAL_API_QUOTA_GOVERNOR`)]:
 *      한 회사에서 마케팅·회계·CS·백오피스·커머스 워크플로우 10개가 동시에 OpenAI API, Google Sheets API, Slack API, 국세청/홈택스 API 등을 호출할 때,
 *      회사 전체 API 호출량을 70% 안전 정격(`ratedLimit70`)으로 묶어 중앙 스풀링(Spool & Auto-Resume)하고 비상 정지용 예비 쿼터를 보존함으로써 어느 워크플로우도 `HTTP 429`로 죽지 않게 무중단 보장.
 *    - ⑤ [공유 예산·좌석·재고 원자적 선점 (`SHARED_CAPACITY_AND_INVENTORY_RESERVATION`)]:
 *      캠페인 일일 예산 한도, 영업 담당자 배정 슬롯, 라이선스 시트, 커머스 SKU 재고를 여러 워크플로우가 동시에 차감할 때 원자적 선점(Atomic Reservation)으로 초과 소진 및 초과 판매 원천 차단.
 */

'use strict';

const fs = require('fs');
const path = require('path');

const CHANNEL_PRIORITY_TABLE = Object.freeze({
  KAKAO_ALIMTALK: 1,
  CUSTOM_PROPOSAL_ALIMTALK: 1,
  ALIMTALK: 1,
  KAKAO: 1,
  SMS: 2,
  LMS: 2,
  MMS: 2,
  TEXT: 2,
  WHATSAPP: 2,
  EMAIL: 3,
  COLD_EMAIL: 3,
  GMAIL: 3,
  SMTP: 3,
  SLACK: 1,
  TELEGRAM: 2,
  TEAMS: 2,
  DISCORD: 3,
  JANDI: 3,
  MATTERMOST: 3,
  WEBHOOK: 4,
  WEBHOOK_CALLBACK: 4
});

const UNIVERSAL_BUSINESS_DOMAINS = Object.freeze({
  CRM_SALES: 'CRM_SALES',
  MARKETING_CONTENT: 'MARKETING_CONTENT',
  FINANCE_ACCOUNTING: 'FINANCE_ACCOUNTING',
  CS_SUPPORT: 'CS_SUPPORT',
  HR_BACKOFFICE: 'HR_BACKOFFICE',
  COMMERCE_LOGISTICS: 'COMMERCE_LOGISTICS',
  GENERAL_WORKFLOW: 'GENERAL_WORKFLOW'
});

const DOMAIN_DEFAULT_API_LIMITS = Object.freeze({
  OPENAI: 500,
  OPENAI_API: 500,
  ANTHROPIC: 400,
  CLAUDE_API: 400,
  GEMINI_API: 360,
  GOOGLE_SHEETS: 60,
  SLACK: 50,
  SLACK_API: 50,
  DISCORD: 50,
  NOTION: 180,
  NOTION_API: 180,
  AIRTABLE: 300,
  HOMETAX: 30,
  HOMETAX_API: 30,
  BOLTA_TAX_API: 60,
  SOLAPI: 100,
  SOLAPI_ALIMTALK: 100,
  KAKAO_ALIMTALK: 100,
  SMTP_EMAIL: 120,
  ERP_DB: 200,
  NAVER_SMARTSTORE: 60,
  COUPANG_WING: 100,
  HUBSPOT: 100,
  HUBSPOT_CRM: 100,
  TELEGRAM_API: 30
});

// 전 도메인 보류·격리·수신거부·해지·클레임 상태 집합 (Contra-Intent Mutex dominant states)
const HOLD_OR_CLAIM_ORDER_STATES = Object.freeze(new Set([
  // 공통 / 보류 / 격리
  'HOLD',
  'QUARANTINE',
  'FROZEN',
  'SUSPENDED',
  'BLOCKED',
  'REJECTED',
  'AUDIT_LOCK',
  'SECURITY_LOCK',
  'COMPLIANCE_HOLD',
  'BUDGET_EXHAUSTED_HOLD',
  // CRM / 마케팅 (수신거부 / 이탈 / 연락금지 / 블랙리스트 / 분쟁)
  'OPT_OUT',
  'UNSUBSCRIBED',
  'DO_NOT_CONTACT',
  'DNC_LISTED',
  'BLACKLISTED',
  'CHURN',
  'CHURNED',
  'GDPR_ERASURE_REQUESTED',
  // 회계 / 재무 / 세무 / 백오피스 (미승인 / 전표오류 / 대사불일치 / 독소조항 / 압류)
  'UNAPPROVED',
  'PAYMENT_UNVERIFIED',
  'VOUCHER_ERROR',
  'INVOICE_ERROR',
  'RECON_MISMATCH',
  'TAX_ERROR',
  'TAX_INVOICE_MISMATCH',
  'TOXIC_CLAUSE_HOLD',
  'RESTRICTED_MCC_HOLD',
  'SEIZURE_HOLD',
  'IAM_EXCESS_PRIVILEGE_HOLD',
  // CS / 위기관리
  'CRISIS_HOLD',
  'CRISIS_HOLD_HUMAN_REQUIRED',
  'LEGAL_THREAT_HOLD',
  'DISPUTE',
  'DISPUTE_HOLD',
  // 콘텐츠 / SNS
  'COPYRIGHT_HOLD',
  'FTC_DISCLOSURE_MISSING_HOLD',
  'BROKEN_TEMPLATE_HOLD',
  // 커머스 / 물류 (하위 호환 포함)
  'CANCEL',
  'CANCELLED',
  'CANCEL_REQUESTED',
  'RETURN',
  'RETURN_REQUESTED',
  'RETURNED',
  'EXCHANGE',
  'EXCHANGE_REQUESTED',
  'REFUND',
  'REFUND_REQUESTED',
  'PCCC_INVALID',
  'ADDRESS_INVALID',
  'FRAUD_HOLD',
  'STOCKOUT_HOLD'
]));

// 전 도메인 실행·발행·송금·발급·출고 액션 상태 집합 (보류/격리 시 차단되어야 하는 진행성 액션)
const DISPATCH_ACTION_STATES = Object.freeze(new Set([
  // 회계 / 재무 / 정산
  'ISSUE_TAX_INVOICE',
  'AUTO_ISSUE_TAX_INVOICE',
  'ISSUE_BOLTA_INVOICE',
  'EXECUTE_WIRE_TRANSFER',
  'EXECUTE_PAYOUT',
  'AUTO_PAYOUT',
  'FINALIZE_SETTLEMENT',
  'CONFIRM_LEDGER',
  'CONFIRM_ACCOUNTING_VOUCHER',
  'APPROVE_EXPENSE',
  'AUTO_APPROVE_EXPENSE',
  // CRM / 마케팅 / 영업
  'SEND_PROMO',
  'MARKETING_PROMO',
  'REVIEW_BOOSTER',
  'UPSELL_COUPON',
  'UPSELL_CAMPAIGN',
  'RETARGETING_AD',
  'COLD_OUTREACH',
  'DRIP_CAMPAIGN',
  'AUTO_RENEW_CHARGE',
  // 콘텐츠 / SNS 발행
  'PUBLISH_CONTENT',
  'PUBLISH_ARTICLE',
  'UPLOAD_POST',
  'UPLOAD_VIDEO',
  'UPLOAD_SHORTS',
  'CROSS_POST_SNS',
  'POST_SNS',
  'SEND_NEWSLETTER',
  // 인사 / 백오피스 / 계약
  'GRANT_PRIVILEGE',
  'GRANT_IAM_ADMIN',
  'AUTO_SIGN_CONTRACT',
  'PROVISION_ACCOUNT',
  // 커머스 / 물류 출고 (하위 호환 포함)
  'DISPATCH_INVOICE',
  'DISPATCH_READY',
  'DISPATCHED',
  'AUTO_SHIPMENT',
  'SHIP_ORDER',
  'SHIPPED',
  'INVOICE_REGISTERED',
  'PRINT_WAYBILL',
  'SHIP_CONFIRM'
]));

const REVIEW_OR_PROMO_INTENTS = Object.freeze(new Set([
  'REVIEW_BOOSTER',
  'REVIEW_REQUEST',
  'MARKETING_PROMO',
  'UPSELL_COUPON',
  'UPSELL_CAMPAIGN',
  'RETARGETING_AD',
  'PROMOTION_BLAST',
  'COLD_OUTREACH',
  'DRIP_CAMPAIGN',
  'RENEWAL_UPSELL',
  'REENGAGEMENT_PROMO',
  'CROSS_SELL_OFFER',
  'EVENT_COUPON',
  'VIP_PROMO',
  'SEND_NEWSLETTER',
  'NEWSLETTER_DIGEST'
]));

const CLAIM_NOTICE_INTENTS = Object.freeze(new Set([
  'CLAIM_APOLOGY',
  'CANCEL_NOTICE',
  'RETURN_NOTICE',
  'DISPUTE_HOLD_NOTICE',
  'REFUND_CONFIRM',
  'OPT_OUT_CONFIRM',
  'UNSUBSCRIBE_CONFIRM',
  'CHURN_EXIT_NOTICE',
  'CRISIS_ESCALATION_NOTICE',
  'QUARANTINE_ALERT',
  'VOUCHER_HOLD_NOTICE'
]));

const IRREVERSIBLE_COMMITTED_STATES = Object.freeze({
  SHIPPED: 'CONVERT_TO_RETURN_PICKUP_FLOW',
  DISPATCHED: 'CONVERT_TO_RETURN_PICKUP_FLOW',
  INVOICE_REGISTERED: 'CONVERT_TO_RETURN_PICKUP_FLOW',
  SHIP_CONFIRM: 'CONVERT_TO_RETURN_PICKUP_FLOW',
  SHIP_ORDER: 'CONVERT_TO_RETURN_PICKUP_FLOW',
  DISPATCH_INVOICE: 'CONVERT_TO_RETURN_PICKUP_FLOW',
  PRINT_WAYBILL: 'CONVERT_TO_RETURN_PICKUP_FLOW',
  AUTO_SHIPMENT: 'CONVERT_TO_RETURN_PICKUP_FLOW',
  ISSUED_TAX_INVOICE: 'CONVERT_TO_AMENDED_TAX_INVOICE_FLOW',
  TAX_INVOICE_ISSUED: 'CONVERT_TO_AMENDED_TAX_INVOICE_FLOW',
  ISSUE_TAX_INVOICE: 'CONVERT_TO_AMENDED_TAX_INVOICE_FLOW',
  AUTO_ISSUE_TAX_INVOICE: 'CONVERT_TO_AMENDED_TAX_INVOICE_FLOW',
  ISSUE_BOLTA_INVOICE: 'CONVERT_TO_AMENDED_TAX_INVOICE_FLOW',
  WIRE_TRANSFERRED: 'CONVERT_TO_REVERSAL_VOUCHER_AND_RECOVERY_FLOW',
  PAYOUT_COMPLETED: 'CONVERT_TO_REVERSAL_VOUCHER_AND_RECOVERY_FLOW',
  EXECUTE_WIRE_TRANSFER: 'CONVERT_TO_REVERSAL_VOUCHER_AND_RECOVERY_FLOW',
  EXECUTE_PAYOUT: 'CONVERT_TO_REVERSAL_VOUCHER_AND_RECOVERY_FLOW',
  AUTO_PAYOUT: 'CONVERT_TO_REVERSAL_VOUCHER_AND_RECOVERY_FLOW',
  FINALIZE_SETTLEMENT: 'CONVERT_TO_REVERSAL_VOUCHER_AND_RECOVERY_FLOW',
  CONFIRM_LEDGER: 'CONVERT_TO_REVERSAL_VOUCHER_AND_RECOVERY_FLOW',
  CONFIRM_ACCOUNTING_VOUCHER: 'CONVERT_TO_REVERSAL_VOUCHER_AND_RECOVERY_FLOW',
  CONTRACT_EXECUTED: 'CONVERT_TO_TERMINATION_ADDENDUM_FLOW',
  AUTO_SIGN_CONTRACT: 'CONVERT_TO_TERMINATION_ADDENDUM_FLOW'
});

const IRREVERSIBLE_DISPATCH_GROUP_BY_ACTION = Object.freeze({
  ISSUE_TAX_INVOICE: 'TAX_INVOICE_ISSUANCE',
  AUTO_ISSUE_TAX_INVOICE: 'TAX_INVOICE_ISSUANCE',
  ISSUE_BOLTA_INVOICE: 'TAX_INVOICE_ISSUANCE',
  EXECUTE_WIRE_TRANSFER: 'WIRE_TRANSFER_PAYOUT',
  EXECUTE_PAYOUT: 'WIRE_TRANSFER_PAYOUT',
  AUTO_PAYOUT: 'WIRE_TRANSFER_PAYOUT',
  FINALIZE_SETTLEMENT: 'SETTLEMENT_FINALIZATION',
  AUTO_SIGN_CONTRACT: 'CONTRACT_EXECUTION',
  SHIP_ORDER: 'PHYSICAL_SHIPMENT_DISPATCH',
  DISPATCH_INVOICE: 'PHYSICAL_SHIPMENT_DISPATCH',
  AUTO_SHIPMENT: 'PHYSICAL_SHIPMENT_DISPATCH'
});

const SIMPLE_CANCEL_OR_DELETE_STATES = Object.freeze(new Set([
  'CANCEL',
  'CANCELLED',
  'CANCEL_REQUESTED',
  'DIRECT_CANCEL',
  'AUTO_REFUND',
  'DELETE_VOUCHER',
  'DELETE_RECORD',
  'HARD_DELETE',
  'RAW_DELETE',
  'DROP_RECORD',
  'VOID_INVOICE'
]));

const CONTENT_PUBLISH_ACTION_STATES = Object.freeze(new Set([
  'PUBLISH_CONTENT',
  'PUBLISH_ARTICLE',
  'UPLOAD_POST',
  'UPLOAD_VIDEO',
  'UPLOAD_SHORTS',
  'CROSS_POST_SNS',
  'POST_SNS',
  'SEND_NEWSLETTER'
]));

const UNIVERSAL_CROSS_WORKFLOW_CONFLICT_MATRIX = Object.freeze([
  Object.freeze({
    pillarId: 'OUTBOUND_MESSAGE_DEDUP_AND_PRIORITY',
    caseId: 'CASE_1_OUTBOUND_INTENT_AND_CLAIM_MUTEX',
    domainsCovered: Object.freeze(['CRM_SALES', 'MARKETING_CONTENT', 'CS_SUPPORT', 'FINANCE_ACCOUNTING', 'HR_BACKOFFICE', 'COMMERCE_LOGISTICS']),
    titleKo: '동일 대상 중복 발송·연락 충돌 및 채널 우선순위 선점 (OUTBOUND_MESSAGE_DEDUP & PRIORITY)',
    arbitrationMechanism: '4D Universal Intent Idempotency Ledger (domain + entityKey + recipient + intentType) + Channel Priority Preemption (AlimTalk 1순위 > SMS 2순위 > Email 3순위 / Slack 1순위 > Telegram 2순위 > Discord 3순위 > Webhook 4순위)',
    whyWorkflowJsonCannotSolveKo: '개별 .n8n.json 워크플로우는 각자 분리된 실행 컨텍스트에서 돌기 때문에, 영업 리드 인입 시 [워크플로우 A: 기본 문자/이메일]과 [워크플로우 B: 알림톡/맞춤 제안서]가 동시에 발사되거나 사내 장애 경보가 여러 워크플로우에서 중복 폭주하는 것을 스스로 인지·중재할 수 없음.'
  }),
  Object.freeze({
    pillarId: 'CONTRA_INTENT_MUTEX',
    caseId: 'CASE_2_ORDER_STATE_HOLD_VS_DISPATCH',
    domainsCovered: Object.freeze(['CRM_SALES', 'MARKETING_CONTENT', 'FINANCE_ACCOUNTING', 'HR_BACKOFFICE', 'CS_SUPPORT', 'COMMERCE_LOGISTICS']),
    titleKo: '상반된 비즈니스 의도 상호 배타 차단 (CONTRA_INTENT_MUTEX: 수신거부·해지 vs 프로모션 / 전표·정산보류 vs 세금계산서·송금·출고 / SNS 중복 업로드 차단)',
    arbitrationMechanism: 'Universal Entity Lifecycle State Machine (OPT_OUT/CHURN/DISPUTE vs Promo Mutex + HOLD/QUARANTINE/UNAPPROVED vs TaxInvoice/WireTransfer/Dispatch Mutex + Sticky Irreversible Commitment Guard + SNS Duplicate Channel Upload Lock)',
    whyWorkflowJsonCannotSolveKo: 'CRM 수신거부·클레임 워크플로우나 회계 정산 대사 워크플로우가 특정 건을 보류(HOLD/OPT_OUT)시켜도, 별도 스케줄로 도는 마케팅 프로모션 워크플로우나 세금계산서 자동발행·자동출고 워크플로우는 이를 모른 채 폭주하여 법적 분쟁·오발행·오출고 사고를 일으킴.'
  }),
  Object.freeze({
    pillarId: 'SHARED_CAPACITY_AND_INVENTORY_RESERVATION',
    caseId: 'CASE_3_INVENTORY_ATOMIC_RESERVATION',
    domainsCovered: Object.freeze(['MARKETING_CONTENT', 'CRM_SALES', 'FINANCE_ACCOUNTING', 'HR_BACKOFFICE', 'COMMERCE_LOGISTICS']),
    titleKo: '공유 예산·캠페인 한도·좌석·재고 동시 차감 충돌 (SHARED_CAPACITY_AND_INVENTORY_RESERVATION)',
    arbitrationMechanism: 'Atomic Resource & SKU Capacity Reservation Ledger + Exhaustion Sync Signal + Automatic Entity Hold Interlock',
    whyWorkflowJsonCannotSolveKo: '다수의 마케팅·영업·커머스 워크플로우가 동일한 일일 광고 예산, 프로모션 쿠폰 수량, 라이선스 시트, 혹은 마켓 마지막 재고 1개를 동시에 조회하면 Race Condition으로 한도 초과 집행 및 초과 판매가 발생함.'
  }),
  Object.freeze({
    pillarId: 'SHARED_RESOURCE_WRITE_LOCK',
    caseId: 'CASE_4_SHEET_LEDGER_ROW_UPSERT_MUTEX',
    domainsCovered: Object.freeze(['FINANCE_ACCOUNTING', 'CRM_SALES', 'HR_BACKOFFICE', 'MARKETING_CONTENT', 'CS_SUPPORT', 'COMMERCE_LOGISTICS']),
    titleKo: '공유 리소스(구글 시트·노션·DB·ERP 원장) 동시 쓰기 및 덮어쓰기 충돌 (SHARED_RESOURCE_WRITE_LOCK)',
    arbitrationMechanism: 'Shared Resource Row Mutex Queue + Duplicate Append-to-Partial-Update Conversion + Recursive Non-Destructive Deep Field Merge (Blank Overwrite Guard) & Optimistic Version Lock',
    whyWorkflowJsonCannotSolveKo: '회계 워크플로우, 영업 리드 워크플로우, 인사·재고 워크플로우가 동일한 구글 시트/노션/DB 테이블의 같은 행·셀을 동시에 수정하면 행이 2줄로 중복 생성되거나 선행 워크플로우가 기입한 세금계산서 번호·담당자·송장번호가 빈값("")으로 덮어써져 전사 원장이 파열됨.'
  }),
  Object.freeze({
    pillarId: 'GLOBAL_API_QUOTA_GOVERNOR',
    caseId: 'CASE_5_ACCOUNT_API_QUOTA_GOVERNOR',
    domainsCovered: Object.freeze(['MARKETING_CONTENT', 'CRM_SALES', 'FINANCE_ACCOUNTING', 'CS_SUPPORT', 'HR_BACKOFFICE', 'COMMERCE_LOGISTICS']),
    titleKo: '전사 공유 API 쿼터 70% 안전 정격 통제 및 무중단 중앙 스풀 댐 (GLOBAL_API_QUOTA_GOVERNOR)',
    arbitrationMechanism: 'Company-Wide 70% Safety Factor Governor (ratedLimit70) + Executable Priority Spool Queue & Auto-Resume Drain + Emergency Reserve for Critical Freeze/Stop Signals',
    whyWorkflowJsonCannotSolveKo: '한 회사에서 마케팅·회계·CS·커머스 워크플로우 10개가 동시에 OpenAI API, Google Sheets API, Slack API, 국세청/홈택스 API를 호출할 때, 워크플로우 내부의 Wait 노드는 타 워크플로우의 호출량을 알 수 없어 합산 쿼터 폭발(HTTP 429)로 전사 자동화가 연쇄 중단됨.'
  })
]);

const CROSS_WORKFLOW_CONFLICT_MATRIX = UNIVERSAL_CROSS_WORKFLOW_CONFLICT_MATRIX;

function normalizeChannelName(rawChannel) {
  const ch = String(rawChannel || 'KAKAO_ALIMTALK').trim().toUpperCase();
  return ch || 'KAKAO_ALIMTALK';
}

function getChannelPriorityRank(rawChannel) {
  const ch = normalizeChannelName(rawChannel);
  return Object.prototype.hasOwnProperty.call(CHANNEL_PRIORITY_TABLE, ch)
    ? CHANNEL_PRIORITY_TABLE[ch]
    : 5;
}

function isPlainObject(val) {
  return Boolean(val) && typeof val === 'object' && !Array.isArray(val) && Object.prototype.toString.call(val) === '[object Object]';
}

function isValueEmptyForMerge(val) {
  if (val === '' || val === null || val === undefined) return true;
  if (Array.isArray(val) && val.length === 0) return true;
  if (isPlainObject(val) && Object.keys(val).length === 0) return true;
  return false;
}

function deepCloneSafe(val) {
  if (val === null || val === undefined || typeof val !== 'object') return val;
  if (Array.isArray(val)) return val.map(deepCloneSafe);
  if (isPlainObject(val)) {
    const out = {};
    for (const [k, v] of Object.entries(val)) {
      if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
      if (v !== undefined) out[k] = deepCloneSafe(v);
    }
    return out;
  }
  return val;
}

function deepEqualValues(a, b) {
  if (a === b) return true;
  if (a === null || b === null || a === undefined || b === undefined) return false;
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (!deepEqualValues(a[i], b[i])) return false;
    }
    return true;
  }
  if (isPlainObject(a) && isPlainObject(b)) {
    const keysA = Object.keys(a).filter(k => a[k] !== undefined);
    const keysB = Object.keys(b).filter(k => b[k] !== undefined);
    if (keysA.length !== keysB.length) return false;
    for (const k of keysA) {
      if (!Object.prototype.hasOwnProperty.call(b, k)) return false;
      if (!deepEqualValues(a[k], b[k])) return false;
    }
    return true;
  }
  return String(a) === String(b);
}

function nonDestructiveDeepMerge(targetObj, incomingObj, allowBlankOverwrite, pathPrefix, preservedFields, updatedFields) {
  for (const [k, v] of Object.entries(incomingObj)) {
    if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
    const fieldPath = pathPrefix ? `${pathPrefix}.${k}` : k;
    const curVal = targetObj[k];

    if (isPlainObject(v) && isPlainObject(curVal)) {
      if (Object.keys(v).length === 0 && Object.keys(curVal).length > 0 && !allowBlankOverwrite) {
        preservedFields.push(fieldPath);
        continue;
      }
      nonDestructiveDeepMerge(curVal, v, allowBlankOverwrite, fieldPath, preservedFields, updatedFields);
      continue;
    }

    const incomingEmpty = isValueEmptyForMerge(v);
    const existingValid = !isValueEmptyForMerge(curVal);

    if (incomingEmpty && existingValid && !allowBlankOverwrite) {
      preservedFields.push(fieldPath);
      continue;
    }

    if (!incomingEmpty && !deepEqualValues(curVal, v)) {
      targetObj[k] = deepCloneSafe(v);
      updatedFields.push(fieldPath);
    } else if (!(k in targetObj) && v !== undefined) {
      targetObj[k] = deepCloneSafe(v);
      updatedFields.push(fieldPath);
    } else if (allowBlankOverwrite && incomingEmpty && existingValid) {
      targetObj[k] = deepCloneSafe(v);
      updatedFields.push(fieldPath);
    }
  }
}

function isPromoOrMarketingIntent(intentStr) {
  const s = String(intentStr || '').trim().toUpperCase();
  if (!s) return false;
  if (REVIEW_OR_PROMO_INTENTS.has(s)) return true;
  if (CLAIM_NOTICE_INTENTS.has(s)) return false;
  return (
    s.includes('PROMO') ||
    s.includes('UPSELL') ||
    s.includes('CROSS_SELL') ||
    s.includes('RETARGET') ||
    s.includes('COLD_OUTREACH') ||
    s.includes('COLD_EMAIL') ||
    s.includes('MARKETING_BLAST') ||
    s.includes('NEWSLETTER') ||
    s.includes('REVIEW_BOOSTER') ||
    s.includes('AD_CAMPAIGN')
  );
}

/**
 * 전 도메인 범용 비즈니스 도메인 자동 판별기
 */
function detectBusinessDomain(rawReq = {}) {
  const req = (rawReq && typeof rawReq === 'object' && !Array.isArray(rawReq)) ? rawReq : {};
  const explicit = String(req.domain ?? req.businessDomain ?? req.department ?? '').trim().toUpperCase();
  if (explicit) {
    if (explicit.includes('CRM') || explicit.includes('SALES') || explicit.includes('LEAD')) return UNIVERSAL_BUSINESS_DOMAINS.CRM_SALES;
    if (explicit.includes('MKT') || explicit.includes('MARKETING') || explicit.includes('CONTENT') || explicit.includes('SNS')) return UNIVERSAL_BUSINESS_DOMAINS.MARKETING_CONTENT;
    if (explicit.includes('FIN') || explicit.includes('ACCOUNT') || explicit.includes('TAX') || explicit.includes('RECON')) return UNIVERSAL_BUSINESS_DOMAINS.FINANCE_ACCOUNTING;
    if (explicit.includes('CS') || explicit.includes('SUPPORT') || explicit.includes('TICKET') || explicit.includes('INQUIRY')) return UNIVERSAL_BUSINESS_DOMAINS.CS_SUPPORT;
    if (explicit.includes('HR') || explicit.includes('BACKOFFICE') || explicit.includes('BO') || explicit.includes('IAM') || explicit.includes('CONTRACT')) return UNIVERSAL_BUSINESS_DOMAINS.HR_BACKOFFICE;
    if (explicit.includes('COMMERCE') || explicit.includes('SHOP') || explicit.includes('ORDER') || explicit.includes('LOGISTICS')) return UNIVERSAL_BUSINESS_DOMAINS.COMMERCE_LOGISTICS;
    return explicit;
  }

  if (
    req.leadId || req.lead_id || req.dealId || req.deal_id ||
    req.prospectId || req.prospect_id || req.contactId || req.contact_id ||
    req.customerId || req.customer_id || req.clientId || req.client_id
  ) {
    return UNIVERSAL_BUSINESS_DOMAINS.CRM_SALES;
  }
  if (
    req.postId || req.post_id || req.campaignId || req.campaign_id ||
    req.contentId || req.content_id || req.videoId || req.video_id ||
    req.articleId || req.article_id || req.newsletterId || req.newsletter_id ||
    req.adId || req.ad_id || req.targetPlatform
  ) {
    return UNIVERSAL_BUSINESS_DOMAINS.MARKETING_CONTENT;
  }
  if (
    req.invoiceId || req.invoice_id || req.taxInvoiceId || req.tax_invoice_id ||
    req.voucherId || req.voucher_id || req.statementId || req.statement_id ||
    req.billingId || req.billing_id || req.expenseId || req.expense_id ||
    req.poId || req.po_id || req.settlementId || req.settlement_id
  ) {
    return UNIVERSAL_BUSINESS_DOMAINS.FINANCE_ACCOUNTING;
  }
  if (
    req.ticketId || req.ticket_id || req.inquiryId || req.inquiry_id ||
    req.claimId || req.claim_id || req.csId || req.cs_id ||
    req.caseId || req.case_id || req.disputeId || req.dispute_id
  ) {
    return UNIVERSAL_BUSINESS_DOMAINS.CS_SUPPORT;
  }
  if (
    req.employeeId || req.employee_id || req.contractId || req.contract_id ||
    req.applicantId || req.applicant_id || req.candidateId || req.candidate_id ||
    req.approvalId || req.approval_id || req.leaveId || req.leave_id ||
    req.incidentId || req.incident_id
  ) {
    return UNIVERSAL_BUSINESS_DOMAINS.HR_BACKOFFICE;
  }
  if (
    req.orderId || req.order_id || req.orderNo || req.order_no ||
    req.shipmentId || req.shipment_id || req.deliveryId || req.delivery_id ||
    req.waybillNo || req.trackingNo || req.skuId || req.sku_id
  ) {
    return UNIVERSAL_BUSINESS_DOMAINS.COMMERCE_LOGISTICS;
  }
  return UNIVERSAL_BUSINESS_DOMAINS.GENERAL_WORKFLOW;
}

/**
 * 범용 엔티티 키 추출기 (`entityKey` / `eventId` + 전 도메인 ID 수용 + `orderId` 하위 호환)
 */
function extractUniversalEntityKey(rawReq = {}) {
  if (typeof rawReq === 'string' || typeof rawReq === 'number') {
    const clean = String(rawReq).trim();
    return {
      entityKey: clean,
      keyFieldUsed: 'primitive',
      domain: UNIVERSAL_BUSINESS_DOMAINS.GENERAL_WORKFLOW
    };
  }
  const req = (rawReq && typeof rawReq === 'object' && !Array.isArray(rawReq)) ? rawReq : {};
  const candidateFields = [
    'entityKey', 'entity_key', 'eventId', 'event_id',
    'leadId', 'lead_id', 'dealId', 'deal_id', 'prospectId', 'prospect_id', 'contactId', 'contact_id', 'customerId', 'customer_id', 'clientId', 'client_id',
    'invoiceId', 'invoice_id', 'taxInvoiceId', 'tax_invoice_id', 'voucherId', 'voucher_id', 'statementId', 'statement_id', 'billingId', 'billing_id', 'expenseId', 'expense_id', 'poId', 'po_id', 'settlementId', 'settlement_id',
    'ticketId', 'ticket_id', 'inquiryId', 'inquiry_id', 'claimId', 'claim_id', 'csId', 'cs_id', 'caseId', 'case_id', 'disputeId', 'dispute_id',
    'postId', 'post_id', 'campaignId', 'campaign_id', 'contentId', 'content_id', 'videoId', 'video_id', 'articleId', 'article_id', 'newsletterId', 'newsletter_id', 'adId', 'ad_id',
    'employeeId', 'employee_id', 'contractId', 'contract_id', 'applicantId', 'applicant_id', 'candidateId', 'candidate_id', 'approvalId', 'approval_id', 'leaveId', 'leave_id', 'incidentId', 'incident_id',
    'orderId', 'order_id', 'orderNo', 'order_no', 'shipmentId', 'shipment_id', 'deliveryId', 'delivery_id',
    'rowKey', 'row_key', 'recordId', 'record_id', 'id'
  ];

  for (const field of candidateFields) {
    const val = req[field];
    if (val !== undefined && val !== null && typeof val !== 'object') {
      const trimmed = String(val).trim();
      if (trimmed) {
        return {
          entityKey: trimmed,
          keyFieldUsed: field,
          domain: detectBusinessDomain(req)
        };
      }
    }
  }

  return {
    entityKey: '',
    keyFieldUsed: null,
    domain: detectBusinessDomain(req)
  };
}

class OrderDedupSentinel {
  constructor(maxSizeOrOptions = 2000, maybeOptions = {}) {
    const isObjArg = isPlainObject(maxSizeOrOptions);
    const opts = isObjArg ? maxSizeOrOptions : (isPlainObject(maybeOptions) ? maybeOptions : {});
    const rawMax = isObjArg ? opts.maxSize : maxSizeOrOptions;
    const safeMax = (typeof rawMax === 'number' && Number.isFinite(rawMax) && rawMax > 0)
      ? Math.floor(rawMax)
      : 2000;
    this.maxSize = safeMax;
    this.snapshotPath = typeof opts.snapshotPath === 'string' && opts.snapshotPath.trim()
      ? opts.snapshotPath.trim()
      : null;
    this.autoPersist = Boolean(opts.autoPersist && this.snapshotPath);

    this.historyQueue = [];
    this.historySet = new Set();

    // Universal Enterprise Cross-Workflow Arbitration Ledgers (Bounded LRU in-memory state)
    this.actionIntentQueue = [];
    this.actionIntentLedger = new Map(); // key: entityKey::recipient::intent -> record (with domain metadata)
    this.orderClaimHistory = new Map();  // key: entityKey -> Set of contra-intent states (OPT_OUT, CHURN, DISPUTE, HOLD, QUARANTINE...)
    this.orderStateLedger = new Map();   // key: entityKey -> { entityKey, orderId, domain, state, holdLocked, holdReason, committedIrreversibleState, committedActions, ... }
    this.contentPublishLedger = new Map(); // key: entityKey::targetChannel -> { entityKey, targetChannel, workflowId, publishedAt }
    this.inventoryLedger = new Map();    // key: resourcePoolOrSkuId -> { resourceId, skuId, availableStock, reservedOrders: Map<entityKey, record> }
    this.sheetRowLedger = new Map();     // key: resourceId::entityKey -> { resourceId, sheetId, entityKey, orderId, version, mutexSeq, fields, ... }
    this.apiQuotaLedger = new Map();     // key: provider::accountId -> { provider, accountId, limitPerMinute, ratedLimit70, usedCount, workflowUsage }
    this.apiSpoolQueue = new Map();      // key: provider::accountId -> Array<spooledRequestRecord>
    this.mutexSequenceCounter = 0;

    if (this.snapshotPath && opts.autoRestoreOnInit === true && fs.existsSync(this.snapshotPath)) {
      this.restoreLedgerSnapshot(this.snapshotPath);
    }
  }

  _enforceMapCap(mapInstance) {
    if (mapInstance && mapInstance.size > this.maxSize) {
      const oldestKey = mapInstance.keys().next().value;
      if (oldestKey !== undefined) {
        mapInstance.delete(oldestKey);
      }
    }
  }

  _maybeAutoPersist() {
    if (this.autoPersist && this.snapshotPath) {
      this.persistLedgerSnapshot(this.snapshotPath);
    }
  }

  /**
   * 범용 엔티티 키(주문번호·리드ID·세금계산서ID·티켓ID·포스트ID·사원ID 등) 중복 검사 및 신규 등록
   * @param {string|number|Object} entityOrOrderId 엔티티 식별자 또는 페이로드 객체
   * @returns {boolean} true: 중복 (이미 처리됨), false: 신규
   */
  isDuplicate(entityOrOrderId) {
    if (entityOrOrderId === null || entityOrOrderId === undefined) return false;
    let cleanId = '';
    if (typeof entityOrOrderId === 'object') {
      cleanId = extractUniversalEntityKey(entityOrOrderId).entityKey;
    } else {
      cleanId = String(entityOrOrderId).trim();
    }
    if (!cleanId) return false;
    if (this.historySet.has(cleanId)) {
      return true;
    }

    // 신규 등록
    this.historySet.add(cleanId);
    this.historyQueue.push(cleanId);

    // 링 버퍼 크기 유지
    if (this.historyQueue.length > this.maxSize) {
      const oldest = this.historyQueue.shift();
      this.historySet.delete(oldest);
    }

    return false;
  }

  /**
   * 복수 엔티티/주문 중 중복을 걸러낸 신규 목록 추출 (전 도메인 ID 및 orderId 완벽 호환)
   * @param {Array} items 엔티티/주문 객체 배열
   * @returns {Array} 신규 객체 배열
   */
  filterNewOrders(items = []) {
    if (!Array.isArray(items)) return [];
    return items.filter(item => {
      if (!item || typeof item !== 'object') return false;
      const extracted = extractUniversalEntityKey(item);
      return Boolean(extracted.entityKey) && !this.isDuplicate(extracted.entityKey);
    });
  }

  filterNewEntities(items = []) {
    return this.filterNewOrders(items);
  }

  /**
   * 주문 폭주 감지 및 스마트 묶음 포맷팅
   * @param {Array} newOrders 중복 제거된 신규 주문 목록
   * @param {Object} options 설정 (smartBatchThreshold: 4)
   * @returns {Object} { isBatchRollup: boolean, messageCount: number, messages: string[] }
   */
  formatBatchNotification(newOrders = [], options = {}) {
    const safeOptions = (options && typeof options === 'object' && !Array.isArray(options)) ? options : {};
    const threshold = safeOptions.smartBatchThreshold || 4;

    if (!Array.isArray(newOrders) || newOrders.length === 0) {
      return { isBatchRollup: false, messageCount: 0, messages: [] };
    }

    const validOrders = newOrders.filter(o => o && typeof o === 'object');
    if (validOrders.length === 0) {
      return { isBatchRollup: false, messageCount: 0, messages: [] };
    }

    // 1) 임계치 미만: 개별 주문 상세 알림
    if (validOrders.length < threshold) {
      const messages = validOrders.map(o => {
        const id = o.orderId || o.id || "ORD-UNKNOWN";
        const title = o.productName || o.title || "주문 상품";
        const amt = Number(o.orderPrice || o.amount || 0).toLocaleString();
        return `🛒 [쿠팡 신규 주문] ${title} (${amt}원) / 주문번호: ${id}`;
      });
      return { isBatchRollup: false, messageCount: messages.length, messages };
    }

    // 2) 임계치 이상: 주문 폭주 스마트 묶음 요약 알림 (1건으로 집약)
    const count = validOrders.length;
    let totalAmt = 0;
    const sampleItems = [];

    validOrders.forEach((o, idx) => {
      totalAmt += Number(o.orderPrice || o.amount || 0);
      if (idx < 2) {
        const t = o.productName || o.title || "주문 상품";
        sampleItems.push(`- ${t}`);
      }
    });

    const formattedTotal = totalAmt.toLocaleString();
    const rollupMessage = `⚡ [AutoFlow 주문 폭주 스마트 안심 요약]
대표님, 방금 신규 주문 ${count}건이 일시에 쇄도했습니다! 🎉
• 총 결제금액: ${formattedTotal}원
• 주요 상품:
${sampleItems.join("\n")}${count > 2 ? `\n- 외 ${count - 2}건` : ""}

💡 메신저 도배 방지 및 플랫폼 레이트리미트(429) 보호를 위해 1건으로 요약 발송되었습니다.
상세 주문 내역 및 송장 처리는 쿠팡 WING에서 확인해 주세요.`;

    return {
      isBatchRollup: true,
      messageCount: 1,
      messages: [rollupMessage]
    };
  }

  /**
   * [범용 충돌 중재 ① — 동일 대상 중복 발송·연락 충돌 및 채널 우선순위 선점 (`OUTBOUND_MESSAGE_DEDUP & PRIORITY`)]
   * 쇼핑몰 주문 안내뿐 아니라 영업 리드 인입 시 [워크플로우 A: 기본 문자/이메일]과 [워크플로우 B: 알림톡/맞춤 제안서] 중복,
   * 또는 사내 슬랙/텔레그램 경보가 여러 워크플로우에서 동시에 터질 때 (domain + entityKey + recipient + intentType) 기준으로
   * 상위 채널만 1회 발송하고 하위/중복 발송은 자동 Skip & 수신거부/해지/클레임(OPT_OUT/CHURN/DISPUTE/HOLD) 대상 프로모션 차단
   * @param {Object} rawReq
   */
  arbitrateOutboundNotification(rawReq = {}) {
    const req = (rawReq && typeof rawReq === 'object' && !Array.isArray(rawReq)) ? rawReq : {};
    const extracted = extractUniversalEntityKey(req);
    const cleanEntityKey = extracted.entityKey;
    const domain = extracted.domain;

    if (!cleanEntityKey) {
      return {
        ok: true,
        allowed: false,
        blocked: false,
        skipped: true,
        pillarId: 'OUTBOUND_MESSAGE_DEDUP_AND_PRIORITY',
        conflictCase: 'CASE_1_OUTBOUND_INTENT_AND_CLAIM_MUTEX',
        domain,
        status: 'INVALID_OR_EMPTY_INPUT',
        reasonKo: '유효한 엔티티 식별자(entityKey / lead_id / invoice_id / ticket_id / post_id / orderId)가 제공되지 않아 발송 중재를 건너뛰었습니다.'
      };
    }

    const cleanRecipient = String(
      req.recipient ?? req.phone ?? req.email ?? req.receiverPhone ?? req.slackChannel ?? req.channelTarget ?? 'DEFAULT_RECIPIENT'
    ).trim().toUpperCase();
    const cleanIntent = String(
      req.intentType ?? req.intent ?? req.actionIntent ?? req.purpose ?? 'DEFAULT_NOTIFICATION'
    ).trim().toUpperCase();
    const workflowId = String(req.workflowId ?? req.workflow_id ?? 'WF_DEFAULT').trim();
    const explicitEntityStatus = String(
      req.entityStatus ?? req.leadStatus ?? req.customerStatus ?? req.orderStatus ?? req.order_status ?? req.state ?? ''
    ).trim().toUpperCase();

    // 1) 후보 채널 배열(다중 워크플로우 동시 경합)이 주어진 경우 우선순위 1위 채널(알림톡 > 문자 > 이메일 / 슬랙 > 텔레그램) 선점
    let selectedChannel = normalizeChannelName(req.channel ?? req.channelType ?? 'KAKAO_ALIMTALK');
    const suppressedChannels = [];
    if (Array.isArray(req.candidateChannels) && req.candidateChannels.length > 0) {
      const sorted = req.candidateChannels
        .map(c => normalizeChannelName(c))
        .filter(Boolean)
        .sort((a, b) => getChannelPriorityRank(a) - getChannelPriorityRank(b));
      if (sorted.length > 0) {
        selectedChannel = sorted[0];
        for (let i = 1; i < sorted.length; i++) {
          if (sorted[i] !== selectedChannel) {
            suppressedChannels.push({
              channel: sorted[i],
              rank: getChannelPriorityRank(sorted[i]),
              suppressedBy: selectedChannel,
              status: 'SUPPRESSED_BY_HIGHER_PRIORITY_CHANNEL'
            });
          }
        }
      }
    }
    const channelRank = getChannelPriorityRank(selectedChannel);

    // 2) 수신거부(OPT_OUT)/이탈(CHURN)/클레임(DISPUTE)/보류(HOLD/QUARANTINE) 상태 기록 및 프로모션/리뷰독려/업셀링 상호 배타 차단
    if (CLAIM_NOTICE_INTENTS.has(cleanIntent) || HOLD_OR_CLAIM_ORDER_STATES.has(explicitEntityStatus)) {
      if (!this.orderClaimHistory.has(cleanEntityKey)) {
        this.orderClaimHistory.set(cleanEntityKey, new Set());
        this._enforceMapCap(this.orderClaimHistory);
      }
      this.orderClaimHistory.get(cleanEntityKey).add(explicitEntityStatus || cleanIntent);
    }

    const trackedEntityState = this.orderStateLedger.get(cleanEntityKey);
    const currentEntityState = explicitEntityStatus || (trackedEntityState && trackedEntityState.state) || 'ACTIVE';
    const hasContraHistory = (this.orderClaimHistory.has(cleanEntityKey) && this.orderClaimHistory.get(cleanEntityKey).size > 0) ||
      HOLD_OR_CLAIM_ORDER_STATES.has(currentEntityState) ||
      Boolean(trackedEntityState && trackedEntityState.holdLocked);

    if (isPromoOrMarketingIntent(cleanIntent) && hasContraHistory) {
      return {
        ok: true,
        allowed: false,
        blocked: true,
        skipped: true,
        contraIntentBlocked: true,
        pillarId: 'CONTRA_INTENT_MUTEX',
        conflictCase: 'CASE_1_OUTBOUND_INTENT_AND_CLAIM_MUTEX',
        status: 'BLOCKED_BY_CLAIM_STATE_MUTEX',
        domain,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        keyFieldUsed: extracted.keyFieldUsed,
        recipient: cleanRecipient,
        intent: cleanIntent,
        intentType: cleanIntent,
        selectedChannel,
        currentEntityState,
        currentOrderState: currentEntityState,
        workflowId,
        reasonKo: `[${domain}] 대상(${cleanEntityKey})이 수신거부·해지·클레임·보류(${currentEntityState}) 상태이므로 상반된 비즈니스 의도인 프로모션/리뷰독려/업셀링(${cleanIntent}) 발송이 원천 차단되었습니다.`
      };
    }

    // 3) (domain + entityKey + recipient + intentType) 4차원 발송 멱등성 및 채널 우선순위 선점 검사
    const canonicalIntentKey = `${cleanEntityKey}::${cleanRecipient}::${cleanIntent}`;
    const domainIntentKey = `${domain}::${cleanEntityKey}::${cleanRecipient}::${cleanIntent}`;
    const existing = this.actionIntentLedger.get(canonicalIntentKey);
    const nowMs = (Number.isFinite(Number(req.nowMs ?? req.timestampMs)))
      ? Number(req.nowMs ?? req.timestampMs)
      : Date.now();
    const arbWindowMs = (Number.isFinite(Number(req.arbitrationWindowMs)) && Number(req.arbitrationWindowMs) > 0)
      ? Number(req.arbitrationWindowMs)
      : 0;

    if (existing) {
      const withinArbWindow = arbWindowMs > 0 && Number.isFinite(existing.dispatchedAtMs) && (nowMs - existing.dispatchedAtMs <= arbWindowMs);
      // 하위 채널(예: 기본 문자/이메일 2~3순위)이 등록된 상태에서 상위 채널(예: 맞춤 제안 알림톡/슬랙 1순위)이 유입된 경우 상위 채널 선점 승격
      const canPreempt =
        (existing.deliveryState === 'PENDING_WINDOW' || req.preemptLowerPriority === true || withinArbWindow) &&
        channelRank < existing.channelRank;

      if (canPreempt) {
        const preemptedChannel = existing.channel;
        const preemptedWorkflowId = existing.workflowId;
        const updatedRecord = {
          intentKey: canonicalIntentKey,
          domainIntentKey,
          domain,
          entityKey: cleanEntityKey,
          orderId: cleanEntityKey,
          recipient: cleanRecipient,
          intent: cleanIntent,
          intentType: cleanIntent,
          channel: selectedChannel,
          channelRank,
          workflowId,
          deliveryState: 'DISPATCHED',
          preemptedChannel,
          preemptedWorkflowId,
          dispatchedAtMs: nowMs,
          dispatchedAt: new Date(nowMs).toISOString()
        };
        this.actionIntentLedger.set(canonicalIntentKey, updatedRecord);
        this._maybeAutoPersist();
        return {
          ok: true,
          allowed: true,
          blocked: false,
          skipped: false,
          isDuplicateIntent: false,
          pillarId: 'OUTBOUND_MESSAGE_DEDUP_AND_PRIORITY',
          conflictCase: 'CASE_1_OUTBOUND_INTENT_AND_CLAIM_MUTEX',
          status: 'UPGRADED_TO_HIGHER_PRIORITY_CHANNEL',
          domain,
          intentKey: canonicalIntentKey,
          domainIntentKey,
          entityKey: cleanEntityKey,
          orderId: cleanEntityKey,
          keyFieldUsed: extracted.keyFieldUsed,
          recipient: cleanRecipient,
          intent: cleanIntent,
          intentType: cleanIntent,
          selectedChannel,
          channelRank,
          preemptedChannel,
          preemptedWorkflowId,
          suppressedChannels,
          reasonKo: `[${domain}] 하위 채널(${preemptedChannel}, ${preemptedWorkflowId}) 대신 상위 1순위 채널(${selectedChannel}, ${workflowId})이 선점 발송 승인되었으며 하위 중복 발송은 자동 Skip 처리되었습니다.`
        };
      }

      return {
        ok: true,
        allowed: false,
        blocked: true,
        skipped: true,
        isDuplicateIntent: true,
        pillarId: 'OUTBOUND_MESSAGE_DEDUP_AND_PRIORITY',
        conflictCase: 'CASE_1_OUTBOUND_INTENT_AND_CLAIM_MUTEX',
        status: 'DUPLICATE_INTENT_BLOCKED',
        domain,
        intentKey: canonicalIntentKey,
        domainIntentKey,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        keyFieldUsed: extracted.keyFieldUsed,
        recipient: cleanRecipient,
        intent: cleanIntent,
        intentType: cleanIntent,
        attemptedChannel: selectedChannel,
        attemptedByWorkflow: workflowId,
        firstChannel: existing.channel,
        firstDispatchedByWorkflow: existing.workflowId,
        firstDispatchedAt: existing.dispatchedAt,
        reasonKo: `[${domain}] 동일 엔티티(${cleanEntityKey})·동일 수신자(${cleanRecipient})·동일 의도(${cleanIntent})로 이미 [${existing.workflowId}]에서 상위/선행 채널[${existing.channel}] 발송이 완료되어 [${workflowId}/${selectedChannel}] 중복 발송이 자동 Skip 되었습니다.`
      };
    }

    const record = {
      intentKey: canonicalIntentKey,
      domainIntentKey,
      domain,
      entityKey: cleanEntityKey,
      orderId: cleanEntityKey,
      recipient: cleanRecipient,
      intent: cleanIntent,
      intentType: cleanIntent,
      channel: selectedChannel,
      channelRank,
      workflowId,
      deliveryState: req.holdWindow === true ? 'PENDING_WINDOW' : 'DISPATCHED',
      dispatchedAtMs: nowMs,
      dispatchedAt: new Date(nowMs).toISOString()
    };
    this.actionIntentLedger.set(canonicalIntentKey, record);
    this.actionIntentQueue.push(canonicalIntentKey);
    if (this.actionIntentQueue.length > this.maxSize) {
      const oldestKey = this.actionIntentQueue.shift();
      this.actionIntentLedger.delete(oldestKey);
    }
    this._maybeAutoPersist();

    return {
      ok: true,
      allowed: true,
      blocked: false,
      skipped: false,
      isDuplicateIntent: false,
      pillarId: 'OUTBOUND_MESSAGE_DEDUP_AND_PRIORITY',
      conflictCase: 'CASE_1_OUTBOUND_INTENT_AND_CLAIM_MUTEX',
      status: 'DISPATCH_APPROVED',
      domain,
      intentKey: canonicalIntentKey,
      domainIntentKey,
      entityKey: cleanEntityKey,
      orderId: cleanEntityKey,
      keyFieldUsed: extracted.keyFieldUsed,
      recipient: cleanRecipient,
      intent: cleanIntent,
      intentType: cleanIntent,
      selectedChannel,
      channelRank,
      workflowId,
      suppressedChannels,
      reasonKo: `[${domain}] 4차원 발송 멱등성(${domainIntentKey}) 및 채널 우선순위(${selectedChannel}, ${channelRank}순위) 검증 통과 — 단독 1회 발송 승인.`
    };
  }

  arbitrateUniversalOutboundDedup(rawReq = {}) {
    return this.arbitrateOutboundNotification(rawReq);
  }

  /**
   * [범용 충돌 중재 ② — 상반된 비즈니스 의도 상호 배타 차단 (`CONTRA_INTENT_MUTEX`)]
   * 1) CRM/마케팅: 고객·리드가 [수신거부/해지/환불/클레임(OPT_OUT/CHURN/DISPUTE)] 상태일 때 프로모션·리뷰독려·콜드메일 차단
   * 2) 회계/재무/인사/출고: [결제미승인/전표오류/정산불일치/독소조항/보류(HOLD/QUARANTINE/UNAPPROVED/RECON_MISMATCH)] 상태인 건에 대해
   *    다른 자동화 워크플로우의 [세금계산서 자동발행 / 자동송금 / 장부확정 / 권한부여 / 자동출고] 실행 원천 차단
   * 3) 이미 확정(세금계산서 발급 완료 / 송금 완료 / 출고 완료)된 건에 대한 단순 취소/삭제 차단 및 보상 플로우(수정세금계산서 / 역분개 / 반품회수) 전환 +
   *    동일 세금계산서·송금·출고 액션의 이중 실행(Double Issuance / Double Payout) 원천 차단
   * 4) 콘텐츠/SNS: 동일 소스 글·영상을 여러 발행 워크플로우가 동시에 같은 채널에 중복 업로드하려는 충돌 차단
   * @param {Object} rawReq
   */
  arbitrateOrderStateTransition(rawReq = {}) {
    const req = (rawReq && typeof rawReq === 'object' && !Array.isArray(rawReq)) ? rawReq : {};
    const extracted = extractUniversalEntityKey(req);
    const cleanEntityKey = extracted.entityKey;
    const domain = extracted.domain;
    const targetState = String(
      req.targetState ?? req.nextState ?? req.intentType ?? req.action ?? req.orderStatus ?? ''
    ).trim().toUpperCase();

    if (!cleanEntityKey || !targetState) {
      return {
        ok: true,
        allowed: false,
        blocked: false,
        pillarId: 'CONTRA_INTENT_MUTEX',
        conflictCase: 'CASE_2_ORDER_STATE_HOLD_VS_DISPATCH',
        domain,
        status: 'INVALID_OR_EMPTY_INPUT',
        reasonKo: '유효한 엔티티 식별자(entityKey/orderId/leadId/invoiceId/postId) 또는 목표 액션·상태(targetState)가 없어 중재를 건너뛰었습니다.'
      };
    }

    const workflowId = String(req.workflowId ?? req.workflow_id ?? 'WF_DEFAULT').trim();
    const holdReason = String(req.holdReason ?? req.reason ?? '').trim() || null;
    const trackingNo = String(req.trackingNo ?? req.invoiceNumber ?? req.taxInvoiceNo ?? req.waybillNo ?? '').trim() || null;
    const targetChannel = String(req.targetChannel ?? req.platform ?? req.snsChannel ?? '').trim().toUpperCase();

    const existing = this.orderStateLedger.get(cleanEntityKey) || {
      entityKey: cleanEntityKey,
      orderId: cleanEntityKey,
      domain,
      state: 'INITIALIZED',
      holdLocked: false,
      holdReason: null,
      committedIrreversibleState: null,
      committedActionGroups: [],
      updatedByWorkflow: null,
      trackingNo: null,
      updatedAt: null,
      history: []
    };

    const currentState = existing.state;
    const isTargetDispatch = DISPATCH_ACTION_STATES.has(targetState) || isPromoOrMarketingIntent(targetState);
    const isTargetHoldOrClaim = HOLD_OR_CLAIM_ORDER_STATES.has(targetState);
    const isContentPublishAction = CONTENT_PUBLISH_ACTION_STATES.has(targetState);

    // Rule 2-A (Contra-Intent Mutex): 보류(HOLD/QUARANTINE/UNAPPROVED/RECON_MISMATCH) 또는 수신거부/해지/클레임(OPT_OUT/CHURN/DISPUTE/CANCEL) 상태에서
    // 세금계산서 발행, 자동송금, 프로모션 발송, 권한 부여, 콘텐츠 발행, 택배 출고 등 상반된 진행 액션을 시도할 때 원천 차단
    if (
      (existing.holdLocked || HOLD_OR_CLAIM_ORDER_STATES.has(currentState)) &&
      isTargetDispatch &&
      req.explicitHumanReleaseHold !== true
    ) {
      return {
        ok: true,
        allowed: false,
        blocked: true,
        contraIntentBlocked: true,
        pillarId: 'CONTRA_INTENT_MUTEX',
        conflictCase: 'CASE_2_ORDER_STATE_HOLD_VS_DISPATCH',
        status: 'BLOCKED_BY_ORDER_HOLD_STATE',
        domain,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        keyFieldUsed: extracted.keyFieldUsed,
        currentEntityState: currentState,
        currentOrderState: currentState,
        attemptedState: targetState,
        holdLocked: true,
        holdReason: existing.holdReason || currentState,
        lockedByWorkflow: existing.updatedByWorkflow,
        attemptedByWorkflow: workflowId,
        reasonKo: `[${domain}] 엔티티(${cleanEntityKey})는 선행 워크플로우[${existing.updatedByWorkflow || 'SYSTEM'}]에 의해 보류/격리/수신거부(${currentState}: ${existing.holdReason || '사유 잠금'}) 상태이므로 상반된 자동화 액션[${workflowId} ➔ ${targetState}] 실행이 원천 차단되었습니다.`
      };
    }

    // Rule 2-0 (Content/SNS): 동일 소스 글/영상을 여러 발행 워크플로우가 동시에 같은 채널에 중복 업로드하려는 충돌 차단
    if (isContentPublishAction) {
      const channelKey = targetChannel || 'DEFAULT_CONTENT_CHANNEL';
      const pubKey = `${cleanEntityKey}::${channelKey}`;
      const prevPub = this.contentPublishLedger.get(pubKey);
      if (prevPub && req.allowDuplicateUpload !== true) {
        return {
          ok: true,
          allowed: false,
          blocked: true,
          contraIntentBlocked: true,
          duplicateUploadBlocked: true,
          pillarId: 'CONTRA_INTENT_MUTEX',
          conflictCase: 'CASE_2_ORDER_STATE_HOLD_VS_DISPATCH',
          status: 'BLOCKED_DUPLICATE_CHANNEL_UPLOAD',
          domain,
          entityKey: cleanEntityKey,
          orderId: cleanEntityKey,
          targetChannel: channelKey,
          attemptedState: targetState,
          firstPublishedByWorkflow: prevPub.workflowId,
          firstPublishedAt: prevPub.publishedAt,
          attemptedByWorkflow: workflowId,
          reasonKo: `[${domain}] 동일 콘텐츠 소스(${cleanEntityKey})가 이미 [${prevPub.workflowId}]에 의해 [${channelKey}] 채널에 업로드 완료되었으므로 [${workflowId}]의 중복 업로드가 원천 차단되었습니다.`
        };
      }
      this.contentPublishLedger.set(pubKey, {
        entityKey: cleanEntityKey,
        targetChannel: channelKey,
        workflowId,
        publishedAt: new Date().toISOString()
      });
      this._enforceMapCap(this.contentPublishLedger);
    }

    // Rule 2-A-2 (Irreversible Dispatch Idempotency): 세금계산서 발행, 대금 송금, 계약 체결 등 비가역 대외 확정을 두 번 중복 실행하려는 경우 원천 차단
    const targetDispatchGroup = IRREVERSIBLE_DISPATCH_GROUP_BY_ACTION[targetState] || null;
    const prevActionGroups = Array.isArray(existing.committedActionGroups) ? existing.committedActionGroups : [];
    if (
      targetDispatchGroup &&
      prevActionGroups.includes(targetDispatchGroup) &&
      req.allowDuplicateDispatch !== true
    ) {
      return {
        ok: true,
        allowed: false,
        blocked: true,
        contraIntentBlocked: true,
        duplicateDispatchBlocked: true,
        pillarId: 'CONTRA_INTENT_MUTEX',
        conflictCase: 'CASE_2_ORDER_STATE_HOLD_VS_DISPATCH',
        status: 'BLOCKED_DUPLICATE_IRREVERSIBLE_ACTION',
        domain,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        keyFieldUsed: extracted.keyFieldUsed,
        currentEntityState: currentState,
        currentOrderState: currentState,
        attemptedState: targetState,
        dispatchGroup: targetDispatchGroup,
        firstCommittedByWorkflow: existing.updatedByWorkflow,
        attemptedByWorkflow: workflowId,
        reasonKo: `[${domain}] 엔티티(${cleanEntityKey})에 대해 비가역 대외 확정 작업(${targetDispatchGroup}: ${targetState})이 이미 선행 워크플로우[${existing.updatedByWorkflow}]에서 실행 완료되었으므로 [${workflowId}]의 이중 발행/이중 송금이 원천 차단되었습니다.`
      };
    }

    // Rule 2-B: 이미 외부 기관/물류/은행에 확정 실행(세금계산서 발급 완료 / 송금 완료 / 실물 출고 완료)된 건에 대해
    // 중간 로그 상태가 끼어든 이후라도 단순 취소/삭제 시도 시 보상 트랜잭션(수정세금계산서 / 역분개 / 반품회수) 전환
    const effectiveIrreversibleState = IRREVERSIBLE_COMMITTED_STATES[currentState]
      ? currentState
      : (existing.committedIrreversibleState && IRREVERSIBLE_COMMITTED_STATES[existing.committedIrreversibleState]
        ? existing.committedIrreversibleState
        : null);
    const committedCompensationFlow = effectiveIrreversibleState
      ? IRREVERSIBLE_COMMITTED_STATES[effectiveIrreversibleState]
      : null;
    const isSimpleCancelOrDelete = SIMPLE_CANCEL_OR_DELETE_STATES.has(targetState);

    if (committedCompensationFlow && isSimpleCancelOrDelete) {
      const isShippingCommit = (
        effectiveIrreversibleState === 'SHIPPED' ||
        effectiveIrreversibleState === 'DISPATCHED' ||
        effectiveIrreversibleState === 'INVOICE_REGISTERED' ||
        effectiveIrreversibleState === 'SHIP_CONFIRM' ||
        effectiveIrreversibleState === 'SHIP_ORDER' ||
        effectiveIrreversibleState === 'DISPATCH_INVOICE' ||
        effectiveIrreversibleState === 'PRINT_WAYBILL' ||
        effectiveIrreversibleState === 'AUTO_SHIPMENT'
      );
      return {
        ok: true,
        allowed: false,
        blocked: true,
        contraIntentBlocked: true,
        pillarId: 'CONTRA_INTENT_MUTEX',
        conflictCase: 'CASE_2_ORDER_STATE_HOLD_VS_DISPATCH',
        status: isShippingCommit
          ? 'BLOCKED_ALREADY_SHIPPED_REQUIRE_RETURN_PICKUP'
          : 'BLOCKED_ALREADY_COMMITTED_REQUIRE_COMPENSATING_FLOW',
        domain,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        currentEntityState: currentState,
        currentOrderState: currentState,
        committedIrreversibleState: effectiveIrreversibleState,
        attemptedState: targetState,
        trackingNo: existing.trackingNo,
        recommendedAction: committedCompensationFlow,
        attemptedByWorkflow: workflowId,
        reasonKo: `[${domain}] 엔티티(${cleanEntityKey})는 이미 대외 확정(${effectiveIrreversibleState}${existing.trackingNo ? `, 참조번호:${existing.trackingNo}` : ''}) 상태이므로 단순 즉시 취소/삭제(${targetState})가 불가하며 보상 워크플로우(${committedCompensationFlow})로 전환 중재되었습니다.`
      };
    }

    // 정상 상태 전이 기록 (비가역 확정 상태는 중간 일반 상태 전이가 와도 영구 보존)
    const nextHoldLocked = isTargetHoldOrClaim
      ? true
      : (req.explicitHumanReleaseHold === true ? false : existing.holdLocked);
    const nextHoldReason = isTargetHoldOrClaim
      ? (holdReason || targetState)
      : (nextHoldLocked ? existing.holdReason : null);
    const nextCommittedIrreversibleState = IRREVERSIBLE_COMMITTED_STATES[targetState]
      ? targetState
      : existing.committedIrreversibleState || null;
    const nextCommittedActionGroups = targetDispatchGroup && !prevActionGroups.includes(targetDispatchGroup)
      ? prevActionGroups.concat([targetDispatchGroup])
      : prevActionGroups;

    const updatedRecord = {
      entityKey: cleanEntityKey,
      orderId: cleanEntityKey,
      domain,
      state: targetState,
      holdLocked: nextHoldLocked,
      holdReason: nextHoldReason,
      committedIrreversibleState: nextCommittedIrreversibleState,
      committedActionGroups: nextCommittedActionGroups,
      updatedByWorkflow: workflowId,
      trackingNo: trackingNo || existing.trackingNo,
      updatedAt: new Date().toISOString(),
      history: existing.history.concat([{
        from: currentState,
        to: targetState,
        domain,
        workflowId,
        holdReason: nextHoldReason,
        at: new Date().toISOString()
      }]).slice(-20)
    };

    this.orderStateLedger.set(cleanEntityKey, updatedRecord);
    this._enforceMapCap(this.orderStateLedger);

    if (isTargetHoldOrClaim) {
      if (!this.orderClaimHistory.has(cleanEntityKey)) {
        this.orderClaimHistory.set(cleanEntityKey, new Set());
        this._enforceMapCap(this.orderClaimHistory);
      }
      this.orderClaimHistory.get(cleanEntityKey).add(targetState);
    }
    this._maybeAutoPersist();

    return {
      ok: true,
      allowed: true,
      blocked: false,
      pillarId: 'CONTRA_INTENT_MUTEX',
      conflictCase: 'CASE_2_ORDER_STATE_HOLD_VS_DISPATCH',
      status: 'STATE_TRANSITION_COMMITTED',
      domain,
      entityKey: cleanEntityKey,
      orderId: cleanEntityKey,
      keyFieldUsed: extracted.keyFieldUsed,
      previousState: currentState,
      currentEntityState: targetState,
      currentOrderState: targetState,
      committedIrreversibleState: updatedRecord.committedIrreversibleState,
      holdLocked: updatedRecord.holdLocked,
      holdReason: updatedRecord.holdReason,
      trackingNo: updatedRecord.trackingNo,
      targetChannel: targetChannel || null,
      workflowId,
      reasonKo: `[${domain}] 엔티티(${cleanEntityKey}) 상태가 [${currentState} ➔ ${targetState}]로 정상 중재 및 잠금 반영되었습니다.`
    };
  }

  arbitrateContraIntentMutex(rawReq = {}) {
    return this.arbitrateOrderStateTransition(rawReq);
  }

  /**
   * [범용 충돌 중재 ⑤ — 공유 예산·좌석·캠페인 한도·재고 원자적 선점 (`SHARED_CAPACITY_AND_INVENTORY_RESERVATION`)]
   * 다중 마케팅 캠페인 예산, 영업 리드 배정 슬롯, 사내 라이선스 시트, 또는 다중 마켓 SKU 재고를
   * 여러 워크플로우가 동시에 차감할 때 초과 소진/초과 판매(Overselling) 원천 차단
   * @param {Object} rawReq
   */
  arbitrateInventoryReservation(rawReq = {}) {
    const req = (rawReq && typeof rawReq === 'object' && !Array.isArray(rawReq)) ? rawReq : {};
    const cleanResourcePoolId = String(
      req.resourcePoolId ?? req.budgetId ?? req.seatPoolId ?? req.skuId ?? req.sku_id ?? req.itemCode ?? ''
    ).trim();
    const extracted = extractUniversalEntityKey(req);
    const cleanEntityKey = extracted.entityKey;
    const domain = extracted.domain;

    if (!cleanResourcePoolId || !cleanEntityKey) {
      return {
        ok: true,
        allowed: false,
        blocked: false,
        pillarId: 'SHARED_CAPACITY_AND_INVENTORY_RESERVATION',
        conflictCase: 'CASE_3_INVENTORY_OVERSELLING_CONFLICT',
        domain,
        status: 'INVALID_OR_EMPTY_INPUT',
        reasonKo: '유효한 공유 자원 코드(resourcePoolId/budgetId/skuId) 또는 엔티티 식별자(entityKey/orderId)가 없어 선점 중재를 건너뛰었습니다.'
      };
    }

    const workflowId = String(req.workflowId ?? req.workflow_id ?? 'WF_DEFAULT').trim();
    const marketplace = String(req.marketplace ?? req.channel ?? req.department ?? 'SHARED_POOL').trim().toUpperCase();
    const rawQty = Number(req.requestedQty ?? req.requestedAmount ?? req.quantity ?? req.qty ?? 1);
    const requestedQty = (Number.isFinite(rawQty) && rawQty > 0) ? Math.floor(rawQty) : 1;

    let poolEntry = this.inventoryLedger.get(cleanResourcePoolId);
    const initStockCandidate = req.initialAvailableStock ?? req.initialCapacity ?? req.availableStock ?? req.currentStock;
    const hasExplicitInitStock = initStockCandidate !== undefined && initStockCandidate !== null && Number.isFinite(Number(initStockCandidate));

    if (!poolEntry || req.resetStock === true || req.resetCapacity === true) {
      const startStock = hasExplicitInitStock ? Math.max(0, Math.floor(Number(initStockCandidate))) : 1;
      poolEntry = {
        resourcePoolId: cleanResourcePoolId,
        skuId: cleanResourcePoolId,
        availableStock: startStock,
        reservedOrders: new Map(),
        updatedAt: new Date().toISOString()
      };
      this.inventoryLedger.set(cleanResourcePoolId, poolEntry);
      this._enforceMapCap(this.inventoryLedger);
    }

    // 동일 엔티티 재유입 시 이중 차감 방지(Idempotent Replay)
    if (poolEntry.reservedOrders.has(cleanEntityKey)) {
      const prev = poolEntry.reservedOrders.get(cleanEntityKey);
      return {
        ok: true,
        allowed: true,
        blocked: false,
        idempotentReplay: true,
        pillarId: 'SHARED_CAPACITY_AND_INVENTORY_RESERVATION',
        conflictCase: 'CASE_3_INVENTORY_OVERSELLING_CONFLICT',
        status: 'IDEMPOTENT_ALREADY_RESERVED',
        domain,
        resourcePoolId: cleanResourcePoolId,
        skuId: cleanResourcePoolId,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        reservedQty: prev.reservedQty,
        remainingStock: poolEntry.availableStock,
        remainingCapacity: poolEntry.availableStock,
        workflowId: prev.workflowId,
        marketplace: prev.marketplace,
        triggerCrossChannelSoldOutSync: poolEntry.availableStock === 0,
        reasonKo: `[${domain}] 엔티티(${cleanEntityKey})는 이미 공유 자원(${cleanResourcePoolId}) ${prev.reservedQty}단위가 선점되어 있어 이중 차감 없이 통과되었습니다.`
      };
    }

    // 가용 한도/재고 부족 시 초과 집행/초과 판매 원천 차단 + 해당 엔티티 자동 보류(HOLD) 잠금 연동
    if (poolEntry.availableStock < requestedQty || poolEntry.availableStock <= 0) {
      this.arbitrateOrderStateTransition({
        domain,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        targetState: 'HOLD',
        holdReason: `CAPACITY_OR_STOCKOUT_EXCEEDED (POOL:${cleanResourcePoolId}, 잔여:${poolEntry.availableStock}, 요청:${requestedQty})`,
        workflowId
      });

      return {
        ok: true,
        allowed: false,
        blocked: true,
        idempotentReplay: false,
        pillarId: 'SHARED_CAPACITY_AND_INVENTORY_RESERVATION',
        conflictCase: 'CASE_3_INVENTORY_OVERSELLING_CONFLICT',
        status: 'BLOCKED_OVERSELLING_STOCKOUT',
        domain,
        resourcePoolId: cleanResourcePoolId,
        skuId: cleanResourcePoolId,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        workflowId,
        marketplace,
        requestedQty,
        remainingStock: poolEntry.availableStock,
        remainingCapacity: poolEntry.availableStock,
        triggerCrossChannelSoldOutSync: true,
        autoHoldOrderApplied: true,
        reasonKo: `[${domain}] 공유 자원/재고(${cleanResourcePoolId})의 잔여량(${poolEntry.availableStock})이 요청량(${requestedQty})보다 부족하여 [${marketplace}/${workflowId}] 초과 집행이 차단되고 엔티티(${cleanEntityKey})가 자동 보류(HOLD) 잠금되었습니다.`
      };
    }

    // 원자적 차감 및 선점 완료
    poolEntry.availableStock -= requestedQty;
    poolEntry.updatedAt = new Date().toISOString();
    poolEntry.reservedOrders.set(cleanEntityKey, {
      entityKey: cleanEntityKey,
      orderId: cleanEntityKey,
      reservedQty: requestedQty,
      workflowId,
      marketplace,
      reservedAt: poolEntry.updatedAt
    });
    this._maybeAutoPersist();

    const exhausted = poolEntry.availableStock === 0;
    return {
      ok: true,
      allowed: true,
      blocked: false,
      idempotentReplay: false,
      pillarId: 'SHARED_CAPACITY_AND_INVENTORY_RESERVATION',
      conflictCase: 'CASE_3_INVENTORY_OVERSELLING_CONFLICT',
      status: 'STOCK_RESERVED',
      domain,
      resourcePoolId: cleanResourcePoolId,
      skuId: cleanResourcePoolId,
      entityKey: cleanEntityKey,
      orderId: cleanEntityKey,
      workflowId,
      marketplace,
      reservedQty: requestedQty,
      remainingStock: poolEntry.availableStock,
      remainingCapacity: poolEntry.availableStock,
      triggerCrossChannelSoldOutSync: exhausted,
      reasonKo: exhausted
        ? `[${domain}] 공유 자원/재고(${cleanResourcePoolId}) 마지막 잔여량 ${requestedQty}단위가 [${marketplace}/${workflowId}] 엔티티(${cleanEntityKey})에 원자적 배정되었으며 잔여 0 도달로 전 채널 소진 동기화 신호가 발행되었습니다.`
        : `[${domain}] 공유 자원/재고(${cleanResourcePoolId}) ${requestedQty}단위가 정상 선점되었습니다 (잔여: ${poolEntry.availableStock}).`
    };
  }

  arbitrateSharedCapacityReservation(rawReq = {}) {
    return this.arbitrateInventoryReservation(rawReq);
  }

  /**
   * [범용 충돌 중재 ③ — 공유 리소스/DB/시트 동시 쓰기 충돌 중재 (`SHARED_RESOURCE_WRITE_LOCK`)]
   * 회계 워크플로우, 영업 워크플로우, 인사·재고 워크플로우가 동일한 구글 시트/노션/에어테이블/DB 테이블의
   * 같은 행·셀(entityKey)을 동시에 수정할 때 원자적 직렬화(Mutex Queue), 중복 행 추가(APPEND)의 부분 업데이트 자동 전환,
   * 재귀적 비파괴 병합(빈값·빈배열·빈객체 덮어쓰기 원천 차단) 및 중첩 객체 낙관적 버전 충돌 감지
   * @param {Object} rawReq
   */
  arbitrateSheetLedgerWrite(rawReq = {}) {
    const req = (rawReq && typeof rawReq === 'object' && !Array.isArray(rawReq)) ? rawReq : {};
    const cleanResourceId = String(
      req.resourceId ?? req.sheetId ?? req.ledgerId ?? req.spreadsheetId ?? req.tableId ?? req.notionDbId ?? req.databaseId ?? 'DEFAULT_SHARED_LEDGER'
    ).trim();
    const extracted = extractUniversalEntityKey(req);
    const cleanEntityKey = extracted.entityKey;
    const domain = extracted.domain;

    if (!cleanEntityKey) {
      return {
        ok: true,
        allowed: false,
        blocked: false,
        pillarId: 'SHARED_RESOURCE_WRITE_LOCK',
        conflictCase: 'CASE_4_SHEET_LEDGER_WRITE_CONFLICT',
        domain,
        status: 'INVALID_OR_EMPTY_INPUT',
        reasonKo: '유효한 행/레코드 식별자(entityKey/rowKey/leadId/invoiceId/orderId)가 없어 공유 리소스 쓰기 중재를 건너뛰었습니다.'
      };
    }

    const requestedOp = String(req.operation ?? req.op ?? 'UPSERT').trim().toUpperCase();
    const workflowId = String(req.workflowId ?? req.workflow_id ?? 'WF_DEFAULT').trim();
    const incomingFields = (req.fields && typeof req.fields === 'object' && !Array.isArray(req.fields))
      ? req.fields
      : {};
    const rowKey = `${cleanResourceId}::${cleanEntityKey}`;
    const existing = this.sheetRowLedger.get(rowKey);
    const mutexSequenceNo = ++this.mutexSequenceCounter;

    // 1) 신규 행/레코드 생성 (아직 공유 시트/DB에 해당 엔티티 행이 없는 경우)
    if (!existing) {
      const sanitizedInitial = deepCloneSafe(incomingFields);
      sanitizedInitial.entityKey = cleanEntityKey;
      sanitizedInitial.orderId = cleanEntityKey;

      const createdRecord = {
        rowKey,
        resourceId: cleanResourceId,
        sheetId: cleanResourceId,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        domain,
        version: 1,
        mutexSequenceNo,
        fields: sanitizedInitial,
        createdByWorkflow: workflowId,
        updatedByWorkflow: workflowId,
        updatedAt: new Date().toISOString()
      };
      this.sheetRowLedger.set(rowKey, createdRecord);
      this._enforceMapCap(this.sheetRowLedger);
      this._maybeAutoPersist();

      return {
        ok: true,
        allowed: true,
        blocked: false,
        pillarId: 'SHARED_RESOURCE_WRITE_LOCK',
        conflictCase: 'CASE_4_SHEET_LEDGER_WRITE_CONFLICT',
        status: 'ROW_APPEND_COMMITTED',
        domain,
        rowKey,
        resourceId: cleanResourceId,
        sheetId: cleanResourceId,
        entityKey: cleanEntityKey,
        orderId: cleanEntityKey,
        mutexSequenceNo,
        requestedOperation: requestedOp,
        operationExecuted: 'APPEND',
        duplicateRowPrevented: false,
        lostUpdatePrevented: false,
        preservedFields: [],
        updatedFields: Object.keys(sanitizedInitial),
        version: 1,
        mergedFields: deepCloneSafe(sanitizedInitial),
        workflowId,
        reasonKo: `[${domain}] 공유 리소스(${cleanResourceId})에 엔티티(${cleanEntityKey}) 신규 레코드(v1, Mutex #${mutexSequenceNo})가 원자적으로 생성되었습니다.`
      };
    }

    // 2) 이미 존재하는 엔티티 행에 대해 다른 부서/워크플로우가 중복 APPEND를 시도하거나 동시 UPDATE를 시도하는 경우
    const duplicateRowPrevented = requestedOp === 'APPEND';
    const hasExpectedVersion = req.expectedVersion !== undefined && req.expectedVersion !== null && Number.isFinite(Number(req.expectedVersion));

    if (hasExpectedVersion && Number(req.expectedVersion) !== existing.version) {
      const conflictingFields = [];
      for (const [k, v] of Object.entries(incomingFields)) {
        if (k === 'orderId' || k === 'entityKey' || isValueEmptyForMerge(v)) continue;
        const curVal = existing.fields[k];
        if (!isValueEmptyForMerge(curVal) && !deepEqualValues(curVal, v)) {
          conflictingFields.push({ field: k, currentValue: deepCloneSafe(curVal), attemptedValue: deepCloneSafe(v) });
        }
      }
      if (conflictingFields.length > 0) {
        return {
          ok: true,
          allowed: false,
          blocked: true,
          pillarId: 'SHARED_RESOURCE_WRITE_LOCK',
          conflictCase: 'CASE_4_SHEET_LEDGER_WRITE_CONFLICT',
          status: 'BLOCKED_OPTIMISTIC_LOCK_CONFLICT',
          domain,
          rowKey,
          resourceId: cleanResourceId,
          sheetId: cleanResourceId,
          entityKey: cleanEntityKey,
          orderId: cleanEntityKey,
          mutexSequenceNo,
          expectedVersion: Number(req.expectedVersion),
          currentVersion: existing.version,
          conflictingFields,
          workflowId,
          reasonKo: `[${domain}] 공유 리소스 행(${rowKey}) 버전 충돌(기대 v${req.expectedVersion} != 현재 v${existing.version}) 및 필드 값 경합이 감지되어 덮어쓰기가 차단되었습니다.`
        };
      }
    }

    // 재귀적 비파괴 필드 병합(Recursive Non-Destructive Deep Merge):
    // 타 부서 워크플로우의 빈값("", null, undefined, [], {})이 기존 유효값 및 중첩 객체 내부 필드를 지우지 못하도록 보호
    const preservedFields = [];
    const updatedFields = [];
    nonDestructiveDeepMerge(
      existing.fields,
      incomingFields,
      req.allowBlankOverwrite === true,
      '',
      preservedFields,
      updatedFields
    );

    existing.version += 1;
    existing.mutexSequenceNo = mutexSequenceNo;
    existing.updatedByWorkflow = workflowId;
    existing.updatedAt = new Date().toISOString();
    this._maybeAutoPersist();

    return {
      ok: true,
      allowed: true,
      blocked: false,
      pillarId: 'SHARED_RESOURCE_WRITE_LOCK',
      conflictCase: 'CASE_4_SHEET_LEDGER_WRITE_CONFLICT',
      status: duplicateRowPrevented
        ? 'CONVERTED_APPEND_TO_NON_DESTRUCTIVE_UPDATE'
        : 'NON_DESTRUCTIVE_ROW_UPDATE_COMMITTED',
      domain,
      rowKey,
      resourceId: cleanResourceId,
      sheetId: cleanResourceId,
      entityKey: cleanEntityKey,
      orderId: cleanEntityKey,
      mutexSequenceNo,
      requestedOperation: requestedOp,
      operationExecuted: duplicateRowPrevented ? 'CONVERTED_TO_PARTIAL_UPDATE' : 'PARTIAL_UPDATE',
      duplicateRowPrevented,
      lostUpdatePrevented: preservedFields.length > 0,
      preservedFields,
      updatedFields,
      version: existing.version,
      mergedFields: deepCloneSafe(existing.fields),
      workflowId,
      reasonKo: duplicateRowPrevented
        ? `[${domain}] 동일 엔티티(${cleanEntityKey})에 대한 중복 행 추가(APPEND)를 차단하고 기존 레코드(v${existing.version}, Mutex #${mutexSequenceNo}) 비파괴 부분 업데이트로 직렬화 중재했습니다 (보존 필드: ${preservedFields.length}개).`
        : `[${domain}] 공유 리소스 레코드(${cleanEntityKey}, v${existing.version}, Mutex #${mutexSequenceNo}) 비파괴 병합 업데이트 완료 (빈값 덮어쓰기 방어 필드: ${preservedFields.length}개).`
    };
  }

  arbitrateSharedResourceWriteLock(rawReq = {}) {
    return this.arbitrateSheetLedgerWrite(rawReq);
  }

  _enqueueSpooledApiRequest(accountKey, spoolEntry) {
    if (!this.apiSpoolQueue.has(accountKey)) {
      this.apiSpoolQueue.set(accountKey, []);
      this._enforceMapCap(this.apiSpoolQueue);
    }
    const queue = this.apiSpoolQueue.get(accountKey);
    queue.push(spoolEntry);
    const rankMap = { CRITICAL: 1, HIGH: 2, NORMAL: 3, LOW: 4 };
    queue.sort((a, b) => {
      const ra = rankMap[a.priority] || 3;
      const rb = rankMap[b.priority] || 3;
      if (ra !== rb) return ra - rb;
      return a.spooledAtMs - b.spooledAtMs;
    });
    if (queue.length > this.maxSize) {
      queue.pop();
    }
  }

  /**
   * [범용 충돌 중재 ④ — 전사 공유 API 쿼터 70% 안전 정격 통제 및 무중단 스풀 댐 (`GLOBAL_API_QUOTA_GOVERNOR`)]
   * 한 회사에서 마케팅·회계·CS·백오피스·커머스 워크플로우 10개가 동시에 OpenAI API, Google Sheets API,
   * Slack API, 국세청/홈택스 API 등을 호출할 때, 회사 전체 API 호출량을 70% 안전 정격(ratedLimit70)으로 묶어
   * 중앙 스풀링(Spool & Auto-Resume)하고 비상 차단 신호용 예비 쿼터를 보존함으로써 어느 워크플로우도 HTTP 429로 죽지 않게 보장
   * @param {Object} rawReq
   */
  arbitrateCrossWorkflowApiQuota(rawReq = {}) {
    const req = (rawReq && typeof rawReq === 'object' && !Array.isArray(rawReq)) ? rawReq : {};
    const provider = String(req.provider ?? req.apiProvider ?? req.platform ?? '').trim().toUpperCase();
    const domain = detectBusinessDomain(req);

    if (!provider) {
      return {
        ok: true,
        allowed: false,
        blocked: false,
        throttled: false,
        pillarId: 'GLOBAL_API_QUOTA_GOVERNOR',
        conflictCase: 'CASE_5_API_RATE_LIMIT_QUOTA_CONFLICT',
        domain,
        status: 'INVALID_OR_EMPTY_INPUT',
        reasonKo: '유효한 API 제공자(provider: OPENAI, GOOGLE_SHEETS, SLACK, HOMETAX, NOTION 등)가 지정되지 않아 쿼터 중재를 건너뛰었습니다.'
      };
    }

    const accountId = String(req.accountId ?? req.account_id ?? 'COMPANY_SHARED_ACCOUNT').trim();
    const workflowId = String(req.workflowId ?? req.workflow_id ?? 'WF_DEFAULT').trim();
    const priority = String(req.priority ?? 'NORMAL').trim().toUpperCase();
    const isHighPriority = (
      priority === 'CRITICAL' ||
      priority === 'HIGH' ||
      req.emergencyStopShipment === true ||
      req.emergencyFreeze === true
    );

    const defaultProviderLimit = DOMAIN_DEFAULT_API_LIMITS[provider] || 60;
    const rawLimit = Number(req.limitPerMinute ?? req.quotaLimitPerMin ?? defaultProviderLimit);
    const limitPerMinute = (Number.isFinite(rawLimit) && rawLimit > 0) ? Math.floor(rawLimit) : defaultProviderLimit;
    const ratedLimit70 = Math.max(1, Math.floor(limitPerMinute * 0.70));

    // 기본 안전 정격 비율은 70%(0.70)로 강제하되, 호출자가 명시적으로 safeThresholdRatio를 지정한 경우 수용
    const hasExplicitRatio = req.safeThresholdRatio !== undefined && req.safeThresholdRatio !== null && Number.isFinite(Number(req.safeThresholdRatio));
    const safeThresholdRatio = (hasExplicitRatio && Number(req.safeThresholdRatio) > 0 && Number(req.safeThresholdRatio) <= 1)
      ? Number(req.safeThresholdRatio)
      : 0.70;
    const safeNormalLimit = Math.max(1, Math.floor(limitPerMinute * safeThresholdRatio));

    const windowMs = (Number.isFinite(Number(req.windowMs)) && Number(req.windowMs) > 0)
      ? Math.floor(Number(req.windowMs))
      : 60000;
    const nowMs = (Number.isFinite(Number(req.nowMs ?? req.timestampMs)))
      ? Number(req.nowMs ?? req.timestampMs)
      : Date.now();
    const accountKey = `${provider}::${accountId}`;
    let bucket = this.apiQuotaLedger.get(accountKey);

    // 시계 역행(Clock Skew) 방어
    if (bucket && nowMs < bucket.windowStartMs) {
      bucket.windowStartMs = nowMs;
    }

    if (!bucket || (nowMs - bucket.windowStartMs >= windowMs) || req.resetQuotaWindow === true) {
      const prevUsed = (bucket && req.resetQuotaWindow !== true && (nowMs - bucket.windowStartMs < windowMs * 2))
        ? bucket.usedCount
        : 0;
      bucket = {
        accountKey,
        provider,
        accountId,
        limitPerMinute,
        ratedLimit70,
        windowMs,
        windowStartMs: nowMs,
        prevWindowUsedCount: prevUsed,
        usedCount: 0,
        spooledCount: 0,
        workflowUsage: {},
        domainUsage: {}
      };
      this.apiQuotaLedger.set(accountKey, bucket);
      this._enforceMapCap(this.apiQuotaLedger);
    }

    if (req.currentWindowUsedOverride !== undefined && req.currentWindowUsedOverride !== null && Number.isFinite(Number(req.currentWindowUsedOverride))) {
      bucket.usedCount = Math.max(0, Math.floor(Number(req.currentWindowUsedOverride)));
    }

    const cost = (Number.isFinite(Number(req.cost)) && Number(req.cost) > 0) ? Math.floor(Number(req.cost)) : 1;
    const elapsedInWindowMs = Math.max(0, nowMs - bucket.windowStartMs);
    const slidingCarryOver = (req.enforceSlidingWindow === true && bucket.prevWindowUsedCount > 0 && elapsedInWindowMs < windowMs)
      ? Math.floor(bucket.prevWindowUsedCount * ((windowMs - elapsedInWindowMs) / windowMs))
      : 0;
    const effectiveUsedCount = bucket.usedCount + slidingCarryOver;
    const extracted = extractUniversalEntityKey(req);

    // 1) 계정 전체 하드 리미트(100%) 도달 시 -> 즉시 중앙 스풀링 대기
    if (effectiveUsedCount + cost > limitPerMinute) {
      bucket.spooledCount += cost;
      const baseWaitMs = Math.max(500, windowMs - elapsedInWindowMs);
      const recommendedWaitMs = baseWaitMs + ((bucket.usedCount % 7) * 127);
      const spoolTicketId = `SPOOL-${provider}-${accountId}-${++this.mutexSequenceCounter}`;
      this._enqueueSpooledApiRequest(accountKey, {
        spoolTicketId,
        accountKey,
        provider,
        accountId,
        domain,
        workflowId,
        entityKey: extracted.entityKey || null,
        priority,
        cost,
        spooledAtMs: nowMs,
        recommendedWaitMs,
        payload: deepCloneSafe(req.payload || null)
      });
      this._maybeAutoPersist();
      const pendingSpoolDepth = (this.apiSpoolQueue.get(accountKey) || []).length;

      return {
        ok: true,
        allowed: false,
        blocked: true,
        throttled: true,
        spooledForAutoResume: true,
        spoolTicketId,
        pendingSpoolDepth,
        pillarId: 'GLOBAL_API_QUOTA_GOVERNOR',
        conflictCase: 'CASE_5_API_RATE_LIMIT_QUOTA_CONFLICT',
        status: 'THROTTLED_HARD_QUOTA_EXHAUSTED',
        domain,
        provider,
        accountId,
        workflowId,
        priority,
        usedCount: bucket.usedCount,
        effectiveUsedCount,
        limitPerMinute,
        ratedLimit70,
        safeNormalLimit,
        remainingQuota: Math.max(0, limitPerMinute - effectiveUsedCount),
        recommendedWaitMs,
        reasonKo: `[${provider}/${accountId}] 전사 분당 쿼터 한도(${limitPerMinute}회) 도달로 HTTP 429 차단을 막기 위해 [${workflowId}] 요청이 중앙 스풀 큐(${spoolTicketId}, 대기 ${pendingSpoolDepth}건)에 안전 적재되었으며 ${recommendedWaitMs}ms 후 자동 재개(Auto-Resume)됩니다.`
      };
    }

    // 2) 일반/저우선순위(NORMAL/LOW) 요청이 70% 안전 정격(safeNormalLimit)을 초과한 경우 -> 중앙 스풀링(Spool & Auto-Resume)으로 전환하고 잔여 30%는 긴급 제어용으로 보호
    if (!isHighPriority && (effectiveUsedCount + cost > safeNormalLimit)) {
      bucket.spooledCount += cost;
      const recommendedWaitMs = 1270 + ((bucket.usedCount % 5) * 250);
      const spoolTicketId = `SPOOL-${provider}-${accountId}-${++this.mutexSequenceCounter}`;
      this._enqueueSpooledApiRequest(accountKey, {
        spoolTicketId,
        accountKey,
        provider,
        accountId,
        domain,
        workflowId,
        entityKey: extracted.entityKey || null,
        priority,
        cost,
        spooledAtMs: nowMs,
        recommendedWaitMs,
        payload: deepCloneSafe(req.payload || null)
      });
      this._maybeAutoPersist();
      const pendingSpoolDepth = (this.apiSpoolQueue.get(accountKey) || []).length;

      return {
        ok: true,
        allowed: false,
        blocked: true,
        throttled: true,
        spooledForAutoResume: true,
        spoolTicketId,
        pendingSpoolDepth,
        pillarId: 'GLOBAL_API_QUOTA_GOVERNOR',
        conflictCase: 'CASE_5_API_RATE_LIMIT_QUOTA_CONFLICT',
        status: 'THROTTLED_QUEUED_BY_ARBITRATOR',
        domain,
        provider,
        accountId,
        workflowId,
        priority,
        usedCount: bucket.usedCount,
        effectiveUsedCount,
        limitPerMinute,
        ratedLimit70,
        safeNormalLimit,
        remainingEmergencyReserve: Math.max(0, limitPerMinute - effectiveUsedCount),
        recommendedWaitMs,
        reasonKo: `[${provider}/${accountId}] 전사 다중 워크플로우 합산 호출량이 안전 정격(${safeNormalLimit}/${limitPerMinute}회, 70% Governor)에 도달하여 [${domain}/${workflowId}] 작업을 중앙 스풀 댐(${spoolTicketId}, 대기 ${pendingSpoolDepth}건)에 적재(${recommendedWaitMs}ms 후 자동 이어하기)하고, 잔여 ${limitPerMinute - effectiveUsedCount}회는 긴급 위기동결·출고보류(CRITICAL/HIGH) 예비 쿼터로 보호합니다.`
      };
    }

    // 3) 쿼터 승인 (70% 안전 정격 구간 이내 또는 CRITICAL/HIGH 긴급 예비 쿼터 사용)
    const usedEmergencyReserve = isHighPriority && (effectiveUsedCount + cost > safeNormalLimit);
    bucket.usedCount += cost;
    bucket.workflowUsage[workflowId] = (bucket.workflowUsage[workflowId] || 0) + cost;
    bucket.domainUsage[domain] = (bucket.domainUsage[domain] || 0) + cost;
    this._maybeAutoPersist();

    return {
      ok: true,
      allowed: true,
      blocked: false,
      throttled: false,
      spooledForAutoResume: false,
      usedEmergencyReserve,
      pillarId: 'GLOBAL_API_QUOTA_GOVERNOR',
      conflictCase: 'CASE_5_API_RATE_LIMIT_QUOTA_CONFLICT',
      status: usedEmergencyReserve ? 'ALLOWED_BY_EMERGENCY_RESERVE' : 'ALLOWED_WITHIN_QUOTA',
      domain,
      provider,
      accountId,
      workflowId,
      priority,
      usedCount: bucket.usedCount,
      effectiveUsedCount: effectiveUsedCount + cost,
      limitPerMinute,
      ratedLimit70,
      safeNormalLimit,
      remainingQuota: Math.max(0, limitPerMinute - (effectiveUsedCount + cost)),
      workflowUsageSnapshot: { ...bucket.workflowUsage },
      domainUsageSnapshot: { ...bucket.domainUsage },
      reasonKo: usedEmergencyReserve
        ? `[${provider}/${accountId}] 긴급 우선순위(${priority}) 요청으로 비상 예비 쿼터를 할당받아 즉시 실행 승인되었습니다.`
        : `[${provider}/${accountId}] 전사 통합 70% 안전 정격 쿼터 검증 통과 (현재 ${bucket.usedCount}/${safeNormalLimit}회 안전정격, 물리한도 ${limitPerMinute}회).`
    };
  }

  arbitrateGlobalApiQuotaGovernor(rawReq = {}) {
    return this.arbitrateCrossWorkflowApiQuota(rawReq);
  }

  /**
   * 중앙 스풀 큐에 적재된 API 대기 작업들을 새 쿼터 윈도우의 70% 안전 정격 범위 내에서 자동 이어하기(Auto-Resume Drain)
   */
  drainSpooledApiRequests(rawOpts = {}) {
    const opts = (rawOpts && typeof rawOpts === 'object' && !Array.isArray(rawOpts)) ? rawOpts : {};
    const provider = String(opts.provider ?? opts.apiProvider ?? '').trim().toUpperCase();
    if (!provider) {
      return {
        ok: true,
        resumedCount: 0,
        remainingSpoolDepth: 0,
        resumedItems: [],
        status: 'INVALID_OR_EMPTY_PROVIDER'
      };
    }
    const accountId = String(opts.accountId ?? opts.account_id ?? 'COMPANY_SHARED_ACCOUNT').trim();
    const accountKey = `${provider}::${accountId}`;
    const queue = this.apiSpoolQueue.get(accountKey) || [];
    if (queue.length === 0) {
      return {
        ok: true,
        provider,
        accountId,
        resumedCount: 0,
        remainingSpoolDepth: 0,
        resumedItems: [],
        status: 'SPOOL_QUEUE_EMPTY'
      };
    }

    if (opts.resetQuotaWindow === true && this.apiQuotaLedger.has(accountKey)) {
      const b = this.apiQuotaLedger.get(accountKey);
      b.prevWindowUsedCount = 0;
      b.usedCount = 0;
      b.windowStartMs = (Number.isFinite(Number(opts.nowMs))) ? Number(opts.nowMs) : Date.now();
    }

    const maxDrain = (Number.isFinite(Number(opts.maxDrainCount)) && Number(opts.maxDrainCount) > 0)
      ? Math.floor(Number(opts.maxDrainCount))
      : queue.length;
    const resumedItems = [];
    const remainingQueue = [];

    for (const item of queue) {
      if (resumedItems.length >= maxDrain) {
        remainingQueue.push(item);
        continue;
      }
      const decision = this.arbitrateCrossWorkflowApiQuota({
        provider: item.provider,
        accountId: item.accountId,
        domain: item.domain,
        workflowId: item.workflowId,
        entityKey: item.entityKey,
        priority: item.priority,
        cost: item.cost,
        nowMs: opts.nowMs
      });
      if (decision.allowed) {
        resumedItems.push({
          ...item,
          resumedAt: new Date().toISOString(),
          resumeStatus: decision.status
        });
      } else {
        // 방금 재시도에서 다시 스풀링된 중복 티켓 제거 후 원본 유지
        const currentQ = this.apiSpoolQueue.get(accountKey) || [];
        const dupIdx = currentQ.findIndex(x => x.spoolTicketId === decision.spoolTicketId);
        if (dupIdx !== -1) currentQ.splice(dupIdx, 1);
        remainingQueue.push(item);
      }
    }

    this.apiSpoolQueue.set(accountKey, remainingQueue);
    this._maybeAutoPersist();
    return {
      ok: true,
      provider,
      accountId,
      resumedCount: resumedItems.length,
      remainingSpoolDepth: remainingQueue.length,
      resumedItems,
      status: resumedItems.length > 0 ? 'SPOOL_AUTO_RESUMED' : 'WAITING_FOR_QUOTA_WINDOW'
    };
  }

  /**
   * 전 도메인 다중 워크플로우 충돌 통합 중재 라우터 (Universal Cross-Workflow Conflict Arbitrator)
   * @param {Object} rawEvent
   */
  arbitrateCrossWorkflowConflict(rawEvent = {}) {
    const evt = (rawEvent && typeof rawEvent === 'object' && !Array.isArray(rawEvent)) ? rawEvent : {};
    const explicitType = String(evt.conflictType ?? evt.pillarId ?? evt.caseType ?? '').trim().toUpperCase();

    // Phase 1: 명시적 conflictType / pillarId 최우선 라우팅 (타 필드 존재로 인한 하이재킹 원천 차단)
    if (explicitType) {
      if (
        explicitType === 'CASE_1' ||
        explicitType === 'CASE_1_OUTBOUND_INTENT_AND_CLAIM_MUTEX' ||
        explicitType === 'OUTBOUND_NOTIFICATION' ||
        explicitType === 'OUTBOUND_MESSAGE_DEDUP' ||
        explicitType === 'OUTBOUND_MESSAGE_DEDUP_AND_PRIORITY'
      ) {
        return this.arbitrateOutboundNotification(evt);
      }
      if (
        explicitType === 'CASE_2' ||
        explicitType === 'CASE_2_ORDER_STATE_HOLD_VS_DISPATCH' ||
        explicitType === 'ORDER_STATE' ||
        explicitType === 'CONTRA_INTENT_MUTEX'
      ) {
        return this.arbitrateOrderStateTransition(evt);
      }
      if (
        explicitType === 'CASE_3' ||
        explicitType === 'CASE_3_INVENTORY_ATOMIC_RESERVATION' ||
        explicitType === 'CASE_3_INVENTORY_OVERSELLING_CONFLICT' ||
        explicitType === 'INVENTORY' ||
        explicitType === 'SHARED_CAPACITY' ||
        explicitType === 'SHARED_CAPACITY_AND_INVENTORY_RESERVATION'
      ) {
        return this.arbitrateInventoryReservation(evt);
      }
      if (
        explicitType === 'CASE_4' ||
        explicitType === 'CASE_4_SHEET_LEDGER_ROW_UPSERT_MUTEX' ||
        explicitType === 'CASE_4_SHEET_LEDGER_WRITE_CONFLICT' ||
        explicitType === 'SHEET_LEDGER' ||
        explicitType === 'SHARED_RESOURCE_LOCK' ||
        explicitType === 'SHARED_RESOURCE_WRITE_LOCK'
      ) {
        return this.arbitrateSheetLedgerWrite(evt);
      }
      if (
        explicitType === 'CASE_5' ||
        explicitType === 'CASE_5_ACCOUNT_API_QUOTA_GOVERNOR' ||
        explicitType === 'CASE_5_API_RATE_LIMIT_QUOTA_CONFLICT' ||
        explicitType === 'API_QUOTA' ||
        explicitType === 'GLOBAL_API_QUOTA' ||
        explicitType === 'GLOBAL_API_QUOTA_GOVERNOR'
      ) {
        return this.arbitrateCrossWorkflowApiQuota(evt);
      }
    }

    // Phase 2: 암묵적 페이로드 시그니처 기반 추론 라우팅
    if (evt.provider || evt.apiProvider) {
      return this.arbitrateCrossWorkflowApiQuota(evt);
    }
    if (evt.resourcePoolId || evt.budgetId || evt.seatPoolId || evt.skuId || evt.sku_id) {
      return this.arbitrateInventoryReservation(evt);
    }
    if (evt.fields || evt.operation || evt.op || evt.sheetId || evt.ledgerId || evt.tableId || evt.notionDbId || evt.resourceId) {
      return this.arbitrateSheetLedgerWrite(evt);
    }
    if (evt.targetState || evt.nextState || evt.targetChannel) {
      return this.arbitrateOrderStateTransition(evt);
    }
    if (evt.intent || evt.intentType || evt.actionIntent || evt.candidateChannels || evt.recipient) {
      return this.arbitrateOutboundNotification(evt);
    }

    return {
      ok: true,
      allowed: false,
      blocked: false,
      status: 'NO_APPLICABLE_CONFLICT_CASE',
      supportedCases: UNIVERSAL_CROSS_WORKFLOW_CONFLICT_MATRIX.map(c => c.caseId),
      supportedPillars: UNIVERSAL_CROSS_WORKFLOW_CONFLICT_MATRIX.map(c => c.pillarId)
    };
  }

  arbitrateUniversalWorkflowConflict(rawEvent = {}) {
    return this.arbitrateCrossWorkflowConflict(rawEvent);
  }

  /**
   * 범용 워크플로우 무중단·충돌 중재 커널(Universal Workflow Arbitration & Non-Stop Kernel) 상태 및 아키텍처 요약 반환
   */
  getCrossWorkflowArbitrationSummary() {
    let totalSpooledRequests = 0;
    for (const q of this.apiSpoolQueue.values()) {
      totalSpooledRequests += q.length;
    }
    return {
      ok: true,
      architecturePositioning: 'UNIVERSAL_WORKFLOW_ARBITRATION_AND_NONSTOP_KERNEL',
      legacyPositioningAlias: 'HEADLESS_ERP_ARBITRATION_KERNEL',
      architectureNameKo: '범용 워크플로우 무중단·충돌 중재 커널 (Universal Workflow Arbitration & Non-Stop Kernel)',
      workflowJsonAloneSufficient: false,
      daemonArbitrationMandatory: true,
      supportedDomains: Object.values(UNIVERSAL_BUSINESS_DOMAINS),
      supportedEntityKeyExamples: [
        'lead_id / contact_id (영업/CRM 리드·고객)',
        'invoice_id / voucher_id / statement_id (세금계산서·회계전표·정산서)',
        'ticket_id / inquiry_id / cs_id (고객 CS 문의·클레임)',
        'post_id / campaign_id (마케팅·SNS·뉴스레터 발행)',
        'employee_id / contract_id / applicant_id (인사·백오피스·전자계약)',
        'order_id / orderNo / shipment_id (커머스·물류 주문·운송장)'
      ],
      totalConflictCasesCovered: UNIVERSAL_CROSS_WORKFLOW_CONFLICT_MATRIX.length,
      conflictMatrix: UNIVERSAL_CROSS_WORKFLOW_CONFLICT_MATRIX,
      activeLedgerMetrics: {
        orderDedupCount: this.historySet.size,
        actionIntentCount: this.actionIntentLedger.size,
        trackedOrderStateCount: this.orderStateLedger.size,
        trackedEntityStateCount: this.orderStateLedger.size,
        trackedContentPublishCount: this.contentPublishLedger.size,
        trackedSkuInventoryCount: this.inventoryLedger.size,
        trackedCapacityPoolCount: this.inventoryLedger.size,
        trackedSheetRowCount: this.sheetRowLedger.size,
        trackedSharedResourceRowCount: this.sheetRowLedger.size,
        trackedApiQuotaAccountCount: this.apiQuotaLedger.size,
        spooledApiRequestCount: totalSpooledRequests
      },
      strategicConclusionKo: '단품 .n8n.json 워크플로우 파일들은 각자 고립된 메모리에서 실행되므로, 한 기업이 마케팅·영업(CRM)·회계(세금계산서)·인사(백오피스)·CS·커머스 등 여러 부서의 워크플로우를 동시에 가동하는 순간 중복 발송, 상반된 비즈니스 의도 충돌(수신거부 고객 프로모션 발송, 미승인 전표 세금계산서 발행), 공유 시트/DB 덮어쓰기, 전사 API 쿼터 폭발(HTTP 429)이 필연적으로 발생합니다. 따라서 AutoFlow 상주형 엔진은 단순 에러 복구기를 넘어 기업 내 모든 도메인의 n8n 워크플로우들을 중앙에서 지휘·중재하는 『범용 워크플로우 ERP 오케스트레이터(Universal Workflow Arbitration Kernel)』로서 작동합니다.'
    };
  }

  getUniversalArbitrationKernelSummary() {
    return this.getCrossWorkflowArbitrationSummary();
  }

  getErpArbitrationKernelSummary() {
    return this.getCrossWorkflowArbitrationSummary();
  }

  getArbitrationLedgerSummary() {
    const summary = this.getCrossWorkflowArbitrationSummary();
    const spooled = (summary.activeLedgerMetrics && summary.activeLedgerMetrics.spooledApiRequestCount) || 0;
    const activeLocks = this.sheetRowLedger.size + this.inventoryLedger.size;
    const totalEvents = this.mutexSequenceCounter || (this.historySet.size + this.actionIntentLedger.size + this.orderStateLedger.size);
    return {
      ...summary,
      spooledApiRequestCount: spooled,
      totalArbitratedEvents: totalEvents,
      activeLocksCount: activeLocks,
      supportedDomains: summary.supportedDomains || Object.values(UNIVERSAL_BUSINESS_DOMAINS)
    };
  }

  /**
   * 사이드카 데몬 재시작 시에도 중재 원장(엔티티 상태·공유 시트 행 버전·API 스풀 큐)을 보존하기 위한 원자적 스냅샷 저장
   */
  persistLedgerSnapshot(targetFilePath = null) {
    const resolvedPath = typeof targetFilePath === 'string' && targetFilePath.trim()
      ? targetFilePath.trim()
      : this.snapshotPath;
    if (!resolvedPath) {
      return { ok: true, persisted: false, status: 'NO_SNAPSHOT_PATH_CONFIGURED' };
    }
    try {
      const dir = path.dirname(resolvedPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      const snapshot = {
        schemaVersion: '1.0.0',
        savedAt: new Date().toISOString(),
        mutexSequenceCounter: this.mutexSequenceCounter,
        historyQueue: [...this.historyQueue],
        actionIntentQueue: [...this.actionIntentQueue],
        actionIntentEntries: [...this.actionIntentLedger.entries()],
        orderClaimEntries: [...this.orderClaimHistory.entries()].map(([k, setVal]) => [k, [...setVal]]),
        orderStateEntries: [...this.orderStateLedger.entries()],
        contentPublishEntries: [...this.contentPublishLedger.entries()],
        inventoryEntries: [...this.inventoryLedger.entries()].map(([k, v]) => [
          k,
          { ...v, reservedOrders: [...v.reservedOrders.entries()] }
        ]),
        sheetRowEntries: [...this.sheetRowLedger.entries()],
        apiQuotaEntries: [...this.apiQuotaLedger.entries()],
        apiSpoolEntries: [...this.apiSpoolQueue.entries()]
      };
      const tmpPath = `${resolvedPath}.tmp.${process.pid}`;
      fs.writeFileSync(tmpPath, JSON.stringify(snapshot, null, 2), 'utf8');
      fs.renameSync(tmpPath, resolvedPath);
      return { ok: true, persisted: true, status: 'SNAPSHOT_PERSISTED', snapshotPath: resolvedPath };
    } catch (err) {
      return { ok: false, persisted: false, status: 'SNAPSHOT_PERSIST_ERROR', message: err.message };
    }
  }

  /**
   * 디스크 스냅샷으로부터 중재 원장 상태 복원
   */
  restoreLedgerSnapshot(sourceFilePath = null) {
    const resolvedPath = typeof sourceFilePath === 'string' && sourceFilePath.trim()
      ? sourceFilePath.trim()
      : this.snapshotPath;
    if (!resolvedPath || !fs.existsSync(resolvedPath)) {
      return { ok: true, restored: false, status: 'SNAPSHOT_FILE_NOT_FOUND' };
    }
    try {
      const raw = JSON.parse(fs.readFileSync(resolvedPath, 'utf8'));
      if (!raw || typeof raw !== 'object') {
        return { ok: true, restored: false, status: 'INVALID_SNAPSHOT_PAYLOAD' };
      }
      this.clear();
      this.mutexSequenceCounter = Number(raw.mutexSequenceCounter) || 0;
      if (Array.isArray(raw.historyQueue)) {
        this.historyQueue = raw.historyQueue.slice(-this.maxSize);
        this.historySet = new Set(this.historyQueue);
      }
      if (Array.isArray(raw.actionIntentQueue)) {
        this.actionIntentQueue = raw.actionIntentQueue.slice(-this.maxSize);
      }
      if (Array.isArray(raw.actionIntentEntries)) {
        this.actionIntentLedger = new Map(raw.actionIntentEntries.slice(-this.maxSize));
      }
      if (Array.isArray(raw.orderClaimEntries)) {
        this.orderClaimHistory = new Map(
          raw.orderClaimEntries.slice(-this.maxSize).map(([k, arr]) => [k, new Set(Array.isArray(arr) ? arr : [])])
        );
      }
      if (Array.isArray(raw.orderStateEntries)) {
        this.orderStateLedger = new Map(raw.orderStateEntries.slice(-this.maxSize));
      }
      if (Array.isArray(raw.contentPublishEntries)) {
        this.contentPublishLedger = new Map(raw.contentPublishEntries.slice(-this.maxSize));
      }
      if (Array.isArray(raw.inventoryEntries)) {
        this.inventoryLedger = new Map(
          raw.inventoryEntries.slice(-this.maxSize).map(([k, v]) => [
            k,
            { ...v, reservedOrders: new Map(Array.isArray(v && v.reservedOrders) ? v.reservedOrders : []) }
          ])
        );
      }
      if (Array.isArray(raw.sheetRowEntries)) {
        this.sheetRowLedger = new Map(raw.sheetRowEntries.slice(-this.maxSize));
      }
      if (Array.isArray(raw.apiQuotaEntries)) {
        this.apiQuotaLedger = new Map(raw.apiQuotaEntries.slice(-this.maxSize));
      }
      if (Array.isArray(raw.apiSpoolEntries)) {
        this.apiSpoolQueue = new Map(raw.apiSpoolEntries.slice(-this.maxSize));
      }
      return { ok: true, restored: true, status: 'SNAPSHOT_RESTORED', snapshotPath: resolvedPath };
    } catch (err) {
      return { ok: false, restored: false, status: 'SNAPSHOT_RESTORE_ERROR', message: err.message };
    }
  }

  /**
   * 메모리 캐시 초기화 (테스트 또는 공장 초기화 시 호출)
   */
  clear() {
    this.historyQueue = [];
    this.historySet.clear();
    this.actionIntentQueue = [];
    this.actionIntentLedger.clear();
    this.orderClaimHistory.clear();
    this.orderStateLedger.clear();
    this.contentPublishLedger.clear();
    this.inventoryLedger.clear();
    this.sheetRowLedger.clear();
    this.apiQuotaLedger.clear();
    this.apiSpoolQueue.clear();
    this.mutexSequenceCounter = 0;
  }
}

const defaultSnapshotPath = path.join(__dirname, '..', 'data', 'arbitration_ledger_snapshot.json');
const defaultSentinel = new OrderDedupSentinel({
  maxSize: 2000,
  snapshotPath: defaultSnapshotPath,
  autoPersist: true
});

try {
  if (fs.existsSync(defaultSnapshotPath)) {
    defaultSentinel.restoreLedgerSnapshot(defaultSnapshotPath);
  }
} catch (_) {}

defaultSentinel.defaultSentinel = defaultSentinel;

module.exports = {
  OrderDedupSentinel,
  UniversalWorkflowArbitrationKernel: OrderDedupSentinel,
  orderDedupSentinel: defaultSentinel,
  universalArbitrationKernel: defaultSentinel,
  defaultSentinel,
  UNIVERSAL_BUSINESS_DOMAINS,
  DOMAIN_DEFAULT_API_LIMITS,
  UNIVERSAL_CROSS_WORKFLOW_CONFLICT_MATRIX,
  CROSS_WORKFLOW_CONFLICT_MATRIX,
  CHANNEL_PRIORITY_TABLE,
  HOLD_OR_CLAIM_ORDER_STATES,
  DISPATCH_ACTION_STATES,
  IRREVERSIBLE_COMMITTED_STATES,
  detectBusinessDomain,
  extractUniversalEntityKey,
  arbitrateOutboundNotification: (...args) => defaultSentinel.arbitrateOutboundNotification(...args),
  arbitrateUniversalOutboundDedup: (...args) => defaultSentinel.arbitrateUniversalOutboundDedup(...args),
  arbitrateOrderStateTransition: (...args) => defaultSentinel.arbitrateOrderStateTransition(...args),
  arbitrateContraIntentMutex: (...args) => defaultSentinel.arbitrateContraIntentMutex(...args),
  arbitrateInventoryReservation: (...args) => defaultSentinel.arbitrateInventoryReservation(...args),
  arbitrateSharedCapacityReservation: (...args) => defaultSentinel.arbitrateSharedCapacityReservation(...args),
  arbitrateSheetLedgerWrite: (...args) => defaultSentinel.arbitrateSheetLedgerWrite(...args),
  arbitrateSharedResourceWriteLock: (...args) => defaultSentinel.arbitrateSharedResourceWriteLock(...args),
  arbitrateCrossWorkflowApiQuota: (...args) => defaultSentinel.arbitrateCrossWorkflowApiQuota(...args),
  arbitrateGlobalApiQuotaGovernor: (...args) => defaultSentinel.arbitrateGlobalApiQuotaGovernor(...args),
  drainSpooledApiRequests: (...args) => defaultSentinel.drainSpooledApiRequests(...args),
  arbitrateCrossWorkflowConflict: (...args) => defaultSentinel.arbitrateCrossWorkflowConflict(...args),
  arbitrateUniversalWorkflowConflict: (...args) => defaultSentinel.arbitrateUniversalWorkflowConflict(...args),
  getCrossWorkflowArbitrationSummary: (...args) => defaultSentinel.getCrossWorkflowArbitrationSummary(...args),
  getUniversalArbitrationKernelSummary: (...args) => defaultSentinel.getUniversalArbitrationKernelSummary(...args),
  getErpArbitrationKernelSummary: (...args) => defaultSentinel.getErpArbitrationKernelSummary(...args),
  getArbitrationLedgerSummary: (...args) => defaultSentinel.getArbitrationLedgerSummary(...args),
  persistLedgerSnapshot: (...args) => defaultSentinel.persistLedgerSnapshot(...args),
  restoreLedgerSnapshot: (...args) => defaultSentinel.restoreLedgerSnapshot(...args)
};



