/**
 * Phase 3 Automated Refactoring Script for v8_native_combat_runner.js
 * Replaces hardcoded keywords and patchwork regexes with the 3 Regularity Engines.
 */

const fs = require('fs');
const path = require('path');

const targetPath = '/Volumes/Mac_SSD/Projects/AutoFlowEngine/core/v8_native_combat_runner.js';
let content = fs.readFileSync(targetPath, 'utf8');

// 1. Definition of evaluateSyntacticValence and resolveUniversalScale
const regularityEnginesCode = `
    // ============================================================================
    // [규칙성 엔진 2] 구문론적 감성 중화기 (Syntactic Valence Engine)
    // 개별 단어 수십 개 나열을 배제하고, 어휘 체계 및 결합 구문 규칙으로 감성 평가
    // ============================================================================
    function evaluateSyntacticValence(text) {
        if (!text || typeof text !== 'string') {
            return { isCrisis: false, isPraise: false, cleanedText: '', sarcasmDetected: false };
        }

        let normText = text.slice(0, 3000).replace(/\\s+/g, ' ');

        // 1. 반어법/역설적 혹평 검출 ("5점이라더니 진짜 최악", "이게 5점짜리 식당인가요?")
        const sarcasmRegex = /([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)(?:이라더니|짜리\\s*(?:식당|음식|가게|곳)?인가요|이라고\\??|준다는\\s*게)/i;
        const sarcasmDetected = sarcasmRegex.test(normText);

        // 2. 공공기관/위생 인증 호평 중화 규칙 (식약처/보건소/구청/위생과 + 인증/선정/우수/식당)
        const certPraiseRegex = /(?:식약처|보건소|구청|위생과)\\s*(?:인증|지정|선정|표창|우수)?\\s*(?:위생\\s*식당|안심\\s*식당|모범\\s*음식점|맛집|위생등급|위생\\s*점검\\s*안심|위생점검\\s*안심|위생\\s*안심|위생안심)/gi;
        let cleanedText = normText.replace(certPraiseRegex, ' ');

        // 3. 구문 부정/안심 중화 규칙 ([위기어휘] + 0~3단어 + [안심접미사])
        const riskWords = [
            '벌레', '식중독', '장염', '노로바이러스', '병원', '배탈', '알레르기', '두드러기', '복통',
            '이물질', '머리카락', '쇳조각', '유리조각', '비닐', '침', '곰팡이', '신고', '경찰',
            '보건소', '구청', '식약처', '위생과', '영업정지', '소비자원', '소비자고발센터', '민원',
            '손해배상', '고발', '인권위', '기만', '배째라', '환불', '사기', '쓰레기', '상했', '쉰내',
            '누락', '오배송', '불친절', '식어서', '식었', '쏟아짐', '샜음', '파손'
        ].join('|');

        const peaceSuffixes = [
            '나올\\\\s*일\\\\s*없이', '나올\\\\s*걱정\\\\s*없이', '볼\\\\s*일\\\\s*없이', '버릴\\\\s*일\\\\s*없이',
            '걱정\\\\s*없이', '갈\\\\s*일\\\\s*없이', '걸릴\\\\s*일\\\\s*없이', '걱정없는', '안심하고', '안심',
            '탈\\\\s*없이', '없이', '없고', '안\\\\s*나고', '않고', '안\\\\s*하고', '튈\\\\s*걱정\\\\s*없이',
            '뱉을\\\\s*일\\\\s*없이', '할\\\\s*일\\\\s*없이', '넣을\\\\s*걱정\\\\s*없이', '넣을\\\\s*일\\\\s*없이'
        ].join('|');

        const peacePrefixRegex = new RegExp(\`(?:$\{riskWords\})\\\\s*(?:한\\\\s*마리|하나|한\\\\s*개|한\\\\s*올|핀\\\\s*거\\\\s*하나)?\\\\s*(?:전혀\\\\s*)?(?:\\\\s*[^.!?\\\\n\\\\s]{1,15}){0,3}\\\\s*(?:$\{peaceSuffixes\})\`, 'gi');
        const peaceSuffixRegex = new RegExp(\`(?:$\{peaceSuffixes\})\\\\s*(?:\\\\s*[^.!?\\\\n\\\\s]{1,15}){0,3}\\\\s*(?:$\{riskWords\})\`, 'gi');

        cleanedText = cleanedText
            .replace(peacePrefixRegex, ' ')
            .replace(peaceSuffixRegex, ' ')
            .replace(/사기적인\\s*맛/gi, ' ');

        // 4. 핵심 위기 판별
        const coreRiskPattern = new RegExp(\`(?:$\{riskWords\}|바퀴벌레|최악|썩었|폭망|위세척|응급실|입원|119|중환자실|구급차|구토|설사|링거|수액|더러워)\`, 'i');
        const isCrisis = coreRiskPattern.test(cleanedText);

        // 5. 호평 판별
        const praisePattern = /(?:맛있|인생|추천|최고|대박|친절|감사|깨끗|위생\\s*최상|위생식당|안심식당|모범음식점|안심|만점|우수)/i;
        const isPraise = praisePattern.test(cleanedText) || certPraiseRegex.test(normText);

        return { isCrisis, isPraise, cleanedText, sarcasmDetected };
    }

    // ============================================================================
    // [규칙성 엔진 1] 통합 척도 역산기 (Universal Scale Resolver)
    // 수치, 분수, 백분율, 수사, 이모지, 척도 문장 등을 수학적 5점 척도로 일원화 변환
    // ============================================================================
    function resolveUniversalScale(val, reviewText, targetField = 'rating', depth = 0) {
        if (depth > 35) return NaN;

        if (typeof val === 'string') {
            if (val.length > 3000) val = val.slice(0, 3000);
            val = val.replace(/\\s+/g, ' ');
        }
        if (typeof reviewText === 'string') {
            if (reviewText.length > 3000) reviewText = reviewText.slice(0, 3000);
            reviewText = reviewText.replace(/\\s+/g, ' ');
        }

        while (Array.isArray(val)) {
            if (val.length === 0) return NaN;
            val = val[0];
        }

        if (val === null || val === undefined) {
            if (reviewText && typeof reviewText === 'string') {
                const valence = evaluateSyntacticValence(reviewText);
                if (valence.sarcasmDetected) return 1;

                const extractedScore = resolveUniversalScale(valence.cleanedText, undefined, targetField, depth + 1);
                if (!isNaN(extractedScore)) return extractedScore;

                if (valence.isCrisis) return 1;
                if (valence.isPraise) return NaN;
            }
            return NaN;
        }

        if (typeof val === 'symbol' || typeof val === 'boolean') return NaN;
        if (typeof val === 'object' && val !== null) {
            const innerVal = getValidInner(val);
            if (innerVal !== undefined) return resolveUniversalScale(innerVal, reviewText, targetField, depth + 1);
            return resolveUniversalScale(null, reviewText, targetField, depth + 1);
        }

        if (typeof val === 'number') {
            return normalizeScore(val, targetField);
        }

        const unicodeFractions = {
            '¾': 0.75, '⅝': 0.625, '⅚': 0.833, '½': 0.5, '¼': 0.25,
            '⅓': 0.333, '⅔': 0.667, '⅛': 0.125, '⅜': 0.375, '⅞': 0.875,
            '⅙': 0.167, '⅕': 0.2, '⅖': 0.4, '⅗': 0.6, '⅘': 0.8
        };

        let preStr = String(val);
        preStr = preStr.replace(/([0-9]+)\\s*½/g, '$1.5')
                       .replace(/([0-9]+)\\s*¼/g, '$1.25')
                       .replace(/([0-9]+)\\s*¾/g, '$1.75')
                       .replace(/([0-9]+)\\s*⅓/g, (m, p) => (Number(p) + 0.333).toFixed(3))
                       .replace(/([0-9]+)\\s*⅔/g, (m, p) => (Number(p) + 0.667).toFixed(3))
                       .replace(/([0-9]+)\\s*⅕/g, '$1.2')
                       .replace(/([0-9]+)\\s*⅖/g, '$1.4')
                       .replace(/([0-9]+)\\s*⅗/g, '$1.6')
                       .replace(/([0-9]+)\\s*⅘/g, '$1.8');
        const rawStr = preStr.normalize('NFKC').replace(/[\\u200B-\\u200D\\uFEFF]/g, '').trim();

        // 0점 구어체 매핑
        if (/^[★⭐☆🌟\\s]*(?:별\\s*)?(?:(?:점수|별점|평점)\\s*[:：]?\\s*)?(?:영점|빵점|영\\s*점|빵\\s*점|0점)(?:\\s*(?:입니다|드립니다|줍니다|요))?$/i.test(rawStr) ||
            /(?:평점|별점|점수)\\s*[:：]?\\s*(?:영점|빵점|영\\s*점|빵\\s*점|0점)|(?:영점|빵점)\\s*(?:드립니다|줍니다)/i.test(rawStr)) {
            return 0;
        }

        // 만점 매핑
        if (/^[★⭐☆🌟\\s]*(?:별\\s*)?(?:(?:점수|별점|평점)\\s*[:：]?\\s*)?만점(?:\\s*(?:입니다|드립니다|줍니다|요))?$/i.test(rawStr) ||
            /(?:평점|별점|점수)\\s*[:：]?\\s*만점|만점\\s*(?:드립니다|줍니다)/i.test(rawStr)) {
            return 5;
        }

        // 혼합 유니코드 분수 매칭
        const mixedFracMatch = rawStr.match(/([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?|つ?星)?\\s*([¾⅝⅚½¼⅓⅔⅛⅜⅞⅙⅕⅖⅗⅘])/i);
        if (mixedFracMatch) {
            const intPart = parseFloat(mixedFracMatch[1]);
            const fracVal = unicodeFractions[mixedFracMatch[2]] || 0;
            return normalizeScore(intPart + fracVal, targetField);
        }
        for (const [fracChar, fracVal] of Object.entries(unicodeFractions)) {
            if (rawStr.includes(fracChar)) {
                return normalizeScore(fracVal, targetField);
            }
        }

        // 비라틴 유니코드 숫자 ASCII 변환
        function convertUnicodeDigitsToAscii(inputStr) {
            return inputStr.replace(/[\\u0660-\\u0669\\u06F0-\\u06F9\\u0966-\\u096F\\u0E50-\\u0E59]/g, ch => {
                const code = ch.charCodeAt(0);
                if (code >= 0x0660 && code <= 0x0669) return String(code - 0x0660);
                if (code >= 0x06F0 && code <= 0x06F9) return String(code - 0x06F0);
                if (code >= 0x0966 && code <= 0x096F) return String(code - 0x0966);
                if (code >= 0x0E50 && code <= 0x0E59) return String(code - 0x0E50);
                return ch;
            });
        }
        let str = convertUnicodeDigitsToAscii(rawStr);
        if (str === '') return NaN;

        // 불만족 이모지 평점 지원
        const emojiMap = { '👎': 1, '🤮': 1, '💩': 1, '😡': 1 };
        for (const [em, sc] of Object.entries(emojiMap)) {
            if (str.includes(em)) {
                const numMatch = str.match(/([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)/);
                if (numMatch) return normalizeScore(Number(numMatch[1]), targetField);
                return normalizeScore(sc, targetField);
            }
        }

        // 기호 표준화
        str = str.replace(/[\\/⁄\\\\＼∕／]/g, '/');
        str = str.replace(/([0-9]+(?:\\.[0-9]+)?)\\s*(?:과|와)\\s*([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)?\\s*[\\/⁄\\\\＼∕／]\\s*([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)?/gi, (match, p1, p2, p3) => {
            const total = Number(p1) + (Number(p2) / Number(p3));
            return ' ' + total + '점 ';
        });
        str = str.replace(/[〜～]/g, '~');
        str = str.replace(/([0-9])\\s*,\\s*([0-9])/g, '$1.$2');
        str = str.replace(/([0-9])\\s*\\.\\s*([0-9])/g, '$1.$2');
        str = str.replace(/(?:^|[^\\d])\\s*\\.\\s*([0-9]+)/g, ' 0.$1');

        // "반 개" -> 0.5
        if (/(?:^|[^\\d])별?\\s*반\\s*개(?:\\s*드립니다|\\s*만)?(?:\\s*[\\p{Emoji}\\u2000-\\u3300])*$/iu.test(str) ||
            /(?:^|[^\\d])별점\\s*반\\s*개(?:\\s*드립니다|\\s*만)?(?:\\s*[\\p{Emoji}\\u2000-\\u3300])*$/iu.test(str) ||
            /^반\\s*개$/i.test(str)) {
            return normalizeScore(0.5, targetField);
        }

        // 한글 고유어 수사 평점
        const nativeKoreanMap = {
            '하나': 1, '한': 1, '한개': 1,
            '둘': 2, '두': 2, '두개': 2,
            '셋': 3, '세': 3, '세개': 3,
            '넷': 4, '네': 4, '네개': 4,
            '다섯': 5
        };
        const nativeMatch = str.match(/^[★⭐☆🌟\\s]*(?:별\\s*)?(하나|한|둘|두|셋|세|넷|네|다섯)\\s*(?:개|점|stars?|つ?星)?(?:\\s*(?:요|임|용|이요|짜리|만|입니다|대))?(?:\\s*드립니다)?$/i);
        if (nativeMatch) {
            const mapped = nativeKoreanMap[nativeMatch[1]];
            if (mapped !== undefined) return normalizeScore(mapped, targetField);
        }
        const nativeSimpleMatch = str.match(/^[★⭐☆🌟\\s]*(?:별\\s+)(하나|둘|셋|넷|다섯)(?:\\s*(?:요|임|용|이요|짜리|만|입니다|대))?$/i);
        if (nativeSimpleMatch) {
            const mapped = nativeKoreanMap[nativeSimpleMatch[1]];
            if (mapped !== undefined) return normalizeScore(mapped, targetField);
        }
        const embeddedNativeMatch = str.match(/(?:별\\s+)?(하나|한|둘|두|셋|세|넷|네|다섯)\\s*(?:개|점|stars?|つ?星)(?:[도만]?\\s*(?:아깝|아깝습니다|아까움))?(?:\\s*(?:드립니다|줍니다|요|임|용|이요|짜리|입니다))?|(?:별\\s*)(하나|한|둘|두|셋|세|넷|네|다섯)(?:\\s*(?:개|점|stars?|つ?星))?(?:[도만]?\\s*(?:아깝|아깝습니다|아까움))?(?:\\s*(?:드립니다|줍니다|요|임|용|이요|짜리|입니다))?/i);
        if (embeddedNativeMatch) {
            const rawWord = embeddedNativeMatch[1] || embeddedNativeMatch[2];
            const mapped = nativeKoreanMap[rawWord];
            if (mapped !== undefined) return normalizeScore(mapped, targetField);
        }

        // 한자어 음운 수사 평점
        const sinoKoreanPhoneticMap = { '일': 1, '이': 2, '삼': 3, '사': 4, '오': 5 };
        const sinoWordMatch = str.match(/^[★⭐☆🌟\\s]*(?:별\\s*)?(?:(?:점수|별점|평점)\\s*[:：]\\s*)?(일|이|삼|사|오)\\s*(?:점|개|stars?)(?:\\s*(?:입니다|드립니다|줍니다|요))?$/i);
        if (sinoWordMatch) return normalizeScore(sinoKoreanPhoneticMap[sinoWordMatch[1]], targetField);
        const embeddedSinoMatch = str.match(/(?:(?:점수|별점|평점)\\s*[:：]?\\s*)(일|이|삼|사|오)\\s*(?:점|개|stars?)(?:\\s*(?:입니다|드립니다|줍니다|요))?/i);
        if (embeddedSinoMatch) return normalizeScore(sinoKoreanPhoneticMap[embeddedSinoMatch[1]], targetField);
        const embeddedSinoSimple = str.match(/(일|이|삼|사|오)\\s*(?:점|개|stars?)\\s*(?:드립니다|줍니다)/i);
        if (embeddedSinoSimple) return normalizeScore(sinoKoreanPhoneticMap[embeddedSinoSimple[1]], targetField);

        // 로마 숫자 평점
        const romanMap = {
            'Ⅰ': 1, 'Ⅱ': 2, 'Ⅲ': 3, 'Ⅳ': 4, 'Ⅴ': 5,
            'ⅰ': 1, 'ⅱ': 2, 'ⅲ': 3, 'ⅳ': 4, 'ⅴ': 5,
            'I': 1, 'II': 2, 'III': 3, 'IV': 4, 'V': 5
        };
        const romanMatch = str.match(/^[★⭐☆🌟\\s]*(?:별\\s*)?([ⅠⅡⅢⅣⅤⅰⅱⅲⅳⅴ]|I{1,3}|IV|V)\\s*(?:점|개|stars?)?(?:\\s*드립니다)?$/i);
        if (romanMatch) {
            const rawRoman = romanMatch[1];
            const mapped = romanMap[rawRoman.toUpperCase()] || romanMap[rawRoman];
            if (mapped !== undefined) return normalizeScore(mapped, targetField);
        }

        // 한자/동아시아 수사 평점
        const eastAsianMap = { '一': 1, '二': 2, '三': 3, '四': 4, '五': 5 };
        const eaMatch = str.match(/^[★⭐☆🌟\\s]*(?:별\\s*)?([一二三四五])\\s*(?:개|점|つ?星|star|stars?)(?:\\s*드립니다)?$/i);
        if (eaMatch) return normalizeScore(eastAsianMap[eaMatch[1]], targetField);

        // 영문 수사 평점
        const englishWordMap = { 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5 };
        const engWordMatch = str.match(/^[★⭐☆🌟\\s]*(?:별\\s*)?(one|two|three|four|five)\\s*(?:star|stars|points?|점|개)\\b(?!\\s*(?:out\\s+of|of))/i);
        if (engWordMatch) return normalizeScore(englishWordMap[engWordMatch[1].toLowerCase()], targetField);

        // 척도 역산 ("10점 만점에 10점", "100점 중 5점", "100점에 5점")
        const scaleMatch = str.match(/([0-9]+(?:\\.[0-9]+)?|\\.[0-9]+)\\s*(?:개|점)?\\s*(?:만점\\s*(?:에|중|에서|기준)?|(?:점|개)\\s*(?:만점\\s*(?:에|중|에서|기준)?|에|중|에서|기준|만점기준|만점\\s*기준))\\s*([0-9]+(?:\\.[0-9]+)?|\\.[0-9]+)(?!\\s*(?:등|위|호점|번째|번|순위|차|회))\\s*(?:개|점)?/i);
        if (scaleMatch) {
            const scaleBase = Number(scaleMatch[1]);
            const scaleScore = Number(scaleMatch[2]);
            if (!isNaN(scaleBase) && !isNaN(scaleScore) && scaleBase > 0) {
                return targetField === 'rating' ? (scaleBase === 5 ? scaleScore : (scaleScore / scaleBase) * 5) : scaleScore;
            }
        }

        // 역순 척도 역산 ("1점 (5점 만점)", "1점 (10점 만점)")
        const reverseScaleMatch = str.match(/([0-9]+(?:\\.[0-9]+)?|\\.[0-9]+)\\s*(?:개|점)?\\s*\\(?\\s*([0-9]+(?:\\.[0-9]+)?|\\.[0-9]+)\\s*(?:개|점)?\\s*만점\\s*\\)?/i);
        if (reverseScaleMatch) {
            const scaleScore = Number(reverseScaleMatch[1]);
            const scaleBase = Number(reverseScaleMatch[2]);
            if (!isNaN(scaleBase) && !isNaN(scaleScore) && scaleBase > 0) {
                return targetField === 'rating' ? (scaleBase === 5 ? scaleScore : (scaleScore / scaleBase) * 5) : scaleScore;
            }
        }

        // 비교 문맥 제거
        let strWithoutComparison = str
            .replace(/\\([^)]*(?:다른|속아서|속았|사기|광고|알바|조작|가짜|의심|배달앱|인스타|블로그)[^)]*\\)/gi, ' ')
            .replace(/(?:다른|속아서|속았|사기|광고|알바|조작|가짜|배달앱|인스타|블로그)\\s*(?:리뷰|사람|평점|후기)?[^.!?\\n]*?([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)/gi, ' ')
            .replace(/([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)(?:\\s*만점\\s*(?:맛집|식당|곳)?이라더니|\\s*주는\\s*사람들은|\\s*리뷰\\s*보고\\s*시켰는데|\\s*평점)?\\s*(?:사기|알바|조작|가짜|낚였|낚임|의심|의혹)/gi, ' ');

        // 하이픈/물결 범위 평점 -> 평균값 치환
        strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\\.[0-9]+)?)\\s*[-~−–—〜～]\\s*([0-9]+(?:\\.[0-9]+)?)\\s*(점|개|stars?|つ?星)?/gi, (match, p1, p2, unit) => {
            const avg = (Number(p1) + Number(p2)) / 2;
            return ' ' + avg + (unit || '') + ' ';
        });

        // 반어법/역설적 혹평 마스킹
        const sarcasticRegex = /([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)(?:이라더니|짜리\\s*(?:식당|음식|가게|곳)?인가요|이라고\\??|준다는\\s*게)/i;
        strWithoutComparison = strWithoutComparison.replace(sarcasticRegex, ' ');

        // 할인율/쿠폰 마스킹
        strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\\.[0-9]+)?)\\s*%\\s*(?:할인|쿠폰|적립|캐시백|세일)?/gi, ' ');

        // 날짜 마스킹 (1/5, 1/10, 1/100 분수 보존)
        strWithoutComparison = strWithoutComparison.replace(/\\b(?:0?[1-9]|1[0-2])\\s*[/⁄\\\\＼]\\s*(?:0?[1-9]|[12][0-9]|3[01])\\b(?![\s]*(?:점|개|stars?|つ?星|만점))/gi, (match) => {
            const parts = match.split(/[/⁄\\\\＼]/);
            const d = Number(parts[1]);
            if (d === 5 || d === 10 || d === 100) return match;
            return ' ';
        });
        strWithoutComparison = strWithoutComparison.replace(/(?:방문일|주문일|방문|주문|포장|배달)?\\s*[:=\\s]?\\s*(?:20[0-9]{2}[/.-][0-9]{1,2}[/.-][0-9]{1,2}|[0-9]{1,2}\\s*[/]\\s*[0-9]{1,2}\\s*(?:주문|방문|포장|배달|결제|이용|배송))\\s*/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/(?:v|ver\\.?)\\s*[0-9]+(?:\\.[0-9]+)+(?:\\s*(?:버전|빌드|업데이트))?|[0-9]+(?:\\.[0-9]+)+\\s*(?:버전|빌드|업데이트)|버전\\s*[0-9]+(?:\\.[0-9]+)+/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/(?:만점|점|개)\\s*(?:에|중|에서)?\\s*([0-9]+(?:\\.[0-9]+)?)\\s*(?:등|위|호점|번째|번\\s*추천|순위|차|회)/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\\.[0-9]+)?)\\s*(?:등|위|호점|번째|번\\s*추천|순위)\\b/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/([0-9]+)\\s*개\\s*(?:더|포장|주문|먹|시켰|구매|추가|사|남김|배달)/gi, ' ');
        strWithoutComparison = strWithoutComparison.replace(/\\b[0-9]{1,2}\\s*[:]\\s*[0-9]{2}\\s*(?:에|경|쯤|시|분|초|주문|방문|포장|배달|결제|이용|배송)?/gi, ' ');

        // ASCII 혼합 분수 매칭 (4 1/2점)
        const asciiMixedMatch = strWithoutComparison.match(/([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?|つ?星)?\\s+([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)?\\s*[\\/⁄\\\\＼]\\s*([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)?(?!\\s*(?:주문|방문|포장|배달|결제|이용|배송))/i);
        if (asciiMixedMatch) {
            const intPart = parseFloat(asciiMixedMatch[1]);
            const num = parseFloat(asciiMixedMatch[2]);
            const denom = parseFloat(asciiMixedMatch[3]);
            if (!isNaN(intPart) && !isNaN(num) && !isNaN(denom) && denom > 0 && denom <= 100 && (denom === 100 || denom === 10 || denom === 5 || num <= 31 || num <= denom)) {
                return normalizeScore(intPart + (num / denom), targetField);
            }
        }

        // 분수 매칭 (35/100, 1/5, 2/5 등)
        const fractionMatch = strWithoutComparison.match(/([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)?\\s*[\\/⁄\\\\＼]\\s*([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)?(?!\\s*(?:주문|방문|포장|배달|결제|이용|배송))/i);
        if (fractionMatch) {
            const num = Number(fractionMatch[1]);
            const denom = Number(fractionMatch[2]);
            if (!isNaN(num) && !isNaN(denom) && denom > 0 && denom <= 100 && (denom === 100 || denom === 10 || denom === 5 || num <= 31 || num <= denom)) {
                return targetField === 'rating' ? (num / denom) * 5 : num / denom;
            }
        }

        // 비율 척도 (1:5)
        const ratioMatch = strWithoutComparison.match(/([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?)?\\s*[:]\\s*([0-9]+(?:\\.[0-9]+)?)\\b\\s*(?:점|개|stars?)?(?!\\s*(?:에|경|쯤|시|분|초|주문|방문|포장|배달|결제|이용|배송))/i);
        if (ratioMatch) {
            const num = Number(ratioMatch[1]);
            const denom = Number(ratioMatch[2]);
            if (!isNaN(num) && !isNaN(denom) && denom > 0 && denom <= 100) {
                return targetField === 'rating' ? (num / denom) * 5 : num / denom;
            }
        }

        // 별 이모지 파싱 및 텍스트 교차 검증
        if (/[★⭐☆🌟]/.test(str)) {
            if (reviewText && typeof reviewText === 'string') {
                const textNorm = reviewText.normalize('NFKC').replace(/[\\u200B-\\u200D\\uFEFF]/g, '').trim();
                const isExplicitBad = /(?:[1-2]점|별\\s*(?:하나|한\\s*개|1개)|최악|쓰레기|환불|고소|썩었|폭망)/i.test(textNorm);
                const isExplicitGood = /(?:5점\\s*만점|5점|별\\s*(?:다섯|5개)|최고|인생맛집|대박)/i.test(textNorm);
                const filledStars = (str.match(/[★⭐🌟]/g) || []).length;
                if (filledStars >= 4 && isExplicitBad) return 1;
                if (filledStars <= 2 && isExplicitGood) return 5;
            }

            const hasExplicitNumberWithUnit = /(?:[0-9]+(?:\\.[0-9]+)?|[一二三四五]|one|two|three|four|five|하나|한|둘|두|셋|세|넷|네|다섯)\\s*(?:점|개|stars?|points?|つ?星)/i.test(strWithoutComparison);
            if (!hasExplicitNumberWithUnit) {
                const filledStars = (str.match(/[★⭐🌟]/g) || []).length;
                const emptyStars = (str.match(/[☆]/g) || []).length;
                if (filledStars > 0 || emptyStars > 0) {
                    if (filledStars === 0 && emptyStars > 0) return 0;
                    if (filledStars >= 1 && filledStars <= 5) return filledStars;
                    if (filledStars === 0) return 0;
                }
            }
        }

        // 영문 척도 ("1 star out of 5 stars")
        const engScaleMatch = strWithoutComparison.match(/(one|two|three|four|five|[0-9]+(?:\\.[0-9]+)?)\\s*(?:stars?|points?|점)?\\s*(?:out\\s+of|of)\\s*(one|two|three|four|five|[0-9]+(?:\\.[0-9]+)?)\\s*(?:stars?|points?|점)?/i);
        if (engScaleMatch) {
            const sVal = englishWordMap[engScaleMatch[1].toLowerCase()] || Number(engScaleMatch[1]);
            const bVal = englishWordMap[engScaleMatch[2].toLowerCase()] || Number(engScaleMatch[2]);
            if (!isNaN(sVal) && !isNaN(bVal) && bVal > 0) return targetField === 'rating' ? (sVal / bVal) * 5 : sVal;
        }

        // 다국어 척도 ("1 out of 5 stars", "1 de 5")
        const multiScaleMatch = strWithoutComparison.match(/([0-9]+(?:\\.[0-9]+)?|\\.[0-9]+)\\s*(?:stars?|étoiles?|sternen?|estrellas?|점|개)?\\s*(?:out\\s+of|of|de|sobre|sur|von|su)\\s*([0-9]+(?:\\.[0-9]+)?|\\.[0-9]+)\\s*(?:stars?|étoiles?|sternen?|estrellas?|점|개)?/i);
        if (multiScaleMatch) {
            const score = Number(multiScaleMatch[1]);
            const base = Number(multiScaleMatch[2]);
            if (!isNaN(score) && !isNaN(base) && base > 0) return targetField === 'rating' ? (score / base) * 5 : score;
        }

        // 지수 표기법 (5e0, 1e0)
        const expMatch = strWithoutComparison.match(/\\b([0-9]+(?:\\.[0-9]+)?e[+\\-]?[0-9]+)\\b\\s*(?:점|개|stars?)?/i);
        if (expMatch) {
            const n = Number(expMatch[1]);
            if (!isNaN(n)) return normalizeScore(n, targetField);
        }

        // Key-value 평점 ("평점: 5", "score: 5")
        const colonMatch = strWithoutComparison.match(/(?:평점|score|rating|별점)\\s*[:=\\-]\\s*([0-9]+(?:\\.[0-9]+)?|\\.[0-9]+)/i);
        if (colonMatch) {
            const n = Number(colonMatch[1]);
            if (!isNaN(n)) return normalizeScore(n, targetField);
        }

        // 단위 수치 매칭 ("1점", "5점", "맛 1점 양 5점")
        const unitRegex = /([0-9]+(?:\\.[0-9]+)?)\\s*(?:점|개|stars?|points?|つ?星)/gi;
        const unitMatches = [...strWithoutComparison.matchAll(unitRegex)];
        if (unitMatches.length > 0) {
            const parsedValues = unitMatches.map(m => Number(m[1])).filter(v => !isNaN(v));
            const badScore = parsedValues.find(v => v < 3);
            const chosen = (badScore !== undefined) ? badScore : parsedValues[parsedValues.length - 1];
            return normalizeScore(chosen, targetField);
        }

        // 비단위 분리 수치 매칭
        const nonContextMatches = [...strWithoutComparison.matchAll(/(?:^|[^\\d.−-])([-−]?(?:[0-9]+(?:\\.[0-9]+)?|\\.[0-9]+))(?!\\s*(?:년|번째|번|차|회|개월|주|일|시|분|초|살|명|원|달러|\\b(?:st|nd|rd|th)\\b))/gi)];
        if (nonContextMatches.length > 0) {
            const parsedValues = nonContextMatches.map(m => Number(m[1].replace(/−/g, '-'))).filter(v => !isNaN(v));
            const badScore = parsedValues.find(v => v < 3);
            const chosen = (badScore !== undefined) ? badScore : parsedValues[parsedValues.length - 1];
            return normalizeScore(chosen, targetField);
        }

        if (hasSarcastic) return 1;

        const fallbackNum = Number(str.replace(/−/g, '-'));
        if (isNaN(fallbackNum) || !Number.isFinite(fallbackNum)) {
            if (reviewText && typeof reviewText === 'string') {
                return resolveUniversalScale(null, reviewText, targetField, depth + 1);
            }
            return NaN;
        }
        return normalizeScore(fallbackNum, targetField);
    }
`;

// Insert regularityEnginesCode right after normalizeScore
const normScoreIndex = content.indexOf('return n;\n    }');
if (normScoreIndex === -1) {
    console.error('normalizeScore end not found!');
    process.exit(1);
}
const insertPos = normScoreIndex + 'return n;\n    }'.length;

// Find parseSafeNumber function start and end
const parseSafeStart = content.indexOf('function parseSafeNumber(val, reviewText, targetField = \'rating\', depth = 0) {', insertPos);
if (parseSafeStart === -1) {
    console.error('parseSafeNumber start not found!');
    process.exit(1);
}
const selectPriorityStart = content.indexOf('function selectPriorityItem(arr) {', parseSafeStart);
if (selectPriorityStart === -1) {
    console.error('selectPriorityItem start not found!');
    process.exit(1);
}

// Replace the old parseSafeNumber body with a clean delegation to resolveUniversalScale
const newParseSafeNumber = `
    function parseSafeNumber(val, reviewText, targetField = 'rating', depth = 0) {
        return resolveUniversalScale(val, reviewText, targetField, depth);
    }
`;

content = content.slice(0, insertPos) + '\n' + regularityEnginesCode + '\n' + newParseSafeNumber + '\n    ' + content.slice(selectPriorityStart);

// Now update selectPriorityItem to remove crisisKeywords and use evaluateSyntacticValence
const oldSelectBodyStart = content.indexOf('const criticalItem = flatArr.find(item => {');
const oldSelectBodyEnd = content.indexOf('const reviewItem = flatArr.find(x => x && typeof x === \'object\' && isReviewData(x));');

if (oldSelectBodyStart !== -1 && oldSelectBodyEnd !== -1) {
    const newSelectBody = `const criticalItem = flatArr.find(item => {
            if (!item || typeof item !== 'object') return false;
            const candidateFields = ['rating', 'score', 'overall_rating', 'total_score', 'user_rating', 'value', 'item_score', 'star_count', 'grade', 'food_rating', 'service_rating', 'taste', 'delivery'];
            let found = [];
            for (const f of candidateFields) {
                if (item[f] !== undefined && item[f] !== null && item[f] !== '') {
                    found.push(item[f]);
                }
            }
            let r = undefined;
            if (found.length > 0) {
                const bad = found.find(val => {
                    const num = parseSafeNumber(val, undefined, 'rating');
                    return !isNaN(num) && num < 3;
                });
                r = bad !== undefined ? bad : found[0];
            }
            const text = typeof item.review_text === 'string' ? item.review_text : (typeof item.comment === 'string' ? item.comment : (typeof item.content === 'string' ? item.content : (typeof item.text === 'string' ? item.text : '')));
            const parsedR = parseSafeNumber(r, text, 'rating');
            if (!isNaN(parsedR)) {
                if (parsedR < 3) return true;
                return false;
            }
            const valence = evaluateSyntacticValence(text);
            if (valence.isCrisis && !valence.isPraise) return true;
            return false;
        });

        `;
    
    // Also remove the crisisKeywords definition above criticalItem
    const crisisKwStart = content.lastIndexOf('const crisisKeywords = [', oldSelectBodyStart);
    if (crisisKwStart !== -1 && crisisKwStart < oldSelectBodyStart) {
        content = content.slice(0, crisisKwStart) + newSelectBody + content.slice(oldSelectBodyEnd);
    } else {
        content = content.slice(0, oldSelectBodyStart) + newSelectBody + content.slice(oldSelectBodyEnd);
    }
}

fs.writeFileSync(targetPath, content, 'utf8');
console.log('Successfully refactored v8_native_combat_runner.js with 3 Regularity Engines!');
