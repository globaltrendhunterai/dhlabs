/**
 * AutoFlow Carrier Shipping Accident Claim & Compensation Sentinel v2.0
 *
 * [비즈니스 & 법무 목적]
 * 1. 이커머스 배송 중 택배사 과실로 인한 파손, 분실, 오배송 발생 시,
 *    「상법」 제147조(운송인의 책임의 시효) 및 공정위 택배 표준약관 제25조 제2항에 명시된
 *    "수령일로부터 14일 이내 통지" 제척기간을 1초 만에 감별하여 시효 만료로 인한
 *    셀러의 100% 손실 독박(쿠팡의 일방적 선환불 + 택배사의 면책 거부)을 원천 차단.
 * 2. 1원 단위 손해배상 청구액 계산 엔진: [물품 매입원가 + 편도/왕복 택배비 + 부가세 매입세액].
 * 3. 1초 고객 증빙 사진(외부박스/송장/파손부위 3종) 요청 정중 문자 템플릿 자동 포맷터.
 * 4. 8대 메이저 택배사 본사/지점 접수용 공식 손해배상청구 소명서 HTML 자동 렌더링:
 *    - Pure White Clean Enterprise 라이트 모드 및 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건).
 * 5. 손해배상 청구 큐(`logs/shipping_accident_claims.json`) 영속화 및 상태 전이.
 */

const fs = require("fs");
const path = require("path");

class ShippingAccidentSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/shipping_accident_claims.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/shipping_accident_config.json");

    this.SUPPORTED_CARRIERS = {
      CJ: { name: "CJ대한통운", phone: "1588-1255", url: "https://www.cjlogistics.com" },
      POST: { name: "우체국택배", phone: "1588-1300", url: "https://parcel.epost.go.kr" },
      HANJIN: { name: "한진택배", phone: "1588-0011", url: "https://www.hanjin.com" },
      LOTTE: { name: "롯데택배", phone: "1588-2121", url: "https://www.lotteglogis.com" },
      LOGEN: { name: "로젠택배", phone: "1588-9988", url: "https://www.ilogen.com" },
      KDEXP: { name: "경동택배", phone: "1899-5368", url: "https://kdexp.com" },
      DAESIN: { name: "대신택배", phone: "043-255-3211", url: "https://www.ds3211.co.kr" },
      ILYANG: { name: "일양로지스", phone: "1588-0002", url: "https://www.ilyanglogis.com" }
    };

    this.defaultConfig = {
      defaultVatRate: 0.10, // 10%
      statuteDays: 14, // 상법 제147조 14일
      urgentDays: 3, // 3일 미만 긴급 경보
      approachingDays: 7, // 7일 미만 주의
      storeName: "AutoFlow 공식 스토어",
      sellerName: "디에이치랩스 대표 김동형",
      sellerPhone: "010-0000-0000",
      sellerAddress: "서울특별시 강남구 테헤란로",
      sellerEmail: "contact@autoflow.enterprise.kr"
    };

    this.ensureStorage();
  }

  ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(this.storagePath, JSON.stringify({ claims: [], updatedAt: new Date().toISOString() }, null, 2), "utf8");
      }
    } catch (e) {
      // safe fallback for storage init
    }
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          return Object.assign({}, this.defaultConfig, parsed);
        }
      }
    } catch (e) {}
    return Object.assign({}, this.defaultConfig);
  }

  /**
   * 상법 제147조 14일(336시간) 소멸시효 평가
   * @param {Object} claim 사고 접수 데이터
   * @param {Object} customOptions 옵션 재정의
   * @returns {Object} 시효 평가 결과
   */
  evaluateClaimDeadline(claim = {}, customOptions = {}) {
    claim = (claim && typeof claim === "object") ? claim : {};
    customOptions = (customOptions && typeof customOptions === "object") ? customOptions : {};
    const config = Object.assign({}, this.getConfig(), customOptions);
    const incidentTimeStr = claim.receivedAt || claim.incidentAt || claim.deliveredAt || claim.createdAt || new Date().toISOString();
    const parsedTime = new Date(incidentTimeStr).getTime();
    const now = Date.now();
    const incidentTime = (!isNaN(parsedTime) && parsedTime > 0) ? parsedTime : now;

    const elapsedMs = Math.max(0, now - incidentTime);
    const elapsedHours = Number((elapsedMs / (1000 * 60 * 60)).toFixed(1));
    const elapsedDays = Number((elapsedHours / 24).toFixed(1));

    const totalStatuteHours = config.statuteDays * 24; // 336시간
    const remainingHours = Number(Math.max(0, totalStatuteHours - elapsedHours).toFixed(1));
    const remainingDays = Number(Math.max(0, config.statuteDays - elapsedDays).toFixed(1));

    let riskLevel = "SAFE";
    let isUrgent = false;
    let isExpired = false;

    if (elapsedHours >= totalStatuteHours) {
      riskLevel = "EXPIRED_14D";
      isExpired = true;
    } else if (remainingDays <= config.urgentDays) {
      riskLevel = "URGENT_3D";
      isUrgent = true;
    } else if (remainingDays <= config.approachingDays) {
      riskLevel = "APPROACHING_7D";
    }

    return {
      incidentTime: new Date(incidentTime).toISOString(),
      statuteDays: config.statuteDays,
      elapsedHours,
      elapsedDays,
      remainingHours,
      remainingDays,
      riskLevel,
      isUrgent,
      isExpired
    };
  }

  /**
   * 손해배상 청구액 1원 정밀 산출
   * 공식: [물품 매입원가 + 편도/왕복 택배비 + 부가세 매입세액]
   * @param {Object} claim 사고 데이터
   * @param {Object} customOptions
   * @returns {Object}
   */
  calculateCompensationAmount(claim = {}, customOptions = {}) {
    claim = (claim && typeof claim === "object") ? claim : {};
    customOptions = (customOptions && typeof customOptions === "object") ? customOptions : {};
    const config = Object.assign({}, this.getConfig(), customOptions);
    const costPrice = Math.max(0, Number(claim.costPrice || claim.wholesaleCost || 0));
    const quantity = Math.max(1, Number(claim.quantity || 1));
    const totalCostPrice = Math.round(costPrice * quantity);

    const shippingFee = Math.max(0, Number(claim.shippingFee || 3000));
    const returnShippingFee = Math.max(0, Number(claim.returnShippingFee || (claim.isRoundTrip ? shippingFee : 0)));
    const totalShippingFee = Math.round(shippingFee + returnShippingFee);

    const isTaxable = claim.isTaxable !== false;
    const vatRate = isTaxable ? config.defaultVatRate : 0;
    const costVat = Math.round(totalCostPrice * vatRate);

    // 총 손해배상 청구액 = 물품 원가 + 부가세 매입세액 + 운송비 합계
    const totalClaimAmount = totalCostPrice + costVat + totalShippingFee;

    const carrierCode = String(claim.carrierCode || "CJ").toUpperCase();
    const carrierInfo = this.SUPPORTED_CARRIERS[carrierCode] || { name: claim.carrierName || "기타택배", phone: "1588-0000", url: "" };

    return {
      costPrice,
      quantity,
      totalCostPrice,
      shippingFee,
      returnShippingFee,
      totalShippingFee,
      isTaxable,
      vatRate,
      costVat,
      totalClaimAmount,
      carrierCode,
      carrierName: carrierInfo.name,
      carrierPhone: carrierInfo.phone,
      carrierUrl: carrierInfo.url
    };
  }

  /**
   * 고객 안심 증빙 사진 요청 정중 문자 템플릿 생성
   * @param {Object} claim 사고 데이터
   * @returns {string} 문자 메시지 텍스트
   */
  generateCustomerEvidenceNotice(claim = {}) {
    claim = (claim && typeof claim === "object") ? claim : {};
    const config = this.getConfig();
    const customerName = claim.customerName || "고객";
    const productName = claim.productName || "주문 상품";
    const storeName = config.storeName || "스토어";
    const csPhone = config.sellerPhone || "1544-0000";

    return `[${storeName}] 배송사고(파손/오배송) 안심 처리 및 교환/환불 접수 안내

안녕하세요, ${customerName}님.
${storeName}을 이용해 주셨는데, 배송 과정 중 상품 파손으로 큰 불편을 드려 진심으로 고개 숙여 사과드립니다.

고객님의 소중한 피해를 신속하게 100% 무상 교환 또는 전액 환불 처리해 드리기 위해, 택배사고 공식 접수에 필요한 증빙 사진 3장을 문자 회신으로 요청드립니다.

[필수 증빙 사진 3종]
1. 택배 운송장 스티커가 잘 보이는 '외부 박스 전체 사진' 1장
2. 외부 박스의 파손/찌그러짐 부위 및 '내부 포장(에어캡/완충재)' 상태 사진 1장
3. 파손/손상된 '상품 본체' 상세 사진 1장

사진을 본 번호로 회신해 주시면, 확인 즉시 택배사 회수 접수 및 교환/환불을 우선적으로 신속히 집행해 드리겠습니다.
불편을 드려 다시 한번 깊이 사과드립니다.

- 문의 및 접수처: ${storeName} 고객감동센터 (${csPhone})`;
  }

  /**
   * 텔레그램 / 슬랙 긴급 알림 메시지 포맷터
   * @param {Object} claim 사고 데이터
   * @param {Object} evalData 시효 및 금액 평가 데이터
   * @returns {string}
   */
  formatAccidentAlertBlock(claim = {}, evalData = {}) {
    claim = (claim && typeof claim === "object") ? claim : {};
    evalData = (evalData && typeof evalData === "object") ? evalData : {};
    const deadline = (evalData.deadline && typeof evalData.deadline === "object") ? evalData.deadline : this.evaluateClaimDeadline(claim);
    const compensation = (evalData.compensation && typeof evalData.compensation === "object") ? evalData.compensation : this.calculateCompensationAmount(claim);
    const riskBadge = deadline.isExpired ? "🚨 [시효 만료 - 면책 위험]" : (deadline.isUrgent ? "⚠️ [초긴급 - 3일 미만]" : "📦 [14일 시효 가동]");

    return `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${riskBadge} 택배사고 손해배상 청구 시효 수호 경보
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• 주문번호: ${claim.orderId || "미지정"}
• 운송장번호: [${compensation.carrierName}] ${claim.trackingNumber || "미등록"}
• 사고 유형: ${claim.accidentType || "파손(DAMAGE)"}
• 수령/사고일시: ${String(deadline.incidentTime || "").slice(0, 19).replace("T", " ")}
---------------------------------------------------------
• 경과 시간: ${deadline.elapsedDays}일 (${deadline.elapsedHours}시간) 경과
• 14일 잔여 시효: ⏰ ${deadline.remainingDays}일 (${deadline.remainingHours}시간 남음)
---------------------------------------------------------
• 도매 원가 합계: ₩${Number(compensation.totalCostPrice || 0).toLocaleString()} (부가세 ₩${Number(compensation.costVat || 0).toLocaleString()})
• 청구 배송비: ₩${Number(compensation.totalShippingFee || 0).toLocaleString()}
• 총 손해배상 청구액: ₩${Number(compensation.totalClaimAmount || 0).toLocaleString()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 「상법」 제147조에 따라 14일 이내 택배사에 공식 서면 접수하지 않으면 구상권이 영구 소멸됩니다.
1초 공문서 손해배상청구서를 발급하여 ${compensation.carrierName} (${compensation.carrierPhone})에 접수하십시오.`;
  }

  /**
   * 택배사 제출용 정식 손해배상청구서 HTML 렌더링
   * Pure White Clean Enterprise 라이트 모드 및 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건)
   * @param {Object} claim 사고 접수 데이터
   * @param {Object} evalData 계산 데이터
   * @returns {string} HTML 마크업
   */
  generateCarrierClaimEvidenceHtml(claim = {}, evalData = {}) {
    claim = (claim && typeof claim === "object") ? claim : {};
    evalData = (evalData && typeof evalData === "object") ? evalData : {};
    const config = this.getConfig();
    const deadline = (evalData.deadline && typeof evalData.deadline === "object") ? evalData.deadline : this.evaluateClaimDeadline(claim);
    const comp = (evalData.compensation && typeof evalData.compensation === "object") ? evalData.compensation : this.calculateCompensationAmount(claim);
    const currentDate = new Date().toISOString().slice(0, 10);
    const incidentDate = String(deadline.incidentTime || currentDate).slice(0, 10);

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>운송물 손해배상 청구서 (택배사고 증명서)</title>
  <style>
    @page { size: A4; margin: 20mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo", "Malgun Gothic", "Pretendard", sans-serif;
      background-color: #ffffff;
      color: #0f172a;
      line-height: 1.6;
      margin: 0;
      padding: 30px;
    }
    .official-doc {
      max-width: 800px;
      margin: 0 auto;
      border: 1px solid #cbd5e1;
      padding: 40px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    }
    .doc-header {
      text-align: center;
      border-bottom: 2px solid #0f172a;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    .doc-title {
      font-size: 24px;
      font-weight: 800;
      letter-spacing: -0.5px;
      margin: 0 0 10px 0;
      color: #0f172a;
    }
    .doc-subtitle {
      font-size: 13px;
      color: #475569;
      margin: 0;
    }
    .meta-box {
      display: flex;
      justify-content: space-between;
      margin-bottom: 25px;
      font-size: 13px;
    }
    .meta-col {
      flex: 1;
    }
    .section-title {
      font-size: 14px;
      font-weight: 700;
      color: #0f172a;
      border-left: 4px solid #0284c7;
      padding-left: 8px;
      margin: 25px 0 10px 0;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 12px;
    }
    th, td {
      border: 1px solid #cbd5e1;
      padding: 10px 12px;
      text-align: left;
    }
    th {
      background-color: #f8fafc;
      font-weight: 600;
      color: #334155;
      width: 25%;
    }
    td.amount-cell {
      text-align: right;
      font-weight: 700;
      font-family: monospace;
    }
    .highlight-box {
      background-color: #f0f9ff;
      border: 1px solid #bae6fd;
      border-radius: 6px;
      padding: 15px;
      margin: 20px 0;
      font-size: 12px;
      color: #0369a1;
      line-height: 1.7;
    }
    .legal-notice {
      background-color: #fef2f2;
      border: 1px solid #fecaca;
      border-radius: 6px;
      padding: 15px;
      margin: 20px 0;
      font-size: 12px;
      color: #991b1b;
      line-height: 1.7;
    }
    .photo-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 10px;
      margin-top: 10px;
    }
    .photo-placeholder {
      border: 1px dashed #94a3b8;
      border-radius: 4px;
      height: 120px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-size: 11px;
      color: #64748b;
      background: #f8fafc;
      text-align: center;
      padding: 5px;
    }
    .doc-footer {
      margin-top: 40px;
      text-align: center;
      border-top: 1px solid #e2e8f0;
      padding-top: 25px;
      font-size: 13px;
      color: #334155;
    }
    .signature-area {
      margin: 20px 0;
      font-size: 15px;
      font-weight: 700;
      color: #0f172a;
    }
    .system-badge {
      font-size: 11px;
      color: #94a3b8;
      margin-top: 15px;
    }
    @media print {
      body { padding: 0; }
      .official-doc { border: none; box-shadow: none; padding: 0; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="max-width: 800px; margin: 0 auto 15px auto; display: flex; justify-content: flex-end; gap: 10px;">
    <button onclick="window.print()" style="padding: 8px 16px; background: #0f172a; color: #fff; border: none; border-radius: 4px; font-weight: 600; cursor: pointer;">🖨️ 공문서 인쇄 / PDF 저장</button>
  </div>

  <div class="official-doc">
    <div class="doc-header">
      <h1 class="doc-title">운송물 손해배상 청구서 (택배사고 사실확인서)</h1>
      <p class="doc-subtitle">「상법」 제147조 및 공정거래위원회 택배 표준약관 제25조에 근거한 정식 손해배상 청구 공문</p>
    </div>

    <div class="meta-box">
      <div class="meta-col">
        <strong>수 신:</strong> ${comp.carrierName} 고객만족센터 및 관할 배송지점장 귀하<br>
        <strong>발 신:</strong> ${config.storeName} (${config.sellerName})<br>
        <strong>문서번호:</strong> CLAIM-${String(claim.orderId || "ACC").replace(/[^a-zA-Z0-9]/g, "").slice(-8)}-${Date.now().toString().slice(-4)}
      </div>
      <div class="meta-col" style="text-align: right;">
        <strong>발송일자:</strong> ${currentDate}<br>
        <strong>사고유형:</strong> ${claim.accidentType || "운송 중 파손(DAMAGE)"}<br>
        <strong>시효상태:</strong> 14일 제척기간 내 정식 청구 (잔여 ${deadline.remainingDays}일)
      </div>
    </div>

    <div class="section-title">1. 운송물 및 사고 기본 내역</div>
    <table>
      <tr>
        <th>운송장 번호</th>
        <td><strong>${claim.trackingNumber || "미등록"}</strong></td>
        <th>택배사 / 담당</th>
        <td>${comp.carrierName} (${comp.carrierPhone})</td>
      </tr>
      <tr>
        <th>주문 번호</th>
        <td>${claim.orderId || "미지정"}</td>
        <th>배송/수령 일시</th>
        <td>${incidentDate}</td>
      </tr>
      <tr>
        <th>수령인 성명</th>
        <td>${claim.customerName || "고객"}</td>
        <th>수령인 연락처</th>
        <td>${claim.customerPhone || "010-****-****"}</td>
      </tr>
      <tr>
        <th>운송물 명칭</th>
        <td colspan="3">${claim.productName || "주문 상품"} (수량: ${comp.quantity}개)</td>
      </tr>
    </table>

    <div class="section-title">2. 손해배상 청구 금액 산출 명세 (1원 단위 실손 산정)</div>
    <table>
      <thead>
        <tr>
          <th style="width: 40%;">항목 구분</th>
          <th style="width: 20%; text-align: center;">수량/단위</th>
          <th style="width: 40%; text-align: right;">산정 금액 (KRW)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>운송물 매입 도매원가</td>
          <td style="text-align: center;">${comp.quantity} 개</td>
          <td class="amount-cell">₩${Number(comp.totalCostPrice || 0).toLocaleString()}</td>
        </tr>
        <tr>
          <td>매입 부가가치세 (10% 환급불가 손실액)</td>
          <td style="text-align: center;">부가세법 준용</td>
          <td class="amount-cell">₩${Number(comp.costVat || 0).toLocaleString()}</td>
        </tr>
        <tr>
          <td>청구 운송료 (편도 및 사고회수 택배비)</td>
          <td style="text-align: center;">실지급액</td>
          <td class="amount-cell">₩${Number(comp.totalShippingFee || 0).toLocaleString()}</td>
        </tr>
        <tr style="background-color: #f8fafc; font-size: 13px;">
          <td><strong>최종 손해배상 합계 청구액</strong></td>
          <td style="text-align: center;"><strong>실손해 전액</strong></td>
          <td class="amount-cell" style="color: #dc2626; font-size: 15px;"><strong>₩${Number(comp.totalClaimAmount || 0).toLocaleString()}</strong></td>
        </tr>
      </tbody>
    </table>

    <div class="highlight-box">
      <strong>[청구 사유 및 사실 관계]</strong><br>
      귀사의 운송 위탁을 받아 수하인에게 전달되는 과정에서 취급 부주의로 인하여 포장 박스가 심각하게 파손되었으며, 이로 인해 내부 운송물이 훼손·멸실되어 상품 가치가 100% 영구 상실되었습니다. 구매자의 정당한 항의로 인하여 판매자는 즉시 환불 조치를 완료하였으며, 귀사의 운송계약 불완전이행에 따른 실손해를 배상 청구하오니 조속히 정산 계좌로 입금 바랍니다.
    </div>

    <div class="legal-notice">
      <strong>[법적 근거 및 제척기간 수호 고지]</strong><br>
      본 청구는 <strong>「상법」 제147조(운송인의 책임의 시효)</strong> 및 <strong>공정거래위원회 승인 택배 표준약관 제25조(사고증명 및 손해배상청구) 제2항</strong>에 의거하여, 운송물 수령일로부터 <strong>14일 이내</strong>에 하자 통지 및 배상 청구를 정식으로 전자 발송한 문서입니다. 본 청구서 접수 시점 기준 14일 제척기간이 유효하게 중단되었음을 확인합니다.
    </div>

    <div class="section-title">3. 사고 현장 입증 증빙 자료</div>
    <div class="photo-grid">
      <div class="photo-placeholder">
        <strong>증빙 1. 외부 박스 송장면</strong><br>
        (운송장 번호 식별 사진)
      </div>
      <div class="photo-placeholder">
        <strong>증빙 2. 박스 외관 파손 부위</strong><br>
        (찌그러짐, 훼손, 찢어짐 부위)
      </div>
      <div class="photo-placeholder">
        <strong>증빙 3. 내부 완충재 및 상품</strong><br>
        (상품 훼손 및 파손 상세 사진)
      </div>
    </div>

    <div class="doc-footer">
      <div class="signature-area">
        ${currentDate}<br><br>
        청구인(송하인): ${config.storeName} (${config.sellerName}) (인쇄 시 직인 생략)
      </div>
      <div style="font-size: 12px; color: #64748b;">
        연락처: ${config.sellerPhone} | 주소: ${config.sellerAddress} | 이메일: ${config.sellerEmail}
      </div>
      <div class="system-badge">
        발급 시스템: AutoFlow Enterprise Carrier Shipping Accident Claim Sentinel v2.0 (인쇄 시 직인 생략)
      </div>
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * 사고 건 목록을 영속화 파일에 기록
   * @param {Array} claims 사고 건 목록
   */
  recordAccidentClaims(claims = []) {
    if (!Array.isArray(claims) || claims.length === 0) return { recorded: 0 };
    try {
      this.ensureStorage();
      let data = { claims: [] };
      if (fs.existsSync(this.storagePath)) {
        try {
          const parsed = JSON.parse(fs.readFileSync(this.storagePath, "utf8"));
          if (parsed && typeof parsed === "object") {
            data = parsed;
          }
        } catch (e) {}
      }
      data.claims = (Array.isArray(data.claims) ? data.claims : []).filter(c => c && typeof c === "object");

      let count = 0;
      for (const item of claims) {
        if (!item || typeof item !== "object" || Object.keys(item).length === 0) continue;
        const claimId = String(item.claimId || item.orderId || Date.now());
        const existingIdx = data.claims.findIndex(c => c && String(c.claimId || c.orderId) === claimId);

        const evalDeadline = this.evaluateClaimDeadline(item);
        const evalCompensation = this.calculateCompensationAmount(item);

        const record = {
          claimId,
          orderId: item.orderId || claimId,
          trackingNumber: item.trackingNumber || "",
          carrierCode: evalCompensation.carrierCode,
          carrierName: evalCompensation.carrierName,
          carrierPhone: evalCompensation.carrierPhone,
          customerName: item.customerName || "고객",
          customerPhone: item.customerPhone || "",
          productName: item.productName || "주문 상품",
          accidentType: item.accidentType || "파손(DAMAGE)",
          status: item.status || "CLAIM_PENDING",
          costPrice: evalCompensation.costPrice,
          quantity: evalCompensation.quantity,
          totalCostPrice: evalCompensation.totalCostPrice,
          totalShippingFee: evalCompensation.totalShippingFee,
          totalClaimAmount: evalCompensation.totalClaimAmount,
          remainingHours: evalDeadline.remainingHours,
          remainingDays: evalDeadline.remainingDays,
          riskLevel: evalDeadline.riskLevel,
          isUrgent: evalDeadline.isUrgent,
          isExpired: evalDeadline.isExpired,
          recordedAt: item.recordedAt || new Date().toISOString(),
          resolvedAt: item.resolvedAt || null
        };

        if (existingIdx >= 0) {
          data.claims[existingIdx] = Object.assign({}, data.claims[existingIdx], record);
        } else {
          data.claims.unshift(record);
        }
        count++;
      }

      data.updatedAt = new Date().toISOString();
      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { recorded: count };
    } catch (e) {
      return { recorded: 0, error: e.message };
    }
  }

  /**
   * 사고 건 상태 전이 (보상 완료 / 청구 기각 / 포기)
   * @param {string} claimId 주문번호 또는 사고식별자
   * @param {string} action 상태 (`COMPENSATION_RECEIVED`, `CLAIM_REJECTED`, `WAIVED`)
   * @param {Object} options 추가 메모 등
   */
  resolveAccidentClaim(claimId, action = "COMPENSATION_RECEIVED", options = {}) {
    if (claimId && typeof claimId === "object") {
      action = claimId.action || action || "COMPENSATION_RECEIVED";
      options = claimId.options || claimId;
      claimId = claimId.claimId || claimId.orderId || "";
    }
    action = (typeof action === "string" && action) ? action : "COMPENSATION_RECEIVED";
    options = (options && typeof options === "object") ? options : {};
    try {
      this.ensureStorage();
      if (!fs.existsSync(this.storagePath)) return { success: false, error: "File not found" };

      const data = JSON.parse(fs.readFileSync(this.storagePath, "utf8")) || { claims: [] };
      data.claims = (Array.isArray(data.claims) ? data.claims : []).filter(c => c && typeof c === "object");
      const target = data.claims.find(c => String(c.claimId || c.orderId) === String(claimId));

      if (!target) {
        return { success: false, error: `Claim ID ${claimId} not found` };
      }

      target.status = action;
      target.resolvedAt = new Date().toISOString();
      target.compensationReceivedAmount = options.receivedAmount ? Number(options.receivedAmount) : target.totalClaimAmount;
      target.resolutionNote = options.note || (action === "COMPENSATION_RECEIVED" ? "택배사 보상금 입금 완료" : action);

      data.updatedAt = new Date().toISOString();
      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { success: true, updated: target };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  /**
   * 사고 대기열 및 보상 통계 조회
   * @returns {Object}
   */
  getAccidentSummary() {
    try {
      this.ensureStorage();
      if (!fs.existsSync(this.storagePath)) {
        return { totalClaims: 0, pendingClaims: 0, urgentClaims: 0, totalClaimAmount: 0, totalRecoveredAmount: 0 };
      }

      const data = JSON.parse(fs.readFileSync(this.storagePath, "utf8")) || { claims: [] };
      const claims = (Array.isArray(data.claims) ? data.claims : []).filter(c => c && typeof c === "object");

      let pendingClaims = 0;
      let urgentClaims = 0;
      let totalClaimAmount = 0;
      let totalRecoveredAmount = 0;

      for (const item of claims) {
        if (item.status === "CLAIM_PENDING") {
          pendingClaims++;
          totalClaimAmount += Number(item.totalClaimAmount || 0);
          if (item.isUrgent || item.riskLevel === "URGENT_3D" || item.riskLevel === "EXPIRED_14D") {
            urgentClaims++;
          }
        } else if (item.status === "COMPENSATION_RECEIVED") {
          totalRecoveredAmount += Number(item.compensationReceivedAmount || item.totalClaimAmount || 0);
        }
      }

      return {
        totalClaims: claims.length,
        pendingClaims,
        urgentClaims,
        totalClaimAmount,
        totalRecoveredAmount,
        recentClaims: claims.slice(0, 50)
      };
    } catch (e) {
      return { totalClaims: 0, pendingClaims: 0, urgentClaims: 0, totalClaimAmount: 0, totalRecoveredAmount: 0, recentClaims: [] };
    }
  }
}

const createShippingAccidentSentinel = (options = {}) => new ShippingAccidentSentinel(options);
ShippingAccidentSentinel.createShippingAccidentSentinel = createShippingAccidentSentinel;

module.exports = {
  ShippingAccidentSentinel,
  createShippingAccidentSentinel
};
