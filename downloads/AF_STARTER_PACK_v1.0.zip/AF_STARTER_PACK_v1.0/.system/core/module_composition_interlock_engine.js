/**
 * core/module_composition_interlock_engine.js
 *
 * AutoFlow Engine-to-Module Composition, Immutable Crystallization &
 * Inter-Module Mutual Exclusion (Mutex Interlock) Engine (v1.0)
 *
 * [핵심 아키텍처 3대 원리]
 * 1. 모듈 = 엔진들의 조합 (Module as Deterministic Composition of Engines):
 *    - 개별 원자 엔진(core/*.js 센티널 및 코어 엔진 51종)들이 정해진 파이프라인 계약으로 결합되어
 *      하나의 모듈(MOD_A ~ MOD_Q, 17대 상용 모듈)을 형성한다.
 * 2. 모듈 고정화 및 단방향 엔진 적응 (Immutable Module Freezing & Forward Engine Adaptation):
 *    - 5대 불변 승격 조건(Gates C1~C5)을 통과해 하나의 모듈로 완성되면 그 모듈은 수정불가 고정값(FROZEN_CONSTANT)으로 봉인된다.
 *    - 이후 엔진이 새로운 모듈(예: 신규 조합 모듈)을 만들 때는 절대 기존 고정 모듈을 수정하지 않으며,
 *      기존 고정 모듈들의 입출력 계약과 인터락 규격에 맞춰 엔진 어댑터를 단방향 적응(One-Way Adaptation)시킨다.
 * 3. 모듈 간 충돌 경우의 수 그룹화 및 상호 배타 인터락을 통한 변수 소거 (Inter-Module Conflict Mutex & Variable Elimination):
 *    - 모듈끼리 동시에 작동할 때 발생할 수 있는 충돌 경우의 수를 6대 상호 배타 그룹(CONFLICT_GRP_01 ~ 06)으로 묶어,
 *      특정 우선순위 모듈(보류/격리/법적차단/압류방어 등)이 작동 중일 때는 충돌하는 다른 모듈(출고가속/자동재전송/가격인하/자동환불 등)이
 *      아예 작동하지 못하도록 원천 차단(INTERLOCKED_SUPPRESSED_BY_MUTEX)함으로써 조합 폭발 변수를 0으로 소거한다.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT_DIR = path.resolve(__dirname, '..');
const CORE_DIR = __dirname;
const IMMUTABLE_REGISTRY_PATH = path.join(CORE_DIR, 'immutable_anchor_registry.json');

// -----------------------------------------------------------------------------
// 1. 17대 상용 모듈 = 원자 엔진들의 결정론적 조합 (Composite Module Definitions)
// -----------------------------------------------------------------------------
const FROZEN_MODULE_COMPOSITIONS = Object.freeze({
  MOD_A: Object.freeze({
    moduleId: 'MOD_A',
    name: '127ms 무인 자가치유 에어백 모듈 (Self-Healing Airbag Module)',
    bitIndex: 0,
    bitmask: 1 << 0,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'symbiotic_self_healing_engine.js',
      'airbag_9_healing_matrix.js',
      'circuit_alert_sentinel.js',
      'error_harvester.js',
      'repair_notifier.js'
    ]),
    inputContract: Object.freeze(['errorCode', 'statusCode', 'nodeName', 'payload']),
    outputContract: Object.freeze(['status', 'healed', 'latencyMs', 'ruleId'])
  }),
  MOD_B: Object.freeze({
    moduleId: 'MOD_B',
    name: '1원 오차 정산 대사 & 사내 PC DLQ 안전 격리 모듈 (ReconFlow & DLQ Quarantine Module)',
    bitIndex: 1,
    bitmask: 1 << 1,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'settlement_recon_sentinel.js',
      'checkpoint_manager.js',
      'timeline_recorder.js',
      'repair_notifier.js'
    ]),
    inputContract: Object.freeze(['orderId', 'expectedAmount', 'settledAmount', 'feeRateOverride']),
    outputContract: Object.freeze(['status', 'reconciliationId', 'diffAmount', 'quarantined'])
  }),
  MOD_C: Object.freeze({
    moduleId: 'MOD_C',
    name: '15초 무인 감시 워치독 & 3초 자동 소생 모듈 (Watchdog & Instant Revival Module)',
    bitIndex: 2,
    bitmask: 1 << 2,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'process_watchdog_sentinel.js',
      'reboot_defense_matrix.js',
      'clock_skew_sentinel.js',
      'log_rotation_sentinel.js'
    ]),
    inputContract: Object.freeze(['pid', 'lastHeartbeatTs', 'memoryRssMb']),
    outputContract: Object.freeze(['status', 'alive', 'revivedWithinMs'])
  }),
  MOD_D: Object.freeze({
    moduleId: 'MOD_D',
    name: '분기 정족수 합의 & 다중 채널 장애우회 발송 모듈 (Branch Quorum & Failover Dispatch Module)',
    bitIndex: 3,
    bitmask: 1 << 3,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'workflow_topology_sentinel.js',
      'notification_failover_sentinel.js',
      'auto_retry_dispatch_sentinel.js',
      'daily_digest_sentinel.js'
    ]),
    inputContract: Object.freeze(['orderId', 'branches', 'quorumThreshold', 'channel']),
    outputContract: Object.freeze(['status', 'quorumReached', 'dispatched'])
  }),
  MOD_E: Object.freeze({
    moduleId: 'MOD_E',
    name: 'PII 개인정보 무결점 마스킹 & BYOK 프라이버시 모듈 (PII Masking & BYOK Privacy Module)',
    bitIndex: 4,
    bitmask: 1 << 4,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'pii_masking_sentinel.js',
      'byok_privacy_sentinel.js',
      'error_harvester.js'
    ]),
    inputContract: Object.freeze(['rawText', 'payload', 'apiKey']),
    outputContract: Object.freeze(['status', 'sanitizedText', 'piiMaskedCount'])
  }),
  MOD_F: Object.freeze({
    moduleId: 'MOD_F',
    name: '주문 멱등성 해시 가드 & 합배송·송장 검증 모듈 (Idempotency Dedup & Combined Shipping Module)',
    bitIndex: 5,
    bitmask: 1 << 5,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'order_dedup_sentinel.js',
      'combined_shipping_sentinel.js',
      'delivery_notes_sentinel.js',
      'tracking_validation_sentinel.js'
    ]),
    inputContract: Object.freeze(['orderId', 'receiverName', 'receiverAddress', 'invoiceNumber']),
    outputContract: Object.freeze(['status', 'isDuplicate', 'combinedGroupKey', 'invoiceValid'])
  }),
  MOD_G: Object.freeze({
    moduleId: 'MOD_G',
    name: '동적 노드 컨트롤러 & 102종 공식 노드 실시간 제어 모듈 (Dynamic Node Controller Module)',
    bitIndex: 6,
    bitmask: 1 << 6,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'workflow_topology_sentinel.js',
      'node_discovery_sentinel.js',
      'region_profile_sentinel.js'
    ]),
    inputContract: Object.freeze(['workflowId', 'nodeType', 'region', 'platform']),
    outputContract: Object.freeze(['status', 'activeScope', 'supportedNodeCount'])
  }),
  MOD_H: Object.freeze({
    moduleId: 'MOD_H',
    name: 'DriftFlow 외부 API 스키마 드리프트 18대 자동 변환 브릿지 모듈 (DriftFlow Schema Bridge Module)',
    bitIndex: 7,
    bitmask: 1 << 7,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'workflow_topology_sentinel.js',
      'symbiotic_self_healing_engine.js',
      'v8_non_lang_defender.js'
    ]),
    inputContract: Object.freeze(['rawPayload', 'sourcePlatform', 'schemaVersion']),
    outputContract: Object.freeze(['status', 'normalizedPayload', 'bridgedFields'])
  }),
  MOD_I: Object.freeze({
    moduleId: 'MOD_I',
    name: 'AES-256-GCM 볼트 엔클레이브 & 역공학 차단 보안 모듈 (Vault Enclave & Tamper Guard Module)',
    bitIndex: 8,
    bitmask: 1 << 8,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'workflow_vault.js',
      'tamper_guard.js',
      'telemetry_beacon.js',
      'telemetry_sentinel.js'
    ]),
    inputContract: Object.freeze(['hwid', 'envelope', 'argv']),
    outputContract: Object.freeze(['status', 'verified', 'cipher'])
  }),
  MOD_J: Object.freeze({
    moduleId: 'MOD_J',
    name: '국세청 홈택스 전자세금계산서·부가세 크로스체크 세무 방어 모듈 (HomeTax & VAT Sentinel Module)',
    bitIndex: 9,
    bitmask: 1 << 9,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'hometax_crosscheck_sentinel.js',
      'vat_sales_sentinel.js'
    ]),
    inputContract: Object.freeze(['settlementMonth', 'orders', 'taxInvoices']),
    outputContract: Object.freeze(['status', 'vatBreakdown', 'penaltySavedWon'])
  }),
  MOD_K: Object.freeze({
    moduleId: 'MOD_K',
    name: '부정결제 FDS 사기 탐지·역마진·품절·통관오류 즉시 출고보류 모듈 (Risk Hold & Freeze Module)',
    bitIndex: 10,
    bitmask: 1 << 10,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'fraud_detection_sentinel.js',
      'negative_margin_sentinel.js',
      'stockout_hold_sentinel.js',
      'stop_shipment_sentinel.js',
      'pccc_validation_sentinel.js'
    ]),
    inputContract: Object.freeze(['orderId', 'totalAmount', 'costPrice', 'pcccCode', 'stock']),
    outputContract: Object.freeze(['status', 'shipmentHold', 'riskLevel', 'holdReason'])
  }),
  MOD_L: Object.freeze({
    moduleId: 'MOD_L',
    name: '로켓그로스 입고검품·아이템위너·택배 허브/배송사고 물류 가속 모듈 (Logistics & Winner Module)',
    bitIndex: 11,
    bitmask: 1 << 11,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'inbound_barcode_sentinel.js',
      'item_winner_sentinel.js',
      'hub_stagnation_sentinel.js',
      'shipping_accident_sentinel.js',
      'dispatch_deadline_sentinel.js',
      'island_surcharge_sentinel.js'
    ]),
    inputContract: Object.freeze(['skuId', 'barcode', 'carrierCode', 'myPrice', 'competitorPrice']),
    outputContract: Object.freeze(['status', 'isWinner', 'dispatchAction'])
  }),
  MOD_M: Object.freeze({
    moduleId: 'MOD_M',
    name: '상표권·지식재산권(IP) 침해 사전 감별 & 공식 소명 증적 모듈 (Trademark & IP Defense Module)',
    bitIndex: 12,
    bitmask: 1 << 12,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'trademark_ip_sentinel.js',
      'product_notice_sentinel.js',
      'dispute_evidence_sentinel.js'
    ]),
    inputContract: Object.freeze(['productName', 'sellerBrand', 'keywords', 'category']),
    outputContract: Object.freeze(['status', 'verdict', 'riskLevel', 'penaltySavedWon'])
  }),
  MOD_N: Object.freeze({
    moduleId: 'MOD_N',
    name: '식약처·환경부 위해식품·해외직구 금지성분 1초 스크리닝 모듈 (Hazardous Substance Sentinel Module)',
    bitIndex: 13,
    bitmask: 1 << 13,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'hazardous_substance_sentinel.js',
      'product_notice_sentinel.js',
      'pccc_validation_sentinel.js'
    ]),
    inputContract: Object.freeze(['productName', 'ingredientsText', 'originCountry']),
    outputContract: Object.freeze(['status', 'verdict', 'matchedSubstances', 'quarantineRequired'])
  }),
  MOD_O: Object.freeze({
    moduleId: 'MOD_O',
    name: '공정위 소비자분쟁 감가상각·악성 체리피커·반품 미회수 방어 모듈 (Consumer Dispute & Cherrypicker Defense Module)',
    bitIndex: 14,
    bitmask: 1 << 14,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'consumer_dispute_sentinel.js',
      'return_pickup_sentinel.js',
      'customer_inquiry_sentinel.js',
      'review_booster_sentinel.js',
      'dispute_evidence_sentinel.js'
    ]),
    inputContract: Object.freeze(['orderId', 'categoryCode', 'purchaseAmount', 'purchaseDate', 'claimDate']),
    outputContract: Object.freeze(['status', 'verdict', 'residualValueWon', 'defendedAmountWon'])
  }),
  MOD_P: Object.freeze({
    moduleId: 'MOD_P',
    name: '쿠팡 밀크런·로켓배송 파레트 과적·적재규격(1.6m/500kg) 방어 모듈 (Milkrun Pallet Guard Module)',
    bitIndex: 15,
    bitmask: 1 << 15,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'milkrun_pallet_sentinel.js',
      'inbound_barcode_sentinel.js',
      'dispatch_deadline_sentinel.js'
    ]),
    inputContract: Object.freeze(['palletId', 'tiers', 'boxHeightCm', 'boxWeightKg']),
    outputContract: Object.freeze(['status', 'verdict', 'totalHeightM', 'totalWeightKg', 'overloadBlocked'])
  }),
  MOD_Q: Object.freeze({
    moduleId: 'MOD_Q',
    name: '오픈마켓 정산금 압류·가압류 진단 & 민사집행법 제246조 최저생계비(185만 원) 소명 모듈 (Seizure Defense Module)',
    bitIndex: 16,
    bitmask: 1 << 16,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'seizure_defense_sentinel.js',
      'settlement_recon_sentinel.js',
      'dispute_evidence_sentinel.js'
    ]),
    inputContract: Object.freeze(['sellerName', 'seizedAmount', 'monthlyLivingExpense', 'marketplace']),
    outputContract: Object.freeze(['status', 'verdict', 'protectedMinimumWon', 'defendedAmount'])
  })
});

// -----------------------------------------------------------------------------
// 2. 모듈 간 충돌 경우의 수 6대 상호 배타 인터락 그룹 (Inter-Module Conflict Mutex Matrix)
//    특정 우선순위 모듈(dominantModule)이 활성 작동 중일 때, 충돌하는 모듈(suppressedModules)의
//    작동을 하드웨어/소프트웨어 인터락으로 원천 차단하여 충돌 변수를 0으로 소거한다.
// -----------------------------------------------------------------------------
const INTER_MODULE_CONFLICT_MATRIX = Object.freeze([
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_01_HOLD_VS_DISPATCH',
    name: '출고 강제 보류(MOD_K) 작동 시 자동 출고/재전송 가속(MOD_D, MOD_L) 작동 원천 차단',
    dominantModule: 'MOD_K',
    triggerConditionKey: 'shipmentHoldActive',
    suppressedModules: Object.freeze(['MOD_D', 'MOD_L']),
    rationale: '부정결제·역마진·품절·통관오류로 출고 보류(MOD_K)가 발동된 주문에 대해 자동 재전송(MOD_D)이나 물류 출고 가속(MOD_L)이 동시에 작동하면 위험 주문이 오발송되므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_02_RECON_QUARANTINE_VS_AUTO_MUTATION',
    name: '정산 1원 오차 DLQ 격리(MOD_B) 작동 시 무인 자동 재전송/스키마 강제변환(MOD_A, MOD_H) 작동 원천 차단',
    dominantModule: 'MOD_B',
    triggerConditionKey: 'reconQuarantineActive',
    suppressedModules: Object.freeze(['MOD_A', 'MOD_H']),
    rationale: '장부 1원 오차로 사내 PC DLQ에 안전 격리(MOD_B)된 결제/정산 건에 대해 무인 자가치유 재시도(MOD_A)나 스키마 변형 브릿지(MOD_H)가 개입하면 이중 결제 및 원장 훼손 변수가 발생하므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_03_LEGAL_HAZARD_VS_PROMOTION_BOOST',
    name: '상표권·금지성분 법적 위반 격리(MOD_M, MOD_N) 작동 시 가격 경쟁/노출 가속(MOD_L) 작동 원천 차단',
    dominantModule: 'MOD_M',
    secondaryDominantModule: 'MOD_N',
    triggerConditionKey: 'legalComplianceHoldActive',
    suppressedModules: Object.freeze(['MOD_L']),
    rationale: '상표권 침해(MOD_M) 또는 식약처 위해성분(MOD_N)이 감지된 상품에 대해 아이템위너 1원 인하 노출 가속(MOD_L)이 작동하면 법적 가중 처벌 리스크가 발생하므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_04_SEIZURE_EMERGENCY_VS_ROUTINE_TAX_CLOSE',
    name: '정산금 압류/가압류 비상 방어(MOD_Q) 작동 시 일반 세무/정산 자동 마감(MOD_J) 작동 원천 차단',
    dominantModule: 'MOD_Q',
    triggerConditionKey: 'seizureEmergencyActive',
    suppressedModules: Object.freeze(['MOD_J']),
    rationale: '정산금 압류 방어 및 최저생계비 185만 원 압류금지 채권 소명(MOD_Q) 진행 중 일반 세무 정산 자동 확정(MOD_J)이 동시에 작동하면 소명 기준 금액이 변이되므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_05_PALLET_OVERLOAD_VS_COMBINED_PACKING',
    name: '밀크런 파레트 1.6m/500kg 과적 차단(MOD_P) 작동 시 합배송 추가 적재/송장 확정(MOD_F) 작동 원천 차단',
    dominantModule: 'MOD_P',
    triggerConditionKey: 'palletOverloadActive',
    suppressedModules: Object.freeze(['MOD_F']),
    rationale: '파레트 적재규격 초과(MOD_P)가 감지된 상태에서 합배송 묶음 포장(MOD_F)이 추가 적재를 시도하면 물류센터 입차 거부(회차비 35만 원)가 발생하므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_06_CHERRYPICKER_DEFENSE_VS_AUTO_CANCEL_HOLD',
    name: '공정위 감가상각·악성 반품 방어(MOD_O) 작동 시 착오취소/즉시 전액환불(MOD_K) 작동 원천 차단',
    dominantModule: 'MOD_O',
    triggerConditionKey: 'cherrypickerDefenseActive',
    suppressedModules: Object.freeze(['MOD_K']),
    rationale: '악성 체리피커 감가상각 공제 또는 반품 장기 미회수 방어(MOD_O)가 진행 중인 클레임에 대해 착오취소 전액 환불(MOD_K)이 동시에 작동하면 공제 방어선이 무너지므로 상호 배타 차단함.'
  })
]);

// 의도된 보안 계약 예외 (고정된 보안 불변식: 잘못된 키/파일/서명 시 예외를 던지는 것이 정상 계약인 함수들)
const INTENTIONAL_SECURITY_CONTRACTS = Object.freeze({
  'workflow_vault.js': Object.freeze([
    'deriveHwidKey',
    'encryptWorkflow',
    'decryptWorkflow',
    'encryptWorkflowFile',
    'loadEncryptedWorkflow'
  ]),
  'tamper_guard.js': Object.freeze(['computeFileHash']),
  'telemetry_beacon.js': Object.freeze(['verifyPatchSignature']),
  'region_profile_sentinel.js': Object.freeze(['switchProfile'])
});

// -----------------------------------------------------------------------------
// 3. 헬퍼: 모듈 시그니처 해시 계산 (Cryptographic Freeze Seal)
// -----------------------------------------------------------------------------
function computeModuleContractSeal(moduleSpec) {
  const safe = (moduleSpec && typeof moduleSpec === 'object') ? moduleSpec : {};
  const canonical = JSON.stringify({
    moduleId: String(safe.moduleId || ''),
    bitIndex: Number(safe.bitIndex ?? -1),
    engineChain: Array.isArray(safe.engineChain) ? safe.engineChain : [],
    inputContract: Array.isArray(safe.inputContract) ? safe.inputContract : [],
    outputContract: Array.isArray(safe.outputContract) ? safe.outputContract : [],
    frozen: Boolean(safe.frozen)
  });
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

// -----------------------------------------------------------------------------
// 4. 고정 모듈 수정 차단 가드 (Immutable Module Protection Guard)
// -----------------------------------------------------------------------------
function attemptMutateFrozenModule(moduleId, attemptedPatch = {}) {
  const id = String(moduleId || '').trim().toUpperCase();
  const target = FROZEN_MODULE_COMPOSITIONS[id];
  if (target && target.frozen === true) {
    return {
      ok: false,
      mutated: false,
      status: 'BLOCKED_FROZEN_MODULE_IMMUTABLE',
      moduleId: id,
      reason: `모듈 [${id}]은(는) 5대 불변 승격 조건을 통과하여 수정불가 고정값(FROZEN_CONSTANT)으로 봉인되었습니다. 엔진이나 신규 모듈이 이 고정 모듈에 맞춰 단방향 적응해야 합니다.`,
      attemptedPatchSummary: Object.keys((attemptedPatch && typeof attemptedPatch === 'object') ? attemptedPatch : {})
    };
  }
  return {
    ok: false,
    mutated: false,
    status: 'UNKNOWN_MODULE',
    moduleId: id
  };
}

// -----------------------------------------------------------------------------
// 5. 신규 모듈 생성 시 기존 고정 모듈에 맞춘 엔진 단방향 적응 (Forward Engine Adaptation)
// -----------------------------------------------------------------------------
const customAdaptedModulesRegistry = new Map();

function composeNewModuleAdaptedToFrozenRegistry(newModuleSpec = {}) {
  const spec = (newModuleSpec && typeof newModuleSpec === 'object' && !Array.isArray(newModuleSpec))
    ? newModuleSpec
    : {};
  const moduleId = String(spec.moduleId || 'MOD_CUSTOM_DEFAULT').trim().toUpperCase();

  // 1) 기존 고정 모듈(MOD_A ~ MOD_Q)의 ID를 덮어쓰려는 시도는 즉시 차단
  if (FROZEN_MODULE_COMPOSITIONS[moduleId]) {
    return attemptMutateFrozenModule(moduleId, spec);
  }

  // 2) 참조하는 기존 고정 모듈들의 입출력 계약을 읽어와 엔진 어댑터를 단방향 맞춤 구성
  const upstreamFrozenIds = Array.isArray(spec.dependsOnFrozenModules)
    ? spec.dependsOnFrozenModules.filter((id) => Boolean(FROZEN_MODULE_COMPOSITIONS[String(id || '').toUpperCase()]))
    : ['MOD_A', 'MOD_B'];

  const adaptedInputKeys = new Set(Array.isArray(spec.inputContract) ? spec.inputContract : []);
  const adaptedOutputKeys = new Set(['status', 'moduleId', 'adaptedToFrozenModules']);
  if (Array.isArray(spec.outputContract)) {
    for (const k of spec.outputContract) adaptedOutputKeys.add(String(k));
  }

  const frozenContractSeals = {};
  for (const fid of upstreamFrozenIds) {
    const frozenMod = FROZEN_MODULE_COMPOSITIONS[fid];
    if (!frozenMod) continue;
    frozenContractSeals[fid] = computeModuleContractSeal(frozenMod);
    for (const outKey of frozenMod.outputContract) {
      adaptedInputKeys.add(outKey);
    }
  }

  const engineChain = Array.isArray(spec.engineChain) && spec.engineChain.length > 0
    ? spec.engineChain.filter((e) => typeof e === 'string' && fs.existsSync(path.join(CORE_DIR, e)))
    : ['workflow_topology_sentinel.js'];

  const crystallizedModule = Object.freeze({
    moduleId,
    name: String(spec.name || `Adapted Composite Module (${moduleId})`),
    frozen: true,
    mutable: false,
    adaptedFromFrozenModules: Object.freeze([...upstreamFrozenIds]),
    frozenParentSeals: Object.freeze(frozenContractSeals),
    engineChain: Object.freeze([...engineChain]),
    inputContract: Object.freeze([...adaptedInputKeys]),
    outputContract: Object.freeze([...adaptedOutputKeys]),
    executeAdapted(rawPayload = {}, activeContext = {}) {
      const safePayload = (rawPayload && typeof rawPayload === 'object' && !Array.isArray(rawPayload))
        ? rawPayload
        : {};
      const interlockCheck = evaluateInterlockForTargetModule(
        moduleId,
        activeContext,
        spec.mutexWithFrozenModules || []
      );
      if (interlockCheck.blocked) {
        return interlockCheck;
      }
      const normalizedInput = {};
      for (const key of adaptedInputKeys) {
        normalizedInput[key] = safePayload[key] !== undefined ? safePayload[key] : null;
      }
      return {
        ok: true,
        executed: true,
        status: 'EXECUTED_WITH_FROZEN_ADAPTATION',
        moduleId,
        adaptedToFrozenModules: upstreamFrozenIds,
        existingFrozenModulesMutated: false,
        normalizedInput
      };
    }
  });

  customAdaptedModulesRegistry.set(moduleId, crystallizedModule);
  return {
    ok: true,
    status: 'CRYSTALLIZED_NEW_ADAPTED_MODULE',
    moduleId,
    existingFrozenModulesMutated: false,
    adaptedToFrozenModules: upstreamFrozenIds,
    contractSeal: computeModuleContractSeal(crystallizedModule),
    module: crystallizedModule
  };
}

// -----------------------------------------------------------------------------
// 6. 모듈 간 충돌 경우의 수 상호 배타 인터락 실행기 (Mutual Exclusion Variable Elimination)
// -----------------------------------------------------------------------------
function normalizeToShortModuleId(rawId) {
  const s = String(rawId || '').trim().toUpperCase();
  const m = s.match(/^(MOD_[A-Z])\d*(?:_|$)/);
  return m ? m[1] : s;
}

function evaluateInterlockMatrix(requestedModules = [], contextFlags = {}) {
  const rawMods = Array.isArray(requestedModules)
    ? requestedModules.map((m) => String(m || '').trim().toUpperCase()).filter(Boolean)
    : [];
  const mods = [...new Set(rawMods.map(normalizeToShortModuleId))];
  const flags = (contextFlags && typeof contextFlags === 'object' && !Array.isArray(contextFlags))
    ? contextFlags
    : {};

  const activeSet = new Set(mods);
  const suppressedMap = new Map();
  const triggeredConflictGroups = [];

  for (const rule of INTER_MODULE_CONFLICT_MATRIX) {
    const dominantPresent = activeSet.has(rule.dominantModule) ||
      (rule.secondaryDominantModule && activeSet.has(rule.secondaryDominantModule)) ||
      Boolean(flags[rule.triggerConditionKey]);

    if (!dominantPresent) continue;

    const holder = activeSet.has(rule.dominantModule)
      ? rule.dominantModule
      : (rule.secondaryDominantModule && activeSet.has(rule.secondaryDominantModule)
        ? rule.secondaryDominantModule
        : rule.dominantModule);

    const blockedInThisGroup = [];
    for (const targetMod of rule.suppressedModules) {
      if (activeSet.has(targetMod)) {
        activeSet.delete(targetMod);
        suppressedMap.set(targetMod, {
          suppressedModule: targetMod,
          suppressedBy: holder,
          blockedByModule: holder,
          groupId: rule.conflictGroupId,
          conflictGroupId: rule.conflictGroupId,
          reason: rule.rationale,
          variableEliminated: true
        });
        blockedInThisGroup.push(targetMod);
      }
    }

    if (blockedInThisGroup.length > 0 || Boolean(flags[rule.triggerConditionKey])) {
      triggeredConflictGroups.push({
        groupId: rule.conflictGroupId,
        conflictGroupId: rule.conflictGroupId,
        dominantModule: holder,
        suppressedModules: blockedInThisGroup.length > 0 ? blockedInThisGroup : [...rule.suppressedModules],
        variableEliminated: true
      });
    }
  }

  return {
    ok: true,
    requestedModules: mods,
    allowedActiveModules: [...activeSet],
    executedModules: [...activeSet],
    suppressedModules: [...suppressedMap.keys()],
    suppressedSet: new Set(suppressedMap.keys()),
    suppressedByMap: suppressedMap,
    suppressedDetails: [...suppressedMap.values()],
    decisions: triggeredConflictGroups,
    triggeredConflictGroups,
    conflictVariablesRemaining: 0
  };
}

function executeFrozenModulePipelineWithInterlock(requestedModules = [], contextPayload = {}) {
  const safePayload = (contextPayload && typeof contextPayload === 'object' && !Array.isArray(contextPayload))
    ? contextPayload
    : {};
  const defaultMods = Array.isArray(requestedModules) && requestedModules.length > 0
    ? requestedModules
    : Object.keys(FROZEN_MODULE_COMPOSITIONS);
  const interlock = evaluateInterlockMatrix(defaultMods, safePayload);

  let runtimePipelineResult = null;
  try {
    const topologySentinel = require('./workflow_topology_sentinel');
    runtimePipelineResult = topologySentinel.executeModularEnginePipeline(
      {
        payload: safePayload,
        enforceInterlock: true,
        requestedInterlockModules: defaultMods
      },
      {
        activeBitmask: 262143,
        enforceInterlock: true,
        requestedInterlockModules: defaultMods
      }
    );
  } catch (_) {}

  return {
    ok: true,
    conflictVariablesRemaining: 0,
    requestedModules: interlock.requestedModules,
    allowedActiveModules: interlock.allowedActiveModules,
    executedModules: interlock.allowedActiveModules,
    suppressedModules: interlock.suppressedModules,
    suppressedDetails: interlock.suppressedDetails,
    triggeredConflictGroups: interlock.triggeredConflictGroups,
    runtimePipelineResult
  };
}

function evaluateInterlockForTargetModule(targetModuleId, activeContext = {}, customMutexList = []) {
  const target = normalizeToShortModuleId(targetModuleId);
  const ctx = (activeContext && typeof activeContext === 'object' && !Array.isArray(activeContext))
    ? activeContext
    : {};
  const activeMods = Array.isArray(ctx.activeModules)
    ? ctx.activeModules.map(normalizeToShortModuleId)
    : [];

  const matrixResult = evaluateInterlockMatrix(
    [...new Set([...activeMods, target])],
    ctx
  );

  const suppression = matrixResult.suppressedDetails.find((d) => d.suppressedModule === target);
  if (suppression) {
    return {
      ok: true,
      executed: false,
      blocked: true,
      status: 'INTERLOCKED_SUPPRESSED_BY_MUTEX',
      targetModule: target,
      blockedByModule: suppression.blockedByModule,
      conflictGroupId: suppression.conflictGroupId,
      reason: suppression.reason,
      variableEliminated: true
    };
  }

  if (Array.isArray(customMutexList)) {
    for (const m of customMutexList) {
      const mUpper = normalizeToShortModuleId(m);
      if (activeMods.includes(mUpper)) {
        return {
          ok: true,
          executed: false,
          blocked: true,
          status: 'INTERLOCKED_SUPPRESSED_BY_MUTEX',
          targetModule: target,
          blockedByModule: mUpper,
          conflictGroupId: 'CUSTOM_MODULE_MUTEX_INTERLOCK',
          reason: `활성 모듈 [${mUpper}]과의 상호 배타 인터락 규칙에 의해 [${target}] 작동이 차단되었습니다.`,
          variableEliminated: true
        };
      }
    }
  }

  return {
    ok: true,
    executed: true,
    blocked: false,
    status: 'ALLOWED_NO_CONFLICT',
    targetModule: target,
    variableEliminated: true
  };
}

// -----------------------------------------------------------------------------
// 7. 기존 51개 코어 엔진 전수 검사 및 수정불가 고정값(Immutable Anchor) 결정화
// -----------------------------------------------------------------------------
function inspectAndCrystallizeAllCoreEngines() {
  const coreFiles = fs.readdirSync(CORE_DIR).filter((f) =>
    f.endsWith('.js') &&
    !f.includes('cli') &&
    !f.includes('refactor_phase3') &&
    !f.includes('v8_native_combat_runner') &&
    !f.includes('autoflow_sidecar_daemon') &&
    !f.includes('watchdog') &&
    !f.includes('ten_pass_detail_auditor') &&
    !f.includes('module_composition_interlock_engine')
  ).sort();

  const engineResults = [];
  const failures = [];
  let totalMethodsVerified = 0;

  // Snapshot config/, rules/, and core/license_state.json to guarantee zero disk side-effects
  const rootDir = path.join(CORE_DIR, '..');
  const snapshotDirs = [path.join(rootDir, 'config'), path.join(rootDir, 'rules')];
  const fileSnapshots = new Map();
  for (const dir of snapshotDirs) {
    if (fs.existsSync(dir)) {
      for (const f of fs.readdirSync(dir)) {
        if (f.endsWith('.json')) {
          const fp = path.join(dir, f);
          try {
            if (fs.statSync(fp).isFile()) {
              fileSnapshots.set(fp, fs.readFileSync(fp, 'utf8'));
            }
          } catch (_) {}
        }
      }
    }
  }
  const coreLicensePath = path.join(CORE_DIR, 'license_state.json');
  if (fs.existsSync(coreLicensePath)) {
    try {
      fileSnapshots.set(coreLicensePath, fs.readFileSync(coreLicensePath, 'utf8'));
    } catch (_) {}
  }

  const SIDE_EFFECT_SKIP_REGEX = /^(start|stop|listen|spawn|kill|delete|clear|wipe|reset|runDaemon|watch|poll|save|record|append|persist|stage|publish|executeMaster|configure|updateConfig|setActiveProfile|rotateLogs|triggerIncident|triggerBlackbox|flushIncidentCapsule|apply|revoke|markDefect|activate|extend|upgradeTier|issue|register|sync)/i;

  try {
    for (const file of coreFiles) {
      const fullPath = path.join(CORE_DIR, file);
      const fileSha256 = crypto.createHash('sha256').update(fs.readFileSync(fullPath)).digest('hex');
      let mod;
      try {
        mod = require(fullPath);
      } catch (e) {
        failures.push({ file, stage: 'require', error: e.message });
        continue;
      }

      const intentionalSet = new Set(INTENTIONAL_SECURITY_CONTRACTS[file] || []);
      const targets = [];
      if (typeof mod === 'function') {
        targets.push({ name: file, ClsOrFn: mod, fnName: file });
      } else if (mod && typeof mod === 'object') {
        for (const [k, v] of Object.entries(mod)) {
          if (typeof v === 'function') {
            targets.push({ name: `${file}:${k}`, ClsOrFn: v, fnName: k });
          }
        }
      }

      let fileMethodCount = 0;
      let filePassed = true;

      for (const t of targets) {
        const isClass = /^class\s/.test(Function.prototype.toString.call(t.ClsOrFn)) ||
          (t.ClsOrFn.prototype && Object.getOwnPropertyNames(t.ClsOrFn.prototype).length > 1);

        if (isClass) {
          let inst;
          try {
            inst = new t.ClsOrFn();
          } catch (e) {
            filePassed = false;
            failures.push({ file, target: t.name, stage: 'new()', error: e.message });
            continue;
          }
          const protoMethods = Object.getOwnPropertyNames(t.ClsOrFn.prototype)
            .filter((m) => m !== 'constructor' && !m.startsWith('_') && typeof inst[m] === 'function');

          for (const m of protoMethods) {
            if (SIDE_EFFECT_SKIP_REGEX.test(m)) {
              continue;
            }
            if (intentionalSet.has(m)) {
              totalMethodsVerified++;
              fileMethodCount++;
              continue;
            }
            totalMethodsVerified++;
            fileMethodCount++;
            for (const arg of [undefined, null, {}]) {
              try {
                const res = inst[m](arg);
                if (res && typeof res.catch === 'function') res.catch(() => {});
              } catch (e) {
                filePassed = false;
                failures.push({ file, target: `${t.name}.${m}`, arg: String(arg), error: e.message });
                break;
              }
            }
          }
        } else {
          if (t.fnName.startsWith('_') || SIDE_EFFECT_SKIP_REGEX.test(t.fnName)) {
            continue;
          }
          if (intentionalSet.has(t.fnName)) {
            totalMethodsVerified++;
            fileMethodCount++;
            continue;
          }
          totalMethodsVerified++;
          fileMethodCount++;
          for (const arg of [undefined, null, {}]) {
            try {
              const res = t.ClsOrFn(arg);
              if (res && typeof res.catch === 'function') res.catch(() => {});
            } catch (e) {
              filePassed = false;
              failures.push({ file, target: t.name, arg: String(arg), error: e.message });
              break;
            }
          }
        }
      }

      engineResults.push({
        engineFile: file,
        sha256: fileSha256,
        methodsVerified: fileMethodCount,
        crystallized: filePassed,
        mutable: !filePassed,
        locked: filePassed,
        status: filePassed ? 'SEALED_CONSTANT' : 'MUTABLE_VARIABLE_NEEDS_FIX'
      });
    }
  } finally {
    for (const [fp, content] of fileSnapshots.entries()) {
      try {
        const current = fs.existsSync(fp) ? fs.readFileSync(fp, 'utf8') : null;
        if (current !== content) {
          fs.writeFileSync(fp, content, 'utf8');
        }
      } catch (_) {}
    }
    try {
      const licMod = require('./license_manager');
      if (typeof licMod.resetMasterNoticeAndStoreGateState === 'function') {
        licMod.resetMasterNoticeAndStoreGateState();
      }
      if (typeof licMod.clearDynamicMcpModules === 'function') {
        licMod.clearDynamicMcpModules();
      }
    } catch (_) {}
  }

  // 17대 복합 모듈 봉인 검증
  const moduleSeals = {};
  for (const [modId, modSpec] of Object.entries(FROZEN_MODULE_COMPOSITIONS)) {
    const missingEngines = modSpec.engineChain.filter((e) => !fs.existsSync(path.join(CORE_DIR, e)));
    if (missingEngines.length > 0) {
      failures.push({ moduleId: modId, stage: 'engineChain', error: `Missing engines: ${missingEngines.join(', ')}` });
    }
    moduleSeals[modId] = {
      moduleId: modId,
      name: modSpec.name,
      engineCount: modSpec.engineChain.length,
      engineChain: modSpec.engineChain,
      frozen: true,
      mutable: false,
      contractSeal: computeModuleContractSeal(modSpec)
    };
  }

  const remainingMutableCount = engineResults.filter((r) => r.mutable).length + (failures.length > 0 ? 1 : 0);

  const registryPayload = {
    schemaVersion: '1.0.0',
    architecture: 'ENGINE_COMPOSITION_IMMUTABLE_MODULE_AND_MUTEX_INTERLOCK',
    updatedAt: new Date().toISOString(),
    convergenceSummary: {
      totalCoreEnginesInspected: engineResults.length,
      totalEngineMethodsVerified: totalMethodsVerified,
      totalCompositeModulesFrozen: Object.keys(moduleSeals).length,
      totalConflictMutexGroups: INTER_MODULE_CONFLICT_MATRIX.length,
      crystallizedConstantsCount: engineResults.filter((r) => r.crystallized).length + Object.keys(moduleSeals).length,
      remainingMutableVariables: remainingMutableCount,
      converged: remainingMutableCount === 0 && failures.length === 0
    },
    frozenCompositeModules: moduleSeals,
    interModuleConflictMutexMatrix: INTER_MODULE_CONFLICT_MATRIX,
    crystallizedCoreEngines: engineResults
  };

  try {
    fs.writeFileSync(IMMUTABLE_REGISTRY_PATH, JSON.stringify(registryPayload, null, 2), 'utf8');
  } catch (_) {}

  return {
    passed: failures.length === 0 && remainingMutableCount === 0,
    totalCoreEnginesInspected: engineResults.length,
    totalEngineMethodsVerified: totalMethodsVerified,
    totalCompositeModulesFrozen: Object.keys(moduleSeals).length,
    totalConflictMutexGroups: INTER_MODULE_CONFLICT_MATRIX.length,
    remainingMutableVariables: remainingMutableCount,
    failures,
    registryPath: IMMUTABLE_REGISTRY_PATH
  };
}

module.exports = {
  FROZEN_MODULE_COMPOSITIONS,
  FROZEN_COMPOSITE_MODULES: FROZEN_MODULE_COMPOSITIONS,
  INTER_MODULE_CONFLICT_MATRIX,
  CONFLICT_MUTEX_GROUPS: INTER_MODULE_CONFLICT_MATRIX,
  INTENTIONAL_SECURITY_CONTRACTS,
  normalizeToShortModuleId,
  computeModuleContractSeal,
  attemptMutateFrozenModule,
  composeNewModuleAdaptedToFrozenRegistry,
  evaluateInterlockMatrix,
  executeFrozenModulePipelineWithInterlock,
  evaluateInterlockForTargetModule,
  inspectAndCrystallizeAllCoreEngines,
  verifyFullSystemArchitecture: inspectAndCrystallizeAllCoreEngines
};
