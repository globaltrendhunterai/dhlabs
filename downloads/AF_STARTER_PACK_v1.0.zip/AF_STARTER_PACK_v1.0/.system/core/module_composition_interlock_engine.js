/**
 * core/module_composition_interlock_engine.js
 *
 * AutoFlow Engine-to-Module Composition, Immutable Crystallization &
 * Inter-Module Mutual Exclusion (Mutex Interlock) Engine (v1.0)
 *
 * [핵심 아키텍처 3대 원리]
 * 1. 모듈 = 엔진들의 조합 (Module as Deterministic Composition of Engines):
 *    - 개별 원자 엔진(core/*.js 센티널 및 코어 엔진 51종)들이 정해진 파이프라인 계약으로 결합되어
 *      하나의 모듈(MOD_A ~ MOD_Q, 17대 상용 모듈)을 형성한다.
 * 2. 모듈 고정화 및 단방향 엔진 적응 (Immutable Module Freezing & Forward Engine Adaptation):
 *    - 5대 불변 승격 조건(Gates C1~C5)을 통과해 하나의 모듈로 완성되면 그 모듈은 수정불가 고정값(FROZEN_CONSTANT)으로 봉인된다.
 *    - 이후 엔진이 새로운 모듈(예: 신규 조합 모듈)을 만들 때는 절대 기존 고정 모듈을 수정하지 않으며,
 *      기존 고정 모듈들의 입출력 계약과 인터락 규격에 맞춰 엔진 어댑터를 단방향 적응(One-Way Adaptation)시킨다.
 * 3. 모듈 간 충돌 경우의 수 그룹화 및 상호 배타 인터락을 통한 변수 소거 (Inter-Module Conflict Mutex & Variable Elimination):
 *    - 모듈끼리 동시에 작동할 때 발생할 수 있는 충돌 경우의 수를 6대 상호 배타 그룹(CONFLICT_GRP_01 ~ 06)으로 묶어,
 *      특정 우선순위 모듈(보류/격리/법적차단/압류방어 등)이 작동 중일 때는 충돌하는 다른 모듈(출고가속/자동재전송/가격인하/자동환불 등)이
 *      아예 작동하지 못하도록 원천 차단(INTERLOCKED_SUPPRESSED_BY_MUTEX)함으로써 조합 폭발 변수를 0으로 소거한다.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT_DIR = path.resolve(__dirname, '..');
const CORE_DIR = __dirname;
const IMMUTABLE_REGISTRY_PATH = path.join(CORE_DIR, 'immutable_anchor_registry.json');

// -----------------------------------------------------------------------------
// 1. 17대 상용 모듈 = 원자 엔진들의 결정론적 조합 (Composite Module Definitions)
// -----------------------------------------------------------------------------
const FROZEN_MODULE_COMPOSITIONS = Object.freeze({
  MOD_A: Object.freeze({
    moduleId: 'MOD_A',
    name: '127ms 무인 자가치유 에어백 모듈 (Self-Healing Airbag Module)',
    bitIndex: 0,
    bitmask: 1 << 0,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'symbiotic_self_healing_engine.js',
      'airbag_9_healing_matrix.js',
      'circuit_alert_sentinel.js',
      'error_harvester.js',
      'repair_notifier.js'
    ]),
    inputContract: Object.freeze(['errorCode', 'statusCode', 'nodeName', 'payload']),
    outputContract: Object.freeze(['status', 'healed', 'latencyMs', 'ruleId'])
  }),
  MOD_B: Object.freeze({
    moduleId: 'MOD_B',
    name: '1원 오차 정산 대사 & 사내 PC DLQ 안전 격리 모듈 (ReconFlow & DLQ Quarantine Module)',
    bitIndex: 1,
    bitmask: 1 << 1,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'settlement_recon_sentinel.js',
      'checkpoint_manager.js',
      'timeline_recorder.js',
      'repair_notifier.js'
    ]),
    inputContract: Object.freeze(['orderId', 'expectedAmount', 'settledAmount', 'feeRateOverride']),
    outputContract: Object.freeze(['status', 'reconciliationId', 'diffAmount', 'quarantined'])
  }),
  MOD_C: Object.freeze({
    moduleId: 'MOD_C',
    name: '15초 무인 감시 워치독 & 3초 자동 소생 모듈 (Watchdog & Instant Revival Module)',
    bitIndex: 2,
    bitmask: 1 << 2,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'process_watchdog_sentinel.js',
      'reboot_defense_matrix.js',
      'clock_skew_sentinel.js',
      'log_rotation_sentinel.js'
    ]),
    inputContract: Object.freeze(['pid', 'lastHeartbeatTs', 'memoryRssMb']),
    outputContract: Object.freeze(['status', 'alive', 'revivedWithinMs'])
  }),
  MOD_D: Object.freeze({
    moduleId: 'MOD_D',
    name: '분기 정족수 합의 & 다중 채널 장애우회 발송 모듈 (Branch Quorum & Failover Dispatch Module)',
    bitIndex: 3,
    bitmask: 1 << 3,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'workflow_topology_sentinel.js',
      'notification_failover_sentinel.js',
      'auto_retry_dispatch_sentinel.js',
      'daily_digest_sentinel.js'
    ]),
    inputContract: Object.freeze(['orderId', 'branches', 'quorumThreshold', 'channel']),
    outputContract: Object.freeze(['status', 'quorumReached', 'dispatched'])
  }),
  MOD_E: Object.freeze({
    moduleId: 'MOD_E',
    name: 'PII 개인정보 무결점 마스킹 & BYOK 프라이버시 모듈 (PII Masking & BYOK Privacy Module)',
    bitIndex: 4,
    bitmask: 1 << 4,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'pii_masking_sentinel.js',
      'byok_privacy_sentinel.js',
      'error_harvester.js'
    ]),
    inputContract: Object.freeze(['rawText', 'payload', 'apiKey']),
    outputContract: Object.freeze(['status', 'sanitizedText', 'piiMaskedCount'])
  }),
  MOD_F: Object.freeze({
    moduleId: 'MOD_F',
    name: '주문 멱등성 해시 가드 & 합배송·송장 검증 모듈 (Idempotency Dedup & Combined Shipping Module)',
    bitIndex: 5,
    bitmask: 1 << 5,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'order_dedup_sentinel.js',
      'combined_shipping_sentinel.js',
      'delivery_notes_sentinel.js',
      'tracking_validation_sentinel.js'
    ]),
    inputContract: Object.freeze(['orderId', 'receiverName', 'receiverAddress', 'invoiceNumber']),
    outputContract: Object.freeze(['status', 'isDuplicate', 'combinedGroupKey', 'invoiceValid'])
  }),
  MOD_G: Object.freeze({
    moduleId: 'MOD_G',
    name: '동적 노드 컨트롤러 & 102종 공식 노드 실시간 제어 모듈 (Dynamic Node Controller Module)',
    bitIndex: 6,
    bitmask: 1 << 6,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'workflow_topology_sentinel.js',
      'node_discovery_sentinel.js',
      'region_profile_sentinel.js'
    ]),
    inputContract: Object.freeze(['workflowId', 'nodeType', 'region', 'platform']),
    outputContract: Object.freeze(['status', 'activeScope', 'supportedNodeCount'])
  }),
  MOD_H: Object.freeze({
    moduleId: 'MOD_H',
    name: 'DriftFlow 외부 API 스키마 드리프트 18대 자동 변환 브릿지 모듈 (DriftFlow Schema Bridge Module)',
    bitIndex: 7,
    bitmask: 1 << 7,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'workflow_topology_sentinel.js',
      'symbiotic_self_healing_engine.js',
      'v8_non_lang_defender.js'
    ]),
    inputContract: Object.freeze(['rawPayload', 'sourcePlatform', 'schemaVersion']),
    outputContract: Object.freeze(['status', 'normalizedPayload', 'bridgedFields'])
  }),
  MOD_I: Object.freeze({
    moduleId: 'MOD_I',
    name: 'AES-256-GCM 볼트 엔클레이브 & 역공학 차단 보안 모듈 (Vault Enclave & Tamper Guard Module)',
    bitIndex: 8,
    bitmask: 1 << 8,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'workflow_vault.js',
      'tamper_guard.js',
      'telemetry_beacon.js',
      'telemetry_sentinel.js'
    ]),
    inputContract: Object.freeze(['hwid', 'envelope', 'argv']),
    outputContract: Object.freeze(['status', 'verified', 'cipher'])
  }),
  MOD_J: Object.freeze({
    moduleId: 'MOD_J',
    name: '국세청 홈택스 전자세금계산서·부가세 크로스체크 세무 방어 모듈 (HomeTax & VAT Sentinel Module)',
    bitIndex: 9,
    bitmask: 1 << 9,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'hometax_crosscheck_sentinel.js',
      'vat_sales_sentinel.js'
    ]),
    inputContract: Object.freeze(['settlementMonth', 'orders', 'taxInvoices']),
    outputContract: Object.freeze(['status', 'vatBreakdown', 'penaltySavedWon'])
  }),
  MOD_K: Object.freeze({
    moduleId: 'MOD_K',
    name: '부정결제 FDS 사기 탐지·역마진·품절·통관오류 즉시 출고보류 모듈 (Risk Hold & Freeze Module)',
    bitIndex: 10,
    bitmask: 1 << 10,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'fraud_detection_sentinel.js',
      'negative_margin_sentinel.js',
      'stockout_hold_sentinel.js',
      'stop_shipment_sentinel.js',
      'pccc_validation_sentinel.js'
    ]),
    inputContract: Object.freeze(['orderId', 'totalAmount', 'costPrice', 'pcccCode', 'stock']),
    outputContract: Object.freeze(['status', 'shipmentHold', 'riskLevel', 'holdReason'])
  }),
  MOD_L: Object.freeze({
    moduleId: 'MOD_L',
    name: '로켓그로스 입고검품·아이템위너·택배 허브/배송사고 물류 가속 모듈 (Logistics & Winner Module)',
    bitIndex: 11,
    bitmask: 1 << 11,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'inbound_barcode_sentinel.js',
      'item_winner_sentinel.js',
      'hub_stagnation_sentinel.js',
      'shipping_accident_sentinel.js',
      'dispatch_deadline_sentinel.js',
      'island_surcharge_sentinel.js'
    ]),
    inputContract: Object.freeze(['skuId', 'barcode', 'carrierCode', 'myPrice', 'competitorPrice']),
    outputContract: Object.freeze(['status', 'isWinner', 'dispatchAction'])
  }),
  MOD_M: Object.freeze({
    moduleId: 'MOD_M',
    name: '상표권·지식재산권(IP) 침해 사전 감별 & 공식 소명 증적 모듈 (Trademark & IP Defense Module)',
    bitIndex: 12,
    bitmask: 1 << 12,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'trademark_ip_sentinel.js',
      'product_notice_sentinel.js',
      'dispute_evidence_sentinel.js'
    ]),
    inputContract: Object.freeze(['productName', 'sellerBrand', 'keywords', 'category']),
    outputContract: Object.freeze(['status', 'verdict', 'riskLevel', 'penaltySavedWon'])
  }),
  MOD_N: Object.freeze({
    moduleId: 'MOD_N',
    name: '식약처·환경부 위해식품·해외직구 금지성분 1초 스크리닝 모듈 (Hazardous Substance Sentinel Module)',
    bitIndex: 13,
    bitmask: 1 << 13,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'hazardous_substance_sentinel.js',
      'product_notice_sentinel.js',
      'pccc_validation_sentinel.js'
    ]),
    inputContract: Object.freeze(['productName', 'ingredientsText', 'originCountry']),
    outputContract: Object.freeze(['status', 'verdict', 'matchedSubstances', 'quarantineRequired'])
  }),
  MOD_O: Object.freeze({
    moduleId: 'MOD_O',
    name: '공정위 소비자분쟁 감가상각·악성 체리피커·반품 미회수 방어 모듈 (Consumer Dispute & Cherrypicker Defense Module)',
    bitIndex: 14,
    bitmask: 1 << 14,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'consumer_dispute_sentinel.js',
      'return_pickup_sentinel.js',
      'customer_inquiry_sentinel.js',
      'review_booster_sentinel.js',
      'dispute_evidence_sentinel.js'
    ]),
    inputContract: Object.freeze(['orderId', 'categoryCode', 'purchaseAmount', 'purchaseDate', 'claimDate']),
    outputContract: Object.freeze(['status', 'verdict', 'residualValueWon', 'defendedAmountWon'])
  }),
  MOD_P: Object.freeze({
    moduleId: 'MOD_P',
    name: '쿠팡 밀크런·로켓배송 파레트 과적·적재규격(1.6m/500kg) 방어 모듈 (Milkrun Pallet Guard Module)',
    bitIndex: 15,
    bitmask: 1 << 15,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'milkrun_pallet_sentinel.js',
      'inbound_barcode_sentinel.js',
      'dispatch_deadline_sentinel.js'
    ]),
    inputContract: Object.freeze(['palletId', 'tiers', 'boxHeightCm', 'boxWeightKg']),
    outputContract: Object.freeze(['status', 'verdict', 'totalHeightM', 'totalWeightKg', 'overloadBlocked'])
  }),
  MOD_Q: Object.freeze({
    moduleId: 'MOD_Q',
    name: '오픈마켓 정산금 압류·가압류 진단 & 민사집행법 제246조 최저생계비(185만 원) 소명 모듈 (Seizure Defense Module)',
    bitIndex: 16,
    bitmask: 1 << 16,
    frozen: true,
    mutable: false,
    engineChain: Object.freeze([
      'seizure_defense_sentinel.js',
      'settlement_recon_sentinel.js',
      'dispute_evidence_sentinel.js'
    ]),
    inputContract: Object.freeze(['sellerName', 'seizedAmount', 'monthlyLivingExpense', 'marketplace']),
    outputContract: Object.freeze(['status', 'verdict', 'protectedMinimumWon', 'defendedAmount'])
  })
});

// -----------------------------------------------------------------------------
// 2. 모듈 간 충돌 경우의 수 6대 상호 배타 인터락 그룹 (Inter-Module Conflict Mutex Matrix)
//    특정 우선순위 모듈(dominantModule)이 활성 작동 중일 때, 충돌하는 모듈(suppressedModules)의
//    작동을 하드웨어/소프트웨어 인터락으로 원천 차단하여 충돌 변수를 0으로 소거한다.
// -----------------------------------------------------------------------------
const INTER_MODULE_CONFLICT_MATRIX = Object.freeze([
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_01_HOLD_VS_DISPATCH',
    name: '출고 강제 보류(MOD_K) 작동 시 자동 출고/재전송 가속(MOD_D, MOD_L) 작동 원천 차단',
    dominantModule: 'MOD_K',
    triggerConditionKey: 'shipmentHoldActive',
    suppressedModules: Object.freeze(['MOD_D', 'MOD_L']),
    rationale: '부정결제·역마진·품절·통관오류로 출고 보류(MOD_K)가 발동된 주문에 대해 자동 재전송(MOD_D)이나 물류 출고 가속(MOD_L)이 동시에 작동하면 위험 주문이 오발송되므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_02_RECON_QUARANTINE_VS_AUTO_MUTATION',
    name: '정산 1원 오차 DLQ 격리(MOD_B) 작동 시 무인 자동 재전송/스키마 강제변환(MOD_A, MOD_H) 작동 원천 차단',
    dominantModule: 'MOD_B',
    triggerConditionKey: 'reconQuarantineActive',
    suppressedModules: Object.freeze(['MOD_A', 'MOD_H']),
    rationale: '장부 1원 오차로 사내 PC DLQ에 안전 격리(MOD_B)된 결제/정산 건에 대해 무인 자가치유 재시도(MOD_A)나 스키마 변형 브릿지(MOD_H)가 개입하면 이중 결제 및 원장 훼손 변수가 발생하므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_03_LEGAL_HAZARD_VS_PROMOTION_BOOST',
    name: '상표권·금지성분 법적 위반 격리(MOD_M, MOD_N) 작동 시 가격 경쟁/노출 가속(MOD_L) 작동 원천 차단',
    dominantModule: 'MOD_M',
    secondaryDominantModule: 'MOD_N',
    triggerConditionKey: 'legalComplianceHoldActive',
    suppressedModules: Object.freeze(['MOD_L']),
    rationale: '상표권 침해(MOD_M) 또는 식약처 위해성분(MOD_N)이 감지된 상품에 대해 아이템위너 1원 인하 노출 가속(MOD_L)이 작동하면 법적 가중 처벌 리스크가 발생하므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_04_SEIZURE_EMERGENCY_VS_ROUTINE_TAX_CLOSE',
    name: '정산금 압류/가압류 비상 방어(MOD_Q) 작동 시 일반 세무/정산 자동 마감(MOD_J) 작동 원천 차단',
    dominantModule: 'MOD_Q',
    triggerConditionKey: 'seizureEmergencyActive',
    suppressedModules: Object.freeze(['MOD_J']),
    rationale: '정산금 압류 방어 및 최저생계비 185만 원 압류금지 채권 소명(MOD_Q) 진행 중 일반 세무 정산 자동 확정(MOD_J)이 동시에 작동하면 소명 기준 금액이 변이되므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_05_PALLET_OVERLOAD_VS_COMBINED_PACKING',
    name: '밀크런 파레트 1.6m/500kg 과적 차단(MOD_P) 작동 시 합배송 추가 적재/송장 확정(MOD_F) 작동 원천 차단',
    dominantModule: 'MOD_P',
    triggerConditionKey: 'palletOverloadActive',
    suppressedModules: Object.freeze(['MOD_F']),
    rationale: '파레트 적재규격 초과(MOD_P)가 감지된 상태에서 합배송 묶음 포장(MOD_F)이 추가 적재를 시도하면 물류센터 입차 거부(회차비 35만 원)가 발생하므로 상호 배타 차단함.'
  }),
  Object.freeze({
    conflictGroupId: 'CONFLICT_GRP_06_CHERRYPICKER_DEFENSE_VS_AUTO_CANCEL_HOLD',
    name: '공정위 감가상각·악성 반품 방어(MOD_O) 작동 시 착오취소/즉시 전액환불(MOD_K) 작동 원천 차단',
    dominantModule: 'MOD_O',
    triggerConditionKey: 'cherrypickerDefenseActive',
    suppressedModules: Object.freeze(['MOD_K']),
    rationale: '악성 체리피커 감가상각 공제 또는 반품 장기 미회수 방어(MOD_O)가 진행 중인 클레임에 대해 착오취소 전액 환불(MOD_K)이 동시에 작동하면 공제 방어선이 무너지므로 상호 배타 차단함.'
  })
]);

// 의도된 보안 계약 예외 (고정된 보안 불변식: 잘못된 키/파일/서명 시 예외를 던지는 것이 정상 계약인 함수들)
const INTENTIONAL_SECURITY_CONTRACTS = Object.freeze({
  'workflow_vault.js': Object.freeze([
    'deriveHwidKey',
    'encryptWorkflow',
    'decryptWorkflow',
    'encryptWorkflowFile',
    'loadEncryptedWorkflow'
  ]),
  'tamper_guard.js': Object.freeze(['computeFileHash']),
  'telemetry_beacon.js': Object.freeze(['verifyPatchSignature']),
  'region_profile_sentinel.js': Object.freeze(['switchProfile'])
});

// -----------------------------------------------------------------------------
// 3. 헬퍼: 모듈 시그니처 해시 계산 (Cryptographic Freeze Seal)
// -----------------------------------------------------------------------------
function computeModuleContractSeal(moduleSpec) {
  const safe = (moduleSpec && typeof moduleSpec === 'object') ? moduleSpec : {};
  const canonical = JSON.stringify({
    moduleId: String(safe.moduleId || ''),
    bitIndex: Number(safe.bitIndex ?? -1),
    engineChain: Array.isArray(safe.engineChain) ? safe.engineChain : [],
    inputContract: Array.isArray(safe.inputContract) ? safe.inputContract : [],
    outputContract: Array.isArray(safe.outputContract) ? safe.outputContract : [],
    frozen: Boolean(safe.frozen)
  });
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

// -----------------------------------------------------------------------------
// 4. 고정 모듈 수정 차단 가드 (Immutable Module Protection Guard)
// -----------------------------------------------------------------------------
function attemptMutateFrozenModule(moduleId, attemptedPatch = {}) {
  const id = String(moduleId || '').trim().toUpperCase();
  const target = FROZEN_MODULE_COMPOSITIONS[id];
  if (target && target.frozen === true) {
    return {
      ok: false,
      mutated: false,
      status: 'BLOCKED_FROZEN_MODULE_IMMUTABLE',
      moduleId: id,
      reason: `모듈 [${id}]은(는) 5대 불변 승격 조건을 통과하여 수정불가 고정값(FROZEN_CONSTANT)으로 봉인되었습니다. 엔진이나 신규 모듈이 이 고정 모듈에 맞춰 단방향 적응해야 합니다.`,
      attemptedPatchSummary: Object.keys((attemptedPatch && typeof attemptedPatch === 'object') ? attemptedPatch : {})
    };
  }
  return {
    ok: false,
    mutated: false,
    status: 'UNKNOWN_MODULE',
    moduleId: id
  };
}

// -----------------------------------------------------------------------------
// 5. 신규 모듈 생성 시 기존 고정 모듈에 맞춘 엔진 단방향 적응 (Forward Engine Adaptation)
// -----------------------------------------------------------------------------
const customAdaptedModulesRegistry = new Map();

function composeNewModuleAdaptedToFrozenRegistry(newModuleSpec = {}) {
  const spec = (newModuleSpec && typeof newModuleSpec === 'object' && !Array.isArray(newModuleSpec))
    ? newModuleSpec
    : {};
  const moduleId = String(spec.moduleId || 'MOD_CUSTOM_DEFAULT').trim().toUpperCase();

  // 1) 기존 고정 모듈(MOD_A ~ MOD_Q)의 ID를 덮어쓰려는 시도는 즉시 차단
  if (FROZEN_MODULE_COMPOSITIONS[moduleId]) {
    return attemptMutateFrozenModule(moduleId, spec);
  }

  // 2) 참조하는 기존 고정 모듈들의 입출력 계약을 읽어와 엔진 어댑터를 단방향 맞춤 구성
  const upstreamFrozenIds = Array.isArray(spec.dependsOnFrozenModules)
    ? spec.dependsOnFrozenModules.filter((id) => Boolean(FROZEN_MODULE_COMPOSITIONS[String(id || '').toUpperCase()]))
    : ['MOD_A', 'MOD_B'];

  const adaptedInputKeys = new Set(Array.isArray(spec.inputContract) ? spec.inputContract : []);
  const adaptedOutputKeys = new Set(['status', 'moduleId', 'adaptedToFrozenModules']);
  if (Array.isArray(spec.outputContract)) {
    for (const k of spec.outputContract) adaptedOutputKeys.add(String(k));
  }

  const frozenContractSeals = {};
  for (const fid of upstreamFrozenIds) {
    const frozenMod = FROZEN_MODULE_COMPOSITIONS[fid];
    if (!frozenMod) continue;
    frozenContractSeals[fid] = computeModuleContractSeal(frozenMod);
    for (const outKey of frozenMod.outputContract) {
      adaptedInputKeys.add(outKey);
    }
  }

  const engineChain = Array.isArray(spec.engineChain) && spec.engineChain.length > 0
    ? spec.engineChain.filter((e) => typeof e === 'string' && fs.existsSync(path.join(CORE_DIR, e)))
    : ['workflow_topology_sentinel.js'];

  const crystallizedModule = Object.freeze({
    moduleId,
    name: String(spec.name || `Adapted Composite Module (${moduleId})`),
    frozen: true,
    mutable: false,
    adaptedFromFrozenModules: Object.freeze([...upstreamFrozenIds]),
    frozenParentSeals: Object.freeze(frozenContractSeals),
    engineChain: Object.freeze([...engineChain]),
    engines: Object.freeze([...engineChain]),
    inputContract: Object.freeze([...adaptedInputKeys]),
    outputContract: Object.freeze([...adaptedOutputKeys]),
    executeAdapted(rawPayload = {}, activeContext = {}) {
      const safePayload = (rawPayload && typeof rawPayload === 'object' && !Array.isArray(rawPayload))
        ? rawPayload
        : {};
      const interlockCheck = evaluateInterlockForTargetModule(
        moduleId,
        activeContext,
        spec.mutexWithFrozenModules || []
      );
      if (interlockCheck.blocked) {
        return interlockCheck;
      }
      const normalizedInput = {};
      for (const key of adaptedInputKeys) {
        normalizedInput[key] = safePayload[key] !== undefined ? safePayload[key] : null;
      }
      return {
        ok: true,
        executed: true,
        status: 'EXECUTED_WITH_FROZEN_ADAPTATION',
        moduleId,
        adaptedToFrozenModules: upstreamFrozenIds,
        existingFrozenModulesMutated: false,
        normalizedInput
      };
    }
  });

  customAdaptedModulesRegistry.set(moduleId, crystallizedModule);
  return {
    ok: true,
    status: 'CRYSTALLIZED_NEW_ADAPTED_MODULE',
    moduleId,
    existingFrozenModulesMutated: false,
    adaptedToFrozenModules: upstreamFrozenIds,
    contractSeal: computeModuleContractSeal(crystallizedModule),
    engineChain: crystallizedModule.engineChain,
    engines: crystallizedModule.engineChain,
    module: crystallizedModule
  };
}

// -----------------------------------------------------------------------------
// 6. 모듈 간 충돌 경우의 수 상호 배타 인터락 실행기 (Mutual Exclusion Variable Elimination)
// -----------------------------------------------------------------------------
function normalizeToShortModuleId(rawId) {
  const s = String(rawId || '').trim().toUpperCase();
  const m = s.match(/^(MOD_[A-Z])\d*(?:_|$)/);
  return m ? m[1] : s;
}

function evaluateInterlockMatrix(requestedModules = [], contextFlags = {}) {
  const rawMods = Array.isArray(requestedModules)
    ? requestedModules.map((m) => String(m || '').trim().toUpperCase()).filter(Boolean)
    : [];
  const mods = [...new Set(rawMods.map(normalizeToShortModuleId))];
  const flags = (contextFlags && typeof contextFlags === 'object' && !Array.isArray(contextFlags))
    ? contextFlags
    : {};

  const activeSet = new Set(mods);
  const suppressedMap = new Map();
  const triggeredConflictGroups = [];

  for (const rule of INTER_MODULE_CONFLICT_MATRIX) {
    const dominantPresent = activeSet.has(rule.dominantModule) ||
      (rule.secondaryDominantModule && activeSet.has(rule.secondaryDominantModule)) ||
      Boolean(flags[rule.triggerConditionKey]);

    if (!dominantPresent) continue;

    const holder = activeSet.has(rule.dominantModule)
      ? rule.dominantModule
      : (rule.secondaryDominantModule && activeSet.has(rule.secondaryDominantModule)
        ? rule.secondaryDominantModule
        : rule.dominantModule);

    const blockedInThisGroup = [];
    for (const targetMod of rule.suppressedModules) {
      if (activeSet.has(targetMod)) {
        activeSet.delete(targetMod);
        suppressedMap.set(targetMod, {
          suppressedModule: targetMod,
          suppressedBy: holder,
          blockedByModule: holder,
          groupId: rule.conflictGroupId,
          conflictGroupId: rule.conflictGroupId,
          reason: rule.rationale,
          variableEliminated: true
        });
        blockedInThisGroup.push(targetMod);
      }
    }

    if (blockedInThisGroup.length > 0 || Boolean(flags[rule.triggerConditionKey])) {
      triggeredConflictGroups.push({
        groupId: rule.conflictGroupId,
        conflictGroupId: rule.conflictGroupId,
        dominantModule: holder,
        suppressedModules: blockedInThisGroup.length > 0 ? blockedInThisGroup : [...rule.suppressedModules],
        variableEliminated: true
      });
    }
  }

  return {
    ok: true,
    requestedModules: mods,
    allowedActiveModules: [...activeSet],
    executedModules: [...activeSet],
    suppressedModules: [...suppressedMap.keys()],
    suppressedSet: new Set(suppressedMap.keys()),
    suppressedByMap: suppressedMap,
    suppressedDetails: [...suppressedMap.values()],
    decisions: triggeredConflictGroups,
    triggeredConflictGroups,
    conflictVariablesRemaining: 0
  };
}

function executeFrozenModulePipelineWithInterlock(requestedModules = [], contextPayload = {}) {
  const safePayload = (contextPayload && typeof contextPayload === 'object' && !Array.isArray(contextPayload))
    ? contextPayload
    : {};
  const defaultMods = Array.isArray(requestedModules) && requestedModules.length > 0
    ? requestedModules
    : Object.keys(FROZEN_MODULE_COMPOSITIONS);
  const interlock = evaluateInterlockMatrix(defaultMods, safePayload);

  let runtimePipelineResult = null;
  try {
    const topologySentinel = require('./workflow_topology_sentinel');
    runtimePipelineResult = topologySentinel.executeModularEnginePipeline(
      {
        payload: safePayload,
        enforceInterlock: true,
        requestedInterlockModules: defaultMods
      },
      {
        activeBitmask: 262143,
        enforceInterlock: true,
        requestedInterlockModules: defaultMods
      }
    );
  } catch (_) {}

  return {
    ok: true,
    conflictVariablesRemaining: 0,
    requestedModules: interlock.requestedModules,
    allowedActiveModules: interlock.allowedActiveModules,
    executedModules: interlock.allowedActiveModules,
    suppressedModules: interlock.suppressedModules,
    suppressedDetails: interlock.suppressedDetails,
    triggeredConflictGroups: interlock.triggeredConflictGroups,
    runtimePipelineResult
  };
}

function evaluateInterlockForTargetModule(targetModuleId, activeContext = {}, customMutexList = []) {
  const target = normalizeToShortModuleId(targetModuleId);
  const ctx = (activeContext && typeof activeContext === 'object' && !Array.isArray(activeContext))
    ? activeContext
    : {};
  const activeMods = Array.isArray(ctx.activeModules)
    ? ctx.activeModules.map(normalizeToShortModuleId)
    : [];

  const matrixResult = evaluateInterlockMatrix(
    [...new Set([...activeMods, target])],
    ctx
  );

  const suppression = matrixResult.suppressedDetails.find((d) => d.suppressedModule === target);
  if (suppression) {
    return {
      ok: true,
      executed: false,
      blocked: true,
      status: 'INTERLOCKED_SUPPRESSED_BY_MUTEX',
      targetModule: target,
      blockedByModule: suppression.blockedByModule,
      conflictGroupId: suppression.conflictGroupId,
      reason: suppression.reason,
      variableEliminated: true
    };
  }

  if (Array.isArray(customMutexList)) {
    for (const m of customMutexList) {
      const mUpper = normalizeToShortModuleId(m);
      if (activeMods.includes(mUpper)) {
        return {
          ok: true,
          executed: false,
          blocked: true,
          status: 'INTERLOCKED_SUPPRESSED_BY_MUTEX',
          targetModule: target,
          blockedByModule: mUpper,
          conflictGroupId: 'CUSTOM_MODULE_MUTEX_INTERLOCK',
          reason: `활성 모듈 [${mUpper}]과의 상호 배타 인터락 규칙에 의해 [${target}] 작동이 차단되었습니다.`,
          variableEliminated: true
        };
      }
    }
  }

  return {
    ok: true,
    executed: true,
    blocked: false,
    status: 'ALLOWED_NO_CONFLICT',
    targetModule: target,
    variableEliminated: true
  };
}

// -----------------------------------------------------------------------------
// 7. 기존 51개 코어 엔진 전수 검사 및 수정불가 고정값(Immutable Anchor) 결정화
// -----------------------------------------------------------------------------
function inspectAndCrystallizeAllCoreEngines() {
  const coreFiles = fs.readdirSync(CORE_DIR).filter((f) =>
    f.endsWith('.js') &&
    !f.includes('cli') &&
    !f.includes('refactor_phase3') &&
    !f.includes('v8_native_combat_runner') &&
    !f.includes('autoflow_sidecar_daemon') &&
    !f.includes('watchdog') &&
    !f.includes('ten_pass_detail_auditor') &&
    !f.includes('module_composition_interlock_engine')
  ).sort();

  const engineResults = [];
  const failures = [];
  let totalMethodsVerified = 0;

  // Snapshot config/, rules/, and core/license_state.json to guarantee zero disk side-effects
  const rootDir = path.join(CORE_DIR, '..');
  const snapshotDirs = [path.join(rootDir, 'config'), path.join(rootDir, 'rules')];
  const fileSnapshots = new Map();
  for (const dir of snapshotDirs) {
    if (fs.existsSync(dir)) {
      for (const f of fs.readdirSync(dir)) {
        if (f.endsWith('.json')) {
          const fp = path.join(dir, f);
          try {
            if (fs.statSync(fp).isFile()) {
              fileSnapshots.set(fp, fs.readFileSync(fp, 'utf8'));
            }
          } catch (_) {}
        }
      }
    }
  }
  const coreLicensePath = path.join(CORE_DIR, 'license_state.json');
  const coreLicenseExistedBefore = fs.existsSync(coreLicensePath);
  if (coreLicenseExistedBefore) {
    try {
      fileSnapshots.set(coreLicensePath, fs.readFileSync(coreLicensePath, 'utf8'));
    } catch (_) {}
  }

  const SIDE_EFFECT_SKIP_REGEX = /^(start|stop|listen|spawn|kill|delete|clear|wipe|reset|runDaemon|watch|poll|save|record|append|persist|stage|publish|executeMaster|execute|deploy|lock|trigger|configure|updateConfig|setActiveProfile|rotateLogs|triggerIncident|triggerBlackbox|flushIncidentCapsule|apply|revoke|markDefect|markPending|activate|extend|upgradeTier|issue|register|sync|regulate|drain|commit|rollback)/i;

  try {
    for (const file of coreFiles) {
      const fullPath = path.join(CORE_DIR, file);
      const fileSha256 = crypto.createHash('sha256').update(fs.readFileSync(fullPath)).digest('hex');
      let mod;
      try {
        mod = require(fullPath);
      } catch (e) {
        failures.push({ file, stage: 'require', error: e.message });
        continue;
      }

      const intentionalSet = new Set(INTENTIONAL_SECURITY_CONTRACTS[file] || []);
      const targets = [];
      if (typeof mod === 'function') {
        targets.push({ name: file, ClsOrFn: mod, fnName: file });
      } else if (mod && typeof mod === 'object') {
        for (const [k, v] of Object.entries(mod)) {
          if (typeof v === 'function') {
            targets.push({ name: `${file}:${k}`, ClsOrFn: v, fnName: k });
          }
        }
      }

      let fileMethodCount = 0;
      let filePassed = true;

      for (const t of targets) {
        const isClass = /^class\s/.test(Function.prototype.toString.call(t.ClsOrFn)) ||
          (t.ClsOrFn.prototype && Object.getOwnPropertyNames(t.ClsOrFn.prototype).length > 1);

        if (isClass) {
          let inst;
          try {
            inst = new t.ClsOrFn();
          } catch (e) {
            filePassed = false;
            failures.push({ file, target: t.name, stage: 'new()', error: e.message });
            continue;
          }
          const protoMethods = Object.getOwnPropertyNames(t.ClsOrFn.prototype)
            .filter((m) => m !== 'constructor' && !m.startsWith('_') && typeof inst[m] === 'function');

          for (const m of protoMethods) {
            if (SIDE_EFFECT_SKIP_REGEX.test(m)) {
              continue;
            }
            if (intentionalSet.has(m)) {
              totalMethodsVerified++;
              fileMethodCount++;
              continue;
            }
            totalMethodsVerified++;
            fileMethodCount++;
            for (const arg of [undefined, null, {}]) {
              try {
                const res = inst[m](arg);
                if (res && typeof res.catch === 'function') res.catch(() => {});
              } catch (e) {
                filePassed = false;
                failures.push({ file, target: `${t.name}.${m}`, arg: String(arg), error: e.message });
                break;
              }
            }
          }
        } else {
          if (t.fnName.startsWith('_') || SIDE_EFFECT_SKIP_REGEX.test(t.fnName)) {
            continue;
          }
          if (intentionalSet.has(t.fnName)) {
            totalMethodsVerified++;
            fileMethodCount++;
            continue;
          }
          totalMethodsVerified++;
          fileMethodCount++;
          for (const arg of [undefined, null, {}]) {
            try {
              const res = t.ClsOrFn(arg);
              if (res && typeof res.catch === 'function') res.catch(() => {});
            } catch (e) {
              filePassed = false;
              failures.push({ file, target: t.name, arg: String(arg), error: e.message });
              break;
            }
          }
        }
      }

      engineResults.push({
        engineFile: file,
        sha256: fileSha256,
        methodsVerified: fileMethodCount,
        crystallized: filePassed,
        mutable: !filePassed,
        locked: filePassed,
        status: filePassed ? 'SEALED_CONSTANT' : 'MUTABLE_VARIABLE_NEEDS_FIX'
      });
    }
  } finally {
    for (const [fp, content] of fileSnapshots.entries()) {
      try {
        const current = fs.existsSync(fp) ? fs.readFileSync(fp, 'utf8') : null;
        if (current !== content) {
          fs.writeFileSync(fp, content, 'utf8');
        }
      } catch (_) {}
    }
    if (!coreLicenseExistedBefore && fs.existsSync(coreLicensePath)) {
      try {
        fs.unlinkSync(coreLicensePath);
      } catch (_) {}
    }
    try {
      const licMod = require('./license_manager');
      if (typeof licMod.resetMasterNoticeAndStoreGateState === 'function') {
        licMod.resetMasterNoticeAndStoreGateState();
      }
      if (typeof licMod.clearDynamicMcpModules === 'function') {
        licMod.clearDynamicMcpModules();
      }
    } catch (_) {}
  }

  // 17대 복합 모듈 봉인 검증
  const moduleSeals = {};
  for (const [modId, modSpec] of Object.entries(FROZEN_MODULE_COMPOSITIONS)) {
    const missingEngines = modSpec.engineChain.filter((e) => !fs.existsSync(path.join(CORE_DIR, e)));
    if (missingEngines.length > 0) {
      failures.push({ moduleId: modId, stage: 'engineChain', error: `Missing engines: ${missingEngines.join(', ')}` });
    }
    moduleSeals[modId] = {
      moduleId: modId,
      name: modSpec.name,
      engineCount: modSpec.engineChain.length,
      engineChain: modSpec.engineChain,
      frozen: true,
      mutable: false,
      contractSeal: computeModuleContractSeal(modSpec)
    };
  }

  const remainingMutableCount = engineResults.filter((r) => r.mutable).length + (failures.length > 0 ? 1 : 0);

  let existingUpdatedAt = null;
  let existingCanonical = null;
  try {
    if (fs.existsSync(IMMUTABLE_REGISTRY_PATH)) {
      const existingRaw = JSON.parse(fs.readFileSync(IMMUTABLE_REGISTRY_PATH, 'utf8'));
      if (existingRaw && typeof existingRaw.updatedAt === 'string') {
        existingUpdatedAt = existingRaw.updatedAt;
        const clone = Object.assign({}, existingRaw, { updatedAt: '__CANONICAL__' });
        existingCanonical = JSON.stringify(clone);
      }
    }
  } catch (_) {}

  const registryPayload = {
    schemaVersion: '1.0.0',
    architecture: 'ENGINE_COMPOSITION_IMMUTABLE_MODULE_AND_MUTEX_INTERLOCK',
    updatedAt: existingUpdatedAt || new Date().toISOString(),
    convergenceSummary: {
      totalCoreEnginesInspected: engineResults.length,
      totalEngineMethodsVerified: totalMethodsVerified,
      totalCompositeModulesFrozen: Object.keys(moduleSeals).length,
      totalConflictMutexGroups: INTER_MODULE_CONFLICT_MATRIX.length,
      crystallizedConstantsCount: engineResults.filter((r) => r.crystallized).length + Object.keys(moduleSeals).length,
      remainingMutableVariables: remainingMutableCount,
      converged: remainingMutableCount === 0 && failures.length === 0
    },
    frozenCompositeModules: moduleSeals,
    interModuleConflictMutexMatrix: INTER_MODULE_CONFLICT_MATRIX,
    crystallizedCoreEngines: engineResults
  };

  try {
    const nextCanonical = JSON.stringify(Object.assign({}, registryPayload, { updatedAt: '__CANONICAL__' }));
    if (existingCanonical !== nextCanonical) {
      registryPayload.updatedAt = new Date().toISOString();
      fs.writeFileSync(IMMUTABLE_REGISTRY_PATH, JSON.stringify(registryPayload, null, 2), 'utf8');
    }
  } catch (_) {}

  return {
    passed: failures.length === 0 && remainingMutableCount === 0,
    totalCoreEnginesInspected: engineResults.length,
    totalEngineMethodsVerified: totalMethodsVerified,
    totalCompositeModulesFrozen: Object.keys(moduleSeals).length,
    totalConflictMutexGroups: INTER_MODULE_CONFLICT_MATRIX.length,
    remainingMutableVariables: remainingMutableCount,
    failures,
    registryPath: IMMUTABLE_REGISTRY_PATH
  };
}

// -----------------------------------------------------------------------------
// 8. 4대 도메인(틀 1: 쇼핑몰 / 틀 2: CS / 틀 3: 백오피스 / 틀 4: 마케팅·영업) 전용 어댑터 팩
//    기존 고정 모듈(MOD_A ~ MOD_Q)을 수정하지 않고 단방향 적응(composeNewModuleAdaptedToFrozenRegistry)으로 결합
// -----------------------------------------------------------------------------
const _csDomainPack = composeNewModuleAdaptedToFrozenRegistry({
  moduleId: 'MOD_CS_DOMAIN',
  name: '틀 2: AI 고객응대(CS) 전용 정합성·도배차단·위기브레이크·자가치유 엔진 팩',
  dependsOnFrozenModules: ['MOD_A', 'MOD_E'],
  mutexWithFrozenModules: ['MOD_O'],
  engineChain: [
    'cs_domain_integrity_sentinel.js',
    'pii_masking_sentinel.js',
    'symbiotic_self_healing_engine.js'
  ],
  inputContract: ['inquiryText', 'draftText', 'rawAiResponse', 'customerId', 'customerName'],
  outputContract: ['healedDraft', 'autoReplyBlocked', 'escalateToHuman', 'violations']
});
const _boDomainPack = composeNewModuleAdaptedToFrozenRegistry({
  moduleId: 'MOD_BO_DOMAIN',
  name: '틀 3: 사내 백오피스(영수증·계약서·인사권한·서버감시) 전용 정합성·자가치유 엔진 팩',
  dependsOnFrozenModules: ['MOD_A', 'MOD_C', 'MOD_E'],
  mutexWithFrozenModules: ['MOD_J'],
  engineChain: [
    'backoffice_domain_integrity_sentinel.js',
    'pii_masking_sentinel.js',
    'process_watchdog_sentinel.js',
    'safety_governor_spool_engine.js',
    'cyber_deception_tarpit_sentinel.js'
  ],
  inputContract: ['merchantName', 'approvalNumber', 'totalAmount', 'contractText', 'eventType'],
  outputContract: ['allowedToBook', 'healedTaxBreakdown', 'amountMismatchDetected', 'missingMandatoryClauses']
});
const _mktDomainPack = composeNewModuleAdaptedToFrozenRegistry({
  moduleId: 'MOD_MKT_DOMAIN',
  name: '틀 4: 마케팅·B2B 영업(SNS 배포·리드 순환배정·광고 픽셀 브레이크) 전용 정합성·자가치유 엔진 팩',
  dependsOnFrozenModules: ['MOD_A', 'MOD_D', 'MOD_E'],
  mutexWithFrozenModules: ['MOD_M'],
  engineChain: [
    'marketing_sales_domain_sentinel.js',
    'pii_masking_sentinel.js',
    'notification_failover_sentinel.js'
  ],
  inputContract: ['title', 'summary', 'linkUrl', 'leadEmail', 'companyName', 'adSpendWon', 'trackedConversions'],
  outputContract: ['allowedToPost', 'xPostText', 'assignedRep', 'brakeTriggered']
});

const _universalArbitrationKernelPack = composeNewModuleAdaptedToFrozenRegistry({
  moduleId: 'MOD_UNIVERSAL_ARBITRATION_KERNEL',
  name: '전 도메인 범용 워크플로우 무중단·충돌 중재 커널 (Universal Workflow Arbitration & Non-Stop Kernel)',
  dependsOnFrozenModules: ['MOD_A', 'MOD_B', 'MOD_D', 'MOD_F'],
  mutexWithFrozenModules: [],
  engineChain: [
    'order_dedup_sentinel.js',
    'safety_governor_spool_engine.js',
    'cs_domain_integrity_sentinel.js',
    'backoffice_domain_integrity_sentinel.js',
    'marketing_sales_domain_sentinel.js'
  ],
  inputContract: ['domain', 'entityKey', 'recipient', 'intentType', 'targetState', 'resourceId', 'provider'],
  outputContract: ['allowed', 'blocked', 'pillarId', 'conflictCase', 'status', 'reasonKo']
});

const DOMAIN_ADAPTED_ENGINE_PACKS = Object.freeze({
  CS_DOMAIN: _csDomainPack,
  BACKOFFICE_DOMAIN: _boDomainPack,
  MARKETING_SALES_DOMAIN: _mktDomainPack,
  UNIVERSAL_ARBITRATION_KERNEL: _universalArbitrationKernelPack,
  MOD_CS_DOMAIN: _csDomainPack,
  MOD_BO_DOMAIN: _boDomainPack,
  MOD_MKT_DOMAIN: _mktDomainPack,
  MOD_UNIVERSAL_ARBITRATION_KERNEL: _universalArbitrationKernelPack
});

function executeDomainEnginePack(domain = 'CS', action = 'DEFAULT', payload = {}) {
  const dom = String(domain || 'CS').trim().toUpperCase();
  const act = String(action || 'DEFAULT').trim().toUpperCase();
  const safePayload = (payload && typeof payload === 'object' && !Array.isArray(payload)) ? payload : {};

  if (
    dom === 'ARBITRATION' ||
    dom === 'UNIVERSAL_ARBITRATION' ||
    dom === 'ERP_KERNEL' ||
    dom === 'MOD_UNIVERSAL_ARBITRATION_KERNEL'
  ) {
    const arb = require('./order_dedup_sentinel');
    if (act === 'SUMMARY') return arb.getUniversalArbitrationKernelSummary();
    if (act === 'OUTBOUND_DEDUP') return arb.arbitrateUniversalOutboundDedup(safePayload);
    if (act === 'CONTRA_INTENT_MUTEX') return arb.arbitrateContraIntentMutex(safePayload);
    if (act === 'SHARED_RESOURCE_LOCK') return arb.arbitrateSharedResourceWriteLock(safePayload);
    if (act === 'GLOBAL_API_QUOTA') return arb.arbitrateGlobalApiQuotaGovernor(safePayload);
    if (act === 'DRAIN_SPOOL') return arb.drainSpooledApiRequests(safePayload);
    if (act === 'SHARED_CAPACITY') return arb.arbitrateSharedCapacityReservation(safePayload);
    return arb.arbitrateUniversalWorkflowConflict(safePayload);
  }

  if (dom === 'CS' || dom === 'MOD_CS_DOMAIN') {
    const cs = require('./cs_domain_integrity_sentinel');
    if (act === 'DRAFT_INTEGRITY') return cs.verifyCsDraftIntegrity(safePayload);
    if (act === 'BURST_DEDUP') return cs.guardDuplicateAndBurstInquiry(safePayload);
    return cs.evaluateCrisisEscalationAndHeal(safePayload);
  }

  if (dom === 'BACKOFFICE' || dom === 'BO' || dom === 'MOD_BO_DOMAIN') {
    const bo = require('./backoffice_domain_integrity_sentinel');
    if (act === 'CONTRACT_INTEGRITY') return bo.verifyContractClauseAndAmountIntegrity(safePayload);
    if (act === 'IAM_OR_ALERT_GUARD') return bo.guardIamOnboardingAndServerAlertFatigue(safePayload);
    return bo.verifyReceiptExpenseIntegrity(safePayload);
  }

  if (dom === 'MARKETING' || dom === 'MKT' || dom === 'SALES' || dom === 'MOD_MKT_DOMAIN') {
    const mkt = require('./marketing_sales_domain_sentinel');
    if (act === 'LEAD_ROUTING') return mkt.guardB2bLeadRoutingIntegrity(safePayload);
    if (act === 'AD_BRAKE') return mkt.evaluateAdTrackingAndBudgetBrake(safePayload);
    return mkt.verifySnsCrossPostIntegrity(safePayload);
  }

  return executeFrozenModulePipelineWithInterlock(['MOD_A', 'MOD_B', 'MOD_E', 'MOD_F'], safePayload);
}

// -----------------------------------------------------------------------------
// 10. 통합 모듈 분류 체계 SSOT (Unified Module Taxonomy SSoT)
//     MOD_A ~ MOD_Q 17대 복합 모듈 <-> 라이선스 관리자(license_manager.js) 상용 코드 1:1 매핑
// -----------------------------------------------------------------------------
const MODULE_TAXONOMY_SSOT = Object.freeze({
  MOD_A: Object.freeze({
    moduleId: 'MOD_A',
    commercialCode: 'MOD_A1_LOCAL_HEALER',
    commercialCodeShort: 'MOD_A1',
    bitIndex: 0,
    bitmask: 1 << 0,
    compositeBitmask: 1 << 0,
    licenseBitIndex: 0,
    licenseBitmask: 1 << 0,
    commercialBitmask: 1 << 0,
    domain: 'CORE_INFRA',
    titleKo: '127ms 무인 자가치유 에어백 모듈',
    titleEn: '127ms Autonomous Self-Healing Airbag Module',
    name: '127ms 무인 자가치유 에어백 모듈 (Self-Healing Airbag Module)'
  }),
  MOD_B: Object.freeze({
    moduleId: 'MOD_B',
    commercialCode: 'MOD_B_RECON_ENGINE',
    commercialCodeShort: 'MOD_B',
    bitIndex: 1,
    bitmask: 1 << 1,
    compositeBitmask: 1 << 1,
    licenseBitIndex: 2,
    licenseBitmask: 1 << 2,
    commercialBitmask: 1 << 2,
    domain: 'FINANCE_ACCOUNTING',
    titleKo: '1원 오차 정산 대사 & 사내 PC DLQ 안전 격리 모듈',
    titleEn: '1-Won Reconciliation & On-Prem DLQ Quarantine Module',
    name: '1원 오차 정산 대사 & 사내 PC DLQ 안전 격리 모듈 (ReconFlow & DLQ Quarantine Module)'
  }),
  MOD_C: Object.freeze({
    moduleId: 'MOD_C',
    commercialCode: 'MOD_C_PACE_DEDUP',
    commercialCodeShort: 'MOD_C',
    bitIndex: 2,
    bitmask: 1 << 2,
    compositeBitmask: 1 << 2,
    licenseBitIndex: 3,
    licenseBitmask: 1 << 3,
    commercialBitmask: 1 << 3,
    domain: 'CORE_INFRA',
    titleKo: '15초 무인 감시 워치독 & 3초 자동 소생 모듈',
    titleEn: '15s Watchdog & 3s Instant Revival Module',
    name: '15초 무인 감시 워치독 & 3초 자동 소생 모듈 (Watchdog & Instant Revival Module)'
  }),
  MOD_D: Object.freeze({
    moduleId: 'MOD_D',
    commercialCode: 'MOD_D_COMPLIANCE_PII',
    commercialCodeShort: 'MOD_D',
    bitIndex: 3,
    bitmask: 1 << 3,
    compositeBitmask: 1 << 3,
    licenseBitIndex: 4,
    licenseBitmask: 1 << 4,
    commercialBitmask: 1 << 4,
    domain: 'MARKETING_CONTENT',
    titleKo: '분기 정족수 합의 & 다중 채널 장애우회 발송 모듈',
    titleEn: 'Branch Quorum Consensus & Multi-Channel Failover Dispatch Module',
    name: '분기 정족수 합의 & 다중 채널 장애우회 발송 모듈 (Branch Quorum & Failover Dispatch Module)'
  }),
  MOD_E: Object.freeze({
    moduleId: 'MOD_E',
    commercialCode: 'MOD_E_BLACKBOX_REPLAY',
    commercialCodeShort: 'MOD_E',
    bitIndex: 4,
    bitmask: 1 << 4,
    compositeBitmask: 1 << 4,
    licenseBitIndex: 5,
    licenseBitmask: 1 << 5,
    commercialBitmask: 1 << 5,
    domain: 'CS_SUPPORT',
    titleKo: 'PII 개인정보 무결점 마스킹 & BYOK 프라이버시 모듈',
    titleEn: 'PII Zero-Defect Masking & BYOK Privacy Module',
    name: 'PII 개인정보 무결점 마스킹 & BYOK 프라이버시 모듈 (PII Masking & BYOK Privacy Module)'
  }),
  MOD_F: Object.freeze({
    moduleId: 'MOD_F',
    commercialCode: 'MOD_F_SIMFLOW_SANDBOX',
    commercialCodeShort: 'MOD_F',
    bitIndex: 5,
    bitmask: 1 << 5,
    compositeBitmask: 1 << 5,
    licenseBitIndex: 6,
    licenseBitmask: 1 << 6,
    commercialBitmask: 1 << 6,
    domain: 'COMMERCE_LOGISTICS',
    titleKo: '주문 멱등성 해시 가드 & 합배송·송장 검증 모듈',
    titleEn: 'Order Idempotency Hash Guard & Combined Shipping Module',
    name: '주문 멱등성 해시 가드 & 합배송·송장 검증 모듈 (Idempotency Dedup & Combined Shipping Module)'
  }),
  MOD_G: Object.freeze({
    moduleId: 'MOD_G',
    commercialCode: 'MOD_G_KEYFLOW_ROTATOR',
    commercialCodeShort: 'MOD_G',
    bitIndex: 6,
    bitmask: 1 << 6,
    compositeBitmask: 1 << 6,
    licenseBitIndex: 7,
    licenseBitmask: 1 << 7,
    commercialBitmask: 1 << 7,
    domain: 'COMMERCE_LOGISTICS',
    titleKo: '동적 노드 컨트롤러 & 102종 공식 노드 실시간 제어 모듈',
    titleEn: 'Dynamic Node Controller & 102 Official Nodes Control Module',
    name: '동적 노드 컨트롤러 & 102종 공식 노드 실시간 제어 모듈 (Dynamic Node Controller Module)'
  }),
  MOD_H: Object.freeze({
    moduleId: 'MOD_H',
    commercialCode: 'MOD_H_DRIFTFLOW_RADAR',
    commercialCodeShort: 'MOD_H',
    bitIndex: 7,
    bitmask: 1 << 7,
    compositeBitmask: 1 << 7,
    licenseBitIndex: 8,
    licenseBitmask: 1 << 8,
    commercialBitmask: 1 << 8,
    domain: 'CRM_SALES',
    titleKo: 'DriftFlow 외부 API 스키마 드리프트 18대 자동 변환 브릿지 모듈',
    titleEn: 'DriftFlow External API Schema Drift 18-Bridge Module',
    name: 'DriftFlow 외부 API 스키마 드리프트 18대 자동 변환 브릿지 모듈 (DriftFlow Schema Bridge Module)'
  }),
  MOD_I: Object.freeze({
    moduleId: 'MOD_I',
    commercialCode: 'MOD_I_PROFITFLOW_GUARD',
    commercialCodeShort: 'MOD_I',
    bitIndex: 8,
    bitmask: 1 << 8,
    compositeBitmask: 1 << 8,
    licenseBitIndex: 9,
    licenseBitmask: 1 << 9,
    commercialBitmask: 1 << 9,
    domain: 'CORE_INFRA',
    titleKo: 'AES-256-GCM 볼트 엔클레이브 & 역공학 차단 보안 모듈',
    titleEn: 'AES-256-GCM Vault Enclave & Anti-Tamper Security Module',
    name: 'AES-256-GCM 볼트 엔클레이브 & 역공학 차단 보안 모듈 (Vault Enclave & Tamper Guard Module)'
  }),
  MOD_J: Object.freeze({
    moduleId: 'MOD_J',
    commercialCode: 'MOD_J_CUSTOMS_CLEARANCE',
    commercialCodeShort: 'MOD_J',
    bitIndex: 9,
    bitmask: 1 << 9,
    compositeBitmask: 1 << 9,
    licenseBitIndex: 10,
    licenseBitmask: 1 << 10,
    commercialBitmask: 1 << 10,
    domain: 'FINANCE_ACCOUNTING',
    titleKo: '국세청 홈택스 전자세금계산서·부가세 크로스체크 세무 방어 모듈',
    titleEn: 'HomeTax Electronic Tax Invoice & VAT Cross-Check Defense Module',
    name: '국세청 홈택스 전자세금계산서·부가세 크로스체크 세무 방어 모듈 (HomeTax & VAT Sentinel Module)'
  }),
  MOD_K: Object.freeze({
    moduleId: 'MOD_K',
    commercialCode: 'MOD_K_GLOBAL_FX_SETTLEMENT',
    commercialCodeShort: 'MOD_K',
    bitIndex: 10,
    bitmask: 1 << 10,
    compositeBitmask: 1 << 10,
    licenseBitIndex: 11,
    licenseBitmask: 1 << 11,
    commercialBitmask: 1 << 11,
    domain: 'COMMERCE_LOGISTICS',
    titleKo: '부정결제 FDS 사기 탐지·역마진·품절·통관오류 즉시 출고보류 모듈',
    titleEn: 'FDS Fraud Detection, Negative Margin & Immediate Hold Module',
    name: '부정결제 FDS 사기 탐지·역마진·품절·통관오류 즉시 출고보류 모듈 (Risk Hold & Freeze Module)'
  }),
  MOD_L: Object.freeze({
    moduleId: 'MOD_L',
    commercialCode: 'MOD_L_COLDCHAIN_LOT_GUARD',
    commercialCodeShort: 'MOD_L',
    bitIndex: 11,
    bitmask: 1 << 11,
    compositeBitmask: 1 << 11,
    licenseBitIndex: 12,
    licenseBitmask: 1 << 12,
    commercialBitmask: 1 << 12,
    domain: 'COMMERCE_LOGISTICS',
    titleKo: '로켓그로스 입고검품·아이템위너·택배 허브/배송사고 물류 가속 모듈',
    titleEn: 'Logistics Inspection, Item Winner & Hub Acceleration Module',
    name: '로켓그로스 입고검품·아이템위너·택배 허브/배송사고 물류 가속 모듈 (Logistics & Winner Module)'
  }),
  MOD_M: Object.freeze({
    moduleId: 'MOD_M',
    commercialCode: 'MOD_M_B2B_CREDIT_LIMIT_GUARD',
    commercialCodeShort: 'MOD_M',
    bitIndex: 12,
    bitmask: 1 << 12,
    compositeBitmask: 1 << 12,
    licenseBitIndex: 13,
    licenseBitmask: 1 << 13,
    commercialBitmask: 1 << 13,
    domain: 'CS_SUPPORT',
    titleKo: '상표권·지식재산권(IP) 침해 사전 감별 & 공식 소명 증적 모듈',
    titleEn: 'Trademark & Intellectual Property Defense & Evidence Module',
    name: '상표권·지식재산권(IP) 침해 사전 감별 & 공식 소명 증적 모듈 (Trademark & IP Defense Module)'
  }),
  MOD_N: Object.freeze({
    moduleId: 'MOD_N',
    commercialCode: 'MOD_N_RETURN_FRAUD_CLAIM_RADAR',
    commercialCodeShort: 'MOD_N',
    bitIndex: 13,
    bitmask: 1 << 13,
    compositeBitmask: 1 << 13,
    licenseBitIndex: 14,
    licenseBitmask: 1 << 14,
    commercialBitmask: 1 << 14,
    domain: 'CS_SUPPORT',
    titleKo: '식약처·환경부 위해식품·해외직구 금지성분 1초 스크리닝 모듈',
    titleEn: 'Hazardous Substance & Banned Ingredients Screening Module',
    name: '식약처·환경부 위해식품·해외직구 금지성분 1초 스크리닝 모듈 (Hazardous Substance Sentinel Module)'
  }),
  MOD_O: Object.freeze({
    moduleId: 'MOD_O',
    commercialCode: 'MOD_O_PHARMA_NARCOTICS_SERIAL_GUARD',
    commercialCodeShort: 'MOD_O',
    bitIndex: 14,
    bitmask: 1 << 14,
    compositeBitmask: 1 << 14,
    licenseBitIndex: 15,
    licenseBitmask: 1 << 15,
    commercialBitmask: 1 << 15,
    domain: 'CS_SUPPORT',
    titleKo: '공정위 소비자분쟁 감가상각·악성 체리피커·반품 미회수 방어 모듈',
    titleEn: 'Consumer Dispute Depreciation & Cherrypicker Defense Module',
    name: '공정위 소비자분쟁 감가상각·악성 체리피커·반품 미회수 방어 모듈 (Consumer Dispute & Cherrypicker Defense Module)'
  }),
  MOD_P: Object.freeze({
    moduleId: 'MOD_P',
    commercialCode: 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD',
    commercialCodeShort: 'MOD_P',
    bitIndex: 15,
    bitmask: 1 << 15,
    compositeBitmask: 1 << 15,
    licenseBitIndex: 16,
    licenseBitmask: 1 << 16,
    commercialBitmask: 1 << 16,
    domain: 'COMMERCE_LOGISTICS',
    titleKo: '쿠팡 밀크런·로켓배송 파레트 과적·적재규격(1.6m/500kg) 방어 모듈',
    titleEn: 'Milkrun Pallet Overload & Stacking Specification Guard Module',
    name: '쿠팡 밀크런·로켓배송 파레트 과적·적재규격(1.6m/500kg) 방어 모듈 (Milkrun Pallet Guard Module)'
  }),
  MOD_Q: Object.freeze({
    moduleId: 'MOD_Q',
    commercialCode: 'MOD_Q_HS_TARIFF_DUTY_GUARD',
    commercialCodeShort: 'MOD_Q',
    bitIndex: 16,
    bitmask: 1 << 16,
    compositeBitmask: 1 << 16,
    licenseBitIndex: 17,
    licenseBitmask: 1 << 17,
    commercialBitmask: 1 << 17,
    domain: 'FINANCE_ACCOUNTING',
    titleKo: '오픈마켓 정산금 압류·가압류 진단 & 민사집행법 제246조 최저생계비(185만 원) 소명 모듈',
    titleEn: 'Settlement Seizure Defense & Protected Minimum Living Wage Module',
    name: '오픈마켓 정산금 압류·가압류 진단 & 민사집행법 제246조 최저생계비(185만 원) 소명 모듈 (Seizure Defense Module)'
  })
});

// -----------------------------------------------------------------------------
// 11. 상황별 6대 엔진 모듈 패키지 카트리지 카탈로그 (Situation-Specific Engine Pack Catalog)
// -----------------------------------------------------------------------------
const SITUATION_ENGINE_PACK_CATALOG = Object.freeze({
  PACK_CORE_BASE: Object.freeze({
    packId: 'PACK_CORE_BASE',
    skuId: 'AF-ENG-CORE',
    titleKo: '기본 무중단 베이스 차체',
    titleEn: 'Core Non-Stop Base Chassis',
    description: '127ms 자가치유 + 15초 워치독 + 70% 스풀 거버너 + 보안 볼트 (상시 기본 장착)',
    modules: Object.freeze(['MOD_A', 'MOD_C', 'MOD_I']),
    bitmask: 521,
    licenseBitmask: 521,
    standalonePriceKRW: 29000,
    standalonePriceUSD: 24,
    checkoutUrl: '/checkout.html?engine=AF-ENG-CORE',
    domain: 'CORE_INFRA',
    defaultMounted: true
  }),
  PACK_COMMERCE_LOGISTICS: Object.freeze({
    packId: 'PACK_COMMERCE_LOGISTICS',
    skuId: 'AF-ENG-COMMERCE',
    titleKo: '커머스·물류·합배송·출고보류 엔진 팩',
    titleEn: 'Commerce, Logistics, Combined Shipping & Hold Engine Pack',
    description: '주문 멱등성 + 부정결제/품절 출고보류 + 로켓그로스/배송사고 + 파레트 과적 방어',
    modules: Object.freeze(['MOD_F', 'MOD_K', 'MOD_L', 'MOD_P']),
    bitmask: 71744,
    licenseBitmask: 71744,
    standalonePriceKRW: 49000,
    standalonePriceUSD: 39,
    checkoutUrl: '/checkout.html?engine=AF-ENG-COMMERCE',
    domain: 'COMMERCE_LOGISTICS',
    defaultMounted: false
  }),
  PACK_FINANCE_TAX_ERP: Object.freeze({
    packId: 'PACK_FINANCE_TAX_ERP',
    skuId: 'AF-ENG-FINANCE',
    titleKo: '재무·정산대사·국세청 홈택스·압류방어 엔진 팩',
    titleEn: 'Finance, Tax Reconciliation, HomeTax & Seizure Defense Engine Pack',
    description: '1원 오차 정산 대사 + 국세청 홈택스 전자세금계산서/부가세 + 압류방어 최저생계비 소명',
    modules: Object.freeze(['MOD_B', 'MOD_J', 'MOD_Q']),
    bitmask: 132100,
    licenseBitmask: 132100,
    standalonePriceKRW: 59000,
    standalonePriceUSD: 49,
    checkoutUrl: '/checkout.html?engine=AF-ENG-FINANCE',
    domain: 'FINANCE_ACCOUNTING',
    defaultMounted: false
  }),
  PACK_GLOBAL_CUSTOMS_FX: Object.freeze({
    packId: 'PACK_GLOBAL_CUSTOMS_FX',
    skuId: 'AF-ENG-GLOBAL',
    titleKo: '글로벌 역직구·관세청 통관부호(PCCC)·다통화 환율 엔진 팩',
    titleEn: 'Global Cross-Border, Customs PCCC & Multi-Currency FX Engine Pack',
    description: '동적 노드 제어 + 개인통관고유부호(PCCC) 검증 + 해외직구 출고보류 + 다통화 환율',
    modules: Object.freeze(['MOD_G', 'MOD_K']),
    bitmask: 2176,
    licenseBitmask: 2176,
    standalonePriceKRW: 59000,
    standalonePriceUSD: 49,
    checkoutUrl: '/checkout.html?engine=AF-ENG-GLOBAL',
    domain: 'COMMERCE_LOGISTICS',
    defaultMounted: false
  }),
  PACK_CS_DISPUTE_PRIVACY: Object.freeze({
    packId: 'PACK_CS_DISPUTE_PRIVACY',
    skuId: 'AF-ENG-CS',
    titleKo: '옴니채널 CS·개인정보 마스킹·악성리뷰/분쟁/지재권 방어 엔진 팩',
    titleEn: 'Omnichannel CS, PII Masking & Dispute / IP Defense Engine Pack',
    description: 'PII 개인정보 마스킹 + 상표권/IP 침해 소명 + 위해성분 스크리닝 + 소비자분쟁/체리피커 방어',
    modules: Object.freeze(['MOD_E', 'MOD_M', 'MOD_N', 'MOD_O']),
    bitmask: 57376,
    licenseBitmask: 57376,
    standalonePriceKRW: 49000,
    standalonePriceUSD: 39,
    checkoutUrl: '/checkout.html?engine=AF-ENG-CS',
    domain: 'CS_SUPPORT',
    defaultMounted: false
  }),
  PACK_MARKETING_CRM_PIPELINE: Object.freeze({
    packId: 'PACK_MARKETING_CRM_PIPELINE',
    skuId: 'AF-ENG-MARKETING',
    titleKo: '마케팅·SNS 멀티배포·CRM 영업 파이프라인·스키마 드리프트 방어 엔진 팩',
    titleEn: 'Marketing SNS Multi-Distribution, CRM Pipeline & Drift Defense Engine Pack',
    description: '분기 정족수 합의 다중채널 발송 + DriftFlow 외부 API 스키마 드리프트 자동 변환 브릿지',
    modules: Object.freeze(['MOD_D', 'MOD_H']),
    bitmask: 272,
    licenseBitmask: 272,
    standalonePriceKRW: 39000,
    standalonePriceUSD: 29,
    checkoutUrl: '/checkout.html?engine=AF-ENG-MARKETING',
    domain: 'MARKETING_CONTENT',
    defaultMounted: false
  })
});

const ENGINE_PACK_MASTER_BUNDLE = Object.freeze({
  skuId: 'AF-ENG-ALL',
  titleKo: '6대 전문 엔진 올인원 마스터 패스',
  titleEn: '6-Domain Engine Master All-Access Pass',
  bitmask: 262141, // 521 | 71744 | 132100 | 2176 | 57376 | 272 = 262141
  standalonePriceKRW: 189000,
  standalonePriceUSD: 149,
  checkoutUrl: '/checkout.html?engine=AF-ENG-ALL'
});

const SMARTGRID_PROGRAM_CATALOG = Object.freeze({
  'AF-SMARTGRID-PRO': Object.freeze({
    skuId: 'AF-SMARTGRID-PRO',
    titleKo: 'AutoFlow SmartGrid 프로 스마트 원장 프로그램',
    titleEn: 'AutoFlow SmartGrid Pro Intelligent Ledger App',
    standalonePriceKRW: 49000,
    standalonePriceUSD: 39,
    bundleDiscountPriceKRW: 19000,
    bundleDiscountPriceUSD: 15,
    checkoutUrl: '/checkout.html?addon=AF-SMARTGRID-PRO'
  }),
  'AF-EXCEL-PACK-5DEPT': Object.freeze({
    skuId: 'AF-EXCEL-PACK-5DEPT',
    titleKo: '5대 부서 표준 스마트 엑셀(.xlsx) 마스터팩',
    titleEn: '5-Department Standard Smart Excel (.xlsx) Master Pack',
    standalonePriceKRW: 19000,
    standalonePriceUSD: 15,
    bundleDiscountPriceKRW: 9900,
    bundleDiscountPriceUSD: 8,
    checkoutUrl: '/checkout.html?addon=AF-EXCEL-PACK-5DEPT'
  })
});

// -----------------------------------------------------------------------------
// 12. 다중 도메인 워크플로우 연결도 & 가격 티어 SSOT (Workflow Connectivity Tiers)
// -----------------------------------------------------------------------------
const WORKFLOW_CONNECTIVITY_TIERS = Object.freeze({
  TIER_1_SINGLE_LINK: Object.freeze({
    tierId: 'TIER_1_SINGLE_LINK',
    nameKo: '단일 연결·알림 자동화',
    nameEn: 'Single Link & Notification Automation',
    recommendedPriceKrw: 39000,
    recommendedPriceUsd: 29,
    priceRangeKrw: '29,000 ~ 39,000',
    description: '1~2개 시스템 간 단순 알림/동기화 자동화'
  }),
  TIER_2_DOMAIN_GUARD: Object.freeze({
    tierId: 'TIER_2_DOMAIN_GUARD',
    nameKo: '도메인 규칙·다중 검증 자동화',
    nameEn: 'Domain Rule & Multi-Validation Guard',
    recommendedPriceKrw: 59000,
    recommendedPriceUsd: 45,
    priceRangeKrw: '49,000 ~ 69,000',
    description: '3~4개 시스템 또는 도메인 검증/보류 규칙이 포함된 자동화'
  }),
  TIER_3_CROSS_AI_PIPELINE: Object.freeze({
    tierId: 'TIER_3_CROSS_AI_PIPELINE',
    nameKo: '크로스-시스템·AI 복합 파이프라인',
    nameEn: 'Cross-System & AI Multi-Pipeline',
    recommendedPriceKrw: 119000,
    recommendedPriceUsd: 89,
    priceRangeKrw: '89,000 ~ 149,000',
    description: '4~5개 시스템 또는 AI/LLM 결합 다채널 오케스트레이션 파이프라인'
  }),
  TIER_4_ENTERPRISE_ERP_CORE: Object.freeze({
    tierId: 'TIER_4_ENTERPRISE_ERP_CORE',
    nameKo: '전사 ERP·재무·기간망 하이엔드 파이프라인',
    nameEn: 'Enterprise ERP, Finance & Core Backbone Pipeline',
    recommendedPriceKrw: 199000,
    recommendedPriceUsd: 149,
    priceRangeKrw: '179,000 ~ 290,000',
    description: '5개 이상 시스템 또는 국세청/관세청/금융/ERP 양방향 원장 대사 하이엔드 기간망'
  })
});

/**
 * 워크플로우 JSON 페이로드를 정밀 분석하여 연결 시스템 수, AI 탑재, 정부/금융 API,
 * 분기 인터락 여부를 도출하고 최적 엔진 팩과 공정 권장 가격 티어를 산정한다.
 * @param {object|string} workflowPayload
 * @returns {object}
 */
function analyzeWorkflowConnectivityAndPricing(workflowPayload = {}) {
  let wf = workflowPayload;
  if (typeof wf === 'string') {
    try {
      wf = JSON.parse(wf);
    } catch (_) {
      wf = {};
    }
  }
  let safeWf = (wf && typeof wf === 'object' && !Array.isArray(wf)) ? wf : {};
  if (safeWf.workflow && typeof safeWf.workflow === 'object' && !Array.isArray(safeWf.workflow)) {
    safeWf = safeWf.workflow;
  } else if (safeWf.data && typeof safeWf.data === 'object' && !Array.isArray(safeWf.data) && Array.isArray(safeWf.data.nodes)) {
    safeWf = safeWf.data;
  }
  const nodes = Array.isArray(safeWf.nodes) ? safeWf.nodes : [];
  const connections = (safeWf.connections && typeof safeWf.connections === 'object') ? safeWf.connections : {};
  const wfName = String(safeWf.name || safeWf.id || '').toLowerCase();
  const explicitDomain = String(safeWf.domain || '').trim().toUpperCase();

  const detectedSystemsSet = new Set();
  let hasAiOrVision = false;
  let hasGovOrFinanceApi = false;
  let hasMultiBranchInterlock = false;
  let hasDomainValidationOrHold = false;
  const detectedDomainsSet = new Set();

  if (explicitDomain) {
    detectedDomainsSet.add(explicitDomain);
  }

  // 시스템별 고유 패턴 매칭 사전
  const specificSystemPatterns = [
    { key: 'naver', regex: /naver|smartstore|네이버/i },
    { key: 'coupang', regex: /coupang|rocket|쿠팡|(?:^|[^a-z])wing(?:[^a-z]|$)/i },
    { key: 'cafe24', regex: /cafe24|카페24/i },
    { key: 'shopify', regex: /shopify|쇼피파이/i },
    { key: 'slack', regex: /slack/i },
    { key: 'kakao', regex: /kakao|alimtalk|카카오|알림톡/i },
    { key: 'telegram', regex: /telegram|텔레그램/i },
    { key: 'googlesheets', regex: /googlesheet|google_sheet|google-sheet|sheets|시트/i },
    { key: 'notion', regex: /notion|노션/i },
    { key: 'airtable', regex: /airtable|에어테이블/i },
    { key: 'postgres', regex: /postgres/i },
    { key: 'mysql', regex: /mysql|mariadb/i },
    { key: 'openai', regex: /openai|chatgpt/i },
    { key: 'anthropic', regex: /anthropic|claude/i },
    { key: 'gemini', regex: /gemini/i },
    { key: 'hometax', regex: /hometax|홈택스|국세청/i },
    { key: 'tax', regex: /taxinvoice|tax_invoice|세금계산서|부가세/i },
    { key: 'customs', regex: /customs|관세청|유니패스|unipass/i },
    { key: 'pccc', regex: /pccc|개인통관고유부호|통관고유부호/i },
    { key: 'bank', regex: /(?:^|[^a-z])bank(?:[^a-z]|$)|banking|계좌|송금/i },
    { key: 'stripe', regex: /stripe/i },
    { key: 'pg', regex: /paypal|tosspay|kakaopay|nicepay|inicis|토스페이|이니시스|(?:^|[^a-z])pg(?:[^a-z]|$)|정산/i },
    { key: 'instagram', regex: /instagram|인스타/i },
    { key: 'youtube', regex: /youtube|유튜브/i },
    { key: 'blog', regex: /blog|wordpress|블로그/i },
    { key: 'email', regex: /email|sendgrid|mailgun|gmail|outlook|이메일/i },
    { key: 'smtp', regex: /smtp/i },
    { key: 'erp', regex: /(?:^|[^a-z])(?:erp|sap|douzone)(?:[^a-z]|$)|더존/i },
    { key: 'crm', regex: /(?:^|[^a-z])crm(?:[^a-z]|$)|hubspot|salesforce/i }
  ];

  // 워크플로우 이름 매칭
  for (const { key, regex } of specificSystemPatterns) {
    if (regex.test(wfName)) {
      detectedSystemsSet.add(key);
    }
  }

  // 노드 단위 시스템 및 도메인 지표 정밀 추출
  for (const node of nodes) {
    if (!node || typeof node !== 'object') continue;
    const nName = String(node.name || '');
    const nType = String(node.type || '');
    let nParamStr = '';
    try {
      nParamStr = JSON.stringify(node.parameters || {});
    } catch (_) {
      try {
        nParamStr = String(node.parameters || '');
      } catch (_) {
        nParamStr = '';
      }
    }
    const combinedText = `${nName} ${nType} ${nParamStr}`;

    let matchedSpecific = false;
    for (const { key, regex } of specificSystemPatterns) {
      if (regex.test(combinedText)) {
        detectedSystemsSet.add(key);
        matchedSpecific = true;
      }
    }

    // 특정 시스템에 잡히지 않은 범용 웹훅/HTTP 요청인 경우에만 'webhook'으로 분류
    if (!matchedSpecific && /webhook|httpRequest|http-request|웹훅/i.test(combinedText)) {
      detectedSystemsSet.add('webhook');
    }

    // AI/Vision 검출
    if (/openai|anthropic|claude|gemini|deepseek|chatgpt|llm|vision|ocr|인공지능|langchain/i.test(combinedText)) {
      hasAiOrVision = true;
    }

    // 정부망/금융/ERP API 검출
    if (/(?:^|[^a-z])(?:bank|pg|erp)(?:[^a-z]|$)|hometax|홈택스|국세청|customs|관세청|unipass|pccc|banking|stripe|paypal|tosspay|정산|세무|세금계산서|taxinvoice|reconciliation|대사|압류/i.test(combinedText)) {
      hasGovOrFinanceApi = true;
    }

    // 도메인 유효성 검증 및 출고보류 로직 검출
    if (/hold|quarantine|보류|격리|검증|차단|아이템위너|winner|margin|역마진|품절|위해성분|체리피커/i.test(combinedText)) {
      hasDomainValidationOrHold = true;
    }

    // 조건부 분기, 정족수 합의, 보류/격리 라우팅 노드 검출 (hasMultiBranchInterlock)
    if (/if|switch|filter|router|quorum|branch|hold|quarantine|보류|격리|분기/i.test(`${nType} ${nName}`)) {
      hasMultiBranchInterlock = true;
    }

    // 공통 템플릿 에어백/터미널/환경변수 노드는 도메인 키워드 오염 방지를 위해 스캔 제외
    const isTemplateBoilerplateNode = /^branch\s+\d+\s+terminal|환경변수_보관함|global_error_trigger/i.test(nName);
    if (!isTemplateBoilerplateNode) {
      // 노드 내용 기반 도메인 분류
      if (/coupang|naver|cafe24|shopify|shipping|pallet|winner|밀크런|합배송|송장|커머스|물류|택배|출고|재고/i.test(combinedText)) {
        detectedDomainsSet.add('COMMERCE_LOGISTICS');
      }
      if (/(?:^|[^a-z])(?:tax|erp)(?:[^a-z]|$)|hometax|홈택스|vat|부가세|세무|정산|대사|reconciliation|seizure|압류|세금계산서|회계/i.test(combinedText)) {
        detectedDomainsSet.add('FINANCE_ACCOUNTING');
      }
      if (/customs|pccc|unipass|(?:currency|fx|rate|foreign)[\s_-]?exchange|환율|외환|관세|통관|역직구|다통화/i.test(combinedText)) {
        detectedDomainsSet.add('COMMERCE_LOGISTICS');
        detectedDomainsSet.add('GLOBAL_CUSTOMS_FX');
      }
      if (/cs|voice|claim|dispute|cherrypicker|sentiment|trademark|상표권|소비자분쟁|위해성분|감가상각|불만|상담|리뷰/i.test(combinedText)) {
        detectedDomainsSet.add('CS_SUPPORT');
      }
      if (/marketing|sns|crm|lead|campaign|adspend|리드|광고|인스타|유튜브|블로그/i.test(combinedText)) {
        detectedDomainsSet.add('MARKETING_CONTENT');
        detectedDomainsSet.add('CRM_SALES');
      }
    }
  }

  // 연결망 분기 검사 (Fan-out branching / Quorum)
  for (const [srcNode, connObj] of Object.entries(connections)) {
    if (!connObj || typeof connObj !== 'object') continue;
    const mainBranches = Array.isArray(connObj.main) ? connObj.main : [];
    if (mainBranches.length > 1) {
      hasMultiBranchInterlock = true;
    }
    for (const b of mainBranches) {
      if (Array.isArray(b) && b.length > 1) {
        hasMultiBranchInterlock = true;
      }
    }
  }

  // 워크플로우 이름 기반 폴백 도메인 매핑
  if (/coupang|naver|cafe24|shopify|order|commerce|logistics|배송|주문|쇼핑몰/i.test(wfName)) {
    detectedDomainsSet.add('COMMERCE_LOGISTICS');
  }
  if (/tax|hometax|finance|vat|세무|홈택스|회계|정산/i.test(wfName)) {
    detectedDomainsSet.add('FINANCE_ACCOUNTING');
  }
  if (/customs|pccc|fx|관세|통관|해외직구/i.test(wfName)) {
    detectedDomainsSet.add('GLOBAL_CUSTOMS_FX');
  }
  if (/cs|support|dispute|voice|상담|고객/i.test(wfName)) {
    detectedDomainsSet.add('CS_SUPPORT');
  }
  if (/marketing|sales|crm|sns|마케팅|영업/i.test(wfName)) {
    detectedDomainsSet.add('MARKETING_CONTENT');
    detectedDomainsSet.add('CRM_SALES');
  }

  // 감지된 핵심 시스템 기반 교차 도메인 및 API 플래그 보강
  hasGovOrFinanceApi = Boolean(
    hasGovOrFinanceApi ||
    detectedSystemsSet.has('hometax') ||
    detectedSystemsSet.has('tax') ||
    detectedSystemsSet.has('customs') ||
    detectedSystemsSet.has('pccc') ||
    detectedSystemsSet.has('bank') ||
    detectedSystemsSet.has('stripe') ||
    detectedSystemsSet.has('pg') ||
    detectedSystemsSet.has('erp')
  );

  hasAiOrVision = Boolean(
    hasAiOrVision ||
    detectedSystemsSet.has('openai') ||
    detectedSystemsSet.has('anthropic') ||
    detectedSystemsSet.has('gemini')
  );

  if (
    detectedSystemsSet.has('coupang') ||
    detectedSystemsSet.has('naver') ||
    detectedSystemsSet.has('cafe24') ||
    detectedSystemsSet.has('shopify')
  ) {
    detectedDomainsSet.add('COMMERCE_LOGISTICS');
  }
  if (
    detectedSystemsSet.has('hometax') ||
    detectedSystemsSet.has('tax') ||
    detectedSystemsSet.has('bank') ||
    detectedSystemsSet.has('stripe') ||
    detectedSystemsSet.has('pg') ||
    detectedSystemsSet.has('erp')
  ) {
    detectedDomainsSet.add('FINANCE_ACCOUNTING');
  }
  if (detectedSystemsSet.has('customs') || detectedSystemsSet.has('pccc')) {
    detectedDomainsSet.add('COMMERCE_LOGISTICS');
    detectedDomainsSet.add('GLOBAL_CUSTOMS_FX');
  }
  if (
    detectedSystemsSet.has('instagram') ||
    detectedSystemsSet.has('youtube') ||
    detectedSystemsSet.has('blog') ||
    detectedSystemsSet.has('crm')
  ) {
    detectedDomainsSet.add('MARKETING_CONTENT');
    detectedDomainsSet.add('CRM_SALES');
  }

  if (nodes.length > 0 && detectedSystemsSet.size === 0) {
    if (nodes.length >= 20) {
      detectedSystemsSet.add('industrial_scada');
      detectedSystemsSet.add('telemetry_bus');
    } else {
      detectedSystemsSet.add('local_runtime');
    }
  }

  const connectedSystems = Array.from(detectedSystemsSet);
  const connectedSystemsCount = connectedSystems.length;
  const nodeCount = nodes.length;

  // 4단계 연결도 및 권장 가격 티어 결정 (연결 시스템 수 + 노드 규모 + AI/기관API/다중분기 밀도 종합)
  let connectivityTier = 'TIER_1_SINGLE_LINK';
  if (
    nodeCount >= 20 ||
    connectedSystemsCount >= 5 ||
    (hasGovOrFinanceApi && (hasAiOrVision || connectedSystemsCount >= 4 || (connectedSystemsCount >= 3 && hasMultiBranchInterlock))) ||
    (connectedSystemsCount >= 4 && hasGovOrFinanceApi && hasAiOrVision)
  ) {
    connectivityTier = 'TIER_4_ENTERPRISE_ERP_CORE';
  } else if (hasAiOrVision || connectedSystemsCount >= 4 || nodeCount >= 12) {
    connectivityTier = 'TIER_3_CROSS_AI_PIPELINE';
  } else if (connectedSystemsCount >= 3 || hasDomainValidationOrHold || nodeCount >= 6) {
    connectivityTier = 'TIER_2_DOMAIN_GUARD';
  } else {
    connectivityTier = 'TIER_1_SINGLE_LINK';
  }

  const tierMeta = WORKFLOW_CONNECTIVITY_TIERS[connectivityTier] || WORKFLOW_CONNECTIVITY_TIERS.TIER_1_SINGLE_LINK;

  // 상황별 엔진 팩 요구사항 산출 (상시 기본 무중단 PACK_CORE_BASE 포함)
  const requiredEnginePacksSet = new Set(['PACK_CORE_BASE']);

  if (detectedDomainsSet.has('COMMERCE_LOGISTICS')) {
    requiredEnginePacksSet.add('PACK_COMMERCE_LOGISTICS');
  }
  if (detectedDomainsSet.has('FINANCE_ACCOUNTING')) {
    requiredEnginePacksSet.add('PACK_FINANCE_TAX_ERP');
  }
  if (detectedDomainsSet.has('GLOBAL_CUSTOMS_FX') || detectedSystemsSet.has('customs') || detectedSystemsSet.has('pccc')) {
    requiredEnginePacksSet.add('PACK_GLOBAL_CUSTOMS_FX');
  }
  if (detectedDomainsSet.has('CS_SUPPORT')) {
    requiredEnginePacksSet.add('PACK_CS_DISPUTE_PRIVACY');
  }
  if (detectedDomainsSet.has('MARKETING_CONTENT') || detectedDomainsSet.has('CRM_SALES')) {
    requiredEnginePacksSet.add('PACK_MARKETING_CRM_PIPELINE');
  }

  const requiredEnginePacks = Array.from(requiredEnginePacksSet);
  const allPackCatalogKeys = Object.keys(SITUATION_ENGINE_PACK_CATALOG);
  const dormantEnginePacks = allPackCatalogKeys.filter(p => !requiredEnginePacksSet.has(p));

  let recommendedBitmask = 0;
  for (const packId of requiredEnginePacks) {
    const pack = SITUATION_ENGINE_PACK_CATALOG[packId];
    if (pack) {
      if (typeof pack.licenseBitmask === 'number') {
        recommendedBitmask = ((recommendedBitmask | pack.licenseBitmask) >>> 0);
      }
      if (typeof pack.bitmask === 'number') {
        recommendedBitmask = ((recommendedBitmask | pack.bitmask) >>> 0);
      }
      if (Array.isArray(pack.modules)) {
        for (const mId of pack.modules) {
          const modDef = FROZEN_MODULE_COMPOSITIONS[mId];
          if (modDef && typeof modDef.bitmask === 'number') {
            recommendedBitmask = ((recommendedBitmask | modDef.bitmask) >>> 0);
          }
        }
      }
    }
  }

  const detectedDomains = Array.from(detectedDomainsSet);

  return {
    connectedSystems,
    connectedSystemsCount,
    nodeCount,
    hasAiOrVision,
    hasGovOrFinanceApi,
    hasMultiBranchInterlock,
    hasDomainValidationOrHold,
    connectivityTier,
    tierDetails: tierMeta,
    recommendedPriceKrw: tierMeta.recommendedPriceKrw,
    recommendedPriceUsd: tierMeta.recommendedPriceUsd,
    detectedDomains,
    requiredEnginePacks,
    dormantEnginePacks,
    recommendedBitmask
  };
}

module.exports = {
  FROZEN_MODULE_COMPOSITIONS,
  FROZEN_COMPOSITE_MODULES: FROZEN_MODULE_COMPOSITIONS,
  INTER_MODULE_CONFLICT_MATRIX,
  CONFLICT_MUTEX_GROUPS: INTER_MODULE_CONFLICT_MATRIX,
  INTENTIONAL_SECURITY_CONTRACTS,
  DOMAIN_ADAPTED_ENGINE_PACKS,
  MODULE_TAXONOMY_SSOT,
  SITUATION_ENGINE_PACK_CATALOG,
  ENGINE_PACK_MASTER_BUNDLE,
  SMARTGRID_PROGRAM_CATALOG,
  WORKFLOW_CONNECTIVITY_TIERS,
  analyzeWorkflowConnectivityAndPricing,
  getSituationEnginePackCatalog: () => SITUATION_ENGINE_PACK_CATALOG,
  getEnginePackMasterBundle: () => ENGINE_PACK_MASTER_BUNDLE,
  getSmartGridProgramCatalog: () => SMARTGRID_PROGRAM_CATALOG,
  getWorkflowConnectivityTiers: () => WORKFLOW_CONNECTIVITY_TIERS,
  getModuleTaxonomySsot: () => MODULE_TAXONOMY_SSOT,
  normalizeToShortModuleId,
  computeModuleContractSeal,
  attemptMutateFrozenModule,
  composeNewModuleAdaptedToFrozenRegistry,
  evaluateInterlockMatrix,
  executeFrozenModulePipelineWithInterlock,
  evaluateInterlockForTargetModule,
  executeDomainEnginePack,
  inspectAndCrystallizeAllCoreEngines,
  crystallizeAllEngineModules: inspectAndCrystallizeAllCoreEngines,
  verifyFullSystemArchitecture: inspectAndCrystallizeAllCoreEngines
};


