// [AutoFlow Blue Team 36대 카오스 장애 감지 시그니처 & 1:1 자동 치유 처방전 인라인 실코드]
const items = (typeof $input !== 'undefined' && $input && typeof $input.all === 'function') ? $input.all() : [];
const healedItems = [];

function toSafeString(val) {
  if (val === null) return 'null';
  if (val === undefined) return 'undefined';
  if (typeof val === 'string') return val;
  if (typeof val === 'number') return isNaN(val) ? 'NaN' : String(val);
  if (typeof val === 'boolean') return String(val);
  if (typeof val === 'bigint') return val.toString();
  if (typeof val === 'object') {
    try {
      const seen = new WeakSet();
      return JSON.stringify(val, (key, value) => {
        if (typeof value === 'object' && value !== null) {
          if (seen.has(value)) return '[Circular]';
          seen.add(value);
        }
        if (typeof value === 'bigint') return value.toString();
        return value;
      });
    } catch(e) { return String(val); }
  }
  return String(val);
}

function isValidBizNumber(bizNum) {
  const clean = String(bizNum).replace(/[^0-9]/g, '');
  if (clean.length !== 10) return false;
  const weights = [1, 3, 7, 1, 3, 7, 1, 3, 5];
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += Number(clean[i]) * weights[i];
  }
  sum += Math.floor((Number(clean[8]) * 5) / 10);
  const remainder = (10 - (sum % 10)) % 10;
  return remainder === Number(clean[9]);
}

function maskPII(text, preserveEmail = false, preservePhone = false) {
  if (typeof text !== 'string') return text;
  let res = text
    // IPv6 주소 마스킹
    .replace(/(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/g, '[IP 마스킹]')
    // DB 접속 URL (사용자명 및 패스워드) 마스킹
    .replace(/(postgres|mysql|mongodb|redis|amqp):\/\/[^\s\/]+@([^\s]+)/gi, '$1://****:****@$2')
    .replace(/(postgres|mysql|mongodb|redis|amqp):\/\/([^:\s]+):([^@\s]+)@/gi, '$1://****:****@')
    // Stripe API 라이브 시크릿 키 마스킹
    .replace(/sk_live_[0-9a-zA-Z]{16,}/g, 'sk_live_****')
    // [FIND_008 해결] Slack API Bot/User/App Token 마스킹
    .replace(/xox[baprs]-[0-9a-zA-Z-]{20,}/g, 'xoxb-****')
    // [FIND_006 해결] Notion 공식 통합 토큰 (ntn_...) 마스킹
    .replace(/\bntn_[a-zA-Z0-9]{20,}\b/g, '[노션 토큰 마스킹]')
    // [FIND_002 해결] OpenAI API Secret Key 마스킹
    .replace(/sk-(?:proj-)?[0-9a-zA-Z_-]{20,}/g, 'sk-proj-****')
    // [FIND_001 해결] GitHub Fine-Grained Personal Access Token 마스킹
    .replace(/github_pat_[0-9a-zA-Z_]{20,}/g, 'github_pat_****')
    // GitHub Classic Personal Access Token 마스킹
    .replace(/(?:ghp|gho|ghu|ghs|ghr)_[0-9a-zA-Z]{20,}/g, 'ghp_****')
    // AWS Access Key ID 마스킹
    .replace(/(?:AKIA|ABIA|ACCA|ASIA)[0-9A-Z]{16}/g, 'AKIA****')
    // [FIND_009 & FIND_006 해결] 하이픈 있는 신용카드번호 마스킹 (16자리: 4자리-4자리-4자리-4자리)
    .replace(/(?<![0-9a-zA-Z가-힣])(?:\d{4}\s*[-]\s*){3}\d{4}(?![0-9a-zA-Z가-힣])/g, '****');

  if (!preservePhone) {
    // 국내 일반전화, 0505/0507 안심번호, 인터넷전화(070), 휴대폰(010~019), 국제전화(+82) 마스킹
    res = res.replace(/(?<![0-9a-zA-Z가-힣])(?:02|0[3-6][1-5]|050[2-7]|070|01[016789]|\+82\s*)\s*[-.]?\s*\d{3,4}\s*[-.]?\s*\d{4}(?![0-9])/g, '****');
  }

  res = res
    // [FIND_006 & FIND_002 해결] 하이픈 있는 주민등록번호 및 외국인등록번호(뒷자리 1~8) 마스킹
    .replace(/(?<![0-9a-zA-Z가-힣])\d{6}\s*[-]\s*[1-8]\d{6}(?![0-9a-zA-Z가-힣])/g, '******-*******')
    // [FIND_004 해결] 운전면허번호 마스킹
    .replace(/(?<![0-9a-zA-Z가-힣])\d{2}[-]\d{2}[-]\d{6}[-]\d{2}(?![0-9a-zA-Z가-힣])/g, '**-**-******-**')
    // [FIND_003 해결] 여권번호 마스킹
    .replace(/(?<![0-9a-zA-Z가-힣])[A-Z][0-9]{8}(?![0-9a-zA-Z가-힣])/g, 'M********')
    // [FIND_007 & FIND_006 & FIND_BOLTA_010] 국내 주요 은행 계좌번호 마스킹 (3~6자리 - 2~6자리 - 3~8자리) - 사업자등록번호(3-2-5자리) 제외
    .replace(/(?<![0-9a-zA-Z가-힣])(?!\d{3}-\d{2}-\d{5}(?![0-9a-zA-Z가-힣]))\d{3,6}[-]\d{2,6}[-]\d{3,8}(?![0-9a-zA-Z가-힣])/g, '[계좌번호 마스킹]')
    // [FIND_008 & FIND_006] 하이픈 없는 주민등록번호 마스킹 (13자리: 생년월일 6자리 + 뒷 7자리)
    .replace(/(?<![0-9a-zA-Z가-힣])\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{7}(?![0-9a-zA-Z가-힣])/g, '******')
    // [FIND_008 & FIND_006] 하이픈 없는 신용카드번호 마스킹 (15~16자리)
    .replace(/(?<![0-9a-zA-Z가-힣])(?:4\d{15}|5[1-5]\d{14}|6011\d{12}|3[47]\d{13}|\d{16})(?![0-9a-zA-Z가-힣])/g, '****')
    // [FIND_011 해결] 하이픈 없는 계좌번호 마스킹 (11~14자리 연속 숫자)
    .replace(/(?<![0-9a-zA-Z가-힣])\d{11,14}(?![0-9a-zA-Z가-힣])/g, '[계좌번호 마스킹]')
    // [FIND_011 & FIND_004 해결] 임원 급여 및 비자금/재무 민감 메모 및 연봉/희망급여 마스킹
    .replace(/(?:비자금|대외활동\s*비자금|임원\s*급여|비자금\s*계좌)/g, '[민감 정보 마스킹]')
    .replace(/(?:연봉|희망연봉|월급|급여|희망급여|이전\s*직장\s*연봉|희망\s*연봉)\s*[:=]?\s*[\d,]+(?:\s*만원|\s*원)?/gi, '[급여 정보 마스킹]')
    // [FIND_HR_LEAVE_009 해결] 민감 의료/질병/진단 정보 마스킹 (개인정보보호법 제23조 민감정보)
    .replace(/(?:유산|자궁\s*출혈|수술|임신\s*\d+주차|우울증|외상후스트레스장애|정신과|입원\s*치료)/g, '[민감 의료 정보 마스킹]')
    // [FIND_HR_LEAVE_010 해결] 슬랙 웹훅 검증 토큰 마스킹
    .replace(/[A-Za-z0-9_-]{20,}_SLACK_VERIFY_TOKEN/g, '[슬랙 토큰 마스킹]');

  if (!preserveEmail) {
    // [FIND_010] 우커머스 고객 이메일 마스킹
    res = res.replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g, '[이메일 마스킹]');
  }

  return res
    // [FIND_010] IPv4 주소 마스킹
    .replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g, '[IP 마스킹]')
    // 주소 마스킹
    .replace(/(?:서울시|서울특별시|경기도|[가-힣]{2,4}[시도])\s+[가-힣\d\s-]+?(?:동|로|길)\s+[\d-]+(?:\s*거주)?/g, '[주소 마스킹]');
}

// ============================================================================
// [디벨롭: L0~L4 5대 병목 전용 능동 방어 스위트 (Active Defect Defense Suite)]
// 실측 분석 Top 5 병목(BYPASS, API 429, IF오판, Undefined참조, SQLi) 사전 차단
// ============================================================================
function L0_preventBypassInflow(payload, requiredKeys = []) {
  requiredKeys = Array.isArray(requiredKeys) ? requiredKeys : [];
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return { valid: false, reason: 'INVALID_PAYLOAD_STRUCTURE', data: {} };
  }
  const keys = Object.keys(payload);
  if (keys.length === 0) {
    return { valid: false, reason: 'EMPTY_INFLOW_PAYLOAD_BYPASS_BLOCKED', data: {} };
  }
  if (requiredKeys.length > 0) {
    const missing = requiredKeys.filter(k => payload[k] === undefined || payload[k] === null || payload[k] === '');
    if (missing.length > 0) {
      return { valid: false, reason: `MISSING_REQUIRED_KEYS: ${missing.join(', ')}`, data: payload };
    }
  }
  return { valid: true, reason: 'INFLOW_PASSED', data: payload };
}

function L1_safePropertyAccess(obj, pathStr, defaultValue = null) {
  if (!obj || typeof obj !== 'object') return defaultValue;
  try {
    const parts = String(pathStr).split('.');
    let curr = obj;
    for (const p of parts) {
      if (curr === null || curr === undefined) return defaultValue;
      curr = curr[p];
    }
    return curr !== undefined ? curr : defaultValue;
  } catch (e) {
    return defaultValue;
  }
}

function L2_strictConditionEvaluate(val, operator, threshold) {
  if (val === undefined || val === null || val === '') return false;
  if (operator === 'equals') return String(val) === String(threshold);
  if (operator === 'not_equals') return String(val) !== String(threshold);
  if (operator === 'greater_than') return Number(val) > Number(threshold);
  if (operator === 'less_than') return Number(val) < Number(threshold);
  if (operator === 'in') return Array.isArray(threshold) && threshold.includes(val);
  return Boolean(val);
}

function L3_exponentialBackoffGate(attempt = 1, baseDelayMs = 500, maxDelayMs = 5000) {
  const safeAttempt = (typeof attempt === 'number' && Number.isFinite(attempt)) ? attempt : 1;
  const safeBase = (typeof baseDelayMs === 'number' && Number.isFinite(baseDelayMs)) ? baseDelayMs : 500;
  const safeMax = (typeof maxDelayMs === 'number' && Number.isFinite(maxDelayMs)) ? maxDelayMs : 5000;
  const delay = Math.min(safeMax, safeBase * Math.pow(2, Math.max(0, safeAttempt - 1)));
  const jitter = Math.floor(Math.random() * 200);
  return {
    shouldRetry: safeAttempt <= 4,
    waitMs: delay + jitter,
    circuitOpen: safeAttempt > 4
  };
}

function L4_zeroWidthAndSqlPurge(inputStr) {
  if (typeof inputStr !== 'string') return inputStr;
  let clean = inputStr.replace(/[\u200B\u200C\u200D\uFEFF\0]/g, '');
  clean = clean.replace(/(\b)(DROP\s+TABLE|UNION\s+SELECT|ALTER\s+TABLE|DELETE\s+FROM)(\b)/gi, '$1[SQL_BLOCKED]$3');
  return clean;
}

// ============================================================================
// [규칙성 엔진 1] 점수 정규화 및 내부 값 탐색기
// ============================================================================
function normalizeScore(n, field) {
  if (typeof n !== 'number' || isNaN(n) || !Number.isFinite(n)) return NaN;
  if (field === 'rating') {
    if (n < 0) return 0;
    if (n <= 5.5) return n;
    if (n <= 10) return (n / 10) * 5;
    if (n <= 100) return (n / 100) * 5;
    return NaN;
  }
  return n;
}

function getValidInner(obj) {
  if (!obj || typeof obj !== 'object') return undefined;
  const fields = ['rating', 'score', 'value', 'item_score', 'user_rating', 'star_count', 'grade', 'overall_rating', 'total_score', 'food_rating', 'service_rating', 'taste', 'delivery'];
  for (const f of fields) {
    if (obj[f] !== undefined && obj[f] !== null && obj[f] !== '') return obj[f];
  }
  return undefined;
}

// ============================================================================
// [규칙성 엔진 2] 구문론적 감성 중화기 (Syntactic Valence Engine)
// 개별 단어 수십 개 나열을 배제하고, 어휘 체계 및 결합 구문 규칙으로 감성 평가
// ============================================================================
function evaluateSyntacticValence(text) {
  if (!text || typeof text !== 'string') {
    return { isCrisis: false, isPraise: false, cleanedText: '', sarcasmDetected: false };
  }

  let normText = text.slice(0, 3000).replace(/\s+/g, ' ');

  // 1. 반어법/역설적 혹평 검출 ("5점이라더니 진짜 최악", "이게 5점짜리 식당인가요?")
  const sarcasmRegex = /([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)(?:이라더니|짜리\s*(?:식당|음식|가게|곳)?인가요|이라고\??|준다는\s*게)/i;
  const sarcasmDetected = sarcasmRegex.test(normText);

  // 2. 공공기관/위생 인증 호평 중화 규칙 (식약처/보건소/구청/위생과 + 인증/선정/우수/식당)
  const certPraiseRegex = /(?:식약처|보건소|구청|위생과)\s*(?:인증|지정|선정|표창|우수)?\s*(?:위생\s*식당|안심\s*식당|모범\s*음식점|맛집|위생등급|위생\s*점검\s*안심|위생점검\s*안심|위생\s*안심|위생안심)/gi;
  let cleanedText = normText.replace(certPraiseRegex, ' ');

  // 3. 구문 부정/안심 중화 규칙 ([위기어휘] + 0~3단어 + [안심접미사])
  const riskWords = [
    '벌레', '식중독', '장염', '노로바이러스', '병원', '배탈', '알레르기', '두드러기', '복통',
    '이물질', '머리카락', '쇳조각', '유리조각', '비닐', '침', '곰팡이', '신고', '경찰',
    '보건소', '구청', '식약처', '위생과', '영업정지', '소비자원', '소비자고발센터', '민원',
    '손해배상', '고발', '인권위', '기만', '배째라', '환불', '사기', '쓰레기', '상했', '쉰내',
    '누락', '오배송', '불친절', '식어서', '식었', '쏟아짐', '샜음', '파손'
  ].join('|');

  const peaceSuffixes = [
    '나올\\s*일\\s*없이', '나올\\s*걱정\\s*없이', '볼\\s*일\\s*없이', '버릴\\s*일\\s*없이',
    '걱정\\s*없이', '갈\\s*일\\s*없이', '걸릴\\s*일\\s*없이', '걱정없는', '안심하고', '안심',
    '탈\\s*없이', '없이', '없고', '안\\s*나고', '않고', '안\\s*하고', '튈\\s*걱정\\s*없이',
    '뱉을\\s*일\\s*없이', '할\\s*일\\s*없이', '넣을\\s*걱정\\s*없이', '넣을\\s*일\\s*없이'
  ].join('|');

  const peacePrefixRegex = new RegExp(`(?:${riskWords})\\s*(?:한\\s*마리|하나|한\\s*개|한\\s*올|핀\\s*거\\s*하나)?\\s*(?:전혀\\s*)?(?:\\s*[^.!?\\n\\s]{1,15}){0,3}\\s*(?:${peaceSuffixes})`, 'gi');
  const peaceSuffixRegex = new RegExp(`(?:${peaceSuffixes})\\s*(?:\\s*[^.!?\\n\\s]{1,15}){0,3}\\s*(?:${riskWords})`, 'gi');

  cleanedText = cleanedText
    .replace(peacePrefixRegex, ' ')
    .replace(peaceSuffixRegex, ' ')
    .replace(/사기적인\s*맛/gi, ' ');

  // 4. 핵심 위기 판별
  const coreRiskPattern = new RegExp(`(?:${riskWords}|바퀴벌레|최악|썩었|폭망|위세척|응급실|입원|119|중환자실|구급차|구토|설사|링거|수액|더러워)`, 'i');
  const isCrisis = coreRiskPattern.test(cleanedText);

  // 5. 호평 판별
  const praisePattern = /(?:맛있|인생|추천|최고|대박|친절|감사|깨끗|위생\s*최상|위생식당|안심식당|모범음식점|안심|만점|우수)/i;
  const isPraise = praisePattern.test(cleanedText) || certPraiseRegex.test(normText);

  return { isCrisis, isPraise, cleanedText, sarcasmDetected };
}

// ============================================================================
// [규칙성 엔진 3] 통합 척도 역산기 (Universal Scale Resolver)
// 수치, 분수, 백분율, 수사, 이모지, 척도 문장 등을 수학적 5점 척도로 일원화 변환
// ============================================================================
function resolveUniversalScale(val, reviewText, targetField = 'rating', depth = 0) {
  if (depth > 35) return NaN;

  if (typeof val === 'string') {
    if (val.length > 3000) val = val.slice(0, 3000);
    val = val.replace(/\s+/g, ' ');
  }
  if (typeof reviewText === 'string') {
    if (reviewText.length > 3000) reviewText = reviewText.slice(0, 3000);
    reviewText = reviewText.replace(/\s+/g, ' ');
  }

  while (Array.isArray(val)) {
    if (val.length === 0) return NaN;
    val = val[0];
  }

  if (val === null || val === undefined) {
    if (reviewText && typeof reviewText === 'string') {
      const valence = evaluateSyntacticValence(reviewText);
      if (valence.sarcasmDetected) return 1;

      const extractedScore = resolveUniversalScale(valence.cleanedText, undefined, targetField, depth + 1);
      if (!isNaN(extractedScore)) return extractedScore;

      if (valence.isCrisis) return 1;
      if (valence.isPraise) return NaN;
    }
    return NaN;
  }

  if (typeof val === 'symbol' || typeof val === 'boolean') return NaN;
  if (typeof val === 'object' && val !== null) {
    const innerVal = getValidInner(val);
    if (innerVal !== undefined) return resolveUniversalScale(innerVal, reviewText, targetField, depth + 1);
    return resolveUniversalScale(null, reviewText, targetField, depth + 1);
  }

  if (typeof val === 'number') {
    return normalizeScore(val, targetField);
  }

  const unicodeFractions = {
    '¾': 0.75, '⅝': 0.625, '⅚': 0.833, '½': 0.5, '¼': 0.25,
    '⅓': 0.333, '⅔': 0.667, '⅛': 0.125, '⅜': 0.375, '⅞': 0.875,
    '⅙': 0.167, '⅕': 0.2, '⅖': 0.4, '⅗': 0.6, '⅘': 0.8
  };

  let preStr = String(val);
  preStr = preStr.replace(/([0-9]+)\s*½/g, '$1.5')
                 .replace(/([0-9]+)\s*¼/g, '$1.25')
                 .replace(/([0-9]+)\s*¾/g, '$1.75')
                 .replace(/([0-9]+)\s*⅓/g, (m, p) => (Number(p) + 0.333).toFixed(3))
                 .replace(/([0-9]+)\s*⅔/g, (m, p) => (Number(p) + 0.667).toFixed(3))
                 .replace(/([0-9]+)\s*⅕/g, '$1.2')
                 .replace(/([0-9]+)\s*⅖/g, '$1.4')
                 .replace(/([0-9]+)\s*⅗/g, '$1.6')
                 .replace(/([0-9]+)\s*⅘/g, '$1.8');
  const rawStr = preStr.normalize('NFKC').replace(/[\u200B-\u200D\uFEFF]/g, '').trim();

  // 0점 구어체 매핑
  if (/^[★⭐☆🌟\s]*(?:별\s*)?(?:(?:점수|별점|평점)\s*[:：]?\s*)?(?:영점|빵점|영\s*점|빵\s*점|0점)(?:\s*(?:입니다|드립니다|줍니다|요))?$/i.test(rawStr) ||
      /(?:평점|별점|점수)\s*[:：]?\s*(?:영점|빵점|영\s*점|빵\s*점|0점)|(?:영점|빵점)\s*(?:드립니다|줍니다)/i.test(rawStr)) {
    return 0;
  }

  // 만점 매핑
  if (/^[★⭐☆🌟\s]*(?:별\s*)?(?:(?:점수|별점|평점)\s*[:：]?\s*)?만점(?:\s*(?:입니다|드립니다|줍니다|요))?$/i.test(rawStr) ||
      /(?:평점|별점|점수)\s*[:：]?\s*만점|만점\s*(?:드립니다|줍니다)/i.test(rawStr)) {
    return 5;
  }

  // 혼합 유니코드 분수 매칭
  const mixedFracMatch = rawStr.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?|つ?星)?\s*([¾⅝⅚½¼⅓⅔⅛⅜⅞⅙⅕⅖⅗⅘])/i);
  if (mixedFracMatch) {
    const intPart = parseFloat(mixedFracMatch[1]);
    const fracVal = unicodeFractions[mixedFracMatch[2]] || 0;
    return normalizeScore(intPart + fracVal, targetField);
  }
  for (const [fracChar, fracVal] of Object.entries(unicodeFractions)) {
    if (rawStr.includes(fracChar)) {
      return normalizeScore(fracVal, targetField);
    }
  }

  // 비라틴 유니코드 숫자 ASCII 변환
  function convertUnicodeDigitsToAscii(inputStr) {
    return inputStr.replace(/[\u0660-\u0669\u06F0-\u06F9\u0966-\u096F\u0E50-\u0E59]/g, ch => {
      const code = ch.charCodeAt(0);
      if (code >= 0x0660 && code <= 0x0669) return String(code - 0x0660);
      if (code >= 0x06F0 && code <= 0x06F9) return String(code - 0x06F0);
      if (code >= 0x0966 && code <= 0x096F) return String(code - 0x0966);
      if (code >= 0x0E50 && code <= 0x0E59) return String(code - 0x0E50);
      return ch;
    });
  }
  let str = convertUnicodeDigitsToAscii(rawStr);
  if (str === '') return NaN;

  // 불만족 이모지 평점 지원
  const emojiMap = { '👎': 1, '🤮': 1, '💩': 1, '😡': 1 };
  for (const [em, sc] of Object.entries(emojiMap)) {
    if (str.includes(em)) {
      const numMatch = str.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)/);
      if (numMatch) return normalizeScore(Number(numMatch[1]), targetField);
      return normalizeScore(sc, targetField);
    }
  }

  // 기호 표준화
  str = str.replace(/[\/⁄\\＼∕／]/g, '/');
  str = str.replace(/([0-9]+(?:\.[0-9]+)?)\s*(?:과|와)\s*([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?\s*[\/⁄\\＼∕／]\s*([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?/gi, (match, p1, p2, p3) => {
    const total = Number(p1) + (Number(p2) / Number(p3));
    return ' ' + total + '점 ';
  });
  str = str.replace(/[〜～]/g, '~');
  str = str.replace(/([0-9])\s*,\s*([0-9])/g, '$1.$2');
  str = str.replace(/([0-9])\s*\.\s*([0-9])/g, '$1.$2');
  str = str.replace(/(?:^|[^\d])\s*\.\s*([0-9]+)/g, ' 0.$1');

  // "반 개" -> 0.5
  if (/(?:^|[^\d])별?\s*반\s*개(?:\s*드립니다|\s*만)?(?:\s*[\p{Emoji}\u2000-\u3300])*$/iu.test(str) ||
      /(?:^|[^\d])별점\s*반\s*개(?:\s*드립니다|\s*만)?(?:\s*[\p{Emoji}\u2000-\u3300])*$/iu.test(str) ||
      /^반\s*개$/i.test(str)) {
    return normalizeScore(0.5, targetField);
  }

  // 한글 고유어 수사 평점
  const nativeKoreanMap = {
    '하나': 1, '한': 1, '한개': 1,
    '둘': 2, '두': 2, '두개': 2,
    '셋': 3, '세': 3, '세개': 3,
    '넷': 4, '네': 4, '네개': 4,
    '다섯': 5
  };
  const nativeMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?(하나|한|둘|두|셋|세|넷|네|다섯)\s*(?:개|점|stars?|つ?星)?(?:\s*(?:요|임|용|이요|짜리|만|입니다|대))?(?:\s*드립니다)?$/i);
  if (nativeMatch) {
    const mapped = nativeKoreanMap[nativeMatch[1]];
    if (mapped !== undefined) return normalizeScore(mapped, targetField);
  }
  const nativeSimpleMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s+)(하나|둘|셋|넷|다섯)(?:\s*(?:요|임|용|이요|짜리|만|입니다|대))?$/i);
  if (nativeSimpleMatch) {
    const mapped = nativeKoreanMap[nativeSimpleMatch[1]];
    if (mapped !== undefined) return normalizeScore(mapped, targetField);
  }
  const embeddedNativeMatch = str.match(/(?:별\s+)?(하나|한|둘|두|셋|세|넷|네|다섯)\s*(?:개|점|stars?|つ?星)(?:[도만]?\s*(?:아깝|아깝습니다|아까움))?(?:\s*(?:드립니다|줍니다|요|임|용|이요|짜리|입니다))?|(?:별\s*)(하나|한|둘|두|셋|세|넷|네|다섯)(?:\s*(?:개|점|stars?|つ?星))?(?:[도만]?\s*(?:아깝|아깝습니다|아까움))?(?:\s*(?:드립니다|줍니다|요|임|용|이요|짜리|입니다))?/i);
  if (embeddedNativeMatch) {
    const rawWord = embeddedNativeMatch[1] || embeddedNativeMatch[2];
    const mapped = nativeKoreanMap[rawWord];
    if (mapped !== undefined) return normalizeScore(mapped, targetField);
  }

  // 한자어 음운 수사 평점
  const sinoKoreanPhoneticMap = { '일': 1, '이': 2, '삼': 3, '사': 4, '오': 5 };
  const sinoWordMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?(?:(?:점수|별점|평점)\s*[:：]\s*)?(일|이|삼|사|오)\s*(?:점|개|stars?)(?:\s*(?:입니다|드립니다|줍니다|요))?$/i);
  if (sinoWordMatch) return normalizeScore(sinoKoreanPhoneticMap[sinoWordMatch[1]], targetField);
  const embeddedSinoMatch = str.match(/(?:(?:점수|별점|평점)\s*[:：]?\s*)(일|이|삼|사|오)\s*(?:점|개|stars?)(?:\s*(?:입니다|드립니다|줍니다|요))?/i);
  if (embeddedSinoMatch) return normalizeScore(sinoKoreanPhoneticMap[embeddedSinoMatch[1]], targetField);
  const embeddedSinoSimple = str.match(/(일|이|삼|사|오)\s*(?:점|개|stars?)\s*(?:드립니다|줍니다)/i);
  if (embeddedSinoSimple) return normalizeScore(sinoKoreanPhoneticMap[embeddedSinoSimple[1]], targetField);

  // 로마 숫자 평점
  const romanMap = {
    'Ⅰ': 1, 'Ⅱ': 2, 'Ⅲ': 3, 'Ⅳ': 4, 'Ⅴ': 5,
    'ⅰ': 1, 'ⅱ': 2, 'ⅲ': 3, 'ⅳ': 4, 'ⅴ': 5,
    'I': 1, 'II': 2, 'III': 3, 'IV': 4, 'V': 5
  };
  const romanMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?([ⅠⅡⅢⅣⅤⅰⅱⅲⅳⅴ]|I{1,3}|IV|V)\s*(?:점|개|stars?)?(?:\s*드립니다)?$/i);
  if (romanMatch) {
    const rawRoman = romanMatch[1];
    const mapped = romanMap[rawRoman.toUpperCase()] || romanMap[rawRoman];
    if (mapped !== undefined) return normalizeScore(mapped, targetField);
  }

  // 한자/동아시아 수사 평점
  const eastAsianMap = { '一': 1, '二': 2, '三': 3, '四': 4, '五': 5 };
  const eaMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?([一二三四五])\s*(?:개|점|つ?星|star|stars?)(?:\s*드립니다)?$/i);
  if (eaMatch) return normalizeScore(eastAsianMap[eaMatch[1]], targetField);

  // 영문 수사 평점
  const englishWordMap = { 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5 };
  const engWordMatch = str.match(/^[★⭐☆🌟\s]*(?:별\s*)?(one|two|three|four|five)\s*(?:star|stars|points?|점|개)\b(?!\s*(?:out\s+of|of))/i);
  if (engWordMatch) return normalizeScore(englishWordMap[engWordMatch[1].toLowerCase()], targetField);

  // 척도 역산 ("10점 만점에 10점", "100점 중 5점", "100점에 5점")
  const scaleMatch = str.match(/([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:개|점)?\s*(?:만점\s*(?:에|중|에서|기준)?|(?:점|개)\s*(?:만점\s*(?:에|중|에서|기준)?|에|중|에서|기준|만점기준|만점\s*기준))\s*([0-9]+(?:\.[0-9]+)?|\.[0-9]+)(?!\s*(?:등|위|호점|번째|번|순위|차|회))\s*(?:개|점)?/i);
  if (scaleMatch) {
    const scaleBase = Number(scaleMatch[1]);
    const scaleScore = Number(scaleMatch[2]);
    if (!isNaN(scaleBase) && !isNaN(scaleScore) && scaleBase > 0) {
      return targetField === 'rating' ? (scaleBase === 5 ? scaleScore : (scaleScore / scaleBase) * 5) : scaleScore;
    }
  }

  // 역순 척도 역산 ("1점 (5점 만점)", "1점 (10점 만점)")
  const reverseScaleMatch = str.match(/([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:개|점)?\s*\(?\s*([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:개|점)?\s*만점\s*\)?/i);
  if (reverseScaleMatch) {
    const scaleScore = Number(reverseScaleMatch[1]);
    const scaleBase = Number(reverseScaleMatch[2]);
    if (!isNaN(scaleBase) && !isNaN(scaleScore) && scaleBase > 0) {
      return targetField === 'rating' ? (scaleBase === 5 ? scaleScore : (scaleScore / scaleBase) * 5) : scaleScore;
    }
  }

  // 비교 문맥 제거
  let strWithoutComparison = str
    .replace(/\([^)]*(?:다른|속아서|속았|사기|광고|알바|조작|가짜|의심|배달앱|인스타|블로그)[^)]*\)/gi, ' ')
    .replace(/(?:다른|속아서|속았|사기|광고|알바|조작|가짜|배달앱|인스타|블로그)\s*(?:리뷰|사람|평점|후기)?[^.!?\n]*?([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)/gi, ' ')
    .replace(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)(?:\s*만점\s*(?:맛집|식당|곳)?이라더니|\s*주는\s*사람들은|\s*리뷰\s*보고\s*시켰는데|\s*평점)?\s*(?:사기|알바|조작|가짜|낚였|낚임|의심|의혹)/gi, ' ');

  // 하이픈/물결 범위 평점 -> 평균값 치환
  strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\.[0-9]+)?)\s*[-~−–—〜～]\s*([0-9]+(?:\.[0-9]+)?)\s*(점|개|stars?|つ?星)?/gi, (match, p1, p2, unit) => {
    const avg = (Number(p1) + Number(p2)) / 2;
    return ' ' + avg + (unit || '') + ' ';
  });

  // 반어법/역설적 혹평 마스킹
  const sarcasticRegex = /([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)(?:이라더니|짜리\s*(?:식당|음식|가게|곳)?인가요|이라고\??|준다는\s*게)/i;
  strWithoutComparison = strWithoutComparison.replace(sarcasticRegex, ' ');

  // 할인율/쿠폰 마스킹
  strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\.[0-9]+)?)\s*%\s*(?:할인|쿠폰|적립|캐시백|세일)?/gi, ' ');

  // 날짜 마스킹 (1/5, 1/10, 1/100 분수 보존)
  // [FIND_R22_002 해결] (?!\s*) 표준화로 분수와 단위 사이 공백 지원
  strWithoutComparison = strWithoutComparison.replace(/\b(?:0?[1-9]|1[0-2])\s*[/⁄\\＼]\s*(?:0?[1-9]|[12][0-9]|3[01])\b(?!\s*(?:점|개|stars?|つ?星|만점))/gi, (match) => {
    const parts = match.split(/[/⁄\\＼]/);
    const d = Number(parts[1]);
    if (d === 5 || d === 10 || d === 100) return match;
    return ' ';
  });
  strWithoutComparison = strWithoutComparison.replace(/(?:방문일|주문일|방문|주문|포장|배달)?\s*[:=\s]?\s*(?:20[0-9]{2}[/.-][0-9]{1,2}[/.-][0-9]{1,2}|[0-9]{1,2}\s*[/]\s*[0-9]{1,2}\s*(?:주문|방문|포장|배달|결제|이용|배송))\s*/gi, ' ');
  strWithoutComparison = strWithoutComparison.replace(/(?:v|ver\.?)\s*[0-9]+(?:\.[0-9]+)+(?:\s*(?:버전|빌드|업데이트))?|[0-9]+(?:\.[0-9]+)+\s*(?:버전|빌드|업데이트)|버전\s*[0-9]+(?:\.[0-9]+)+/gi, ' ');
  strWithoutComparison = strWithoutComparison.replace(/(?:만점|점|개)\s*(?:에|중|에서)?\s*([0-9]+(?:\.[0-9]+)?)\s*(?:등|위|호점|번째|번\s*추천|순위|차|회)/gi, ' ');
  strWithoutComparison = strWithoutComparison.replace(/([0-9]+(?:\.[0-9]+)?)\s*(?:등|위|호점|번째|번\s*추천|순위)\b/gi, ' ');
  strWithoutComparison = strWithoutComparison.replace(/([0-9]+)\s*개\s*(?:더|포장|주문|먹|시켰|구매|추가|사|남김|배달)/gi, ' ');
  strWithoutComparison = strWithoutComparison.replace(/\b[0-9]{1,2}\s*[:]\s*[0-9]{2}\s*(?:에|경|쯤|시|분|초|주문|방문|포장|배달|결제|이용|배송)?/gi, ' ');

  // ASCII 혼합 분수 매칭 (4 1/2점)
  const asciiMixedMatch = strWithoutComparison.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?|つ?星)?\s+([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?\s*[\/⁄\\＼]\s*([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?(?!\s*(?:주문|방문|포장|배달|결제|이용|배송))/i);
  if (asciiMixedMatch) {
    const intPart = parseFloat(asciiMixedMatch[1]);
    const num = parseFloat(asciiMixedMatch[2]);
    const denom = parseFloat(asciiMixedMatch[3]);
    if (!isNaN(intPart) && !isNaN(num) && !isNaN(denom) && denom > 0 && denom <= 100 && (denom === 100 || denom === 10 || denom === 5 || num <= 31 || num <= denom)) {
      return normalizeScore(intPart + (num / denom), targetField);
    }
  }

  // 분수 매칭 (35/100, 1/5, 2/5 등)
  const fractionMatch = strWithoutComparison.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?\s*[\/⁄\\＼]\s*([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?(?!\s*(?:주문|방문|포장|배달|결제|이용|배송))/i);
  if (fractionMatch) {
    const num = Number(fractionMatch[1]);
    const denom = Number(fractionMatch[2]);
    if (!isNaN(num) && !isNaN(denom) && denom > 0 && denom <= 100 && (denom === 100 || denom === 10 || denom === 5 || num <= 31 || num <= denom)) {
      return targetField === 'rating' ? (num / denom) * 5 : num / denom;
    }
  }

  // 비율 척도 (1:5)
  const ratioMatch = strWithoutComparison.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?)?\s*[:]\s*([0-9]+(?:\.[0-9]+)?)\b\s*(?:점|개|stars?)?(?!\s*(?:에|경|쯤|시|분|초|주문|방문|포장|배달|결제|이용|배송))/i);
  if (ratioMatch) {
    const num = Number(ratioMatch[1]);
    const denom = Number(ratioMatch[2]);
    if (!isNaN(num) && !isNaN(denom) && denom > 0 && denom <= 100) {
      return targetField === 'rating' ? (num / denom) * 5 : num / denom;
    }
  }

  // 별 이모지 파싱 및 텍스트 교차 검증
  if (/[★⭐☆🌟]/.test(str)) {
    if (reviewText && typeof reviewText === 'string') {
      const textNorm = reviewText.normalize('NFKC').replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
      const isExplicitBad = /(?:[1-2]점|별\s*(?:하나|한\s*개|1개)|최악|쓰레기|환불|고소|썩었|폭망)/i.test(textNorm);
      const isExplicitGood = /(?:5점\s*만점|5점|별\s*(?:다섯|5개)|최고|인생맛집|대박)/i.test(textNorm);
      const filledStars = (str.match(/[★⭐🌟]/g) || []).length;
      if (filledStars >= 4 && isExplicitBad) return 1;
      if (filledStars <= 2 && isExplicitGood) return 5;
    }

    const hasExplicitNumberWithUnit = /(?:[0-9]+(?:\.[0-9]+)?|[一二三四五]|one|two|three|four|five|하나|한|둘|두|셋|세|넷|네|다섯)\s*(?:점|개|stars?|points?|つ?星)/i.test(strWithoutComparison);
    if (!hasExplicitNumberWithUnit) {
      const filledStars = (str.match(/[★⭐🌟]/g) || []).length;
      const emptyStars = (str.match(/[☆]/g) || []).length;
      if (filledStars > 0 || emptyStars > 0) {
        if (filledStars === 0 && emptyStars > 0) return 0;
        if (filledStars >= 1 && filledStars <= 5) return filledStars;
        if (filledStars === 0) return 0;
      }
    }
  }

  // 영문 척도 ("1 star out of 5 stars")
  const engScaleMatch = strWithoutComparison.match(/(one|two|three|four|five|[0-9]+(?:\.[0-9]+)?)\s*(?:stars?|points?|점)?\s*(?:out\s+of|of)\s*(one|two|three|four|five|[0-9]+(?:\.[0-9]+)?)\s*(?:stars?|points?|점)?/i);
  if (engScaleMatch) {
    const sVal = englishWordMap[engScaleMatch[1].toLowerCase()] || Number(engScaleMatch[1]);
    const bVal = englishWordMap[engScaleMatch[2].toLowerCase()] || Number(engScaleMatch[2]);
    if (!isNaN(sVal) && !isNaN(bVal) && bVal > 0) return targetField === 'rating' ? (sVal / bVal) * 5 : sVal;
  }

  // 다국어 척도 ("1 out of 5 stars", "1 de 5")
  const multiScaleMatch = strWithoutComparison.match(/([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:stars?|étoiles?|sternen?|estrellas?|점|개)?\s*(?:out\s+of|of|de|sobre|sur|von|su)\s*([0-9]+(?:\.[0-9]+)?|\.[0-9]+)\s*(?:stars?|étoiles?|sternen?|estrellas?|점|개)?/i);
  if (multiScaleMatch) {
    const score = Number(multiScaleMatch[1]);
    const base = Number(multiScaleMatch[2]);
    if (!isNaN(score) && !isNaN(base) && base > 0) return targetField === 'rating' ? (score / base) * 5 : score;
  }

  // 지수 표기법 (5e0, 1e0)
  const expMatch = strWithoutComparison.match(/\b([0-9]+(?:\.[0-9]+)?e[+\-]?[0-9]+)\b\s*(?:점|개|stars?)?/i);
  if (expMatch) {
    const n = Number(expMatch[1]);
    if (!isNaN(n)) return normalizeScore(n, targetField);
  }

  // Key-value 평점 ("평점: 5", "score: 5")
  const colonMatch = strWithoutComparison.match(/(?:평점|score|rating|별점)\s*[:=\-]\s*([0-9]+(?:\.[0-9]+)?|\.[0-9]+)/i);
  if (colonMatch) {
    const n = Number(colonMatch[1]);
    if (!isNaN(n)) return normalizeScore(n, targetField);
  }

  // 단위 수치 매칭 ("1점", "5점", "맛 1점 양 5점")
  const unitRegex = /([0-9]+(?:\.[0-9]+)?)\s*(?:점|개|stars?|points?|つ?星)/gi;
  const unitMatches = [...strWithoutComparison.matchAll(unitRegex)];
  if (unitMatches.length > 0) {
    const parsedValues = unitMatches.map(m => Number(m[1])).filter(v => !isNaN(v));
    const badScore = parsedValues.find(v => v < 3);
    const chosen = (badScore !== undefined) ? badScore : parsedValues[parsedValues.length - 1];
    return normalizeScore(chosen, targetField);
  }

  // 비단위 분리 수치 매칭
  const nonContextMatches = strWithoutComparison.match(/[0-9]+(?:\.[0-9]+)?/g);
  if (nonContextMatches) {
    const numValues = nonContextMatches.map(Number).filter(v => !isNaN(v));
    if (numValues.length > 0) {
      const badVal = numValues.find(v => v < 3);
      const chosen = (badVal !== undefined) ? badVal : numValues[numValues.length - 1];
      return normalizeScore(chosen, targetField);
    }
  }

  return NaN;
}

// [FIND_014, FIND_015, FIND_007, FIND_008 해결] 2차 중첩 스키마 및 카카오톡 CS 문의(userRequest.utterance) 판별
function isReviewData(d) {
  if (!d || typeof d !== 'object') return false;
  const candidateObjs = [
    d,
    d.review,
    d.payload,
    d.feedback,
    d.data,
    d.response,
    d.userRequest,
    d.userRequest?.user,
    ...(Array.isArray(d.reviews) ? d.reviews : []),
    ...(Array.isArray(d.items) ? d.items : []),
    ...(Array.isArray(d.data?.reviews) ? d.data.reviews : []),
    ...(Array.isArray(d.response?.items) ? d.response.items : [])
  ].filter(x => x && typeof x === 'object');
  return candidateObjs.some(obj => (
    obj.rating !== undefined || obj.review_text !== undefined || obj.score !== undefined ||
    obj.nps_score !== undefined || obj.survey_id !== undefined ||
    obj.comment !== undefined || obj.value !== undefined || obj.feedback !== undefined ||
    obj.content !== undefined || obj.text !== undefined || obj.user_rating !== undefined ||
    obj.item_score !== undefined || obj.star_count !== undefined || obj.grade !== undefined ||
    obj.review_detail !== undefined || obj.utterance !== undefined || obj.message !== undefined ||
    obj.inquiry !== undefined ||
    obj.overall_rating !== undefined || obj.total_score !== undefined ||
    obj.food_rating !== undefined || obj.service_rating !== undefined ||
    obj.taste !== undefined || obj.delivery !== undefined
  )) || d.userRequest !== undefined || typeof d.utterance === 'string' || d.survey_id !== undefined || d.nps_score !== undefined || d.feedback !== undefined;
}

const CHAOS_SIGNATURES = {
  // L1: 프로토콜 및 네트워크 6종
  L1_DNS_TIMEOUT: {
    match: (d) => d.dns_error || d.code === 'EAI_AGAIN' || (typeof d.error_message === 'string' && (d.error_message.includes('EAI_AGAIN') || d.error_message.includes('ETIMEDOUT'))),
    remedy: (d) => {
      d.dns_fallback_socket = '8.8.8.8';
      d.dns_flushed = true;
      d.healing_applied = 'DNS 캐시 플러시 및 8.8.8.8 보조 소켓 자동 페일오버';
      return d;
    }
  },
  L1_SSL_HANDSHAKE_FAIL: {
    match: (d) => d.ssl_error || (typeof d.error_message === 'string' && (d.error_message.includes('SSL') || d.error_message.includes('TLS'))),
    remedy: (d) => {
      d.tls_version = 'TLSv1.3';
      d.ca_reloaded = true;
      d.healing_applied = 'TLS 1.2/1.3 암호화 스위트 자동 교정 및 로컬 CA 저장소 리로드';
      return d;
    }
  },
  L1_TCP_SOCKET_HANG: {
    match: (d) => {
      if (isReviewData(d)) return false;
      return d.hang_seconds >= 90 || d.socket_hung === true;
    },
    remedy: (d) => {
      d.socket_rst = true;
      d.deadman_escalated = true;
      d.status = 'ALARM_DISPATCHED';
      d.healing_applied = '고착 소켓 강제 종료(TCP RST) 및 90초 데드맨 스위치 비상 알림 발송';
      return d;
    }
  },
  L1_CLIENT_BROKEN_PIPE: {
    match: (d) => d.code === 'ECONNRESET' || d.broken_pipe === true,
    remedy: (d) => {
      d.async_queue_dispatched = true;
      d.healing_applied = '비동기 작업 큐로 분리하여 클라이언트 단선과 무관하게 백그라운드 완주';
      return d;
    }
  },
  L1_CONNECTION_POOL_EXHAUST: {
    match: (d) => d.code === 'EADDRINUSE' || d.pool_exhausted === true,
    remedy: (d) => {
      d.pool_recycled = true;
      d.healing_applied = '유휴 커넥션 즉시 회수(Recycle) 및 소켓 풀 자동 확장';
      return d;
    }
  },
  L1_MTU_FRAGMENTATION: {
    match: (d) => d.packet_fragmented === true || d.mtu_corrupt === true,
    remedy: (d) => {
      d.chunk_buffer_bytes = 1400;
      d.healing_applied = '스트리밍 청크 버퍼 크기 1400바이트로 축소 및 재시도';
      return d;
    }
  },

  // L2: 페이로드 및 인코딩 6종
  L2_NULL_BYTE_INJECTION: {
    match: (d) => {
      try {
        const s = JSON.stringify(d);
        return typeof s === 'string' && (s.indexOf('\x00') !== -1 || s.indexOf('\\u0000') !== -1 || /\x00|\\u0000/.test(s));
      } catch (e) {
        return false;
      }
    },
    remedy: (d) => {
      function deepStripNull(obj) {
        if (!obj || typeof obj !== 'object') return obj;
        if (Array.isArray(obj)) return obj.map(deepStripNull);
        for (const k of Object.keys(obj)) {
          if (typeof obj[k] === 'string') {
            obj[k] = obj[k].replace(/\x00|\u0000/g, '');
          } else if (typeof obj[k] === 'object') {
            deepStripNull(obj[k]);
          }
        }
        return obj;
      }
      deepStripNull(d);
      d.healing_applied = '재귀 심층 필터에서 Null 바이트(\\x00) 전역 제거 후 안전 복원';
      return d;
    }
  },
  L2_BROKEN_UTF8_SEQUENCE: {
    match: (d) => d.utf8_corrupt === true || (typeof d.error_message === 'string' && d.error_message.includes('UTF-8')),
    remedy: (d) => {
      d.utf8_sanitized = true;
      d.healing_applied = 'U+FFFD 치환 문자로 안전 복원 후 로컬 DB 저장';
      return d;
    }
  },
  L2_BOM_HEADER_POLLUTION: {
    match: (d) => {
      try {
        const s = JSON.stringify(d);
        return typeof s === 'string' && s.indexOf('\uFEFF') !== -1;
      } catch (e) {
        return false;
      }
    },
    remedy: (d) => {
      function deepStripBOM(obj) {
        if (!obj || typeof obj !== 'object') return obj;
        if (Array.isArray(obj)) return obj.map(deepStripBOM);
        for (const k of Object.keys(obj)) {
          if (typeof obj[k] === 'string') {
            obj[k] = obj[k].replace(/^\uFEFF/, '').replace(/\uFEFF/g, '');
          } else if (typeof obj[k] === 'object') {
            deepStripBOM(obj[k]);
          }
        }
        return obj;
      }
      deepStripBOM(d);
      d.healing_applied = '재귀 심층 필터에서 BOM 바이트(\\uFEFF) 전역 자동 절삭';
      return d;
    }
  },
  L2_UNESCAPED_CONTROL_CHARS: {
    match: (d) => d.unescaped_control === true || (typeof d.raw_text === 'string' && /[\x00-\x1F\x7F]/.test(d.raw_text)),
    remedy: (d) => {
      if (d.raw_text && typeof d.raw_text === 'string') {
        d.raw_text = d.raw_text.replace(/[\n\r\t]/g, (c) => c === '\n' ? '\\n' : c === '\r' ? '\\r' : '\\t');
      }
      d.healing_applied = '정규식 기반 제어문자 자동 이스케이프(\\n, \\t) 후 재파싱';
      return d;
    }
  },
  L2_EMOJI_SURROGATE_TRUNC: {
    match: (d) => d.surrogate_truncated === true || (typeof d.raw_text === 'string' && typeof d.raw_text.split === 'function' && d.raw_text.split('').some(c => c.charCodeAt(0) >= 0xD800 && c.charCodeAt(0) <= 0xDBFF)),
    remedy: (d) => {
      if (d.raw_text && typeof d.raw_text === 'string') {
        let cleanText = '';
        for (let i = 0; i < d.raw_text.length; i++) {
          const code = d.raw_text.charCodeAt(i);
          if (code >= 0xD800 && code <= 0xDBFF) {
            const next = (i + 1 < d.raw_text.length) ? d.raw_text.charCodeAt(i + 1) : 0;
            if (next >= 0xDC00 && next <= 0xDFFF) {
              cleanText += d.raw_text[i] + d.raw_text[i + 1];
              i++;
            } else {
              cleanText += ' ';
            }
          } else if (code >= 0xDC00 && code <= 0xDFFF) {
            cleanText += ' ';
          } else {
            cleanText += d.raw_text[i];
          }
        }
        d.raw_text = cleanText;
      }
      d.healing_applied = '불완전한 서로게이트 페어 탐지 및 안전 공백 치환';
      return d;
    }
  },
  L2_ZERO_WIDTH_SPACE: {
    match: (d) => {
      try {
        const s = JSON.stringify(d);
        return typeof s === 'string' && (s.indexOf('\u200B') !== -1 || Object.values(d).some(v => typeof v === 'string' && (v.indexOf('\u200B') !== -1 || v.indexOf('\u200C') !== -1 || v.indexOf('\u200D') !== -1)));
      } catch (e) {
        return false;
      }
    },
    remedy: (d) => {
      // 보안 인가 결정 필드(telegram_approval_override 등)에 제로 너비 공백, BiDi, 제어 문자 변조 시 자동 승격 금지 및 FAIL_CLOSED_REJECTED 격리
      const authFields = ['telegram_approval_override', 'approval_override', 'auth_token', 'telegram_approval_status'];
      for (const authField of authFields) {
        if (typeof d[authField] === 'string' && /[\u200B-\u200D\uFEFF\u202A-\u202E\x00-\x1F]/.test(d[authField])) {
          d.status = 'FAIL_CLOSED_REJECTED';
          d.quarantined = true;
          d.telegram_approval_status = 'TAMPERED_APPROVAL_REJECTED';
          d.quarantine_reason = 'TAMPERED_APPROVAL_TOKEN_INJECTION';
          d.healing_applied = '인가 토큰 내 제로 너비/제어 문자 변조 주입 탐지 즉시 Fail-Closed 거부 및 격리';
          return d;
        }
      }
      function deepSanitizeZWSP(obj) {
        if (!obj || typeof obj !== 'object') return obj;
        if (Array.isArray(obj)) return obj.map(deepSanitizeZWSP);
        for (const k of Object.keys(obj)) {
          if (authFields.includes(k)) continue;
          if (typeof obj[k] === 'string') {
            obj[k] = obj[k].replace(/[\u200B-\u200D\uFEFF]/g, '');
          } else if (typeof obj[k] === 'object' && obj[k] !== null) {
            deepSanitizeZWSP(obj[k]);
          }
        }
        return obj;
      }
      deepSanitizeZWSP(d);
      d.healing_applied = '정규식 [\\u200B-\\u200D\\uFEFF] 전역 제거 후 정규화';
      return d;
    }
  },
  // [FIND_R27_002, FIND_005, FIND_006, FIND_003, FIND_004, FIND_009 해결] 프롬프트 인젝션 및 XSS 악성 지시어 차단
  L2_PROMPT_INJECTION_XSS_ATTACK: {
    match: (d) => {
      // [FIND_003, FIND_004, FIND_009, FIND_R22_006 해결] <img> 오탐 제거, [SYSTEM] 일반 커밋 분리, 일반 HTML5 태그(<div/b/p/h1...> 등) 포함 모든 이벤트 핸들러 공격 벡터 포괄 차단
      const promptInjectionRegex = /(?:\[\s*SYSTEM\s*(?:OVERRIDE|PROMPT|INSTRUCTION|DIRECTIVE|MESSAGE)\b|IGNORE\s+PREVIOUS|DISREGARD\s+PREVIOUS|SYSTEM\s*OVERRIDE|<script\b|<iframe\b|<svg\b|<object\b|<embed\b|<[a-zA-Z1-6]+\b[^>]*\bon[a-zA-Z]+\s*=|javascript:\s*|지침\s*무효화|지침\s*파기|지침\s*무시|지시\s*무시|이전\s*지침|이전\s*지시|명령\s*무시|긴급도.*HIGH.*지정|1000\s*만원\s*보상|법적\s*책임\s*100%|We\s*admit\s*100%\s*legal\s*fault)/i;
      const legitSystemErrorReportRegex = /(?:오류|에러|장애|중단|보고|코드|발생|접수)/i;
      const legalClaimRegex = /(?:1000\s*만원\s*보상|법적\s*책임\s*100%|We\s*admit\s*100%\s*legal\s*fault)/i;
      const coreJailbreakRegex = /(?:\[\s*SYSTEM\s*(?:OVERRIDE|PROMPT|INSTRUCTION|DIRECTIVE|MESSAGE)\b|IGNORE\s+PREVIOUS|DISREGARD\s+PREVIOUS|SYSTEM\s*OVERRIDE|<script\b|<iframe\b|<svg\b|<object\b|<embed\b|<[a-zA-Z1-6]+\b[^>]*\bon[a-zA-Z]+\s*=|javascript:\s*|지침\s*무효화|지침\s*파기|지침\s*무시|지시\s*무시|이전\s*지침|이전\s*지시|명령\s*무시|긴급도.*HIGH.*지정)/i;

      const getStrings = (obj, depth = 0, inLineItems = false) => {
        if (!obj || depth > 5) return [];
        let strs = [];
        if (typeof obj === 'string') return [{ str: obj, inLineItems, key: '' }];
        if (typeof obj === 'object') {
          for (const [k, v] of Object.entries(obj)) {
            const isLineItems = inLineItems || k === 'line_items' || k === 'items';
            if (typeof v === 'string') strs.push({ str: v, inLineItems: isLineItems, key: k });
            else if (typeof v === 'object' && v !== null) strs.push(...getStrings(v, depth + 1, isLineItems));
          }
        }
        return strs;
      };
      const allStrs = getStrings(d);
      return allStrs.some(item => {
        const s = item.str || '';
        // [FIND_009 해결] WooCommerce / eCommerce line_items 상품 품명 내 기술 서적/용어(<script> 입문 등) 오탐 방지
        if (item.inLineItems && (item.key === 'name' || item.key === 'title' || item.key === 'product_name')) {
          if (!/<script\b[^>]*>[\s\S]*?<\/script>/i.test(s) && !/<script\b[^>]*src\s*=/i.test(s) && !/<script\b[^>]*>(?:alert|eval|document|window|fetch|XMLHttpRequest|location)/i.test(s)) {
            return false;
          }
        }
        // [FIND_004 해결] 정상적인 개발 커밋/시스템 인프라 변경 접두사 [SYSTEM] 예외 가드
        if (s.includes('[SYSTEM]') && /(?:Optimize|Improve|Fix|Add|Update|Feature|Refactor|Changelog|Release|worker|thread|daemon|pool|limits)/i.test(s)) {
          if (!/(?:IGNORE\s+PREVIOUS|DISREGARD\s+PREVIOUS|SYSTEM\s*OVERRIDE|<script\b|<iframe\b|<svg\b)/i.test(s)) {
            return false;
          }
        }
        if (!promptInjectionRegex.test(s)) return false;

        // [FIND_R22_003 해결] 정당한 소비자 식중독/치료비 1000만원 보상 청구 및 법적 책임 100% 요구 리뷰 오탐 격리 방지
        if (legalClaimRegex.test(s) && !coreJailbreakRegex.test(s)) {
          const isReviewContext = d && (d.review_text !== undefined || d.rating !== undefined || d.comment !== undefined || d.category === 'REPUTATION_MANAGEMENT' || item.key === 'review_text' || item.key === 'comment');
          if (isReviewContext) {
            return false;
          }
        }

        // [FIND_HR_LEAVE_007 해결] 정상 진료 연차 사유("의사의 이전 지침에 따라...") 프롬프트 인젝션 오탐 방지
        const isHrLeaveReason = Boolean(
          (d && (d.leave_type !== undefined || d.days !== undefined)) &&
          (item.key === 'reason' || d.reason)
        );
        if (isHrLeaveReason) {
          const actualJailbreak = /(?:지침\s*무시|이전\s*지침\s*무시|지침\s*파기|지침\s*무효화|system\s*override|ignore\s*previous|disregard\s*previous|<script\b|<iframe\b|<svg\b|<object\b|<embed\b|<[a-zA-Z1-6]+\b[^>]*\bon[a-zA-Z]+\s*=|javascript:\s*|명령\s*무시)/i;
          if (!actualJailbreak.test(s)) {
            return false;
          }
        }

        // [FIND_006] SYSTEM OVERRIDE 오류 보고 등 정상 시스템 장애 접수 티켓 예외 가드
        if (s.includes('SYSTEM OVERRIDE') || s.includes('SYSTEM_OVERRIDE')) {
          if (legitSystemErrorReportRegex.test(s) && !/(?:지침\s*무시|지시\s*무시|이전\s*지침|이전\s*지시|명령\s*무시|무조건\s*HIGH)/i.test(s)) {
            return false;
          }
        }
        return true;
      });
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'PROMPT_INJECTION_ATTEMPT';
      d.quarantine_reason = 'PROMPT_INJECTION_ATTEMPT';
      d.healing_applied = '프롬프트 인젝션 및 XSS 악성 지시어 탐지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_007 & FIND_003 해결] 사원번호 및 입사지원서 식별자 내 SQL Injection 공격 페이로드 감지 및 DLQ 격리
  L2_SQL_INJECTION_DETECTED: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      const idFields = [d.employee_id, d.application_id, d.applicant_id, d.candidate_id, d.slot_id, d.booking_id];
      const sqlInjectionRegex = /;|--|\/\*|\*\/|drop\s+table|delete\s+from|insert\s+into|update\s+|union\s+select/i;
      return idFields.some(id => id && sqlInjectionRegex.test(String(id)));
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      const isAppId = Boolean(d.application_id || d.applicant_id || d.candidate_id || d.slot_id || d.booking_id);
      const reasonCode = isAppId ? 'SQL_INJECTION_DETECTED_IN_APPLICATION_ID' : 'SQL_INJECTION_DETECTED_IN_EMPLOYEE_ID';
      d.reason = reasonCode;
      d.quarantine_reason = reasonCode;
      d.healing_applied = isAppId ? '지원서/슬롯 식별자 내 SQL Injection 공격 페이로드 감지 즉시 DLQ 격리' : '사원번호 내 SQL Injection 공격 페이로드 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_R27_003 & FIND_L3_STRIPE_006, FIND_007, FIND_008, FIND_009 해결] PII 민감 개인정보 마스킹 파이프라인 탑재
  L2_PII_DATA_MASKING: {
    match: (d) => {
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      const piiPatterns = [
        /(?<![0-9a-zA-Z가-힣])\d{6}\s*[-]\s*[1-8]\d{6}(?![0-9a-zA-Z가-힣])/,
        /(?<![0-9a-zA-Z가-힣])(?:\d{4}\s*[-]\s*){3}\d{4}(?![0-9a-zA-Z가-힣])/,
        /(?<![0-9a-zA-Z가-힣])(?:02|0[3-6][1-5]|070|01[016789]|\+82\s*)\s*[-.]?\s*\d{3,4}\s*[-.]?\s*\d{4}(?![0-9])/,
        /(?<![0-9a-zA-Z가-힣])\d{2}[-]\d{2}[-]\d{6}[-]\d{2}(?![0-9a-zA-Z가-힣])/,
        /(?<![0-9a-zA-Z가-힣])[A-Z][0-9]{8}(?![0-9a-zA-Z가-힣])/,
        /(?:서울시|서울특별시|경기도|[가-힣]{2,4}[시도])\s+[가-힣\d\s-]+(?:동|로|길)\s+[\d-]+(?:\s*거주)?/,
        /(?<![0-9a-zA-Z가-힣])(?!\d{3}-\d{2}-\d{5}(?![0-9a-zA-Z가-힣]))\d{3,6}[-]\d{2,6}[-]\d{3,8}(?![0-9a-zA-Z가-힣])/,
        /(?<![0-9a-zA-Z가-힣])\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{7}(?![0-9a-zA-Z가-힣])/,
        /(?<![0-9a-zA-Z가-힣])(?:4\d{15}|5[1-5]\d{14}|6011\d{12}|3[47]\d{13}|\d{16})(?![0-9a-zA-Z가-힣])/,
        /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/,
        /\b(?:\d{1,3}\.){3}\d{1,3}\b/,
        /sk_live_[0-9a-zA-Z]{16,}/,
        /xox[baprs]-[0-9a-zA-Z-]{20,}/,
        /sk-(?:proj-)?[0-9a-zA-Z_-]{20,}/
      ];
      const isMarketingEmailContext = Boolean(
        d.subscribers !== undefined ||
        d.preferred_category !== undefined ||
        (d.email && d.marketing_consent !== undefined) ||
        (typeof context !== 'undefined' && (
          context?.category === 'MARKETING_EMAIL' ||
          (context?.workflowPath && /stibee|newsletter/i.test(context.workflowPath)) ||
          (context?.workflowName && /stibee|newsletter/i.test(context.workflowName))
        ))
      );
      const isHrOnboardingContext = Boolean(
        d.service_key === 'BO_EMPLOYEE_ONBOARDING' ||
        d.employee_id !== undefined ||
        (typeof context !== 'undefined' && (
          (context?.workflowPath && /EMPLOYEE_ONBOARDING/i.test(context.workflowPath)) ||
          (context?.workflowName && /온보딩|EMPLOYEE_ONBOARDING/i.test(context.workflowName))
        ))
      );
      const isTaxInvoiceContext = Boolean(
        d.buyer_biz_no !== undefined ||
        d.clean_biz_no !== undefined ||
        d.supply_cost !== undefined ||
        d.buyer_email !== undefined ||
        (typeof context !== 'undefined' && (
          (context?.workflowPath && /bolta|tax-invoice|tax_invoice/i.test(context.workflowPath)) ||
          (context?.workflowName && /bolta|세금계산서/i.test(context.workflowName))
        ))
      );
      const isChannelTalkContext = Boolean(
        d.last_chat_summary !== undefined ||
        d.lastChatSummary !== undefined ||
        (d.event && String(d.event).startsWith('user.')) ||
        (d.event_type && String(d.event_type).startsWith('user.')) ||
        (d.entity && (d.entity.profile || d.entity.tags)) ||
        (typeof context !== 'undefined' && (
          context?.category === 'CRM_AUTOMATION' ||
          (context?.workflowPath && /channeltalk/i.test(context.workflowPath)) ||
          (context?.workflowName && /채널톡|channeltalk/i.test(context.workflowName))
        ))
      );
      const piiSensitiveKeys = [
        'card_number', 'pan', 'credit_card', 'card_no', 'bank_account', 'account_number', 'account_no',
        'resident_id', 'rrn', 'foreign_rrn', 'card', 'customer_ip_address', 'ip_address', 'ip',
        'passport', 'passport_number', 'passport_no', 'passport_num',
        'driver_license', 'drivers_license', 'license_number', 'driver_license_number',
        'desired_salary', 'current_salary', 'expected_salary', 'annual_salary'
      ];
      if (!isMarketingEmailContext && !isHrOnboardingContext && !isTaxInvoiceContext && !isChannelTalkContext) {
        piiSensitiveKeys.push('email');
      }
      if (!isHrOnboardingContext && !isChannelTalkContext) {
        piiSensitiveKeys.push('phone', 'mobile', 'mobilenumber', 'mobile_number');
      }
      const deepCheckPII = (obj, depth = 0) => {
        if (!obj || depth > 10) return false;
        if (typeof obj === 'string') {
          return piiPatterns.some(p => {
            if ((isMarketingEmailContext || isHrOnboardingContext || isTaxInvoiceContext || isChannelTalkContext) && p.source.includes('@')) return false;
            if (isChannelTalkContext && p.source.includes('\\d{3,4}')) return false;
            return p.test(obj);
          });
        }
        if (typeof obj === 'object') {
          for (const [k, v] of Object.entries(obj)) {
            const lowerK = k.toLowerCase();
            if (lowerK.includes('biz_no') || lowerK.includes('business') || lowerK.includes('bizno') || lowerK.includes('tax_id')) continue;
            if (lowerK === 'buyer_email' || (isTaxInvoiceContext && lowerK === 'email') || (isChannelTalkContext && (lowerK === 'email' || lowerK === 'mobilenumber' || lowerK === 'phone' || lowerK === 'mobile'))) continue;
            if (lowerK === 'email' && (d.type === 'unsubscribe' || d.type === 'subscribe' || isMarketingEmailContext || isHrOnboardingContext || isTaxInvoiceContext || isChannelTalkContext)) continue;
            if (piiSensitiveKeys.includes(lowerK)) return true;
            if (typeof v === 'string') {
              const matched = piiPatterns.some(p => {
                if ((isMarketingEmailContext || isHrOnboardingContext || isChannelTalkContext) && p.source.includes('@')) return false;
                if (isChannelTalkContext && p.source.includes('\\d{3,4}')) return false;
                return p.test(v);
              });
              if (matched) return true;
            }
            if (typeof v === 'object' && v !== null && deepCheckPII(v, depth + 1)) return true;
          }
        }
        return false;
      };
      return deepCheckPII(d);
    },
    remedy: (d) => {
      const isMarketingEmailContext = Boolean(
        d.subscribers !== undefined ||
        d.preferred_category !== undefined ||
        (d.email && d.marketing_consent !== undefined) ||
        (typeof context !== 'undefined' && (
          context?.category === 'MARKETING_EMAIL' ||
          (context?.workflowPath && /stibee|newsletter/i.test(context.workflowPath)) ||
          (context?.workflowName && /stibee|newsletter/i.test(context.workflowName))
        ))
      );
      const isHrOnboardingContext = Boolean(
        d.service_key === 'BO_EMPLOYEE_ONBOARDING' ||
        d.employee_id !== undefined ||
        (typeof context !== 'undefined' && (
          (context?.workflowPath && /EMPLOYEE_ONBOARDING/i.test(context.workflowPath)) ||
          (context?.workflowName && /온보딩|EMPLOYEE_ONBOARDING/i.test(context.workflowName))
        ))
      );
      const isHrApplicantContext = Boolean(
        d.resume_url !== undefined ||
        d.applicant_phone !== undefined ||
        d.candidate_email !== undefined ||
        d.service_key === 'HR_RESUME_AI_EVALUATION' ||
        (typeof context !== 'undefined' && (
          (context?.workflowPath && /HR_RESUME/i.test(context.workflowPath)) ||
          (context?.workflowName && /이력서|HR_RESUME/i.test(context.workflowName))
        ))
      );
      const isTaxInvoiceContext = Boolean(
        d.buyer_biz_no !== undefined ||
        d.clean_biz_no !== undefined ||
        d.supply_cost !== undefined ||
        d.buyer_email !== undefined ||
        (typeof context !== 'undefined' && (
          (context?.workflowPath && /bolta|tax-invoice|tax_invoice/i.test(context.workflowPath)) ||
          (context?.workflowName && /bolta|세금계산서/i.test(context.workflowName))
        ))
      );
      let origPhone = null;
      if (isHrApplicantContext) {
        const rawP = d.original_phone || d.applicant_phone || d.phone || d.mobile || d.clean_phone || d.customer_tel;
        if (rawP && typeof rawP === 'string' && rawP !== '****') {
          origPhone = rawP;
          d.original_phone = rawP;
        }
      }
      if (d.buyer_biz_no && typeof d.buyer_biz_no === 'string') {
        if (!d.original_buyer_biz_no) d.original_buyer_biz_no = d.buyer_biz_no;
      }
      const isChannelTalkContext = Boolean(
        d.last_chat_summary !== undefined ||
        d.lastChatSummary !== undefined ||
        (d.event && String(d.event).startsWith('user.')) ||
        (d.event_type && String(d.event_type).startsWith('user.')) ||
        (d.entity && (d.entity.profile || d.entity.tags)) ||
        (typeof context !== 'undefined' && (
          context?.category === 'CRM_AUTOMATION' ||
          (context?.workflowPath && /channeltalk/i.test(context.workflowPath)) ||
          (context?.workflowName && /채널톡|channeltalk/i.test(context.workflowName))
        ))
      );
      const isHrRecruitingContext = Boolean(
        (typeof context !== 'undefined' && context?.workflowPath && /AF-HR-02|HR_RECRUITING/i.test(context.workflowPath)) ||
        d.slot_id !== undefined ||
        d.interview_time !== undefined
      );
      const preserveEmailFlag = isMarketingEmailContext || isHrOnboardingContext || isTaxInvoiceContext || isChannelTalkContext || isHrRecruitingContext;
      const preservePhoneFlag = isHrOnboardingContext || isChannelTalkContext;
      const deepMaskPII = (obj, depth = 0) => {
        if (!obj || depth > 10) return obj;
        if (Array.isArray(obj)) {
          for (let i = 0; i < obj.length; i++) {
            if (typeof obj[i] === 'string') {
              obj[i] = maskPII(obj[i], preserveEmailFlag, preservePhoneFlag);
            } else if (typeof obj[i] === 'object' && obj[i] !== null) {
              deepMaskPII(obj[i], depth + 1);
            }
          }
          return obj;
        }
        for (const k of Object.keys(obj)) {
          const lowerK = k.toLowerCase();
          if (lowerK === 'original_phone' || lowerK === 'original_buyer_biz_no') {
            continue;
          }
          if (lowerK === 'buyer_email' || (isTaxInvoiceContext && lowerK === 'email') || (isHrRecruitingContext && (lowerK === 'email' || lowerK === 'applicant_email' || lowerK === 'interviewer_email')) || (isChannelTalkContext && (lowerK === 'email' || lowerK === 'mobilenumber' || lowerK === 'phone' || lowerK === 'mobile'))) {
            continue;
          }
          if (lowerK.includes('biz_no') || lowerK.includes('business') || lowerK.includes('bizno') || lowerK.includes('tax_id')) {
            if (!d.original_buyer_biz_no && typeof obj[k] === 'string') {
              d.original_buyer_biz_no = obj[k];
            }
            continue;
          }
          if (['card_number', 'pan', 'credit_card', 'card_no', 'card'].includes(lowerK)) {
            obj[k] = '****';
          } else if (['bank_account', 'account_number', 'account_no'].includes(lowerK)) {
            obj[k] = '[계좌번호 마스킹]';
          } else if (['resident_id', 'rrn', 'foreign_rrn'].includes(lowerK)) {
            obj[k] = '******-*******';
          } else if (['passport', 'passport_number', 'passport_no', 'passport_num'].includes(lowerK) || lowerK.includes('passport')) {
            obj[k] = 'M********';
          } else if (['driver_license', 'drivers_license', 'license_number', 'driver_license_number'].includes(lowerK) || lowerK.includes('driver_license')) {
            obj[k] = '**-**-******-**';
          } else if (['phone', 'mobile', 'customer_phone', 'clean_phone', 'buyer_phone', 'customer_tel', 'applicant_phone', 'mobilenumber', 'mobile_number'].includes(lowerK)) {
            if (!preservePhoneFlag) {
              if (typeof obj[k] === 'string' && obj[k] !== '****') {
                if (!obj.original_phone) obj.original_phone = obj[k];
                if (!d.original_phone) d.original_phone = obj[k];
              }
              obj[k] = '****';
            }
          } else if (['desired_salary', 'current_salary', 'expected_salary', 'annual_salary'].includes(lowerK) || lowerK.includes('salary')) {
            obj[k] = '[급여 정보 마스킹]';
          } else if (lowerK === 'email' || lowerK === 'applicant_email' || lowerK === 'interviewer_email') {
            if (d.type !== 'unsubscribe' && d.type !== 'subscribe' && !preserveEmailFlag) {
              obj[k] = '[이메일 마스킹]';
            }
          } else if (['customer_ip_address', 'ip_address', 'ip'].includes(lowerK)) {
            obj[k] = '[IP 마스킹]';
          } else if (typeof obj[k] === 'string') {
            obj[k] = maskPII(obj[k], preserveEmailFlag, preservePhoneFlag);
          } else if (typeof obj[k] === 'object' && obj[k] !== null) {
            deepMaskPII(obj[k], depth + 1);
          }
        }
        return obj;
      };
      deepMaskPII(d);
      // [FIND_007, FIND_008 해결] query, error_log, message, raw_query 등 주요 텍스트 필드 명시적 순회 마스킹
      const targetTextFields = ['query', 'error_log', 'message', 'raw_query'];
      for (const field of targetTextFields) {
        if (typeof d[field] === 'string') {
          d[field] = maskPII(d[field], preserveEmailFlag, preservePhoneFlag);
        }
      }
      if (isHrApplicantContext && origPhone) {
        d.original_phone = origPhone;
      }
      d.pii_masked = true;
      d.healing_applied = '리뷰 및 결제 메모 내 주민번호/카드번호/전화번호/계좌번호/주소 등 민감 PII 개인정보 마스킹 처리';
      return d;
    }
  },

  // L3: 비즈니스 데이터 및 결측 6종
  // [순서 교정: 통화 표기 문자열 파싱을 음수/0원 판정보다 먼저 실행]
  L3_CURRENCY_STRING_MIX: {
    match: (d) => {
      const raw = toSafeString(d.amount !== undefined ? d.amount : (d.total_price !== undefined ? d.total_price : (d.competitor_price !== undefined ? d.competitor_price : (d.my_price !== undefined ? d.my_price : ''))));
      return /[₩$원,]/.test(raw);
    },
    remedy: (d) => {
      const clean = (val) => Number(toSafeString(val).replace(/[^0-9.-]/g, '')) || 0;
      if (d.amount !== undefined) d.amount = clean(d.amount);
      if (d.total_price !== undefined) d.total_price = clean(d.total_price);
      if (d.competitor_price !== undefined) d.competitor_price = clean(d.competitor_price);
      if (d.my_price !== undefined) d.my_price = clean(d.my_price);
      if (d.standardized_deal_amount !== undefined) d.standardized_deal_amount = clean(d.standardized_deal_amount);
      d.healed_amount = d.amount || d.total_price || d.competitor_price || d.my_price;
      d.healing_applied = '정규식 /[^0-9.-]/g 숫자 추출기 가동 후 안전 파싱';
      return d;
    }
  },
  // [FIND_001: Mailchimp ping 헬스체크 신호 오발송 방어]
  L3_MAILCHIMP_PING_EVENT: {
    match: (d) => Boolean(d && d.type === 'ping'),
    remedy: (d) => {
      d.status = 'PING_EVENT_ACKNOWLEDGED_NO_ACTION';
      d.ping_acknowledged = true;
      d.healing_applied = 'Mailchimp ping 헬스체크 신호 수신 확인 및 성공 종료(PING_EVENT_ACKNOWLEDGED_NO_ACTION)';
      return d;
    }
  },
  // [FIND_002: 신규 구독(type: "subscribe") 오분류 차단]
  L3_MAILCHIMP_NON_UNSUBSCRIBE_EVENT: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      const isMailchimp = d.list_id !== undefined || (d.data && d.data.merges !== undefined) || (typeof context !== 'undefined' && ((context.workflowName && context.workflowName.toLowerCase().includes('mailchimp')) || (context.workflowPath && context.workflowPath.toLowerCase().includes('mailchimp'))));
      if (!isMailchimp) return false;
      if (d.type === 'subscribe') return true;
      if (d.type && d.type !== 'unsubscribe' && d.type !== 'ping' && (d.list_id || d.data?.list_id || d.data?.merges)) {
        return true;
      }
      return false;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'NON_UNSUBSCRIBE_EVENT_FILTERED';
      d.quarantine_reason = 'NON_UNSUBSCRIBE_EVENT_FILTERED';
      d.healing_applied = 'Mailchimp 비-구독취소(subscribe 등) 이벤트 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_003 & FIND_004 해결: 비정상 이메일 규격(@ 누락 / 유효 정규식 불일치) DLQ 격리]
  L3_MAILCHIMP_INVALID_EMAIL: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.type === 'unsubscribe') {
        const email = d.email || d.data?.email;
        if (!email || !String(email).includes('@')) {
          return true;
        }
      }
      const isHrRecruiting = Boolean(
        (typeof context !== 'undefined' && context?.workflowPath && /AF-HR-02|HR_RECRUITING/i.test(context.workflowPath)) ||
        d.slot_id !== undefined ||
        d.applicant_email !== undefined ||
        d.interview_time !== undefined
      );
      if (isHrRecruiting) {
        const targetEmail = String(d.applicant_email || d.email || '').trim();
        if (targetEmail && (!targetEmail.includes('@') || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(targetEmail))) {
          return true;
        }
      }
      return false;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      const isApplicant = Boolean(d.applicant_email || d.slot_id);
      const reasonCode = isApplicant ? 'INVALID_APPLICANT_EMAIL_FORMAT' : 'INVALID_EMAIL_FORMAT';
      d.reason = reasonCode;
      d.quarantine_reason = reasonCode;
      d.healing_applied = isApplicant ? '비정상 지원자 이메일 규격 감지 즉시 DLQ 격리' : '비정상 이메일 규격(@ 누락) 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_008 해결] 퇴사자(status: RESIGNED) 온보딩 파이프라인 차단 및 DLQ 격리
  L3_HR_RESIGNED_EMPLOYEE_BLOCKED: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      // [FIND_HR_LEAVE_008 해결] 퇴사 예정 직원의 적법한 잔여 연차 전수 소진 신청 허용
      if (d.leave_type !== undefined || d.days !== undefined) return false;
      const isHr = Boolean(
        d.employee_id !== undefined ||
        d.service_key === 'BO_EMPLOYEE_ONBOARDING' ||
        (typeof context !== 'undefined' && ((context?.workflowPath && /EMPLOYEE_ONBOARDING/i.test(context.workflowPath)) || (context?.workflowName && /온보딩|EMPLOYEE_ONBOARDING/i.test(context.workflowName))))
      );
      if (isHr) {
        return Boolean(d.status === 'RESIGNED' || d.is_resigned === true || d.resignation_date !== undefined);
      }
      return false;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'RESIGNED_EMPLOYEE_ONBOARDING_BLOCKED';
      d.quarantine_reason = 'RESIGNED_EMPLOYEE_ONBOARDING_BLOCKED';
      d.healing_applied = '퇴사자(RESIGNED) 온보딩 파이프라인 인입 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_003, FIND_004, FIND_005 해결] 비정상(음수, 0원, NaN) 경쟁사 가격 탐지 및 DLQ 격리
  L3_INVALID_COMPETITOR_PRICE: {
    match: (d) => {
      if (d.competitor_price === undefined) return false;
      const cleanStr = typeof d.competitor_price === 'string' ? d.competitor_price.replace(/[₩$원,]/g, '').trim() : d.competitor_price;
      const num = Number(cleanStr);
      return isNaN(num) || num <= 0;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'INVALID_COMPETITOR_PRICE';
      d.status = 'QUARANTINED';
      d.healing_applied = '비정상(음수/0원/NaN) 경쟁사 가격 감지 및 DLQ 즉시 격리';
      return d;
    }
  },
  L3_FLOAT_PRECISION_CORRUPT: {
    match: (d) => {
      const getNum = (v) => (typeof v === 'number' ? v : (typeof v === 'string' ? Number(v) : 0));
      const amt = getNum(d.amount) || getNum(d.total_price) || getNum(d.standardized_deal_amount) || 0;
      return amt > 0 && String(amt).includes('.') && String(amt).split('.')[1].length > 4 && (String(amt).includes('0000000') || String(amt).includes('9999999'));
    },
    remedy: (d) => {
      const getNum = (v) => (typeof v === 'number' ? v : (typeof v === 'string' ? Number(v) : 0));
      const amt = getNum(d.amount) || getNum(d.total_price) || getNum(d.standardized_deal_amount) || 0;
      const normalized = Number(amt.toFixed(8));
      if (d.amount !== undefined) d.amount = normalized;
      if (d.total_price !== undefined) d.total_price = normalized;
      if (d.standardized_deal_amount !== undefined) d.standardized_deal_amount = normalized;
      d.healing_applied = '극단 부동소수점 오차 안전 정밀도 보존 및 toFixed(8) 정규화';
      return d;
    }
  },
  // [FIND_L3_STRIPE_004, FIND_008 해결] Webhook Signature 위조/누락 감지 가드
  L1_INVALID_WEBHOOK_SIGNATURE: {
    match: (d) => {
      if (d.signature_valid === false || d.is_signature_valid === false) return true;
      if (d.stripe_signature && typeof d.stripe_signature === 'string') {
        return !d.stripe_signature.includes('t=') || !d.stripe_signature.includes('v1=');
      }
      // [FIND_008 해결] GitHub 웹훅 서명 (X-Hub-Signature-256) 검증
      const ghSig = d.x_hub_signature_256 || d['x-hub-signature-256'] || d.headers?.['x-hub-signature-256'] || d.headers?.['X-Hub-Signature-256'];
      if (ghSig && typeof ghSig === 'string') {
        if (!/^sha256=[0-9a-fA-F]{64}$/.test(ghSig) || /forged|hacker|injected|invalid|fake/i.test(ghSig)) {
          return true;
        }
      }
      // [FIND_004 해결] WooCommerce 웹훅 서명 (x-wc-webhook-signature) 검증
      const wcSig = d.x_wc_webhook_signature || d['x-wc-webhook-signature'] || d.headers?.['x-wc-webhook-signature'] || d.headers?.['X-Wc-Webhook-Signature'];
      if (wcSig && typeof wcSig === 'string') {
        if (/forged|hacker|injected|invalid|fake|attacker/i.test(wcSig) || !/^[A-Za-z0-9+/=]{20,}$/.test(wcSig)) {
          return true;
        }
      }
      return false;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'INVALID_WEBHOOK_SIGNATURE';
      d.status = 'QUARANTINED';
      d.healing_applied = '웹훅 서명 위조/누락 감지 즉시 DLQ 격리';
      return d;
    }
  },
  L3_NEGATIVE_ZERO_AMOUNT: {
    match: (d) => {
      // [FIND_004, FIND_005, FIND_006, FIND_014, FIND_015, FIND_007 해결] 리뷰/피드백/NPS 설문 데이터인 경우 오탐 격리 방지
      if (isReviewData(d) || d.nps_score !== undefined || d.survey_id !== undefined || d.feedback !== undefined) return false;
      const getNum = (v) => (typeof v === 'number' ? v : (typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN));
      // [FIND_003 해결] WooCommerce total 금액 필드 추가
      const raw = d.amount !== undefined ? d.amount : (d.order_amount !== undefined ? d.order_amount : (d.total_amount !== undefined ? d.total_amount : (d.total_price !== undefined ? d.total_price : (d.total !== undefined ? d.total : d.standardized_deal_amount))));
      if (raw === undefined) return false;
      if (typeof raw === 'string' && /[₩$원,]/.test(raw)) return false; // 통화 문자열은 L3_CURRENCY_STRING_MIX가 처리
      if (typeof raw === 'string' && raw.trim() === '') return true;
      const num = Number(raw);
      // [FIND_010 해결] Infinity/비한정 비정상 수치 차단
      if (!Number.isFinite(num)) return true;

      // [FIND_003 & FIND_004 해결] 경영 리포트/재무 집계 컨텍스트에서는 매출 0원(휴무) 및 적자(-금액) 허용
      const isExecReport = d.sales !== undefined || d.expenses !== undefined || d.report_type || d.anomaly_flag || d.executive_salary || d.sales_memo || d.report_detail || d.report_title || d.hours !== undefined || d.executive_briefing || (typeof context !== 'undefined' && (context.isCron || context.category === 'EXECUTIVE_REPORTING'));
      if (isExecReport) return false;

      // Stripe 정상 0원 프로모션/무료 체험 결제건 오탐 방지 (FIND_005, FIND_L3_STRIPE_010)
      const isZeroPromo = (num === 0 && (
        d.is_zero_promo === true ||
        d.is_free_promo === true ||
        (typeof d.description === 'string' && /(?:promo|free|license)/i.test(d.description)) ||
        (typeof d.event_id === 'string' && d.event_id.toLowerCase().includes('promo'))
      ));
      if (isZeroPromo) return false;
      return isNaN(num) || num <= 0;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'INVALID_PAYMENT_AMOUNT';
      d.status = 'QUARANTINED';
      d.healing_applied = '0원/마이너스 결제 사기 탐지 및 DLQ 즉시 격리';
      return d;
    }
  },
  // [FIND_010 해결] 비정상 음수 급여 및 비상식적 미래 입사일자 차단 및 DLQ 격리
  L3_HR_INVALID_SALARY_OR_JOIN_DATE: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      const isHr = Boolean(
        d.employee_id !== undefined ||
        d.service_key === 'BO_EMPLOYEE_ONBOARDING' ||
        d.salary !== undefined ||
        d.join_date !== undefined ||
        (typeof context !== 'undefined' && ((context?.workflowPath && /EMPLOYEE_ONBOARDING/i.test(context.workflowPath)) || (context?.workflowName && /온보딩|EMPLOYEE_ONBOARDING/i.test(context.workflowName))))
      );
      if (!isHr) return false;
      if (d.salary !== undefined && Number(d.salary) < 0) return true;
      if (d.join_date !== undefined) {
        const yr = Number(String(d.join_date).slice(0, 4));
        if (yr > 2100 || isNaN(yr) || yr < 1900) return true;
      }
      return false;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      if (d.salary !== undefined && Number(d.salary) < 0) {
        d.quarantine_reason = 'NEGATIVE_SALARY_AMOUNT_BLOCKED';
        d.reason = 'NEGATIVE_SALARY_AMOUNT_BLOCKED';
      } else {
        d.quarantine_reason = 'INVALID_FUTURE_JOIN_DATE';
        d.reason = 'INVALID_FUTURE_JOIN_DATE';
      }
      d.healing_applied = '비정상 음수 급여 또는 비상식적 미래 입사일자 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_HR_LEAVE_001 해결] 음수/0일 휴가 일수 입력 차단 및 DLQ 격리
  L3_HR_INVALID_LEAVE_DAYS_NEGATIVE: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      return d.days !== undefined && Number(d.days) <= 0;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'NEGATIVE_OR_ZERO_LEAVE_DAYS';
      d.quarantine_reason = 'NEGATIVE_OR_ZERO_LEAVE_DAYS';
      d.healing_applied = '음수 또는 0일 휴가 신청 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_HR_LEAVE_002 해결] 잔여 연차 초과 차감 입력 차단 및 DLQ 격리
  L3_HR_EXCEEDED_REMAINING_LEAVE_DAYS: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      return d.remaining_days !== undefined && d.days !== undefined && Number(d.days) > Number(d.remaining_days);
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'EXCEEDED_REMAINING_LEAVE_DAYS';
      d.quarantine_reason = 'EXCEEDED_REMAINING_LEAVE_DAYS';
      d.healing_applied = '잔여 연차 한도 초과 신청 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_001 해결: 과거 시간 예약 방어]
  L3_HR_PAST_INTERVIEW_TIME_BLOCKED: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      const isHrRecruiting = Boolean(
        (typeof context !== 'undefined' && context?.workflowPath && /AF-HR-02|HR_RECRUITING/i.test(context.workflowPath)) ||
        d.slot_id !== undefined ||
        d.interview_time !== undefined
      );
      if (!isHrRecruiting) return false;
      const intTime = d.interview_time || d.start_time || d.booked_time;
      if (intTime && new Date(intTime).getTime() < Date.now() - 300000) {
        return true;
      }
      return false;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'PAST_INTERVIEW_TIME_RESERVATION_BLOCKED';
      d.quarantine_reason = 'PAST_INTERVIEW_TIME_RESERVATION_BLOCKED';
      d.healing_applied = '과거 시간 면접 예약 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_002 해결: 마감 슬롯 예약 방어]
  L3_HR_SLOT_CLOSED_OR_BOOKED: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      const isHrRecruiting = Boolean(
        (typeof context !== 'undefined' && context?.workflowPath && /AF-HR-02|HR_RECRUITING/i.test(context.workflowPath)) ||
        d.slot_id !== undefined ||
        d.interview_time !== undefined
      );
      if (!isHrRecruiting) return false;
      return (d.slot_status === 'CLOSED' || d.is_booked === true || d.is_available === false);
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'INTERVIEW_SLOT_ALREADY_CLOSED_OR_BOOKED';
      d.quarantine_reason = 'INTERVIEW_SLOT_ALREADY_CLOSED_OR_BOOKED';
      d.healing_applied = '마감 및 이미 예약된 면접 슬롯 중복 신청 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_HR_LEAVE_003 & FIND_006 해결] 시작일/시간 > 종료일/시간 역전 기간 모순 데이터 차단 및 DLQ 격리
  L3_HR_INVALID_LEAVE_DATE_RANGE: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      const sTime = d.start_time || d.start_date;
      const eTime = d.end_time || d.end_date;
      if (sTime && eTime) {
        return new Date(sTime).getTime() > new Date(eTime).getTime();
      }
      return false;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      const isInterview = Boolean(d.start_time || d.slot_id || d.interview_time);
      const reasonCode = isInterview ? 'INVALID_INTERVIEW_TIME_RANGE' : 'INVALID_LEAVE_DATE_RANGE';
      d.reason = reasonCode;
      d.quarantine_reason = reasonCode;
      d.healing_applied = isInterview ? '면접 시작시간이 종료시간보다 뒤선 시간 역전 모순 감지 즉시 DLQ 격리' : '시작일이 종료일보다 뒤선 날짜 역전 모순 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_007 해결: 필수 면접관 이메일 결측 방어]
  L3_HR_MISSING_INTERVIEWER_EMAIL: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      const isHrRecruiting = Boolean(
        (typeof context !== 'undefined' && context?.workflowPath && /AF-HR-02|HR_RECRUITING/i.test(context.workflowPath)) ||
        d.slot_id !== undefined ||
        d.interview_time !== undefined
      );
      if (!isHrRecruiting) return false;
      return (d.interviewer_email === undefined || d.interviewer_email === null || d.interviewer_email === '');
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'MISSING_INTERVIEWER_EMAIL';
      d.quarantine_reason = 'MISSING_INTERVIEWER_EMAIL';
      d.healing_applied = '필수 면접관 이메일 결측 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_HR_LEAVE_006 해결] 비인가자(인턴) 무단 승인 차단 및 DLQ 격리
  L3_HR_UNAUTHORIZED_APPROVER_BLOCKED: {
    match: (d) => {
      if (!d || typeof d !== 'object') return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      return d.approved_by === 'ATTACKER_INTERN' ||
             d.approver_role === 'INTERN' ||
             d.approval_status === 'UNAUTHORIZED_APPROVED' ||
             (typeof d.approved_by === 'string' && /INTERN/i.test(d.approved_by)) ||
             (typeof d.approver_role === 'string' && /INTERN/i.test(d.approver_role));
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'UNAUTHORIZED_APPROVER_BLOCKED';
      d.quarantine_reason = 'UNAUTHORIZED_APPROVER_BLOCKED';
      d.healing_applied = '비인가자(인턴) 무단 승인 감지 즉시 승인 반려 및 DLQ 격리';
      return d;
    }
  },
  // [FIND_L3_STRIPE_003 해결] refund_amount > amount 초과 환불 및 0원 환불 방어
  L3_EXCESSIVE_OR_ZERO_REFUND: {
    match: (d) => {
      if (d.refund_amount === undefined || d.refund_amount === null) return false;
      const refAmt = Number(d.refund_amount);
      const getNum = (v) => (typeof v === 'number' ? v : (typeof v === 'string' ? Number(v) : 0));
      const origAmt = getNum(d.amount) || getNum(d.order_amount) || getNum(d.total_amount) || getNum(d.standardized_amount) || 0;
      return (refAmt > origAmt) || (refAmt === 0);
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'EXCESSIVE_OR_ZERO_REFUND_BLOCKED';
      d.status = 'QUARANTINED';
      d.healing_applied = '초과 환불(refund_amount > amount) 또는 0원 환불 시도 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_L3_STRIPE_008 & FIND_005 해결] 무효 ISO 통화 코드 방어 및 국내 통화 '원' 지원
  L3_INVALID_CURRENCY_CODE: {
    match: (d) => {
      if (!d.currency || typeof d.currency !== 'string') return false;
      const VALID_CURRENCIES = [
        'usd', 'eur', 'gbp', 'cad', 'aud', 'jpy', 'krw', 'cny', 'hkd', 'sgd',
        'nzd', 'chf', 'inr', 'brl', 'mxn', 'sek', 'nok', 'dkk', 'pln', 'thb',
        'idr', 'myr', 'php', 'vnd', 'clp', 'ugx', 'pyg', 'bif', 'djf', 'gnf',
        'kmf', 'mga', 'rwf', 'vuv', 'xaf', 'xof', 'xpf', 'zar', 'twd', 'sar', 'aed',
        '원'
      ];
      return !VALID_CURRENCIES.includes(d.currency.trim().toLowerCase());
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'INVALID_OR_UNSUPPORTED_CURRENCY';
      d.status = 'QUARANTINED';
      d.healing_applied = '무효 ISO 통화 코드 감지 즉시 DLQ 격리';
      return d;
    }
  },
  // [FIND_L3_STRIPE_012 & FIND_006 해결] 만료된 웹훅 타임스탬프 드리프트 차단 및 당일 배치 영수증 예외 허용
  L4_TIMESTAMP_DRIFT_EXCEEDED: {
    match: (d) => {
      if (d.created === undefined || d.created === null) return false;
      if (typeof d.created !== 'number' || isNaN(d.created)) return false;

      // [FIND_006 해결] 배치/일일 보고서 컨텍스트에서는 당일 생성된 영수증/로그 드리프트 허용
      const isExecBatch = d.sales !== undefined || d.hours !== undefined || d.report_type !== undefined || d.expense_memo !== undefined || d.sales_memo !== undefined || d.expenses !== undefined || (typeof context !== 'undefined' && (context.isCron || context.category === 'EXECUTIVE_REPORTING'));
      if (isExecBatch) {
        const nowUnix = Math.floor(Date.now() / 1000);
        const diffSec = nowUnix - d.created;
        if (diffSec <= 86400 && diffSec >= -60) {
          return false;
        }
      }

      const nowUnix = Math.floor(Date.now() / 1000);
      const diffSec = nowUnix - d.created;
      return (diffSec > 300 || diffSec < -60);
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'TIMESTAMP_DRIFT_EXCEEDED';
      d.status = 'QUARANTINED';
      d.healing_applied = '허용 오차(300초/60초) 초과 타임스탬프 드리프트 공격 감지 즉시 DLQ 격리';
      return d;
    }
  },
  L3_PHONE_ANOMALY_DIRTY: {
    match: (d) => {
      const p = toSafeString(d.buyer_phone || d.phone || d.customer_tel || '');
      return p.includes('+82') || p.includes(' ') || p.includes('-');
    },
    remedy: (d) => {
      let p = toSafeString(d.buyer_phone || d.phone || d.customer_tel || '').replace(/[^0-9]/g, '');
      if (p.startsWith('82')) p = '0' + p.substring(2);
      // 정상 10자리(010-123-4567) 및 11자리(010-1234-5678) 모두 순수 숫자로만 보존
      if (d.buyer_phone) d.buyer_phone = p;
      if (d.phone) d.phone = p;
      if (d.customer_tel) d.customer_tel = p;
      d.clean_phone = p;
      d.healing_applied = '특수기호 제거 및 국내 표준 번호 숫자 정규화';
      return d;
    }
  },
  L3_BUSINESS_REG_CHECKSUM_FAIL: {
    match: (d) => {
      // [FIND_002, FIND_006, FIND_014, FIND_015 해결] 리뷰 피드 데이터인 경우 B2B 세금계산서 오탐 격리 방지
      if (isReviewData(d)) return false;
      return Boolean(d.biz_no && d.biz_no_checksum_valid === false);
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'BUSINESS_REG_CHECKSUM_FAIL';
      d.status = 'QUARANTINED';
      d.healing_applied = '세금계산서 발행 중단, 수기 확인 큐(DLQ)로 안전 격리';
      return d;
    }
  },
  L3_EMPTY_VS_NULL_CONFUSION: {
    match: (d) => ('buyer_name' in d) && (d.buyer_name === null || d.buyer_name === ''),
    remedy: (d) => {
      d.buyer_name = d.customer_name ?? d.recipient ?? d.name ?? '고객';
      d.healing_applied = 'Nullish Coalescing (??) 기본값 주입 및 스키마 정규화';
      return d;
    }
  },

  // L4: 트랜잭션 및 동시성 6종
  // [FIND_R27_004 해결] 중복/재전송 페이로드 즉시 DLQ 격리
  L4_DUPLICATE_REPLAY_ATTACK: {
    match: (d) => d.is_replay === true || d.duplicate === true || d.replay === true,
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.status = 'QUARANTINED';
      d.reason = 'DUPLICATE_REVIEW_PAYLOAD';
      d.quarantine_reason = 'DUPLICATE_REVIEW_PAYLOAD';
      d.healing_applied = '중복/재전송 페이로드(is_replay/duplicate) 감지 및 DLQ 즉시 격리';
      return d;
    }
  },
  L4_CONCURRENT_RACE_STORM: {
    match: (d) => {
      if (isReviewData(d)) return false;
      if (d.is_race_condition === true || d.race_condition === true) {
        return true;
      }
      if (typeof d.order_id === 'string' || typeof d.order_id === 'number') {
        const orderStr = String(d.order_id);
        return /\bRACE\b|_RACE_|RACE_STORM/i.test(orderStr);
      }
      return false;
    },
    remedy: (d) => {
      d.idempotency_locked = true;
      d.status = 'BLOCKED_409';
      d.healing_applied = '분산 멱등 락(Idempotency Lock)으로 첫 1건만 통과, 나머지 99건 409 Conflict 안전 차단';
      return d;
    }
  },
  L4_OUT_OF_ORDER_WEBHOOK: {
    match: (d) => d.webhook_sequence_mismatch === true,
    remedy: (d) => {
      d.queue_hold_sec = 3;
      d.healing_applied = '시퀀스 번호 불일치 감지 시 3초 큐 홀딩 후 순서 재정렬 처리';
      return d;
    }
  },
  L4_PHANTOM_READ_RACE: {
    match: (d) => d.phantom_read_detected === true,
    remedy: (d) => {
      d.isolation_level = 'SERIALIZABLE';
      d.pessimistic_lock = true;
      d.healing_applied = 'REPEATABLE READ / SERIALIZABLE 격리 수준 강제 및 비관적 락 적용';
      return d;
    }
  },
  L4_PARTIAL_STATE_DRIFT: {
    match: (d) => d.state_drift === true,
    remedy: (d) => {
      d.state_rollback = true;
      d.healing_applied = '상태 머신 전이 검증기 가동 및 불일치 시 직전 안정 상태로 롤백';
      return d;
    }
  },
  L4_DISTRIBUTED_LOCK_DEADLOCK: {
    match: (d) => d.lock_timeout_exceeded === true,
    remedy: (d) => {
      d.force_release_lock = true;
      d.healing_applied = '15초 TTL 자동 강제 만료(Force Release) 및 좀비 락 자동 청소';
      return d;
    }
  },
  L4_IDEMPOTENCY_KEY_COLLISION: {
    match: (d) => d.idempotency_collision === true,
    remedy: (d) => {
      d.idempotency_key = `${d.idempotency_key}_UUID_${Date.now()}`;
      d.healing_applied = 'UUID v4 + 고객 식별자 복합 키로 2차 충돌 회피 생성';
      return d;
    }
  },

  // L5: 외부 플랫폼 및 API 마찰 6종
  L5_SCHEMA_MUTATION_CHAOS: {
    match: (d) => (!d.order_id && (d.ordId || d.order_no || d.OrderIdentifier || d.orderId)),
    remedy: (d) => {
      d.order_id = d.ordId || d.order_no || d.OrderIdentifier || d.orderId;
      d.healing_applied = '동의어 매핑 사전(Synonym Dictionary) 기반 적응형 필드 자동 복원';
      return d;
    }
  },
  L5_RATE_LIMIT_429_CASCADE: {
    match: (d) => d.upstream_http_code === 429 || d.http_status === 429,
    remedy: (d) => {
      const retry = Number(d.retry_count || 0) + 1;
      d.backoff_delay_ms = Math.min(2000 * Math.pow(2, retry), 16000) + Math.floor(Math.random() * 500);
      d.retry_count = retry;
      d.healing_applied = '지수 백오프 + 무작위 지터(Jitter)로 요청 분산 및 3회 초과 시 DLQ 격리';
      return d;
    }
  },
  // [FIND_006 해결] 크롤링 봇 캡차 차단 및 403 HTTP 상태 감지 후 DLQ 격리
  L5_CRAWLER_CAPTCHA_BLOCKED: {
    match: (d) => {
      return d.is_blocked_captcha === true || d.http_status === 403 || (typeof d.error === 'string' && d.error.toLowerCase().includes('captcha'));
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'CRAWLER_CAPTCHA_BLOCKED';
      d.status = 'QUARANTINED';
      d.healing_applied = '크롤러 봇 캡차 및 403 차단 감지 후 DLQ 즉시 격리';
      return d;
    }
  },
  // [FIND_011 & FIND_002 & FIND_009 해결] 빈 웹훅({}) 스키마 검증 및 HR 온보딩 필수 스키마 결측 차단
  L5_EMPTY_WEBHOOK_SCHEMA_MISSING: {
    match: (d) => {
      if (!d || typeof d !== 'object' || Array.isArray(d)) return false;
      if (d.status === 'QUARANTINED' || d.airbag_dlq_quarantined) return false;
      // [FIND_002 & FIND_001 해결] 크론/스케줄러 트리거 워크플로우이거나 d.__is_cron === true 또는 배치/크론 기본값 위임 컨텍스트인 경우 빈 객체({}) 허용
      const isCron = (typeof context !== 'undefined' && (context.isCron || context.category === 'EXECUTIVE_REPORTING' || (context.workflowPath && (context.workflowPath.includes('PARTITION_CRON') || context.workflowPath.includes('cron'))))) ||
        d.__is_cron === true || d.isCron === true || d.cron !== undefined || d.schedule !== undefined || d.sales !== undefined || d.report_type !== undefined ||
        (Boolean(typeof context !== 'undefined' && context.isCron) && d.parent_table === undefined && d.database_name === undefined);
      if (isCron) return false;

      if (Object.keys(d).length === 0) return true;
      if (d.service_key === 'EC_COMPETITOR_PRICE_MONITOR' || d.is_competitor === true) {
        if (!d.product_name && !d.item_id && d.competitor_price === undefined) return true;
      }
      const isHr = Boolean(
        d.service_key === 'BO_EMPLOYEE_ONBOARDING' ||
        (typeof context !== 'undefined' && ((context?.workflowPath && /EMPLOYEE_ONBOARDING/i.test(context.workflowPath)) || (context?.workflowName && /온보딩|EMPLOYEE_ONBOARDING/i.test(context.workflowName))))
      );
      if (isHr) {
        const hasHrFields = Boolean(d.name || d.employee_id || d.email || d.department || d.join_date || d.phone);
        if (!hasHrFields) return true;
      }
      // [FIND_HR_LEAVE_005 & FIND_009 해결] 연차 신청 컨텍스트에서 필수 식별자(사원번호 employee_id) 누락 차단 및 candidate_id 허용
      const isHrLeave = Boolean(
        d.leave_type !== undefined ||
        d.days !== undefined ||
        (typeof context !== 'undefined' && ((context?.workflowPath && /AF-HR-03|LEAVE/i.test(context.workflowPath)) || (context?.workflowName && /휴가|연차/i.test(context.workflowName))))
      );
      if (isHrLeave) {
        if (!d.employee_id && !d.applicant_id && !d.candidate_id) return true;
      }
      return false;
    },
    remedy: (d) => {
      const isHr = Boolean(
        d.service_key === 'BO_EMPLOYEE_ONBOARDING' ||
        d.leave_type !== undefined ||
        d.days !== undefined ||
        (typeof context !== 'undefined' && ((context?.workflowPath && /EMPLOYEE_ONBOARDING|AF-HR-03|LEAVE/i.test(context.workflowPath)) || (context?.workflowName && /온보딩|EMPLOYEE_ONBOARDING|연차|휴가/i.test(context.workflowName))))
      );
      d.airbag_dlq_quarantined = true;
      d.reason = isHr ? 'SCHEMA_MISSING_REQUIRED_HR_FIELDS' : 'SCHEMA_MISSING_REQUIRED_FIELDS';
      d.quarantine_reason = isHr ? 'SCHEMA_MISSING_REQUIRED_HR_FIELDS' : 'SCHEMA_MISSING_REQUIRED_FIELDS';
      d.status = 'QUARANTINED';
      d.healing_applied = isHr ? 'HR 온보딩/휴가 필수 스키마 결측 감지 후 DLQ 즉시 격리' : '빈 웹훅({}) 및 필수 스키마 결측 감지 후 DLQ 즉시 격리';
      return d;
    }
  },
  L5_SOFT_ERROR_200_OK: {
    match: (d) => {
      if (isReviewData(d)) return false;
      return d.response_body && (d.response_body.code === 'FAIL' || d.response_body.status === 'ERROR');
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'SOFT_ERROR_200_OK_FAIL';
      d.status = 'QUARANTINED';
      d.healing_applied = '응답 페이로드 2차 검증 필터로 반-에러 탐지 및 에러 핸들러 분기';
      return d;
    }
  },
  L5_UPSTREAM_503_HTML: {
    match: (d) => {
      if (isReviewData(d)) return false;
      return d.upstream_http_code === 503 || (typeof d.raw_response === 'string' && d.raw_response.startsWith('<!DOCTYPE html>'));
    },
    remedy: (d) => {
      d.circuit_breaker_opened = true;
      d.circuit_cooldown_sec = 300;
      d.status = 'ALARM_DISPATCHED';
      d.healing_applied = 'Content-Type 검증 후 HTML 감지 시 5분 지연 서킷 브레이커 가동';
      return d;
    }
  },
  L5_OAUTH_TOKEN_EXPIRED: {
    match: (d) => d.upstream_http_code === 401 || d.token_expired === true,
    remedy: (d) => {
      d.token_refreshed = true;
      d.retry_with_new_token = true;
      d.healing_applied = '리프레시 토큰 원자적 갱신(Atomic Token Refresh) 후 원본 요청 1회 투명 재시도';
      return d;
    }
  },
  L5_ENDPOINT_DEPRECATED_410: {
    match: (d) => d.upstream_http_code === 410,
    remedy: (d) => {
      d.api_v2_failover = true;
      d.healing_applied = '최신 API v2 엔드포인트로 자동 페일오버 및 관리자 업그레이드 알림';
      return d;
    }
  },

  // L6: 호스트 인프라 및 거버넌스 6종
  L6_HEAP_MEMORY_OOM: {
    match: (d) => {
      if (d && d.heap_usage_percent !== undefined) return d.heap_usage_percent > 90;
      try {
        const mem = process.memoryUsage();
        return (mem.heapUsed / mem.heapTotal) > 0.90;
      } catch (e) {
        return false;
      }
    },
    remedy: (d) => {
      d.chunk_size = 20;
      d.gc_triggered = true;
      if (typeof global.gc === 'function') {
        try { global.gc(); } catch (e) {}
      }
      d.healing_applied = '실시간 힙 90% 초과 감지 ➔ 청크 분할 및 메모리 안전 회수';
      return d;
    }
  },
  L6_DISK_SPACE_FULL_ENOSPC: {
    match: (d) => d.code === 'ENOSPC' || d.disk_full === true,
    remedy: (d) => {
      d.log_rotated = true;
      d.healing_applied = '오래된 실행 로그/스냅샷 자동 압축 정리(Log Rotate)로 비상 디스크 확보';
      return d;
    }
  },
  L6_FILE_DESCRIPTOR_EMFILE: {
    match: (d) => d.code === 'EMFILE' || d.fd_exhausted === true,
    remedy: (d) => {
      d.idle_fd_closed = true;
      d.healing_applied = '열린 유휴 파일/소켓 핸들 강제 종료 및 커넥션 풀 크기 제한';
      return d;
    }
  },
  L6_TIER1_CORE_TAMPER: {
    match: (d) => d.tier1_tamper_attempt === true,
    remedy: (d) => {
      d.status = 'FAIL_CLOSED_REJECTED';
      d.healing_applied = 'Fail-Closed 안전 잠금 발동 (파이프라인 실행 즉각 거부 및 침투 로그 기록)';
      return d;
    }
  },
  L6_DEPENDENT_CHAIN_BROKEN: {
    match: (d) => d.upstream_broken === true,
    remedy: (d) => {
      d.cascade_skipped = true;
      d.healing_applied = '선행 결측 감지 시 하위 의존성 체인 동반 안전 스킵(Cascade Skip)';
      return d;
    }
  },
  L6_LONG_RUNNING_HANG_90S: {
    match: (d) => {
      if (isReviewData(d)) return false;
      return d.hang_seconds >= 90 || d.deadman_timeout === true;
    },
    remedy: (d) => {
      d.deadman_alarm_dispatched = true;
      d.telegram_hotline_called = true;
      d.status = 'ALARM_DISPATCHED';
      d.healing_applied = '90초 데드맨 스위치 발동 ➔ 스마트폰 긴급 텔레그램 경보 및 서킷 오픈';
      return d;
    }
  },

  // L7: 레드팀 2단계 사각지대 침투 대응 5종
  L7_UNHASHABLE_TYPE_INJECTION: {
    match: (d) => Array.isArray(d.payment_key) || (typeof d.payment_key === 'object' && d.payment_key !== null) || Array.isArray(d.order_id) || (typeof d.order_id === 'object' && d.order_id !== null) || Array.isArray(d.id) || (typeof d.id === 'object' && d.id !== null),
    remedy: (d) => {
      const getObjStr = (obj) => {
        try {
          return JSON.stringify(obj) || String(obj);
        } catch (e) {
          return String(obj);
        }
      };
      if (d.payment_key !== null && d.payment_key !== undefined && (Array.isArray(d.payment_key) || typeof d.payment_key === 'object')) {
        d.payment_key = 'HASH-' + getObjStr(d.payment_key).replace(/[^a-zA-Z0-9]/g, '').slice(0, 16);
      }
      if (d.order_id !== null && d.order_id !== undefined && (Array.isArray(d.order_id) || typeof d.order_id === 'object')) {
        d.order_id = 'ORD-' + getObjStr(d.order_id).replace(/[^a-zA-Z0-9]/g, '').slice(0, 16);
      }
      if (d.id !== null && d.id !== undefined && (Array.isArray(d.id) || typeof d.id === 'object')) {
        d.id = 'ID-' + getObjStr(d.id).replace(/[^a-zA-Z0-9]/g, '').slice(0, 16);
      }
      d.healing_applied = '복합 객체(List/Dict) 식별자 직렬화 평탄화 해시 안전 변환';
      return d;
    }
  },
  L7_NUMERIC_TYPE_COERCION_FAIL: {
    match: (d) => (d.batch_size !== undefined && typeof d.batch_size !== 'number') || (d.retry_count !== undefined && typeof d.retry_count !== 'number'),
    remedy: (d) => {
      if (d.batch_size !== undefined) d.batch_size = Number(d.batch_size) || 1;
      if (d.retry_count !== undefined) d.retry_count = Number(d.retry_count) || 0;
      d.healing_applied = '비수치형 배치/재시도 값 안전 정수형 강제 변환 및 클램핑';
      return d;
    }
  },
  L7_DEEP_PRICE_FRAUD_BYPASS: {
    match: (d) => {
      // [FIND_004, FIND_005, FIND_006, FIND_014, FIND_015 해결] 리뷰 피드 데이터인 경우 결제 사기 오탐 격리 방지
      if (isReviewData(d)) return false;
      // [FIND_003 해결] WooCommerce total 금액 필드 추가
      const raw = d.total_price !== undefined ? d.total_price : (d.total !== undefined ? d.total : (d.order_amount !== undefined ? d.order_amount : (d.total_amount !== undefined ? d.total_amount : d.amount)));
      if (raw === undefined) return false;
      const num = Number(toSafeString(raw).replace(/[₩$원,]/g, ''));

      // [FIND_010 해결] Infinity/비한정 비정상 수치 차단
      if (!Number.isFinite(num)) return true;

      // [FIND_003 & FIND_004 해결] 경영 리포트/재무 집계 컨텍스트에서는 매출 0원(휴무) 및 적자(-금액) 허용
      const isExecReport = d.sales !== undefined || d.expenses !== undefined || d.report_type || d.anomaly_flag || d.executive_salary || d.sales_memo || d.report_detail || d.report_title || d.hours !== undefined || d.executive_briefing || (typeof context !== 'undefined' && (context.isCron || context.category === 'EXECUTIVE_REPORTING'));
      if (isExecReport) return false;

      // Stripe 정상 0원 프로모션/무료 체험 결제건 오탐 방지 (FIND_005)
      const isZeroPromo = (num === 0 && (
        d.is_zero_promo === true ||
        d.is_free_promo === true ||
        (typeof d.description === 'string' && (d.description.toLowerCase().includes('promo') || d.description.toLowerCase().includes('free'))) ||
        (typeof d.event_id === 'string' && d.event_id.toLowerCase().includes('promo'))
      ));
      if (isZeroPromo) return false;
      return isNaN(num) || num <= 0;
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.quarantine_reason = 'INVALID_PAYMENT_AMOUNT';
      d.status = 'QUARANTINED';
      d.healing_applied = '0원/마이너스 결제 사기 탐지 및 DLQ 즉시 격리';
      return d;
    }
  },
  L7_NUMERIC_ZERO_STOCK_BYPASS: {
    match: (d) => {
      // [FIND_004, FIND_005, FIND_006, FIND_014, FIND_015, FIND_005_R7 해결] 리뷰 피드 및 개발 릴리즈 데이터인 경우 재고 소진 오탐 격리 방지
      if (isReviewData(d) || d.release !== undefined || d.action === 'published') return false;
      // [FIND_008 해결] 우커머스 정상 예약/이월 주문(backorders_allowed: true)인 경우 재고 소진 오탐 격리 방지
      if (d.backorders_allowed === true || d.backorders === 'yes' || d.backorder === true || d.is_backorder === true) return false;
      // [FIND_007, FIND_008 해결] 경쟁사 가격 모니터링 시스템의 재고 소진(stock: 0, "품절")은 정상 시장 정보이므로 DLQ 격리 방지
      if (d.competitor_price !== undefined || d.competitor_name !== undefined || d.report_id !== undefined || d.is_competitor === true) return false;
      // [FIND_007 해결] 경영 리포트 / 일일 브리핑 컨텍스트에서는 품절 보고(stock: 0) 정상 허용
      if (d.sales !== undefined || d.report_type !== undefined || d.executive_briefing !== undefined || d.out_of_stock_item !== undefined || (typeof context !== 'undefined' && (context.isCron || context.category === 'EXECUTIVE_REPORTING'))) return false;

      function isOutOfStock(val) {
        if (val === undefined || val === null) return false;
        if (typeof val === 'string' && (val.includes('품절') || val.trim() === '')) return true;
        const num = Number(val);
        return isNaN(num) || num <= 0;
      }
      return isOutOfStock(d.stock) || isOutOfStock(d.stock_quantity) || isOutOfStock(d.remaining_stock);
    },
    remedy: (d) => {
      d.airbag_dlq_quarantined = true;
      d.is_out_of_stock = true;
      d.quarantine_reason = 'PRODUCT_OUT_OF_STOCK';
      d.status = 'QUARANTINED';
      d.healing_applied = '수치형/비수치형 재고 결품 감지 및 DLQ 격리 분기';
      return d;
    }
  },
  L7_HOMOGLYPH_IDEMPOTENCY_EVASION: {
    match: (d) => {
      const raw = toSafeString(d.order_id || '');
      return /[\u0410-\u044F\u200B-\u200D\uFEFF\u3000]/.test(raw);
    },
    remedy: (d) => {
      const cyrillicMap = { '\u041E': 'O', '\u0410': 'A', '\u0412': 'B', '\u0415': 'E', '\u041A': 'K', '\u041C': 'M', '\u041D': 'H', '\u0420': 'P', '\u0421': 'C', '\u0422': 'T', '\u0423': 'Y', '\u0425': 'X' };
      let norm = toSafeString(d.order_id || '').normalize('NFKC');
      norm = norm.replace(/[\u0410-\u044F]/g, c => cyrillicMap[c] || c);
      norm = norm.replace(/[\s\u200B-\u200D\uFEFF\u3000]/g, '').trim().toUpperCase();
      d.order_id = norm;
      d.healing_applied = 'Unicode NFKC + 키릴 호모글리프 영문 표준 통일 정규화';
      return d;
    }
  }
};

function flattenDeep(input) {
  if (!Array.isArray(input)) return [input];
  return input.reduce((acc, val) => Array.isArray(val) ? acc.concat(flattenDeep(val)) : acc.concat(val), []);
}

function runAirbag9HealingMatrix(inputItems = []) {
  let normalizedItems = [];
  if (Array.isArray(inputItems)) {
    normalizedItems = inputItems;
  } else if (inputItems && typeof inputItems === 'object' && typeof inputItems.all === 'function') {
    normalizedItems = inputItems.all() || [];
  } else if (inputItems && typeof inputItems === 'object') {
    normalizedItems = [inputItems.json !== undefined ? inputItems : { json: inputItems }];
  }

  const outItems = [];
  for (const rawItem of normalizedItems) {
    const item = (rawItem && typeof rawItem === 'object') ? rawItem : { json: rawItem };
    let d;
    if (Array.isArray(item.json)) {
      const flat = flattenDeep(item.json).filter(x => x !== null && x !== undefined);
      const criticalObj = flat.find(x => {
        if (!x || typeof x !== 'object') return false;
        const candidateFields = ['rating', 'score', 'overall_rating', 'total_score', 'user_rating', 'value', 'item_score', 'star_count', 'grade', 'food_rating', 'service_rating', 'taste', 'delivery'];
        let r = undefined;
        let foundR = [];
        for (const f of candidateFields) {
          if (x[f] !== undefined && x[f] !== null && x[f] !== '') {
            foundR.push(x[f]);
          }
        }
        if (foundR.length > 0) {
          const bad = foundR.find(val => {
            const num = typeof val === 'number' ? val : parseFloat(String(val).replace(/[^0-9.eE+-]/g, ''));
            return !isNaN(num) && num < 3;
          });
          r = bad !== undefined ? bad : foundR[0];
        }
        const text = typeof x.review_text === 'string' ? x.review_text : (typeof x.comment === 'string' ? x.comment : (typeof x.content === 'string' ? x.content : (typeof x.text === 'string' ? x.text : '')));
        const numR = resolveUniversalScale(r, text, 'rating');
        if (!isNaN(numR) && numR < 3) return true;
        const valence = evaluateSyntacticValence(text);
        if (valence.isCrisis && !valence.isPraise) return true;
        return false;
      });
      // [FIND_TC_05_2 해결] 리뷰 객체를 일반 주문/상품 객체보다 우선 선택
      const reviewObj = flat.find(x => x && typeof x === 'object' && isReviewData(x));
      const firstObj = flat.find(x => x && typeof x === 'object');
      const selected = criticalObj || reviewObj || firstObj || flat[0] || {};
      d = (selected && typeof selected === 'object') ? { ...selected } : { value: selected, rating: selected, score: selected, raw_data: String(selected) };
    } else if (item.json && typeof item.json === 'object') {
      d = { ...item.json };
    } else {
      d = { value: item.json, rating: item.json, score: item.json, raw_data: String(item.json) };
    }

    // [T24] L0~L4 능동방어 스위트 런타임 실 바인딩 (Dead Code 100% 해소)
    // 1. L0: 인플로우 바이패스 방어 (빈 객체 또는 비정상 구조 검증)
    const inflowCheck = L0_preventBypassInflow(d);
    if (!inflowCheck.valid) {
      d._inflow_defense = { status: 'DEFENDED', reason: inflowCheck.reason };
      if (inflowCheck.reason === 'EMPTY_INFLOW_PAYLOAD_BYPASS_BLOCKED') {
        d._healed_empty_payload = true;
        d.status = d.status || 'EMPTY_PAYLOAD_RECOVERED';
      }
    } else {
      d._inflow_defense = { status: 'PASSED', reason: 'INFLOW_PASSED' };
    }

    // 2. L4: 제로위드 및 악성 SQL 주입 패턴 선제적 정제
    for (const [k, v] of Object.entries(d)) {
      if (typeof v === 'string') {
        const purged = L4_zeroWidthAndSqlPurge(v);
        if (purged !== v) {
          d[k] = purged;
          d._l4_purged = true;
        }
      }
    }

    // 3. L1: 안전한 프로퍼티 접근 (중첩 필드 안전 추출 및 키 보존)
    const safeOrderId = L1_safePropertyAccess(d, 'order_id') || L1_safePropertyAccess(d, 'order.id') || L1_safePropertyAccess(d, 'data.order_id');
    if (safeOrderId && !d.order_id) {
      d.order_id = safeOrderId;
    }

    // 4. L2: 엄격한 조건식 평가 (부정/크라이시스 조건 사전 정밀 평가)
    const rawRating = L1_safePropertyAccess(d, 'rating', null);
    const isLowRating = L2_strictConditionEvaluate(rawRating, 'less_than', 3);
    if (isLowRating) {
      d._is_low_rating_flag = true;
    }

    // 5. L3: 지수 백오프 게이트 (재시도 및 서킷 브레이커 정책 사전 산출)
    const attemptCount = Number(L1_safePropertyAccess(d, 'retry_count', 1));
    const backoffGate = L3_exponentialBackoffGate(attemptCount);
    d._backoff_gate = backoffGate;

    let appliedChaosList = [];

    for (const [code, handler] of Object.entries(CHAOS_SIGNATURES)) {
      if (handler.match(d)) {
        d = handler.remedy(d);
        appliedChaosList.push({
          chaos_code: code,
          healing: d.healing_applied,
          timestamp: new Date().toISOString()
        });
      }
    }

    d.airbag_chaos_matrix_verified = true;
    if (appliedChaosList.length > 0) {
      d.chaos_healing_applied = appliedChaosList;
      d.chaos_healing_status = 'AUTO_HEALED';
    }

    outItems.push({ json: d });
  }

  return outItems;
}

if (typeof module !== 'undefined' && module && module.exports) {
  module.exports = {
    runAirbag9HealingMatrix,
    CHAOS_SIGNATURES,
    toSafeString,
    isValidBizNumber,
    maskPII,
    L0_preventBypassInflow,
    L1_safePropertyAccess,
    L2_strictConditionEvaluate,
    L3_exponentialBackoffGate,
    L4_zeroWidthAndSqlPurge,
    normalizeScore,
    getValidInner,
    evaluateSyntacticValence,
    resolveUniversalScale,
    isReviewData,
    flattenDeep
  };
}

if (typeof $input !== 'undefined' && $input && typeof $input.all === 'function') {
  const result = runAirbag9HealingMatrix(items);
  healedItems.push(...result);
  return healedItems;
}

