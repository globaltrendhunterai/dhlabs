/**
 * AutoFlow Checkpoint & WAL Resume Manager
 * ========================================
 * [핵심 기능]
 * 1. 노드 실행 중 장애/크래시 발생 시, 노드 재부팅 직전 원자적(Atomic) 스냅샷 저장
 *    - 경로: data/checkpoints/{execution_id}.json
 *    - 저장 정보: execution_id, workflow_id, failed_node, progress_dag, completed_outputs
 * 2. 복구/패치 후 런타임 재시작 시:
 *    - 앞단 성공 노드는 완전히 건너뛰고(Skip - 중복 결제/중복 발송 방지)
 *    - 실패했던 노드에 직전 출력 데이터를 직접 주입(Direct Injection)하여 이어서 완주(Resume)
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const vaultCrypto = require('./security/vault_crypto');

const CHECKPOINT_DIR = path.join(__dirname, '../data/checkpoints');
const CHECKPOINT_AUDIT_LOG = path.join(__dirname, '../logs/checkpoint_audit.jsonl');

function ensureDir(dir) {
    if (!fs.existsSync(dir)) {
        try {
            fs.mkdirSync(dir, { recursive: true });
        } catch (e) {
            console.warn(`[WARN] CheckpointManager ensureDir failed for ${dir}: ${e.message}`);
        }
    }
}

class CheckpointManager {
    constructor(checkpointDir = CHECKPOINT_DIR) {
        this.checkpointDir = (typeof checkpointDir === 'string' && checkpointDir.trim()) ? checkpointDir : CHECKPOINT_DIR;
        this.secretKey = 'AUTOFLOW_DEFAULT_JOURNAL_KEY';
        ensureDir(this.checkpointDir);
        ensureDir(path.dirname(CHECKPOINT_AUDIT_LOG));
    }

    getCheckpointPath(executionId) {
        const safeId = (typeof executionId === 'string' && executionId.trim())
            ? executionId.trim()
            : String((executionId && (executionId.execution_id || executionId.executionId || executionId.id)) || 'default_exec');
        return path.join(this.checkpointDir, `${safeId}.json`);
    }

    /**
     * 장애 발생 시 원자적 스냅샷 저장 (Atomic File Write via Temp Rename)
     */
    saveCheckpoint(executionId, workflowId, failedNode, completedOutputs, contextData = {}) {
        if (executionId && typeof executionId === 'object' && workflowId === undefined) {
            const state = executionId;
            executionId = state.execution_id || state.executionId || state.id || 'default_exec';
            workflowId = state.workflow_id || state.workflowId || 'default_wf';
            failedNode = state.failed_node || state.failedNode || 'unknown_node';
            completedOutputs = (state.completed_outputs && typeof state.completed_outputs === 'object') ? state.completed_outputs : {};
            contextData = (state.context_data && typeof state.context_data === 'object') ? state.context_data : state;
        }
        executionId = (typeof executionId === 'string' && executionId.trim()) ? executionId.trim() : 'default_exec';
        completedOutputs = (completedOutputs && typeof completedOutputs === 'object') ? completedOutputs : {};
        contextData = (contextData && typeof contextData === 'object') ? contextData : {};

        const filePath = this.getCheckpointPath(executionId);
        const tempPath = `${filePath}.tmp.${Date.now()}`;

        const snapshot = {
            execution_id: executionId,
            workflow_id: workflowId,
            failed_node: failedNode,
            timestamp: new Date().toISOString(),
            status: 'HALTED_AWAITING_RESUME',
            completed_nodes: Object.keys(completedOutputs),
            completed_outputs: completedOutputs,
            context_data: contextData
        };

        try {
            // 원자적 쓰기 (크래시 중 파일 손상 방지)
            fs.writeFileSync(tempPath, JSON.stringify(snapshot, null, 2), 'utf8');
            fs.renameSync(tempPath, filePath);

            // 감사 원장 기록
            const auditEntry = JSON.stringify({
                timestamp: new Date().toISOString(),
                action: 'CHECKPOINT_SAVED',
                execution_id: executionId,
                workflow_id: workflowId,
                failed_node: failedNode,
                completed_count: Object.keys(completedOutputs).length,
                status: 'SNAPSHOT_PRESERVED'
            }) + '\n';
            fs.appendFileSync(CHECKPOINT_AUDIT_LOG, auditEntry, 'utf8');

            return { success: true, path: filePath, snapshot };
        } catch (err) {
            try {
                if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
            } catch (unlinkErr) {
                console.warn(`[WARN] CheckpointManager tempPath cleanup failed: ${unlinkErr.message}`);
            }
            return { success: false, error: err.message };
        }
    }

    /**
     * 체크포인트 존재 여부 및 로드
     */
    loadCheckpoint(executionId) {
        if (!executionId || (typeof executionId !== 'string' && !(typeof executionId === 'object' && (executionId.execution_id || executionId.executionId || executionId.id)))) {
            return null;
        }
        const filePath = this.getCheckpointPath(executionId);
        if (!fs.existsSync(filePath)) {
            return null;
        }

        try {
            const content = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(content);
        } catch (err) {
            console.warn(`[WARN] CheckpointManager loadCheckpoint parse failed: ${err.message}`);
            return null;
        }
    }

    /**
     * 체크포인트 완주 후 정상 소각/아카이브
     */
    finalizeCheckpoint(executionId, finalResult) {
        if (!executionId) return;
        const filePath = this.getCheckpointPath(executionId);
        if (fs.existsSync(filePath)) {
            try {
                // 완료 상태로 갱신 후 아카이브
                const snapshot = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                snapshot.status = 'COMPLETED_RESUMED';
                snapshot.resumed_at = new Date().toISOString();
                snapshot.final_result = finalResult;
                fs.writeFileSync(filePath, JSON.stringify(snapshot, null, 2), 'utf8');

                const auditEntry = JSON.stringify({
                    timestamp: new Date().toISOString(),
                    action: 'CHECKPOINT_RESUMED_AND_FINALIZED',
                    execution_id: executionId,
                    status: 'RESUME_SUCCESS'
                }) + '\n';
                fs.appendFileSync(CHECKPOINT_AUDIT_LOG, auditEntry, 'utf8');
            } catch (e) {
                console.warn(`[WARN] CheckpointManager finalizeCheckpoint failed: ${e.message}`);
            }
        }
    }

    /**
     * DAG 파이프라인 무중단 재개 (Resume Engine)
     * - pipelineNodes: 실행할 전체 노드 정의 배열 [{ name, run(input) }]
     * - executionId: 실행 ID
     * - initialInput: 최초 입력값
     */
    async executeOrResumePipeline(pipelineNodes, executionId, workflowId, initialInput, options = {}) {
        pipelineNodes = Array.isArray(pipelineNodes) ? pipelineNodes : [];
        options = (options && typeof options === 'object') ? options : {};
        const snapshot = this.loadCheckpoint(executionId);
        const completedOutputs = snapshot ? { ...snapshot.completed_outputs } : {};
        const isResuming = !!snapshot && snapshot.status === 'HALTED_AWAITING_RESUME';

        const executionLog = [];
        let currentInput = initialInput;

        for (let i = 0; i < pipelineNodes.length; i++) {
            const node = (pipelineNodes[i] && typeof pipelineNodes[i] === 'object') ? pipelineNodes[i] : { name: `node_${i}`, run: async (x) => x };
            const nodeName = node.name;

            // 1. 앞단 성공 노드 Skip 로직
            if (isResuming && completedOutputs[nodeName] !== undefined) {
                executionLog.push({
                    node: nodeName,
                    action: 'SKIPPED_DUE_TO_CHECKPOINT',
                    reason: '이전 실행에서 이미 성공 완료됨 (중복 실행 방지)',
                    output: completedOutputs[nodeName]
                });
                // 다음 노드로 전달할 입력값은 저장된 체크포인트 출력값 사용
                currentInput = completedOutputs[nodeName];
                continue;
            }

            // 2. 실패했던 노드부터 직접 주입 및 실행
            try {
                // 고의 에러 트리거 지원 (테스트용)
                if (options.forceFailNode === nodeName) {
                    throw new Error(`IntentionalCrashInNode:${nodeName} - External API Timeout 504`);
                }

                const output = await node.run(currentInput);
                completedOutputs[nodeName] = output;
                currentInput = output;

                executionLog.push({
                    node: nodeName,
                    action: isResuming ? 'RESUMED_AND_EXECUTED' : 'NORMAL_EXECUTED',
                    output
                });
            } catch (err) {
                // 장애 발생! 노드 재부팅 직전 원자적 체크포인트 스냅샷 저장
                this.saveCheckpoint(executionId, workflowId, nodeName, completedOutputs, {
                    last_error: err.message,
                    failed_at_step: i + 1
                });

                executionLog.push({
                    node: nodeName,
                    action: 'HALTED_ON_CRASH',
                    error: err.message,
                    checkpoint_saved: true
                });

                return {
                    success: false,
                    haltedAt: nodeName,
                    error: err.message,
                    executionId,
                    checkpointSaved: true,
                    executionLog
                };
            }
        }

        // 전체 완주 성공 시 체크포인트 완료 처리
        if (isResuming) {
            this.finalizeCheckpoint(executionId, currentInput);
        }

        return {
            success: true,
            executionId,
            wasResumed: isResuming,
            finalOutput: currentInput,
            executionLog
        };
    }

    /**
     * 저널 파일 경로 반환 (data/checkpoints/{executionId}.wal.vault)
     */
    getSecureJournalPath(executionId) {
        const safeId = (typeof executionId === 'string' && executionId.trim())
            ? executionId.trim()
            : String((executionId && (executionId.execution_id || executionId.executionId || executionId.id)) || 'default_exec');
        return path.join(this.checkpointDir, `${safeId}.wal.vault`);
    }

    /**
     * Vault Sentinel 암호화 원자적 저널링 (Write-Ahead Log with AES-256-GCM + fsync)
     * 포맷: [4바이트 길이 헤더] + [SHA-256 체크섬 32바이트] + [JSON 암호문 바이트] + \n
     * 파일 경로: data/checkpoints/{executionId}.wal.vault
     * 물리 플러시: fs.openSync -> fs.writeSync -> fs.fsyncSync(fd) -> fs.closeSync(fd)
     * @param {string} executionId - 실행 ID
     * @param {any} payload - 암호화 저장할 원본 페이로드
     * @param {object} [options] - 옵션 (customMasterKey 등)
     * @returns {object} { success: true, path, bytesWritten, executionId }
     */
    saveSecureJournal(executionId, payload, options = {}) {
        if (executionId && typeof executionId === 'object' && (payload === undefined || typeof payload === 'string')) {
            if (typeof payload === 'string') {
                options = { customMasterKey: payload };
            }
            payload = executionId;
            executionId = payload.execution_id || payload.executionId || payload.id || 'default_exec';
        }
        executionId = (typeof executionId === 'string' && executionId.trim()) ? executionId.trim() : 'default_exec';
        if (payload === undefined || payload === null) {
            payload = {};
        }
        if (typeof options === 'string') {
            options = { customMasterKey: options };
        } else {
            options = (options && typeof options === 'object') ? options : {};
        }

        ensureDir(this.checkpointDir);
        const journalPath = this.getSecureJournalPath(executionId);

        // 1) payload를 vault_crypto.encrypt()로 AES-256-GCM 암호화
        const customKey = options.customMasterKey || null;
        const hmacSecretKey = customKey || this.secretKey || 'AUTOFLOW_DEFAULT_JOURNAL_KEY';
        const hmacSignature = crypto.createHmac('sha256', String(hmacSecretKey)).update(JSON.stringify(payload)).digest('hex');
        const encryptedEnvelope = vaultCrypto.encrypt(payload, customKey, options);
        const jsonCipherBuffer = Buffer.from(JSON.stringify(encryptedEnvelope), 'utf8');

        // 2) 저널 포맷: [4바이트 길이 헤더] + [SHA-256 체크섬 32바이트] + [JSON 암호문 바이트] + \n
        const lengthHeader = Buffer.alloc(4);
        lengthHeader.writeUInt32BE(jsonCipherBuffer.length, 0);

        const checksum = crypto.createHash('sha256').update(jsonCipherBuffer).digest(); // 32바이트
        const newline = Buffer.from('\n', 'utf8'); // 1바이트

        const record = Buffer.concat([lengthHeader, checksum, jsonCipherBuffer, newline]);

        // 3) 파일 경로: data/checkpoints/{executionId}.wal.vault
        // 4) fs.openSync -> fs.writeSync -> fs.fsyncSync(fd) -> fs.closeSync(fd) 디스크 물리 플러시 강제
        const fd = fs.openSync(journalPath, 'a');
        try {
            fs.writeSync(fd, record);
            fs.fsyncSync(fd);
        } finally {
            fs.closeSync(fd);
        }

        try {
            const auditEntry = JSON.stringify({
                timestamp: new Date().toISOString(),
                action: 'SECURE_JOURNAL_SAVED',
                execution_id: executionId,
                bytes_written: record.length,
                hmac_signature: hmacSignature,
                status: 'FSYNC_COMMITTED'
            }) + '\n';
            fs.appendFileSync(CHECKPOINT_AUDIT_LOG, auditEntry, 'utf8');
        } catch (auditErr) {
            console.warn(`[WARN] CheckpointManager audit logging failed: ${auditErr.message}`);
        }

        return {
            success: true,
            path: journalPath,
            bytesWritten: record.length,
            executionId
        };
    }

    /**
     * Vault Sentinel 저널 복구 (Self-Healing Torn Write Recovery + AES-256-GCM Decryption)
     * 1) 저널 파일을 바이트 단위로 파싱.
     * 2) 각 레코드의 SHA-256 체크섬을 검증하여, 정전으로 중간에 찢어진(Torn Write)
     *    불완전한 마지막 블록은 안전하게 건너뛰고 직전의 온전한 레코드까지 100% 복구.
     * 3) vault_crypto.decrypt()로 복호화하여 원본 payload 반환.
     * @param {string} executionId - 실행 ID
     * @param {object} [options] - 옵션 (customMasterKey 등)
     * @returns {Array} 복구된 payload 목록 (latest, payload, payloads, count 속성 포함)
     */
    recoverFromJournal(executionId, options = {}) {
        if (typeof options === 'string') {
            options = { customMasterKey: options };
        } else {
            options = (options && typeof options === 'object') ? options : {};
        }
        const journalPath = this.getSecureJournalPath(executionId);
        if (!executionId || typeof executionId !== 'string' || !fs.existsSync(journalPath)) {
            const emptyResult = [];
            emptyResult.latest = null;
            emptyResult.payload = null;
            emptyResult.payloads = [];
            emptyResult.count = 0;
            return emptyResult;
        }

        const fileBuffer = fs.readFileSync(journalPath);
        const records = [];
        let offset = 0;
        const totalBytes = fileBuffer.length;
        const customKey = options.customMasterKey || null;

        while (offset < totalBytes) {
            // [4바이트 길이 헤더] 확인
            if (offset + 4 > totalBytes) {
                console.warn(`[WARN] VaultJournal torn write detected: remaining ${totalBytes - offset} bytes < 4 byte length header at offset ${offset}. Safely truncating tail.`);
                break;
            }

            const payloadLength = fileBuffer.readUInt32BE(offset);
            const recordLength = 4 + 32 + payloadLength + 1; // 4 (len) + 32 (sha256) + payloadLength + 1 (\n)

            if (offset + recordLength > totalBytes) {
                console.warn(`[WARN] VaultJournal torn write detected: incomplete block at offset ${offset}. Expected ${recordLength} bytes, available ${totalBytes - offset} bytes. Safely truncating tail.`);
                break;
            }

            const expectedChecksum = fileBuffer.slice(offset + 4, offset + 36);
            const jsonCipherBytes = fileBuffer.slice(offset + 36, offset + 36 + payloadLength);
            const newlineByte = fileBuffer[offset + 36 + payloadLength];

            if (newlineByte !== 0x0A) {
                console.warn(`[WARN] VaultJournal torn write detected: missing delimiter byte (0x0A) at offset ${offset + 36 + payloadLength}. Skipping torn block.`);
                break;
            }

            const actualChecksum = crypto.createHash('sha256').update(jsonCipherBytes).digest();
            if (!expectedChecksum.equals(actualChecksum)) {
                console.warn(`[WARN] VaultJournal checksum mismatch at offset ${offset}. Expected ${expectedChecksum.toString('hex')}, calculated ${actualChecksum.toString('hex')}. Skipping torn block.`);
                break;
            }

            try {
                const encryptedEnvelope = JSON.parse(jsonCipherBytes.toString('utf8'));
                const decryptedPayload = vaultCrypto.decrypt(encryptedEnvelope, customKey);
                records.push(decryptedPayload);
            } catch (decErr) {
                console.warn(`[WARN] VaultJournal decryption error at offset ${offset}: ${decErr.message}. Skipping corrupted block.`);
                break;
            }

            offset += recordLength;
        }

        records.latest = records.length > 0 ? records[records.length - 1] : null;
        records.payload = records.length > 0 ? records[records.length - 1] : null;
        records.payloads = records;
        records.count = records.length;

        return records;
    }
}

const defaultManager = new CheckpointManager();

function saveSecureJournal(executionId, payload, options = {}) {
    return defaultManager.saveSecureJournal(executionId, payload, options);
}

function recoverFromJournal(executionId, options = {}) {
    return defaultManager.recoverFromJournal(executionId, options);
}

module.exports = {
    CheckpointManager,
    CHECKPOINT_DIR,
    CHECKPOINT_AUDIT_LOG,
    saveSecureJournal,
    recoverFromJournal
};
