/**
 * AutoFlow HQ — 무인 CS & 티켓 자동 발급 봇 엔진
 *
 * 1단계: 1차 고속 정규식/결정론적 분류기 (환각 0%, 지연 0.001초, 주문번호 검증 & 30종 단골 KB)
 * 2단계: 2차 자유 질문 로컬 AI 처리기 (로컬 Ollama autoflow-healer:gemma3 4초 타임아웃 가드)
 * 3단계: 3차 에스컬레이션 가드 (환불/인간 상담원/긴급 오류 시 대표님 텔레그램 직보)
 */

'use strict';

const http = require('http');
const path = require('path');
const fs = require('fs');
const { LicenseManager } = require('./license_manager');

// 단골 질문 검증 지식베이스 (KB)
const VERIFIED_KNOWLEDGE_BASE = [
  {
    id: 'KB-CUSTOM-WORKFLOW-STANDALONE',
    patterns: [/기존.*워크플로우|자가치유만|정합성만|블루프린트.*아닌|노드.*그대로|등록.*api.*없|api.*안.*넣/i],
    title: '기존 자체 워크플로우 그대로 가져오기 & API 무입력 가동 안내',
    answer: `🔗 [고객 워크플로우 노드 그대로 가져오기 & 무설정 가동 안내]\n━━━━━━━━━━━━━━━━━━\n1️⃣ [등록할 API가 없거나 노드에 이미 세팅된 경우]: 별도로 API를 지정하거나 입력하실 필요가 없습니다. 그대로 가동하시면 워크플로우 노드의 기존 연결·인증을 그대로 사용합니다.\n2️⃣ [당사 블루프린트 없이 자가치유·정합성만 구매하신 고객]: 셋업 위저드(http://127.0.0.1:5678)의 [🔗 워크플로우 노드 그대로 가져오기 & 자가치유·정합성 직결] 카드에서 [📁 워크플로우 JSON 파일 선택] 또는 JSON 붙여넣기를 클릭하시면, 고객님이 쓰시던 노드를 그대로 가져와 127ms 자가치유와 정합성 엔진을 즉시 결선합니다.`
  },
  {
    id: 'KB-COUPANG-API',
    patterns: [/쿠팡.*(api|키|발급|access|secret|wing)/i, /coupang.*(api|key)/i, /wing.*api/i],
    title: '쿠팡 워크플로우 노드 연동 안내',
    answer: `📌 [쿠팡 워크플로우 노드 연동 안내]\n━━━━━━━━━━━━━━━━━━\n1️⃣ 이미 사용 중이신 워크플로우 노드에 인증이 설정되어 있다면 별도 API 입력 없이 노드를 그대로 가져와 즉시 가동됩니다.\n2️⃣ 외부 변수로 키를 주입하려는 경우에만 셋업 위저드(http://127.0.0.1:5678) [🔗 워크플로우 노드 그대로 가져오기] 하단의 [⚙️ 선택 사항: 외부 변수 수동 오버라이드]를 열어 업체코드(Vendor ID), Access Key, Secret Key를 선택적으로 입력하실 수 있습니다.`
  },
  {
    id: 'KB-KAKAO-ALIMTALK',
    patterns: [/알림톡|카카오.*(알림|문자|세팅)|솔라피|coolsms/i],
    title: '알림톡 / 메시징 노드 연동 안내',
    answer: `💬 [알림톡 / 메시징 워크플로우 노드 연동 안내]\n━━━━━━━━━━━━━━━━━━\n1️⃣ 고객님의 워크플로우 노드에 이미 메시징/알림톡 인증이 포함되어 있다면 별도 입력 없이 기존 노드 설정을 그대로 사용합니다.\n2️⃣ 외부 변수로 솔라피(Solapi) 키를 덮어쓰실 경우에만 셋업 위저드(http://127.0.0.1:5678) [🔗 워크플로우 노드 그대로 가져오기] 하단의 [⚙️ 선택 사항: 외부 변수 수동 오버라이드]에서 입력 및 발송 테스트를 진행하실 수 있습니다.`
  },
  {
    id: 'KB-SLACK-WEBHOOK',
    patterns: [/슬랙|slack.*(webhook|웹훅|알림)/i],
    title: '슬랙(Slack) 장애/주문 알림 연동 안내',
    answer: `🔔 [슬랙(Slack) 웹훅 알림 설정]\n━━━━━━━━━━━━━━━━━━\n1️⃣ Slack 채널 설정에서 수신 웹훅(Incoming Webhook) URL을 생성합니다.\n2️⃣ 셋업 위저드(http://127.0.0.1:5678) 알림 설정에 Webhook URL을 붙여넣습니다.\n3️⃣ 노드 에러 자가치유 리포트, 정합성 대사 결과, 프로그램 자동 소생 알림이 해당 슬랙 채널로 실시간 전달됩니다.`
  },
  {
    id: 'KB-DOCKER-NEED',
    patterns: [/도커|docker/i],
    title: '도커(Docker) 설치 필요 여부',
    answer: `🐳 [도커(Docker) 설치 불필요 안내]\n━━━━━━━━━━━━━━━━━━\nAutoFlow는 별도 설치 없는 일체형 프로그램이므로 도커(Docker) 없이도 더블클릭만으로 즉시 작동합니다.\n(※ 사내에 이미 Docker 환경이 갖춰진 경우 docker-compose를 통한 컨테이너 구동도 지원합니다.)`
  },
  {
    id: 'KB-RUN-MAC',
    patterns: [/맥.*(실행|구동|mac)|mac.*(start|run|launch)/i],
    title: 'macOS 환경 1초 실행 방법',
    answer: `🍎 [macOS 1초 시동 방법]\n━━━━━━━━━━━━━━━━━━\n1️⃣ 다운로드받은 압축파일을 풀고 폴더를 엽니다.\n2️⃣ AutoFlow_시작하기_Mac.command 파일을 마우스 더블클릭합니다.\n3️⃣ 브라우저에 셋업 위저드(http://127.0.0.1:5678)가 자동으로 열리며 즉시 가동됩니다.`
  },
  {
    id: 'KB-RUN-WIN',
    patterns: [/윈도우.*(실행|구동|windows)|win.*(start|run|bat)/i],
    title: 'Windows 환경 1초 실행 방법',
    answer: `🪟 [Windows 1초 시동 방법]\n━━━━━━━━━━━━━━━━━━\n1️⃣ 다운로드받은 압축파일을 C: 드라이브 등에 풉니다.\n2️⃣ AutoFlow_시작하기_Windows.bat 파일을 마우스 더블클릭합니다.\n3️⃣ 브라우저에 셋업 위저드(http://127.0.0.1:5678)가 자동으로 열리며 즉시 가동됩니다.`
  },
  {
    id: 'KB-PORT-CONFLICT',
    patterns: [/포트.*(충돌|5678|이미|eaddrinuse)|port.*(5678|conflict)/i],
    title: '포트 5678 충돌(EADDRINUSE) 해결법',
    answer: `⚠️ [포트 5678 충돌 해결 안내]\n━━━━━━━━━━━━━━━━━━\n1️⃣ 이미 사내 PC의 5678 포트에서 기존 n8n이나 워크플로우가 실행 중인 경우, AutoFlow가 해당 워크플로우 노드를 자동 감지하여 자가치유·정합성 브릿지로 연결하거나 가용 포트로 안전하게 기동합니다.\n2️⃣ 기존 AutoFlow 프로세스를 재시작하려면 AutoFlow_Stop 파일을 실행한 뒤 다시 시작해 주세요.`
  },
  {
    id: 'KB-RECONFLOW',
    patterns: [/정합성|대사|1원|reconflow|장부|오차/i],
    title: 'ReconFlow 1원 금융 정합성 쉴드 원리',
    answer: `🛡 [ReconFlow 1원 금융 정합성 원리]\n━━━━━━━━━━━━━━━━━━\n고객님의 워크플로우 분기 노드(주문·결제·재고·정산 장부) 간 데이터를 1원 단위까지 실시간 교차 대조합니다.\n통신 장애로 인한 분기 단절이나 금액 오차를 즉시 감지하여 [안전 임시 보관함(DLQ)]으로 격리하고 핀포인트 복구를 수행합니다.`
  },
  {
    id: 'KB-REFUND-POLICY',
    patterns: [/환불.*규정|취소.*규정|공정.*환불|위약금/i],
    title: '공정 환불 정산 규정 안내',
    answer: `⚖️ [AutoFlow 공정 환불 규정]\n━━━━━━━━━━━━━━━━━━\n• 활성화 7일 이내 결함 발생 시: 100% 전액 환불 보장\n• 7일 경과 후 환불 요청 시: [결제금액 - 실사용 일수 일할 차감 - 10% 위약수수료] 공정 정산 환불\n• 특별 혜택: 환불 처리 후에도 고객님이 영구 소장하신 기본 워크플로우는 중단 없이 평생 가동됩니다!`
  },
  {
    id: 'KB-SETUP-WIZARD',
    patterns: [/셋업.*위저드|setup_wizard|초기.*설정|마법사/i],
    title: '브라우저 셋업 위저드(setup_wizard.html) 안내',
    answer: `🧙‍♂️ [브라우저 셋업 위저드 안내]\n━━━━━━━━━━━━━━━━━━\n엔진 실행 후 브라우저 주소창에 http://127.0.0.1:5678 을 입력하시면 열립니다.\n고객님의 기존 워크플로우 노드를 그대로 가져와 자가치유·정합성 감시를 직결하고, 별도 API 등록 없이도 노드의 자체 설정으로 즉시 가동할 수 있습니다.`
  },
  {
    id: 'KB-TICKET-ACTIVATE',
    patterns: [/티켓.*등록|라이선스.*등록|af-tkt|서명.*티켓/i],
    title: '정품 서명 티켓(AF-TKT-v1) 등록 방법',
    answer: `🎟 [정품 티켓 등록 안내]\n━━━━━━━━━━━━━━━━━━\n1️⃣ 발급받으신 정품 서명 티켓 문자열(AF-TKT-v1...) 또는 라이선스 키를 전체 복사합니다.\n2️⃣ 셋업 위저드(http://127.0.0.1:5678) 상단의 [🔑 라이선스 활성화 / AI 키] 버튼 클릭 ➔ 팝업창에 라이선스 키 입력 후 [지금 활성화 완료하기] 클릭합니다.\n3️⃣ 구매하신 자가치유·정합성 모듈이 고객님의 워크플로우 노드에 즉시 결합되며, 등록 시점부터 이용 기간이 시작됩니다.`
  },
  {
    id: 'KB-HWID',
    patterns: [/hwid|하드웨어.*id|기기.*변경|pc.*교체/i],
    title: '1:1 HWID 기기 종속 및 이전 안내',
    answer: `💻 [사내 PC 전용 안전 잠금 및 기기 이전 안내]\n━━━━━━━━━━━━━━━━━━\n정품 티켓은 고객님의 사내 PC에 1:1로 안전하게 잠깁니다.\n컴퓨터 교체나 서버 이전이 필요하신 경우, 고객센터로 주문번호와 새 PC의 식별번호를 남겨주시면 안전하게 무상 기기 이전을 도와드립니다.`
  },
  {
    id: 'KB-SMARTSTORE-API',
    patterns: [/스마트스토어.*(api|연동|커머스)|naver.*(commerce|api)/i],
    title: '스마트스토어 워크플로우 노드 연동 안내',
    answer: `🟢 [스마트스토어 워크플로우 노드 연동 안내]\n━━━━━━━━━━━━━━━━━━\n특정 쇼핑몰 API를 별도로 지정할 필요 없이, 사용 중이신 스마트스토어 워크플로우 노드를 그대로 가져와 자가치유·정합성 엔진과 직결하여 바로 사용하실 수 있습니다.`
  },
  {
    id: 'KB-SHOPIFY-API',
    patterns: [/쇼피파이|shopify.*(api|연동|스토어|admin)/i],
    title: '쇼피파이(Shopify) 워크플로우 노드 연동 안내',
    answer: `🛍 [쇼피파이(Shopify) 워크플로우 노드 연동 안내]\n━━━━━━━━━━━━━━━━━━\n특정 API 입력창에 구애받지 않고 고객님의 쇼피파이 워크플로우 노드를 그대로 불러오시면, 노드에 설정된 기존 인증을 그대로 유지한 채 자가치유 및 정합성 감시가 즉시 작동합니다.`
  },
  {
    id: 'KB-CAFE24-API',
    patterns: [/카페24|cafe24.*(api|연동|몰)|아임웹|imweb/i],
    title: '자사몰(카페24/아임웹 등) 워크플로우 노드 연동 안내',
    answer: `☕️ [자사몰 워크플로우 노드 그대로 가져오기 안내]\n━━━━━━━━━━━━━━━━━━\n사용 중이신 자사몰/웹훅/ERP 워크플로우 노드를 [🔗 워크플로우 노드 그대로 가져오기]에서 그대로 불러오시면 별도 API 재입력 없이 즉시 자가치유·정합성 엔진이 결합됩니다.`
  },
  {
    id: 'KB-SELF-HEALING',
    patterns: [/자가치유|127ms|에어백|크래시|소생|데몬/i],
    title: '127ms 자가치유 가드 데몬 안내',
    answer: `⚡️ [0.1초 무인 자가치유 보호막]\n━━━━━━━━━━━━━━━━━━\n고객님의 워크플로우 노드를 그대로 감시하다가 외부 API 지연, 스키마 변이, 네트워크 순단 발생 시 127ms(0.12초) 만에 자동 복구하여 업무가 멈추지 않도록 보호합니다.`
  },
  {
    id: 'KB-TRIAL-PERIOD',
    patterns: [/무료.*체험|체험.*기간|7일.*체험|30일.*체험/i],
    title: '온디맨드 무료 체험 티켓 안내',
    answer: `🎁 [온디맨드 무료 체험 안내]\n━━━━━━━━━━━━━━━━━━\nAutoFlow의 무료 체험은 결제일이 아닌, 프로그램 최초 실행 시 7일 온디맨드 무료 체험이 백그라운드에서 자동 가동되므로 미리 다운로드받아 두셔도 이용 기간에 손해가 없습니다.`
  },
  {
    id: 'KB-CUSTOM-NODE',
    patterns: [/노드.*수정|워크플로우.*수정|커스텀|코드.*변경/i],
    title: '워크플로우 및 노드 수정 안내',
    answer: `✏️ [워크플로우 및 노드 자유 연동 안내]\n━━━━━━━━━━━━━━━━━━\n고객님이 직접 구성하신 기존 워크플로우 노드를 그대로 가져와 사용할 수 있으며, 노드를 추가하거나 변경하셔도 토폴로지 엔진이 자동으로 노드를 다시 스캔하여 자가치유·정합성 제어기를 바인딩합니다.`
  },
  {
    id: 'KB-SECURITY-PRIVACY',
    patterns: [/보안|개인정보|유출|클라우드.*저장|온프레미스/i],
    title: '100% 온프레미스 로컬 데이터 보안 안내',
    answer: `🔒 [100% 사내 PC 로컬 구동 (개인정보 완벽 보호)]\n━━━━━━━━━━━━━━━━━━\n외부 클라우드 서비스와 달리 고객님의 워크플로우 데이터나 노드 내 인증 정보가 외부 서버로 전송되지 않으며, 오직 사내 PC 안에서만 안전하게 처리됩니다.`
  },
  {
    id: 'KB-PERPETUAL-OWNERSHIP',
    patterns: [/영구.*소장|월.*비용|구독료.*없|평생/i],
    title: '월 고정비 없는 영구 소장 모델 안내',
    answer: `💎 [평생 영구 소장 및 모듈 단독 구매 안내]\n━━━━━━━━━━━━━━━━━━\n기본 워크플로우는 1회 구매로 평생 소장되며, 이미 자체 워크플로우를 보유하신 고객님은 무인 자가치유(Module A)와 정합성 감시(Module B) 모듈만 단독 구매하여 기존 노드에 그대로 결합하실 수 있습니다.`
  },
  {
    id: 'KB-CHERRY-PICKING',
    patterns: [/체리피킹|수수료|악용.*방지/i],
    title: '체리피킹 방어 및 공정 환불 규정',
    answer: `🛡 [상생 환불 및 공정 정산 정책]\n━━━━━━━━━━━━━━━━━━\n초기 7일 이내에는 결함 발생 시 100% 전액 환불을 보장하며, 이후 중도 해지 시에는 실제 사용하신 일수만큼만 일할 계산하여 정산해 드리는 공정 정산 원칙을 준수합니다.`
  },
  {
    id: 'KB-DLQ-ISOLATION',
    patterns: [/dlq|격리|누락.*주문|보정.*대기열/i],
    title: 'DLQ(Dead Letter Queue) 안전 격리 보관',
    answer: `📦 [안전 임시 보관함 격리 시스템]\n━━━━━━━━━━━━━━━━━━\n워크플로우 노드 실행 중 이상 데이터나 분기 불일치가 발생하더라도 전체 파이프라인이 멈추지 않고, 해당 건만 [안전 임시 보관함]에 격리 보관되어 사내 PC 화면에서 1클릭으로 확인 및 보정하실 수 있습니다.`
  },
  {
    id: 'KB-PHONE-SANITATION',
    patterns: [/전화번호|핸드폰|하이픈|010/i],
    title: '전화번호 형식 자동 정규화 에어백',
    answer: `📱 [전화번호 자동 정규화 안내]\n━━━━━━━━━━━━━━━━━━\n고객이 입력한 전화번호의 하이픈 유무, 띄어쓰기, 특수문자, 국가번호(+82)를 자동으로 분석하여 표준 규격(010-XXXX-XXXX)으로 자동 정리합니다.`
  },
  {
    id: 'KB-STOCKOUT-DEFENSE',
    patterns: [/품절|재고|마이너스.*마진/i],
    title: '품절 및 마이너스 마진 주문 자동 방어',
    answer: `🛑 [품절 및 마이너스 마진 주문 방어]\n━━━━━━━━━━━━━━━━━━\n공급처 품절 상품이나 가격 오기로 인한 마이너스 마진 감지 시 즉각 처리를 보류하고 담당자에게 긴급 알림을 전송합니다.`
  },
  {
    id: 'KB-NETWORK-DROP',
    patterns: [/인터넷.*끊|네트워크.*순단|재접속/i],
    title: '네트워크 순단 시 데이터 보존 원리',
    answer: `🌐 [인터넷 순단 시 데이터 보존 원리]\n━━━━━━━━━━━━━━━━━━\n인터넷 연결이 일시적으로 끊겨도 사내 PC에 실행 데이터를 안전하게 임시 보관한 뒤, 네트워크가 복구되는 즉시 누락 없이 순서대로 처리를 완료합니다.`
  },
  {
    id: 'KB-FACTORY-RESET',
    patterns: [/공장.*초기화|초기.*상태|원복|factory.*reset/i],
    title: '1초 초기 출하 상태 원복(Factory Reset)',
    answer: `🔄 [초기 출하 상태 복원 안내]\n━━━━━━━━━━━━━━━━━━\n설정이 꼬였거나 노드가 삭제되었을 때, 동봉된 패키지의 원본 파일을 다시 적용하시면 언제든 1초 만에 처음 출하 상태로 깨끗하게 복원됩니다.`
  },
  {
    id: 'KB-ERP-SHEETS',
    patterns: [/구글.*시트|스프레드시트|erp.*연동|엑셀/i],
    title: '구글 스프레드시트 및 사내 ERP 연동',
    answer: `📊 [구글 시트 및 사내 ERP 노드 연동 안내]\n━━━━━━━━━━━━━━━━━━\n고객님의 워크플로우에 포함된 구글 시트, DB, 사내 ERP 노드를 그대로 인식하여 정합성 대사와 자가치유를 수행합니다.`
  },
  {
    id: 'KB-MULTI-STORE',
    patterns: [/다계정|사업자.*여러|멀티.*스토어/i],
    title: '복수 워크플로우 및 다중 노드 연동 안내',
    answer: `🏢 [복수 워크플로우 및 다중 노드 연동 안내]\n━━━━━━━━━━━━━━━━━━\n여러 채널이나 다중 분기 노드로 구성된 복합 워크플로우도 그대로 가져와 한 대의 PC에서 통합 자가치유 및 정합성 감시를 수행할 수 있습니다.`
  },
  {
    id: 'KB-GLOBAL-GUMROAD',
    patterns: [/해외|gumroad|검로드|글로벌|달러|usd/i],
    title: '검로드(Gumroad) 해외 구매 및 라이선스 키 연동',
    answer: `🌏 [검로드(Gumroad) 해외 결제 안내]\n━━━━━━━━━━━━━━━━━━\n해외 고객님은 검로드(달러 결제)를 통해 패키지를 즉시 다운로드받으실 수 있으며, 이메일로 받으신 라이선스 키를 셋업 위저드에 입력하시면 즉시 정품 인증됩니다.`
  },
  {
    id: 'KB-UPGRADE-PLAN',
    patterns: [/업그레이드|플랜.*변경|차액/i],
    title: '상위 플랜 업그레이드 및 차액 결제 안내',
    answer: `🚀 [상위 플랜 업그레이드 안내]\n━━━━━━━━━━━━━━━━━━\n셋업 위저드 상단의 [🚀 상위 플랜 업그레이드] 버튼을 클릭하시면 실시간 잔여일수 기준 기납부 공제액과 차액이 자동 계산되어 1초 만에 즉시 승급됩니다.`
  },
  {
    id: 'KB-CONTACT-HUMAN',
    patterns: [/상담원|사람.*연결|고객센터|대표.*문의|전화/i],
    title: '본사 엔지니어링 상담팀 연결 안내',
    answer: `👨‍💻 [본사 엔지니어링 1:1 상담 안내]\n━━━━━━━━━━━━━━━━━━\n• 이메일: contact@autoflow.io\n• 긴급 텔레그램: 대표님 관제 센터로 즉시 직보 호출됩니다.\n궁금하신 상세 내용을 메시지로 남겨주시면 담당 엔지니어가 신속히 확인하여 답변드리겠습니다.`
  }
];

class HqAutonomousCsBot {
  constructor(options = {}) {
    this.licenseManager = options.licenseManager || new LicenseManager();
    this.ollamaHost = options.ollamaHost || '127.0.0.1';
    this.ollamaPort = options.ollamaPort || 11434;
    this.primaryModel = options.primaryModel || 'autoflow-healer:gemma3';
    this.fallbackModel = options.fallbackModel || 'gemma3:4b';
  }

  /**
   * 대표님 텔레그램 안전 직보 헬퍼
   */
  async _notifyCeoSafe(category, title, detailsObj) {
    try {
      const sentinel = require('./hq_telegram_master_sentinel');
      if (typeof sentinel.sendCeoTelegramAlert === 'function') {
        await sentinel.sendCeoTelegramAlert(category, title, detailsObj);
      }
    } catch (_) {}
  }

  /**
   * 주문번호 또는 라이선스키 형태인지 고속 판정
   */
  detectOrderOrKeyPattern(text = '') {
    const trimmed = String(text || '').trim();

    // 1) 16자리 숫자 스마트스토어 주문번호 (예: 2026101812345678)
    if (/^\d{16}$/.test(trimmed)) {
      return { isOrder: true, type: 'SMARTSTORE_ORDER_ID', value: trimmed };
    }

    // 2) ORD- 접두사 주문번호
    if (/^ORD-[A-Za-z0-9_-]{6,40}$/i.test(trimmed)) {
      return { isOrder: true, type: 'INTERNAL_ORDER_ID', value: trimmed };
    }

    // 3) GUMROAD- 접두사
    if (/^GUMROAD-[A-Za-z0-9_-]{6,40}$/i.test(trimmed)) {
      return { isOrder: true, type: 'GUMROAD_ORDER_ID', value: trimmed };
    }

    // 4) 8-8-8-8 검로드 라이선스 키
    if (/^[A-Za-z0-9]{8}-[A-Za-z0-9]{8}-[A-Za-z0-9]{8}-[A-Za-z0-9]{8}$/.test(trimmed)) {
      return { isOrder: true, type: 'GUMROAD_LICENSE_KEY', value: trimmed };
    }

    // 5) AF-TKT-v1 서명 티켓 직접 입력
    if (trimmed.startsWith('AF-TKT-v1.')) {
      return { isOrder: true, type: 'SIGNED_MODULE_TICKET', value: trimmed };
    }

    // 6) 일반 주문번호 형태 (영문숫자하이픈 8~32자)
    const match = trimmed.match(/\b([A-Za-z0-9]{4,8}-[A-Za-z0-9]{4,8}-[A-Za-z0-9]{4,8})\b/);
    if (match) {
      return { isOrder: true, type: 'FORMATTED_ORDER_OR_KEY', value: match[1] };
    }

    return { isOrder: false };
  }

  /**
   * 1차 고속 정규식/결정론적 분류기 (환각 0%, 0.001초 지연)
   */
  matchKnowledgeBase(text = '') {
    const trimmed = String(text || '').trim();
    for (const entry of VERIFIED_KNOWLEDGE_BASE) {
      for (const pattern of entry.patterns) {
        if (pattern.test(trimmed)) {
          return entry;
        }
      }
    }
    return null;
  }

  /**
   * 에스컬레이션 트리거 여부 검사
   */
  isEscalationRequested(text = '') {
    const trimmed = String(text || '').trim();
    const escalationKeywords = [
      /환불.*(원해|해줘|요청|신청)/i,
      /사람.*(연결|바꿔|상담)/i,
      /상담원.*(연결|통화|채팅)/i,
      /해결.*(안.*됨|불가|안돼)/i,
      /화가.*나|신고|고소|사기/i,
      /대표.*(통화|연락|직접)/i
    ];
    return escalationKeywords.some(rx => rx.test(trimmed));
  }

  /**
   * 2차 자유 질문 로컬 AI 처리기 (로컬 Ollama 파인튜닝 모델 호출)
   */
  queryLocalOllama(prompt, timeoutMs = 4000) {
    return new Promise((resolve) => {
      const postData = JSON.stringify({
        model: this.primaryModel,
        prompt: `당신은 AutoFlow 무인 CS 엔지니어입니다. 한국어로 친절하고 정확하게 3문장 이내로 핵심만 답변하십시오.\n질문: ${prompt}\n답변:`,
        stream: false,
        options: {
          temperature: 0.2,
          top_p: 0.9,
          num_predict: 256
        }
      });

      const req = http.request({
        hostname: this.ollamaHost,
        port: this.ollamaPort,
        path: '/api/generate',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData)
        },
        timeout: timeoutMs
      }, (res) => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            if (parsed && parsed.response) {
              resolve({ success: true, answer: parsed.response.trim() });
            } else {
              resolve({ success: false, reason: 'EMPTY_RESPONSE' });
            }
          } catch (e) {
            resolve({ success: false, reason: 'PARSE_ERROR' });
          }
        });
      });

      req.on('error', (e) => resolve({ success: false, reason: e.message }));
      req.on('timeout', () => {
        req.destroy();
        resolve({ success: false, reason: 'TIMEOUT' });
      });

      req.write(postData);
      req.end();
    });
  }

  /**
   * 메시지 처리 메인 파이프라인
   */
  async processMessage(rawInput = {}) {
    const input = typeof rawInput === 'string' ? { message: rawInput } : (rawInput || {});
    const text = String(input.message || '').trim();
    const hwid = String(input.hwid || this.licenseManager._calculateLocalHwid()).trim();
    const customerEmail = String(input.customerEmail || input.email || '').trim();
    const channel = String(input.channel || 'SMARTSTORE').toUpperCase();

    if (!text) {
      return {
        success: false,
        reply: '안녕하세요! AutoFlow 무인 고객지원 봇입니다.\n주문번호(16자리)를 입력하시면 1초 만에 정품 티켓이 발급되며, 설치나 사용법에 대해 무엇이든 편하게 물어보세요.'
      };
    }

    // 1) 3차 에스컬레이션 우선 검사
    if (this.isEscalationRequested(text)) {
      await this._notifyCeoSafe(
        '🛑 [고객 환불/결함 검수 요청]',
        '🛑 [고객 상담 긴급 에스컬레이션]',
        {
          customerMessage: text,
          hwid: hwid.slice(0, 16) + '...',
          customerEmail: customerEmail || '미기재',
          channel
        }
      );
      return {
        success: true,
        escalated: true,
        reply: `🚨 [본사 전담 엔지니어 긴급 호출 완료]\n━━━━━━━━━━━━━━━━━━\n고객님의 요청사항("${text.slice(0, 50)}")이 대표님 및 엔지니어링 관제 센터로 직보되었습니다.\n\n• 담당 엔지니어가 신속히 확인하여 등록된 이메일 또는 연락처로 직접 연락드립니다.\n• 긴급 문의: contact@autoflow.io`
      };
    }

    // 2) 1차 고속 정규식 분류기: 주문번호 또는 라이선스 키 감지
    const orderDetection = this.detectOrderOrKeyPattern(text);
    if (orderDetection.isOrder) {
      const orderIdOrKey = orderDetection.value;
      const exchRes = this.licenseManager.exchangeExternalOrderForTicket({
        orderIdOrKey,
        channel,
        customerEmail,
        hwid,
        validDays: 30
      });

      if (exchRes.success && exchRes.ticket) {
        await this._notifyCeoSafe(
          '💰 [무인 결제·티켓 자동 발급]',
          '💰 [정품 티켓 무인 자동 발급 완료]',
          {
            orderIdOrKey,
            ticketId: exchRes.ticketId,
            channel: exchRes.channel || channel,
            hwid: hwid.slice(0, 16) + '...'
          }
        );

        return {
          success: true,
          isTicketIssued: true,
          ticket: exchRes.ticket,
          ticketId: exchRes.ticketId,
          expiresAt: exchRes.expiresAt,
          reply: `🎉 [정품 모듈 티켓 발급 완료]\n━━━━━━━━━━━━━━━━━━\n주문번호(${orderIdOrKey}) 확인이 완료되어 정품 티켓이 즉시 발급되었습니다.\n\n[정품 티켓 코드]:\n${exchRes.ticket}\n\n• 이용 기간: 등록 시점부터 ${exchRes.validDays || 30}일간 보장\n• 등록 방법: 브라우저 셋업 위저드(http://127.0.0.1:5678)에 위 코드를 복사해 입력하시면 즉시 가동됩니다.`
        };
      } else {
        await this._notifyCeoSafe(
          '⚠️ [비인가 접근 차단]',
          '⚠️ [미확인 주문 시도 차단]',
          {
            attemptedOrder: orderIdOrKey,
            error: exchRes.error,
            hwid: hwid.slice(0, 16) + '...'
          }
        );

        return {
          success: false,
          error: exchRes.error,
          reply: `⚠️ [주문번호 확인 불가]\n━━━━━━━━━━━━━━━━━━\n입력하신 번호(${orderIdOrKey})는 아직 결제가 확인되지 않았거나 이미 다른 PC에 등록된 번호입니다.\n\n• 스마트스토어/검로드 결제 완료 후 1~2분 뒤 다시 입력해 주세요.\n• 기기 이전이나 확인이 필요하시면 contact@autoflow.io 로 주문 내역과 함께 문의해 주세요.`
        };
      }
    }

    // 3) 1차 고속 정규식 분류기: 30종 단골 FAQ 매칭
    const matchedKb = this.matchKnowledgeBase(text);
    if (matchedKb) {
      return {
        success: true,
        source: 'VERIFIED_KNOWLEDGE_BASE',
        kbId: matchedKb.id,
        title: matchedKb.title,
        reply: matchedKb.answer
      };
    }

    // 4) 2차 자유 질문 로컬 AI 처리기 (Ollama autoflow-healer:gemma3 4초 가드)
    const aiRes = await this.queryLocalOllama(text, 4000);
    if (aiRes.success && aiRes.answer) {
      return {
        success: true,
        source: 'LOCAL_OLLAMA_AI',
        model: this.primaryModel,
        reply: `🤖 [AI 고객지원 엔지니어 답변]\n━━━━━━━━━━━━━━━━━━\n${aiRes.answer}\n\n※ 추가 문의나 정품 티켓 발급은 주문번호 16자리를 입력해 주세요.`
      };
    }

    // 5) AI 응답 실패/타임아웃 시 친절한 표준 FAQ 폴백
    return {
      success: true,
      source: 'STANDARD_FALLBACK',
      reply: `💡 [AutoFlow 안내 센터]\n━━━━━━━━━━━━━━━━━━\n궁금하신 내용을 입력하시거나 주문번호를 입력해 주세요:\n\n• 주문번호 16자리 입력: 0.1초 정품 티켓 자동 발급\n• 쿠팡 API: 윙 OpenAPI 발급 및 입력 방법\n• 알림톡: 솔라피 카카오톡 연동 방법\n• 설치: 윈도우/맥 더블클릭 실행 가이드\n• 환불: 7일 전액 환불 및 실사용 일할 차감 규정\n• 상담원 연결: 본사 엔지니어링 1:1 직통 호출`
    };
  }
}

module.exports = {
  HqAutonomousCsBot,
  VERIFIED_KNOWLEDGE_BASE
};
