/**
 * core/log_rotation_sentinel.js
 * 
 * AutoFlow 24시간 365일 무인 가동 디스크 고갈(ENOSPC) 방어 센티널
 * (Log Rotation & Disk Storage Sentinel)
 * 
 * 1. 로그 보관주기 7일(168시간) 자동 롤링: 기한 경과 파일 안전 삭제
 * 2. 디스크 점유 상한(50MB) 보장: 무인 가동 중 용량 누적으로 인한 C드라이브 고갈 및 DB 손상 원천 방어
 * 3. 핵심 설정 파일(config, license) 절대 보호 (화이트리스트 보존)
 */

const fs = require("fs");
const path = require("path");

class LogRotationSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.maxAgeDays = options.maxAgeDays || 7;
    this.maxTotalSizeBytes = options.maxTotalSizeBytes || (50 * 1024 * 1024); // 기본 50MB 상한
    this.maxSingleFileSizeBytes = options.maxSingleFileSizeBytes || (10 * 1024 * 1024); // 10MB 초과 시 대형 파일 롤링
    this.protectedFiles = new Set([
      "notification_settings.json",
      "config.json",
      "license_state.json",
      "checkpoint.json",
      "embedded_workflow.json",
      "active_port.txt",
      "active_sidecar_port.txt",
      "engine.pid",
      "license_bindings.json",
      "license_transfer_tokens.json",
      "customer_config.json",
      "client_pass_records.json",
      "tunnel_url.txt"
    ]);
  }

  /**
   * 지정된 디렉토리 내의 파일 목록 재귀 탐색
   * @param {string} dir 탐색 디렉토리
   * @returns {Array<{path: string, size: number, mtime: Date}>}
   */
  collectLogFiles(dir) {
    const results = [];
    if (typeof dir !== "string" || !dir) dir = this.logDir;
    if (typeof dir !== "string" || !dir || !fs.existsSync(dir)) return results;

    const list = fs.readdirSync(dir);
    for (const item of list) {
      const fullPath = path.join(dir, item);
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          results.push(...this.collectLogFiles(fullPath));
        } else if (stat.isFile()) {
          const base = path.basename(fullPath);
          if (!this.protectedFiles.has(base)) {
            results.push({
              path: fullPath,
              size: stat.size,
              mtime: stat.mtime
            });
          }
        }
      } catch (e) {
        console.warn("[AutoFlow Safety] Failed to inspect log file stat:", e.message);
      }
    }
    return results;
  }

  /**
   * 디스크 로그 사용량 집계
   * @param {string} baseLogDir 로그 루트 디렉토리
   * @returns {{ totalFiles: number, totalSizeBytes: number, formattedSize: string }}
   */
  getStorageUsage(baseLogDir) {
    const files = this.collectLogFiles(baseLogDir);
    const totalBytes = files.reduce((acc, f) => acc + f.size, 0);
    return {
      totalFiles: files.length,
      totalSizeBytes: totalBytes,
      formattedSize: this.formatBytes(totalBytes)
    };
  }

  /**
   * 10MB 초과 대형 로그 롤링, 7일 경과 만료 삭제, 50MB 상한 FIFO 정리
   * @param {string} baseLogDir 로그 루트 디렉토리
   * @returns {{ deletedCount: number, freedBytes: number, remainingBytes: number, rolledCount: number }}
   */
  rotateLogs(baseLogDir) {
    if (typeof baseLogDir !== "string" || !baseLogDir || !fs.existsSync(baseLogDir)) {
      return { deletedCount: 0, freedBytes: 0, remainingBytes: 0, rolledCount: 0 };
    }

    const files = this.collectLogFiles(baseLogDir);
    const now = Date.now();
    const maxAgeMs = this.maxAgeDays * 24 * 60 * 60 * 1000;

    let deletedCount = 0;
    let freedBytes = 0;
    let rolledCount = 0;
    const remainingFiles = [];

    // 1단계: 10MB 초과 대형 로그 파일 백업/롤링 (.1 로 백업 및 원본 리셋)
    for (const f of files) {
      if (f.size > this.maxSingleFileSizeBytes && !f.path.endsWith(".1") && !f.path.endsWith(".bak")) {
        try {
          const backupPath = `${f.path}.1`;
          if (fs.existsSync(backupPath)) {
            try {
              const oldStat = fs.statSync(backupPath);
              freedBytes += oldStat.size;
              deletedCount++;
              fs.unlinkSync(backupPath);
            } catch (e) {
              console.warn("[AutoFlow Safety] Failed to unlink old backup log:", e.message);
            }
          }
          fs.renameSync(f.path, backupPath);
          fs.writeFileSync(f.path, "", "utf8");
          rolledCount++;
          remainingFiles.push({
            path: backupPath,
            size: f.size,
            mtime: new Date()
          });
          remainingFiles.push({
            path: f.path,
            size: 0,
            mtime: new Date()
          });
        } catch (e) {
          console.warn("[AutoFlow Safety] Failed to roll large log file:", e.message);
          remainingFiles.push(f);
        }
      } else {
        remainingFiles.push(f);
      }
    }

    // 2단계: 7일 초과 파일 삭제
    const activeFiles = [];
    for (const f of remainingFiles) {
      const ageMs = now - f.mtime.getTime();
      if (ageMs > maxAgeMs) {
        try {
          fs.unlinkSync(f.path);
          deletedCount++;
          freedBytes += f.size;
        } catch (e) {
          console.warn("[AutoFlow Safety] Failed to delete expired log file:", e.message);
          activeFiles.push(f);
        }
      } else {
        activeFiles.push(f);
      }
    }

    // 3단계: 50MB 용량 상한 초과 시 오래된 순으로 긴급 방출 (FIFO)
    let currentTotalBytes = activeFiles.reduce((acc, f) => acc + f.size, 0);
    if (currentTotalBytes > this.maxTotalSizeBytes) {
      activeFiles.sort((a, b) => a.mtime.getTime() - b.mtime.getTime());
      while (currentTotalBytes > this.maxTotalSizeBytes && activeFiles.length > 0) {
        const oldest = activeFiles.shift();
        try {
          fs.unlinkSync(oldest.path);
          deletedCount++;
          freedBytes += oldest.size;
          currentTotalBytes -= oldest.size;
        } catch (e) {
          console.warn("[AutoFlow Safety] Failed to FIFO purge oldest log file:", e.message);
        }
      }
    }

    return {
      deletedCount,
      freedBytes,
      remainingBytes: Math.max(0, currentTotalBytes),
      rolledCount
    };
  }

  /**
   * 6시간 주기 자동 로그 롤링 스케줄러 가동
   * @param {string} baseLogDir 로그 루트 디렉토리
   * @param {number} intervalMs 실행 주기 (기본 6시간 = 21,600,000ms)
   */
  startRotationScheduler(baseLogDir, intervalMs = 21600000) {
    if (this._timer) return;
    const safeInterval = (typeof intervalMs === "number" && Number.isFinite(intervalMs) && intervalMs > 0) ? intervalMs : 21600000;
    this._timer = setInterval(() => {
      try {
        const res = this.rotateLogs(baseLogDir);
        if (res.deletedCount > 0 || res.rolledCount > 0) {
          console.log(`[AutoFlow Storage] Scheduled log rotation freed ${this.formatBytes(res.freedBytes)} (${res.deletedCount} files purged, ${res.rolledCount} rolled).`);
        }
      } catch (e) {
        console.warn("[AutoFlow Safety] Periodic log rotation error:", e.message);
      }
    }, safeInterval);
    if (this._timer && typeof this._timer.unref === "function") {
      this._timer.unref();
    }
  }

  formatBytes(bytes) {
    const num = Number(bytes);
    if (!Number.isFinite(num) || num <= 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.min(sizes.length - 1, Math.floor(Math.log(num) / Math.log(k)));
    return parseFloat((num / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  }
}

const defaultLogSentinel = new LogRotationSentinel({
  maxAgeDays: 7,
  maxTotalSizeBytes: 50 * 1024 * 1024,
  maxSingleFileSizeBytes: 10 * 1024 * 1024
});

module.exports = {
  LogRotationSentinel,
  logRotationSentinel: defaultLogSentinel
};
