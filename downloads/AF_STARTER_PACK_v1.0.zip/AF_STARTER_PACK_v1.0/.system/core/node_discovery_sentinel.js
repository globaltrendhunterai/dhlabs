/**
 * core/node_discovery_sentinel.js
 * 
 * AutoFlow Node Discovery & Port Collision Sidecar Sentinel (Pure Node.js)
 * 
 * [목적]
 * 1. 로컬 머신의 기존 구동 중인 n8n / 자동화 노드 인스턴스 자동 탐색 (5678 포트 Auto-Discovery Ping).
 * 2. 포트 충돌(EADDRINUSE) 방지를 위해 기존 n8n 감지 시 AutoFlow 데몬을 5679~5688 포트로 격리 및 사이드카 모드로 자동 안전 기동.
 * 3. 기존 n8n과 무결성 연동을 위한 사이드카 브릿지 설정(generateSidecarBridgeConfig) 및 1-클릭 노드 임포트 JSON 제공.
 * 4. 영속 탐색 감사 원장(logs/node_discovery_audits.json) 및 상태 진단 API 완비.
 */

const net = require("net");
const http = require("http");
const fs = require("fs");
const path = require("path");

class NodeDiscoverySentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.appRoot = (typeof options.appRoot === "string" && options.appRoot.trim()) ? options.appRoot.trim() : path.resolve(__dirname, "..");
    this.auditFilePath = (typeof options.auditFilePath === "string" && options.auditFilePath.trim())
      ? options.auditFilePath.trim()
      : path.join(this.appRoot, "logs", "node_discovery_audits.json");
    this.maxAudits = (typeof options.maxAudits === "number" && Number.isFinite(options.maxAudits) && options.maxAudits > 0)
      ? options.maxAudits
      : 100;
    this.lastDiscovery = null;
  }

  /**
   * 지정 포트가 점유(Listening) 상태인지 확인
   * @param {number} port
   * @param {string} host
   * @param {number} timeoutMs
   * @returns {Promise<boolean>} 점유 중이면 true, 비어있으면 false
   */
  async checkPort(port, host = "127.0.0.1", timeoutMs = 400) {
    if (port && typeof port === "object") {
      host = port.host || host;
      timeoutMs = port.timeoutMs || timeoutMs;
      port = port.port;
    }
    const numPort = Number(port);
    if (!Number.isInteger(numPort) || numPort < 1 || numPort > 65535) {
      return false;
    }
    const safeHost = (typeof host === "string" && host.trim()) ? host.trim() : "127.0.0.1";
    const safeTimeout = (typeof timeoutMs === "number" && Number.isFinite(timeoutMs) && timeoutMs > 0) ? timeoutMs : 400;

    return new Promise((resolve) => {
      const socket = new net.Socket();
      let status = false;

      socket.setTimeout(safeTimeout);

      socket.once("connect", () => {
        status = true;
        socket.destroy();
        resolve(true);
      });

      socket.once("timeout", () => {
        socket.destroy();
        resolve(false);
      });

      socket.once("error", (err) => {
        socket.destroy();
        resolve(false);
      });

      socket.connect(numPort, safeHost);
    });
  }

  /**
   * startPort부터 endPort까지 탐색하여 사용 가능한 첫 번째 포트 반환
   * @param {number} startPort
   * @param {number} endPort
   * @param {string} host
   * @returns {Promise<number>}
   */
  async findAvailablePort(startPort = 5679, endPort = 5688, host = "127.0.0.1") {
    if (startPort && typeof startPort === "object") {
      endPort = startPort.endPort !== undefined ? startPort.endPort : endPort;
      host = startPort.host || host;
      startPort = startPort.startPort;
    }
    const safeStart = (typeof startPort === "number" && Number.isInteger(startPort) && startPort >= 1 && startPort <= 65535)
      ? startPort
      : 5679;
    const safeEnd = (typeof endPort === "number" && Number.isInteger(endPort) && endPort >= safeStart && endPort <= 65535)
      ? endPort
      : Math.min(65535, safeStart + 9);
    const safeHost = (typeof host === "string" && host.trim()) ? host.trim() : "127.0.0.1";

    for (let p = safeStart; p <= safeEnd; p++) {
      const isOccupied = await this.checkPort(p, safeHost, 250);
      if (!isOccupied) {
        return p;
      }
    }
    // 기본 안전 폴백: 마지막 포트 + 1
    return safeEnd + 1;
  }

  /**
   * 로컬 5678 포트 및 기존 n8n 노드 인스턴스 자동 탐색
   * @param {object} options
   * @returns {Promise<object>} 탐색 결과 객체
   */
  async discoverLocalNode(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    const targetPort = (typeof options.targetPort === "number" && Number.isInteger(options.targetPort) && options.targetPort >= 1)
      ? options.targetPort
      : 5678;
    const host = (typeof options.host === "string" && options.host.trim()) ? options.host.trim() : "127.0.0.1";
    const fallbackStart = (typeof options.fallbackStart === "number" && Number.isInteger(options.fallbackStart) && options.fallbackStart >= 1)
      ? options.fallbackStart
      : 5679;
    const fallbackEnd = (typeof options.fallbackEnd === "number" && Number.isInteger(options.fallbackEnd) && options.fallbackEnd >= fallbackStart)
      ? options.fallbackEnd
      : 5688;

    const isOccupied = await this.checkPort(targetPort, host, 500);

    let discoveryResult = null;

    if (!isOccupied) {
      discoveryResult = {
        status: "INSTANCE_STANDALONE_NEW",
        isOccupied: false,
        targetPort: targetPort,
        recommendedPort: targetPort,
        sidecarMode: false,
        message: `기존 자동화 노드가 발견되지 않았습니다. 기본 포트 ${targetPort}에서 AutoFlow 독립형 엔진으로 기동합니다.`,
        detectedService: "none",
        timestamp: new Date().toISOString()
      };
    } else {
      const sidecarPort = await this.findAvailablePort(fallbackStart, fallbackEnd, host);
      discoveryResult = {
        status: "INSTANCE_DETECTED_EXISTING",
        isOccupied: true,
        targetPort: targetPort,
        recommendedPort: sidecarPort,
        sidecarMode: true,
        message: `기존 n8n/노드 인스턴스(포트 ${targetPort})가 감지되었습니다. 포트 충돌 방지를 위해 AutoFlow 데몬이 포트 ${sidecarPort}에서 사이드카 모드로 안전 격리 기동됩니다.`,
        detectedService: "n8n_or_compatible_automation_engine",
        bridgeConfig: this.generateSidecarBridgeConfig({ mainPort: targetPort, sidecarPort: sidecarPort }),
        timestamp: new Date().toISOString()
      };
    }

    this.lastDiscovery = discoveryResult;
    this.auditDiscovery(discoveryResult);
    return discoveryResult;
  }

  /**
   * 기존 n8n 인스턴스와 AutoFlow 사이드카 엔진 연동 설정 및 노드 임포트 JSON 생성
   * @param {object} options
   * @returns {object}
   */
  generateSidecarBridgeConfig(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    const {
      mainPort = 5678,
      sidecarPort = 5679,
      webhookPath = "/webhook/autoflow-bridge",
      apiKey = ""
    } = options;
    const sidecarBaseUrl = `http://127.0.0.1:${sidecarPort}`;
    const webhookUrl = `${sidecarBaseUrl}${webhookPath}`;

    const sampleWorkflow = {
      name: "AutoFlow Sidecar Bridge Connector",
      nodes: [
        {
          parameters: {
            httpMethod: "POST",
            path: "autoflow-bridge",
            responseMode: "lastNode",
            options: {}
          },
          name: "AutoFlow Bridge Ingress",
          type: "n8n-nodes-base.webhook",
          typeVersion: 1,
          position: [240, 300]
        },
        {
          parameters: {
            requestMethod: "GET",
            url: `${sidecarBaseUrl}/api/system/node-discovery-status`,
            options: {}
          },
          name: "Query AutoFlow Engine Status",
          type: "n8n-nodes-base.httpRequest",
          typeVersion: 3,
          position: [480, 300]
        }
      ],
      connections: {
        "AutoFlow Bridge Ingress": {
          main: [
            [
              {
                node: "Query AutoFlow Engine Status",
                type: "main",
                index: 0
              }
            ]
          ]
        }
      }
    };

    return {
      sidecarMode: true,
      existingN8nUrl: `http://127.0.0.1:${mainPort}`,
      sidecarDaemonUrl: sidecarBaseUrl,
      webhookEndpoint: webhookUrl,
      healthCheckUrl: `${sidecarBaseUrl}/healthz`,
      integrationType: "SIDECAR_HTTP_BRIDGE",
      sampleWorkflow: sampleWorkflow,
      oneClickImportJson: JSON.stringify(sampleWorkflow, null, 2),
      instructions: [
        "1. 기존 n8n (http://127.0.0.1:5678) 관리자 화면에 접속합니다.",
        "2. 우측 상단 'Import from File / Clipboard'를 클릭하고 아래 1-클릭 워크플로우 JSON을 붙여넣습니다.",
        "3. HTTP Request 노드의 타깃 주소가 AutoFlow 사이드카 데몬(5679)으로 자동 결선되어 즉시 상호 연동됩니다."
      ].join("\n")
    };
  }

  /**
   * 탐색 이력을 영속 감사 원장 파일(logs/node_discovery_audits.json)에 기록
   * @param {object} record
   */
  auditDiscovery(record) {
    if (!record || typeof record !== "object" || Array.isArray(record) || Object.keys(record).length === 0) {
      return;
    }
    try {
      const dir = path.dirname(this.auditFilePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      let audits = [];
      if (fs.existsSync(this.auditFilePath)) {
        try {
          const content = fs.readFileSync(this.auditFilePath, "utf8");
          audits = JSON.parse(content || "[]");
          if (!Array.isArray(audits)) audits = [];
        } catch (e) {
          audits = [];
        }
      }

      audits.unshift({
        id: `DISC-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        ...record
      });

      if (audits.length > this.maxAudits) {
        audits = audits.slice(0, this.maxAudits);
      }

      fs.writeFileSync(this.auditFilePath, JSON.stringify(audits, null, 2), "utf8");
    } catch (err) {
      console.error("[NodeDiscoverySentinel] Failed to write audit record:", err.message);
    }
  }

  /**
   * 감사 원장 전체 또는 최근 N건 조회
   * @param {number} limit
   * @returns {Array}
   */
  getAuditHistory(limit = 20) {
    const safeLimit = (typeof limit === "number" && Number.isFinite(limit) && limit > 0) ? Math.floor(limit) : 20;
    try {
      if (fs.existsSync(this.auditFilePath)) {
        const content = fs.readFileSync(this.auditFilePath, "utf8");
        const list = JSON.parse(content || "[]");
        if (Array.isArray(list)) {
          return list.slice(0, safeLimit);
        }
      }
    } catch (e) {
      // non-fatal
    }
    return [];
  }

  /**
   * 현재 상태 및 진단 데이터 반환
   * @returns {object}
   */
  getStatus() {
    const audits = this.getAuditHistory(5);
    const totalCount = audits.length;
    const detectedExistingCount = audits.filter(a => a && a.status === "INSTANCE_DETECTED_EXISTING").length;

    return {
      status: "SUCCESS",
      lastDiscovery: this.lastDiscovery,
      currentMode: this.lastDiscovery ? this.lastDiscovery.status : "INITIALIZING",
      sidecarActive: this.lastDiscovery ? this.lastDiscovery.sidecarMode : false,
      historySummary: {
        totalRecorded: totalCount,
        detectedExistingCount: detectedExistingCount,
        recentAudits: audits
      },
      auditFilePath: this.auditFilePath
    };
  }

  /**
   * 테스트 및 상태 초기화용
   */
  resetState() {
    this.lastDiscovery = null;
  }
}

const defaultNodeDiscoverySentinel = new NodeDiscoverySentinel();

module.exports = {
  NodeDiscoverySentinel,
  nodeDiscoverySentinel: defaultNodeDiscoverySentinel
};
