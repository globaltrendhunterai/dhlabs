/**
 * AutoFlow Engine - Coupang Stockout & Inventory Depletion Airbag Sentinel
 *
 * [역할 및 법무/비즈니스 배경]
 * 1. 위탁/사입 판매자는 공급처의 실시간 재고 품절(옵션 단종, 일시품절, 거래처 휴가 등)을
 *    사전에 인지하지 못하고 쿠팡 WING 주문을 접수했다가 뒤늦게 취소하여
 *    "판매자 귀책 취소" 패널티(판매자 점수 대폭 삭감, 아이템위너 박탈, 벌점)를 받는 치명적 손실이 발생합니다.
 * 2. 「전자상거래 등에서의 소비자보호에 관한 법률」 제15조(재화등의 공급) 제2항에 따라
 *    "통신판매업자는 청약을 받은 재화등을 공급하기 곤란하다는 것을 알았을 때에는
 *    지체 없이 그 사유를 소비자에게 알려야 하고, 대금을 받은 날부터 3영업일 이내에 환급 조치"를 취해야 합니다.
 *    이를 지연하면 법정 지연배상금(연 15%) 및 공정거래위원회 시정명령 대상이 됩니다.
 * 3. 본 Sentinel은 주문 데이터의 상품명, 옵션명, SKU를 1초 만에 감별하여
 *    품절 의심 주문을 즉시 STOCKOUT_HOLD 상태로 전환하고 출고를 일시 보류하며,
 *    셀러에게 긴급 경보를 발송하고 전자상거래법 제15조 제2항에 부합하는
 *    공식 고객 안내 및 환불 통지 문구를 원클릭으로 자동 생성합니다.
 *
 * [공문서 및 알림 표준]
 * - Pure White Clean Enterprise 라이트 모드 준수
 * - 붉은 직인 0건 및 (인쇄 시 직인 생략) 공문서 표준 보존
 * - 텔레그램/슬랙 [⚠️ 품절 의심 긴급 출고 홀드] 경보 생성
 * - 감사 로그: logs/stockout_hold_orders.json 영속화
 */

const fs = require("fs");
const path = require("path");

class StockoutHoldSentinel {
  constructor(options = {}) {
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/stockout_hold_orders.json");
    this.keywordsPath = options.keywordsPath || path.resolve(process.cwd(), "config/stockout_keywords.json");

    // 기본 품절 감지 키워드 목록
    this.defaultKeywords = [
      "품절", "단종", "일시품절", "재고소진", "공급중단",
      "재고없음", "재고0", "입고대기", "생산중단", "SOLD OUT", "OUT OF STOCK"
    ];

    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const storageDir = path.dirname(this.storagePath);
      if (!fs.existsSync(storageDir)) {
        fs.mkdirSync(storageDir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(this.storagePath, JSON.stringify({ orders: [], lastUpdated: new Date().toISOString() }, null, 2), "utf8");
      }

      const configDir = path.dirname(this.keywordsPath);
      if (!fs.existsSync(configDir)) {
        fs.mkdirSync(configDir, { recursive: true });
      }
      if (!fs.existsSync(this.keywordsPath)) {
        fs.writeFileSync(this.keywordsPath, JSON.stringify({ keywords: this.defaultKeywords, lastUpdated: new Date().toISOString() }, null, 2), "utf8");
      }
    } catch (e) {
      // safe fallback
    }
  }

  /**
   * 등록된 품절 키워드 목록 조회
   */
  getKeywords() {
    try {
      this._ensureStorage();
      if (fs.existsSync(this.keywordsPath)) {
        const raw = fs.readFileSync(this.keywordsPath, "utf8");
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.keywords)) {
          return parsed.keywords;
        }
      }
    } catch (e) {}
    return this.defaultKeywords;
  }

  /**
   * 품절 키워드 목록 갱신
   */
  updateKeywords(keywords) {
    try {
      this._ensureStorage();
      if (!Array.isArray(keywords)) return false;
      const clean = keywords.map(k => String(k).trim()).filter(k => k.length > 0);
      fs.writeFileSync(this.keywordsPath, JSON.stringify({ keywords: clean, lastUpdated: new Date().toISOString() }, null, 2), "utf8");
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * 주문 상품명/옵션명 기반 품절 의심 여부 1초 감별
   * @param {Object} order - { orderId, productName, optionName, vendorItemId }
   * @returns {Object} { isStockoutSuspected, matchedKeyword, targetField, status }
   */
  detectStockout(order) {
    if (!order) {
      return { isStockoutSuspected: false, reason: "ORDER_EMPTY" };
    }

    const keywords = this.getKeywords();
    const productName = String(order.productName || "");
    const optionName = String(order.optionName || "");
    const note = String(order.note || "");

    const searchTarget = `${productName} ${optionName} ${note}`.toUpperCase();

    for (const kw of keywords) {
      const upperKw = kw.toUpperCase();
      if (searchTarget.includes(upperKw)) {
        let field = "기본정보";
        if (optionName.toUpperCase().includes(upperKw)) field = "옵션명";
        else if (productName.toUpperCase().includes(upperKw)) field = "상품명";
        else if (note.toUpperCase().includes(upperKw)) field = "배송메모";

        return {
          isStockoutSuspected: true,
          status: "STOCKOUT_HOLD",
          matchedKeyword: kw,
          targetField: field,
          orderId: order.orderId || `ORD-${Date.now()}`,
          productName: order.productName || "상품",
          optionName: order.optionName || "",
          detectedAt: new Date().toISOString()
        };
      }
    }

    return {
      isStockoutSuspected: false,
      status: "NORMAL",
      orderId: order.orderId,
      detectedAt: new Date().toISOString()
    };
  }

  /**
   * 텔레그램/슬랙 긴급 출고 보류 경보 블록 생성
   */
  formatStockoutAlert(order, detection) {
    if (!detection || !detection.isStockoutSuspected) return "";

    return [
      `----------------------------------------`,
      `⚠️ [쿠팡 재고 보호] 품절 의심 긴급 출고 보류 안내`,
      `* 주문번호: ${detection.orderId}`,
      `* 상품명: ${detection.productName}`,
      `* 감지옵션: ${detection.optionName || "기본단품"}`,
      `* 매칭키워드: [${detection.matchedKeyword}] (${detection.targetField})`,
      `* 상태: 🛑 출고 보류 (공급처 재고 실물 확인 필수)`,
      `* 법무권고: 공급 불가 시 「전자상거래법」 제15조 제2항에 따라 지체 없이 소비자에게 알리고 3영업일 이내 환불 조치해야 합니다.`,
      `----------------------------------------`
    ].join("\n");
  }

  /**
   * 「전자상거래법」 제15조 제2항 준수 공식 구매자 품절 안내 및 환불 문자 템플릿 생성
   */
  generateCustomerNotice(order, detection) {
    const orderId = (order && order.orderId) || (detection && detection.orderId) || "주문번호";
    const prodName = (order && order.productName) || (detection && detection.productName) || "주문상품";
    const optName = (order && order.optionName) || (detection && detection.optionName) || "";

    return [
      `[AutoFlow 안내] 주문 상품 일시 품절 및 배송 지연 안내`,
      ``,
      `안녕하세요, 고객님. 주문해주신 상품에 대해 안내드립니다.`,
      `고객님께서 주문하신 [${prodName}${optName ? " - " + optName : ""}] 상품이 거래처 주문 폭주로 인해 부득이하게 일시 품절(재고 소진)되었습니다.`,
      ``,
      `* 주문번호: ${orderId}`,
      `* 관련법령: 「전자상거래 등에서의 소비자보호에 관한 법률」 제15조 제2항 준용`,
      `* 조치사항: 재고 재입고 여부를 확인 중에 있으며, 공급이 어려울 경우 결제하신 대금은 지체 없이 3영업일 이내에 즉시 전액 결제 취소(환불) 처리됩니다.`,
      ``,
      `소중한 주문에 불편을 드려 진심으로 사과드리며, 빠른 취소나 변경을 원하실 경우 고객센터로 회신 주시면 1초 만에 즉시 처리 도와드리겠습니다. 감사합니다.`
    ].join("\n");
  }

  /**
   * 품절 의심 주문 큐 기록
   */
  recordHoldOrder(detection) {
    try {
      this._ensureStorage();
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const data = JSON.parse(raw);
      const orders = data.orders || [];

      const filtered = orders.filter(o => o.orderId !== detection.orderId);
      filtered.unshift({
        orderId: detection.orderId,
        productName: detection.productName,
        optionName: detection.optionName,
        matchedKeyword: detection.matchedKeyword,
        status: detection.status,
        detectedAt: detection.detectedAt || new Date().toISOString()
      });

      const trimmed = filtered.slice(0, 100);
      fs.writeFileSync(this.storagePath, JSON.stringify({ orders: trimmed, lastUpdated: new Date().toISOString() }, null, 2), "utf8");
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * 품절 홀드 해제 (실물 재고 확인 완료 또는 취소 완료)
   */
  resolveHoldOrder(orderId, resolution = "RESOLVED") {
    try {
      this._ensureStorage();
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const data = JSON.parse(raw);
      const orders = data.orders || [];

      const target = orders.find(o => o.orderId === orderId);
      if (target) {
        target.status = resolution;
        target.resolvedAt = new Date().toISOString();
        fs.writeFileSync(this.storagePath, JSON.stringify({ orders, lastUpdated: new Date().toISOString() }, null, 2), "utf8");
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  /**
   * 품절 홀드 대기 큐 요약 조회
   */
  getHoldOrdersSummary() {
    try {
      this._ensureStorage();
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const data = JSON.parse(raw);
      const orders = data.orders || [];

      const holdingOrders = orders.filter(o => o.status === "STOCKOUT_HOLD");
      const resolvedOrders = orders.filter(o => o.status !== "STOCKOUT_HOLD");

      return {
        success: true,
        holdingCount: holdingOrders.length,
        resolvedCount: resolvedOrders.length,
        totalCount: orders.length,
        holdingOrders,
        lastUpdated: data.lastUpdated
      };
    } catch (e) {
      return {
        success: false,
        holdingCount: 0,
        resolvedCount: 0,
        totalCount: 0,
        holdingOrders: [],
        error: e.message
      };
    }
  }
}

const defaultStockoutHoldSentinel = new StockoutHoldSentinel();

module.exports = {
  StockoutHoldSentinel,
  stockoutHoldSentinel: defaultStockoutHoldSentinel
};
