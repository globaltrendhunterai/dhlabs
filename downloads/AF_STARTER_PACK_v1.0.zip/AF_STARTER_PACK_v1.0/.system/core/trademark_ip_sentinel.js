/**
 * AutoFlow Trademark & Intellectual Property Defense Sentinel
 * (Gate 46: GATE_LEGAL_13)
 * (core/trademark_ip_sentinel.js)
 * 
 * [법률 및 지식재산권 컴플라이언스]
 * 1. 「상표법」 제90조(상표권의 효력이 미치지 아니하는 범위) 제1항 제2호:
 *    - 자기의 성명이나 상호, 또는 상품의 산지, 품질, 원재료, 효능, 용도(호환품·전용품 표기),
 *      수량, 형상 등을 보통으로 사용하는 방법으로 표시하는 상표에 대해서는 상표권의 효력이 미치지 아니함.
 *    - 대법원 판례(대법원 2002도3445 판결 등): 소비자로 하여금 타인의 상품과 혼동을 초래하지 않고,
 *      자신의 상품이 타인의 정품에 부속·호환되는 물품임을 설명하기 위해 보통의 글씨체로 표시하는 것은
 *      상표적 사용(출처 표시 기능)에 해당하지 않아 상표권 침해를 구성하지 않음.
 * 2. 「상표법」 제108조(침해로 보는 행위) 및 제230조(벌칙: 7년 이하의 징역 또는 1억 원 이하의 벌금):
 *    - 타인의 등록상표와 동일 또는 유사한 상표를 그 지정상품과 동일·유사한 상품에 사용하는 행위 원천 차단.
 * 3. 「부정경쟁방지 및 영업비밀보호에 관한 법률」 제2조 제1호 (가)목 및 (나)목:
 *    - 국내에 널리 인식된 타인의 상표·상호 등을 사용하여 타인의 상품 또는 영업과 혼동을 일으키게 하거나,
 *      그 식별력이나 명성을 손상하는 행위(~스타일, ~st 등 모조품·사칭 키워드) 사전 감별.
 * 4. 4대 판정 엔진 (auditTrademarkRisk):
 *    - IP_CLEAN: 침해 의심 키워드 없음 (안전 출고/등록 가능, 방어액 0원)
 *    - IP_COMPATIBLE_CAUTION: 호환/전용 표기 주의 (소비자 오인 방지 권고문 자동 생성, 방어액 0원)
 *    - IP_RISK_STYLE_INFRINGEMENT: "~스타일", "~st" 모조품/카피캣 사칭 키워드 적발 (즉시 삭제 권고, 합의금 300만 원 방어)
 *    - IP_CRITICAL_DIRECT_INFRINGE: 등록상표 무단 도용 및 가품 의심 (형사고소 및 계정 정지 위험, 즉시 판매중단 권고, 500만 원 방어)
 * 5. Pure White Clean Enterprise 라이트 모드 공식 비침해 소명서 및 내용증명 답변서 HTML 발급기:
 *    - 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건, 다크모드 영구 금지).
 * 6. 영속 원장(`logs/trademark_ip_audits.json`), 통계 집계(`getSummary()`), 이슈 종결(`resolveIpIssue()`).
 */

"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

/**
 * 100여 개 글로벌/국내 주요 등록상표 브랜드 데이터베이스
 */
const TRADEMARK_BRAND_DATABASE = [
  // --- 테크/가전 (IT & Electronics) ---
  { id: "APPLE", nameKo: "애플", nameEn: "Apple", aliases: ["아이폰", "에어팟", "아이패드", "맥북", "애플워치", "iphone", "ipad", "macbook", "airpods"], category: "가전/IT" },
  { id: "SAMSUNG", nameKo: "삼성", nameEn: "Samsung", aliases: ["갤럭시", "갤럭시노트", "갤럭시탭", "갤럭시워치", "galaxy", "비스포크", "bespoke"], category: "가전/IT" },
  { id: "LG", nameKo: "LG", nameEn: "LG", aliases: ["엘지", "그램", "트롬", "오브제", "tromm", "gram"], category: "가전/IT" },
  { id: "SONY", nameKo: "소니", nameEn: "Sony", aliases: ["플레이스테이션", "플스", "playstation", "ps5", "ps4", "엑스페리아"], category: "가전/IT" },
  { id: "DYSON", nameKo: "다이슨", nameEn: "Dyson", aliases: ["에어랩", "슈퍼소닉", "v12", "v15", "v8", "v10", "airwrap", "supersonic"], category: "가전/IT" },
  { id: "NINTENDO", nameKo: "닌텐도", nameEn: "Nintendo", aliases: ["닌텐도스위치", "스위치", "포켓몬", "마리오", "zelda"], category: "가전/IT" },
  { id: "LOGITECH", nameKo: "로지텍", nameEn: "Logitech", aliases: ["로지", "마스터3", "gpro", "g502", "mxkeys"], category: "가전/IT" },
  { id: "RAZER", nameKo: "레이저", nameEn: "Razer", aliases: ["블랙위도우", "데스에더", "바이퍼"], category: "가전/IT" },
  { id: "MICROSOFT", nameKo: "마이크로소프트", nameEn: "Microsoft", aliases: ["서피스", "엑스박스", "xbox", "surface"], category: "가전/IT" },
  { id: "INTEL", nameKo: "인텔", nameEn: "Intel", aliases: ["코어i7", "코어i5", "코어i9", "core i7", "core i5"], category: "가전/IT" },
  { id: "AMD", nameKo: "AMD", nameEn: "AMD", aliases: ["라이젠", "라데온", "ryzen", "radeon"], category: "가전/IT" },
  { id: "NVIDIA", nameKo: "엔비디아", nameEn: "Nvidia", aliases: ["지포스", "geforce", "rtx", "gtx"], category: "가전/IT" },
  { id: "ASUS", nameKo: "에이수스", nameEn: "ASUS", aliases: ["아수스", "로그", "rog", "젠북", "터프"], category: "가전/IT" },
  { id: "LENOVO", nameKo: "레노버", nameEn: "Lenovo", aliases: ["씽크패드", "아이디어패드", "thinkpad", "legion"], category: "가전/IT" },
  { id: "HP", nameKo: "HP", nameEn: "HP", aliases: ["휴렛팩커드", "파빌리온", "오멘", "spectre", "omen"], category: "가전/IT" },
  { id: "DELL", nameKo: "델", nameEn: "Dell", aliases: ["에일리언웨어", "인스피론", "xps", "alienware"], category: "가전/IT" },
  { id: "BOSE", nameKo: "보스", nameEn: "Bose", aliases: ["qc45", "qc35", "quietcomfort", "사운드링크"], category: "가전/IT" },
  { id: "JBL", nameKo: "JBL", nameEn: "JBL", aliases: ["플립", "차지", "붐박스", "하만"], category: "가전/IT" },
  { id: "MARSHALL", nameKo: "마샬", nameEn: "Marshall", aliases: ["액톤", "스탠모어", "엠버튼", "스톡웰", "acton", "stanmore"], category: "가전/IT" },
  { id: "HARMAN_KARDON", nameKo: "하만카돈", nameEn: "Harman Kardon", aliases: ["오라", "오라클", "아우라"], category: "가전/IT" },
  { id: "BANG_OLUFSEN", nameKo: "뱅앤올룹슨", nameEn: "Bang & Olufsen", aliases: ["B&O", "베오사운드", "베오플레이"], category: "가전/IT" },
  { id: "CANON", nameKo: "캐논", nameEn: "Canon", aliases: ["이오스", "eos", "익서스"], category: "가전/IT" },
  { id: "NIKON", nameKo: "니콘", nameEn: "Nikon", aliases: ["쿨픽스", "d850", "z6", "z7"], category: "가전/IT" },
  { id: "DJI", nameKo: "DJI", nameEn: "DJI", aliases: ["오즈모", "매빅", "아바타", "로닌", "osmo", "mavic"], category: "가전/IT" },
  { id: "GOPRO", nameKo: "고프로", nameEn: "GoPro", aliases: ["히어로11", "히어로12", "hero"], category: "가전/IT" },
  { id: "XIAOMI", nameKo: "샤오미", nameEn: "Xiaomi", aliases: ["미밴드", "홍미노트", "redmi", "mi band"], category: "가전/IT" },
  { id: "PHILIPS", nameKo: "필립스", nameEn: "Philips", aliases: ["소닉케어", "휴", "hue", "휴비비"], category: "가전/IT" },
  { id: "BRAUN", nameKo: "브라운", nameEn: "Braun", aliases: ["시리즈9", "시리즈7", "체온계"], category: "가전/IT" },
  { id: "TEFAL", nameKo: "테팔", nameEn: "Tefal", aliases: ["매직핸즈", "옵티그릴"], category: "가전/IT" },
  { id: "CUCKOO", nameKo: "쿠쿠", nameEn: "Cuckoo", aliases: ["쿠쿠밥솥", "트윈프레셔"], category: "가전/IT" },
  { id: "CUCHEN", nameKo: "쿠첸", nameEn: "Cuchen", aliases: ["쿠첸밥솥", "브레인"], category: "가전/IT" },
  { id: "BALMUDA", nameKo: "발뮤다", nameEn: "Balmuda", aliases: ["토스터기", "더팟", "그린팬"], category: "가전/IT" },
  { id: "DELONGHI", nameKo: "드롱기", nameEn: "De'Longhi", aliases: ["아이코나", "데디카", "마그니피카"], category: "가전/IT" },
  { id: "NESPRESSO", nameKo: "네스프레소", nameEn: "Nespresso", aliases: ["버츄오", "오리지널", "에센자", "시티즈"], category: "가전/IT" },

  // --- 명품 / 럭셔리 / 패션 (Fashion & Luxury) ---
  { id: "NIKE", nameKo: "나이키", nameEn: "Nike", aliases: ["에어포스", "조던", "에어맥스", "덩크", "jordan", "air force", "dunk"], category: "패션/스포츠" },
  { id: "ADIDAS", nameKo: "아디다스", nameEn: "Adidas", aliases: ["삼바", "가젤", "이지", "슈퍼스타", "samba", "gazelle", "yeezy"], category: "패션/스포츠" },
  { id: "CHANEL", nameKo: "샤넬", nameEn: "Chanel", aliases: ["클래식백", "보이백", "가브리엘", "샤넬no5"], category: "명품/패션" },
  { id: "GUCCI", nameKo: "구찌", nameEn: "Gucci", aliases: ["홀스빗", "디오니소스", "마몬트", "재키백"], category: "명품/패션" },
  { id: "LOUIS_VUITTON", nameKo: "루이비통", nameEn: "Louis Vuitton", aliases: ["루이뷔통", "모노그램", "스피디", "네버풀", "알마"], category: "명품/패션" },
  { id: "DIOR", nameKo: "디올", nameEn: "Dior", aliases: ["레이디디올", "새들백", "북토트", "소바쥬"], category: "명품/패션" },
  { id: "PRADA", nameKo: "프라다", nameEn: "Prada", aliases: ["나일론백", "갈레리아", "리에디션"], category: "명품/패션" },
  { id: "CROCS", nameKo: "크록스", nameEn: "Crocs", aliases: ["클로그", "지비츠", "바야밴드", "clog"], category: "신발/잡화" },
  { id: "ROLEX", nameKo: "롤렉스", nameEn: "Rolex", aliases: ["서브마리너", "데이토나", "데이저스트", "submariner"], category: "시계/명품" },
  { id: "BALENCIAGA", nameKo: "발렌시아가", nameEn: "Balenciaga", aliases: ["트리플s", "스피드러너", "카골백"], category: "명품/패션" },
  { id: "HERMES", nameKo: "에르메스", nameEn: "Hermes", aliases: ["버킨백", "켈리백", "콘스탄스", "오란"], category: "명품/패션" },
  { id: "YSL", nameKo: "입생로랑", nameEn: "Saint Laurent", aliases: ["생로랑", "YSL", "카산드라", "니키백", "루루백"], category: "명품/패션" },
  { id: "BURBERRY", nameKo: "버버리", nameEn: "Burberry", aliases: ["트렌치코트", "노바체크", "TB백"], category: "명품/패션" },
  { id: "THOM_BROWNE", nameKo: "톰브라운", nameEn: "Thom Browne", aliases: ["사선완장", "삼색탭", "밀라노"], category: "명품/패션" },
  { id: "MONCLER", nameKo: "몽클레르", nameEn: "Moncler", aliases: ["몽클레어", "클로에", "마야", "플라메뜨"], category: "명품/패션" },
  { id: "BOTTEGA_VENETA", nameKo: "보테가베네타", nameEn: "Bottega Veneta", aliases: ["인트레치아토", "카세트백", "조디백"], category: "명품/패션" },
  { id: "CELINE", nameKo: "셀린느", nameEn: "Celine", aliases: ["트리옹프", "러기지백", "벨트백"], category: "명품/패션" },
  { id: "FENDI", nameKo: "펜디", nameEn: "Fendi", aliases: ["바게트백", "피카부", "몬스터"], category: "명품/패션" },
  { id: "LOEWE", nameKo: "로에베", nameEn: "Loewe", aliases: ["퍼즐백", "해먹백", "게이트백"], category: "명품/패션" },
  { id: "MIU_MIU", nameKo: "미우미우", nameEn: "Miu Miu", aliases: ["완더백", "마테라쎄"], category: "명품/패션" },
  { id: "ZARA", nameKo: "자라", nameEn: "Zara", aliases: ["자라키즈", "자라홈"], category: "패션/의류" },
  { id: "HM", nameKo: "에이치앤엠", nameEn: "H&M", aliases: ["흐앤므", "h&m"], category: "패션/의류" },
  { id: "UNIQLO", nameKo: "유니클로", nameEn: "Uniqlo", aliases: ["히트텍", "에어리즘", "울트라라이트다운"], category: "패션/의류" },
  { id: "UNDER_ARMOUR", nameKo: "언더아머", nameEn: "Under Armour", aliases: ["프로젝트락", "콜드기어"], category: "패션/스포츠" },
  { id: "NEW_BALANCE", nameKo: "뉴발란스", nameEn: "New Balance", aliases: ["뉴발", "992", "993", "574", "327", "530"], category: "패션/스포츠" },
  { id: "ASICS", nameKo: "아식스", nameEn: "Asics", aliases: ["젤카야노", "젤벤쳐", "키코"], category: "패션/스포츠" },
  { id: "VANS", nameKo: "반스", nameEn: "Vans", aliases: ["올드스쿨", "어센틱", "체커보드"], category: "신발/스포츠" },
  { id: "CONVERSE", nameKo: "컨버스", nameEn: "Converse", aliases: ["척테일러", "올스타", "런스타"], category: "신발/스포츠" },
  { id: "PUMA", nameKo: "푸마", nameEn: "Puma", aliases: ["스웨이드", "팔레르모"], category: "패션/스포츠" },
  { id: "THE_NORTH_FACE", nameKo: "노스페이스", nameEn: "The North Face", aliases: ["눕시", "화이트라벨", "빅샷"], category: "아웃도어" },
  { id: "PATAGONIA", nameKo: "파타고니아", nameEn: "Patagonia", aliases: ["레트로x", "신칠라", "P-6"], category: "아웃도어" },
  { id: "ARCTERYX", nameKo: "아크테릭스", nameEn: "Arc'teryx", aliases: ["베타lt", "아톰ar", "헬리아드"], category: "아웃도어" },
  { id: "STONE_ISLAND", nameKo: "스톤아일랜드", nameEn: "Stone Island", aliases: ["와펜", "나일론메탈", "크링클랩스"], category: "패션/명품" },
  { id: "SUPREME", nameKo: "슈프림", nameEn: "Supreme", aliases: ["박스로고", "캠프캡"], category: "스트릿패션" },
  { id: "OFF_WHITE", nameKo: "오프화이트", nameEn: "Off-White", aliases: ["버질아블로", "애로우", "케이블타이"], category: "스트릿패션" },
  { id: "STUSSY", nameKo: "스투시", nameEn: "Stussy", aliases: ["월드투어", "8볼", "다이스"], category: "스트릿패션" },
  { id: "FEAR_OF_GOD", nameKo: "피어오브갓", nameEn: "Fear of God", aliases: ["에센셜", "fog essentials"], category: "스트릿패션" },
  { id: "MAISON_KITSUNE", nameKo: "메종키츠네", nameEn: "Maison Kitsune", aliases: ["폭스헤드", "칠랙스"], category: "컨템포러리" },
  { id: "AMI", nameKo: "아미", nameEn: "Ami", aliases: ["하트로고", "아미알렉상드르"], category: "컨템포러리" },
  { id: "ACNE_STUDIOS", nameKo: "아크네스튜디오", nameEn: "Acne Studios", aliases: ["페이스패치", "머플러", "토론토"], category: "컨템포러리" },
  { id: "MAISON_MARGIELA", nameKo: "메종마르지엘라", nameEn: "Maison Margiela", aliases: ["타비", "스티치", "레플리카향수", "독일군"], category: "컨템포러리" },
  { id: "GENTLE_MONSTER", nameKo: "젠틀몬스터", nameEn: "Gentle Monster", aliases: ["선글라스", "릴리트", "로셀"], category: "아이웨어" },
  { id: "TAMBURINS", nameKo: "탬버린즈", nameEn: "Tamburins", aliases: ["카모", "퍼퓸핸드크림", "에그퍼퓸"], category: "뷰티/향수" },

  // --- 뷰티 / 화장품 / 향수 (Beauty & Cosmetics) ---
  { id: "SULWHASOO", nameKo: "설화수", nameEn: "Sulwhasoo", aliases: ["윤조에센스", "자음생"], category: "뷰티/화장품" },
  { id: "HERA", nameKo: "헤라", nameEn: "Hera", aliases: ["블랙쿠션", "센슈얼틴트"], category: "뷰티/화장품" },
  { id: "INNISFREE", nameKo: "이니스프리", nameEn: "Innisfree", aliases: ["그린티씨드", "노세범"], category: "뷰티/화장품" },
  { id: "OLIVE_YOUNG", nameKo: "올리브영", nameEn: "Olive Young", aliases: ["올영", "웨이크메이크", "바이오힐보"], category: "뷰티/유통" },
  { id: "ROMAND", nameKo: "롬앤", nameEn: "Rom&nd", aliases: ["쥬시래스팅", "글래스팅"], category: "뷰티/색조" },
  { id: "CLIO", nameKo: "클리오", nameEn: "Clio", aliases: ["킬커버", "프로아이팔레트"], category: "뷰티/색조" },
  { id: "TOO_COOL_FOR_SCHOOL", nameKo: "투쿨포스쿨", nameEn: "Too Cool For School", aliases: ["아트클래스", "바이로댕", "쉐딩"], category: "뷰티/색조" },
  { id: "ETUDE", nameKo: "에뛰드", nameEn: "Etude", aliases: ["디어달링", "순정"], category: "뷰티/화장품" },
  { id: "JO_MALONE", nameKo: "조말론", nameEn: "Jo Malone", aliases: ["블랙베리앤베이", "우드세이지", "잉글리쉬페어"], category: "향수/뷰티" },
  { id: "DIPTYQUE", nameKo: "딥티크", nameEn: "Diptyque", aliases: ["도손", "탐다오", "플레르드뽀", "필로시코스"], category: "향수/뷰티" },
  { id: "BYREDO", nameKo: "바이레도", nameEn: "Byredo", aliases: ["블랑쉬", "집시워터", "발다프리크", "모하비고스트"], category: "향수/뷰티" },
  { id: "AESOP", nameKo: "이솝", nameEn: "Aesop", aliases: ["에이솝", "레저렉션", "테싯", "마라케시"], category: "뷰티/바디" },

  // --- 라이프스타일 / 리빙 / 식음료 / 완구 / 자동차 (Living & Motors) ---
  { id: "STARBUCKS", nameKo: "스타벅스", nameEn: "Starbucks", aliases: ["스벅", "사이렌", "프라푸치노", "starbucks"], category: "식음료" },
  { id: "LEGO", nameKo: "레고", nameEn: "Lego", aliases: ["듀플로", "테크닉", "lego", "닌자고"], category: "완구/취미" },
  { id: "STANLEY", nameKo: "스탠리", nameEn: "Stanley", aliases: ["퀜처", "어드벤처", "보온병", "텀블러", "quencher"], category: "주방/아웃도어" },
  { id: "TESLA", nameKo: "테슬라", nameEn: "Tesla", aliases: ["모델3", "모델y", "모델s", "모델x", "model 3", "model y"], category: "자동차" },
  { id: "PORSCHE", nameKo: "포르쉐", nameEn: "Porsche", aliases: ["911", "타이칸", "파나메라", "카이엔", "마칸"], category: "자동차" },
  { id: "BMW", nameKo: "BMW", nameEn: "BMW", aliases: ["비엠더블유", "m3", "m5", "x5", "x6", "x7"], category: "자동차" },
  { id: "BENZ", nameKo: "벤츠", nameEn: "Mercedes-Benz", aliases: ["메르세데스벤츠", "메르세데스", "e클래스", "s클래스", "c클래스"], category: "자동차" },
  { id: "AUDI", nameKo: "아우디", nameEn: "Audi", aliases: ["콰트로", "a6", "a7", "a8", "q7", "q8"], category: "자동차" },
  { id: "HYUNDAI", nameKo: "현대", nameEn: "Hyundai", aliases: ["아이오닉", "그랜저", "아반떼", "싼타페", "투싼", "제네시스"], category: "자동차" },
  { id: "KIA", nameKo: "기아", nameEn: "Kia", aliases: ["스포티지", "쏘렌토", "카니발", "k5", "k8", "ev6", "ev9"], category: "자동차" },
  { id: "SAMSONITE", nameKo: "샘소나이트", nameEn: "Samsonite", aliases: ["캐리어", "레드", "아메리칸투어리스터"], category: "여행/잡화" },
  { id: "TUPPERWARE", nameKo: "타파웨어", nameEn: "Tupperware", aliases: ["밀폐용기", "에코물통"], category: "주방/생활" }
];

/**
 * 4대 침해 패턴 정규식 및 키워드 사전
 */
const IP_PATTERNS = {
  // 1. 단독 모조품/불법 사칭/가품 의심 키워드
  COUNTERFEIT_KEYWORDS: [
    "레플리카", "레플", "미러급", "SA급", "S급레플", "1:1제작", "1:1미러", "커스텀급",
    "오마주", "정품급", "정품동일", "하이엔드급", "파이널급", "자체제작급", "풀박스급"
  ],

  // 2. 사칭/스타일 접미사 및 접두사 패턴 (~스타일, ~st, ~풍 등)
  STYLE_SUFFIX_REGEX: /(?:스타일|st\.?|풍|느낌|모티브|st스타일|모작|카피)/i,

  // 3. 정당한 호환/전용 표기 키워드 (상표법 제90조 준용)
  COMPATIBLE_KEYWORDS: [
    "전용", "호환", "호환용", "호환되는", "용", "부속품", "부품", "소모품",
    "교체용", "장착용", "악세사리", "액세서리", "케이스", "거치대", "필름", "필터",
    "for", "compatible", "dedicated", "replacement"
  ]
};

class TrademarkIpSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.appRoot = options.appRoot || path.resolve(__dirname, "..");
    this.storagePath = options.storagePath || path.join(this.appRoot, "logs", "trademark_ip_audits.json");
    this.configPath = options.configPath || path.join(this.appRoot, "config", "trademark_ip_config.json");
    this.brands = TRADEMARK_BRAND_DATABASE;
    this.ensureStorageDir();
  }

  ensureStorageDir() {
    try {
      const logsDir = path.dirname(this.storagePath);
      if (!fs.existsSync(logsDir)) {
        fs.mkdirSync(logsDir, { recursive: true });
      }
      const configDir = path.dirname(this.configPath);
      if (!fs.existsSync(configDir)) {
        fs.mkdirSync(configDir, { recursive: true });
      }
    } catch (_) {}
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") return parsed;
      }
    } catch (_) {}
    return {
      enabled: true,
      storeName: "AutoFlow 이커머스 컴플라이언스 센터",
      sellerName: "오토플로우 대표",
      sellerPhone: "02-1544-0000",
      sellerEmail: "legal-ip@autoflow.local",
      settlementDefenseStyleWon: 3000000,
      settlementDefenseDirectWon: 5000000
    };
  }

  loadAudits() {
    try {
      if (fs.existsSync(this.storagePath)) {
        const raw = fs.readFileSync(this.storagePath, "utf8");
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          return parsed.filter(a => a && typeof a === "object" && a.auditId);
        }
      }
    } catch (_) {}
    return [];
  }

  recordAudit(auditRecord) {
    if (!auditRecord || typeof auditRecord !== "object" || !auditRecord.auditId) {
      return;
    }
    try {
      const audits = this.loadAudits();
      const existingIdx = audits.findIndex(a => a && a.auditId === auditRecord.auditId);
      if (existingIdx >= 0) {
        audits[existingIdx] = auditRecord;
      } else {
        audits.unshift(auditRecord);
      }
      if (audits.length > 5000) {
        audits.length = 5000;
      }
      fs.writeFileSync(this.storagePath, JSON.stringify(audits, null, 2), "utf8");
    } catch (err) {
      console.error("[TrademarkIpSentinel] 원장 저장 실패:", err.message);
    }
  }

  /**
   * 4대 침해 판정 엔진: 상표권 및 지식재산권 리스크 정밀 대사
   * @param {Object} productData 상품 데이터
   * @param {Object} customOptions 추가 설정
   * @returns {Object} 감사 결과 레코드
   */
  auditTrademarkRisk(productData = {}, customOptions = {}) {
    productData = (productData && typeof productData === "object" && !Array.isArray(productData)) ? productData : {};
    customOptions = (customOptions && typeof customOptions === "object" && !Array.isArray(customOptions)) ? customOptions : {};
    const config = Object.assign({}, this.getConfig(), customOptions);

    const auditId = productData.auditId || `IP-${Date.now()}-${Math.floor(Math.random() * 1000).toString().padStart(3, "0")}`;
    const auditTime = productData.auditTime || new Date().toISOString();
    const productName = String(productData.productName || productData.name || "").trim();
    const keywords = Array.isArray(productData.keywords) 
      ? productData.keywords.join(" ") 
      : String(productData.keywords || productData.tags || "").trim();
    const description = String(productData.description || productData.desc || "").trim();
    const sellerBrand = String(productData.sellerBrand || productData.brand || "").trim();
    const marketplace = String(productData.marketplace || "쿠팡 (Coupang Wing)").trim();
    const claimedBrand = String(productData.claimedBrand || "").trim();
    const hasInput = Boolean(productName || keywords || description || sellerBrand || claimedBrand);

    const fullText = `${productName} ${keywords} ${description}`.trim();
    const normalizedText = fullText.toLowerCase();

    // 1. 단독 모조품/가품 키워드 검출
    const matchedCounterfeitKeywords = [];
    for (const kw of IP_PATTERNS.COUNTERFEIT_KEYWORDS) {
      if (fullText.includes(kw)) {
        matchedCounterfeitKeywords.push(kw);
      }
    }

    // 2. 등록상표 매칭 분석
    const matchedBrands = [];
    for (const b of this.brands) {
      let isBrandHit = false;
      const candidates = [b.nameKo, b.nameEn, ...b.aliases];

      for (const cand of candidates) {
        if (!cand) continue;
        const candLower = cand.toLowerCase();

        // 한글 2글자 이상, 영문 3글자 이상 매칭 우선 (오탐지 방지: 짧은 단어 주의)
        if (candLower.length < 2) continue;

        // 특수문자 이스케이프 정규식
        const escaped = cand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const brandRegex = new RegExp(`(^|[^a-zA-Z0-9가-힣])${escaped}([^a-zA-Z0-9가-힣]|$)`, "i");

        if (brandRegex.test(fullText)) {
          isBrandHit = true;
          break;
        }
      }

      if (isBrandHit) {
        matchedBrands.push(b);
      }
    }

    // 3. 사칭 패턴(~스타일, ~st 등) 매칭 분석
    const matchedStyleViolations = [];
    for (const b of this.brands) {
      const brandNames = [b.nameKo, b.nameEn, ...b.aliases];
      for (const bn of brandNames) {
        if (!bn || bn.length < 2) continue;
        const esc = bn.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

        // "나이키st", "나이키스타일", "샤넬 st", "다이슨풍", "애플st 케이스", "스타일 샤넬" 등 (스타일러, 스타일링 등 일반 명사 제외)
        const styleRegex1 = new RegExp(`${esc}[\\s\\-_]*(?:스타일|st\\.?|풍|느낌|모티브|st스타일|모작|카피)(?![가-힣a-zA-Z0-9])`, "i");
        const styleRegex2 = new RegExp(`(?:스타일|st\\.?|풍|느낌|모티브|st스타일|모작|카피)[\\s\\-_]*${esc}(?![가-힣a-zA-Z0-9])`, "i");

        if (styleRegex1.test(fullText)) {
          const m = fullText.match(styleRegex1);
          matchedStyleViolations.push({ brand: b.nameKo, matchedWord: m ? m[0] : `${bn} 스타일` });
        } else if (styleRegex2.test(fullText)) {
          const m = fullText.match(styleRegex2);
          matchedStyleViolations.push({ brand: b.nameKo, matchedWord: m ? m[0] : `스타일 ${bn}` });
        }
      }
    }

    // 일반 사칭 키워드 단독 검사 ("OO 스타일", "OOst", "OO st.") (스타일러, 스타일링 제외)
    const genericStyleRegex = /([a-zA-Z가-힣0-9]{2,10})[\s\-_]*(?:스타일|st\.)(?![가-힣a-zA-Z0-9])/gi;
    let styleMatch;
    while ((styleMatch = genericStyleRegex.exec(productName)) !== null) {
      const word = styleMatch[0];
      const target = styleMatch[1];
      // 이미 잡힌 건 제외하고 추가
      if (!matchedStyleViolations.some(v => v.matchedWord.toLowerCase() === word.toLowerCase())) {
        matchedStyleViolations.push({ brand: target, matchedWord: word });
      }
    }


    // 4. 정당한 호환/전용 표기 분석 (상표법 제90조 준용)
    const hasCompatibleKeyword = IP_PATTERNS.COMPATIBLE_KEYWORDS.some(k => fullText.includes(k));

    // 5. 판정 엔진 (4대 적합성 상태)
    let verdict = "IP_CLEAN";
    let verdictLabel = "✅ 지재권 완전 안전 (Clean IP)";
    let complianceScore = 100;
    let penaltySavedWon = 0;
    let riskLevel = "SAFE";
    let actionRecommendation = "침해 의심 요소가 감지되지 않았습니다. 안전하게 상품을 등록 및 출고할 수 있습니다.";
    const violationPoints = [];

    // [우선순위 1] 직접 무단 도용 및 가품/복제 의심 (IP_CRITICAL_DIRECT_INFRINGE)
    if (matchedCounterfeitKeywords.length > 0) {
      verdict = "IP_CRITICAL_DIRECT_INFRINGE";
      verdictLabel = "🛑 가품·모조품 의심 키워드 감지 (즉시 판매중단)";
      complianceScore = 10;
      penaltySavedWon = config.settlementDefenseDirectWon || 5000000;
      riskLevel = "CRITICAL";
      violationPoints.push(`모조품/가품 유통 의심 키워드 적발: [${matchedCounterfeitKeywords.join(", ")}]`);
      actionRecommendation = "상표법 제108조(침해로 보는 행위) 및 형사처벌(7년 이하 징역/1억 원 이하 벌금) 대상이 될 수 있는 모조품 의심 키워드가 감지되었습니다. 즉시 상품 판매를 중단하고 키워드를 영구 삭제하십시오.";
    } 
    // [우선순위 2] 사칭 키워드 (~스타일, ~st 등) (IP_RISK_STYLE_INFRINGEMENT)
    else if (matchedStyleViolations.length > 0) {
      verdict = "IP_RISK_STYLE_INFRINGEMENT";
      verdictLabel = "🚨 사칭·스타일(~st) 침해 위험 (삭제 권고)";
      complianceScore = 40;
      penaltySavedWon = config.settlementDefenseStyleWon || 3000000;
      riskLevel = "HIGH";
      const words = matchedStyleViolations.map(v => v.matchedWord).join(", ");
      violationPoints.push(`부정경쟁방지법 위반 사칭 키워드 적발: [${words}]`);
      actionRecommendation = "부정경쟁방지법 제2조 및 상표법 위반 위험이 높은 사칭 키워드(~스타일, ~st 등)가 감지되었습니다. 상표권자로부터 건당 300만 원 상당의 합의금 청구 또는 쿠팡 WING 계정 정지를 당할 수 있으므로 해당 키워드를 즉시 삭제하십시오.";
    }
    // [우선순위 3] 등록상표 무단 도용 (호환/전용 표기 없이 타사 브랜드 직접 사용)
    else if (matchedBrands.length > 0) {
      // 판매자가 자신이 해당 브랜드라고 주장하거나, 브랜드가 일치하는지 확인
      const isAuthorizedOrOwnBrand = sellerBrand && matchedBrands.some(b => 
        b.nameKo.toLowerCase() === sellerBrand.toLowerCase() || 
        b.nameEn.toLowerCase() === sellerBrand.toLowerCase()
      );

      if (isAuthorizedOrOwnBrand) {
        // 자사 브랜드인 경우 완전 안전
        verdict = "IP_CLEAN";
        verdictLabel = "✅ 정식 브랜드 상표 사용 (Clean IP)";
        complianceScore = 100;
        penaltySavedWon = 0;
        riskLevel = "SAFE";
        actionRecommendation = "판매자 본인의 등록상표 또는 정식 라이선스 브랜드가 확인되었습니다. 안전하게 출고 가능합니다.";
      } else if (hasCompatibleKeyword) {
        // 호환/전용 표기가 있는 경우 -> 상표법 제90조 정당사용 주의
        verdict = "IP_COMPATIBLE_CAUTION";
        verdictLabel = "⚠️ 호환/전용 표기 주의 (정품 오인 방지 권고)";
        complianceScore = 85;
        penaltySavedWon = 0;
        riskLevel = "MEDIUM";
        const brandNames = matchedBrands.map(b => b.nameKo).join(", ");
        violationPoints.push(`상표법 제90조 호환품 표기 대상 브랜드: [${brandNames}]`);
        actionRecommendation = `상표법 제90조에 따른 정당한 호환 표기이나, 소비자 오인을 방지하기 위해 상세페이지 최상단에 "본 제품은 ${brandNames}사의 정품이 아닌 호환용 제품입니다" 안내 문구를 반드시 게시하십시오.`;
      } else {
        // 호환/전용 표기 없이 타사 등록상표를 직접 상품명에 사용 -> 직접 도용 위험
        verdict = "IP_CRITICAL_DIRECT_INFRINGE";
        verdictLabel = "🛑 타사 등록상표 무단 도용 위험 (즉시 수정)";
        complianceScore = 20;
        penaltySavedWon = config.settlementDefenseDirectWon || 5000000;
        riskLevel = "CRITICAL";
        const brandNames = matchedBrands.map(b => b.nameKo).join(", ");
        violationPoints.push(`타사 등록상표 직접 사용 감지: [${brandNames}] (호환/전용 수식어 부재)`);
        actionRecommendation = `타사의 등록상표(${brandNames})가 호환/전용이라는 수식어 없이 상품명에 단독 기재되어 상표권 침해(상표법 제108조) 및 계정 정지 위험이 발생합니다. "호환용" 또는 "전용" 문구를 명확히 추가하거나 타사 브랜드명을 삭제하십시오.`;
      }
    } else {
      // 아무 침해 키워드 없음
      verdict = "IP_CLEAN";
      verdictLabel = "✅ 지재권 완전 안전 (Clean IP)";
      complianceScore = 100;
      penaltySavedWon = 0;
      riskLevel = "SAFE";
      actionRecommendation = "침해 의심 요소가 감지되지 않았습니다. 안전하게 상품을 등록 및 출고할 수 있습니다.";
    }

    const auditRecord = {
      auditId,
      auditTime,
      productName,
      keywords,
      descriptionSnippet: description.substring(0, 100),
      sellerBrand,
      marketplace,
      claimedBrand: claimedBrand || (matchedBrands.length > 0 ? matchedBrands[0].nameKo : "해당 없음"),
      verdict,
      verdictLabel,
      complianceScore,
      riskLevel,
      penaltySavedWon,
      matchedBrands: matchedBrands.map(b => ({ id: b.id, nameKo: b.nameKo, nameEn: b.nameEn })),
      matchedStyleViolations,
      matchedCounterfeitKeywords,
      violationPoints,
      actionRecommendation,
      status: (verdict === "IP_CLEAN" || verdict === "IP_COMPATIBLE_CAUTION") ? "CLEAN" : "PENDING_ACTION",
      resolution: null,
      resolvedAt: null,
      notes: ""
    };

    if (customOptions.record !== false && (hasInput || customOptions.record === true)) {
      this.recordAudit(auditRecord);
    }
    return auditRecord;
  }

  /**
   * Pure White Clean Enterprise 라이트 모드 공식 지식재산권 비침해 소명서 및 답변서 HTML 생성기
   * 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건, 다크모드 영구 금지)
   * @param {Object} auditRecord 감사 레코드
   * @param {Object} customConfig 판매자 정보 설정
   * @returns {string} Pure White Clean HTML 문서
   */
  generateTrademarkDisputeEvidenceHtml(auditRecord = {}, customConfig = {}) {
    auditRecord = (auditRecord && typeof auditRecord === "object") ? auditRecord : {};
    customConfig = (customConfig && typeof customConfig === "object") ? customConfig : {};
    const config = Object.assign({}, this.getConfig(), customConfig);
    const record = auditRecord;

    const certSerial = `AF-IP-${record.auditId ? String(record.auditId).replace(/[^A-Za-z0-9]/g, "") : Date.now()}`;
    const issueDate = record.auditTime ? new Date(record.auditTime).toLocaleString("ko-KR", { timeZone: "Asia/Seoul" }) : new Date().toLocaleString("ko-KR", { timeZone: "Asia/Seoul" });
    const complianceScore = record.complianceScore !== undefined && record.complianceScore !== null ? Number(record.complianceScore) : 100;
    const verdictLabel = record.verdictLabel || "✅ 지재권 완전 안전 (Clean IP)";
    const actionRecommendation = record.actionRecommendation || "침해 의심 요소가 감지되지 않았습니다. 안전하게 상품을 등록 및 출고할 수 있습니다.";

    let verdictBadgeBg = "#ecfdf5";
    let verdictBadgeColor = "#065f46";
    if (record.verdict === "IP_COMPATIBLE_CAUTION") {
      verdictBadgeBg = "#fffbeb";
      verdictBadgeColor = "#92400e";
    } else if (record.verdict === "IP_RISK_STYLE_INFRINGEMENT") {
      verdictBadgeBg = "#fff7ed";
      verdictBadgeColor = "#c2410c";
    } else if (record.verdict === "IP_CRITICAL_DIRECT_INFRINGE") {
      verdictBadgeBg = "#fef2f2";
      verdictBadgeColor = "#991b1b";
    }

    const matchedBrandsText = (Array.isArray(record.matchedBrands) && record.matchedBrands.length > 0)
      ? record.matchedBrands.filter(b => b && typeof b === "object").map(b => `${b.nameKo || ""} (${b.nameEn || ""})`).join(", ")
      : "특정 등록상표 없음 (일반 상품)";

    const violationsHtml = (Array.isArray(record.violationPoints) && record.violationPoints.length > 0)
      ? record.violationPoints.map(p => `<li>${p}</li>`).join("")
      : "<li>특이 위반 사항 없음 (지식재산권 법률 기준 100% 충족)</li>";

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>지식재산권 비침해 소명서 및 공식 답변서 - ${certSerial}</title>
  <style>
    body {
      margin: 0;
      padding: 30px;
      background: #f8fafc;
      font-family: -apple-system, BlinkMacSystemFont, "Malgun Gothic", "맑은 고딕", helvetica, sans-serif;
      color: #0f172a;
      line-height: 1.6;
    }
    .doc-container {
      max-width: 840px;
      margin: 0 auto;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 40px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    }
    .doc-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 2px solid #0f172a;
      padding-bottom: 20px;
      margin-bottom: 26px;
    }
    .doc-title-group h1 {
      margin: 0;
      font-size: 22px;
      font-weight: 800;
      color: #0f172a;
      letter-spacing: -0.5px;
    }
    .doc-title-group p {
      margin: 6px 0 0 0;
      font-size: 12px;
      color: #64748b;
    }
    .print-btn {
      padding: 8px 16px;
      background: #0f172a;
      color: #ffffff;
      border: none;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
    }
    .meta-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px 24px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 18px 22px;
      margin-bottom: 26px;
    }
    .meta-item {
      display: flex;
      font-size: 13px;
    }
    .meta-item .label {
      width: 140px;
      color: #64748b;
      font-weight: 600;
    }
    .meta-item .value {
      flex: 1;
      color: #0f172a;
      font-weight: 700;
    }
    .legal-box {
      background: #eff6ff;
      border-left: 4px solid #2563eb;
      padding: 14px 18px;
      border-radius: 4px;
      font-size: 12px;
      color: #1e40af;
      line-height: 1.6;
      margin-bottom: 26px;
    }
    .verdict-banner {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      padding: 16px 20px;
      margin-bottom: 26px;
    }
    .verdict-pill {
      display: inline-block;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 800;
      background: ${verdictBadgeBg};
      color: ${verdictBadgeColor};
    }
    .detail-section {
      margin-bottom: 26px;
    }
    .detail-section h2 {
      font-size: 15px;
      font-weight: 800;
      color: #0f172a;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
      margin-bottom: 12px;
    }
    ul.violation-list {
      margin: 0;
      padding-left: 20px;
      font-size: 13px;
      color: #334155;
    }
    ul.violation-list li {
      margin-bottom: 6px;
    }
    .statement-box {
      background: #fffbeb;
      border-left: 4px solid #f59e0b;
      padding: 14px 18px;
      border-radius: 4px;
      font-size: 12px;
      color: #92400e;
      line-height: 1.6;
      margin-bottom: 28px;
    }
    .doc-footer {
      border-top: 1px solid #e2e8f0;
      padding-top: 24px;
      margin-top: 24px;
    }
    .signature-area {
      text-align: right;
      font-size: 13px;
      font-weight: 700;
      color: #0f172a;
      line-height: 1.8;
      margin-bottom: 16px;
    }
    .system-badge {
      font-size: 11px;
      color: #64748b;
      display: flex;
      justify-content: space-between;
    }
    @media print {
      body {
        padding: 0;
        background: #ffffff;
      }
      .doc-container {
        border: none;
        box-shadow: none;
        padding: 0;
        max-width: 100%;
      }
      .print-btn {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="doc-container">
    <div class="doc-header">
      <div class="doc-title-group">
        <h1>📋 지식재산권 비침해 정당사용 소명서 및 공식 답변서</h1>
        <p>Official Statutory Intellectual Property Defense & Non-Infringement Evidence</p>
      </div>
      <div class="doc-actions">
        <button type="button" class="print-btn" onclick="window.print()">🖨️ 증적 인쇄 / PDF 저장</button>
      </div>
    </div>

    <div class="meta-grid">
      <div class="meta-item"><span class="label">소명서 일련번호:</span><span class="value" style="font-family: monospace;">${certSerial}</span></div>
      <div class="meta-item"><span class="label">감사 발급 일시:</span><span class="value">${issueDate}</span></div>
      <div class="meta-item"><span class="label">대상 상품명:</span><span class="value">${record.productName || '미기재'}</span></div>
      <div class="meta-item"><span class="label">판매 플랫폼:</span><span class="value">${record.marketplace || '쿠팡 (Coupang Wing)'}</span></div>
      <div class="meta-item"><span class="label">판매자 등록 브랜드:</span><span class="value">${record.sellerBrand || '자체/미등록'}</span></div>
      <div class="meta-item"><span class="label">감지/주장 상표:</span><span class="value">${matchedBrandsText}</span></div>
    </div>

    <div class="legal-box">
      <strong>⚖️ 지식재산권 비침해 법적 근거 및 판례 원칙:</strong><br>
      1. <strong>「상표법」 제90조(상표권의 효력이 미치지 아니하는 범위) 제1항 제2호:</strong> 상품의 용도, 수량, 규격 등을 보통으로 사용하는 방법으로 표시하는 상표에는 타인의 등록상표권의 효력이 미치지 아니합니다. 본 상품은 특정 단말기 또는 기기와의 호환성 및 규격을 소비자에게 객관적으로 고지하기 위한 목적으로 최소한의 설명을 기재한 것으로서, 출처 표시로서의 상표적 사용에 해당하지 않습니다.<br>
      2. <strong>대법원 확립 판례(대법원 2002도3445 등):</strong> 타인의 등록상표를 자기 상품의 규격, 용도, 호환 대상을 알리기 위해 부득이하게 사용하는 것은 소비자로 하여금 상품 출처의 오인·혼동을 초래할 우려가 없는 한 정당한 사용으로서 상표권 침해 및 부정경쟁행위를 구성하지 아니합니다.<br>
      3. <strong>「부정경쟁방지 및 영업비밀보호에 관한 법률」 제2조 제1호 비침해:</strong> 본 판매자는 타인의 상품 식별력이나 명성을 손상할 의도가 전혀 없으며, 정품 오인을 방지하기 위한 안내 문구를 충실히 게재하고 있습니다.
    </div>

    <div class="verdict-banner">
      <div>
        <div style="font-size: 11px; font-weight: 700; color: #64748b; margin-bottom: 4px;">지식재산권(상표권) 종합 판정</div>
        <div style="font-size: 18px; font-weight: 800; color: #0f172a;">
          적합성 점수: <span style="color: ${complianceScore >= 80 ? '#059669' : '#b91c1c'};">${complianceScore}점 / 100점</span>
        </div>
      </div>
      <div style="text-align: right;">
        <span class="verdict-pill">${verdictLabel}</span>
        <div style="margin-top: 6px; font-size: 11px; font-weight: 700; color: ${record.penaltySavedWon > 0 ? '#b91c1c' : '#059669'};">
          ${record.penaltySavedWon > 0 ? `🛡️ 상표권 합의금/과태료 사전 방어액: ₩${Number(record.penaltySavedWon).toLocaleString()}원` : '✅ 법적 분쟁 위험 0원 (정당한 사용)'}
        </div>
      </div>
    </div>

    <div class="detail-section">
      <h2>📋 세부 검토 및 감별 사항</h2>
      <ul class="violation-list">
        ${violationsHtml}
      </ul>
    </div>

    <div class="statement-box">
      <strong>📝 법무 검토 의견 및 시정 권고:</strong><br>
      ${actionRecommendation}
    </div>

    <div class="doc-footer">
      <div class="signature-area">
        ${issueDate.substring(0, 10)}<br><br>
        소명인(판매사업자): ${config.storeName} (${config.sellerName}) (인쇄 시 직인 생략)
      </div>
      <div class="system-badge">
        <span>발급 엔진: AutoFlow Enterprise Trademark IP Sentinel v2.0 (인쇄 시 직인 생략)</span>
        <span>법무/컴플라이언스 문의: ${config.sellerPhone} | ${config.sellerEmail}</span>
      </div>
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * 누적 통계 집계
   */
  getSummary() {
    const audits = this.loadAudits();
    let totalAudits = audits.length;
    let cleanCount = 0;
    let compatibleCautionCount = 0;
    let styleRiskCount = 0;
    let criticalDirectCount = 0;
    let totalPreventedSettlementCostWon = 0;
    let resolvedCount = 0;
    let pendingIssuesCount = 0;

    for (const a of audits) {
      if (!a || typeof a !== "object") continue;
      if (a.verdict === "IP_CLEAN") cleanCount++;
      else if (a.verdict === "IP_COMPATIBLE_CAUTION") compatibleCautionCount++;
      else if (a.verdict === "IP_RISK_STYLE_INFRINGEMENT") styleRiskCount++;
      else if (a.verdict === "IP_CRITICAL_DIRECT_INFRINGE") criticalDirectCount++;

      totalPreventedSettlementCostWon += Number(a.penaltySavedWon || 0);

      if (a.status === "RESOLVED") {
        resolvedCount++;
      } else if (a.status === "PENDING_ACTION") {
        pendingIssuesCount++;
      }
    }

    return {
      totalAudits,
      cleanCount,
      compatibleCautionCount,
      styleRiskCount,
      criticalDirectCount,
      totalPreventedSettlementCostWon,
      resolvedCount,
      pendingIssuesCount,
      totalBrandsMonitored: this.brands.length,
      latestAudits: audits.slice(0, 50)
    };
  }

  /**
   * 지재권 이슈 종결 처리
   */
  resolveIpIssue(auditId, resolution = "KEYWORD_REMOVED", notes = "") {
    if (auditId && typeof auditId === "object") {
      resolution = auditId.resolution || resolution || "KEYWORD_REMOVED";
      notes = auditId.notes || notes || "";
      auditId = auditId.auditId || "";
    }
    resolution = (typeof resolution === "string" && resolution) ? resolution : "KEYWORD_REMOVED";
    const audits = this.loadAudits();
    const target = audits.find(a => a && a.auditId === auditId);
    if (!target) {
      return { success: false, message: `감사 ID [${auditId || ""}]를 찾을 수 없습니다.` };
    }

    target.status = "RESOLVED";
    target.resolution = resolution;
    target.resolvedAt = new Date().toISOString();
    target.notes = String(notes || "판매자가 키워드를 수정하거나 소명 증적을 등록 완료함.");

    fs.writeFileSync(this.storagePath, JSON.stringify(audits, null, 2), "utf8");
    return { success: true, audit: target };
  }

  /**
   * 특정 감사에 대한 HTML 보고서 발급
   */
  generateDisputeResponseDoc(auditIdOrObj, customConfig = {}) {
    customConfig = (customConfig && typeof customConfig === "object") ? customConfig : {};
    const audits = this.loadAudits();
    let target = null;
    if (auditIdOrObj && typeof auditIdOrObj === "object") {
      if (auditIdOrObj.auditId) {
        target = audits.find(a => a && a.auditId === auditIdOrObj.auditId) || auditIdOrObj;
      } else {
        target = auditIdOrObj;
      }
    } else if (typeof auditIdOrObj === "string" || typeof auditIdOrObj === "number") {
      const idStr = String(auditIdOrObj);
      target = audits.find(a => a && a.auditId === idStr) || { auditId: idStr };
    } else {
      target = audits[0] || {};
    }
    return this.generateTrademarkDisputeEvidenceHtml(target, customConfig);
  }
}

const defaultTrademarkIpSentinel = new TrademarkIpSentinel();
const createTrademarkIpSentinel = (options = {}) => new TrademarkIpSentinel(options);
TrademarkIpSentinel.createTrademarkIpSentinel = createTrademarkIpSentinel;

module.exports = {
  TRADEMARK_BRAND_DATABASE,
  IP_PATTERNS,
  TrademarkIpSentinel,
  trademarkIpSentinel: defaultTrademarkIpSentinel,
  createTrademarkIpSentinel
};
