/**
 * AutoFlow Hub Stagnation & Delayed Delivery Shield v2.0
 *
 * [비즈니스 & 법무 목적]
 * 1. 택배사 간선 메가허브(CJ 옥천HUB/곤지암HUB, 롯데 이천HUB, 한진 대전HUB 등)에서
 *    화물 분류 과밀 또는 오도착으로 인해 24시간~48시간 이상 멈춰 있는 '허브 지옥'을 1초 만에 감별.
 * 2. 「전자상거래 등에서의 소비자보호에 관한 법률」 제15조 제1항(재화등의 공급 시기 알림 의무) 준수:
 *    - 고객이 분노하여 허위송장 의심/취소 항의를 하기 전에 선제적 정중 안심 문자 1초 발송 (CS 제로화).
 * 3. 택배사 허브 지점장 제출용 공식 화물 긴급 출고/수색 요청 공문서 HTML 자동 렌더링:
 *    - Pure White Clean Enterprise 라이트 모드 및 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건).
 * 4. 쿠팡 정시배송율 감점 및 아이템위너 박탈 패널티 사전 소명 증적 확보.
 * 5. 허브 정체 관리 큐(`logs/hub_stagnation_orders.json`) 영속화 및 상태 전이.
 */

const fs = require("fs");
const path = require("path");

class HubStagnationSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/hub_stagnation_orders.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/hub_stagnation_config.json");

    this.SUPPORTED_CARRIERS = {
      CJ: { name: "CJ대한통운", phone: "1588-1255", majorHubs: ["옥천HUB", "곤지암HUB", "용인HUB", "대전HUB", "청원HUB"] },
      POST: { name: "우체국택배", phone: "1588-1300", majorHubs: ["중부권IMC", "동서울우편집중국", "대전우편집중국"] },
      HANJIN: { name: "한진택배", phone: "1588-0011", majorHubs: ["대전HUB", "구로HUB", "군포HUB", "남서울HUB"] },
      LOTTE: { name: "롯데택배", phone: "1588-2121", majorHubs: ["이천HUB", "동남권HUB", "오산HUB", "신탄진HUB"] },
      LOGEN: { name: "로젠택배", phone: "1588-9988", majorHubs: ["덕평HUB", "이천HUB", "안성HUB"] },
      KDEXP: { name: "경동택배", phone: "1899-5368", majorHubs: ["김포터미널", "백암터미널", "옥천터미널"] },
      DAESIN: { name: "대신택배", phone: "043-255-3211", majorHubs: ["청원터미널", "안성터미널"] },
      ILYANG: { name: "일양로지스", phone: "1588-0002", majorHubs: ["마포터미널", "부천터미널"] }
    };

    this.defaultConfig = {
      stagnantHoursWarning: 24, // 24시간 정체 시 주의
      stagnantHoursCritical: 48, // 48시간 정체 시 초긴급 독촉
      storeName: "AutoFlow 공식 스토어",
      sellerName: "디에이치랩스 대표 김동형",
      sellerPhone: "010-0000-0000",
      sellerAddress: "서울특별시 강남구 테헤란로",
      sellerEmail: "contact@autoflow.enterprise.kr"
    };

    this.ensureStorage();
  }

  ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(this.storagePath, JSON.stringify({ orders: [], updatedAt: new Date().toISOString() }, null, 2), "utf8");
      }
    } catch (e) {}
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          return Object.assign({}, this.defaultConfig, parsed);
        }
      }
    } catch (e) {}
    return Object.assign({}, this.defaultConfig);
  }

  /**
   * 허브 터미널 입고 경과 시간 및 4단계 위험도 평가
   * @param {Object} order 주문 및 배송 추적 데이터
   * @param {Object} customOptions 옵션 재정의
   * @returns {Object}
   */
  evaluateHubStagnation(order = {}, customOptions = {}) {
    order = (order && typeof order === "object") ? order : {};
    customOptions = (customOptions && typeof customOptions === "object") ? customOptions : {};
    const config = Object.assign({}, this.getConfig(), customOptions);
    const carrierCode = String(order.carrierCode || "CJ").toUpperCase();
    const carrierInfo = this.SUPPORTED_CARRIERS[carrierCode] || { name: order.carrierName || "기타택배", phone: "1588-0000", majorHubs: [] };

    const hubEntryTimeStr = order.hubEntryAt || order.lastTrackingAt || order.shippedAt || new Date().toISOString();
    let hubEntryTime = new Date(hubEntryTimeStr).getTime();
    const now = Date.now();
    if (!Number.isFinite(hubEntryTime) || hubEntryTime <= 0) {
      hubEntryTime = now;
    }

    const elapsedMs = Math.max(0, now - hubEntryTime);
    const elapsedHours = Number((elapsedMs / (1000 * 60 * 60)).toFixed(1));
    const elapsedDays = Number((elapsedHours / 24).toFixed(1));

    let riskLevel = "NORMAL_TRANSIT";
    let isStagnant = false;
    let isCritical = false;

    if (order.status === "DELIVERY_COMPLETED" || order.isDelivered) {
      riskLevel = "DELIVERY_COMPLETED";
    } else if (elapsedHours >= config.stagnantHoursCritical) {
      riskLevel = "CRITICAL_DELAY_48H";
      isStagnant = true;
      isCritical = true;
    } else if (elapsedHours >= config.stagnantHoursWarning) {
      riskLevel = "HUB_STAGNANT_24H";
      isStagnant = true;
    }

    const currentHubName = order.hubName || (carrierInfo.majorHubs[0] || "메가간선HUB");

    return {
      orderId: order.orderId || "미지정",
      trackingNumber: order.trackingNumber || "미등록",
      carrierCode,
      carrierName: carrierInfo.name,
      carrierPhone: carrierInfo.phone,
      currentHubName,
      hubEntryTime: new Date(hubEntryTime).toISOString(),
      elapsedHours,
      elapsedDays,
      riskLevel,
      isStagnant,
      isCritical,
      stagnantThresholdWarning: config.stagnantHoursWarning,
      stagnantThresholdCritical: config.stagnantHoursCritical
    };
  }

  /**
   * 고객 분노 사전 차단용 1초 정중 선제 안심 안내문 템플릿 생성
   * 「전자상거래법」 제15조 제1항(지연 통지 의무) 준수
   * @param {Object} order 주문 데이터
   * @param {Object} stagData 평가 데이터
   * @returns {string} 문자 텍스트
   */
  generateCustomerProactiveNotice(order = {}, stagData = {}) {
    order = (order && typeof order === "object") ? order : {};
    stagData = (stagData && typeof stagData === "object") ? stagData : {};
    const config = this.getConfig();
    const evalData = stagData.elapsedHours !== undefined ? stagData : this.evaluateHubStagnation(order);
    const customerName = order.customerName || "고객";
    const productName = order.productName || "주문 상품";
    const storeName = config.storeName || "스토어";
    const csPhone = config.sellerPhone || "1544-0000";

    return `[${storeName}] 배송 지연 사전 양해 및 안심 배송 진행 안내

안녕하세요, ${customerName}님.
${storeName}에서 주문해 주신 '${productName}' 배송 관련하여 소중한 고객님께 선제적으로 안내 말씀드립니다.

현재 고객님의 상품은 정상 출고되어 [${evalData.carrierName}] ${evalData.currentHubName}에서 안전하게 이동 중입니다.
다만, 최근 택배사 간선 허브 터미널의 택배 물동량 일시 집중으로 인해 분류 작업이 평소보다 약 1~2일 지연되고 있는 것으로 확인되었습니다.

• 택배사/운송장: [${evalData.carrierName}] ${evalData.trackingNumber}
• 현재 위치: ${evalData.currentHubName} (정상 분류 대기 중)
• 예상 수령일: 1~2 영업일 이내 순차 배송 완료 예정

상품이 분실되거나 누락된 것이 아니며, 안전하게 배송될 수 있도록 택배사 터미널에 긴급 출고 협조를 정식 요청해 둔 상태입니다.
기다려 주시는 마음에 깊이 감사드리며, 최대한 신속하고 안전하게 전달해 드릴 수 있도록 끝까지 책임지고 확인하겠습니다.

- 배송/주문 문의: ${storeName} 고객감동센터 (${csPhone})`;
  }

  /**
   * 텔레그램 / 슬랙 긴급 알림 메시지 포맷터
   * @param {Object} order 주문 데이터
   * @param {Object} evalData 평가 데이터
   * @returns {string}
   */
  formatStagnationAlertBlock(order = {}, evalData = {}) {
    order = (order && typeof order === "object") ? order : {};
    evalData = (evalData && typeof evalData === "object") ? evalData : {};
    const stag = evalData.elapsedHours !== undefined ? evalData : this.evaluateHubStagnation(order);
    const riskBadge = stag.isCritical ? "🚨 [초긴급 48h 정체 - 즉시 독촉 요망]" : (stag.isStagnant ? "⚠️ [24h 정체 주의]" : "🚚 [정상 운송 중]");
    const hubEntryTimeStr = String(stag.hubEntryTime || new Date().toISOString());

    return `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${riskBadge} 택배사 허브 멈춤(Hub Stagnation) 긴급 감별
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• 주문번호: ${order.orderId || "미지정"}
• 고객명: ${order.customerName || "고객"}
• 상품명: ${order.productName || "주문 상품"}
• 운송장번호: [${stag.carrierName || "택배사"}] ${stag.trackingNumber || "미등록"}
• 멈춤 발생 위치: 📍 ${stag.currentHubName || "메가간선HUB"}
---------------------------------------------------------
• 허브 입고 시각: ${hubEntryTimeStr.slice(0, 19).replace("T", " ")}
• 허브 체류 시간: ⏰ ${stag.elapsedHours || 0}시간 (${stag.elapsedDays || 0}일간 멈춤)
• 위험도 판정: ${stag.riskLevel || "NORMAL_TRANSIT"}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 고객이 배송 지연으로 항의하기 전에 선제적 안심 문자를 1초 발송하고,
택배사 허브 (${stag.carrierPhone || "1588-0000"})에 '화물 긴급 출고 요청 공문'을 즉시 전송하십시오.`;
  }

  /**
   * 택배사 허브 지점장 제출용 정식 화물 긴급 출고/수색 요청 공문서 HTML 렌더링
   * Pure White Clean Enterprise 라이트 모드 및 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건)
   * @param {Object} order 주문 데이터
   * @param {Object} evalData 평가 데이터
   * @returns {string} HTML
   */
  generateHubUrgentDispatchEvidenceHtml(order = {}, evalData = {}) {
    order = (order && typeof order === "object") ? order : {};
    evalData = (evalData && typeof evalData === "object") ? evalData : {};
    const config = this.getConfig();
    const stag = evalData.elapsedHours !== undefined ? evalData : this.evaluateHubStagnation(order);
    const currentDate = new Date().toISOString().slice(0, 10);
    const entryDate = String(stag.hubEntryTime || currentDate).slice(0, 10);

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>간선 허브 체류화물 긴급 출고 및 수색 협조 요청서</title>
  <style>
    @page { size: A4; margin: 20mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo", "Malgun Gothic", "Pretendard", sans-serif;
      background-color: #ffffff;
      color: #0f172a;
      line-height: 1.6;
      margin: 0;
      padding: 30px;
    }
    .official-doc {
      max-width: 800px;
      margin: 0 auto;
      border: 1px solid #cbd5e1;
      padding: 40px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    }
    .doc-header {
      text-align: center;
      border-bottom: 2px solid #0f172a;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    .doc-title {
      font-size: 24px;
      font-weight: 800;
      letter-spacing: -0.5px;
      margin: 0 0 10px 0;
      color: #0f172a;
    }
    .doc-subtitle {
      font-size: 13px;
      color: #475569;
      margin: 0;
    }
    .meta-box {
      display: flex;
      justify-content: space-between;
      margin-bottom: 25px;
      font-size: 13px;
    }
    .meta-col {
      flex: 1;
    }
    .section-title {
      font-size: 14px;
      font-weight: 700;
      color: #0f172a;
      border-left: 4px solid #0284c7;
      padding-left: 8px;
      margin: 25px 0 10px 0;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 12px;
    }
    th, td {
      border: 1px solid #cbd5e1;
      padding: 10px 12px;
      text-align: left;
    }
    th {
      background-color: #f8fafc;
      font-weight: 600;
      color: #334155;
      width: 25%;
    }
    .highlight-box {
      background-color: #f0f9ff;
      border: 1px solid #bae6fd;
      border-radius: 6px;
      padding: 15px;
      margin: 20px 0;
      font-size: 12px;
      color: #0369a1;
      line-height: 1.7;
    }
    .warning-box {
      background-color: #fef2f2;
      border: 1px solid #fecaca;
      border-radius: 6px;
      padding: 15px;
      margin: 20px 0;
      font-size: 12px;
      color: #991b1b;
      line-height: 1.7;
    }
    .doc-footer {
      margin-top: 40px;
      text-align: center;
      border-top: 1px solid #e2e8f0;
      padding-top: 25px;
      font-size: 13px;
      color: #334155;
    }
    .signature-area {
      margin: 20px 0;
      font-size: 15px;
      font-weight: 700;
      color: #0f172a;
    }
    .system-badge {
      font-size: 11px;
      color: #94a3b8;
      margin-top: 15px;
    }
    @media print {
      body { padding: 0; }
      .official-doc { border: none; box-shadow: none; padding: 0; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="max-width: 800px; margin: 0 auto 15px auto; display: flex; justify-content: flex-end; gap: 10px;">
    <button onclick="window.print()" style="padding: 8px 16px; background: #0f172a; color: #fff; border: none; border-radius: 4px; font-weight: 600; cursor: pointer;">🖨️ 공문서 인쇄 / PDF 저장</button>
  </div>

  <div class="official-doc">
    <div class="doc-header">
      <h1 class="doc-title">간선 허브 체류화물 긴급 출고 및 수색 협조 요청서</h1>
      <p class="doc-subtitle">공정거래위원회 승인 택배 표준약관 제20조 및 상법 준용 간선 잔류 화물 독촉 공문</p>
    </div>

    <div class="meta-box">
      <div class="meta-col">
        <strong>수 신:</strong> ${stag.carrierName} ${stag.currentHubName} 관리지점장 및 간선운송팀장 귀하<br>
        <strong>발 신:</strong> ${config.storeName} (${config.sellerName})<br>
        <strong>문서번호:</strong> HUB-REQ-${String(order.orderId || "STG").replace(/[^a-zA-Z0-9]/g, "").slice(-8)}-${Date.now().toString().slice(-4)}
      </div>
      <div class="meta-col" style="text-align: right;">
        <strong>발송일자:</strong> ${currentDate}<br>
        <strong>지연상태:</strong> 허브 체류 ${stag.elapsedHours}시간 경과 (${stag.riskLevel})<br>
        <strong>요청구분:</strong> 최우선 잔류 화물 수색 및 하차 배차 지정
      </div>
    </div>

    <div class="section-title">1. 대상 운송물 및 허브 멈춤 세부 내역</div>
    <table>
      <tr>
        <th>운송장 번호</th>
        <td><strong>${stag.trackingNumber}</strong></td>
        <th>택배사 / 담당</th>
        <td>${stag.carrierName} (${stag.carrierPhone})</td>
      </tr>
      <tr>
        <th>정체 허브 터미널</th>
        <td><strong style="color: #dc2626;">${stag.currentHubName}</strong></td>
        <th>허브 입고 일시</th>
        <td>${entryDate}</td>
      </tr>
      <tr>
        <th>정체 경과 시간</th>
        <td colspan="3"><strong style="color: #dc2626;">${stag.elapsedHours} 시간 체류 중</strong> (${stag.elapsedDays} 일간 이동 없음)</td>
      </tr>
      <tr>
        <th>주문 번호</th>
        <td>${order.orderId || "미지정"}</td>
        <th>수령인 정보</th>
        <td>${order.customerName || "고객"} (${order.customerPhone || "010-****-****"})</td>
      </tr>
      <tr>
        <th>운송물 명칭</th>
        <td colspan="3">${order.productName || "주문 상품"} (수량: ${order.quantity || 1}개)</td>
      </tr>
    </table>

    <div class="highlight-box">
      <strong>[긴급 출고 요청 사유 및 현황]</strong><br>
      위 화물은 정상 집하되어 귀사의 ${stag.currentHubName}에 입고되었으나, ${stag.elapsedHours}시간이 경과한 현재까지 다음 배송지점으로의 간선 출고(하차/배차)가 이루어지지 않고 전산상 이동이 완전히 멈춰 있는 상태입니다. 구매자의 배송 지연 항의가 심각하여 배송 사고(분실 또는 파손)가 우려되오니, 해당 허브 터미널 내 잔류 화물 보관 구역을 즉시 수색하시고 금일 야간 간선 차량에 최우선 적재하여 관할 배송영업소로 출고 조치해 주시기 바랍니다.
    </div>

    <div class="warning-box">
      <strong>[운송인의 배송지연 책임 및 배상 청구 예고]</strong><br>
      공정거래위원회 택배 표준약관 제20조(손해배상)에 따라 운송물의 인도가 약정 기일을 초과하여 지연된 경우 운송인은 지연일수에 따른 손해를 배상할 책임이 있습니다. 또한 본 화물이 장기 정체로 인하여 수하인의 수령 거부나 주문 취소(반품)로 이어질 경우, 귀사의 배송지연 책임에 따른 왕복 운임 및 판매 대금 실손해 전액에 대해 구상권을 청구할 수 있음을 사전 통지합니다.
    </div>

    <div class="section-title">2. 택배사 처리 협조 요청 사항</div>
    <table>
      <tr>
        <th style="width: 30%;">1. 화물 실물 수색</th>
        <td>${stag.currentHubName} 내 미분류 롤테이너 및 잔류 화물 구역 실물 바코드 스캔 확인</td>
      </tr>
      <tr>
        <th>2. 파손/오도착 점검</th>
        <td>운송장 바코드 훼손 또는 오분류 여부 점검 및 재부착 조치</td>
      </tr>
      <tr>
        <th>3. 최우선 간선 출고</th>
        <td>금일 중 목적지 영업소(최종 배송지점)행 간선차량 최우선 배차 및 상차</td>
      </tr>
    </table>

    <div class="doc-footer">
      <div class="signature-area">
        ${currentDate}<br><br>
        청구인(송하인): ${config.storeName} (${config.sellerName}) (인쇄 시 직인 생략)
      </div>
      <div style="font-size: 12px; color: #64748b;">
        연락처: ${config.sellerPhone} | 주소: ${config.sellerAddress} | 이메일: ${config.sellerEmail}
      </div>
      <div class="system-badge">
        발급 시스템: AutoFlow Enterprise Hub Stagnation & Delayed Delivery Shield v2.0 (인쇄 시 직인 생략)
      </div>
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * 허브 정체 주문 목록을 영속화 파일에 기록
   * @param {Array} orders 주문 목록
   */
  recordStagnationOrders(orders = []) {
    if (orders && !Array.isArray(orders) && Array.isArray(orders.orders)) {
      orders = orders.orders;
    }
    if (!Array.isArray(orders) || orders.length === 0) return { recorded: 0 };
    try {
      this.ensureStorage();
      let data = { orders: [] };
      if (fs.existsSync(this.storagePath)) {
        try {
          const parsed = JSON.parse(fs.readFileSync(this.storagePath, "utf8"));
          if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
            data = parsed;
          }
        } catch (e) {}
      }
      data.orders = Array.isArray(data.orders) ? data.orders.filter(x => x && typeof x === "object") : [];

      let count = 0;
      for (const item of orders) {
        if (!item || typeof item !== "object") continue;
        const orderId = String(item.orderId || Date.now());
        const existingIdx = data.orders.findIndex(o => String(o.orderId) === orderId);

        const evalData = this.evaluateHubStagnation(item);

        const record = {
          orderId,
          trackingNumber: evalData.trackingNumber,
          carrierCode: evalData.carrierCode,
          carrierName: evalData.carrierName,
          carrierPhone: evalData.carrierPhone,
          currentHubName: evalData.currentHubName,
          customerName: item.customerName || "고객",
          customerPhone: item.customerPhone || "",
          productName: item.productName || "주문 상품",
          status: item.status || (evalData.isCritical ? "CRITICAL_DELAY" : "HUB_STAGNANT"),
          elapsedHours: evalData.elapsedHours,
          elapsedDays: evalData.elapsedDays,
          riskLevel: evalData.riskLevel,
          isStagnant: evalData.isStagnant,
          isCritical: evalData.isCritical,
          hubEntryAt: evalData.hubEntryTime,
          recordedAt: item.recordedAt || new Date().toISOString(),
          resolvedAt: item.resolvedAt || null
        };

        if (existingIdx >= 0) {
          data.orders[existingIdx] = Object.assign({}, data.orders[existingIdx], record);
        } else {
          data.orders.unshift(record);
        }
        count++;
      }

      data.updatedAt = new Date().toISOString();
      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { recorded: count };
    } catch (e) {
      return { recorded: 0, error: e.message };
    }
  }

  /**
   * 허브 정체 주문 상태 전이 (배송 재개 / 완료 / 환불 종결)
   * @param {string} orderId 주문번호
   * @param {string} action 상태 (`DELIVERY_RESUMED`, `COMPLETED`, `CANCELLED_REFUNDED`)
   * @param {Object} options 추가 옵션
   */
  resolveStagnationOrder(orderId, action = "DELIVERY_RESUMED", options = {}) {
    if (orderId && typeof orderId === "object") {
      action = orderId.action || action;
      options = orderId.options || orderId;
      orderId = orderId.orderId || "";
    }
    action = action || "DELIVERY_RESUMED";
    options = (options && typeof options === "object") ? options : {};
    try {
      this.ensureStorage();
      if (!fs.existsSync(this.storagePath)) return { success: false, error: "File not found" };

      const parsed = JSON.parse(fs.readFileSync(this.storagePath, "utf8"));
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : { orders: [] };
      data.orders = Array.isArray(data.orders) ? data.orders.filter(x => x && typeof x === "object") : [];
      const target = data.orders.find(o => String(o.orderId) === String(orderId ?? ""));

      if (!target) {
        return { success: false, error: `Order ID ${orderId || "N/A"} not found` };
      }

      target.status = action;
      target.resolvedAt = new Date().toISOString();
      target.resolutionNote = options.note || (action === "DELIVERY_RESUMED" ? "택배사 간선 이동 재개 확인" : action);

      data.updatedAt = new Date().toISOString();
      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { success: true, updated: target };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  /**
   * 허브 정체 요약 통계 조회
   * @returns {Object}
   */
  getStagnationSummary() {
    try {
      this.ensureStorage();
      if (!fs.existsSync(this.storagePath)) {
        return { totalOrders: 0, stagnant24hCount: 0, critical48hCount: 0, resolvedCount: 0, recentOrders: [] };
      }

      const parsed = JSON.parse(fs.readFileSync(this.storagePath, "utf8"));
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : { orders: [] };
      const orders = Array.isArray(data.orders) ? data.orders.filter(x => x && typeof x === "object") : [];

      let stagnant24hCount = 0;
      let critical48hCount = 0;
      let resolvedCount = 0;

      for (const item of orders) {
        if (item.status === "DELIVERY_RESUMED" || item.status === "COMPLETED" || item.status === "CANCELLED_REFUNDED") {
          resolvedCount++;
        } else {
          if (item.riskLevel === "CRITICAL_DELAY_48H" || item.isCritical) {
            critical48hCount++;
          } else if (item.riskLevel === "HUB_STAGNANT_24H" || item.isStagnant) {
            stagnant24hCount++;
          }
        }
      }

      return {
        totalOrders: orders.length,
        stagnant24hCount,
        critical48hCount,
        resolvedCount,
        recentOrders: orders.slice(0, 50)
      };
    } catch (e) {
      return { totalOrders: 0, stagnant24hCount: 0, critical48hCount: 0, resolvedCount: 0, recentOrders: [] };
    }
  }
}

module.exports = {
  HubStagnationSentinel,
  createHubStagnationSentinel: (options = {}) => new HubStagnationSentinel((options && typeof options === "object") ? options : {})
};
