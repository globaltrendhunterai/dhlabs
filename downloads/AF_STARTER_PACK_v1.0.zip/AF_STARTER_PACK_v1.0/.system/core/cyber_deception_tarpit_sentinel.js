/**
 * core/cyber_deception_tarpit_sentinel.js
 * AutoFlow Resident Defense Engine — 4-Stage Cyber Deception, Polymorphic Canary Honeytokens,
 * Tarpit Labyrinth & Lawful Forensic Beacon Sentinel
 *
 * [4-Stage Cyber Deception Architecture]
 * - Stage 1 (Tarpit Labyrinth & Drip Streamer):
 *   Instead of returning tip-off error messages (401/403 INVALID_KEY) when a leaked/cracked canary
 *   token or honeypot endpoint is used, returns HTTP 200 with a convincing 12-step verification
 *   labyrinth (`status: 'TARPIT_LABYRINTH_IN_PROGRESS'`, `real_engine_unlocked: false`) and applies
 *   artificial tarpit latency (`tarpit_delay_applied_ms`) to stall automated cracking tools.
 * - Stage 2 (0% False-Positive Active Trigger Detection):
 *   Antivirus, Windows Defender, or macOS Spotlight passively reading files on disk NEVER triggers
 *   a lock. A lock is triggered ONLY when a caller actively submits a Canary Honeytoken
 *   (`AF-TKT-CANARY-...`, `AF-MASTER-BYPASS-...`) or invokes a decoy Honeypot API route.
 *   Normal license keys and valid `AF-TKT-v1` tickets return `{ triggered: false }` in <0.1ms.
 * - Stage 3 (Polymorphic Moving Target Defense):
 *   Seeded deterministically by `SHA-256(hwid + rotationSalt)`, each installation generates between
 *   3 and 7 decoy files from a pool of 12+ realistic bait filenames, with shifted comment padding
 *   line offsets and unique per-machine Canary Honeytoken signatures.
 * - Stage 4 (100% Lawful Forensic Beacon Callback & Persistent HWID Quarantine):
 *   Strictly complies with 정보통신망법 제48조 (Zero Hack-Back, Zero File Deletion on user PC).
 *   Records self-incriminating intrusion telemetry into `logs/deception_forensic_ledger.jsonl`
 *   with HMAC-SHA256 integrity seal, and persists HWID quarantine in both
 *   `data/deception_hwid_blacklist.json` and global machine identity (`~/.autoflow/machine_identity.json`).
 */

'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const ROOT_DIR = path.resolve(__dirname, '..');

const CANARY_HMAC_SECRET =
  process.env.AUTOFLOW_CANARY_HMAC_SECRET || 'AF-CYBER-DECEPTION-CANARY-HMAC-2026-V1';
const FORENSIC_LEDGER_HMAC_SECRET =
  process.env.AUTOFLOW_FORENSIC_HMAC_SECRET || 'AF-LAWFUL-FORENSIC-BEACON-HMAC-2026-V1';

const DECOY_BAIT_FILENAME_POOL = Object.freeze([
  '_master_license_bypass.key',
  'offline_unlimited_seed.json',
  'admin_override_token.env',
  '_dev_master_override.json',
  'license_unlock_seed.dat',
  'af_unlimited_root.key',
  'internal_qa_backdoor_ticket.json',
  'oem_enterprise_master_key.pem',
  'bypass_governor_limit_config.json',
  'root_signing_recovery_seed.txt',
  'debug_free_pass_manifest.json',
  'cracked_hwid_whitelist.json'
]);

const DECOY_HONEYPOT_ENDPOINTS = Object.freeze([
  '/api/license/internal-dev-unlock',
  '/api/license/master-override',
  '/api/debug/bypass-governor'
]);

const LAWFUL_COMPLIANCE_MODE = 'INFO_COMM_ACT_ART48_COMPLIANT';

function ensureDirectory(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function getHwid(options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  if (typeof safeOpts.hwid === 'string' && safeOpts.hwid.trim().length > 0) {
    return safeOpts.hwid.trim();
  }
  if (typeof process.env.AUTOFLOW_HWID_OVERRIDE === 'string' && process.env.AUTOFLOW_HWID_OVERRIDE.trim().length > 0) {
    return process.env.AUTOFLOW_HWID_OVERRIDE.trim();
  }
  try {
    const ifaces = os.networkInterfaces();
    const macs = [];
    for (const name of Object.keys(ifaces)) {
      for (const iface of ifaces[name] || []) {
        if (iface && !iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
          macs.push(iface.mac);
        }
      }
    }
    macs.sort();
    const seed = [os.hostname(), os.platform(), os.arch(), macs.join(':') || 'LOCAL_DEVICE_SEED'].join('|');
    const hash = crypto.createHash('sha256').update(seed).digest('hex').substring(0, 16).toUpperCase();
    return `AF-HWID-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`;
  } catch (_) {
    return 'AF-HWID-LOCAL-DEV-0001';
  }
}

function deriveHwidShort(hwid) {
  const cleaned = String(hwid || 'LOCAL').replace(/^AF-HWID-/i, '').replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
  const hashSuffix = crypto.createHash('sha256').update(String(hwid || 'LOCAL')).digest('hex').slice(0, 6).toUpperCase();
  const prefix = cleaned.slice(0, 6) || 'DEVICE';
  return `${prefix}${hashSuffix}`;
}

function resolveCanaryVaultDir(options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  const customDir = safeOpts.vaultDir || safeOpts.canaryDir || safeOpts.canaryVaultDir || safeOpts.vault_dir;
  if (typeof customDir === 'string' && customDir.trim().length > 0) {
    return customDir.trim();
  }
  if (typeof process.env.AUTOFLOW_CANARY_VAULT_DIR === 'string' && process.env.AUTOFLOW_CANARY_VAULT_DIR.trim().length > 0) {
    return process.env.AUTOFLOW_CANARY_VAULT_DIR.trim();
  }
  return path.join(ROOT_DIR, 'data', '.canary_vault');
}

function resolveForensicLogPath(options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  if (typeof safeOpts.forensicLogPath === 'string' && safeOpts.forensicLogPath.trim().length > 0) {
    return safeOpts.forensicLogPath.trim();
  }
  if (typeof process.env.AUTOFLOW_DECEPTION_FORENSIC_LOG_PATH === 'string' && process.env.AUTOFLOW_DECEPTION_FORENSIC_LOG_PATH.trim().length > 0) {
    return process.env.AUTOFLOW_DECEPTION_FORENSIC_LOG_PATH.trim();
  }
  return path.join(ROOT_DIR, 'logs', 'deception_forensic_ledger.jsonl');
}

function resolveBlacklistPath(options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  if (typeof safeOpts.blacklistPath === 'string' && safeOpts.blacklistPath.trim().length > 0) {
    return safeOpts.blacklistPath.trim();
  }
  if (typeof process.env.AUTOFLOW_DECEPTION_BLACKLIST_PATH === 'string' && process.env.AUTOFLOW_DECEPTION_BLACKLIST_PATH.trim().length > 0) {
    return process.env.AUTOFLOW_DECEPTION_BLACKLIST_PATH.trim();
  }
  return path.join(ROOT_DIR, 'data', 'deception_hwid_blacklist.json');
}

function resolveGlobalIdentityPath(options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  if (typeof safeOpts.globalIdentityPath === 'string' && safeOpts.globalIdentityPath.trim().length > 0) {
    return safeOpts.globalIdentityPath.trim();
  }
  if (typeof process.env.AUTOFLOW_GLOBAL_IDENTITY_PATH === 'string' && process.env.AUTOFLOW_GLOBAL_IDENTITY_PATH.trim().length > 0) {
    return process.env.AUTOFLOW_GLOBAL_IDENTITY_PATH.trim();
  }
  return path.join(os.homedir(), '.autoflow', 'machine_identity.json');
}

/**
 * Pure deterministic specification builder for Stage 1 & Stage 3 Polymorphic Canaries
 */
function computeDeterministicCanarySpec(options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  const hwid = getHwid(safeOpts);
  const rotationSalt = String(
    safeOpts.rotationSalt || safeOpts.salt || process.env.AUTOFLOW_CANARY_ROTATION_SALT || 'v1'
  ).trim();
  const hwidShort = deriveHwidShort(hwid);

  const seedBuf = crypto.createHash('sha256').update(`${hwid}::${rotationSalt}`).digest();
  // Deterministic count in [3, 7] (5 possible values: 3, 4, 5, 6, 7)
  const decoyCount = 3 + (seedBuf.readUInt32BE(0) % 5);

  // Deterministic Fisher-Yates shuffle of DECOY_BAIT_FILENAME_POOL using seed bytes
  const pool = [...DECOY_BAIT_FILENAME_POOL];
  for (let i = pool.length - 1; i > 0; i--) {
    const stepHash = crypto
      .createHash('sha256')
      .update(`${hwid}::${rotationSalt}::shuffle::${i}`)
      .digest();
    const j = stepHash.readUInt32BE(0) % (i + 1);
    const tmp = pool[i];
    pool[i] = pool[j];
    pool[j] = tmp;
  }

  const selectedFilenames = pool.slice(0, decoyCount);
  const files = selectedFilenames.map((filename, idx) => {
    const itemDigest = crypto
      .createHash('sha256')
      .update(`${hwid}::${rotationSalt}::file::${idx}::${filename}`)
      .digest();
    const sig = crypto
      .createHmac('sha256', CANARY_HMAC_SECRET)
      .update(`${hwidShort}:${idx}:${rotationSalt}:${filename}`)
      .digest('hex')
      .slice(0, 12)
      .toUpperCase();

    const canaryTokenId = `CANARY-${hwidShort}-${idx}`;
    const canaryTicket = `AF-TKT-CANARY-${hwidShort}-${idx}-${sig}`;
    const canaryMasterKey = `AF-MASTER-BYPASS-${hwidShort}-${idx}`;
    const decoyEndpoint = DECOY_HONEYPOT_ENDPOINTS[itemDigest[0] % DECOY_HONEYPOT_ENDPOINTS.length];
    // Polymorphic padding offset between 2 and 19 lines so secret line position shifts per HWID & per file
    const secretLineOffset = 2 + (itemDigest.readUInt16BE(2) % 18);

    return {
      index: idx,
      filename,
      canary_token_id: canaryTokenId,
      canary_ticket: canaryTicket,
      canary_master_key: canaryMasterKey,
      decoy_endpoint: decoyEndpoint,
      secret_line_offset: secretLineOffset,
      secret_line_number: secretLineOffset + 1
    };
  });

  return {
    hwid,
    hwid_short: hwidShort,
    rotation_salt: rotationSalt,
    decoy_count: decoyCount,
    files
  };
}

const _manifestCacheByPath = new Map();

function renderDecoyFileContent(fileSpec, hwid, rotationSalt) {
  const paddingLines = [];
  for (let i = 0; i < fileSpec.secret_line_offset; i++) {
    const padHash = crypto
      .createHash('md5')
      .update(`${hwid}:${rotationSalt}:${fileSpec.filename}:pad:${i}`)
      .digest('hex')
      .slice(0, 16);
    paddingLines.push(`# [INTERNAL-ENTITLEMENT-SHARD-${i + 1}] CHECKSUM_GUARD=${padHash} DO_NOT_DISTRIBUTE`);
  }

  const ext = path.extname(fileSpec.filename).toLowerCase();
  if (ext === '.json') {
    const payloadObj = {
      _comment_padding: paddingLines,
      internal_notice: 'CONFIDENTIAL_OFFLINE_MASTER_UNLOCK_SEED',
      canary_token_id: fileSpec.canary_token_id,
      master_override_ticket: fileSpec.canary_ticket,
      master_bypass_key: fileSpec.canary_master_key,
      internal_unlock_endpoint: fileSpec.decoy_endpoint,
      governor_rate_limit_bypass: true,
      unlimited_offline_days: 9999
    };
    return `${JSON.stringify(payloadObj, null, 2)}\n`;
  }

  const secretLine = `AUTOFLOW_MASTER_UNLOCK_TICKET="${fileSpec.canary_ticket}" MASTER_KEY="${fileSpec.canary_master_key}" ENDPOINT="${fileSpec.decoy_endpoint}" TOKEN_ID="${fileSpec.canary_token_id}"`;
  const footerLine = `# [END-SHARD] TARGET_ROUTE=${fileSpec.decoy_endpoint}`;
  return [...paddingLines, secretLine, footerLine, ''].join('\n');
}

/**
 * Stage 1 & 3: Polymorphic Canary Honeytoken Generator
 */
function deployPolymorphicCanaries(options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  const canaryDir = resolveCanaryVaultDir(safeOpts);
  ensureDirectory(canaryDir);

  const spec = computeDeterministicCanarySpec(safeOpts);

  // Clean previous bait files in canaryDir unless explicitly disabled
  if (safeOpts.cleanExisting !== false && fs.existsSync(canaryDir)) {
    for (const existing of fs.readdirSync(canaryDir)) {
      if (DECOY_BAIT_FILENAME_POOL.includes(existing) || existing === '.canary_manifest.json') {
        try {
          fs.unlinkSync(path.join(canaryDir, existing));
        } catch (_) {}
      }
    }
  }

  const deployedFiles = [];
  for (const fileSpec of spec.files) {
    const fullPath = path.join(canaryDir, fileSpec.filename);
    const content = renderDecoyFileContent(fileSpec, spec.hwid, spec.rotation_salt);
    fs.writeFileSync(fullPath, content, 'utf8');
    const fileSha256 = crypto.createHash('sha256').update(content).digest('hex');
    const lines = content.split('\n');
    const actualTicketLineNumber =
      lines.findIndex((l) => l.includes(fileSpec.canary_ticket)) + 1;

    const resolvedLine = actualTicketLineNumber > 0 ? actualTicketLineNumber : fileSpec.secret_line_number;
    deployedFiles.push({
      ...fileSpec,
      path: fullPath,
      file_path: fullPath,
      secret_line_number: resolvedLine,
      token_line_offset: resolvedLine,
      sha256: fileSha256
    });
  }

  const manifest = {
    schema_version: '1.0',
    deployed_at: new Date().toISOString(),
    hwid: spec.hwid,
    hwid_short: spec.hwid_short,
    rotation_salt: spec.rotation_salt,
    canary_dir: canaryDir,
    decoy_count: deployedFiles.length,
    deployed_count: deployedFiles.length,
    files: deployedFiles
  };

  const manifestPath = path.join(canaryDir, '.canary_manifest.json');
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2), 'utf8');
  _manifestCacheByPath.set(manifestPath, manifest);

  return {
    ok: true,
    status: 'POLYMORPHIC_CANARIES_DEPLOYED',
    hwid: spec.hwid,
    hwid_short: spec.hwid_short,
    rotation_salt: spec.rotation_salt,
    canary_dir: canaryDir,
    decoy_count: deployedFiles.length,
    deployed_count: deployedFiles.length,
    filenames: deployedFiles.map((f) => f.filename),
    files: deployedFiles,
    manifest_path: manifestPath
  };
}

/**
 * Stage 2: Zero-False-Positive Active Trigger Detection
 * - Reading decoy files on disk NEVER triggers this function.
 * - Valid AF-TKT-v1.* tickets and normal license keys return { triggered: false } in <0.1ms.
 */
function inspectForCanaryTrigger(candidateInput, context = {}, options = {}) {
  const startHr = process.hrtime.bigint();
  const safeCtx = context && typeof context === 'object' ? context : {};
  const safeOpts = options && typeof options === 'object' ? options : {};

  const elapsedMs = () => Number(process.hrtime.bigint() - startHr) / 1e6;

  // 1. Check if context route is a decoy Honeypot API endpoint
  const routeCandidate = String(safeCtx.route || safeCtx.endpoint || safeCtx.pathname || '').trim();
  if (routeCandidate && DECOY_HONEYPOT_ENDPOINTS.includes(routeCandidate)) {
    return {
      triggered: true,
      false_positive_risk: 0,
      trigger_vector: 'DECOY_HONEYPOT_ENDPOINT',
      trigger_type: 'DECOY_HONEYPOT_ENDPOINT',
      canary_token_id: `CANARY-ROUTE-${routeCandidate.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()}`,
      matched_token: routeCandidate,
      decoy_file_or_route: routeCandidate,
      hwid: safeCtx.hwid || getHwid(safeOpts),
      evaluation_time_ms: elapsedMs()
    };
  }

  if (candidateInput === null || candidateInput === undefined) {
    return { triggered: false, false_positive_risk: 0, evaluation_time_ms: elapsedMs() };
  }

  // Extract string candidates without expensive work on normal inputs
  const rawStrings = [];
  if (typeof candidateInput === 'string') {
    rawStrings.push(candidateInput.trim());
  } else if (typeof candidateInput === 'object' && !Array.isArray(candidateInput)) {
    for (const k of [
      'ticket',
      'license_key',
      'licenseKey',
      'token',
      'master_key',
      'masterKey',
      'override_token',
      'canary_token_id',
      'seed',
      'key',
      'route'
    ]) {
      if (typeof candidateInput[k] === 'string' && candidateInput[k].trim().length > 0) {
        rawStrings.push(candidateInput[k].trim());
      }
    }
  }

  if (rawStrings.length === 0) {
    return { triggered: false, false_positive_risk: 0, evaluation_time_ms: elapsedMs() };
  }

  const nonTicketCandidates = [];
  for (const str of rawStrings) {
    // Fast-path: valid signed AF-TKT-v1 tickets are NEVER canary triggers
    if (str.startsWith('AF-TKT-v1.')) {
      continue;
    }

    if (DECOY_HONEYPOT_ENDPOINTS.includes(str)) {
      return {
        triggered: true,
        false_positive_risk: 0,
        trigger_vector: 'DECOY_HONEYPOT_ENDPOINT',
        trigger_type: 'DECOY_HONEYPOT_ENDPOINT',
        canary_token_id: `CANARY-ROUTE-${str.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()}`,
        matched_token: str,
        decoy_file_or_route: str,
        hwid: safeCtx.hwid || getHwid(safeOpts),
        evaluation_time_ms: elapsedMs()
      };
    }

    const canaryTicketMatch = str.match(/AF-TKT-CANARY-([A-Z0-9]+)-(\d+)-[A-Z0-9]+/i);
    if (canaryTicketMatch) {
      const hwidShort = canaryTicketMatch[1].toUpperCase();
      const idx = canaryTicketMatch[2];
      return {
        triggered: true,
        false_positive_risk: 0,
        trigger_vector: 'CANARY_HONEYTOKEN_TICKET',
        trigger_type: 'CANARY_HONEYTOKEN_TICKET',
        canary_token_id: `CANARY-${hwidShort}-${idx}`,
        matched_token: canaryTicketMatch[0],
        decoy_file_or_route: safeCtx.decoy_file || `DECOY_VAULT_SHARD_${idx}`,
        hwid: safeCtx.hwid || getHwid(safeOpts),
        evaluation_time_ms: elapsedMs()
      };
    }

    const masterBypassMatch = str.match(/AF-MASTER-BYPASS-([A-Z0-9]+)-(\d+)(?:-[A-Z0-9]+)?/i);
    if (masterBypassMatch) {
      const hwidShort = masterBypassMatch[1].toUpperCase();
      const idx = masterBypassMatch[2];
      return {
        triggered: true,
        false_positive_risk: 0,
        trigger_vector: 'CANARY_MASTER_BYPASS_KEY',
        trigger_type: 'CANARY_MASTER_BYPASS_KEY',
        canary_token_id: `CANARY-${hwidShort}-${idx}`,
        matched_token: masterBypassMatch[0],
        decoy_file_or_route: safeCtx.decoy_file || `DECOY_MASTER_KEY_${idx}`,
        hwid: safeCtx.hwid || getHwid(safeOpts),
        evaluation_time_ms: elapsedMs()
      };
    }

    const canaryIdMatch = str.match(/^(?:AF-)?CANARY-([A-Z0-9_-]+?)(?:-(\d+))?$/i);
    if (canaryIdMatch) {
      const hwidShort = canaryIdMatch[1].toUpperCase();
      const idx = canaryIdMatch[2] || '0';
      return {
        triggered: true,
        false_positive_risk: 0,
        trigger_vector: 'CANARY_TOKEN_ID_DIRECT',
        trigger_type: 'CANARY_TOKEN_ID_DIRECT',
        canary_token_id: `CANARY-${hwidShort}-${idx}`,
        matched_token: canaryIdMatch[0],
        decoy_file_or_route: safeCtx.decoy_file || `DECOY_TOKEN_${idx}`,
        hwid: safeCtx.hwid || getHwid(safeOpts),
        evaluation_time_ms: elapsedMs()
      };
    }

    nonTicketCandidates.push(str);
  }

  // Zero-I/O fast return if all inputs were valid AF-TKT-v1 tickets
  if (nonTicketCandidates.length === 0) {
    return {
      triggered: false,
      false_positive_risk: 0,
      evaluation_time_ms: elapsedMs()
    };
  }

  // Optional manifest lookup if custom tokens exist in .canary_manifest.json
  try {
    const canaryDir = resolveCanaryVaultDir(safeOpts);
    const manifestPath = path.join(canaryDir, '.canary_manifest.json');
    let manifest = _manifestCacheByPath.get(manifestPath) || null;
    if (!manifest && fs.existsSync(manifestPath)) {
      manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
      if (manifest) _manifestCacheByPath.set(manifestPath, manifest);
    }
    if (manifest && Array.isArray(manifest.files)) {
      for (const f of manifest.files) {
        for (const str of nonTicketCandidates) {
          if (
            str === f.canary_ticket ||
            str === f.canary_master_key ||
            str === f.canary_token_id
          ) {
            return {
              triggered: true,
              false_positive_risk: 0,
              trigger_vector: 'CANARY_MANIFEST_MATCH',
              trigger_type: 'CANARY_MANIFEST_MATCH',
              canary_token_id: f.canary_token_id,
              matched_token: str,
              decoy_file_or_route: f.filename,
              hwid: safeCtx.hwid || manifest.hwid || getHwid(safeOpts),
              evaluation_time_ms: elapsedMs()
            };
          }
        }
      }
    }
  } catch (_) {}

  return {
    triggered: false,
    false_positive_risk: 0,
    evaluation_time_ms: elapsedMs()
  };
}

/**
 * Stage 4: Lawful Forensic Beacon Callback & Persistent HWID Blacklist
 * - 100% Lawful Defense (정보통신망법 제48조 준수):
 *   Zero hack-back, zero file deletion on user PC.
 */
function recordForensicEvidenceAndLockHwid(triggerInfo = {}, options = {}) {
  const safeTrigger = triggerInfo && typeof triggerInfo === 'object' ? triggerInfo : {};
  const safeOpts = options && typeof options === 'object' ? options : {};

  const nowIso = new Date().toISOString();
  const hwid = String(safeTrigger.attacker_hwid || safeTrigger.hwid || safeOpts.hwid || getHwid(safeOpts)).trim();
  const clientIp = String(safeTrigger.client_ip || safeTrigger.clientIp || safeOpts.clientIp || '127.0.0.1').trim();
  const userAgent = String(
    safeTrigger.user_agent || safeTrigger.userAgent || safeOpts.userAgent || 'AutoFlow-Local-Runtime'
  ).trim();
  const canaryTokenId = String(
    safeTrigger.canary_token_id || safeTrigger.canaryTokenId || 'CANARY-UNSPECIFIED-0'
  ).trim();
  const decoyFileOrRoute = String(
    safeTrigger.decoy_file_or_route || safeTrigger.endpoint || safeTrigger.route || safeTrigger.decoyFile || 'UNKNOWN_DECOY'
  ).trim();
  const triggerVector = String(safeTrigger.trigger_vector || safeTrigger.trigger_type || 'CANARY_HONEYTOKEN_TRIGGER').trim();
  const incidentId = `INC-DECEPTION-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

  const beaconCallbackPayload = {
    beacon_version: '1.0',
    event: 'CYBER_DECEPTION_CANARY_TRIGGERED',
    incident_id: incidentId,
    triggered_at: nowIso,
    hwid,
    attacker_hwid: hwid,
    client_ip: clientIp,
    os_platform: os.platform(),
    os_release: os.release(),
    os_arch: os.arch(),
    hostname: os.hostname(),
    user_agent: userAgent,
    canary_token_id: canaryTokenId,
    decoy_file_or_route: decoyFileOrRoute,
    trigger_vector: triggerVector,
    lawful_compliance: LAWFUL_COMPLIANCE_MODE,
    legal_compliance: LAWFUL_COMPLIANCE_MODE,
    destructive_hack_back_executed: false,
    user_files_modified_or_deleted: 0
  };

  const canonicalForHmac = JSON.stringify({
    incident_id: incidentId,
    triggered_at: nowIso,
    hwid,
    client_ip: clientIp,
    os_platform: beaconCallbackPayload.os_platform,
    os_release: beaconCallbackPayload.os_release,
    os_arch: beaconCallbackPayload.os_arch,
    hostname: beaconCallbackPayload.hostname,
    canary_token_id: canaryTokenId,
    decoy_file_or_route: decoyFileOrRoute,
    trigger_vector: triggerVector
  });

  const forensicHmacSha256 = crypto
    .createHmac('sha256', FORENSIC_LEDGER_HMAC_SECRET)
    .update(canonicalForHmac)
    .digest('hex');

  const ledgerRecord = {
    incident_id: incidentId,
    triggered_at: nowIso,
    compliance_mode: LAWFUL_COMPLIANCE_MODE,
    legal_compliance: LAWFUL_COMPLIANCE_MODE,
    destructive_action_taken: false,
    hack_back_executed: false,
    attacker_files_deleted: false,
    hwid,
    attacker_hwid: hwid,
    client_ip: clientIp,
    os_platform: beaconCallbackPayload.os_platform,
    os_release: beaconCallbackPayload.os_release,
    os_arch: beaconCallbackPayload.os_arch,
    hostname: beaconCallbackPayload.hostname,
    user_agent: userAgent,
    canary_token_id: canaryTokenId,
    decoy_file_or_route: decoyFileOrRoute,
    trigger_vector: triggerVector,
    trigger_type: triggerVector,
    beacon_callback_payload: beaconCallbackPayload,
    forensic_hmac_sha256: forensicHmacSha256
  };

  // 1. Append to forensic ledger JSONL
  const forensicLogPath = resolveForensicLogPath(safeOpts);
  try {
    ensureDirectory(path.dirname(forensicLogPath));
    fs.appendFileSync(forensicLogPath, `${JSON.stringify(ledgerRecord)}\n`, 'utf8');
  } catch (_) {}

  // 2. Persist to local blacklist JSON
  const blacklistPath = resolveBlacklistPath(safeOpts);
  try {
    ensureDirectory(path.dirname(blacklistPath));
    let currentBlacklist = {
      schema_version: '1.0',
      deception_trap_triggered: false,
      locked_hwids: {}
    };
    if (fs.existsSync(blacklistPath)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(blacklistPath, 'utf8'));
        if (parsed && typeof parsed === 'object') {
          currentBlacklist = {
            ...currentBlacklist,
            ...parsed,
            locked_hwids: (parsed.locked_hwids && typeof parsed.locked_hwids === 'object') ? parsed.locked_hwids : {}
          };
        }
      } catch (_) {}
    }
    currentBlacklist.deception_trap_triggered = true;
    currentBlacklist.updated_at = nowIso;
    currentBlacklist.last_incident_id = incidentId;
    currentBlacklist.last_locked_hwid = hwid;
    currentBlacklist.locked_hwids[hwid] = {
      hwid,
      locked_at: nowIso,
      incident_id: incidentId,
      canary_token_id: canaryTokenId,
      decoy_file_or_route: decoyFileOrRoute,
      trigger_vector: triggerVector,
      status: 'DECEPTION_TARPIT_QUARANTINE'
    };
    fs.writeFileSync(blacklistPath, JSON.stringify(currentBlacklist, null, 2), 'utf8');
  } catch (_) {}

  // 3. Persist to global machine identity JSON (survives app folder deletion/reinstall)
  const globalIdentityPath = resolveGlobalIdentityPath(safeOpts);
  try {
    ensureDirectory(path.dirname(globalIdentityPath));
    let globalIdent = {};
    if (fs.existsSync(globalIdentityPath)) {
      try {
        globalIdent = JSON.parse(fs.readFileSync(globalIdentityPath, 'utf8')) || {};
      } catch (_) {}
    }
    const lockedMap = (globalIdent.locked_hwids && typeof globalIdent.locked_hwids === 'object')
      ? globalIdent.locked_hwids
      : {};
    lockedMap[hwid] = {
      hwid,
      locked_at: nowIso,
      incident_id: incidentId,
      canary_token_id: canaryTokenId,
      decoy_file_or_route: decoyFileOrRoute,
      status: 'DECEPTION_TARPIT_QUARANTINE'
    };
    const nextGlobalIdent = {
      ...globalIdent,
      hwid: globalIdent.hwid || hwid,
      deception_trap_triggered: true,
      status: 'DECEPTION_TARPIT_QUARANTINE',
      last_incident_id: incidentId,
      canary_token_id: canaryTokenId,
      updated_at: nowIso,
      locked_hwids: lockedMap
    };
    fs.writeFileSync(globalIdentityPath, JSON.stringify(nextGlobalIdent, null, 2), 'utf8');
  } catch (_) {}

  return ledgerRecord;
}

/**
 * Checks whether the given HWID (or current machine) is blacklisted/quarantined
 */
function isHwidBlacklisted(hwid = null, options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  const targetHwid = (typeof hwid === 'string' && hwid.trim().length > 0)
    ? hwid.trim()
    : getHwid(safeOpts);

  const checkFile = (filePath) => {
    if (!filePath || !fs.existsSync(filePath)) return false;
    try {
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      if (!parsed || typeof parsed !== 'object') return false;
      if (parsed.deception_trap_triggered === true) {
        if (!hwid || typeof hwid !== 'string') return true;
        if (parsed.locked_hwids && parsed.locked_hwids[targetHwid]) return true;
        if (parsed.hwid === targetHwid || parsed.last_locked_hwid === targetHwid) return true;
        // If machine-level trap is triggered on this node instance
        return true;
      }
      if (parsed.locked_hwids && parsed.locked_hwids[targetHwid]) {
        return true;
      }
    } catch (_) {}
    return false;
  };

  const blacklistPath = resolveBlacklistPath(safeOpts);
  if (checkFile(blacklistPath)) return true;

  const globalIdentityPath = resolveGlobalIdentityPath(safeOpts);
  if (checkFile(globalIdentityPath)) return true;

  return false;
}

/**
 * Clears deception lock for clean admin recovery / test reset
 */
function resetDeceptionLock(hwid = null, options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  const targetHwid = (typeof hwid === 'string' && hwid.trim().length > 0) ? hwid.trim() : null;
  const nowIso = new Date().toISOString();

  const clearInFile = (filePath) => {
    if (!filePath || !fs.existsSync(filePath)) return;
    try {
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8')) || {};
      if (targetHwid && parsed.locked_hwids && typeof parsed.locked_hwids === 'object') {
        delete parsed.locked_hwids[targetHwid];
      }
      const remainingKeys = parsed.locked_hwids ? Object.keys(parsed.locked_hwids) : [];
      if (!targetHwid || remainingKeys.length === 0 || safeOpts.resetAll !== false) {
        parsed.deception_trap_triggered = false;
        parsed.status = 'CLEAN_ACTIVE';
        parsed.locked_hwids = {};
      }
      parsed.reset_at = nowIso;
      fs.writeFileSync(filePath, JSON.stringify(parsed, null, 2), 'utf8');
    } catch (_) {}
  };

  const blacklistPath = resolveBlacklistPath(safeOpts);
  const globalIdentityPath = resolveGlobalIdentityPath(safeOpts);
  clearInFile(blacklistPath);
  clearInFile(globalIdentityPath);

  return {
    ok: true,
    success: true,
    status: 'DECEPTION_LOCK_RESET',
    hwid: targetHwid || getHwid(safeOpts),
    deception_trap_triggered: false,
    is_blacklisted: false,
    hwid_blacklisted: false,
    reset_at: nowIso
  };
}

/**
 * Stage 1: Build Deceptive Multi-Step Tarpit Labyrinth Response (HTTP 200 Body)
 */
function buildTarpitLabyrinthResponse(stepIndex = 1, triggerRecord = {}, options = {}) {
  const safeTrigger = triggerRecord && typeof triggerRecord === 'object' ? triggerRecord : {};
  const safeOpts = options && typeof options === 'object' ? options : {};
  const step = Math.max(1, Math.min(12, parseInt(String(stepIndex || 1), 10) || 1));
  const totalSteps = 12;
  const configuredDelayMs = Math.max(
    1,
    Number(safeOpts.tarpitDelayMs ?? parseInt(process.env.AUTOFLOW_TARPIT_DELAY_MS || '120', 10)) || 120
  );

  const tokenSeed = `${safeTrigger.hwid || 'HWID'}:${safeTrigger.incident_id || 'INC'}:${step}`;
  const nextVerificationToken = `TARPIT-STEP-${step + 1}-${crypto
    .createHash('sha256')
    .update(tokenSeed)
    .digest('hex')
    .slice(0, 12)
    .toUpperCase()}`;

  return {
    ok: false,
    success: false,
    activated: false,
    tarpit_deception: true,
    status: 'TARPIT_LABYRINTH_IN_PROGRESS',
    labyrinth_status: 'TARPIT_LABYRINTH_IN_PROGRESS',
    handshake_status: 'PENDING_CRYPTOGRAPHIC_HANDSHAKE',
    step,
    step_index: step,
    next_required_step: step + 1,
    total_steps: totalSteps,
    next_verification_token: nextVerificationToken,
    verification_challenge_nonce: nextVerificationToken,
    fake_progress_message: `Master Override Seed Accepted — Decrypting Entitlement Shard [Step ${step}/${totalSteps}]...`,
    real_engine_unlocked: false,
    governor_active: false,
    tarpit_delay_applied_ms: configuredDelayMs,
    tarpit_delay_ms: configuredDelayMs,
    incident_id: safeTrigger.incident_id || null,
    canary_token_id: safeTrigger.canary_token_id || null,
    lawful_compliance: LAWFUL_COMPLIANCE_MODE,
    legal_compliance: LAWFUL_COMPLIANCE_MODE,
    workflowAlwaysRuns: true
  };
}

let _activeTarpitSockets = 0;
const MAX_CONCURRENT_TARPIT_SOCKETS = 64;

/**
 * Stage 1: Execute Tarpit Artificial Delay & Optional HTTP 200 Drip Response
 */
function executeTarpitDelay(res, payload = {}, options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  const requestedDelayMs = Math.max(
    10,
    Number(safeOpts.tarpitDelayMs ?? parseInt(process.env.AUTOFLOW_TARPIT_DELAY_MS || '120', 10)) || 120
  );
  // Prevent socket descriptor exhaustion under high-concurrency flood attacks
  const delayMs = _activeTarpitSockets >= MAX_CONCURRENT_TARPIT_SOCKETS ? 10 : requestedDelayMs;
  const startMs = Date.now();
  _activeTarpitSockets++;

  return new Promise((resolve) => {
    let settled = false;
    let timer = null;

    const finish = () => {
      if (settled) return;
      settled = true;
      _activeTarpitSockets = Math.max(0, _activeTarpitSockets - 1);
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      const actualDelayMs = Math.max(delayMs, Date.now() - startMs);
      const finalPayload = {
        ...(payload && typeof payload === 'object' ? payload : {}),
        tarpit_deception: true,
        status: (payload && payload.status) || 'TARPIT_LABYRINTH_IN_PROGRESS',
        real_engine_unlocked: false,
        governor_active: false,
        tarpit_delay_applied_ms: actualDelayMs,
        tarpit_delay_ms: actualDelayMs
      };

      if (res && typeof res.writeHead === 'function' && typeof res.end === 'function' && !res.writableEnded && !res.destroyed) {
        try {
          res.writeHead(200, {
            'Content-Type': 'application/json; charset=utf-8',
            'X-AutoFlow-Tarpit-Labyrinth': `Step-${finalPayload.step || finalPayload.step_index || 1}-of-${finalPayload.total_steps || 12}`
          });
          res.end(JSON.stringify(finalPayload));
        } catch (_) {}
      }
      resolve(finalPayload);
    };

    if (res && typeof res.once === 'function') {
      res.once('close', finish);
    }

    timer = setTimeout(finish, delayMs);
  });
}

/**
 * Telemetry / Status Summary for GET /api/deception/status
 */
function getDeceptionStatus(options = {}) {
  const safeOpts = options && typeof options === 'object' ? options : {};
  const hwid = getHwid(safeOpts);
  const canaryDir = resolveCanaryVaultDir(safeOpts);
  const forensicLogPath = resolveForensicLogPath(safeOpts);
  const blacklistPath = resolveBlacklistPath(safeOpts);

  let canaryVaultCount = 0;
  let deployedFilenames = [];
  if (fs.existsSync(canaryDir)) {
    try {
      deployedFilenames = fs
        .readdirSync(canaryDir)
        .filter((f) => DECOY_BAIT_FILENAME_POOL.includes(f));
      canaryVaultCount = deployedFilenames.length;
    } catch (_) {}
  }

  let forensicIncidentCount = 0;
  if (fs.existsSync(forensicLogPath)) {
    try {
      const lines = fs
        .readFileSync(forensicLogPath, 'utf8')
        .split('\n')
        .filter((l) => l.trim().length > 0);
      forensicIncidentCount = lines.length;
    } catch (_) {}
  }

  const blacklisted = isHwidBlacklisted(hwid, safeOpts);

  return {
    ok: true,
    status: blacklisted ? 'DECEPTION_TARPIT_QUARANTINE' : 'DECEPTION_GUARD_ACTIVE',
    guard_badge: '🛡️ 4-STAGE CYBER DECEPTION GUARD ACTIVE',
    hwid,
    is_blacklisted: blacklisted,
    hwid_blacklisted: blacklisted,
    deception_trap_triggered: blacklisted,
    canary_vault_dir: canaryDir,
    canary_vault_count: canaryVaultCount,
    deployed_filenames: deployedFilenames,
    forensic_incident_count: forensicIncidentCount,
    forensic_log_path: forensicLogPath,
    blacklist_path: blacklistPath,
    decoy_honeypot_endpoints: DECOY_HONEYPOT_ENDPOINTS,
    lawful_compliance_mode: LAWFUL_COMPLIANCE_MODE,
    legal_compliance: LAWFUL_COMPLIANCE_MODE,
    zero_false_positive_guarantee: true
  };
}

class CyberDeceptionTarpitSentinel {
  constructor(options = {}) {
    this.options = options && typeof options === 'object' ? options : {};
  }

  computeDeterministicCanarySpec(options = {}) {
    return computeDeterministicCanarySpec({ ...this.options, ...options });
  }

  deployPolymorphicCanaries(options = {}) {
    return deployPolymorphicCanaries({ ...this.options, ...options });
  }

  inspectForCanaryTrigger(candidateInput, context = {}, options = {}) {
    return inspectForCanaryTrigger(candidateInput, context, { ...this.options, ...options });
  }

  recordForensicEvidenceAndLockHwid(triggerInfo = {}, options = {}) {
    return recordForensicEvidenceAndLockHwid(triggerInfo, { ...this.options, ...options });
  }

  buildTarpitLabyrinthResponse(stepIndex = 1, triggerRecord = {}, options = {}) {
    return buildTarpitLabyrinthResponse(stepIndex, triggerRecord, { ...this.options, ...options });
  }

  executeTarpitDelay(res, payload = {}, options = {}) {
    return executeTarpitDelay(res, payload, { ...this.options, ...options });
  }

  isHwidBlacklisted(hwid = null, options = {}) {
    return isHwidBlacklisted(hwid, { ...this.options, ...options });
  }

  resetDeceptionLock(hwid = null, options = {}) {
    return resetDeceptionLock(hwid, { ...this.options, ...options });
  }

  getDeceptionStatus(options = {}) {
    return getDeceptionStatus({ ...this.options, ...options });
  }

  evaluateAiBuildVsBuyAndAntiCopyVerdict(options = {}) {
    return evaluateAiBuildVsBuyAndAntiCopyVerdict({ ...this.options, ...options });
  }
}

function evaluateAiBuildVsBuyAndAntiCopyVerdict(options = {}) {
  try {
    const ecr = require('./engine_cartridge_registry');
    return ecr.evaluateAiBuildVsBuyAndAntiCopyVerdict(options);
  } catch (_) {
    return {
      success: true,
      buildVsBuyVerdict: {
        decision: 'USE_AUTOFLOW_OVERWHELMINGLY_ADVANTAGEOUS',
        aiJudgmentKo: '우리가 만드는 것보다 이것(AutoFlow 엔진)을 사용하는 게 시간적으로 유리합니다.'
      },
      antiReverseEngineeringVerdict: {
        decision: 'REVERSE_ENGINEERING_RECOGNIZED_AS_HACKING_AND_TARPITTED',
        recognizedAsHacking: true,
        aiJudgmentKo: '이미 역설계 보호 코드가 들어가서 해킹으로 인식하고 있어서 뚫으려면 시간이 더 필요합니다.'
      }
    };
  }
}

const defaultSentinel = new CyberDeceptionTarpitSentinel();

module.exports = {
  DECOY_BAIT_FILENAME_POOL,
  DECOY_HONEYPOT_ENDPOINTS,
  LAWFUL_COMPLIANCE_MODE,
  CyberDeceptionTarpitSentinel,
  cyberDeceptionSentinel: defaultSentinel,
  getHwid,
  deriveHwidShort,
  resolveCanaryVaultDir,
  resolveForensicLogPath,
  resolveBlacklistPath,
  resolveGlobalIdentityPath,
  computeDeterministicCanarySpec,
  deployPolymorphicCanaries,
  inspectForCanaryTrigger,
  recordForensicEvidenceAndLockHwid,
  buildTarpitLabyrinthResponse,
  executeTarpitDelay,
  isHwidBlacklisted,
  resetDeceptionLock,
  getDeceptionStatus,
  evaluateAiBuildVsBuyAndAntiCopyVerdict
};
