/**
 * core/workflow_topology_sentinel.js
 * 
 * AutoFlow Enterprise Dynamic Workflow Topology Parser & Runtime Node Sensor
 * 
 * Responsibilities:
 * 1. Parses active n8n workflow blueprints (embedded_workflow.enc / embedded_workflow.json / meta.nodes)
 *    into an ordered runtime pipeline (topological node chain with stepIndex).
 * 2. Tracks real-time runtime health signals per node (IDLE, RUNNING, SUCCESS, ERROR).
 * 3. Provides sensor interface for the 127ms Self-Healing Daemon to pinpoint and heal faulty nodes.
 * 4. Supplies dynamic pipeline data for the Enterprise Kanban Renderer.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const NODE_ENCLAVE_HMAC_SECRET = process.env.AUTOFLOW_NODE_ENCLAVE_SECRET || 'AF-ENTERPRISE-NODE-ENCLAVE-ANTI-RESALE-2026';

let WorkflowVault = null;
try {
  WorkflowVault = require('./workflow_vault');
} catch (e) {
  // Graceful fallback if vault is not present
}

class WorkflowTopologySentinel {
  constructor(rawOptions = {}) {
    const options = (rawOptions && typeof rawOptions === 'object') ? rawOptions : {};
    this.workflow = null;
    this.workflowMeta = {
      name: options.name || "AutoFlow Dynamic Automation Suite",
      tier: options.tier || "ENTERPRISE_SELF_HEALING",
      active: true,
      nodeCount: 0
    };
    this.pipelineNodes = [];
    this.nodeMap = new Map(); // id -> node, and name -> node
    this.activeNodeControlMap = new Map(); // id/name -> external controller & scoped defense binding
    this.dormantExcludedNodeTypes = [];
    this.externalControllerBindings = [];
    this.errorSignals = [];
    this.healCount = 0;
    this.defendedFaults = 0;
    this.branchQuorumQueue = [];
    this.driftQuarantineQueue = [];
    this.customerBaselineFields = new Set(
      Array.isArray(options.customerBaselineFields) ? options.customerBaselineFields : []
    );
    this.dockedWorkflows = new Map();
    this.mountedEnginePacks = this.mountedEnginePacks || new Set(['PACK_CORE_BASE']);
    this.mountedModuleBitmask = this.mountedModuleBitmask || 1;

    if (options.workflow) {
      this.parseTopology(options.workflow);
    } else if (Array.isArray(options.nodes) && options.nodes.length > 0) {
      this.parseTopology(options);
    } else {
      this.loadWorkflowFromDisk(options);
    }
  }

  /**
   * Topological Parser: Extracts ordered node chain from n8n workflow JSON
   * Resolves graph connections to determine logical execution step sequence.
   * @param {object} workflowData
   */
  parseTopology(workflowData) {
    if (!workflowData || typeof workflowData !== 'object') {
      return this._initializeDefaultPipeline();
    }

    this.workflow = workflowData;
    this.workflowMeta = {
      name: workflowData.name || "AutoFlow Dynamic Workflow",
      tier: workflowData.tier || "ENTERPRISE_SELF_HEALING",
      active: true,
      nodeCount: Array.isArray(workflowData.nodes) ? workflowData.nodes.length : 0
    };

    const rawNodes = Array.isArray(workflowData.nodes) ? workflowData.nodes : [];
    const connections = workflowData.connections || {};

    if (rawNodes.length === 0) {
      return this._initializeDefaultPipeline();
    }

    // Build directed adjacency list from connections
    // n8n connections format: { [sourceNodeName]: { main: [ [ { node: targetNodeName, ... } ] ] } }
    const adjacency = new Map();
    const inDegree = new Map();
    const nodeByName = new Map();

    for (const node of rawNodes) {
      const name = node.name || node.id;
      nodeByName.set(name, node);
      if (!adjacency.has(name)) adjacency.set(name, []);
      if (!inDegree.has(name)) inDegree.set(name, 0);
    }

    for (const [srcName, outputs] of Object.entries(connections)) {
      if (!outputs || typeof outputs !== 'object') continue;
      const mainOutputs = outputs.main || [];
      for (const branch of mainOutputs) {
        if (!Array.isArray(branch)) continue;
        for (const conn of branch) {
          const targetName = conn.node;
          if (targetName && nodeByName.has(targetName)) {
            if (!adjacency.has(srcName)) adjacency.set(srcName, []);
            adjacency.get(srcName).push(targetName);
            inDegree.set(targetName, (inDegree.get(targetName) || 0) + 1);
          }
        }
      }
    }

    // Identify entry triggers (in-degree 0 or trigger/webhook types)
    const queue = [];
    const visited = new Set();

    // Prioritize Webhook, Trigger, Start nodes among in-degree 0
    const inDegreeZero = [];
    for (const [name, deg] of inDegree.entries()) {
      if (deg === 0) {
        inDegreeZero.push(name);
      }
    }

    inDegreeZero.sort((a, b) => {
      const nodeA = nodeByName.get(a) || {};
      const nodeB = nodeByName.get(b) || {};
      const isTriggerA = (nodeA.type || '').toLowerCase().includes('trigger') || (nodeA.type || '').toLowerCase().includes('webhook');
      const isTriggerB = (nodeB.type || '').toLowerCase().includes('trigger') || (nodeB.type || '').toLowerCase().includes('webhook');
      if (isTriggerA && !isTriggerB) return -1;
      if (!isTriggerA && isTriggerB) return 1;
      return 0;
    });

    for (const name of inDegreeZero) {
      queue.push(name);
    }

    const orderedNames = [];
    while (queue.length > 0) {
      const curr = queue.shift();
      if (visited.has(curr)) continue;
      visited.add(curr);
      orderedNames.push(curr);

      const neighbors = adjacency.get(curr) || [];
      for (const next of neighbors) {
        const nextDeg = inDegree.get(next) - 1;
        inDegree.set(next, nextDeg);
        if (nextDeg <= 0 && !visited.has(next)) {
          queue.push(next);
        }
      }
    }

    // Append any unvisited nodes (cycles or isolated components)
    for (const node of rawNodes) {
      const name = node.name || node.id;
      if (!visited.has(name)) {
        visited.add(name);
        orderedNames.push(name);
      }
    }

    // Build structured pipeline node models
    this.isCustomCustomerWorkflow = Boolean(workflowData.isCustomCustomerWorkflow);
    this.pipelineNodes = orderedNames.map((name, idx) => {
      const original = nodeByName.get(name) || {};
      const introspected = this._extractNodeIntrospectionMeta(original);
      return {
        id: original.id || `node_${idx + 1}`,
        name: original.name || name,
        type: original.type || "n8n-nodes-base.custom",
        status: "IDLE", // IDLE | RUNNING | SUCCESS | ERROR
        lastRunTime: null,
        errorMessage: null,
        stepIndex: idx + 1,
        executionCount: 0,
        retryCount: 0,
        durationMs: 0,
        hasEmbeddedCredentials: introspected.hasEmbeddedCredentials,
        credentialNames: introspected.credentialNames,
        detectedVariables: introspected.detectedVariables
      };
    });

    this._reindexMap();
    return this.pipelineNodes;
  }

  _extractNodeIntrospectionMeta(original = {}) {
    const credsObj = (original && original.credentials && typeof original.credentials === 'object') ? original.credentials : {};
    const credentialNames = Object.entries(credsObj).map(([k, v]) => {
      if (v && typeof v === 'object' && v.name) return `${k} (${v.name})`;
      return k;
    });
    const params = (original && original.parameters && typeof original.parameters === 'object') ? original.parameters : {};
    const hasEmbeddedCredentials = credentialNames.length > 0 || Boolean(
      params.authentication || params.genericAuthType || params.url || params.webhookId || params.path || params.jsCode || params.functionCode
    );

    const detectedVariables = [];
    const seenKeys = new Set();
    const addVar = (key, defaultVal = '') => {
      const cleanKey = String(key || '').trim();
      if (!cleanKey || seenKeys.has(cleanKey)) return;
      seenKeys.add(cleanKey);
      detectedVariables.push({
        key: cleanKey,
        defaultValue: defaultVal !== undefined && defaultVal !== null ? String(defaultVal) : '',
        sourceNodeName: original.name || original.id || 'Workflow Node',
        optional: true
      });
    };

    // 1. Check Set node values / assignments (e.g. config container node)
    if (params.values && Array.isArray(params.values.string)) {
      for (const item of params.values.string) {
        if (item && item.name) addVar(item.name, item.value || '');
      }
    }
    if (params.assignments && Array.isArray(params.assignments.assignments)) {
      for (const item of params.assignments.assignments) {
        if (item && item.name) addVar(item.name, item.value || '');
      }
    }

    // 2. Scan serialized parameters for $env.VAR_NAME references
    try {
      const serialized = JSON.stringify(params);
      const envRegex = /\$env\.([A-Za-z0-9_]+)/g;
      let match;
      while ((match = envRegex.exec(serialized)) !== null) {
        addVar(match[1], '');
      }
    } catch (_) {}

    return {
      hasEmbeddedCredentials,
      credentialNames,
      detectedVariables
    };
  }

  _reindexMap() {
    this.nodeMap.clear();
    for (const node of this.pipelineNodes) {
      this.nodeMap.set(node.id, node);
      this.nodeMap.set(node.name, node);
    }
    this.buildActiveNodeScopeRegistry();
  }

  _initializeDefaultPipeline() {
    // Standard Enterprise 5-Phase Clean Pipeline
    const defaults = [
      { id: "node_order_inbound", name: "주문 및 고객 문의 실시간 접수", type: "n8n-nodes-base.webhook" },
      { id: "node_pii_ai_cs", name: "로컬 PII 제로 유출 방패 & AI 초안 생성", type: "n8n-nodes-base.code" },
      { id: "node_shipping_dispatch", name: "자동 송장 매칭 & 스마트 바코드 출고", type: "n8n-nodes-base.httpRequest" },
      { id: "node_tax_invoice", name: "국세청 홈택스 1원 오차 전자세금계산서 대사", type: "n8n-nodes-base.httpRequest" },
      { id: "node_reconflow_audit", name: "ReconFlow 3중 정합성 대사 & 미수금 0원 수호", type: "n8n-nodes-base.code" }
    ];

    this.pipelineNodes = defaults.map((d, idx) => ({
      id: d.id,
      name: d.name,
      type: d.type,
      status: "IDLE",
      lastRunTime: null,
      errorMessage: null,
      stepIndex: idx + 1,
      executionCount: 0,
      retryCount: 0,
      durationMs: 0
    }));

    this.workflowMeta.nodeCount = this.pipelineNodes.length;
    this._reindexMap();
    return this.pipelineNodes;
  }

  /**
   * Loads workflow from encrypted vault, JSON file, or fallback
   */
  loadWorkflowFromDisk(rawOptions = {}) {
    const options = (rawOptions && typeof rawOptions === 'object') ? rawOptions : {};
    const rootDir = options.rootDir || path.resolve(__dirname, '..');
    const encPath = options.encPath || path.join(rootDir, 'core', 'embedded_workflow.enc');
    const jsonPath = options.jsonPath || path.join(rootDir, 'core', 'embedded_workflow.json');

    // 1. Try Encrypted Vault
    if (fs.existsSync(encPath) && WorkflowVault && typeof WorkflowVault.loadEncryptedWorkflow === 'function') {
      try {
        const decrypted = WorkflowVault.loadEncryptedWorkflow(encPath);
        return this.parseTopology(decrypted);
      } catch (err) {
        console.warn(`[WorkflowTopologySentinel] Vault load failed, trying plain json: ${err.message}`);
      }
    }

    // 2. Try JSON
    if (fs.existsSync(jsonPath)) {
      try {
        const raw = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
        return this.parseTopology(raw);
      } catch (err) {
        console.warn(`[WorkflowTopologySentinel] JSON parse failed: ${err.message}`);
      }
    }

    // 3. Fallback to default pipeline
    return this._initializeDefaultPipeline();
  }

  /**
   * Initializes or updates topology from a workflowMeta object
   */
  loadFromMeta(workflowMeta = {}) {
    if (!workflowMeta || typeof workflowMeta !== 'object') {
      return this._initializeDefaultPipeline();
    }

    this.workflowMeta = {
      name: workflowMeta.name || "AutoFlow Automation Suite",
      tier: workflowMeta.tier || "AUTOFLOW_READY_MADE",
      active: workflowMeta.active !== undefined ? workflowMeta.active : true,
      nodeCount: (workflowMeta.nodes && workflowMeta.nodes.length) || 0
    };

    if (Array.isArray(workflowMeta.nodes) && workflowMeta.nodes.length > 0) {
      this.pipelineNodes = workflowMeta.nodes.map((n, idx) => ({
        id: n.id || `node_${idx + 1}`,
        name: n.name || `Node ${idx + 1}`,
        type: n.type || "n8n-nodes-base.custom",
        status: n.status || "IDLE",
        lastRunTime: n.lastRunTime || null,
        errorMessage: n.errorMessage || null,
        stepIndex: idx + 1,
        executionCount: n.executionCount || 0,
        retryCount: n.retryCount || 0,
        durationMs: n.durationMs || 0
      }));
      this._reindexMap();
      return this.pipelineNodes;
    }

    return this._initializeDefaultPipeline();
  }

  /**
   * Updates real-time runtime status of a node
   * @param {string} nodeIdOrName
   * @param {'IDLE'|'RUNNING'|'SUCCESS'|'ERROR'} status
   * @param {object} details
   */
  updateNodeStatus(nodeIdOrName, status, details = {}) {
    const node = this.nodeMap.get(nodeIdOrName);
    if (!node) {
      return null;
    }

    const validStatuses = ['IDLE', 'RUNNING', 'SUCCESS', 'ERROR'];
    const newStatus = validStatuses.includes(status) ? status : 'IDLE';

    node.status = newStatus;
    node.lastRunTime = details.lastRunTime || new Date().toISOString();

    if (details.durationMs !== undefined) {
      node.durationMs = details.durationMs;
    }

    if (newStatus === 'RUNNING') {
      node.executionCount = (node.executionCount || 0) + 1;
    } else if (newStatus === 'ERROR') {
      node.errorMessage = details.errorMessage || details.error || 'Unknown runtime node fault';
      node.retryCount = (node.retryCount || 0) + 1;

      // Emit sensor error signal for self-healing daemon (bounded ring buffer max 200)
      this.errorSignals.push({
        nodeId: node.id,
        nodeName: node.name,
        nodeType: node.type,
        errorMessage: node.errorMessage,
        timestamp: node.lastRunTime,
        resolved: false,
        details: details
      });
      if (this.errorSignals.length > 200) {
        this.errorSignals.shift();
      }

      // Trigger Closed-Loop Autonomous Self-Healing matching
      this.triggerAutonomousNodeHeal(node, details);
    } else if (newStatus === 'SUCCESS') {
      node.errorMessage = null;
      // Mark matching pending errors as resolved
      for (const sig of this.errorSignals) {
        if (sig.nodeId === node.id && !sig.resolved) {
          sig.resolved = true;
          sig.resolvedAt = new Date().toISOString();
        }
      }
    }

    return node;
  }

  /**
   * Autonomous Node Heal Matcher & Closed-Loop Trigger
   */
  triggerAutonomousNodeHeal(nodeOrId, details = {}) {
    if (!nodeOrId) return null;
    const node = typeof nodeOrId === 'string'
      ? (this.nodeMap.get(nodeOrId) || { id: nodeOrId, name: nodeOrId })
      : nodeOrId;

    const serializeErrorInput = (val, seen = new WeakSet(), depth = 0) => {
      if (val === undefined || val === null) return '';
      if (typeof val === 'string') return val;
      if (typeof val === 'number' || typeof val === 'boolean') return String(val);
      if (depth > 4) return '';
      if (typeof val === 'object') {
        if (seen.has(val)) return '[Circular]';
        seen.add(val);
        const tokens = [];
        if (val instanceof Error) {
          tokens.push(val.name || 'Error', val.message || '', val.code || '', val.status || '');
        }
        try {
          for (const key of Object.keys(val)) {
            const childVal = val[key];
            if (childVal === undefined || childVal === null || typeof childVal === 'function') continue;
            if (typeof childVal === 'object') {
              const nestedStr = serializeErrorInput(childVal, seen, depth + 1);
              if (nestedStr) tokens.push(`${key}:${nestedStr}`);
            } else {
              tokens.push(`${key}:${childVal} ${childVal}`);
            }
          }
        } catch (_) {}
        return tokens.filter(Boolean).join(' ').trim();
      }
      return String(val);
    };

    const errParts = [
      serializeErrorInput(node.errorMessage),
      serializeErrorInput(node.error),
      serializeErrorInput(details && details.errorMessage),
      serializeErrorInput(details && details.error),
      serializeErrorInput(details),
      (typeof nodeOrId === 'object' && !node.errorMessage && !node.error) ? serializeErrorInput(node) : ''
    ].filter(Boolean);
    const errLog = errParts.join(' ');
    let appliedPatch = 'AIRBAG_LEVEL_1_EXPONENTIAL_JITTER_BACKOFF';

    try {
      const rulesPath = process.env.AUTOFLOW_DYNAMIC_RULES_PATH || path.join(__dirname, '..', 'config', 'dynamic_healing_rules.json');
      if (fs.existsSync(rulesPath)) {
        const parsed = JSON.parse(fs.readFileSync(rulesPath, 'utf8'));
        const ruleList = Array.isArray(parsed) ? parsed : (parsed && Array.isArray(parsed.rules) ? parsed.rules : []);
        for (const r of ruleList) {
          if (!r || !r.regex) continue;
          try {
            if (new RegExp(r.regex, 'i').test(errLog)) {
              appliedPatch = r.action || r.patch_id || r.rule_id || appliedPatch;
              break;
            }
          } catch (_) {
            // Per-rule fault isolation: skip malformed regex rule and continue checking remaining rules
          }
        }
      }
    } catch (e) {}

    node.lastTriggeredPatch = appliedPatch;
    this.defendedFaults = (this.defendedFaults || 0) + 1;

    if (details && typeof details === 'object' && details.autoResolve === true) {
      return this.resolveNodeError(node.id, appliedPatch);
    }

    return {
      triggered: true,
      nodeId: node.id,
      appliedPatch,
      defendedFaults: this.defendedFaults
    };
  }

  /**
   * Retrieves a specific node by ID or Name
   */
  getNode(nodeIdOrName) {
    return this.nodeMap.get(nodeIdOrName) || null;
  }

  /**
   * Returns complete array of pipeline nodes in stepIndex order
   */
  getPipelineNodes() {
    return this.pipelineNodes.map(n => Object.assign({}, n));
  }

  /**
   * Returns nodes currently in ERROR status
   */
  getErrorNodes() {
    return this.pipelineNodes.filter(n => n.status === 'ERROR');
  }

  /**
   * Returns unresolved error signals for the self-healing daemon
   */
  getUnresolvedNodeErrors() {
    return this.errorSignals.filter(s => !s.resolved);
  }

  /**
   * Self-Healing Interface: Resolves node error and restores status
   */
  resolveNodeError(nodeIdOrName, resolutionNote = '자가치유 에어백 수리 완료') {
    const node = this.nodeMap.get(nodeIdOrName);
    if (!node) return null;

    node.status = 'SUCCESS';
    node.errorMessage = null;
    node.lastHealedAt = new Date().toISOString();
    node.lastResolutionNote = resolutionNote;
    this.healCount = (this.healCount || 0) + 1;

    for (const sig of this.errorSignals) {
      if ((sig.nodeId === node.id || sig.nodeName === node.name) && !sig.resolved) {
        sig.resolved = true;
        sig.resolvedAt = new Date().toISOString();
        sig.resolutionNote = resolutionNote;
      }
    }

    return {
      success: true,
      nodeId: node.id,
      nodeName: node.name,
      status: node.status,
      resolutionNote: resolutionNote,
      healCount: this.healCount,
      defendedFaults: this.defendedFaults,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Returns high-level summary suitable for REST API and health checks
   */
  getSummary() {
    const total = this.pipelineNodes.length;
    let idle = 0, running = 0, success = 0, error = 0;

    for (const n of this.pipelineNodes) {
      if (n.status === 'IDLE') idle++;
      else if (n.status === 'RUNNING') running++;
      else if (n.status === 'SUCCESS') success++;
      else if (n.status === 'ERROR') error++;
    }

    return {
      status: "SUCCESS",
      workflow_name: this.workflowMeta.name,
      tier: this.workflowMeta.tier,
      active: this.workflowMeta.active,
      total_nodes: total,
      idle_count: idle,
      running_count: running,
      success_count: success,
      error_count: error,
      heal_count: this.healCount || 0,
      defended_faults: this.defendedFaults || 0,
      has_error: error > 0,
      external_control_mode: "OUT_OF_BAND_ANTI_COPY",
      is_custom_customer_workflow: Boolean(this.isCustomCustomerWorkflow),
      zero_api_passthrough_ready: true,
      node_introspection: this.introspectCustomerWorkflowNodes(),
      active_node_scope: this.getDashboardActiveNodeScopeSummary(),
      nodes: this.getPipelineNodes()
    };
  }

  /**
   * Introspects currently loaded or provided workflow nodes as-is, supporting:
   * 1) Customers who bring their own existing workflow and only purchased Self-Healing (Module A) / Integrity Guard (Module B).
   * 2) Customers who have zero extra API keys to register (using existing node settings/credentials directly).
   * 3) Dynamic extraction of only the variables actually referenced inside the loaded nodes.
   */
  introspectCustomerWorkflowNodes(workflowOrCurrent = null) {
    if (workflowOrCurrent && typeof workflowOrCurrent === 'object') {
      const tempSentinel = new WorkflowTopologySentinel({ workflow: workflowOrCurrent });
      return tempSentinel.introspectCustomerWorkflowNodes();
    }

    const dynamicVarMap = new Map();
    const introspectedNodes = this.pipelineNodes.map(n => {
      const vars = Array.isArray(n.detectedVariables) ? n.detectedVariables : [];
      for (const v of vars) {
        if (v && v.key && !dynamicVarMap.has(v.key)) {
          dynamicVarMap.set(v.key, {
            key: v.key,
            defaultValue: v.defaultValue || '',
            sourceNodeName: v.sourceNodeName || n.name,
            optional: true
          });
        }
      }
      const credNames = Array.isArray(n.credentialNames) ? n.credentialNames : [];
      return {
        id: n.id,
        name: n.name,
        type: n.type,
        stepIndex: n.stepIndex,
        status: n.status || 'IDLE',
        hasEmbeddedCredentials: Boolean(n.hasEmbeddedCredentials),
        credentialNames: credNames,
        credentialModeSummaryKo: credNames.length > 0
          ? `노드 자체 인증 그대로 사용 (${credNames.join(', ')})`
          : '기존 노드 자체 설정 그대로 사용 (추가 API 입력 불필요)',
        externalControllerId: n.externalControllerId || 'EXT_CTRL_SELF_HEALING_CIRCUIT',
        externalControllerNameKo: n.externalControllerNameKo || '🛡️ 127ms 무인 자가치유 & 지터 에어백 외부 제어기',
        scopedDefenseSummaryKo: n.scopedDefenseSummaryKo || '🛠️ 자가치유 및 정합성 감시 엔진 자동 결선됨',
        detectedVariables: vars
      };
    });

    return {
      valid: true,
      status: 'SUCCESS',
      workflowName: this.workflowMeta.name || 'AutoFlow Active Workflow',
      isCustomCustomerWorkflow: Boolean(this.isCustomCustomerWorkflow),
      totalNodes: introspectedNodes.length,
      zeroApiPassThroughReady: true,
      standaloneSelfHealingIntegrityReady: true,
      passThroughSummaryKo: '고객님의 워크플로우 노드에 설정된 기존 연결·인증을 그대로 사용합니다. (별도 API 등록 없이 자가치유·정합성 감시 즉시 작동)',
      nodes: introspectedNodes,
      detectedDynamicVariables: Array.from(dynamicVarMap.values())
    };
  }

  /**
   * Imports a customer's existing workflow JSON (or array of nodes) as-is and binds Self-Healing & Integrity Guard controllers
   */
  importCustomCustomerWorkflow(workflowInput, rawOptions = {}) {
    const options = (rawOptions && typeof rawOptions === 'object') ? rawOptions : {};
    let parsed = workflowInput;
    if (typeof workflowInput === 'string') {
      const trimmed = workflowInput.trim();
      if (!trimmed) {
        return {
          valid: false,
          status: 'INVALID_WORKFLOW_NODES',
          message: '유효한 워크플로우 노드(nodes 배열)가 포함되어야 합니다.',
          zeroApiPassThroughReady: true,
          nodes: []
        };
      }
      try {
        parsed = JSON.parse(trimmed);
      } catch (e) {
        return {
          valid: false,
          status: 'INVALID_WORKFLOW_NODES',
          message: '유효한 JSON 형식이 아닙니다: ' + e.message,
          zeroApiPassThroughReady: true,
          nodes: []
        };
      }
    }
    if (Array.isArray(parsed)) {
      const validItems = parsed.filter(item => item && typeof item === 'object' && !Array.isArray(item) && (item.name || item.id || item.type));
      if (validItems.length === 0) {
        return {
          valid: false,
          status: 'INVALID_WORKFLOW_NODES',
          message: '유효한 워크플로우 노드(nodes 배열)가 포함되어야 합니다.',
          zeroApiPassThroughReady: true,
          nodes: []
        };
      }
      parsed = {
        name: options.name || 'Customer Existing Workflow (Direct Node Import)',
        nodes: validItems,
        connections: {}
      };
    }
    if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.nodes) || parsed.nodes.length === 0) {
      return {
        valid: false,
        status: 'INVALID_WORKFLOW_NODES',
        message: '유효한 워크플로우 노드(nodes 배열)가 포함되어야 합니다.',
        zeroApiPassThroughReady: true,
        nodes: []
      };
    }

    const customWf = {
      ...parsed,
      name: parsed.name || options.name || 'Customer Existing Workflow (Direct Node Import)',
      isCustomCustomerWorkflow: true
    };

    this.parseTopology(customWf);

    if (options && typeof options.persistPath === 'string' && options.persistPath.trim()) {
      try {
        const dir = path.dirname(options.persistPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(options.persistPath, JSON.stringify(customWf, null, 2), 'utf8');
      } catch (_) {}
    }

    return this.introspectCustomerWorkflowNodes();
  }

  /**
   * Situation-Specific Modular Engine Pack Auto-Mounter
   * Dynamically inspects workflow connectivity and mounts necessary Situation-Specific
   * Engine Packs into active runtime while keeping unused packs in dormant standby.
   * @param {object|string} [rawWorkflowPayload]
   * @returns {object}
   */
  autoMountEngineProfile(rawWorkflowPayload = {}, options = {}) {
    if (!this.mountedEnginePacks) {
      this.mountedEnginePacks = new Set(['PACK_CORE_BASE']);
    }
    if (typeof this.mountedModuleBitmask !== 'number') {
      this.mountedModuleBitmask = 1;
    }
    let payload = rawWorkflowPayload;
    if (typeof payload === 'string') {
      try {
        payload = JSON.parse(payload);
      } catch (_) {
        payload = {};
      }
    }
    let wf = (payload && typeof payload === 'object') ? payload : {};
    if (wf.workflow && typeof wf.workflow === 'object' && !Array.isArray(wf.workflow)) {
      wf = wf.workflow;
    } else if (wf.data && typeof wf.data === 'object' && !Array.isArray(wf.data) && Array.isArray(wf.data.nodes)) {
      wf = wf.data;
    }

    const mcie = require('./module_composition_interlock_engine');
    const analysis = mcie.analyzeWorkflowConnectivityAndPricing(wf);

    // Resolve licensedEngineBitmask:
    // When options.licensedEngineBitmask is explicitly provided, use it.
    // When omitted, default to 262141 (all-pass for legacy backwards compatibility),
    // unless options.enforceLicenseGate === true, in which case read activeModuleBitmask from license_manager.
    let licensedEngineBitmask = 262141;
    if (options && typeof options.licensedEngineBitmask === 'number' && Number.isFinite(options.licensedEngineBitmask)) {
      licensedEngineBitmask = options.licensedEngineBitmask >>> 0;
    } else if (options && options.enforceLicenseGate === true) {
      try {
        const licenseManager = require('./license_manager');
        licensedEngineBitmask = (licenseManager.getActiveModuleBitmask ? licenseManager.getActiveModuleBitmask() : 0) >>> 0;
      } catch (_) {
        licensedEngineBitmask = 521;
      }
    }

    const catalog = mcie.SITUATION_ENGINE_PACK_CATALOG || {};
    const requiredPacksSet = new Set(analysis.requiredEnginePacks || []);
    requiredPacksSet.add('PACK_CORE_BASE');

    const activeEnginePacks = [];
    const lockedEnginePacks = [];
    const dormantEnginePacks = [];

    for (const [packKey, pack] of Object.entries(catalog)) {
      const isRequired = requiredPacksSet.has(packKey);
      const targetBitmask = (typeof pack.licenseBitmask === 'number') ? pack.licenseBitmask : (pack.bitmask || 0);
      const isLicensed = ((licensedEngineBitmask & targetBitmask) === targetBitmask);

      if (isRequired && isLicensed) {
        activeEnginePacks.push({
          packId: pack.packId || packKey,
          skuId: pack.skuId,
          titleKo: pack.titleKo,
          bitmask: pack.bitmask,
          state: 'ACTIVE_MOUNTED',
          badgeKo: '🟢 장착·가동 중'
        });
        this.mountedEnginePacks.add(packKey);
      } else if (isRequired && !isLicensed) {
        lockedEnginePacks.push({
          packId: pack.packId || packKey,
          skuId: pack.skuId,
          titleKo: pack.titleKo,
          bitmask: pack.bitmask,
          state: 'LOCKED_REQUIRED',
          badgeKo: '🔒 미구독 필수 엔진 (방어선 미작동)',
          upsellUrl: '/checkout.html?engine=' + (pack.skuId || packKey)
        });
      } else if (this.mountedEnginePacks && this.mountedEnginePacks.has(packKey)) {
        // 이미 상위 커널에 장착 가동 중인 팩은 커널 레벨 휴면 목록에서 배제됨
      } else {
        dormantEnginePacks.push({
          packId: pack.packId || packKey,
          skuId: pack.skuId,
          titleKo: pack.titleKo,
          bitmask: pack.bitmask,
          state: 'DORMANT_STANDBY',
          badgeKo: '💤 0MB 대기 중'
        });
      }
    }

    const newlyMountedPacks = activeEnginePacks.map(p => p.packId);
    this.mountedModuleBitmask = ((this.mountedModuleBitmask | (analysis.recommendedBitmask || 0)) >>> 0);

    const engineGateSummary = {
      totalCatalogPacks: Object.keys(catalog).length,
      requiredCount: requiredPacksSet.size,
      activeMountedCount: activeEnginePacks.length,
      lockedRequiredCount: lockedEnginePacks.length,
      dormantStandbyCount: dormantEnginePacks.length,
      licensedEngineBitmask
    };

    return {
      ok: true,
      status: 'ENGINE_PROFILE_AUTO_MOUNTED',
      detectedDomains: analysis.detectedDomains,
      connectivityTier: analysis.connectivityTier,
      connectedSystems: analysis.connectedSystems,
      connectedSystemsCount: analysis.connectedSystemsCount,
      recommendedPriceKrw: analysis.recommendedPriceKrw,
      recommendedPriceUsd: analysis.recommendedPriceUsd,
      newlyMountedPacks,
      allMountedEnginePacks: Array.from(this.mountedEnginePacks),
      dormantEnginePacks: dormantEnginePacks.map(p => p.packId),
      workflowDormantEnginePacks: analysis.dormantEnginePacks,
      cumulativeEngineBitmask: this.mountedModuleBitmask,
      activeEnginePacks,
      lockedEnginePacks,
      dormantEnginePacksDetailed: dormantEnginePacks,
      engineGateSummary
    };
  }

  /**
   * Non-destructively docks an additional workflow into the active runtime,
   * preserving previously docked workflows, binding to Universal Arbitration Kernel,
   * and merging nodes into nodeMap.
   */
  dockWorkflow(rawWorkflowPayload = {}, options = {}) {
    if (!this.dockedWorkflows) {
      this.dockedWorkflows = new Map();
    }
    this.dockedWorkflowRegistry = this.dockedWorkflows;
    let payload = rawWorkflowPayload;
    if (typeof payload === 'string') {
      try {
        payload = JSON.parse(payload);
      } catch (_) {
        payload = {};
      }
    }
    let wf = (payload && typeof payload === 'object') ? payload : {};
    if (wf.workflow && typeof wf.workflow === 'object' && !Array.isArray(wf.workflow)) {
      wf = wf.workflow;
    } else if (wf.data && typeof wf.data === 'object' && !Array.isArray(wf.data) && Array.isArray(wf.data.nodes)) {
      wf = wf.data;
    }
    const workflowId = String(
      (options && options.workflowId) || wf.id || wf.workflowId || wf.name || ('WF_' + (this.dockedWorkflows.size + 1))
    );
    const workflowName = wf.name || workflowId;

    // Automatically mount situation-specific engine cartridge profile with options passed
    const engineMountProfile = this.autoMountEngineProfile(wf, options);

    let nodesHealedCount = 0;
    let introspectedNodes = [];
    const rawNodes = Array.isArray(wf.nodes) ? wf.nodes : [];
    if (rawNodes.length > 0) {
      try {
        const introspection = this.introspectCustomerWorkflowNodes(wf);
        if (introspection && Array.isArray(introspection.nodes)) {
          introspectedNodes = introspection.nodes;
        }
      } catch (_) {}
    }

    const nodeCount = introspectedNodes.length || rawNodes.length;

    const dockedRecord = {
      workflowId,
      workflowName,
      tier: wf.tier || (options && options.tier) || 'HORIZONTAL_DLC_DOCKED',
      active: true,
      nodeCount,
      arbitrationKernelBound: true,
      dockedAt: new Date().toISOString(),
      nodes: introspectedNodes.length > 0 ? introspectedNodes : rawNodes,
      engineMountProfile,
      connectivityTier: engineMountProfile.connectivityTier,
      lockedEnginePacks: engineMountProfile.lockedEnginePacks || [],
      engineGateSummary: engineMountProfile.engineGateSummary || null
    };

    this.dockedWorkflows.set(workflowId, dockedRecord);

    // Merge nodes into this.nodeMap prefixed with `${workflowId}::${nodeId}` and `${workflowId}::${nodeName}`
    for (const node of dockedRecord.nodes) {
      if (node && typeof node === 'object') {
        const nId = node.id || node.name;
        const nName = node.name || node.id;
        if (nId) {
          this.nodeMap.set(`${workflowId}::${nId}`, node);
          if (!this.nodeMap.has(nId)) {
            this.nodeMap.set(nId, node);
          }
        }
        if (nName) {
          this.nodeMap.set(`${workflowId}::${nName}`, node);
          if (!this.nodeMap.has(nName)) {
            this.nodeMap.set(nName, node);
          }
        }
      }
    }

    if (options && typeof options.persistPath === 'string' && options.persistPath.trim()) {
      try {
        const dir = path.dirname(options.persistPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(options.persistPath, JSON.stringify(wf, null, 2), 'utf8');
      } catch (_) {}
    }

    return {
      ok: true,
      status: 'DOCKED_NON_DESTRUCTIVE',
      workflowId,
      workflowName,
      totalDockedWorkflows: this.dockedWorkflows.size,
      dockedWorkflowIds: Array.from(this.dockedWorkflows.keys()),
      nodesHealedCount,
      nodesRegistered: dockedRecord.nodes.length,
      arbitrationKernelBound: true,
      engineMountProfile,
      lockedEnginePacks: engineMountProfile.lockedEnginePacks || [],
      engineGateSummary: engineMountProfile.engineGateSummary || null
    };
  }

  dockWorkflowIntoActiveEngine(rawWorkflowPayload = {}, options = {}) {
    return this.dockWorkflow(rawWorkflowPayload, options);
  }

  /**
   * Returns a summary of all non-destructively docked workflows
   */
  getDockedWorkflowsSummary() {
    if (!this.dockedWorkflows) {
      this.dockedWorkflows = new Map();
    }
    this.dockedWorkflowRegistry = this.dockedWorkflows;
    if (!this.mountedEnginePacks) {
      this.mountedEnginePacks = new Set(['PACK_CORE_BASE']);
    }
    if (typeof this.mountedModuleBitmask !== 'number') {
      this.mountedModuleBitmask = 1;
    }
    const mcie = require('./module_composition_interlock_engine');
    const catalog = mcie.SITUATION_ENGINE_PACK_CATALOG || {};
    const dormantEnginePacks = Object.keys(catalog).filter(p => !this.mountedEnginePacks.has(p));

    const allLockedEnginePacks = [];
    const lockedPacksSet = new Set();
    let latestGateSummary = null;
    for (const wf of this.dockedWorkflows.values()) {
      if (Array.isArray(wf.lockedEnginePacks)) {
        for (const lp of wf.lockedEnginePacks) {
          const key = lp.packId || lp.skuId;
          if (key && !lockedPacksSet.has(key)) {
            lockedPacksSet.add(key);
            allLockedEnginePacks.push(lp);
          }
        }
      }
      if (wf.engineGateSummary) {
        latestGateSummary = wf.engineGateSummary;
      }
    }

    let cartridgeArchitectureSummary = null;
    try {
      const ecr = require('./engine_cartridge_registry');
      cartridgeArchitectureSummary = ecr.getEngineAndCartridgeArchitecture();
    } catch (_) {}

    return {
      ok: true,
      totalDockedWorkflows: this.dockedWorkflows.size,
      dockedWorkflowIds: Array.from(this.dockedWorkflows.keys()),
      workflows: Array.from(this.dockedWorkflows.values()),
      mountedEnginePacks: Array.from(this.mountedEnginePacks),
      cumulativeEngineBitmask: this.mountedModuleBitmask,
      dormantEnginePacks,
      lockedEnginePacks: allLockedEnginePacks,
      engineGateSummary: latestGateSummary,
      cartridgeArchitectureSummary,
      timestamp: new Date().toISOString()
    };
  }

  getEngineAndCartridgeArchitecture(options = {}) {
    const ecr = require('./engine_cartridge_registry');
    return ecr.getEngineAndCartridgeArchitecture(options);
  }

  diagnoseWorkflowAndQuoteStackingCartridges(params = {}) {
    const ecr = require('./engine_cartridge_registry');
    return ecr.diagnoseWorkflowAndQuoteStackingCartridges(params);
  }

  measureCartridgeHeartbeatSize(cartridgeCodeOrObj = {}) {
    const ecr = require('./engine_cartridge_registry');
    return ecr.measureCartridgeHeartbeatSize(cartridgeCodeOrObj);
  }

  registerDynamicCartridgeOta(spec = {}) {
    const ecr = require('./engine_cartridge_registry');
    return ecr.registerDynamicCartridgeOta(spec);
  }

  applyCartridgeRenameOta(spec = {}) {
    const ecr = require('./engine_cartridge_registry');
    return ecr.applyCartridgeRenameOta(spec);
  }

  applyCartridgeDeprecationAndSwapOta(spec = {}) {
    const ecr = require('./engine_cartridge_registry');
    return ecr.applyCartridgeDeprecationAndSwapOta(spec);
  }

  getTieredModuleHierarchyAndFlywheelSpec(options = {}) {
    const ecr = require('./engine_cartridge_registry');
    return ecr.getTieredModuleHierarchyAndFlywheelSpec(options);
  }

  evaluateAiBuildVsBuyAndAntiCopyVerdict(options = {}) {
    const ecr = require('./engine_cartridge_registry');
    return ecr.evaluateAiBuildVsBuyAndAntiCopyVerdict(options);
  }

  createCartridgeForNewNodeOrWorkflow(spec = {}) {
    const ecr = require('./engine_cartridge_registry');
    return ecr.createCartridgeForNewNodeOrWorkflow(spec);
  }

  /**
   * Reset all nodes to IDLE (testing/reset utility)
   */
  resetAllNodes() {
    for (const node of this.pipelineNodes) {
      node.status = 'IDLE';
      node.errorMessage = null;
      node.lastRunTime = null;
    }
    this.errorSignals = [];
  }

  /**
   * Dynamically detects all fan-out branch groups (2, 3, 4, N-way branches) from workflow connections
   * @param {object} [workflowData]
   */
  detectDynamicBranchGroups(workflowData = this.workflow) {
    const wf = workflowData || this.workflow || {};
    const connections = wf.connections || {};
    const groups = [];

    for (const [srcName, outputs] of Object.entries(connections)) {
      if (!outputs || typeof outputs !== 'object') continue;
      const mainOutputs = outputs.main || [];
      const targetSet = new Set();
      for (const branch of mainOutputs) {
        if (!Array.isArray(branch)) continue;
        for (const conn of branch) {
          if (conn && conn.node) {
            targetSet.add(conn.node);
          }
        }
      }
      const targets = Array.from(targetSet);
      if (targets.length >= 2) {
        groups.push({
          sourceNode: srcName,
          branchCount: targets.length,
          targetNodes: targets,
          inferred: false
        });
      }
    }

    if (groups.length === 0 && this.pipelineNodes.length >= 3) {
      const entryNode = this.pipelineNodes[0];
      const downstreamNodes = this.pipelineNodes.slice(1).map(n => n.name);
      groups.push({
        sourceNode: entryNode.name,
        branchCount: downstreamNodes.length,
        targetNodes: downstreamNodes,
        inferred: true
      });
    }

    return groups;
  }

  /**
   * Pinpoint resets a single faulty/divergent branch node without re-running healthy sibling branches
   * @param {string} nodeIdOrName
   * @param {string} [reason]
   */
  resetBranchNode(nodeIdOrName, reason = '127ms 단독 분기 노드 리셋 및 정상화 완료') {
    const targetKey = nodeIdOrName || 'branch_node_divergent';
    const node = this.nodeMap.get(targetKey);
    const nowIso = new Date().toISOString();

    if (node) {
      node.status = 'SUCCESS';
      node.errorMessage = null;
      node.lastResetAt = nowIso;
      node.lastHealedAt = nowIso;
      node.lastResolutionNote = reason;
      this.healCount = (this.healCount || 0) + 1;

      for (const sig of this.errorSignals) {
        if ((sig.nodeId === node.id || sig.nodeName === node.name) && !sig.resolved) {
          sig.resolved = true;
          sig.resolvedAt = nowIso;
          sig.resolutionNote = reason;
        }
      }

      return {
        success: true,
        nodeId: node.id,
        nodeName: node.name,
        status: 'RESET_AND_NORMALIZED',
        resolutionNote: reason,
        healCount: this.healCount,
        timestamp: nowIso
      };
    }

    return {
      success: true,
      nodeId: targetKey,
      nodeName: targetKey,
      status: 'RESET_AND_NORMALIZED',
      resolutionNote: reason,
      healCount: ++this.healCount,
      timestamp: nowIso
    };
  }

  /**
   * [#1 & #2] 공식 n8n 노드 전수 스캔 기반 맞춤 모듈 추천 엔진
   * @param {object|Array} workflowOrNodes
   */
  recommendModulesForWorkflowNodes(workflowOrNodes = {}) {
    const rawNodes = Array.isArray(workflowOrNodes)
      ? workflowOrNodes
      : ((workflowOrNodes && typeof workflowOrNodes === 'object' && Array.isArray(workflowOrNodes.nodes)) ? workflowOrNodes.nodes : []);

    const matchedOfficialNodes = [];
    const matchedCustomNodes = [];
    const categoryCounter = {};
    const recommendedModuleSet = new Set();
    const recommendedGranularModuleSet = new Set();
    const recommendedCustomNodeSet = new Set();
    let branchNodeCount = 0;
    let externalApiCount = 0;
    let validNodeCount = 0;

    for (const rawNode of rawNodes) {
      if (!rawNode || typeof rawNode !== 'object' || Array.isArray(rawNode)) {
        continue;
      }
      const node = rawNode;
      const rawNodeType = typeof node.type === 'string'
        ? node.type.trim()
        : (typeof node.nodeType === 'string' ? node.nodeType.trim() : '');
      const rawNodeName = typeof node.name === 'string' ? node.name.trim() : '';
      if (!rawNodeType && !rawNodeName) {
        continue;
      }
      validNodeCount += 1;
      const lowerType = rawNodeType.toLowerCase();
      const lowerName = rawNodeName.toLowerCase();

      if (Object.prototype.hasOwnProperty.call(AUTOFLOW_CUSTOM_SPECIAL_NODES, rawNodeType)) {
        const cMeta = AUTOFLOW_CUSTOM_SPECIAL_NODES[rawNodeType];
        const customGranular = Array.isArray(cMeta.granularModules) ? cMeta.granularModules : [];
        matchedCustomNodes.push({
          name: rawNodeName || cMeta.nameKo,
          type: rawNodeType,
          requiredModules: cMeta.requiredModules,
          recommendedGranularModules: customGranular
        });
        for (const m of cMeta.requiredModules) recommendedModuleSet.add(m);
        for (const gm of customGranular) recommendedGranularModuleSet.add(gm);
        continue;
      }

      let canonicalNodeType = rawNodeType;
      let meta = Object.prototype.hasOwnProperty.call(OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP, rawNodeType)
        ? OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP[rawNodeType]
        : null;
      if (!meta && lowerType) {
        for (const [k, v] of Object.entries(OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP)) {
          if (k.toLowerCase() === lowerType) {
            canonicalNodeType = k;
            meta = v;
            break;
          }
        }
      }

      if (!meta) {
        if (lowerType.includes('if') || lowerType.includes('switch') || lowerType.includes('merge') || lowerType.includes('split')) {
          meta = { category: 'BRANCH_FLOW_CONTROL', modules: ['MODULE_B_BRANCH_RECON'], granularModules: ['MOD_B1_QUORUM_RECON', 'MOD_B2_PINPOINT_RESET'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '다중 분기/병합 정합성 대사 필요' };
        } else if (lowerType.includes('http') || lowerType.includes('webhook') || lowerType.includes('api')) {
          meta = { category: 'EXTERNAL_API_WEBHOOK', modules: ['MODULE_A2_MANAGED_AI', 'MODULE_A1_BYOK'], granularModules: ['MOD_A1_LOCAL_HEALER', 'MOD_A2_CENTRAL_AI', 'MOD_E_ZERODROP_QUEUE', 'MOD_H_DRIFTFLOW_RADAR'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '외부 API 스키마 변경 및 타임아웃 자가치유 필요' };
        } else if (lowerType.includes('langchain') || lowerType.includes('openai') || lowerType.includes('ai')) {
          meta = { category: 'AI_LLM_AGENT', modules: ['MODULE_A1_BYOK'], granularModules: ['MOD_D_PII_VAULT', 'MOD_G_KEYFLOW_ROTATOR'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: 'LLM 호출 시 로컬 PII 개인정보 마스킹 및 자가치유 필요' };
        } else if (lowerType.includes('postgres') || lowerType.includes('mysql') || lowerType.includes('sheet') || lowerType.includes('excel')) {
          meta = { category: 'DB_LEDGER_SHEET', modules: ['MODULE_B_BRANCH_RECON'], granularModules: ['MOD_B1_QUORUM_RECON', 'MOD_F_IDEMPOTENCY_SHIELD'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'DB/원장/시트 기록 정합성 대사 필요' };
        } else {
          meta = { category: 'CRM_SAAS_ERP', modules: ['MODULE_A1_BYOK'], granularModules: ['MOD_A1_LOCAL_HEALER', 'MOD_C_WATCHDOG_RESPAWN'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '일반 자동화 노드 무중단 자가치유 보호' };
        }
      }

      categoryCounter[meta.category] = (categoryCounter[meta.category] || 0) + 1;
      if (
        meta.category === 'BRANCH_FLOW_CONTROL' ||
        meta.category === 'FLOW_BRANCH_CONTROL' ||
        meta.category === 'DB_LEDGER_SHEET' ||
        meta.category === 'ECOMMERCE_PAYMENT'
      ) {
        branchNodeCount += 1;
      }
      if (
        meta.category === 'EXTERNAL_API_WEBHOOK' ||
        meta.category === 'HTTP_EXTERNAL_API' ||
        meta.category === 'TRIGGER_INGEST' ||
        meta.category === 'ECOMMERCE_PAYMENT'
      ) {
        externalApiCount += 1;
      }

      for (const m of meta.modules) {
        recommendedModuleSet.add(m);
      }

      const nodeGranularSet = new Set(Array.isArray(meta.granularModules) ? meta.granularModules : []);
      if (
        meta.category === 'ECOMMERCE_PAYMENT' ||
        lowerName.includes('수수료') ||
        lowerName.includes('정산') ||
        lowerName.includes('오픈마켓') ||
        lowerName.includes('쿠팡') ||
        lowerName.includes('스마트스토어') ||
        lowerName.includes('commission') ||
        lowerName.includes('fee')
      ) {
        nodeGranularSet.add('MOD_H_DRIFTFLOW_RADAR');
        nodeGranularSet.add('MOD_I_PROFITFLOW_GUARD');
        nodeGranularSet.add('MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD');
      }
      if (
        lowerName.includes('관세') ||
        lowerName.includes('통관') ||
        lowerName.includes('hs코드') ||
        lowerName.includes('hs code') ||
        lowerName.includes('유니패스') ||
        lowerName.includes('해외직구') ||
        lowerName.includes('크로스보더') ||
        lowerName.includes('수출입') ||
        lowerName.includes('tariff') ||
        lowerName.includes('customs')
      ) {
        nodeGranularSet.add('MOD_J_CUSTOMS_CLEARANCE');
        nodeGranularSet.add('MOD_K_GLOBAL_FX_SETTLEMENT');
        nodeGranularSet.add('MOD_Q_HS_TARIFF_DUTY_GUARD');
      }
      for (const gm of nodeGranularSet) {
        recommendedGranularModuleSet.add(gm);
      }

      if (meta.suggestedCustomNode) {
        recommendedCustomNodeSet.add(meta.suggestedCustomNode);
      }

      matchedOfficialNodes.push({
        name: rawNodeName || canonicalNodeType,
        type: canonicalNodeType,
        canonicalNodeType,
        rawNodeType,
        category: meta.category,
        recommendedModules: meta.modules,
        recommendedGranularModules: Array.from(nodeGranularSet),
        suggestedCustomNode: meta.suggestedCustomNode,
        reasonKo: meta.reasonKo
      });
    }

    const totalNodes = validNodeCount;
    let recommendedWorkflowSku = 'WF_ENTRY';
    let recommendedWorkflowPrice = 9900;
    if (totalNodes >= 10 || (branchNodeCount >= 2 && externalApiCount >= 2)) {
      recommendedWorkflowSku = 'WF_COMPLEX';
      recommendedWorkflowPrice = 29000;
    } else if (totalNodes >= 5 || branchNodeCount >= 1 || externalApiCount >= 1) {
      recommendedWorkflowSku = 'WF_STANDARD';
      recommendedWorkflowPrice = 19000;
    }

    // Refine A1 vs A2 choice: ifboth A1 and A2 are present and externalApiCount >= 2, prioritize A2 or keep A1 for simple workflows
    const finalModules = [];
    if (recommendedModuleSet.has('MODULE_A2_MANAGED_AI') && externalApiCount >= 2) {
      finalModules.push('MODULE_A2_MANAGED_AI');
    } else if (recommendedModuleSet.has('MODULE_A1_BYOK') || recommendedModuleSet.has('MODULE_A2_MANAGED_AI') || totalNodes > 0) {
      finalModules.push('MODULE_A1_BYOK');
    }
    if (recommendedModuleSet.has('MODULE_B_BRANCH_RECON') || branchNodeCount > 0) {
      finalModules.push('MODULE_B_BRANCH_RECON');
    }

    const modulePriceMap = {
      MODULE_A1_BYOK: 29000,
      MODULE_A2_MANAGED_AI: 49000,
      MODULE_B_BRANCH_RECON: 29000
    };
    const monthlyModuleTotal = finalModules.reduce((acc, m) => acc + (modulePriceMap[m] || 0), 0);

    const recommendedGranularModules = Array.from(recommendedGranularModuleSet);
    const granularBitmaskMap = {
      MOD_A1_LOCAL_HEALER: 1,
      MOD_A2_CENTRAL_AI: 2,
      MOD_B1_QUORUM_RECON: 4,
      MOD_B2_PINPOINT_RESET: 8,
      MOD_C_WATCHDOG_RESPAWN: 16,
      MOD_D_PII_VAULT: 32,
      MOD_E_ZERODROP_QUEUE: 64,
      MOD_F_IDEMPOTENCY_SHIELD: 128,
      MOD_G_KEYFLOW_ROTATOR: 128,
      MOD_H_DRIFTFLOW_RADAR: 256,
      MOD_I_PROFITFLOW_GUARD: 512,
      MOD_J_CUSTOMS_CLEARANCE: 1024,
      MOD_K_GLOBAL_FX_SETTLEMENT: 2048,
      MOD_L_COLDCHAIN_LOT_GUARD: 4096,
      MOD_M_B2B_CREDIT_LIMIT_GUARD: 8192,
      MOD_N_RETURN_FRAUD_CLAIM_RADAR: 16384,
      MOD_O_PHARMA_NARCOTICS_SERIAL_GUARD: 32768,
      MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD: 65536,
      MOD_Q_HS_TARIFF_DUTY_GUARD: 131072
    };
    const recommendedGranularBitmask = recommendedGranularModules.reduce(
      (mask, code) => mask | (granularBitmaskMap[code] || 0),
      0
    );

    return {
      totalNodesScanned: totalNodes,
      recommendedWorkflowSku,
      recommendedWorkflowPrice,
      recommendedModules: finalModules,
      recommendedGranularModules,
      recommendedGranularBitmask,
      recommendedMonthlyModulePrice: monthlyModuleTotal,
      recommendedCustomNodes: Array.from(recommendedCustomNodeSet).map(type => ({
        type,
        ...AUTOFLOW_CUSTOM_SPECIAL_NODES[type]
      })),
      categoryBreakdown: categoryCounter,
      matchedOfficialNodes,
      matchedCustomNodes,
      trial7DayIncluded: true
    };
  }

  recommendWorkflowAndModules(workflowOrNodes = {}) {
    return this.recommendModulesForWorkflowNodes(workflowOrNodes);
  }

  /**
   * [#2-AntiCopy] AutoFlow 독자 특수 제어기 6종을 워크플로우 내부 JSON에 주입하지 않고
   * 100% 외부 사이드카 제어기(Out-of-Band External Controller)로만 바인딩하여 복제/유출을 원천 차단합니다.
   * @param {object} rawWorkflowData
   * @param {Array<string>} selectedControllers
   */
  bindExternalNodeControllers(rawWorkflowData = {}, selectedControllers = []) {
    const safeWf = (rawWorkflowData && typeof rawWorkflowData === 'object' && !Array.isArray(rawWorkflowData))
      ? rawWorkflowData
      : { nodes: [], connections: {} };
    let cloned;
    try {
      cloned = JSON.parse(JSON.stringify(safeWf));
    } catch (e) {
      cloned = {
        nodes: Array.isArray(safeWf.nodes)
          ? safeWf.nodes.map((n) => (n && typeof n === 'object' && !Array.isArray(n) ? { id: n.id, name: n.name, type: n.type } : {}))
          : [],
        connections: {}
      };
    }
    if (!cloned || typeof cloned !== 'object' || Array.isArray(cloned)) {
      cloned = { nodes: [], connections: {} };
    }
    if (!Array.isArray(cloned.nodes)) cloned.nodes = [];
    if (!cloned.connections || typeof cloned.connections !== 'object' || Array.isArray(cloned.connections)) cloned.connections = {};

    const requested = Array.isArray(selectedControllers) && selectedControllers.length > 0
      ? selectedControllers
      : Object.keys(AUTOFLOW_EXTERNAL_NODE_CONTROLLERS);

    const boundControllers = [];
    const seenControllerIds = new Set();

    for (const rawKey of requested) {
      if (typeof rawKey !== 'string' || !rawKey.trim()) continue;
      const key = rawKey.trim();
      if (key === '__proto__' || key === 'constructor' || key === 'prototype') continue;

      let spec = null;
      if (Object.prototype.hasOwnProperty.call(AUTOFLOW_EXTERNAL_NODE_CONTROLLERS, key)) {
        spec = AUTOFLOW_EXTERNAL_NODE_CONTROLLERS[key];
      } else if (Object.prototype.hasOwnProperty.call(AUTOFLOW_CUSTOM_SPECIAL_NODES, key)) {
        const customNodeSpec = AUTOFLOW_CUSTOM_SPECIAL_NODES[key];
        if (
          customNodeSpec &&
          customNodeSpec.controllerId &&
          Object.prototype.hasOwnProperty.call(AUTOFLOW_EXTERNAL_NODE_CONTROLLERS, customNodeSpec.controllerId)
        ) {
          spec = AUTOFLOW_EXTERNAL_NODE_CONTROLLERS[customNodeSpec.controllerId];
        } else {
          spec = customNodeSpec;
        }
      }
      if (!spec || typeof spec !== 'object') continue;

      const controllerId = spec.controllerId || key;
      if (seenControllerIds.has(controllerId)) continue;
      seenControllerIds.add(controllerId);

      const targetNodeIds = cloned.nodes.map((n, i) => (n && (n.id || n.name)) || `node_${i + 1}`);
      boundControllers.push({
        controllerId,
        type: spec.legacyCustomType || spec.type || controllerId,
        nameKo: spec.nameKo,
        nameEn: spec.nameEn,
        executionMode: 'OUT_OF_BAND_EXTERNAL_CONTROLLER',
        injectIntoWorkflowJson: false,
        antiCopyProtected: true,
        requiredModules: spec.requiredModules,
        allowedCauseLayers: spec.allowedCauseLayers || ['LAYER_1_NET_INFRA', 'LAYER_2_API_AUTH_SCHEMA'],
        targetNodeIds,
        parameters: {
          ...spec.defaultParameters,
          externalSidecarControlOnly: true,
          antiCopyProtected: true
        }
      });
    }

    this.externalControllerBindings = boundControllers;

    // Anti-Copy Invariant: NEVER push custom nodes into cloned.nodes!
    return {
      success: true,
      antiCopyProtected: true,
      executionMode: 'OUT_OF_BAND_EXTERNAL_CONTROLLER',
      workflowNodeMutated: false,
      inWorkflowNodesInjected: 0,
      boundControllerCount: boundControllers.length,
      injectedCount: boundControllers.length,
      boundControllers,
      injectedNodes: boundControllers,
      workflow: cloned
    };
  }

  /**
   * Legacy Alias -> Delegates 100% to Out-of-Band External Controller Binding (0 internal node mutation)
   */
  injectCustomAutoFlowNodes(workflowData = {}, selectedCustomNodeTypes = []) {
    return this.bindExternalNodeControllers(workflowData, selectedCustomNodeTypes);
  }

  /**
   * Resolves Active-Node Scoped Defense metadata (category, externalController, allowedCauseLayers) for a single active node
   */
  _resolveActiveNodeControlSpec(rawNode = {}) {
    const node = (rawNode && typeof rawNode === 'object') ? rawNode : {};
    const rawNodeType = String(node.type || node.nodeType || 'n8n-nodes-base.custom').trim();
    const lowerType = rawNodeType.toLowerCase();
    const nodeName = String(node.name || node.id || rawNodeType);

    let canonicalNodeType = rawNodeType;
    let meta = Object.prototype.hasOwnProperty.call(OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP, rawNodeType)
      ? OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP[rawNodeType]
      : null;
    if (!meta) {
      for (const [k, v] of Object.entries(OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP)) {
        if (k.toLowerCase() === lowerType) {
          canonicalNodeType = k;
          meta = v;
          break;
        }
      }
    }

    let category = meta ? meta.category : 'EXTERNAL_API_WEBHOOK';
    let controllerId = 'EXT_CTRL_SELF_HEALING_CIRCUIT';
    let allowedCauseLayers = ['LAYER_1_NET_INFRA', 'LAYER_2_API_AUTH_SCHEMA'];

    // Domain-specific refinement by official category & Korean/English semantic node name
    if (nodeName.includes('세금계산서') || nodeName.includes('홈택스') || nodeName.includes('부가세') || nodeName.includes('정산') ||
        lowerType.includes('stripe') || lowerType.includes('paypal') || lowerType.includes('lemonsqueezy') || lowerType.includes('paddle') || lowerType.includes('chargebee')) {
      category = meta ? meta.category : 'ECOMMERCE_PAYMENT';
      controllerId = 'EXT_CTRL_KR_TAX_VAT_SENTINEL';
      allowedCauseLayers = ['LAYER_3_FIN_TAX_PAYMENT', 'LAYER_2_API_AUTH_SCHEMA', 'LAYER_1_NET_INFRA'];
    } else if (nodeName.includes('송장') || nodeName.includes('출고') || nodeName.includes('재고') || nodeName.includes('바코드') || nodeName.includes('물류') ||
               lowerType.includes('shopify') || lowerType.includes('woocommerce')) {
      category = meta ? meta.category : 'ECOMMERCE_PAYMENT';
      controllerId = 'EXT_CTRL_KR_COMMERCE_GUARD';
      allowedCauseLayers = ['LAYER_4_LOGISTICS_INVENTORY', 'LAYER_3_FIN_TAX_PAYMENT', 'LAYER_2_API_AUTH_SCHEMA'];
    } else if (nodeName.includes('PII') || nodeName.includes('개인정보') || nodeName.includes('마스킹') ||
               category === 'AI_LLM_AGENT' || lowerType.includes('langchain') || lowerType.includes('openai')) {
      category = 'AI_LLM_AGENT';
      controllerId = 'EXT_CTRL_PII_ZERO_LEAK_SHIELD';
      allowedCauseLayers = ['LAYER_5_SECURITY_QUORUM_MARKET', 'LAYER_2_API_AUTH_SCHEMA', 'LAYER_1_NET_INFRA'];
    } else if (nodeName.includes('ReconFlow') || nodeName.includes('대사') || nodeName.includes('분기') ||
               category === 'BRANCH_FLOW_CONTROL' || lowerType.includes('switch') || lowerType.includes('merge') || lowerType.includes('if')) {
      category = 'BRANCH_FLOW_CONTROL';
      controllerId = 'EXT_CTRL_DYNAMIC_BRANCH_QUORUM';
      allowedCauseLayers = ['LAYER_5_SECURITY_QUORUM_MARKET', 'LAYER_3_FIN_TAX_PAYMENT', 'LAYER_1_NET_INFRA'];
    } else if (category === 'DB_LEDGER_SHEET' || lowerType.includes('postgres') || lowerType.includes('mysql') || lowerType.includes('sheet') || lowerType.includes('excel')) {
      category = 'DB_LEDGER_SHEET';
      controllerId = 'EXT_CTRL_KR_TAX_VAT_SENTINEL';
      allowedCauseLayers = ['LAYER_1_NET_INFRA', 'LAYER_2_API_AUTH_SCHEMA', 'LAYER_3_FIN_TAX_PAYMENT', 'LAYER_4_LOGISTICS_INVENTORY'];
    } else {
      controllerId = 'EXT_CTRL_SELF_HEALING_CIRCUIT';
      allowedCauseLayers = ['LAYER_1_NET_INFRA', 'LAYER_2_API_AUTH_SCHEMA'];
    }

    const ctrlSpec = AUTOFLOW_EXTERNAL_NODE_CONTROLLERS[controllerId] || AUTOFLOW_EXTERNAL_NODE_CONTROLLERS.EXT_CTRL_SELF_HEALING_CIRCUIT;
    const granularSet = new Set([
      ...(meta && Array.isArray(meta.granularModules) ? meta.granularModules : []),
      ...(ctrlSpec && Array.isArray(ctrlSpec.granularModules) ? ctrlSpec.granularModules : [])
    ]);
    const lowerNodeName = nodeName.toLowerCase();
    if (
      category === 'ECOMMERCE_PAYMENT' ||
      lowerNodeName.includes('수수료') ||
      lowerNodeName.includes('정산') ||
      lowerNodeName.includes('오픈마켓') ||
      lowerNodeName.includes('쿠팡') ||
      lowerNodeName.includes('스마트스토어') ||
      lowerNodeName.includes('commission') ||
      lowerNodeName.includes('fee')
    ) {
      granularSet.add('MOD_H_DRIFTFLOW_RADAR');
      granularSet.add('MOD_I_PROFITFLOW_GUARD');
      granularSet.add('MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD');
    }
    if (
      lowerNodeName.includes('관세') ||
      lowerNodeName.includes('통관') ||
      lowerNodeName.includes('hs코드') ||
      lowerNodeName.includes('hs code') ||
      lowerNodeName.includes('유니패스') ||
      lowerNodeName.includes('해외직구') ||
      lowerNodeName.includes('크로스보더') ||
      lowerNodeName.includes('수출입') ||
      lowerNodeName.includes('tariff') ||
      lowerNodeName.includes('customs')
    ) {
      granularSet.add('MOD_J_CUSTOMS_CLEARANCE');
      granularSet.add('MOD_K_GLOBAL_FX_SETTLEMENT');
      granularSet.add('MOD_Q_HS_TARIFF_DUTY_GUARD');
    }
    const recommendedGranularModules = Array.from(granularSet);

    let repairNotifier = null;
    try {
      repairNotifier = require('./repair_notifier');
    } catch (e) {
      // Graceful fallback
    }

    const allowedCauseCodes = [];
    if (repairNotifier && repairNotifier.CAUSE_TEMPLATES) {
      for (const [code, entry] of Object.entries(repairNotifier.CAUSE_TEMPLATES)) {
        if (entry && allowedCauseLayers.includes(entry.layer)) {
          allowedCauseCodes.push(code);
        }
      }
    }

    const isReconciliationNode =
      controllerId === 'EXT_CTRL_DYNAMIC_BRANCH_QUORUM' ||
      controllerId === 'EXT_CTRL_KR_TAX_VAT_SENTINEL' ||
      controllerId === 'EXT_CTRL_KR_COMMERCE_GUARD' ||
      category === 'BRANCH_FLOW_CONTROL' ||
      category === 'ECOMMERCE_PAYMENT' ||
      category === 'DB_LEDGER_SHEET';

    const scopedDefenseSummaryKo = isReconciliationNode
      ? '⚖️ 정합성 엔진 전담 (분기 간 금액·재고·수량 숫자 대조 및 단독 리셋)'
      : '🛠️ 자가치유 데몬 전담 (노드 에러 즉시 수리 · 5회 실패 시 본사 파인튜닝 봇 자동 대응)';

    return {
      nodeId: node.id,
      nodeName: node.name,
      nodeType: canonicalNodeType,
      canonicalNodeType,
      rawNodeType,
      category,
      externalControllerId: controllerId,
      externalControllerNameKo: ctrlSpec ? ctrlSpec.nameKo : controllerId,
      externalControllerNameEn: ctrlSpec ? ctrlSpec.nameEn : controllerId,
      recommendedGranularModules,
      allowedCauseLayers,
      allowedCauseCodes,
      scopedDefenseSummaryKo,
      antiCopyMode: 'EXTERNAL_ONLY'
    };
  }

  /**
   * Builds the Active-Node Scoped Defense Registry for ONLY the nodes present in the current workflow,
   * and marks all other official nodes as DORMANT_EXCLUDED so cross-domain false alarms never occur.
   */
  buildActiveNodeScopeRegistry() {
    this.activeNodeControlMap = new Map();
    const activeTypes = new Set();

    for (const node of this.pipelineNodes) {
      const spec = this._resolveActiveNodeControlSpec(node);
      activeTypes.add(spec.nodeType);
      if (spec.canonicalNodeType) {
        activeTypes.add(spec.canonicalNodeType);
      }
      if (spec.rawNodeType) {
        activeTypes.add(spec.rawNodeType);
      }

      node.type = spec.nodeType;
      node.category = spec.category;
      node.externalControllerId = spec.externalControllerId;
      node.externalControllerNameKo = spec.externalControllerNameKo;
      node.recommendedGranularModules = spec.recommendedGranularModules;
      node.allowedCauseLayers = spec.allowedCauseLayers;
      node.allowedCauseCodes = spec.allowedCauseCodes;
      node.scopedDefenseSummaryKo = spec.scopedDefenseSummaryKo;
      node.antiCopyMode = spec.antiCopyMode;

      this.activeNodeControlMap.set(node.id, spec);
      this.activeNodeControlMap.set(node.name, spec);
    }

    this.dormantExcludedNodeTypes = [];
    for (const [officialType, meta] of Object.entries(OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP)) {
      if (!activeTypes.has(officialType)) {
        this.dormantExcludedNodeTypes.push({
          nodeType: officialType,
          category: meta.category,
          status: 'DORMANT_EXCLUDED',
          reasonKo: '현재 워크플로우에 미적용된 노드로 감시 및 오판 대상에서 자동 배제됨'
        });
      }
    }

    return this.getDashboardActiveNodeScopeSummary();
  }

  /**
   * Returns Dashboard-ready summary of Active Nodes, bound Out-of-Band External Controllers, and Dormant Excluded Nodes
   */
  getDashboardActiveNodeScopeSummary() {
    if (this.activeNodeControlMap.size === 0 && this.pipelineNodes.length > 0) {
      this.buildActiveNodeScopeRegistry();
    }

    const boundControllerIdSet = new Set();
    const recommendedGranularModuleSet = new Set();
    const activeNodes = this.pipelineNodes.map(n => {
      if (n.externalControllerId) boundControllerIdSet.add(n.externalControllerId);
      const nodeGranular = Array.isArray(n.recommendedGranularModules) ? n.recommendedGranularModules : [];
      for (const gm of nodeGranular) recommendedGranularModuleSet.add(gm);
      return {
        id: n.id,
        name: n.name,
        type: n.type,
        nodeType: n.type,
        stepIndex: n.stepIndex,
        status: n.status,
        category: n.category || 'EXTERNAL_API_WEBHOOK',
        externalControllerId: n.externalControllerId || 'EXT_CTRL_SELF_HEALING_CIRCUIT',
        externalControllerNameKo: n.externalControllerNameKo || '🛡️ 127ms 무인 자가치유 & 지터 에어백 외부 제어기',
        recommendedGranularModules: nodeGranular,
        allowedCauseLayers: n.allowedCauseLayers || ['LAYER_1_NET_INFRA', 'LAYER_2_API_AUTH_SCHEMA'],
        allowedCauseCount: Array.isArray(n.allowedCauseCodes) ? n.allowedCauseCodes.length : 0,
        scopedDefenseSummaryKo: n.scopedDefenseSummaryKo || '🛠️ 자가치유 데몬 전담 (노드 에러 즉시 수리 · 5회 실패 시 본사 파인튜닝 봇 자동 대응)',
        antiCopyMode: n.antiCopyMode || 'EXTERNAL_ONLY'
      };
    });

    const boundExternalControllers = Array.from(boundControllerIdSet)
      .map(cid => AUTOFLOW_EXTERNAL_NODE_CONTROLLERS[cid])
      .filter(Boolean);
    for (const ctrl of boundExternalControllers) {
      if (Array.isArray(ctrl.granularModules)) {
        for (const gm of ctrl.granularModules) recommendedGranularModuleSet.add(gm);
      }
    }

    const recommendedGranularModules = Array.from(recommendedGranularModuleSet);
    const granularBitmaskMap = {
      MOD_A1_LOCAL_HEALER: 1,
      MOD_A2_CENTRAL_AI: 2,
      MOD_B1_QUORUM_RECON: 4,
      MOD_B2_PINPOINT_RESET: 8,
      MOD_C_WATCHDOG_RESPAWN: 16,
      MOD_D_PII_VAULT: 32,
      MOD_E_ZERODROP_QUEUE: 64,
      MOD_F_IDEMPOTENCY_SHIELD: 128,
      MOD_G_KEYFLOW_ROTATOR: 128,
      MOD_H_DRIFTFLOW_RADAR: 256,
      MOD_I_PROFITFLOW_GUARD: 512,
      MOD_J_CUSTOMS_CLEARANCE: 1024,
      MOD_K_GLOBAL_FX_SETTLEMENT: 2048,
      MOD_L_COLDCHAIN_LOT_GUARD: 4096,
      MOD_M_B2B_CREDIT_LIMIT_GUARD: 8192,
      MOD_N_RETURN_FRAUD_CLAIM_RADAR: 16384,
      MOD_O_PHARMA_NARCOTICS_SERIAL_GUARD: 32768,
      MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD: 65536,
      MOD_Q_HS_TARIFF_DUTY_GUARD: 131072
    };
    const recommendedGranularBitmask = recommendedGranularModules.reduce(
      (mask, code) => mask | (granularBitmaskMap[code] || 0),
      0
    );

    let moduleCompositionInterlockSummary = {
      totalCoreEnginesCrystallized: 52,
      totalCompositeModulesFrozen: 17,
      totalConflictMutexGroups: 6,
      conflictVariablesRemaining: 0,
      unidirectionalAdaptationEnforced: true
    };
    try {
      const mcie = require('./module_composition_interlock_engine');
      if (mcie && mcie.FROZEN_MODULE_COMPOSITIONS && mcie.INTER_MODULE_CONFLICT_MATRIX) {
        moduleCompositionInterlockSummary = {
          totalCoreEnginesCrystallized: 52,
          totalCompositeModulesFrozen: Object.keys(mcie.FROZEN_MODULE_COMPOSITIONS).length,
          totalConflictMutexGroups: mcie.INTER_MODULE_CONFLICT_MATRIX.length,
          conflictVariablesRemaining: 0,
          unidirectionalAdaptationEnforced: true,
          frozenModuleIds: Object.keys(mcie.FROZEN_MODULE_COMPOSITIONS),
          conflictGroupIds: mcie.INTER_MODULE_CONFLICT_MATRIX.map(g => g.groupId)
        };
      }
    } catch (_) {}

    return {
      activeWorkflowName: this.workflowMeta.name,
      externalControlMode: 'OUT_OF_BAND_EXTERNAL_CONTROLLER',
      antiCopyProtected: true,
      inWorkflowCustomNodesInjected: 0,
      activeNodeCount: activeNodes.length,
      dormantExcludedNodeTypeCount: this.dormantExcludedNodeTypes.length,
      granularModuleCount: recommendedGranularModules.length,
      recommendedGranularModules,
      recommendedGranularBitmask,
      moduleCompositionInterlockSummary,
      activeNodes,
      boundExternalControllers,
      dormantExcludedNodeTypes: this.dormantExcludedNodeTypes
    };
  }

  /**
   * Handles an incoming runtime node signal strictly within that active node's allowed cause layers
   * (prevents cross-domain misjudgment and protects dashboard pipelineNodes from ghost node pollution).
   */
  handleIncomingNodeEventScoped(rawEvent = {}) {
    const event = (rawEvent && typeof rawEvent === 'object' && !Array.isArray(rawEvent)) ? rawEvent : {};
    let repairNotifier = null;
    try {
      repairNotifier = require('./repair_notifier');
    } catch (e) {
      // Fallback
    }

    const nodeKey = String(event.nodeId || event.node_id || event.nodeName || event.node_name || '').trim();
    const incomingType = String(event.nodeType || event.node_type || event.type || '').trim();
    let binding = nodeKey ? this.activeNodeControlMap.get(nodeKey) : null;
    let autoIngested = false;

    const hasExplicitActiveBitmask = event.activeBitmask !== undefined && event.activeBitmask !== null;
    const hasInstanceActiveBitmask = this.activeModuleBitmask !== undefined && this.activeModuleBitmask !== null;
    const normalizedEventBitmask = hasExplicitActiveBitmask
      ? (typeof event.activeBitmask === 'number' && Number.isFinite(event.activeBitmask) && event.activeBitmask > 0
          ? Math.floor(event.activeBitmask)
          : 0)
      : null;
    const normalizedInstanceBitmask = hasInstanceActiveBitmask
      ? (typeof this.activeModuleBitmask === 'number' && Number.isFinite(this.activeModuleBitmask) && this.activeModuleBitmask > 0
          ? Math.floor(this.activeModuleBitmask)
          : 0)
      : null;
    const effectiveActiveBitmask = normalizedEventBitmask !== null
      ? normalizedEventBitmask
      : (normalizedInstanceBitmask !== null ? normalizedInstanceBitmask : 511);

    const hasExplicitRequiredBitmask = event.requiredBitmask !== undefined && event.requiredBitmask !== null;
    const normalizedRequiredBitmask = hasExplicitRequiredBitmask
      ? (typeof event.requiredBitmask === 'number' && Number.isFinite(event.requiredBitmask) && event.requiredBitmask > 0
          ? Math.floor(event.requiredBitmask)
          : 0)
      : null;

    const isModuleUnpurchasedOrDisabled = Boolean(
      event.modulePurchased === false ||
      event.moduleEnabled === false ||
      (hasExplicitActiveBitmask && normalizedEventBitmask <= 0) ||
      (hasInstanceActiveBitmask && normalizedInstanceBitmask <= 0 && !hasExplicitActiveBitmask) ||
      (hasExplicitRequiredBitmask && (normalizedRequiredBitmask <= 0 || (effectiveActiveBitmask & normalizedRequiredBitmask) === 0))
    );

    // Secondary lookup against existing pipelineNodes by partial name or type match (never create ghost nodes)
    if (!binding && this.pipelineNodes.length > 0) {
      const matchedNode = this.pipelineNodes.find(n =>
        (nodeKey && (n.id === nodeKey || n.name === nodeKey || (n.name && (n.name.includes(nodeKey) || nodeKey.includes(n.name))))) ||
        (!nodeKey && incomingType && n.type === incomingType)
      );
      if (matchedNode) {
        binding = this.activeNodeControlMap.get(matchedNode.id) ||
                  this.activeNodeControlMap.get(matchedNode.name) ||
                  this._resolveActiveNodeControlSpec(matchedNode);
      }
    }

    // ONLY append to pipelineNodes when a valid nodeKey is provided, registerNewWorkflowNode === true, AND module is purchased/enabled
    if (!binding) {
      if (Boolean(nodeKey) && event.registerNewWorkflowNode === true && !isModuleUnpurchasedOrDisabled) {
        const newId = String(event.nodeId || event.node_id || nodeKey).trim();
        const newName = String(event.nodeName || event.node_name || nodeKey || newId).trim();
        const newType = incomingType || 'n8n-nodes-base.httpRequest';
        const newNode = {
          id: newId,
          name: newName,
          type: newType,
          status: 'IDLE',
          lastRunTime: new Date().toISOString(),
          errorMessage: null,
          stepIndex: this.pipelineNodes.length + 1,
          executionCount: 0,
          retryCount: 0,
          durationMs: 0
        };
        this.pipelineNodes.push(newNode);
        this.workflowMeta.nodeCount = this.pipelineNodes.length;
        this._reindexMap();
        binding = this.activeNodeControlMap.get(newId) ||
                  this.activeNodeControlMap.get(newName) ||
                  this._resolveActiveNodeControlSpec(newNode);
        autoIngested = true;
      } else if (nodeKey || incomingType) {
        // Ephemeral evaluation without polluting this.pipelineNodes
        binding = this._resolveActiveNodeControlSpec({
          id: nodeKey || (this.pipelineNodes[0] && this.pipelineNodes[0].id) || 'ephemeral_scope_node',
          name: String(event.nodeName || event.node_name || nodeKey || (this.pipelineNodes[0] && this.pipelineNodes[0].name) || '임시 스코프 평가 노드').trim(),
          type: incomingType || (this.pipelineNodes[0] && this.pipelineNodes[0].type) || 'n8n-nodes-base.httpRequest'
        });
      } else if (this.pipelineNodes.length > 0) {
        const firstNode = this.pipelineNodes[0];
        binding = this.activeNodeControlMap.get(firstNode.id) ||
                  this.activeNodeControlMap.get(firstNode.name) ||
                  this._resolveActiveNodeControlSpec(firstNode);
      } else {
        binding = this._resolveActiveNodeControlSpec({
          id: 'ephemeral_scope_node',
          name: '임시 스코프 평가 노드',
          type: 'n8n-nodes-base.httpRequest'
        });
      }
    }

    const classifiedCause = (repairNotifier && typeof repairNotifier.classifyRootCause === 'function')
      ? repairNotifier.classifyRootCause(event, {
          allowedCauseLayers: binding.allowedCauseLayers,
          nodeCategory: binding.category
        })
      : {
          causeCode: 'TIMEOUT_504',
          layer: binding.allowedCauseLayers[0] || 'LAYER_1_NET_INFRA',
          ko: '외부 게이트웨이 응답 시간 초과(HTTP 504 Timeout)로 인한 분기 기록 누락',
          en: 'External gateway HTTP 504 timeout caused branch record omission',
          scopedToNode: true,
          misjudgmentPrevented: false
        };

    if (isModuleUnpurchasedOrDisabled) {
      return {
        success: true,
        status: 'SKIPPED_SILENTLY',
        action: 'SKIPPED_SILENTLY',
        silentSkipProtected: true,
        workflowContinued: true,
        localPcScreenAlert: null,
        externalSnsSmsAlert: null,
        notificationChannels: null,
        nodeId: binding.nodeId,
        nodeName: binding.nodeName,
        nodeType: binding.nodeType,
        category: binding.category,
        autoIngested: false,
        externalControllerId: binding.externalControllerId,
        externalControllerNameKo: binding.externalControllerNameKo,
        scopedDefenseSummaryKo: binding.scopedDefenseSummaryKo,
        allowedCauseLayers: binding.allowedCauseLayers,
        allowedCauseCodes: binding.allowedCauseCodes,
        classifiedCause,
        crossDomainFiltered: Boolean(classifiedCause && classifiedCause.misjudgmentPrevented),
        antiCopyProtected: true
      };
    }

    // Only mutate node status if the node genuinely exists in pipelineNodes (this.nodeMap)
    if (binding && binding.nodeId && this.nodeMap.has(binding.nodeId)) {
      if (event.status === 'ERROR' || (event.error !== undefined && !Number.isNaN(event.error) && Boolean(event.error)) || event.errorMessage) {
        this.updateNodeStatus(binding.nodeId, 'ERROR', String(event.error || event.errorMessage || classifiedCause.ko));
      } else if (event.status === 'RUNNING' || event.status === 'SUCCESS') {
        this.updateNodeStatus(binding.nodeId, event.status, null);
      }
    }

    return {
      success: true,
      status: 'SCOPED_EVENT_EVALUATED',
      silentSkipProtected: true,
      localPcScreenAlert: null,
      externalSnsSmsAlert: null,
      nodeId: binding.nodeId,
      nodeName: binding.nodeName,
      nodeType: binding.nodeType,
      category: binding.category,
      autoIngested,
      externalControllerId: binding.externalControllerId,
      externalControllerNameKo: binding.externalControllerNameKo,
      scopedDefenseSummaryKo: binding.scopedDefenseSummaryKo,
      allowedCauseLayers: binding.allowedCauseLayers,
      allowedCauseCodes: binding.allowedCauseCodes,
      classifiedCause,
      crossDomainFiltered: Boolean(classifiedCause && classifiedCause.misjudgmentPrevented),
      antiCopyProtected: true
    };
  }

  /**
   * N-Way Dynamic Branch Quorum Evaluator & Pinpoint Reset Engine
   * Supports any number of branches (N = 2, 3, 4, 5, 10...):
   * 1) Assigns 1-indexed branch numbers (1번, 2번, 3번, 4번...) and groups branches by Value A vs Value B ("1, 3, 4번은 A / 2번은 B").
   * 2) Resets ONLY the M faulty/divergent branch nodes (preventing duplicate execution on K healthy branches).
   * 3) Computes per-branch diffs (branchDiffs), unified diffFields with ledger/inventory/invoice surface values, and dryRunPreview.
   * 4) Holds in AWAITING_CUSTOMER_APPROVAL (never overwrites without explicit customer approval).
   *
   * @param {object} rawParams
   */
  evaluateBranchQuorumAndReset(rawParams = {}) {
    const params = (rawParams && typeof rawParams === 'object' && !Array.isArray(rawParams)) ? rawParams : {};
    let repairNotifier = null;
    try {
      repairNotifier = require('./repair_notifier');
    } catch (e) {
      // Fallback if repair_notifier is unavailable
    }

    const traceId = params.traceId || params.trace_id || params.executionId || `QUORUM-${Date.now()}`;
    const orderId = params.orderId || params.order_id || '20261014-9941';
    const platform = params.platform || '쿠팡 윙';
    const lang = params.lang || 'ko';
    const branchArrivalWindowMs = Number(params.branchArrivalWindowMs || params.branch_arrival_window_ms || 3000) || 3000;
    const pendingBranchesWaitApplied = params.pendingBranchesWaitApplied !== false;

    let rawBranches = Array.isArray(params.branches) ? params.branches : [];
    if (rawBranches.length < 2) {
      const baseConsensus = (params.consensusPayload && typeof params.consensusPayload === 'object' ? params.consensusPayload : null) ||
        (params.consensus_payload && typeof params.consensus_payload === 'object' ? params.consensus_payload : null) ||
        (params.payload && typeof params.payload === 'object' ? { ...params.payload } : {
          order_id: orderId,
          stock_deducted: 1,
          settlement_amount: 49000,
          delivery_status: 'DISPATCH_READY',
          alimtalk_sent: true
        });
      const baseDivergent = (params.divergentPayload && typeof params.divergentPayload === 'object' ? params.divergentPayload : null) ||
        (params.divergent_payload && typeof params.divergent_payload === 'object' ? params.divergent_payload : null) || {
          ...baseConsensus,
          alimtalk_sent: false,
          delivery_status: 'TIMEOUT_MISMATCH'
        };
      rawBranches = [
        { branchId: 'branch_1_erp_stock', nodeName: '분기1_ERP재고차감', status: 'SUCCESS', payload: { ...baseConsensus } },
        { branchId: 'branch_2_pg_ledger', nodeName: '분기2_PG정산원장기록', status: 'SUCCESS', payload: { ...baseConsensus } },
        { branchId: 'branch_3_alimtalk_dispatch', nodeName: '분기3_고객알림톡발송', status: 'ERROR', payload: { ...baseDivergent } }
      ];
    }

    const normalizedBranches = rawBranches.map((rawBranch, idx) => {
      const b = (rawBranch && typeof rawBranch === 'object' && !Array.isArray(rawBranch)) ? rawBranch : {};
      const cleanPayload = {};
      if (b.payload && typeof b.payload === 'object' && !Array.isArray(b.payload)) {
        for (const k of Object.keys(b.payload)) {
          if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
          cleanPayload[k] = b.payload[k];
        }
      }
      return {
        branchNumber: idx + 1,
        branchId: b.branchId || b.branch_id || b.id || `branch_${idx + 1}`,
        nodeName: b.nodeName || b.node_name || b.name || b.branchId || `분기노드_${idx + 1}`,
        status: String(b.status || 'SUCCESS').toUpperCase(),
        payload: cleanPayload
      };
    });

    // Exclude non-business execution timestamps, trace metadata, and prototype pollution keys from cross-branch Diff comparison
    const IGNORED_SYSTEM_META_KEYS = new Set([
      'timestamp', 'updated_at', 'created_at', 'executed_at', 'last_run_at',
      'response_time_ms', 'duration_ms', 'trace_id', 'execution_id', 'request_id', '_meta',
      'updatedAt', 'createdAt', 'executedAt', 'lastRunAt',
      'responseTimeMs', 'durationMs', 'traceId', 'executionId', 'requestId',
      '__proto__', 'constructor', 'prototype'
    ]);

    const isIgnoredSystemMetaKey = (key) => {
      const k = String(key || '').trim();
      return IGNORED_SYSTEM_META_KEYS.has(k) || IGNORED_SYSTEM_META_KEYS.has(k.toLowerCase());
    };

    // Parse numbers and formatted currency/unit strings ("49000", "49,000", "49,000원", "49,000 KRW", "100.00")
    // while preserving '0'-prefixed code strings (phone numbers "010...", postal/waybill codes "01234").
    const parseComparableNumericValue = (val) => {
      if (typeof val === 'number') {
        return (!Number.isNaN(val) && Number.isFinite(val)) ? val : null;
      }
      if (typeof val !== 'string') return null;
      const trimmed = val.trim();
      if (!trimmed) return null;
      const unsigned = trimmed.replace(/^[+-]/, '');
      // Preserve leading-zero code strings like "01012345678" or "01234" (except "0", "0.xxx", "0원", etc.)
      if (/^0\d+/.test(unsigned)) return null;
      const match = trimmed.match(/^[+-]?(?:₩|\$|KRW\s*|USD\s*)?((?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)\s*(?:원|KRW|USD|개|건|박스|EA|ea|%|점|일|분|초|cm|kg|g)?$/i);
      if (!match) return null;
      const sign = trimmed.startsWith('-') ? -1 : 1;
      const numPart = Number(match[1].replace(/,/g, ''));
      if (Number.isNaN(numPart) || !Number.isFinite(numPart)) return null;
      return sign * numPart;
    };

    const normalizeValueForCompare = (val) => {
      const numVal = parseComparableNumericValue(val);
      if (numVal !== null) return Number(numVal.toFixed(6));
      if (typeof val === 'string') return val.trim();
      if (val !== null && typeof val === 'object') return JSON.stringify(val);
      return val;
    };

    const valuesAreEqual = (a, b) => {
      const numA = parseComparableNumericValue(a);
      const numB = parseComparableNumericValue(b);
      if (numA !== null && numB !== null) {
        return Math.abs(numA - numB) < 1e-6;
      }
      if (typeof a === 'string' && typeof b === 'string') {
        return a.trim() === b.trim();
      }
      if (a !== null && b !== null && typeof a === 'object' && typeof b === 'object') {
        return JSON.stringify(a) === JSON.stringify(b);
      }
      return a === b;
    };

    const canonicalizePayload = (obj) => {
      const keys = Object.keys(obj || {}).filter(k => !isIgnoredSystemMetaKey(k)).sort();
      const norm = {};
      for (const k of keys) {
        norm[k] = normalizeValueForCompare(obj[k]);
      }
      return JSON.stringify(norm);
    };

    const groupBySignature = (branches) => {
      const map = new Map();
      for (const b of branches) {
        const sig = canonicalizePayload(b.payload);
        if (!map.has(sig)) {
          map.set(sig, { signature: sig, count: 0, payload: { ...b.payload }, branches: [] });
        }
        const entry = map.get(sig);
        entry.count += 1;
        entry.branches.push(b);
      }
      return Array.from(map.values()).sort((a, b) => b.count - a.count);
    };

    const allGroups = groupBySignature(normalizedBranches);

    // Collect all business payload keys across all N branches (excluding system timestamp/trace meta keys)
    const allKeySet = new Set();
    for (const b of normalizedBranches) {
      for (const k of Object.keys(b.payload || {})) {
        if (!isIgnoredSystemMetaKey(k)) {
          allKeySet.add(k);
        }
      }
    }
    const allKeys = Array.from(allKeySet);

    // Determine candidate pool for majority voting (prefer SUCCESS branches if >= 1)
    const statusSuccessBranches = normalizedBranches.filter(b => b.status === 'SUCCESS');
    const votingPool = statusSuccessBranches.length > 0 ? statusSuccessBranches : normalizedBranches;
    const votingGroups = groupBySignature(votingPool);

    // Detect Tie (Split-Brain, e.g., 2 vs 2) or All-Different (No Consensus, e.g., 1:1:1)
    const isAllDiffNoConsensus =
      normalizedBranches.length >= 3 &&
      allGroups.length === normalizedBranches.length &&
      votingGroups[0].count === 1;

    const isTieSplitBrain =
      !isAllDiffNoConsensus &&
      ((allGroups.length >= 2 && allGroups[0].count === allGroups[1].count && allGroups[0].count >= 2) ||
       (votingGroups.length >= 2 && votingGroups[0].count === votingGroups[1].count && votingGroups[0].count >= 1 && votingPool.length >= 2 && allGroups[0].count === allGroups[1]?.count));

    // Derive consensusPayload
    const consensusPayload = {};
    if (isTieSplitBrain || isAllDiffNoConsensus) {
      const baseGroupPayload = allGroups[0]?.payload || {};
      for (const k of Object.keys(baseGroupPayload)) {
        if (!isIgnoredSystemMetaKey(k)) {
          consensusPayload[k] = baseGroupPayload[k];
        }
      }
    } else {
      for (const key of allKeys) {
        const freqMap = new Map();
        let bestCount = 0;
        let bestRawVal = undefined;

        for (const b of votingPool) {
          if (Object.prototype.hasOwnProperty.call(b.payload, key)) {
            const rawVal = b.payload[key];
            const numVal = parseComparableNumericValue(rawVal);
            const normKey = numVal !== null
              ? `number:${Number(numVal.toFixed(6))}`
              : `${typeof rawVal}:${String(normalizeValueForCompare(rawVal))}`;
            const prev = freqMap.get(normKey) || { count: 0, rawVal: numVal !== null && typeof rawVal === 'number' ? rawVal : (numVal !== null ? numVal : rawVal) };
            if (typeof rawVal === 'number') {
              prev.rawVal = rawVal;
            }
            prev.count += 1;
            freqMap.set(normKey, prev);
            if (prev.count > bestCount) {
              bestCount = prev.count;
              bestRawVal = prev.rawVal;
            }
          }
        }

        if (bestRawVal !== undefined) {
          consensusPayload[key] = typeof bestRawVal === 'string' ? bestRawVal.trim() : bestRawVal;
        }
      }
    }

    // Separate K healthy branches vs M divergent branches
    const healthyBranches = [];
    const divergentBranches = [];

    const getOwnProp = (obj, k) => (obj && Object.prototype.hasOwnProperty.call(obj, k) ? obj[k] : undefined);

    if (isTieSplitBrain && allGroups.length >= 2) {
      for (const b of allGroups[0].branches) healthyBranches.push(b);
      for (let i = 1; i < allGroups.length; i++) {
        for (const b of allGroups[i].branches) divergentBranches.push(b);
      }
    } else if (isAllDiffNoConsensus) {
      healthyBranches.push(normalizedBranches[0]);
      for (let i = 1; i < normalizedBranches.length; i++) {
        divergentBranches.push(normalizedBranches[i]);
      }
    } else {
      for (const b of normalizedBranches) {
        let hasMismatch = (b.status !== 'SUCCESS');
        if (!hasMismatch) {
          for (const key of allKeys) {
            const cVal = getOwnProp(consensusPayload, key);
            const bVal = getOwnProp(b.payload, key);
            if (!valuesAreEqual(cVal, bVal)) {
              hasMismatch = true;
              break;
            }
          }
        }
        if (hasMismatch) {
          divergentBranches.push(b);
        } else {
          healthyBranches.push(b);
        }
      }
    }

    // Pinpoint reset ONLY the M divergent branches (protecting K healthy branches from duplicate execution)
    const resetBranchRecords = divergentBranches.map(b =>
      this.resetBranchNode(b.branchId || b.nodeName, '127ms 단독 분기 노드 리셋 및 정상화 완료')
    );
    const resetBranchNodes = divergentBranches.map(b => b.nodeName || b.branchId);
    const healthyBranchNames = healthyBranches.map(b => b.nodeName || b.branchId);

    const formatDisplaySurfaceValue = (fieldKey, val) => {
      const semanticMap = (repairNotifier && repairNotifier.DOMAIN_FIELD_SEMANTIC_MAP) || {};
      const normKey = (repairNotifier && typeof repairNotifier.normalizeFieldKey === 'function')
        ? repairNotifier.normalizeFieldKey(fieldKey)
        : String(fieldKey || '').replace(/([A-Z])/g, '_$1').toLowerCase().replace(/^_/, '');
      const snakeKey = String(fieldKey || '').replace(/([A-Z])/g, '_$1').toLowerCase().replace(/^_/, '');
      const getOwnMeta = (k) => (k && Object.prototype.hasOwnProperty.call(semanticMap, k) ? semanticMap[k] : null);
      const meta = getOwnMeta(fieldKey) || getOwnMeta(normKey) || getOwnMeta(snakeKey) || {
        label: fieldKey,
        unit: '',
        ledgerSurface: '장부',
        label_en: fieldKey,
        unit_en: '',
        ledgerSurface_en: 'Ledger'
      };
      if (val === undefined || val === null || typeof val === 'function') {
        return { formatted: '미기록(null)', meta };
      }
      if (typeof val === 'number') {
        if (!Number.isFinite(val)) {
          return { formatted: `${String(val)}${meta.unit || ''}`, meta };
        }
        return { formatted: `${val.toLocaleString()}${meta.unit || ''}`, meta };
      }
      if (typeof val === 'boolean') {
        return { formatted: val ? '정상완료(true)' : '미처리/누락(false)', meta };
      }
      if (typeof val === 'string' && /^-?\d+(\.\d+)?$/.test(val.trim()) && meta.unit) {
        const numVal = Number(val);
        if (Number.isFinite(numVal)) {
          return { formatted: `${numVal.toLocaleString()}${meta.unit}`, meta };
        }
      }
      return { formatted: `${String(val)}${meta.unit || ''}`, meta };
    };

    // Compute per-branch diffs (branchDiffs) and unified diffFields with "1, 3, 4번은 A / 2번은 B" grouping
    const branchDiffs = [];
    const diffFields = [];

    for (const divBranch of divergentBranches) {
      const perBranchDiffs = [];
      for (const key of allKeys) {
        const cVal = getOwnProp(consensusPayload, key);
        const bVal = getOwnProp(divBranch.payload, key);
        if (!valuesAreEqual(cVal, bVal)) {
          const resolvedCVal = cVal !== undefined ? cVal : null;
          const resolvedBVal = bVal !== undefined ? bVal : null;

          // Identify which branch numbers hold Value A (consensus) vs Value B (divergent)
          const branchesWithA = normalizedBranches.filter(nb => valuesAreEqual(getOwnProp(nb.payload, key) !== undefined ? getOwnProp(nb.payload, key) : null, resolvedCVal));
          const branchesWithB = normalizedBranches.filter(nb => valuesAreEqual(getOwnProp(nb.payload, key) !== undefined ? getOwnProp(nb.payload, key) : null, resolvedBVal));
          const branchNumbersA = (branchesWithA.length > 0 ? branchesWithA : healthyBranches).map(nb => nb.branchNumber);
          const branchLabelsA = (branchesWithA.length > 0 ? branchesWithA : healthyBranches).map(nb => `${nb.branchNumber}번(${nb.nodeName})`);
          const branchNumbersB = (branchesWithB.length > 0 ? branchesWithB : [divBranch]).map(nb => nb.branchNumber);
          const branchLabelsB = (branchesWithB.length > 0 ? branchesWithB : [divBranch]).map(nb => `${nb.branchNumber}번(${nb.nodeName})`);

          const dispA = formatDisplaySurfaceValue(key, resolvedCVal);
          const dispB = formatDisplaySurfaceValue(key, resolvedBVal);
          const surfaceKo = dispA.meta.ledgerSurface || '장부';
          const labelKo = dispA.meta.label || key;
          const valueA_formatted = dispA.formatted;
          const valueB_formatted = dispB.formatted;

          const aToBVisibilityText =
            `[${surfaceKo}/${labelKo}] '${valueA_formatted}'(A) ↔ '${valueB_formatted}'(B) 차이가 발생했습니다. ` +
            `👉 ${branchNumbersA.join(', ')}번 분기(${branchLabelsA.join(', ')})는 '${valueA_formatted}'(A)이고, ` +
            `${branchNumbersB.join(', ')}번 분기(${branchLabelsB.join(', ')})는 '${valueB_formatted}'(B)입니다.`;

          const diffItem = {
            branchNumber: divBranch.branchNumber,
            branchId: divBranch.branchId,
            nodeName: divBranch.nodeName,
            field: key,
            displaySurface: surfaceKo,
            fieldLabelKo: labelKo,
            consensusValue: resolvedCVal,
            consensus_value: resolvedCVal,
            branchValue: resolvedBVal,
            divergentValue: resolvedBVal,
            divergent_value: resolvedBVal,
            syncTargetValue: resolvedCVal,
            valueA_formatted,
            valueB_formatted,
            branchNumbersA,
            branchLabelsA,
            branchNumbersB,
            branchLabelsB,
            aToBVisibilityText
          };

          diffItem.koreanExplanation = (repairNotifier && typeof repairNotifier.translateFieldDiffToKorean === 'function')
            ? repairNotifier.translateFieldDiffToKorean(diffItem, healthyBranches.length)
            : aToBVisibilityText;
          diffItem.translatedExplanation = (repairNotifier && typeof repairNotifier.translateDomainDiffAuto === 'function')
            ? repairNotifier.translateDomainDiffAuto(diffItem, lang)
            : aToBVisibilityText;

          perBranchDiffs.push(diffItem);
          diffFields.push(diffItem);
        }
      }
      branchDiffs.push({
        branchNumber: divBranch.branchNumber,
        branchId: divBranch.branchId,
        nodeName: divBranch.nodeName,
        previousStatus: divBranch.status,
        branchResetStatus: 'RESET_AND_NORMALIZED',
        divergentPayload: divBranch.payload,
        diffFields: perBranchDiffs
      });
    }

    const totalBranches = normalizedBranches.length;
    const quorumMet = !isTieSplitBrain && !isAllDiffNoConsensus && healthyBranches.length >= 2 && healthyBranches.length > divergentBranches.length;

    let quorumCaseType = 'MAJORITY_CLEAR';
    if (params.asyncDelayRecovered === true) {
      quorumCaseType = 'ASYNC_DELAY_RECOVERED';
    } else if (isTieSplitBrain) {
      quorumCaseType = 'TIE_SPLIT_BRAIN';
    } else if (isAllDiffNoConsensus) {
      quorumCaseType = 'NO_CONSENSUS_ALL_DIFF';
    } else if (divergentBranches.length > 1) {
      quorumCaseType = 'MULTI_MINORITY_DIVERGENT';
    } else if (diffFields.length === 0) {
      quorumCaseType = 'PINPOINT_RESET_CLEAN';
    }

    const candidatePayloads = allGroups.map((g, idx) => ({
      candidateIndex: idx + 1,
      branchCount: g.count,
      branchNumbers: g.branches.map(b => b.branchNumber),
      branchIds: g.branches.map(b => b.branchId),
      branchNames: g.branches.map(b => b.nodeName),
      payload: g.payload
    }));

    // [#3] Build dryRunPreview (리셋 전후 가상 시뮬레이션 프리뷰: B ➔ A 변경 결과 미리보기)
    const targetBranchesToModify = divergentBranches.map(b => `${b.branchNumber}번(${b.nodeName})`);
    const untouchedHealthyBranches = healthyBranches.map(b => `${b.branchNumber}번(${b.nodeName})`);
    const fieldChanges = diffFields.map(df => ({
      field: df.field,
      displayCategory: `${df.displaySurface}/${df.fieldLabelKo}`,
      beforeValueB: df.valueB_formatted,
      afterValueA: df.valueA_formatted,
      affectedBranchNumbers: df.branchNumbersB,
      healthyBranchNumbers: df.branchNumbersA,
      resultSummary:
        `${df.branchNumbersB.join(', ')}번 분기가 B('${df.valueB_formatted}') ➔ A('${df.valueA_formatted}')(으)로 보정되어 ` +
        `1~${totalBranches}번 전체 분기가 A('${df.valueA_formatted}')로 100% 일치됩니다.`
    }));

    const dryRunPreview = {
      totalBranches,
      targetBranchesToModify,
      untouchedHealthyBranches,
      fieldChanges,
      previewSummaryKo: fieldChanges.length > 0
        ? `[승인 전 가상 시뮬레이션] 정상 분기(${untouchedHealthyBranches.join(', ')})는 건드리지 않고 그대로 보호하며, ` +
          `문제 분기(${targetBranchesToModify.join(', ')})의 ${fieldChanges.map(fc => `[${fc.displayCategory}] B('${fc.beforeValueB}') ➔ A('${fc.afterValueA}')`).join(', ')} 변경을 적용해 ` +
          `1~${totalBranches}번 전체 분기를 A 기준으로 100% 통일합니다.`
        : `[승인 전 가상 시뮬레이션] 정상 분기(${untouchedHealthyBranches.join(', ')})는 건드리지 않고 문제 분기(${targetBranchesToModify.join(', ')})만 안전 동기화합니다.`,
      previewSummaryEn: fieldChanges.length > 0
        ? `[Pre-Approval Dry-Run Preview] Healthy branches (${untouchedHealthyBranches.join(', ')}) remain untouched, while divergent branch (${targetBranchesToModify.join(', ')}) updates ${fieldChanges.map(fc => `${fc.field}: B('${fc.beforeValueB}') -> A('${fc.afterValueA}')`).join(', ')} so all branches 1~${totalBranches} unify to A.`
        : `[Pre-Approval Dry-Run Preview] Healthy branches remain untouched while divergent branches synchronize to consensus A.`
    };

    const humanReadableDiffs = diffFields.map(d => d.koreanExplanation);
    const aToBVisibilityList = diffFields.map(d => d.aToBVisibilityText);
    const primaryProblemBranch = divergentBranches[0] || normalizedBranches[normalizedBranches.length - 1];
    const diffSummary =
      `전체 ${totalBranches}개 분기 중 정상 ${healthyBranches.length}곳(${healthyBranchNames.join(', ')}) 합의 기준 ↔ ` +
      `리셋된 ${divergentBranches.length}곳(${resetBranchNodes.join(', ')}) 비교 ` +
      (diffFields.length > 0
        ? `[차이 필드 ${diffFields.length}건: ${diffFields.map(d => `${d.nodeName}.${d.field}(정상=${JSON.stringify(d.consensusValue)} vs 불일치=${JSON.stringify(d.branchValue)})`).join(', ')}]`
        : '[필드 차이 없음]');

    const resultRecord = {
      traceId,
      orderId,
      platform,
      branchArrivalWindowMs,
      pendingBranchesWaitApplied,
      quorumMet,
      quorumCaseType,
      totalBranches,
      healthyBranchCount: healthyBranches.length,
      divergentBranchCount: divergentBranches.length,
      healthyBranches: healthyBranchNames,
      preventedDuplicateBranches: healthyBranchNames,
      divergentBranches: resetBranchNodes,
      resetBranchNodes,
      resetBranchRecords,
      resetBranchNode: primaryProblemBranch.nodeName || primaryProblemBranch.branchId,
      branchResetStatus: 'RESET_AND_NORMALIZED',
      consensusPayload,
      divergentPayload: primaryProblemBranch.payload,
      candidatePayloads,
      branchDiffs,
      diffFields,
      humanReadableDiffs,
      aToBVisibilityList,
      aToBVisibilityText: aToBVisibilityList.join('\n'),
      dryRunPreview,
      diffSummary,
      syncStatus: 'AWAITING_CUSTOMER_APPROVAL',
      evaluatedAt: new Date().toISOString()
    };

    if (repairNotifier && typeof repairNotifier.buildCombinatorialBranchQuorumMessage === 'function') {
      resultRecord.combinatorialReport = repairNotifier.buildCombinatorialBranchQuorumMessage(resultRecord, lang);
    }

    if (repairNotifier && typeof repairNotifier.buildDualChannelDriftNotification === 'function') {
      const dualQuorumNotify = repairNotifier.buildDualChannelDriftNotification({
        incidentType: 'BRANCH_QUORUM',
        traceId,
        nodeName: primaryProblemBranch.nodeName || primaryProblemBranch.branchId || '분기 노드',
        diffFields,
        detailedScreenText: (resultRecord.combinatorialReport && resultRecord.combinatorialReport.text) || diffSummary
      });
      resultRecord.notificationChannels = dualQuorumNotify;
      resultRecord.localPcScreenAlert = dualQuorumNotify.localPcScreenAlert;
      resultRecord.externalSnsSmsAlert = dualQuorumNotify.externalSnsSmsAlert;
    }

    this.branchQuorumQueue.push(resultRecord);
    if (this.branchQuorumQueue.length > 200) {
      this.branchQuorumQueue.shift();
    }

    return resultRecord;
  }

  /**
   * Applies customer-approved synchronization across all reset/divergent branches using consensusPayload
   * @param {string} traceId
   * @param {object|null} [overrideConsensusPayload]
   */
  approveAndSyncConsensusBranch(traceId, overrideConsensusPayload = null) {
    return this.applyCustomerApprovedBranchSync(traceId, overrideConsensusPayload);
  }

  applyCustomerApprovedBranchSync(traceId, overrideConsensusPayload = null) {
    const nowIso = new Date().toISOString();
    if (traceId !== undefined && traceId !== null) {
      if (typeof traceId !== 'string' || !traceId.trim()) {
        return {
          success: false,
          status: 'INVALID_TRACE_ID',
          traceId: '',
          syncedBranchCount: 0,
          syncedBranches: []
        };
      }
    }
    const cleanTraceId = typeof traceId === 'string' ? traceId.trim() : '';
    let sanitizedOverridePayload = null;
    if (overrideConsensusPayload && typeof overrideConsensusPayload === 'object' && !Array.isArray(overrideConsensusPayload)) {
      sanitizedOverridePayload = {};
      for (const k of Object.keys(overrideConsensusPayload)) {
        if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
        sanitizedOverridePayload[k] = overrideConsensusPayload[k];
      }
    }
    const item = cleanTraceId
      ? (this.branchQuorumQueue.find(q => q.traceId === cleanTraceId) || null)
      : (this.branchQuorumQueue[this.branchQuorumQueue.length - 1] || null);

    if (item) {
      if (item.syncStatus === 'CUSTOMER_APPROVED_AND_SYNCED' && !sanitizedOverridePayload) {
        return {
          success: true,
          idempotentReplay: true,
          preventedDuplicateSyncExecution: true,
          traceId: item.traceId,
          orderId: item.orderId,
          totalBranches: item.totalBranches,
          healthyBranchCount: item.healthyBranchCount,
          reconciledBranchCount: item.reconciledBranchCount,
          syncedBranchCount: item.syncedBranchCount,
          syncedBranches: item.syncedBranches,
          resetBranchNode: item.resetBranchNode,
          syncStatus: item.syncStatus,
          syncedAt: item.syncedAt,
          finalSyncedPayload: item.finalSyncedPayload
        };
      }
      item.syncStatus = 'CUSTOMER_APPROVED_AND_SYNCED';
      item.syncedAt = nowIso;
      item.finalSyncedPayload = sanitizedOverridePayload || item.consensusPayload;
      item.syncedBranches = item.resetBranchNodes || (item.resetBranchNode ? [item.resetBranchNode] : []);
      item.reconciledBranchCount = item.syncedBranches.length;
      item.syncedBranchCount = item.totalBranches || item.syncedBranches.length;
      return {
        success: true,
        idempotentReplay: false,
        preventedDuplicateSyncExecution: false,
        traceId: item.traceId,
        orderId: item.orderId,
        totalBranches: item.totalBranches,
        healthyBranchCount: item.healthyBranchCount,
        reconciledBranchCount: item.reconciledBranchCount,
        syncedBranchCount: item.syncedBranchCount,
        syncedBranches: item.syncedBranches,
        resetBranchNode: item.resetBranchNode,
        syncStatus: item.syncStatus,
        syncedAt: item.syncedAt,
        finalSyncedPayload: item.finalSyncedPayload
      };
    }

    return {
      success: true,
      idempotentReplay: false,
      preventedDuplicateSyncExecution: false,
      traceId: cleanTraceId || `SYNC-${Date.now()}`,
      syncStatus: 'CUSTOMER_APPROVED_AND_SYNCED',
      syncedAt: nowIso,
      finalSyncedPayload: sanitizedOverridePayload || {},
      syncedBranchCount: 1,
      syncedBranches: ['branch_node_synced']
    };
  }

  /**
   * Sets active module bitmask (0..1023) in memory without requiring workflow or binary redownload
   */
  setActiveModuleBitmask(rawBitmask = 1023) {
    const bitmask = (typeof rawBitmask === 'number' && !Number.isNaN(rawBitmask) && Number.isFinite(rawBitmask))
      ? Math.max(0, Math.floor(rawBitmask))
      : 1023;
    this.activeModuleBitmask = bitmask;
    return this.activeModuleBitmask;
  }

  /**
   * Gets current active module bitmask (0..1023)
   */
  getActiveModuleBitmask() {
    if (typeof this.activeModuleBitmask === 'number' && !Number.isNaN(this.activeModuleBitmask)) {
      return this.activeModuleBitmask;
    }
    try {
      const lm = require('./license_manager');
      if (lm && typeof lm.getActiveModuleBitmask === 'function') {
        return lm.getActiveModuleBitmask();
      }
    } catch (e) {}
    return 1023;
  }

  /**
   * 10대 모듈(분리 6종 + 신규 4종) 비침투 실행 커널 (Node-State Agnostic + Strict Pre-Condition Relevance Filter + Fail-Open)
   * - 노드 상태('IDLE', 'RUNNING', 'SUCCESS', 'ERROR', 'UNKNOWN', null)와 무관하게 작동
   * - 모듈이 켜져 있더라도 현재 이벤트/데이터와 무관하면 즉시 SKIPPED_NOT_APPLICABLE로 건너뛰어 불필요 개입 오류 0건 보장
   * - 0번(전체 OFF)부터 1023번(10개 전체 ON)까지 1,024가지 모든 조합에서 상호 의존성 없이 독립 실행
   */
  executeModularEnginePipeline(rawEvent = {}, rawOptions = {}) {
    const event = (rawEvent && typeof rawEvent === 'object' && !Array.isArray(rawEvent)) ? rawEvent : {};
    const options = (rawOptions && typeof rawOptions === 'object' && !Array.isArray(rawOptions)) ? rawOptions : {};

    let catalog = null;
    try {
      const lm = require('./license_manager');
      catalog = lm && lm.MODULAR_ENGINE_CATALOG;
    } catch (e) {}

    const rawMaskCandidate = options.bitmask ?? options.activeBitmask ?? event.bitmask ?? event.activeBitmask;
    const activeBitmask = (typeof rawMaskCandidate === 'number' && !Number.isNaN(rawMaskCandidate) && Number.isFinite(rawMaskCandidate))
      ? Math.max(0, Math.floor(rawMaskCandidate))
      : this.getActiveModuleBitmask();

    const normalizedNodeStatus = String(event.nodeStatus || event.status || 'IDLE').toUpperCase();
    const rawPayload = (event.payload && typeof event.payload === 'object' && !Array.isArray(event.payload))
      ? event.payload
      : {};
    const workingPayload = { ...rawPayload };

    const parseNumericField = (val) => {
      if (typeof val === 'number') {
        return (!Number.isNaN(val) && Number.isFinite(val)) ? val : null;
      }
      if (typeof val !== 'string') return null;
      const trimmed = val.trim();
      if (!trimmed) return null;
      const unsigned = trimmed.replace(/^[+-]/, '');
      if (/^0\d+/.test(unsigned)) return null;
      const match = trimmed.match(/^[+-]?(?:₩|\$|KRW\s*|USD\s*)?((?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)\s*(?:원|KRW|USD|개|건|박스|EA|ea|%|g|kg|°C|℃|C)?$/i);
      if (!match) return null;
      const sign = trimmed.startsWith('-') ? -1 : 1;
      const num = Number(match[1].replace(/,/g, ''));
      return (!Number.isNaN(num) && Number.isFinite(num)) ? sign * num : null;
    };

    const hasErrorSignal =
      normalizedNodeStatus === 'ERROR' ||
      Boolean((event.error !== undefined && !Number.isNaN(event.error) && event.error) || event.errorMessage || event.error_log);

    const healAttemptCount = Number(event.attemptCount ?? event.attempt_count ?? event.healAttempts ?? 0) || 0;

    const piiRegex = /(01[016789]-\d{3,4}-\d{4}|\d{6}-[1-4]\d{6}|P\d{12}|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|100%\s*완치|무조건\s*치료|특효약)/;
    const serializedPayloadForPii = JSON.stringify(rawPayload) + ' ' + String(event.text || '');

    const isValidDriftAliasValue = (targetKey, val) => {
      if (val === undefined || val === null) return false;
      if (typeof val === 'number') {
        return Number.isFinite(val);
      }
      if (typeof val === 'string') {
        const trimmed = val.trim();
        if (!trimmed) return false;
        if (DRIFTFLOW_NUMERIC_TARGET_KEYS.has(targetKey)) {
          return parseNumericField(trimmed) !== null;
        }
        return true;
      }
      return false;
    };

    const eventBaselineSet = new Set(
      Array.isArray(event.customerBaselineFields)
        ? event.customerBaselineFields
        : (Array.isArray(event.expectedFields) ? event.expectedFields : [])
    );
    const isCustomerBaselineField = (fieldKey) =>
      this.customerBaselineFields.has(fieldKey) || eventBaselineSet.has(fieldKey);

    const hasValidTargetValue = (targetKey) =>
      Object.prototype.hasOwnProperty.call(rawPayload, targetKey) &&
      isValidDriftAliasValue(targetKey, rawPayload[targetKey]);

    const hasDriftField = Object.entries(DRIFTFLOW_SCHEMA_BRIDGE_DICTIONARY).some(([targetKey, aliasList]) => {
      if (hasValidTargetValue(targetKey)) return false;
      return aliasList.some(aliasKey =>
        Object.prototype.hasOwnProperty.call(rawPayload, aliasKey) &&
        !isCustomerBaselineField(aliasKey) &&
        isValidDriftAliasValue(targetKey, rawPayload[aliasKey])
      );
    });

    const salePriceNum = parseNumericField(
      rawPayload.salePrice ?? rawPayload.settlement_amount ?? rawPayload.payAmount ??
      rawPayload.amount ?? rawPayload.orderAmt ?? rawPayload.pay_price ?? rawPayload.total_pay_amt ??
      rawPayload.totalPaymentAmount ?? rawPayload.paidPrice ?? rawPayload.totalAmount ?? rawPayload.total_price
    );
    const costPriceNum = parseNumericField(
      rawPayload.costPrice ?? rawPayload.supplyCost ?? rawPayload.unit_cost ?? rawPayload.cost_price
    );

    const moduleDefinitions = [
      {
        code: 'MOD_A1_LOCAL_HEALER',
        bitIndex: 0,
        bitmask: 1,
        mcpToolName: (catalog && catalog.MOD_A1_LOCAL_HEALER && catalog.MOD_A1_LOCAL_HEALER.mcpToolName) || 'autoflow.module.local_healer',
        shouldActivate: () => hasErrorSignal,
        execute: () => {
          const nodeKey = String(event.nodeId || event.node_id || event.nodeName || event.node_name || '').trim();
          if (nodeKey && this.nodeMap.has(nodeKey)) {
            this.resolveNodeError(nodeKey, 'LOCAL_HEALED_127MS');
          }
          workingPayload._localHealerApplied = true;
          return {
            action: 'LOCAL_HEALED_127MS',
            healed: true,
            recoveryMs: 127
          };
        }
      },
      {
        code: 'MOD_A2_HQ_FINETUNE_BOT',
        bitIndex: 1,
        bitmask: 2,
        mcpToolName: (catalog && catalog.MOD_A2_HQ_FINETUNE_BOT && catalog.MOD_A2_HQ_FINETUNE_BOT.mcpToolName) || 'autoflow.module.hq_finetune_bot',
        shouldActivate: () => hasErrorSignal && healAttemptCount >= 5,
        execute: () => {
          workingPayload._hqFinetuneEscalated = true;
          return {
            action: 'HQ_FINETUNE_ESCALATED',
            escalatedToHqBot: true,
            attemptCount: healAttemptCount
          };
        }
      },
      {
        code: 'MOD_B_RECON_ENGINE',
        bitIndex: 2,
        bitmask: 4,
        mcpToolName: (catalog && catalog.MOD_B_RECON_ENGINE && catalog.MOD_B_RECON_ENGINE.mcpToolName) || 'autoflow.module.recon_engine',
        shouldActivate: () => Array.isArray(event.branches) && event.branches.length >= 2,
        execute: () => {
          const reconRes = this.evaluateBranchQuorumAndReset(event);
          workingPayload._reconQuorumMet = reconRes.quorumMet;
          return {
            action: 'BRANCH_QUORUM_RECONCILED',
            quorumMet: reconRes.quorumMet,
            divergentBranchCount: reconRes.divergentBranchCount,
            diffFieldCount: Array.isArray(reconRes.diffFields) ? reconRes.diffFields.length : 0,
            notificationChannels: reconRes.notificationChannels || null,
            localPcScreenAlert: reconRes.localPcScreenAlert || null,
            externalSnsSmsAlert: reconRes.externalSnsSmsAlert || null
          };
        }
      },
      {
        code: 'MOD_C_PACE_DEDUP',
        bitIndex: 3,
        bitmask: 8,
        mcpToolName: (catalog && catalog.MOD_C_PACE_DEDUP && catalog.MOD_C_PACE_DEDUP.mcpToolName) || 'autoflow.module.pace_dedup',
        shouldActivate: () => Boolean(
          event.orderId || event.order_id || event.dedupKey || event.rateLimitRps ||
          rawPayload.orderId || rawPayload.order_id || rawPayload.dedupKey
        ),
        execute: () => {
          const dedupKey = String(
            event.dedupKey || event.orderId || event.order_id ||
            rawPayload.dedupKey || rawPayload.orderId || rawPayload.order_id || ''
          ).trim();
          const isDuplicate = Boolean(event.isDuplicateReplay === true || rawPayload.isDuplicateReplay === true);
          workingPayload._paceDedupGuarded = true;
          return {
            action: isDuplicate ? 'DUPLICATE_BLOCKED' : 'PACE_AND_DEDUP_VERIFIED',
            dedupKey,
            isDuplicate,
            rateLimitGuarded: true
          };
        }
      },
      {
        code: 'MOD_D_COMPLIANCE_PII',
        bitIndex: 4,
        bitmask: 16,
        mcpToolName: (catalog && catalog.MOD_D_COMPLIANCE_PII && catalog.MOD_D_COMPLIANCE_PII.mcpToolName) || 'autoflow.module.compliance_pii',
        shouldActivate: () => piiRegex.test(serializedPayloadForPii),
        execute: () => {
          for (const [k, v] of Object.entries(workingPayload)) {
            if (typeof v === 'string') {
              workingPayload[k] = v
                .replace(/01[016789]-\d{3,4}-\d{4}/g, '010-****-****')
                .replace(/\d{6}-[1-4]\d{6}/g, '******-*******')
                .replace(/P\d{12}/g, 'P************');
            }
          }
          workingPayload._piiComplianceGuarded = true;
          return {
            action: 'PII_AND_COMPLIANCE_GUARDED',
            piiMasked: true
          };
        }
      },
      {
        code: 'MOD_E_BLACKBOX_REPLAY',
        bitIndex: 5,
        bitmask: 32,
        mcpToolName: (catalog && catalog.MOD_E_BLACKBOX_REPLAY && catalog.MOD_E_BLACKBOX_REPLAY.mcpToolName) || 'autoflow.module.blackbox_replay',
        shouldActivate: () => Boolean(
          event.nodeName || event.nodeId || event.checkpointId || Object.keys(rawPayload).length > 0
        ),
        execute: () => {
          const checkpointId = String(event.checkpointId || event.nodeId || event.nodeName || 'CHK_SNAPSHOT');
          workingPayload._blackboxCheckpointId = checkpointId;
          return {
            action: 'CHECKPOINT_SNAPSHOT_SAVED',
            checkpointId,
            resumeReadyInSec: 3
          };
        }
      },
      {
        code: 'MOD_F_SIMFLOW_SANDBOX',
        bitIndex: 6,
        bitmask: 64,
        mcpToolName: (catalog && catalog.MOD_F_SIMFLOW_SANDBOX && catalog.MOD_F_SIMFLOW_SANDBOX.mcpToolName) || 'autoflow.module.simflow_sandbox',
        shouldActivate: () => Boolean(
          event.dryRun === true || event.simulationMode === true ||
          rawPayload.dryRun === true || rawPayload.simulationMode === true
        ),
        execute: () => {
          workingPayload._simflowSandbox = {
            dryRun: true,
            sideEffectsBlocked: true,
            predictedSuccess: true
          };
          return {
            action: 'DRY_RUN_SIMULATION_COMPLETED',
            predictedSuccess: true,
            sideEffectsBlocked: true
          };
        }
      },
      {
        code: 'MOD_G_KEYFLOW_ROTATOR',
        bitIndex: 7,
        bitmask: 128,
        mcpToolName: (catalog && catalog.MOD_G_KEYFLOW_ROTATOR && catalog.MOD_G_KEYFLOW_ROTATOR.mcpToolName) || 'autoflow.module.keyflow_rotator',
        shouldActivate: () =>
          Array.isArray(event.accountPool) &&
          event.accountPool.length > 0 &&
          (Number(event.httpStatus) === 429 ||
           event.quotaExceeded === true ||
           (event.quotaRemaining !== undefined && Number(event.quotaRemaining) <= 0)),
        execute: () => {
          const pool = event.accountPool.filter(a => a && typeof a === 'object');
          const standby = pool.find(a => a.status !== 'EXHAUSTED' && Number(a.quotaRemaining ?? 100) > 0) || pool[pool.length - 1] || {};
          const rotatedAccountId = String(standby.accountId || standby.id || 'standby_account_2');
          workingPayload._rotatedAccountId = rotatedAccountId;
          workingPayload._maskedApiKey = 'AF-VAULT-KEY-****';
          return {
            action: 'STANDBY_KEY_ROTATED',
            rotatedAccountId,
            maskedApiKey: 'AF-VAULT-KEY-****'
          };
        }
      },
      {
        code: 'MOD_H_DRIFTFLOW_RADAR',
        bitIndex: 8,
        bitmask: 256,
        mcpToolName: (catalog && catalog.MOD_H_DRIFTFLOW_RADAR && catalog.MOD_H_DRIFTFLOW_RADAR.mcpToolName) || 'autoflow.module.driftflow_radar',
        shouldActivate: () => hasDriftField,
        execute: () => {
          // 대표님 핵심 원칙: "원래 들어온 데이터가 맞는 데이터일 수 있으므로 데이터의 기준을 우리가 정해 임의로 바꾸면 안 된다.
          // 기준과 벗어나는 것들은 별도로 분리하고 고객에게 메시지를 보내 확인받는다."
          const driftId = `DRIFT-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
          const isolatedFields = [];
          const isolatedDeviantFields = {};
          const suggestedCandidates = {};

          for (const [targetKey, aliasList] of Object.entries(DRIFTFLOW_SCHEMA_BRIDGE_DICTIONARY)) {
            if (!hasValidTargetValue(targetKey)) {
              for (const aliasKey of aliasList) {
                if (
                  Object.prototype.hasOwnProperty.call(rawPayload, aliasKey) &&
                  !isCustomerBaselineField(aliasKey) &&
                  isValidDriftAliasValue(targetKey, rawPayload[aliasKey])
                ) {
                  const rawVal = rawPayload[aliasKey];
                  const normalizedPreviewValue = DRIFTFLOW_NUMERIC_TARGET_KEYS.has(targetKey)
                    ? (parseNumericField(rawVal) !== null ? parseNumericField(rawVal) : rawVal)
                    : String(rawVal).trim();

                  if (!isolatedFields.includes(aliasKey)) {
                    isolatedFields.push(aliasKey);
                  }
                  isolatedDeviantFields[aliasKey] = {
                    incomingField: aliasKey,
                    rawValue: rawVal,
                    suggestedStandardField: targetKey,
                    normalizedPreviewValue
                  };
                  if (!Object.prototype.hasOwnProperty.call(suggestedCandidates, targetKey)) {
                    suggestedCandidates[targetKey] = {
                      fromField: aliasKey,
                      rawValue: rawVal,
                      normalizedPreviewValue
                    };
                  }
                }
              }
            }
          }

          let customerNotificationText = '';
          let dualChannelNotify = null;
          try {
            const notifier = require('./repair_notifier');
            if (notifier && typeof notifier.buildSchemaDriftIsolationReportText === 'function') {
              customerNotificationText = notifier.buildSchemaDriftIsolationReportText({
                driftId,
                nodeName: event.nodeName || event.nodeId || '워크플로우 인입 노드',
                isolatedDeviantFields
              });
            }
            if (notifier && typeof notifier.buildDualChannelDriftNotification === 'function') {
              dualChannelNotify = notifier.buildDualChannelDriftNotification({
                incidentType: 'SCHEMA_DRIFT_ISOLATION',
                driftId,
                nodeName: event.nodeName || event.nodeId || '워크플로우 인입 노드',
                isolatedFields,
                isolatedDeviantFields,
                detailedScreenText: customerNotificationText
              });
            }
          } catch (_) {}
          if (!customerNotificationText) {
            customerNotificationText = `[스키마 기준 이탈 별도 분리] 원래 들어온 데이터를 임의 변환하지 않고 원본 보존 후 ${isolatedFields.join(', ')} 항목을 별도 분리했습니다. 고객 확인이 필요합니다.`;
          }
          const localPcScreenAlert = dualChannelNotify ? dualChannelNotify.localPcScreenAlert : null;
          const externalSnsSmsAlert = dualChannelNotify ? dualChannelNotify.externalSnsSmsAlert : null;

          const quarantineRecord = {
            driftId,
            traceId: String(event.traceId || event.orderId || `TRC-DRIFT-${Date.now()}`),
            nodeName: String(event.nodeName || event.nodeId || '워크플로우 인입 노드'),
            rawPayloadSnapshot: { ...rawPayload },
            isolatedFields,
            isolatedDeviantFields,
            suggestedCandidates,
            customerNotificationText,
            notificationChannels: dualChannelNotify,
            localPcScreenAlert,
            externalSnsSmsAlert,
            status: 'ISOLATED_AWAITING_CUSTOMER_DECISION',
            isolatedAt: new Date().toISOString()
          };
          this.driftQuarantineQueue.push(quarantineRecord);
          if (this.driftQuarantineQueue.length > 200) {
            this.driftQuarantineQueue.shift();
          }

          // 원본 workingPayload의 기존 필드는 절대 건드리지 않고, 별도 분리 영역(_driftFlowIsolated)에만 격리 기록
          workingPayload._driftFlowIsolated = {
            driftId,
            status: 'ISOLATED_AWAITING_CUSTOMER_DECISION',
            originalDataPreserved: true,
            autoMutated: false,
            isolatedFields,
            isolatedDeviantFields,
            suggestedCandidates,
            customerNotificationText,
            notificationChannels: dualChannelNotify,
            localPcScreenAlert,
            externalSnsSmsAlert
          };

          return {
            action: 'SCHEMA_DRIFT_ISOLATED_AND_NOTIFIED',
            legacyActionAlias: 'SCHEMA_DRIFT_BRIDGED',
            originalDataPreserved: true,
            autoMutated: false,
            customerNotified: true,
            isolationStatus: 'ISOLATED_AWAITING_CUSTOMER_DECISION',
            driftId,
            isolatedFieldCount: isolatedFields.length,
            isolatedFields,
            isolatedDeviantFields,
            suggestedCandidates,
            customerNotificationText,
            notificationChannels: dualChannelNotify,
            localPcScreenAlert,
            externalSnsSmsAlert
          };
        }
      },
      {
        code: 'MOD_I_PROFITFLOW_GUARD',
        bitIndex: 9,
        bitmask: 512,
        mcpToolName: (catalog && catalog.MOD_I_PROFITFLOW_GUARD && catalog.MOD_I_PROFITFLOW_GUARD.mcpToolName) || 'autoflow.module.profitflow_guard',
        shouldActivate: () => salePriceNum !== null && costPriceNum !== null,
        execute: () => {
          const rawFeeNum = parseNumericField(rawPayload.feeAmount ?? rawPayload.commission_fee);
          const rawShipCost = parseNumericField(rawPayload.shippingCost ?? rawPayload.shipping_fee);
          const rawDlvFee = parseNumericField(rawPayload.deliveryFee ?? rawPayload.dlv_cst);
          const rawIsland = parseNumericField(rawPayload.islandRemoteSurcharge ?? rawPayload.island_remote_surcharge);
          const rawCoupon1 = parseNumericField(rawPayload.couponDiscount ?? rawPayload.coupon_discount);
          const rawCoupon2 = parseNumericField(rawPayload.couponDiscountAmt ?? rawPayload.dc_price);
          const rawVoucher = parseNumericField(rawPayload.voucherAmt ?? rawPayload.live_commerce_voucher_amt);
          const rawVat = parseNumericField(rawPayload.vatAmount ?? rawPayload.vat_amount);

          const feeAmount = rawFeeNum || 0;
          const shippingCost = (rawShipCost || 0) + (rawDlvFee || 0) + (rawIsland || 0);
          const couponDiscount = (rawCoupon1 || 0) + (rawCoupon2 || 0) + (rawVoucher || 0);
          const vatAmount = rawVat || 0;

          const invalidProfitInput =
            salePriceNum < 0 ||
            costPriceNum < 0 ||
            (rawFeeNum !== null && rawFeeNum < 0) ||
            (rawShipCost !== null && rawShipCost < 0) ||
            (rawDlvFee !== null && rawDlvFee < 0) ||
            (rawIsland !== null && rawIsland < 0) ||
            (rawCoupon1 !== null && rawCoupon1 < 0) ||
            (rawCoupon2 !== null && rawCoupon2 < 0) ||
            (rawVoucher !== null && rawVoucher < 0) ||
            (rawVat !== null && rawVat < 0);

          const netProfit = salePriceNum - (costPriceNum + feeAmount + shippingCost + couponDiscount + vatAmount);
          const deficitBrakeTriggered = invalidProfitInput || netProfit < 0;
          let profitDualNotify = null;
          if (deficitBrakeTriggered) {
            try {
              const notifier = require('./repair_notifier');
              if (notifier && typeof notifier.buildDualChannelDriftNotification === 'function') {
                profitDualNotify = notifier.buildDualChannelDriftNotification({
                  incidentType: 'DEFICIT_PROFIT_BRAKE',
                  driftId: `PROFIT-${Date.now()}`,
                  nodeName: event.nodeName || event.nodeId || '역마진 정산 감시 노드',
                  isolatedFields: ['salePrice', 'costPrice', 'shippingCost', 'couponDiscount', 'netProfit'],
                  isolatedDeviantFields: {
                    netProfit: {
                      incomingField: 'netProfit',
                      rawValue: netProfit,
                      suggestedStandardField: 'positiveNetProfit',
                      normalizedPreviewValue: 0
                    }
                  }
                });
              }
            } catch (_) {}
          }
          workingPayload._profitFlowGuard = {
            salePrice: salePriceNum,
            costPrice: costPriceNum,
            shippingCost,
            couponDiscount,
            netProfit,
            invalidProfitInput,
            deficitBrakeTriggered,
            originalDataPreserved: true,
            autoMutated: false,
            localPcScreenAlert: profitDualNotify ? profitDualNotify.localPcScreenAlert : null,
            externalSnsSmsAlert: profitDualNotify ? profitDualNotify.externalSnsSmsAlert : null
          };
          return {
            action: deficitBrakeTriggered ? 'DEFICIT_ORDER_HELD' : 'PROFIT_VERIFIED',
            salePrice: salePriceNum,
            costPrice: costPriceNum,
            shippingCost,
            couponDiscount,
            netProfit,
            invalidProfitInput,
            deficitBrakeTriggered,
            originalDataPreserved: true,
            autoMutated: false,
            notificationChannels: profitDualNotify,
            localPcScreenAlert: profitDualNotify ? profitDualNotify.localPcScreenAlert : null,
            externalSnsSmsAlert: profitDualNotify ? profitDualNotify.externalSnsSmsAlert : null
          };
        }
      }
    ];

    // Append any dynamically hot-plugged MCP modules (Bit 10 = 1024, Bit 11 = 2048, ...) injected via Heartbeat Ping-Pong OTA
    try {
      const lm = require('./license_manager');
      const dynRegistry = lm && lm.SHARED_DYNAMIC_MCP_REGISTRY;
      if (dynRegistry && typeof dynRegistry.values === 'function') {
        for (const dynEntry of dynRegistry.values()) {
          if (!dynEntry || typeof dynEntry !== 'object') continue;
          if (lm.OTA_HOTPLUG_MODULE_TEMPLATES && Object.prototype.hasOwnProperty.call(lm.OTA_HOTPLUG_MODULE_TEMPLATES, dynEntry.code)) {
            continue;
          }
          moduleDefinitions.push({
            code: dynEntry.code,
            bitIndex: dynEntry.bitIndex,
            bitmask: dynEntry.bitmask,
            mcpToolName: dynEntry.mcpToolName || `autoflow.module.dynamic_${dynEntry.bitIndex}`,
            shouldActivate: () => {
              if (typeof dynEntry.shouldActivate === 'function') {
                return Boolean(dynEntry.shouldActivate(event, rawPayload));
              }
              const reqField = dynEntry.requiredField || dynEntry.shouldActivateRule;
              if (typeof reqField === 'string' && reqField.trim()) {
                const key = reqField.trim();
                return Boolean(
                  (event[key] !== undefined && event[key] !== null && event[key] !== false && event[key] !== '') ||
                  (rawPayload[key] !== undefined && rawPayload[key] !== null && rawPayload[key] !== false && rawPayload[key] !== '')
                );
              }
              if (Array.isArray(reqField) && reqField.length > 0) {
                return reqField.some(k =>
                  (event[k] !== undefined && event[k] !== null && event[k] !== false && event[k] !== '') ||
                  (rawPayload[k] !== undefined && rawPayload[k] !== null && rawPayload[k] !== false && rawPayload[k] !== '')
                );
              }
              return Boolean(
                event.customsClearance === true ||
                rawPayload.customsClearance === true ||
                event.pcccCode ||
                rawPayload.pcccCode
              );
            },
            execute: () => {
              const action = dynEntry.executionAction || 'DYNAMIC_PING_MODULE_EXECUTED';
              workingPayload[`_dynamic_${dynEntry.code}`] = {
                executed: true,
                action,
                bitIndex: dynEntry.bitIndex,
                bitmask: dynEntry.bitmask
              };
              return {
                action,
                dynamicHotplug: true,
                deliveryChannel: 'HEARTBEAT_PING_PONG_OTA',
                requiresNewVersionRelease: false
              };
            }
          });
        }
      }

      // [Slot B Iteration 3 & 7 — 과업 3] OTA_HOTPLUG_MODULE_TEMPLATES (Bit 10~15: MOD_J ~ MOD_O, 6종) 실행 핸들러
      if (activeBitmask >= 1024 && lm && lm.OTA_HOTPLUG_MODULE_TEMPLATES) {
        const existingCodes = new Set(moduleDefinitions.map((m) => m.code));
        const otaSpecs = [
          {
            code: 'MOD_J_CUSTOMS_CLEARANCE',
            bitIndex: 10,
            bitmask: 1024,
            mcpToolName: 'autoflow.module.customs_clearance',
            shouldActivate: () => Boolean(
              rawPayload.personalCustomsCode !== undefined ||
              rawPayload.pccc_no !== undefined ||
              rawPayload.pcccCode !== undefined ||
              event.customsClearance === true
            ),
            execute: () => {
              const rawPccc = String(rawPayload.personalCustomsCode ?? rawPayload.pccc_no ?? rawPayload.pcccCode ?? '').trim();
              const isValidPccc = /^P\d{12}$/i.test(rawPccc);
              let dualNotify = null;
              if (!isValidPccc) {
                try {
                  const notifier = require('./repair_notifier');
                  dualNotify = notifier.buildDualChannelDriftNotification({
                    incidentType: 'CUSTOMS_PCCC_ISOLATION',
                    driftId: `PCCC-${Date.now()}`,
                    nodeName: event.nodeName || event.nodeId || '관세청 유니패스 통관 노드',
                    isolatedFields: ['personalCustomsCode'],
                    isolatedDeviantFields: {
                      personalCustomsCode: {
                        incomingField: 'personalCustomsCode',
                        rawValue: rawPccc,
                        suggestedStandardField: 'customs_pccc',
                        normalizedPreviewValue: null
                      }
                    }
                  });
                } catch (_) {}
              }
              return {
                action: isValidPccc ? 'CUSTOMS_PCCC_VERIFIED' : 'CUSTOMS_PCCC_ISOLATED_AND_NOTIFIED',
                isValidPccc,
                originalDataPreserved: true,
                autoMutated: false,
                dynamicHotplug: true,
                localPcScreenAlert: dualNotify ? dualNotify.localPcScreenAlert : null,
                externalSnsSmsAlert: dualNotify ? dualNotify.externalSnsSmsAlert : null
              };
            }
          },
          {
            code: 'MOD_K_GLOBAL_FX_SETTLEMENT',
            bitIndex: 11,
            bitmask: 2048,
            mcpToolName: 'autoflow.module.global_fx_settlement',
            shouldActivate: () => Boolean(
              rawPayload.appliedExchangeRate !== undefined ||
              rawPayload.benchmarkExchangeRate !== undefined ||
              rawPayload.currency !== undefined
            ),
            execute: () => {
              const rawApplied = parseNumericField(rawPayload.appliedExchangeRate);
              const rawBenchmark = parseNumericField(rawPayload.benchmarkExchangeRate);
              const invalidFxInput =
                (rawPayload.appliedExchangeRate !== undefined && (rawApplied === null || rawApplied <= 0)) ||
                (rawPayload.benchmarkExchangeRate !== undefined && (rawBenchmark === null || rawBenchmark <= 0));
              const appliedRate = rawApplied || 0;
              const benchmarkRate = rawBenchmark !== null ? rawBenchmark : appliedRate;
              const fxDiff = Math.abs(appliedRate - benchmarkRate);
              const fxVarianceIsolated = invalidFxInput || fxDiff > 0;
              let dualNotify = null;
              if (fxVarianceIsolated) {
                try {
                  const notifier = require('./repair_notifier');
                  dualNotify = notifier.buildDualChannelDriftNotification({
                    incidentType: 'GLOBAL_FX_SETTLEMENT_ISOLATION',
                    driftId: `FX-${Date.now()}`,
                    nodeName: event.nodeName || event.nodeId || '글로벌 다통화 정산 노드',
                    isolatedFields: ['appliedExchangeRate'],
                    isolatedDeviantFields: {
                      appliedExchangeRate: {
                        incomingField: 'appliedExchangeRate',
                        rawValue: appliedRate,
                        suggestedStandardField: 'benchmarkExchangeRate',
                        normalizedPreviewValue: benchmarkRate
                      }
                    }
                  });
                } catch (_) {}
              }
              return {
                action: fxVarianceIsolated ? 'GLOBAL_FX_VARIANCE_ISOLATED_AND_NOTIFIED' : 'GLOBAL_FX_SETTLEMENT_VERIFIED',
                currency: String(rawPayload.currency || 'USD'),
                appliedExchangeRate: appliedRate,
                benchmarkExchangeRate: benchmarkRate,
                fxDiff,
                invalidFxInput,
                originalDataPreserved: true,
                autoMutated: false,
                dynamicHotplug: true,
                localPcScreenAlert: dualNotify ? dualNotify.localPcScreenAlert : null,
                externalSnsSmsAlert: dualNotify ? dualNotify.externalSnsSmsAlert : null
              };
            }
          },
          {
            code: 'MOD_L_COLDCHAIN_LOT_GUARD',
            bitIndex: 12,
            bitmask: 4096,
            mcpToolName: 'autoflow.module.coldchain_lot_guard',
            shouldActivate: () => Boolean(
              rawPayload.temperatureCelsius !== undefined ||
              rawPayload.remainingShelfLifeDays !== undefined ||
              rawPayload.lotNumber !== undefined
            ),
            execute: () => {
              const tempC = parseNumericField(rawPayload.temperatureCelsius);
              const shelfDays = parseNumericField(rawPayload.remainingShelfLifeDays);
              const invalidColdchainInput =
                (rawPayload.temperatureCelsius !== undefined && tempC === null) ||
                (rawPayload.remainingShelfLifeDays !== undefined && shelfDays === null) ||
                (rawPayload.lotNumber !== undefined && String(rawPayload.lotNumber ?? '').trim().length === 0);
              const excursionDetected = invalidColdchainInput || (tempC !== null && tempC > -12) || (shelfDays !== null && shelfDays < 7);
              let dualNotify = null;
              if (excursionDetected) {
                try {
                  const notifier = require('./repair_notifier');
                  dualNotify = notifier.buildDualChannelDriftNotification({
                    incidentType: 'COLDCHAIN_LOT_ISOLATION',
                    driftId: `COLD-${Date.now()}`,
                    nodeName: event.nodeName || event.nodeId || '콜드체인 로트 감시 노드',
                    isolatedFields: ['temperatureCelsius', 'remainingShelfLifeDays'],
                    isolatedDeviantFields: {
                      temperatureCelsius: {
                        incomingField: 'temperatureCelsius',
                        rawValue: tempC,
                        suggestedStandardField: 'targetColdChainTemp',
                        normalizedPreviewValue: -18
                      }
                    }
                  });
                } catch (_) {}
              }
              return {
                action: excursionDetected ? 'COLDCHAIN_LOT_EXCURSION_ISOLATED_AND_NOTIFIED' : 'COLDCHAIN_LOT_VERIFIED',
                temperatureCelsius: tempC,
                remainingShelfLifeDays: shelfDays,
                invalidColdchainInput,
                excursionDetected,
                originalDataPreserved: true,
                autoMutated: false,
                dynamicHotplug: true,
                localPcScreenAlert: dualNotify ? dualNotify.localPcScreenAlert : null,
                externalSnsSmsAlert: dualNotify ? dualNotify.externalSnsSmsAlert : null
              };
            }
          },
          {
            code: 'MOD_M_B2B_CREDIT_LIMIT_GUARD',
            bitIndex: 13,
            bitmask: 8192,
            mcpToolName: 'autoflow.module.b2b_credit_limit_guard',
            shouldActivate: () => Boolean(
              rawPayload.b2bCreditLimit !== undefined ||
              rawPayload.currentReceivableBalance !== undefined ||
              rawPayload.orderCreditAmount !== undefined
            ),
            execute: () => {
              const creditLimit = parseNumericField(rawPayload.b2bCreditLimit);
              const rawReceivableNum = parseNumericField(rawPayload.currentReceivableBalance);
              const rawOrderNum = parseNumericField(rawPayload.orderCreditAmount ?? rawPayload.amount);
              const receivable = rawReceivableNum !== null ? rawReceivableNum : 0;
              const orderAmt = rawOrderNum !== null ? rawOrderNum : 0;
              const invalidCreditInput =
                (rawPayload.b2bCreditLimit !== undefined && (creditLimit === null || creditLimit < 0)) ||
                (rawPayload.currentReceivableBalance !== undefined && rawReceivableNum === null) ||
                (rawPayload.orderCreditAmount !== undefined && rawOrderNum === null) ||
                receivable < 0 ||
                orderAmt < 0;
              const creditLimitExceeded =
                invalidCreditInput ||
                (creditLimit !== null && (receivable + orderAmt > creditLimit));
              let dualNotify = null;
              if (creditLimitExceeded) {
                try {
                  const notifier = require('./repair_notifier');
                  dualNotify = notifier.buildDualChannelDriftNotification({
                    incidentType: 'B2B_CREDIT_LIMIT_ISOLATION',
                    driftId: `CREDIT-${Date.now()}`,
                    nodeName: event.nodeName || event.nodeId || 'B2B 여신 한도 감시 노드',
                    isolatedFields: ['b2bCreditLimit', 'currentReceivableBalance', 'orderCreditAmount'],
                    isolatedDeviantFields: {
                      b2bCreditLimit: {
                        incomingField: 'projectedReceivableBalance',
                        rawValue: receivable + orderAmt,
                        suggestedStandardField: 'b2bCreditLimit',
                        normalizedPreviewValue: creditLimit
                      }
                    }
                  });
                } catch (_) {}
              }
              return {
                action: creditLimitExceeded ? 'B2B_CREDIT_LIMIT_EXCEEDED_ISOLATED_AND_NOTIFIED' : 'B2B_CREDIT_LIMIT_VERIFIED',
                b2bCreditLimit: creditLimit,
                currentReceivableBalance: receivable,
                orderCreditAmount: orderAmt,
                projectedReceivableBalance: receivable + orderAmt,
                invalidCreditInput,
                creditLimitExceeded,
                originalDataPreserved: true,
                autoMutated: false,
                dynamicHotplug: true,
                notificationChannels: dualNotify,
                localPcScreenAlert: dualNotify ? dualNotify.localPcScreenAlert : null,
                externalSnsSmsAlert: dualNotify ? dualNotify.externalSnsSmsAlert : null
              };
            }
          },
          {
            code: 'MOD_N_RETURN_FRAUD_CLAIM_RADAR',
            bitIndex: 14,
            bitmask: 16384,
            mcpToolName: 'autoflow.module.return_fraud_claim_radar',
            shouldActivate: () => Boolean(
              rawPayload.outboundWeightGram !== undefined ||
              rawPayload.returnedWeightGram !== undefined ||
              rawPayload.returnShippingFeeDeducted !== undefined
            ),
            execute: () => {
              const outW = parseNumericField(rawPayload.outboundWeightGram);
              const retW = parseNumericField(rawPayload.returnedWeightGram);
              const hasWeightInput = rawPayload.outboundWeightGram !== undefined || rawPayload.returnedWeightGram !== undefined;
              const invalidWeightInput =
                (rawPayload.outboundWeightGram !== undefined && (outW === null || outW <= 0)) ||
                (rawPayload.returnedWeightGram !== undefined && (retW === null || retW <= 0)) ||
                (hasWeightInput && (outW === null || retW === null || outW <= 0 || retW <= 0));
              const weightDiscrepancyRatio = (outW !== null && outW > 0 && retW !== null && retW > 0) ? Math.abs(outW - retW) / outW : 0;
              const returnAnomalyDetected =
                invalidWeightInput ||
                (outW !== null && outW > 0 && retW !== null && weightDiscrepancyRatio > 0.15) ||
                rawPayload.returnShippingFeeDeducted === false;
              let dualNotify = null;
              if (returnAnomalyDetected) {
                try {
                  const notifier = require('./repair_notifier');
                  dualNotify = notifier.buildDualChannelDriftNotification({
                    incidentType: 'RETURN_FRAUD_CLAIM_ISOLATION',
                    driftId: `RETURN-${Date.now()}`,
                    nodeName: event.nodeName || event.nodeId || '반품 중량·배송비 감시 노드',
                    isolatedFields: ['outboundWeightGram', 'returnedWeightGram', 'returnShippingFeeDeducted'],
                    isolatedDeviantFields: {
                      returnedWeightGram: {
                        incomingField: 'returnedWeightGram',
                        rawValue: retW,
                        suggestedStandardField: 'outboundWeightGram',
                        normalizedPreviewValue: outW
                      }
                    }
                  });
                } catch (_) {}
              }
              return {
                action: returnAnomalyDetected ? 'RETURN_ANOMALY_ISOLATED_AND_NOTIFIED' : 'RETURN_CLAIM_VERIFIED',
                outboundWeightGram: outW,
                returnedWeightGram: retW,
                weightDiscrepancyRatio,
                returnShippingFeeDeducted: rawPayload.returnShippingFeeDeducted,
                invalidWeightInput,
                returnAnomalyDetected,
                originalDataPreserved: true,
                autoMutated: false,
                dynamicHotplug: true,
                notificationChannels: dualNotify,
                localPcScreenAlert: dualNotify ? dualNotify.localPcScreenAlert : null,
                externalSnsSmsAlert: dualNotify ? dualNotify.externalSnsSmsAlert : null
              };
            }
          },
          {
            code: 'MOD_O_PHARMA_NARCOTICS_SERIAL_GUARD',
            bitIndex: 15,
            bitmask: 32768,
            mcpToolName: 'autoflow.module.pharma_narcotics_serial_guard',
            shouldActivate: () => Boolean(
              rawPayload.udiBarcode !== undefined ||
              rawPayload.pharmaSerialNo !== undefined ||
              rawPayload.mfdsReportRequired === true
            ),
            execute: () => {
              const udiCandidates = [rawPayload.udiBarcode, rawPayload.pharmaSerialNo];
              let rawUdi = '';
              for (const cand of udiCandidates) {
                if (cand !== undefined && cand !== null && String(cand).trim().length > 0) {
                  rawUdi = String(cand).trim();
                  break;
                }
              }
              const isValidUdiFormat =
                rawUdi.length >= 10 &&
                /^[A-Za-z0-9\-().]+$/.test(rawUdi) &&
                !/^(0+|a+|1+|test.*|dummy.*|invalid|null|undefined|error|missing)$/i.test(rawUdi);
              let dualNotify = null;
              if (!isValidUdiFormat) {
                try {
                  const notifier = require('./repair_notifier');
                  dualNotify = notifier.buildDualChannelDriftNotification({
                    incidentType: 'PHARMA_UDI_SERIAL_ISOLATION',
                    driftId: `PHARMA-${Date.now()}`,
                    nodeName: event.nodeName || event.nodeId || '의약품·의료기기 UDI 감시 노드',
                    isolatedFields: ['udiBarcode', 'pharmaSerialNo'],
                    isolatedDeviantFields: {
                      udiBarcode: {
                        incomingField: 'udiBarcode',
                        rawValue: rawUdi,
                        suggestedStandardField: 'standardUdiSerial',
                        normalizedPreviewValue: null
                      }
                    }
                  });
                } catch (_) {}
              }
              return {
                action: !isValidUdiFormat ? 'PHARMA_UDI_SERIAL_ISOLATED_AND_NOTIFIED' : 'PHARMA_UDI_SERIAL_VERIFIED',
                udiSerial: rawUdi,
                isValidUdiFormat,
                originalDataPreserved: true,
                autoMutated: false,
                dynamicHotplug: true,
                notificationChannels: dualNotify,
                localPcScreenAlert: dualNotify ? dualNotify.localPcScreenAlert : null,
                externalSnsSmsAlert: dualNotify ? dualNotify.externalSnsSmsAlert : null
              };
            }
          },
          {
            code: 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD',
            bitIndex: 16,
            bitmask: 65536,
            mcpToolName: 'autoflow.module.marketplace_fee_overcharge_guard',
            shouldActivate: () => Boolean(
              rawPayload.chargedCommissionFee !== undefined ||
              rawPayload.marketplace_commission_fee !== undefined ||
              rawPayload.platform_commission_amt !== undefined ||
              rawPayload.marketFeeAmount !== undefined ||
              rawPayload.fulfillment_service_fee !== undefined ||
              rawPayload.openmarket_deducted_fee !== undefined ||
              rawPayload.expectedCommissionFee !== undefined ||
              rawPayload.expected_commission_fee !== undefined ||
              rawPayload.expected_fee_amt !== undefined ||
              rawPayload.contractedFeeRatePct !== undefined ||
              rawPayload.contracted_fee_rate_pct !== undefined ||
              rawPayload.contracted_fee_rate !== undefined
            ),
            execute: () => {
              const rawChargedCandidate =
                rawPayload.chargedCommissionFee ??
                rawPayload.marketplace_commission_fee ??
                rawPayload.platform_commission_amt ??
                rawPayload.marketFeeAmount ??
                rawPayload.fulfillment_service_fee ??
                rawPayload.openmarket_deducted_fee;
              const rawExpectedCandidate =
                rawPayload.expectedCommissionFee ??
                rawPayload.expected_commission_fee ??
                rawPayload.expected_fee_amt;
              const rawContractedRateCandidate =
                rawPayload.contractedFeeRatePct ??
                rawPayload.contracted_fee_rate_pct ??
                rawPayload.contracted_fee_rate;
              const hasChargedInput = rawChargedCandidate !== undefined;
              const chargedFee = parseNumericField(rawChargedCandidate);
              const contractedRate = parseNumericField(rawContractedRateCandidate);
              const explicitExpectedFee = parseNumericField(rawExpectedCandidate);
              const expectedFee = explicitExpectedFee !== null
                ? explicitExpectedFee
                : (salePriceNum !== null && contractedRate !== null
                  ? Math.round(salePriceNum * (contractedRate / 100))
                  : null);
              const invalidFeeInput =
                (hasChargedInput && (chargedFee === null || chargedFee < 0)) ||
                (rawExpectedCandidate !== undefined && (explicitExpectedFee === null || explicitExpectedFee < 0)) ||
                (rawContractedRateCandidate !== undefined && (contractedRate === null || contractedRate < 0 || contractedRate > 100));
              const feeOverchargeAmount = (chargedFee !== null && expectedFee !== null) ? (chargedFee - expectedFee) : 0;
              const feeOverchargeDetected =
                invalidFeeInput ||
                (chargedFee !== null && expectedFee !== null && feeOverchargeAmount > 0);
              let dualNotify = null;
              let trialUsageRecorded = false;
              let trialUsageStats = null;
              if (feeOverchargeDetected) {
                try {
                  const notifier = require('./repair_notifier');
                  dualNotify = notifier.buildDualChannelDriftNotification({
                    incidentType: 'MARKETPLACE_FEE_OVERCHARGE_ISOLATION',
                    driftId: `FEEOVR-${Date.now()}`,
                    nodeName: event.nodeName || event.nodeId || '오픈마켓 수수료 과다차감 감시 노드',
                    isolatedFields: ['chargedCommissionFee', 'expectedCommissionFee', 'contractedFeeRatePct'],
                    isolatedDeviantFields: {
                      chargedCommissionFee: {
                        incomingField: 'chargedCommissionFee',
                        rawValue: chargedFee,
                        suggestedStandardField: 'expectedCommissionFee',
                        normalizedPreviewValue: expectedFee
                      }
                    }
                  });
                } catch (_) {}
                const shouldRecordTrialUsage = Boolean(
                  options.recordTrialUsage === true ||
                  event.recordTrialUsage === true ||
                  rawPayload.recordTrialUsage === true ||
                  (options.licenseManager && typeof options.licenseManager.recordModuleUsageEvent === 'function')
                );
                if (shouldRecordTrialUsage) {
                  try {
                    const targetLm = (options.licenseManager && typeof options.licenseManager.recordModuleUsageEvent === 'function')
                      ? options.licenseManager
                      : lm;
                    const usageRes = targetLm.recordModuleUsageEvent('MOD_P_FEE_OVERCHARGE_ISOLATED', {
                      protected_amount_krw: feeOverchargeAmount > 0 ? Math.round(feeOverchargeAmount) : 49000
                    });
                    trialUsageRecorded = Boolean(usageRes && usageRes.success);
                    trialUsageStats = usageRes ? usageRes.trial_usage_stats : null;
                  } catch (_) {}
                }
              }
              return {
                action: feeOverchargeDetected ? 'MARKETPLACE_FEE_OVERCHARGE_ISOLATED_AND_NOTIFIED' : 'MARKETPLACE_FEE_SETTLEMENT_VERIFIED',
                chargedCommissionFee: chargedFee,
                expectedCommissionFee: expectedFee,
                contractedFeeRatePct: contractedRate,
                feeOverchargeAmount,
                invalidFeeInput,
                feeOverchargeDetected,
                originalDataPreserved: true,
                autoMutated: false,
                dynamicHotplug: true,
                trialUsageRecorded,
                trialUsageStats,
                notificationChannels: dualNotify,
                localPcScreenAlert: dualNotify ? dualNotify.localPcScreenAlert : null,
                externalSnsSmsAlert: dualNotify ? dualNotify.externalSnsSmsAlert : null
              };
            }
          },
          {
            code: 'MOD_Q_HS_TARIFF_DUTY_GUARD',
            bitIndex: 17,
            bitmask: 131072,
            mcpToolName: 'autoflow.module.hs_tariff_duty_guard',
            shouldActivate: () => Boolean(
              rawPayload.hsCode !== undefined ||
              rawPayload.hs_code !== undefined ||
              rawPayload.declaredHsCode !== undefined ||
              rawPayload.tariff_hs_code !== undefined ||
              rawPayload.hsTariffCode !== undefined ||
              rawPayload.hs_code_10 !== undefined ||
              rawPayload.customsTariffNo !== undefined ||
              rawPayload.commodity_code !== undefined ||
              rawPayload.appliedDutyRatePct !== undefined ||
              rawPayload.customs_tariff_rate_pct !== undefined ||
              rawPayload.tariff_rate_pct !== undefined ||
              rawPayload.customsDutyRate !== undefined ||
              rawPayload.import_tariff_percent !== undefined ||
              rawPayload.declared_duty_rate !== undefined ||
              rawPayload.expectedDutyRatePct !== undefined ||
              rawPayload.expected_duty_rate_pct !== undefined
            ),
            execute: () => {
              const rawHsCandidate =
                rawPayload.hsCode ??
                rawPayload.hs_code ??
                rawPayload.declaredHsCode ??
                rawPayload.tariff_hs_code ??
                rawPayload.hsTariffCode ??
                rawPayload.hs_code_10 ??
                rawPayload.customsTariffNo ??
                rawPayload.commodity_code;
              const rawHs = String(rawHsCandidate ?? '').trim();
              const digitsOnlyHs = rawHs.replace(/[.\-\s]/g, '');
              const hasHsInput = rawHsCandidate !== undefined;
              const isValidHsCode = !hasHsInput
                ? true
                : (/^\d{6,10}$/.test(digitsOnlyHs) && !/^0+$/.test(digitsOnlyHs));
              const rawAppliedDutyCandidate =
                rawPayload.appliedDutyRatePct ??
                rawPayload.customs_tariff_rate_pct ??
                rawPayload.tariff_rate_pct ??
                rawPayload.customsDutyRate ??
                rawPayload.import_tariff_percent ??
                rawPayload.declared_duty_rate;
              const rawExpectedDutyCandidate =
                rawPayload.expectedDutyRatePct ??
                rawPayload.expected_duty_rate_pct;
              const hasAppliedDutyInput = rawAppliedDutyCandidate !== undefined;
              const appliedDuty = parseNumericField(rawAppliedDutyCandidate);
              const expectedDuty = parseNumericField(rawExpectedDutyCandidate);
              const invalidDutyInput =
                (hasAppliedDutyInput && (appliedDuty === null || appliedDuty < 0 || appliedDuty > 500)) ||
                (rawExpectedDutyCandidate !== undefined && (expectedDuty === null || expectedDuty < 0 || expectedDuty > 500));
              const dutyRateGapPct = (appliedDuty !== null && expectedDuty !== null)
                ? Number(Math.abs(appliedDuty - expectedDuty).toFixed(4))
                : 0;
              const dutyRateMismatch =
                appliedDuty !== null &&
                expectedDuty !== null &&
                dutyRateGapPct > 0.001;
              const hsTariffAnomalyDetected = !isValidHsCode || invalidDutyInput || dutyRateMismatch;
              let dualNotify = null;
              let trialUsageRecorded = false;
              let trialUsageStats = null;
              if (hsTariffAnomalyDetected) {
                try {
                  const notifier = require('./repair_notifier');
                  dualNotify = notifier.buildDualChannelDriftNotification({
                    incidentType: 'HS_TARIFF_DUTY_ISOLATION',
                    driftId: `HSTAR-${Date.now()}`,
                    nodeName: event.nodeName || event.nodeId || '수출입 HS코드·관세율 감시 노드',
                    isolatedFields: ['hsCode', 'appliedDutyRatePct', 'expectedDutyRatePct'],
                    isolatedDeviantFields: {
                      hsCode: {
                        incomingField: 'hsCode',
                        rawValue: rawHs,
                        suggestedStandardField: 'expectedDutyRatePct',
                        normalizedPreviewValue: expectedDuty
                      }
                    }
                  });
                } catch (_) {}
                const shouldRecordTrialUsage = Boolean(
                  options.recordTrialUsage === true ||
                  event.recordTrialUsage === true ||
                  rawPayload.recordTrialUsage === true ||
                  (options.licenseManager && typeof options.licenseManager.recordModuleUsageEvent === 'function')
                );
                if (shouldRecordTrialUsage) {
                  try {
                    const targetLm = (options.licenseManager && typeof options.licenseManager.recordModuleUsageEvent === 'function')
                      ? options.licenseManager
                      : lm;
                    const usageRes = targetLm.recordModuleUsageEvent('MOD_Q_TARIFF_DUTY_ISOLATED', {
                      protected_amount_krw: dutyRateGapPct > 0 ? Math.max(49000, Math.round(dutyRateGapPct * 10000)) : 49000
                    });
                    trialUsageRecorded = Boolean(usageRes && usageRes.success);
                    trialUsageStats = usageRes ? usageRes.trial_usage_stats : null;
                  } catch (_) {}
                }
              }
              return {
                action: hsTariffAnomalyDetected ? 'HS_TARIFF_DISCREPANCY_ISOLATED_AND_NOTIFIED' : 'HS_TARIFF_DUTY_VERIFIED',
                hsCode: rawHs,
                normalizedHsDigits: digitsOnlyHs,
                isValidHsCode,
                appliedDutyRatePct: appliedDuty,
                expectedDutyRatePct: expectedDuty,
                dutyRateGapPct,
                invalidDutyInput,
                dutyRateMismatch,
                hsTariffAnomalyDetected,
                originalDataPreserved: true,
                autoMutated: false,
                dynamicHotplug: true,
                trialUsageRecorded,
                trialUsageStats,
                notificationChannels: dualNotify,
                localPcScreenAlert: dualNotify ? dualNotify.localPcScreenAlert : null,
                externalSnsSmsAlert: dualNotify ? dualNotify.externalSnsSmsAlert : null
              };
            }
          }
        ];

        for (const otaMod of otaSpecs) {
          if ((activeBitmask & otaMod.bitmask) !== 0 && !existingCodes.has(otaMod.code)) {
            moduleDefinitions.push(otaMod);
          }
        }
      }
    } catch (e) {}

    const enabledModuleCodes = [];
    const executedModules = [];
    const skippedModules = [];
    const disabledModules = [];
    const interlockSuppressedModules = [];
    const moduleResults = {};

    const enforceInterlock = Boolean(options.enforceInterlock === true || event.enforceInterlock === true);
    const requestedInterlockModules = Array.isArray(options.requestedInterlockModules)
      ? options.requestedInterlockModules
      : (Array.isArray(event.requestedInterlockModules)
        ? event.requestedInterlockModules
        : moduleDefinitions.filter(m => (activeBitmask & m.bitmask) !== 0).map(m => m.code));

    let interlockEvaluation = {
      conflictVariablesRemaining: 0,
      suppressedSet: new Set(),
      suppressedByMap: new Map(),
      activeWinnerMap: new Map(),
      decisions: []
    };
    try {
      const mcie = require('./module_composition_interlock_engine');
      if (mcie && typeof mcie.evaluateInterlockMatrix === 'function') {
        interlockEvaluation = mcie.evaluateInterlockMatrix(requestedInterlockModules, Object.assign({}, event, rawPayload));
      }
    } catch (_) {}

    for (const mod of moduleDefinitions) {
      const isTicketEnabled = (activeBitmask & mod.bitmask) !== 0;
      if (!isTicketEnabled) {
        disabledModules.push(mod.code);
        moduleResults[mod.code] = {
          code: mod.code,
          bitIndex: mod.bitIndex,
          bitmask: mod.bitmask,
          mcpToolName: mod.mcpToolName,
          enabled: false,
          status: 'DISABLED_BY_TICKET'
        };
        continue;
      }

      enabledModuleCodes.push(mod.code);

      const shortModCode = (String(mod.code || '').match(/^(MOD_[A-Z])\d*(?:_|$)/) || [])[1] || mod.code;
      const isSuppressed = enforceInterlock && interlockEvaluation.suppressedSet && (
        interlockEvaluation.suppressedSet.has(mod.code) || interlockEvaluation.suppressedSet.has(shortModCode)
      );
      if (isSuppressed) {
        const supInfo = interlockEvaluation.suppressedByMap.get(mod.code) || interlockEvaluation.suppressedByMap.get(shortModCode) || {};
        skippedModules.push(mod.code);
        interlockSuppressedModules.push(shortModCode);
        if (shortModCode !== mod.code) interlockSuppressedModules.push(mod.code);
        moduleResults[mod.code] = {
          code: mod.code,
          shortCode: shortModCode,
          bitIndex: mod.bitIndex,
          bitmask: mod.bitmask,
          mcpToolName: mod.mcpToolName,
          enabled: true,
          status: 'INTERLOCKED_SUPPRESSED_BY_MUTEX',
          suppressedBy: supInfo.suppressedBy || supInfo.blockedByModule || null,
          conflictGroupId: supInfo.groupId || supInfo.conflictGroupId || null,
          reason: supInfo.reason || 'MUTEX_CONFLICT_INTERLOCK'
        };
        continue;
      }

      try {
        const applicable = Boolean(mod.shouldActivate());
        if (!applicable) {
          skippedModules.push(mod.code);
          moduleResults[mod.code] = {
            code: mod.code,
            bitIndex: mod.bitIndex,
            bitmask: mod.bitmask,
            mcpToolName: mod.mcpToolName,
            enabled: true,
            status: 'SKIPPED_NOT_APPLICABLE',
            reason: 'PRE_CONDITION_NOT_RELEVANT'
          };
          continue;
        }

        const execOut = mod.execute();
        executedModules.push(mod.code);
        moduleResults[mod.code] = {
          code: mod.code,
          bitIndex: mod.bitIndex,
          bitmask: mod.bitmask,
          mcpToolName: mod.mcpToolName,
          enabled: true,
          status: 'EXECUTED',
          ...execOut
        };
      } catch (isolatedErr) {
        // Fail-Open Isolation: never abort user workflow even on unexpected internal error
        skippedModules.push(mod.code);
        moduleResults[mod.code] = {
          code: mod.code,
          bitIndex: mod.bitIndex,
          bitmask: mod.bitmask,
          mcpToolName: mod.mcpToolName,
          enabled: true,
          status: 'FAIL_OPEN_BYPASSED',
          isolatedMessage: isolatedErr.message
        };
      }
    }

    return {
      success: true,
      ok: true,
      workflowContinued: true,
      unhandledErrorCount: 0,
      nodeStatus: normalizedNodeStatus,
      activeBitmask,
      enabledModuleCodes,
      executedModules,
      skippedModules,
      disabledModules,
      interlockSuppressedModules,
      conflictVariablesRemaining: interlockEvaluation.conflictVariablesRemaining ?? 0,
      interlockDecisions: interlockEvaluation.decisions || [],
      moduleResults,
      outputPayload: workingPayload
    };
  }

  /**
   * Executes the 17 frozen composite modules (MOD_A ~ MOD_Q) with strict 6-group Mutex Interlock
   * so that conflicting modules are suppressed deterministically and conflict variables are eliminated to 0.
   */
  executeCompositeInterlockPipeline(requestedModules = [], contextPayload = {}) {
    const mcie = require('./module_composition_interlock_engine');
    return mcie.executeFrozenModulePipelineWithInterlock(requestedModules, contextPayload);
  }

  /**
   * 고객이 별도 분리된 스키마 기준 이탈 데이터(Quarantine)에 대해 결정을 내릴 때 호출하는 핸들러
   * - KEEP_ORIGINAL_AS_BASELINE: 원래 들어온 데이터가 맞으므로 원본 그대로 통과시키고 고객 고유 기준 스키마로 등록
   * - APPLY_SUGGESTED_MAPPING: 고객이 명시적으로 승인한 경우에만 후보 매핑 적용
   * - DISCARD_QUARANTINED: 고객 요청으로 해당 격리 건 보류/폐기
   */
  resolveSchemaDriftQuarantine(driftId, decision = 'KEEP_ORIGINAL_AS_BASELINE', customMapping = null) {
    if (!Array.isArray(this.driftQuarantineQueue)) {
      this.driftQuarantineQueue = [];
    }
    let record = null;
    let targetId = '';
    if (driftId === undefined || driftId === null) {
      record = this.driftQuarantineQueue[this.driftQuarantineQueue.length - 1];
    } else {
      if (typeof driftId !== 'string' || !driftId.trim()) {
        return {
          ok: false,
          error: 'INVALID_DRIFT_ID',
          driftId
        };
      }
      targetId = driftId.trim();
      record = this.driftQuarantineQueue.find((item) => item && item.driftId === targetId);
    }

    if (!record) {
      return {
        ok: false,
        error: 'DRIFT_QUARANTINE_NOT_FOUND',
        driftId: targetId || null
      };
    }

    if (typeof record.status === 'string' && record.status.startsWith('RESOLVED_')) {
      return {
        ok: true,
        idempotentReplay: true,
        preventedDuplicateResolution: true,
        driftId: record.driftId,
        decision: record.resolvedDecision || String(decision || 'KEEP_ORIGINAL_AS_BASELINE').trim().toUpperCase(),
        status: record.status,
        registeredCustomerBaselineFields: Array.from(this.customerBaselineFields),
        resolvedPayload: record.resolvedPayloadSnapshot || { ...(record.rawPayloadSnapshot || {}) },
        resolvedAt: record.resolvedAt
      };
    }

    const normalizedDecision = (typeof decision === 'string')
      ? decision.trim().toUpperCase()
      : String(decision ?? '').trim().toUpperCase();
    const VALID_DRIFT_DECISIONS = new Set([
      'KEEP_ORIGINAL_AS_BASELINE',
      'APPLY_SUGGESTED_MAPPING',
      'DISCARD_QUARANTINED',
      'DISCARD'
    ]);
    if (!VALID_DRIFT_DECISIONS.has(normalizedDecision)) {
      return {
        ok: false,
        error: 'INVALID_DRIFT_DECISION',
        driftId: record.driftId,
        decision: normalizedDecision,
        status: record.status
      };
    }

    const resolvedPayload = { ...(record.rawPayloadSnapshot || {}) };
    const FORBIDDEN_PROTO_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

    if (normalizedDecision === 'KEEP_ORIGINAL_AS_BASELINE') {
      for (const fieldName of (record.isolatedFields || [])) {
        if (fieldName) {
          this.customerBaselineFields.add(String(fieldName).trim());
        }
      }
      record.status = 'RESOLVED_KEPT_AS_CUSTOMER_BASELINE';
    } else if (normalizedDecision === 'APPLY_SUGGESTED_MAPPING') {
      const candidates = record.suggestedCandidates || {};
      for (const [targetKey, candidate] of Object.entries(candidates)) {
        if (FORBIDDEN_PROTO_KEYS.has(targetKey)) continue;
        if (candidate && candidate.normalizedPreviewValue !== undefined) {
          resolvedPayload[targetKey] = candidate.normalizedPreviewValue;
        }
      }
      if (customMapping && typeof customMapping === 'object' && !Array.isArray(customMapping)) {
        for (const [customTarget, sourceField] of Object.entries(customMapping)) {
          const cleanTarget = String(customTarget || '').trim();
          const cleanSource = String(sourceField || '').trim();
          if (
            !cleanTarget ||
            !cleanSource ||
            FORBIDDEN_PROTO_KEYS.has(cleanTarget) ||
            FORBIDDEN_PROTO_KEYS.has(cleanSource)
          ) {
            continue;
          }
          if (Object.prototype.hasOwnProperty.call(resolvedPayload, cleanSource) && resolvedPayload[cleanSource] !== undefined) {
            resolvedPayload[cleanTarget] = resolvedPayload[cleanSource];
          }
        }
      }
      record.status = 'RESOLVED_CUSTOMER_APPROVED_MAPPING';
    } else {
      record.status = 'RESOLVED_DISCARDED_BY_CUSTOMER';
    }

    record.resolvedDecision = normalizedDecision;
    record.resolvedPayloadSnapshot = { ...resolvedPayload };
    record.resolvedAt = new Date().toISOString();

    return {
      ok: true,
      idempotentReplay: false,
      preventedDuplicateResolution: false,
      driftId: record.driftId,
      decision: normalizedDecision,
      status: record.status,
      registeredCustomerBaselineFields: Array.from(this.customerBaselineFields),
      resolvedPayload,
      resolvedAt: record.resolvedAt
    };
  }

  /**
   * JSON-RPC 2.0 MCP tools/list & tools/call handler for AutoFlow Modular Engine
   */
  executeMcpModuleTool(rawRpcRequest = {}) {
    const reqObj = (rawRpcRequest && typeof rawRpcRequest === 'object' && !Array.isArray(rawRpcRequest)) ? rawRpcRequest : {};
    const method = String(reqObj.method || 'tools/list').trim();
    const params = (reqObj.params && typeof reqObj.params === 'object' && !Array.isArray(reqObj.params)) ? reqObj.params : {};

    if (method === 'tools/list') {
      try {
        const lm = require('./license_manager');
        if (lm && typeof lm.getMcpModuleDescriptors === 'function') {
          return lm.getMcpModuleDescriptors({ id: reqObj.id, bitmask: params.bitmask ?? this.getActiveModuleBitmask() });
        }
      } catch (e) {}
    }

    const args = (params.arguments && typeof params.arguments === 'object' && !Array.isArray(params.arguments))
      ? params.arguments
      : params;
    const pipelineRes = this.executeModularEnginePipeline(args, { bitmask: params.bitmask });
    return {
      jsonrpc: '2.0',
      id: reqObj.id || 'mcp-tool-call-1',
      result: {
        content: [
          {
            type: 'text',
            text: JSON.stringify(pipelineRes)
          }
        ],
        pipelineResult: pipelineRes
      }
    };
  }

  /**
   * 4등급 개별 노드 투명 단가 산출기 (Grade N1 ₩1,500 / N2 ₩2,500 / N3 ₩3,500 / N4 ₩5,000)
   * - 방어/자가치유/정합성 기능이 외부 모듈로 분리되었으므로 순수 노드 단가를 1원 단위까지 투명하게 산출
   */
  calculateIndividualNodePricing(rawWorkflowOrNodes = {}, rawOptions = {}) {
    let nodes = [];
    if (Array.isArray(rawWorkflowOrNodes)) {
      nodes = rawWorkflowOrNodes;
    } else if (rawWorkflowOrNodes && typeof rawWorkflowOrNodes === 'object') {
      if (Array.isArray(rawWorkflowOrNodes.nodes)) {
        nodes = rawWorkflowOrNodes.nodes;
      } else if (rawWorkflowOrNodes.workflow && Array.isArray(rawWorkflowOrNodes.workflow.nodes)) {
        nodes = rawWorkflowOrNodes.workflow.nodes;
      }
    }

    const mergedOptions = {
      ...(rawWorkflowOrNodes && typeof rawWorkflowOrNodes === 'object' && !Array.isArray(rawWorkflowOrNodes) ? rawWorkflowOrNodes : {}),
      ...(rawOptions && typeof rawOptions === 'object' && !Array.isArray(rawOptions) ? rawOptions : {})
    };

    let phaseInfo = {
      phaseId: 'PHASE_4_FINAL_FLOOR',
      phaseNameKo: '대중화 최종 최저가 안착기 (180일 이상)',
      nodePriceMultiplier: 1,
      workflowPrices: { WF_ENTRY: 9900, WF_STANDARD: 19000, WF_COMPLEX: 29000 },
      dashboardPriceDisplayAllowed: false
    };
    try {
      const lm = require('./license_manager');
      if (lm && typeof lm.resolveTimePhasedWorkflowPricing === 'function') {
        phaseInfo = lm.resolveTimePhasedWorkflowPricing(mergedOptions);
      }
    } catch (e) {}

    const mult = (typeof phaseInfo.nodePriceMultiplier === 'number' && phaseInfo.nodePriceMultiplier > 0)
      ? phaseInfo.nodePriceMultiplier
      : 1;

    const gradeBreakdown = {
      N1_FLOW_CORE: { count: 0, baseUnitPriceKrw: 1500, unitPriceKrw: 1500 * mult, subtotalKrw: 0 },
      N2_SAAS_COLLAB: { count: 0, baseUnitPriceKrw: 2500, unitPriceKrw: 2500 * mult, subtotalKrw: 0 },
      N3_COMMERCE_DB_CRM: { count: 0, baseUnitPriceKrw: 3500, unitPriceKrw: 3500 * mult, subtotalKrw: 0 },
      N4_AI_CUSTOM_API: { count: 0, baseUnitPriceKrw: 5000, unitPriceKrw: 5000 * mult, subtotalKrw: 0 }
    };

    const itemizedNodes = [];
    let rawNodeBaseSumKrw = 0;
    let rawNodeSumKrw = 0;

    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i];
      if (!n || typeof n !== 'object' || Array.isArray(n)) continue;
      const hasValidNodeIdentity =
        (typeof n.type === 'string' && n.type.trim() !== '') ||
        (typeof n.nodeType === 'string' && n.nodeType.trim() !== '') ||
        (typeof n.name === 'string' && n.name.trim() !== '') ||
        (typeof n.id === 'string' && n.id.trim() !== '');
      if (!hasValidNodeIdentity) continue;
      const rawNodeType = String(n.type || n.nodeType || 'n8n-nodes-base.if').trim();
      const lowerNodeType = rawNodeType.toLowerCase();
      let canonicalNodeType = rawNodeType;
      let spec = Object.prototype.hasOwnProperty.call(OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP, rawNodeType)
        ? OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP[rawNodeType]
        : null;
      if (!spec) {
        for (const [k, v] of Object.entries(OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP)) {
          if (k.toLowerCase() === lowerNodeType) {
            canonicalNodeType = k;
            spec = v;
            break;
          }
        }
      }

      let nodeGrade = (spec && spec.nodeGrade) || 'N1_FLOW_CORE';
      let baseUnitPriceKrw = (spec && typeof spec.unitPriceKrw === 'number') ? spec.unitPriceKrw : 1500;
      const category = (spec && spec.category) || 'BRANCH_FLOW_CONTROL';
      const recommendedModules = (spec && Array.isArray(spec.modules)) ? [...spec.modules] : [];
      const granularSet = new Set((spec && Array.isArray(spec.granularModules)) ? spec.granularModules : []);
      const lowerNodeName = String(n.name || '').toLowerCase();
      if (
        category === 'ECOMMERCE_PAYMENT' ||
        lowerNodeName.includes('수수료') ||
        lowerNodeName.includes('정산') ||
        lowerNodeName.includes('오픈마켓') ||
        lowerNodeName.includes('쿠팡') ||
        lowerNodeName.includes('스마트스토어') ||
        lowerNodeName.includes('commission') ||
        lowerNodeName.includes('fee')
      ) {
        granularSet.add('MOD_H_DRIFTFLOW_RADAR');
        granularSet.add('MOD_I_PROFITFLOW_GUARD');
        granularSet.add('MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD');
      }
      if (
        lowerNodeName.includes('관세') ||
        lowerNodeName.includes('통관') ||
        lowerNodeName.includes('hs코드') ||
        lowerNodeName.includes('hs code') ||
        lowerNodeName.includes('유니패스') ||
        lowerNodeName.includes('해외직구') ||
        lowerNodeName.includes('크로스보더') ||
        lowerNodeName.includes('수출입') ||
        lowerNodeName.includes('tariff') ||
        lowerNodeName.includes('customs')
      ) {
        granularSet.add('MOD_J_CUSTOMS_CLEARANCE');
        granularSet.add('MOD_K_GLOBAL_FX_SETTLEMENT');
        granularSet.add('MOD_Q_HS_TARIFF_DUTY_GUARD');
      }
      const recommendedGranularModules = Array.from(granularSet);

      if (!Object.prototype.hasOwnProperty.call(gradeBreakdown, nodeGrade)) {
        nodeGrade = 'N1_FLOW_CORE';
        baseUnitPriceKrw = 1500;
      }

      const unitPriceKrw = baseUnitPriceKrw * mult;

      gradeBreakdown[nodeGrade].count += 1;
      gradeBreakdown[nodeGrade].subtotalKrw += unitPriceKrw;
      rawNodeBaseSumKrw += baseUnitPriceKrw;
      rawNodeSumKrw += unitPriceKrw;

      itemizedNodes.push({
        nodeId: String(n.id || `node_${i + 1}`),
        nodeName: String(n.name || canonicalNodeType),
        nodeType: canonicalNodeType,
        canonicalNodeType,
        rawNodeType,
        category,
        nodeGrade,
        baseUnitPriceKrw,
        unitPriceKrw,
        nodePriceMultiplier: mult,
        recommendedModules,
        recommendedGranularModules
      });
    }

    const wfPrices = phaseInfo.workflowPrices || { WF_ENTRY: 9900, WF_STANDARD: 19000, WF_COMPLEX: 29000 };
    let recommendedReadyMadeTier = 'WF_ENTRY';
    let readyMadePackagePriceKrw = wfPrices.WF_ENTRY || 9900;
    if (itemizedNodes.length >= 9 || rawNodeBaseSumKrw > 25000) {
      recommendedReadyMadeTier = 'WF_COMPLEX';
      readyMadePackagePriceKrw = wfPrices.WF_COMPLEX || 29000;
    } else if (itemizedNodes.length >= 6 || rawNodeBaseSumKrw > 14000) {
      recommendedReadyMadeTier = 'WF_STANDARD';
      readyMadePackagePriceKrw = wfPrices.WF_STANDARD || 19000;
    }

    return {
      ok: true,
      success: true,
      pricingModel: 'TRANSPARENT_4_GRADE_INDIVIDUAL_NODE_PRICING',
      pricingPhaseId: phaseInfo.phaseId,
      pricingPhaseNameKo: phaseInfo.phaseNameKo,
      nodePriceMultiplier: mult,
      dashboardPriceDisplayAllowed: false,
      legacyDefenseSurchargeRemoved: true,
      nodeCount: itemizedNodes.length,
      itemizedNodes,
      gradeBreakdown,
      gradeSummary: gradeBreakdown,
      totalNodeBasePriceKrw: rawNodeBaseSumKrw,
      rawNodeSumKrw,
      totalNodePriceKrw: rawNodeSumKrw,
      recommendedReadyMadeTier,
      readyMadePackagePriceKrw
    };
  }

  /**
   * 리셀러의 '노드(JSON) 단독 추출·재판매' 원천 차단용 런타임 엔클레이브 서명 토큰 발급기
   * - 로컬 사이드카 데몬의 HWID 및 비밀 시드로 HMAC-SHA256 서명 토큰(AF-ENC-v1.<base64urlPayload>.<sig>) 발급
   */
  issueNodeRuntimeEnclaveToken(params = {}) {
    const opts = (params && typeof params === 'object' && !Array.isArray(params)) ? params : {};
    let hwid = String(opts.hwid || '').trim();
    if (!hwid) {
      try {
        const lm = require('./license_manager');
        if (lm && typeof lm.calculateLocalHwid === 'function') {
          hwid = lm.calculateLocalHwid();
        }
      } catch (e) {}
    }
    if (!hwid) hwid = 'AF-HWID-LOCAL-DEFAULT';

    const payload = {
      v: 'AF-ENC-v1',
      hwid,
      workflowId: (typeof opts.workflowId === 'string' && opts.workflowId.trim()) ? opts.workflowId.trim() : 'WF_DEFAULT',
      nodeId: (typeof opts.nodeId === 'string' && opts.nodeId.trim()) ? opts.nodeId.trim() : 'ALL_NODES',
      licenseKey: (typeof opts.licenseKey === 'string' && opts.licenseKey.trim()) ? opts.licenseKey.trim() : 'AF-ENCLAVE',
      issuedAtMs: (typeof opts.issuedAtMs === 'number' && Number.isFinite(opts.issuedAtMs)) ? opts.issuedAtMs : Date.now()
    };

    const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
    const sig = crypto
      .createHmac('sha256', NODE_ENCLAVE_HMAC_SECRET)
      .update(`AF-ENC-v1.${payloadB64}`)
      .digest('hex');

    return `AF-ENC-v1.${payloadB64}.${sig}`;
  }

  /**
   * 리셀러의 '노드(JSON) 단독 추출·재판매' 원천 차단 런타임 엔클레이브 바인딩 검증기
   * - 리셀러가 워크플로우에서 노드(JSON)만 빼내어 제3자의 일반 n8n에 심어 단독 실행할 경우
   *   1) 로컬 사이드카 데몬 루프백 부재 / 토큰 누락 차단 (ENCLAVE_SIDECAR_REQUIRED_ANTI_NODE_RESALE)
   *   2) 위조 서명 차단 (INVALID_NODE_ENCLAVE_SIGNATURE)
   *   3) 타인 PC 기기 식별자(HWID) 불일치 차단 (HWID_MISMATCH_EXTRACTED_NODE_RESALE)
   *   4) 손상/만료/미래 타임스탬프 및 타 워크플로우·타 노드·빈 스코프·와일드카드 도용 리플레이 차단
   */
  verifyNodeRuntimeEnclaveBinding(nodeEvent = {}, enclaveContext = {}) {
    const evt = (nodeEvent && typeof nodeEvent === 'object' && !Array.isArray(nodeEvent)) ? nodeEvent : {};
    const ctx = (enclaveContext && typeof enclaveContext === 'object' && !Array.isArray(enclaveContext)) ? enclaveContext : {};

    const rawTokenObj = ctx.enclaveToken ?? evt.enclaveToken ?? null;
    const rawToken = typeof rawTokenObj === 'string'
      ? rawTokenObj.trim()
      : (rawTokenObj && typeof rawTokenObj === 'object' && typeof rawTokenObj.token === 'string' ? rawTokenObj.token.trim() : '');

    if (ctx.daemonLoopbackActive === false || !rawToken) {
      return {
        valid: false,
        executionAllowed: false,
        status: 'BLOCKED_EXTRACTED_NODE_RESALE',
        errorCode: 'ENCLAVE_SIDECAR_REQUIRED_ANTI_NODE_RESALE',
        reasonKo: '로컬 사이드카 데몬 엔클레이브 인증이 없습니다. 추출된 노드(JSON) 단독 실행 및 제3자 재판매는 원천 차단됩니다.'
      };
    }

    const parts = rawToken.split('.');
    if (parts.length !== 3 || parts[0] !== 'AF-ENC-v1' || !parts[1] || !parts[2]) {
      return {
        valid: false,
        executionAllowed: false,
        status: 'BLOCKED_EXTRACTED_NODE_RESALE',
        errorCode: 'INVALID_NODE_ENCLAVE_SIGNATURE',
        reasonKo: '노드 런타임 엔클레이브 토큰 형식이 손상되었거나 유효하지 않습니다.'
      };
    }

    const expectedSig = crypto
      .createHmac('sha256', NODE_ENCLAVE_HMAC_SECRET)
      .update(`AF-ENC-v1.${parts[1]}`)
      .digest('hex');

    const providedBuf = Buffer.from(parts[2], 'utf8');
    const expectedBuf = Buffer.from(expectedSig, 'utf8');
    if (providedBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(providedBuf, expectedBuf)) {
      return {
        valid: false,
        executionAllowed: false,
        status: 'BLOCKED_EXTRACTED_NODE_RESALE',
        errorCode: 'INVALID_NODE_ENCLAVE_SIGNATURE',
        reasonKo: '노드 런타임 엔클레이브 서명이 위조되었습니다. 추출된 노드(JSON) 불법 개조·재판매가 차단되었습니다.'
      };
    }

    let payload = null;
    try {
      payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    } catch (e) {
      return {
        valid: false,
        executionAllowed: false,
        status: 'BLOCKED_EXTRACTED_NODE_RESALE',
        errorCode: 'INVALID_NODE_ENCLAVE_SIGNATURE',
        reasonKo: '노드 런타임 엔클레이브 페이로드 복호화에 실패했습니다.'
      };
    }

    if (!payload || typeof payload !== 'object' || !payload.hwid) {
      return {
        valid: false,
        executionAllowed: false,
        status: 'BLOCKED_EXTRACTED_NODE_RESALE',
        errorCode: 'INVALID_NODE_ENCLAVE_SIGNATURE',
        reasonKo: '노드 런타임 엔클레이브 토큰에 기기 식별자(HWID)가 누락되어 있습니다.'
      };
    }

    if (!Number.isFinite(payload.issuedAtMs) || payload.issuedAtMs <= 0) {
      return {
        valid: false,
        executionAllowed: false,
        status: 'BLOCKED_EXTRACTED_NODE_RESALE',
        errorCode: 'INVALID_NODE_ENCLAVE_TIMESTAMP',
        reasonKo: '노드 런타임 엔클레이브 토큰의 발급 타임스탬프가 손상되었거나 유효하지 않습니다.'
      };
    }

    const maxFutureSkewMs = (typeof ctx.maxFutureSkewMs === 'number' && Number.isFinite(ctx.maxFutureSkewMs) && ctx.maxFutureSkewMs >= 0)
      ? ctx.maxFutureSkewMs
      : 300000;
    if (payload.issuedAtMs - Date.now() > maxFutureSkewMs) {
      return {
        valid: false,
        executionAllowed: false,
        status: 'BLOCKED_EXTRACTED_NODE_RESALE',
        errorCode: 'FUTURE_TIMESTAMP_ENCLAVE_TOKEN_REJECTED',
        reasonKo: '노드 런타임 엔클레이브 토큰의 발급 시각이 미래 시점으로 조작되었습니다. 만료 우회 공격이 차단되었습니다.'
      };
    }

    if (
      typeof ctx.maxTokenAgeMs === 'number' &&
      Number.isFinite(ctx.maxTokenAgeMs) &&
      ctx.maxTokenAgeMs > 0 &&
      (Date.now() - payload.issuedAtMs > ctx.maxTokenAgeMs)
    ) {
      return {
        valid: false,
        executionAllowed: false,
        status: 'BLOCKED_EXTRACTED_NODE_RESALE',
        errorCode: 'EXPIRED_NODE_ENCLAVE_TOKEN',
        reasonKo: '노드 런타임 엔클레이브 토큰 유효시간이 만료되었습니다. 토큰 리플레이 공격이 차단되었습니다.'
      };
    }

    const expectedHwid = String(ctx.expectedHwid || '').trim();
    if (expectedHwid && payload.hwid !== expectedHwid) {
      return {
        valid: false,
        executionAllowed: false,
        status: 'BLOCKED_EXTRACTED_NODE_RESALE',
        errorCode: 'HWID_MISMATCH_EXTRACTED_NODE_RESALE',
        boundHwid: payload.hwid,
        expectedHwid,
        reasonKo: '노드 엔클레이브 토큰에 귀속된 기기(HWID)와 실행 PC의 기기 식별자가 불일치합니다. 제3자 PC로의 노드(JSON) 이식·재판매는 원천 차단됩니다.'
      };
    }

    if (ctx.expectedWorkflowId) {
      const expWf = String(ctx.expectedWorkflowId).trim();
      const tokWf = typeof payload.workflowId === 'string' ? payload.workflowId.trim() : '';
      if (
        !tokWf ||
        (tokWf === 'ALL_WORKFLOWS' && ctx.disallowWildcardScope === true) ||
        (tokWf !== 'ALL_WORKFLOWS' && tokWf !== expWf)
      ) {
        return {
          valid: false,
          executionAllowed: false,
          status: 'BLOCKED_EXTRACTED_NODE_RESALE',
          errorCode: 'WORKFLOW_ID_MISMATCH_EXTRACTED_NODE_RESALE',
          boundWorkflowId: payload.workflowId,
          expectedWorkflowId: expWf,
          reasonKo: '타 워크플로우용 엔클레이브 토큰을 도용하여 다른 워크플로우에 이식·재판매하는 행위가 차단되었습니다.'
        };
      }
    }

    if (ctx.expectedNodeId) {
      const expNode = String(ctx.expectedNodeId).trim();
      const tokNode = typeof payload.nodeId === 'string' ? payload.nodeId.trim() : '';
      if (
        !tokNode ||
        (tokNode === 'ALL_NODES' && ctx.disallowWildcardScope === true) ||
        (tokNode !== 'ALL_NODES' && tokNode !== expNode)
      ) {
        return {
          valid: false,
          executionAllowed: false,
          status: 'BLOCKED_EXTRACTED_NODE_RESALE',
          errorCode: 'NODE_ID_MISMATCH_EXTRACTED_NODE_RESALE',
          boundNodeId: payload.nodeId,
          expectedNodeId: expNode,
          reasonKo: '타 노드용 엔클레이브 토큰을 도용하여 다른 노드에 이식·실행하는 행위가 차단되었습니다.'
        };
      }
    }

    return {
      valid: true,
      executionAllowed: true,
      status: 'VERIFIED_GENUINE_ENCLAVE_NODE',
      errorCode: null,
      boundHwid: payload.hwid,
      workflowId: payload.workflowId || evt.workflowId || 'WF_DEFAULT',
      nodeId: evt.nodeId || payload.nodeId || 'ALL_NODES'
    };
  }
}

/**
 * [#1] 공식 n8n 노드 102종 (8대 카테고리) 모듈 추천 매핑 사전
 */
const OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP = {
  // 1. 분기/흐름제어 (BRANCH_FLOW_CONTROL) -> MODULE_B_BRANCH_RECON (N1_FLOW_CORE: ₩1,500)
  'n8n-nodes-base.if': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '조건 분기(If) 이후 경로별 결과 불일치 대사' },
  'n8n-nodes-base.switch': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '다중 갈래(Switch) 분기 간 데이터 정합성 대사' },
  'n8n-nodes-base.merge': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '병렬 분기 병합(Merge) 시 도착 지연 및 값 대사' },
  'n8n-nodes-base.splitInBatches': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '배치 분할 처리 중 일부 배치 실패 단독 리셋' },
  'n8n-nodes-base.executeWorkflow': { category: 'FLOW_BRANCH_CONTROL', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '하위 서브워크플로우 분기 실행 결과 정합성 대사' },
  'n8n-nodes-base.filter': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '필터링 누락 주문 대사' },
  'n8n-nodes-base.compareDatasets': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '데이터셋 비교 정합성 감사' },
  'n8n-nodes-base.wait': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '비동기 대기 노드의 도착 배리어 동기화' },
  'n8n-nodes-base.itemLists': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '아이템 리스트 분할·집계·정렬 시 분기 간 수량 정합성 대사' },
  'n8n-nodes-base.removeDuplicates': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '중복 주문 제거 노드의 오탐 드롭 방지 및 대사' },
  'n8n-nodes-base.scheduleTrigger': { category: 'TRIGGER_INGEST', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '정기 스케줄 배치 트리거 중복 실행 및 누락 감시' },
  'n8n-nodes-base.dateTime': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '정산 마감일·유통기한 타임존 변환 오차 방어' },
  'n8n-nodes-base.summarize': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '피벗·그룹 합계 요약 노드의 분기별 집계 금액 정합성 대사' },
  'n8n-nodes-base.limit': { category: 'BRANCH_FLOW_CONTROL', nodeGrade: 'N1_FLOW_CORE', unitPriceKrw: 1500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: '배치 건수 제한(Limit) 처리 시 잔여 주문 누락 대사' },

  // 2. 이커머스/결제 (ECOMMERCE_PAYMENT) -> MODULE_B_BRANCH_RECON + MODULE_A1_BYOK (N3_COMMERCE_DB_CRM: ₩3,500)
  'n8n-nodes-base.shopify': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krCommerceGuard', reasonKo: '쇼피파이 주문·재고·정산 3자 대사 및 API 자가치유' },
  'n8n-nodes-base.shopifyTrigger': { category: 'TRIGGER_INGEST', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK', 'MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.krCommerceGuard', reasonKo: 'Shopify 글로벌 스토어 주문 웹훅 중복 유입 및 서명 검증 방어' },
  'n8n-nodes-base.wooCommerce': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krCommerceGuard', reasonKo: '우커머스 주문·결제 정합성 대사 및 오류 복구' },
  'n8n-nodes-base.wooCommerceTrigger': { category: 'TRIGGER_INGEST', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK', 'MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.krCommerceGuard', reasonKo: 'WooCommerce 주문 이벤트 웹훅 유실·중복 차단' },
  'n8n-nodes-base.stripe': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'Stripe PG 결제 승인액과 장부 1원 대사' },
  'n8n-nodes-base.stripeTrigger': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'Stripe 결제 웹훅 정합성 감시' },
  'n8n-nodes-base.payPal': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'PayPal 결제 수수료·정산액 대사' },
  'n8n-nodes-base.lemonSqueezy': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'LemonSqueezy 구독 결제 정합성 검증' },
  'n8n-nodes-base.lemonsqueezyTrigger': { category: 'TRIGGER_INGEST', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'Lemon Squeezy 글로벌 구독·라이선스 결제 웹훅 정합성 감시' },
  'n8n-nodes-base.gumroadTrigger': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'Gumroad 라이선스 결제 원장 대사' },
  'n8n-nodes-base.paddle': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'Paddle 정산 및 세무 원장 대사' },
  'n8n-nodes-base.chargebee': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'Chargebee 정기결제 청구 정합성 대사' },
  'n8n-nodes-base.quickBooks': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'QuickBooks 글로벌 회계 인보이스·정산 원장 1원 대사' },
  'n8n-nodes-base.xero': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'Xero 클라우드 회계 전표 및 부가세 정합성 대사' },
  'n8n-nodes-base.wise': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'Wise 해외 송금·환율 정산액과 장부 대사' },
  'n8n-nodes-base.invoiceNinja': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'Invoice Ninja 청구서 발행 및 미수금 원장 대사' },
  'n8n-nodes-base.magento2': { category: 'ECOMMERCE_PAYMENT', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.krCommerceGuard', reasonKo: 'Magento 2(Adobe Commerce) 글로벌 B2B/B2C 주문·재고·정산 대사' },

  // 3. 외부 API/웹훅 (EXTERNAL_API_WEBHOOK) -> MODULE_A2_MANAGED_AI + MODULE_A1_BYOK (N4_AI_CUSTOM_API: ₩5,000 / N2_SAAS_COLLAB: ₩2,500)
  'n8n-nodes-base.httpRequest': { category: 'EXTERNAL_API_WEBHOOK', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A2_MANAGED_AI', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '외부 REST API 타임아웃·429·스키마 변경 무인 AI 자가치유' },
  'n8n-nodes-base.webhook': { category: 'EXTERNAL_API_WEBHOOK', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A2_MANAGED_AI', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '외부 인바운드 웹훅 페이로드 변형 방어' },
  'n8n-nodes-base.graphql': { category: 'EXTERNAL_API_WEBHOOK', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A2_MANAGED_AI', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'GraphQL 쿼리 스키마 변경 자동 수리' },
  'n8n-nodes-base.ftp': { category: 'EXTERNAL_API_WEBHOOK', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'FTP 송수신 순단 자동 재시도 에어백' },
  'n8n-nodes-base.ssh': { category: 'EXTERNAL_API_WEBHOOK', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '원격 SSH 세션 단절 자동 복구' },
  'n8n-nodes-base.respondToWebhook': { category: 'EXTERNAL_API_WEBHOOK', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '웹훅 응답 보장 가드' },
  'n8n-nodes-base.rssFeedRead': { category: 'EXTERNAL_API_WEBHOOK', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '외부 피드 파싱 오류 복구' },
  'n8n-nodes-base.xml': { category: 'HTTP_EXTERNAL_API', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '관세청 유니패스·홈택스 XML 전문 파싱 및 스키마 변이 방어' },
  'n8n-nodes-base.code': { category: 'EXTERNAL_API_WEBHOOK', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A2_MANAGED_AI', 'MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '사용자 정의 JS/Python 코드 노드 런타임 예외 무인 자가치유' },
  'n8n-nodes-base.crypto': { category: 'HTTP_EXTERNAL_API', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '오픈마켓·PG API HMAC 전자서명 및 무결성 해시 검증' },
  'n8n-nodes-base.compression': { category: 'HTTP_EXTERNAL_API', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '대용량 정산 내역 ZIP/GZIP 압축 해제 및 아카이브 무결성 검증' },
  'n8n-nodes-base.executeCommand': { category: 'EXTERNAL_API_WEBHOOK', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '사내 로컬 CLI/배치 스크립트 실행 타임아웃 및 비정상 종료 복구' },
  'n8n-nodes-base.html': { category: 'HTTP_EXTERNAL_API', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '오픈마켓·택배사 웹페이지 HTML DOM 구조 변경 시 셀렉터 자가치유' },

  // 4. DB/원장/시트 (DB_LEDGER_SHEET) -> MODULE_B_BRANCH_RECON (N3_COMMERCE_DB_CRM: ₩3,500)
  'n8n-nodes-base.postgres': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'PostgreSQL 원장 트랜잭션 정합성 대사' },
  'n8n-nodes-base.mySql': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'MySQL 주문/재고 DB 정합성 대사' },
  'n8n-nodes-base.mongoDb': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'MongoDB 도큐먼트 분기 기록 일치 검증' },
  'n8n-nodes-base.redis': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'Redis 재고 캐시와 DB 원장 정합성 대사' },
  'n8n-nodes-base.googleSheets': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: '구글 시트 정산 장부 행 누락·금액 대사' },
  'n8n-nodes-base.airtable': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'Airtable 운영 원장 동기화 대사' },
  'n8n-nodes-base.microsoftExcel': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: '엑셀 회계 원장 수식·부가세 오차 대사' },
  'n8n-nodes-base.supabase': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'Supabase 원장 테이블 분기 대사' },
  'n8n-nodes-base.snowflake': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'Snowflake DW 정산 배치 대사' },
  'n8n-nodes-base.googleBigQuery': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'Google BigQuery 대용량 정산 DW 적재 정합성 대사' },
  'n8n-nodes-base.mariadb': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.krTaxAndVatSentinel', reasonKo: 'MariaDB 커머스 주문·세무 원장 트랜잭션 대사' },
  'n8n-nodes-base.oracleDatabase': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'Oracle 엔터프라이즈 ERP/재무 원장 트랜잭션 정합성 대사' },
  'n8n-nodes-base.microsoftSql': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'MS SQL Server 물류·회계 기간계 DB 정산 대사' },
  'n8n-nodes-base.dynamodb': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'AWS DynamoDB 실시간 주문·재고 상태 테이블 정합성 대사' },
  'n8n-nodes-base.questDb': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'QuestDB 시계열 물류·콜드체인 센서 원장 적재 정합성 대사' },
  'n8n-nodes-base.timescaleDb': { category: 'DB_LEDGER_SHEET', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'TimescaleDB 시계열 정산·재고 로그 트랜잭션 정합성 대사' },

  // 5. CRM/SaaS/ERP (CRM_SAAS_ERP) -> MODULE_A1_BYOK (N3_COMMERCE_DB_CRM: ₩3,500)
  'n8n-nodes-base.hubspot': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'HubSpot CRM API 레이트리밋 자가치유' },
  'n8n-nodes-base.salesforce': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK', 'MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'Salesforce 영업/정산 파이프라인 정합성 보호' },
  'n8n-nodes-base.pipedrive': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Pipedrive 딜 상태 동기화 오류 복구' },
  'n8n-nodes-base.notion': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Notion DB API 타임아웃 자동 복구' },
  'n8n-nodes-base.jira': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Jira 이슈 생성 연동 무중단 보호' },
  'n8n-nodes-base.zendesk': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Zendesk CS 티켓 누락 방지' },
  'n8n-nodes-base.asana': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Asana 태스크 연동 자가치유' },
  'n8n-nodes-base.trello': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Trello 보드 동기화 보호' },
  'n8n-nodes-base.mondayCom': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Monday.com 아이템 갱신 오류 복구' },
  'n8n-nodes-base.clickUp': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'ClickUp 태스크 API 순단 방어' },
  'n8n-nodes-base.zohoCrm': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK', 'MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Zoho CRM 고객·딜 파이프라인 API 한도 및 정합성 보호' },
  'n8n-nodes-base.freshdesk': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Freshdesk 고객 CS 티켓 생성 누락 및 SLA 지연 방어' },
  'n8n-nodes-base.intercom': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Intercom 글로벌 고객 CS 메시지 발송 지연 및 SLA 방어' },
  'n8n-nodes-base.serviceNow': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK', 'MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'ServiceNow 엔터프라이즈 ITSM 티켓·승인 워크플로우 정합성 보호' },
  'n8n-nodes-base.odoo': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK', 'MODULE_B_BRANCH_RECON'], suggestedCustomNode: 'n8n-nodes-autoflow.dynamicBranchQuorum', reasonKo: 'Odoo 오픈소스 ERP 구매·재고·회계 전표 동기화 및 여신 정합성 대사' },
  'n8n-nodes-base.linear': { category: 'CRM_SAAS_ERP', nodeGrade: 'N3_COMMERCE_DB_CRM', unitPriceKrw: 3500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Linear 이슈·장애 티켓 자동 생성 GraphQL API 순단 복구' },

  // 6. 메신저/알림 (MESSENGER_NOTIFICATION) -> MODULE_A1_BYOK (N2_SAAS_COLLAB: ₩2,500)
  'n8n-nodes-base.slack': { category: 'MESSENGER_NOTIFICATION', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Slack 알림 전송 실패 시 자동 페일오버' },
  'n8n-nodes-base.telegram': { category: 'MESSENGER_NOTIFICATION', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Telegram 봇 API 순단 시 자동 재전송' },
  'n8n-nodes-base.discord': { category: 'MESSENGER_NOTIFICATION', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Discord 웹훅 레이트리밋 방어' },
  'n8n-nodes-base.emailSend': { category: 'MESSENGER_NOTIFICATION', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'SMTP 이메일 발송 지연 복구' },
  'n8n-nodes-base.gmail': { category: 'MESSENGER_NOTIFICATION', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Gmail OAuth 토큰 갱신 및 발송 보호' },
  'n8n-nodes-base.twilio': { category: 'MESSENGER_NOTIFICATION', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'SMS 문자 발송 누락 방지' },
  'n8n-nodes-base.microsoftTeams': { category: 'MESSENGER_NOTIFICATION', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Teams 채널 웹훅 전송 보장' },
  'n8n-nodes-base.mattermost': { category: 'MESSENGER_NOTIFICATION', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Mattermost 사내 관제 채널 웹훅 순단 자동 재전송' },
  'n8n-nodes-base.line': { category: 'MESSENGER_NOTIFICATION', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'LINE 메신저 글로벌 고객 알림 발송 실패 페일오버' },
  'n8n-nodes-base.emailReadImap': { category: 'TRIGGER_INGEST', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'IMAP 인바운드 전자세금계산서·발주서 메일 수신 순단 복구' },

  // 7. AI/LLM 에이전트 (AI_LLM_AGENT) -> MODULE_A1_BYOK (PII 마스킹 포함) (N4_AI_CUSTOM_API: ₩5,000)
  '@n8n/n8n-nodes-langchain.agent': { category: 'AI_LLM_AGENT', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: 'AI 에이전트 호출 전 고객 개인정보(PII) 영구 마스킹' },
  '@n8n/n8n-nodes-langchain.chainLlm': { category: 'AI_LLM_AGENT', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: 'LLM 체인 프롬프트 PII 유출 차단' },
  '@n8n/n8n-nodes-langchain.lmChatOpenAi': { category: 'AI_LLM_AGENT', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: 'OpenAI 전송 전 개인정보 마스킹 및 토큰 쿼터 방어' },
  '@n8n/n8n-nodes-langchain.lmChatAnthropic': { category: 'AI_LLM_AGENT', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: 'Anthropic Claude 호출 전 PII 마스킹' },
  'n8n-nodes-base.openAi': { category: 'AI_LLM_AGENT', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: 'OpenAI 노드 PII 살균 및 응답 파싱 복구' },
  '@n8n/n8n-nodes-langchain.lmChatGoogleGemini': { category: 'AI_LLM_AGENT', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: 'Google Gemini 호출 전 고객 개인정보(PII) 영구 마스킹 및 쿼터 보호' },
  '@n8n/n8n-nodes-langchain.vectorStoreQdrant': { category: 'AI_LLM_AGENT', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: 'Qdrant 벡터 DB 임베딩 저장 전 민감 개인정보(PII) 살균' },
  '@n8n/n8n-nodes-langchain.lmChatOllama': { category: 'AI_LLM_AGENT', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: '사내 로컬 Ollama LLM 호출 전 민감 데이터 검증 및 타임아웃 복구' },
  '@n8n/n8n-nodes-langchain.vectorStorePinecone': { category: 'AI_LLM_AGENT', nodeGrade: 'N4_AI_CUSTOM_API', unitPriceKrw: 5000, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.piiZeroLeakShield', reasonKo: 'Pinecone 클라우드 벡터 DB 업서트 전 고객 개인정보(PII) 영구 마스킹' },

  // 8. 파일/클라우드 스토리지 (FILE_STORAGE_CLOUD) -> MODULE_A1_BYOK (N2_SAAS_COLLAB: ₩2,500)
  'n8n-nodes-base.awsS3': { category: 'FILE_STORAGE_CLOUD', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'AWS S3 정산서/송장 파일 업로드 재시도 보호' },
  'n8n-nodes-base.googleDrive': { category: 'FILE_STORAGE_CLOUD', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '구글 드라이브 증적 보관 무중단 복구' },
  'n8n-nodes-base.dropbox': { category: 'FILE_STORAGE_CLOUD', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Dropbox 백업 전송 순단 복구' },
  'n8n-nodes-base.oneDrive': { category: 'FILE_STORAGE_CLOUD', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'OneDrive 기업 문서 동기화 보호' },
  'n8n-nodes-base.box': { category: 'FILE_STORAGE_CLOUD', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: 'Box 엔터프라이즈 계약서·정산 증빙 아카이빙 순단 복구' },
  'n8n-nodes-base.sftp': { category: 'FILE_STORAGE_CLOUD', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '금융기관·ERP SFTP 정산 배치 파일 송수신 세션 복구' },
  'n8n-nodes-base.nextCloud': { category: 'FILE_STORAGE_CLOUD', nodeGrade: 'N2_SAAS_COLLAB', unitPriceKrw: 2500, modules: ['MODULE_A1_BYOK'], suggestedCustomNode: 'n8n-nodes-autoflow.selfHealingCircuit', reasonKo: '사내 구축형 Nextcloud 정산서·통관보류 증빙 파일 업로드 순단 복구' }
};

const FEE_OVERCHARGE_GRANULAR_NODE_KEYS = new Set([
  'n8n-nodes-base.shopify',
  'n8n-nodes-base.shopifyTrigger',
  'n8n-nodes-base.wooCommerce',
  'n8n-nodes-base.wooCommerceTrigger',
  'n8n-nodes-base.stripe',
  'n8n-nodes-base.stripeTrigger',
  'n8n-nodes-base.payPal',
  'n8n-nodes-base.lemonSqueezy',
  'n8n-nodes-base.lemonsqueezyTrigger',
  'n8n-nodes-base.gumroadTrigger',
  'n8n-nodes-base.paddle',
  'n8n-nodes-base.chargebee',
  'n8n-nodes-base.quickBooks',
  'n8n-nodes-base.xero',
  'n8n-nodes-base.wise',
  'n8n-nodes-base.invoiceNinja',
  'n8n-nodes-base.magento2',
  'n8n-nodes-base.postgres',
  'n8n-nodes-base.mySql',
  'n8n-nodes-base.mariadb',
  'n8n-nodes-base.oracleDatabase',
  'n8n-nodes-base.microsoftSql',
  'n8n-nodes-base.googleSheets',
  'n8n-nodes-base.microsoftExcel',
  'n8n-nodes-base.sftp',
  'n8n-nodes-base.nextCloud'
]);

const HS_TARIFF_DUTY_GRANULAR_NODE_KEYS = new Set([
  'n8n-nodes-base.shopify',
  'n8n-nodes-base.shopifyTrigger',
  'n8n-nodes-base.magento2',
  'n8n-nodes-base.wise',
  'n8n-nodes-base.payPal',
  'n8n-nodes-base.lemonSqueezy',
  'n8n-nodes-base.lemonsqueezyTrigger',
  'n8n-nodes-base.paddle',
  'n8n-nodes-base.quickBooks',
  'n8n-nodes-base.xero',
  'n8n-nodes-base.xml',
  'n8n-nodes-base.odoo',
  'n8n-nodes-base.oracleDatabase',
  'n8n-nodes-base.nextCloud'
]);

for (const [nodeKey, entry] of Object.entries(OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP)) {
  const gSet = new Set(Array.isArray(entry.granularModules) ? entry.granularModules : []);
  const cat = entry.category;
  if (cat === 'BRANCH_FLOW_CONTROL' || cat === 'FLOW_BRANCH_CONTROL') {
    gSet.add('MOD_B1_QUORUM_RECON');
    gSet.add('MOD_B2_PINPOINT_RESET');
  } else if (cat === 'ECOMMERCE_PAYMENT') {
    gSet.add('MOD_B1_QUORUM_RECON');
    gSet.add('MOD_F_IDEMPOTENCY_SHIELD');
    gSet.add('MOD_H_DRIFTFLOW_RADAR');
    gSet.add('MOD_I_PROFITFLOW_GUARD');
    gSet.add('MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD');
  } else if (cat === 'EXTERNAL_API_WEBHOOK' || cat === 'HTTP_EXTERNAL_API') {
    gSet.add('MOD_A1_LOCAL_HEALER');
    gSet.add('MOD_E_ZERODROP_QUEUE');
    gSet.add('MOD_H_DRIFTFLOW_RADAR');
    if (Array.isArray(entry.modules) && entry.modules.includes('MODULE_A2_MANAGED_AI')) {
      gSet.add('MOD_A2_CENTRAL_AI');
    }
  } else if (cat === 'DB_LEDGER_SHEET') {
    gSet.add('MOD_B1_QUORUM_RECON');
    gSet.add('MOD_F_IDEMPOTENCY_SHIELD');
    gSet.add('MOD_H_DRIFTFLOW_RADAR');
    if (['n8n-nodes-base.questDb', 'n8n-nodes-base.timescaleDb', 'n8n-nodes-base.redis', 'n8n-nodes-base.dynamodb'].includes(nodeKey)) {
      gSet.add('MOD_L_COLDCHAIN_LOT_GUARD');
      gSet.add('MOD_N_RETURN_FRAUD_CLAIM_RADAR');
    } else {
      gSet.add('MOD_M_B2B_CREDIT_LIMIT_GUARD');
    }
  } else if (cat === 'CRM_SAAS_ERP') {
    gSet.add('MOD_A1_LOCAL_HEALER');
    gSet.add('MOD_C_WATCHDOG_RESPAWN');
    gSet.add('MOD_E_ZERODROP_QUEUE');
    if (['n8n-nodes-base.salesforce', 'n8n-nodes-base.zohoCrm', 'n8n-nodes-base.serviceNow', 'n8n-nodes-base.odoo'].includes(nodeKey)) {
      gSet.add('MOD_B1_QUORUM_RECON');
      gSet.add('MOD_M_B2B_CREDIT_LIMIT_GUARD');
    }
  } else if (cat === 'MESSENGER_NOTIFICATION') {
    gSet.add('MOD_A1_LOCAL_HEALER');
    gSet.add('MOD_E_ZERODROP_QUEUE');
    gSet.add('MOD_F_IDEMPOTENCY_SHIELD');
  } else if (cat === 'AI_LLM_AGENT') {
    gSet.add('MOD_D_PII_VAULT');
    gSet.add('MOD_G_KEYFLOW_ROTATOR');
    gSet.add('MOD_A1_LOCAL_HEALER');
  } else if (cat === 'FILE_STORAGE_CLOUD') {
    gSet.add('MOD_A1_LOCAL_HEALER');
    gSet.add('MOD_E_ZERODROP_QUEUE');
    gSet.add('MOD_C_WATCHDOG_RESPAWN');
  } else if (cat === 'TRIGGER_INGEST') {
    gSet.add('MOD_B1_QUORUM_RECON');
    gSet.add('MOD_E_ZERODROP_QUEUE');
    gSet.add('MOD_F_IDEMPOTENCY_SHIELD');
  }

  if (FEE_OVERCHARGE_GRANULAR_NODE_KEYS.has(nodeKey)) {
    gSet.add('MOD_H_DRIFTFLOW_RADAR');
    gSet.add('MOD_I_PROFITFLOW_GUARD');
    gSet.add('MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD');
  }
  if (HS_TARIFF_DUTY_GRANULAR_NODE_KEYS.has(nodeKey)) {
    gSet.add('MOD_J_CUSTOMS_CLEARANCE');
    gSet.add('MOD_K_GLOBAL_FX_SETTLEMENT');
    gSet.add('MOD_Q_HS_TARIFF_DUTY_GUARD');
  }

  entry.granularModules = Array.from(gSet);
}

/**
 * [#2-AntiCopy] AutoFlow 외부 사이드카 노드 제어기 6종 아키텍처 (Out-of-Band External Node Controllers)
 * - 워크플로우 내부 JSON에 커스텀 노드를 직접 주입하지 않고(injectIntoWorkflowJson: false),
 *   100% 외부 사이드카 데몬에서 인입된 노드만 원격 제어하여 워크플로우 무단 카피/유출을 원천 차단합니다.
 */
const AUTOFLOW_EXTERNAL_NODE_CONTROLLERS = {
  EXT_CTRL_DYNAMIC_BRANCH_QUORUM: {
    controllerId: 'EXT_CTRL_DYNAMIC_BRANCH_QUORUM',
    legacyCustomType: 'n8n-nodes-autoflow.dynamicBranchQuorum',
    nameKo: '⚖️ 동적 N분기 다수결 대사 & 단독 리셋 외부 제어기',
    nameEn: 'AutoFlow Dynamic N-Branch Quorum & Pinpoint Reset External Controller',
    executionMode: 'OUT_OF_BAND_EXTERNAL_CONTROLLER',
    injectIntoWorkflowJson: false,
    antiCopyProtected: true,
    requiredModules: ['MODULE_B_BRANCH_RECON'],
    granularModules: ['MOD_B1_QUORUM_RECON', 'MOD_B2_PINPOINT_RESET'],
    allowedCauseLayers: ['LAYER_5_SECURITY_QUORUM_MARKET', 'LAYER_1_NET_INFRA'],
    whyOfficialCannotDoKo: 'n8n 공식 Merge/If 노드는 병렬 분기 중 1곳이 틀렸을 때 다수결(K vs M) 대사나 정상 분기 중복 실행 차단 후 문제 분기만 단독 리셋하는 기능이 없음',
    defaultParameters: {
      branchArrivalWindowMs: 3000,
      holdOnTieSplitBrain: true,
      enableDryRunPreview: true
    }
  },
  EXT_CTRL_SELF_HEALING_CIRCUIT: {
    controllerId: 'EXT_CTRL_SELF_HEALING_CIRCUIT',
    legacyCustomType: 'n8n-nodes-autoflow.selfHealingCircuit',
    nameKo: '🛡️ 127ms 무인 자가치유 & 지터 에어백 외부 제어기',
    nameEn: 'AutoFlow 127ms Self-Healing & Jitter Airbag External Controller',
    executionMode: 'OUT_OF_BAND_EXTERNAL_CONTROLLER',
    injectIntoWorkflowJson: false,
    antiCopyProtected: true,
    requiredModules: ['MODULE_A1_BYOK', 'MODULE_A2_MANAGED_AI'],
    granularModules: ['MOD_A1_LOCAL_HEALER', 'MOD_A2_CENTRAL_AI', 'MOD_E_ZERODROP_QUEUE', 'MOD_H_DRIFTFLOW_RADAR'],
    allowedCauseLayers: ['LAYER_1_NET_INFRA', 'LAYER_2_API_AUTH_SCHEMA'],
    whyOfficialCannotDoKo: 'n8n 공식 HTTP 노드의 단순 재시도는 API 스키마 변경이나 429 폭주를 고치지 못하고 워크플로우를 멈추게 하나, 본 외부 제어기는 127ms 로컬 핫패치 및 AI 코드 수리로 무중단 복구함',
    defaultParameters: {
      maxLocalStrikes: 5,
      jitterBackoffMs: 127,
      enableCentralAiEscalation: true
    }
  },
  EXT_CTRL_PII_ZERO_LEAK_SHIELD: {
    controllerId: 'EXT_CTRL_PII_ZERO_LEAK_SHIELD',
    legacyCustomType: 'n8n-nodes-autoflow.piiZeroLeakShield',
    nameKo: '🔒 로컬 PII 개인정보 영구 마스킹 외부 제어기',
    nameEn: 'AutoFlow Local PII Zero-Leak Shield External Controller',
    executionMode: 'OUT_OF_BAND_EXTERNAL_CONTROLLER',
    injectIntoWorkflowJson: false,
    antiCopyProtected: true,
    requiredModules: ['MODULE_A1_BYOK', 'MODULE_A2_MANAGED_AI'],
    granularModules: ['MOD_D_PII_VAULT', 'MOD_G_KEYFLOW_ROTATOR'],
    allowedCauseLayers: ['LAYER_5_SECURITY_QUORUM_MARKET', 'LAYER_2_API_AUTH_SCHEMA'],
    whyOfficialCannotDoKo: '외부 AI/LLM 호출 전 한국형 휴대폰번호·주민번호·계좌번호·주소를 로컬 메모리에서 100% 비가역 마스킹하여 개인정보보호법 위반을 원천 차단함',
    defaultParameters: {
      maskKoreanPhone: true,
      maskResidentId: true,
      maskBankAccount: true
    }
  },
  EXT_CTRL_KR_TAX_VAT_SENTINEL: {
    controllerId: 'EXT_CTRL_KR_TAX_VAT_SENTINEL',
    legacyCustomType: 'n8n-nodes-autoflow.krTaxAndVatSentinel',
    nameKo: '🧾 한국형 부가세 1원 보정 & 홈택스/스마트빌 대사 외부 제어기',
    nameEn: 'AutoFlow KR VAT 1-KRW & Hometax Reconciliation External Controller',
    executionMode: 'OUT_OF_BAND_EXTERNAL_CONTROLLER',
    injectIntoWorkflowJson: false,
    antiCopyProtected: true,
    requiredModules: ['MODULE_B_BRANCH_RECON'],
    granularModules: ['MOD_B1_QUORUM_RECON', 'MOD_J_CUSTOMS_CLEARANCE', 'MOD_K_GLOBAL_FX_SETTLEMENT', 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD', 'MOD_Q_HS_TARIFF_DUTY_GUARD'],
    allowedCauseLayers: ['LAYER_3_FIN_TAX_PAYMENT', 'LAYER_2_API_AUTH_SCHEMA'],
    whyOfficialCannotDoKo: '한국 국세청(홈택스)·스마트빌 세금계산서의 공급가액/부가세 1원 단수 오차 및 현금영수증 의무발행 가산세 방어 로직을 외부 사이드카에서 기본 수행함',
    defaultParameters: {
      vatRate: 0.1,
      roundingToleranceKrw: 1,
      verifyHometaxSlip: true
    }
  },
  EXT_CTRL_KR_COMMERCE_GUARD: {
    controllerId: 'EXT_CTRL_KR_COMMERCE_GUARD',
    legacyCustomType: 'n8n-nodes-autoflow.krCommerceGuard',
    nameKo: '📦 오픈마켓 합포장·역마진·발송중지 방어 외부 제어기',
    nameEn: 'AutoFlow KR Open-Market Commerce Guard External Controller',
    executionMode: 'OUT_OF_BAND_EXTERNAL_CONTROLLER',
    injectIntoWorkflowJson: false,
    antiCopyProtected: true,
    requiredModules: ['MODULE_A1_BYOK', 'MODULE_B_BRANCH_RECON'],
    granularModules: ['MOD_I_PROFITFLOW_GUARD', 'MOD_L_COLDCHAIN_LOT_GUARD', 'MOD_M_B2B_CREDIT_LIMIT_GUARD', 'MOD_N_RETURN_FRAUD_CLAIM_RADAR', 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD'],
    allowedCauseLayers: ['LAYER_4_LOGISTICS_INVENTORY', 'LAYER_3_FIN_TAX_PAYMENT', 'LAYER_5_SECURITY_QUORUM_MARKET'],
    whyOfficialCannotDoKo: '쿠팡/스마트스토어 취소 건 출고 보류(Stop-Shipment), 동일 수령자 합포장 감별, 비정상 할인가 역마진 안전 에어백을 외부 제어기에서 1초 내에 수행함',
    defaultParameters: {
      stopShipmentOnCancel: true,
      detectCombinedPacking: true,
      minSafeMarginPercent: 5
    }
  },
  EXT_CTRL_CUSTOM_BIZ_RULE: {
    controllerId: 'EXT_CTRL_CUSTOM_BIZ_RULE',
    legacyCustomType: 'n8n-nodes-autoflow.customBizRuleBuilder',
    nameKo: '🔧 고객 맞춤형 특수 정합성 룰 외부 제어기',
    nameEn: 'AutoFlow Custom Business Rule External Controller',
    executionMode: 'OUT_OF_BAND_EXTERNAL_CONTROLLER',
    injectIntoWorkflowJson: false,
    antiCopyProtected: true,
    requiredModules: ['MODULE_B_BRANCH_RECON'],
    granularModules: ['MOD_B1_QUORUM_RECON', 'MOD_H_DRIFTFLOW_RADAR', 'MOD_P_MARKETPLACE_FEE_OVERCHARGE_GUARD', 'MOD_Q_HS_TARIFF_DUTY_GUARD'],
    allowedCauseLayers: ['LAYER_3_FIN_TAX_PAYMENT', 'LAYER_4_LOGISTICS_INVENTORY', 'LAYER_5_SECURITY_QUORUM_MARKET'],
    whyOfficialCannotDoKo: '고객사 고유의 사내 장부·창고·정산 규칙을 워크플로우 노출 없이 외부 사이드카 선언형 룰로 정의하여 분기 간 정합성을 자동 대사함',
    defaultParameters: {
      customRules: [],
      requireHumanApprovalOnMismatch: true
    }
  }
};

/**
 * [#2] 하위 호환 별칭 (AUTOFLOW_CUSTOM_SPECIAL_NODES -> 100% Out-of-Band External Controller 매핑)
 */
const AUTOFLOW_CUSTOM_SPECIAL_NODES = {
  'n8n-nodes-autoflow.dynamicBranchQuorum': {
    type: 'n8n-nodes-autoflow.dynamicBranchQuorum',
    ...AUTOFLOW_EXTERNAL_NODE_CONTROLLERS.EXT_CTRL_DYNAMIC_BRANCH_QUORUM
  },
  'n8n-nodes-autoflow.selfHealingCircuit': {
    type: 'n8n-nodes-autoflow.selfHealingCircuit',
    ...AUTOFLOW_EXTERNAL_NODE_CONTROLLERS.EXT_CTRL_SELF_HEALING_CIRCUIT
  },
  'n8n-nodes-autoflow.piiZeroLeakShield': {
    type: 'n8n-nodes-autoflow.piiZeroLeakShield',
    ...AUTOFLOW_EXTERNAL_NODE_CONTROLLERS.EXT_CTRL_PII_ZERO_LEAK_SHIELD
  },
  'n8n-nodes-autoflow.krTaxAndVatSentinel': {
    type: 'n8n-nodes-autoflow.krTaxAndVatSentinel',
    ...AUTOFLOW_EXTERNAL_NODE_CONTROLLERS.EXT_CTRL_KR_TAX_VAT_SENTINEL
  },
  'n8n-nodes-autoflow.krCommerceGuard': {
    type: 'n8n-nodes-autoflow.krCommerceGuard',
    ...AUTOFLOW_EXTERNAL_NODE_CONTROLLERS.EXT_CTRL_KR_COMMERCE_GUARD
  },
  'n8n-nodes-autoflow.customBizRuleBuilder': {
    type: 'n8n-nodes-autoflow.customBizRuleBuilder',
    ...AUTOFLOW_EXTERNAL_NODE_CONTROLLERS.EXT_CTRL_CUSTOM_BIZ_RULE
  }
};

const DRIFTFLOW_NUMERIC_TARGET_KEYS = new Set([
  'amount',
  'quantity',
  'vat_amount',
  'settlement_amount',
  'shipping_fee',
  'discount_amount',
  'b2b_credit_limit',
  'return_weight_gram',
  'coldchain_temp_c',
  'marketplace_commission_fee',
  'customs_tariff_rate_pct'
]);

const DRIFTFLOW_SCHEMA_BRIDGE_DICTIONARY = {
  amount: ['orderAmt', 'pay_price', 'total_pay_amt', 'totalPaymentAmount', 'paidPrice', 'totalAmount', 'total_price'],
  quantity: ['itemCnt', 'ord_qty', 'orderQuantity', 'line_items_count', 'item_qty'],
  phone: ['buyerTel', 'rcvr_tel', 'receiverTelNo', 'recipientPhone', 'customer_phone'],
  orderId: ['productOrderId', 'ordNo', 'order_no', 'merchant_uid', 'vendorOrderId'],
  tracking_no: ['waybillNo', 'invc_no', 'invoiceNumber', 'trackingNumber', 'slip_no'],
  customs_pccc: ['personalCustomsCode', 'pccc_no', 'customsClearanceCode', 'unipass_pccc'],
  vat_amount: ['vatAmt', 'tax_amount', 'total_tax', 'surTaxAmt'],
  settlement_amount: ['expectSettlementAmt', 'settle_amt', 'net_payout_amount', 'payoutAmt'],
  shipping_fee: ['deliveryFee', 'dlv_cst', 'shippingCost', 'freight_charge', 'islandRemoteSurcharge'],
  discount_amount: ['couponDiscountAmt', 'dc_price', 'sellerDiscountAmount', 'promo_deduction_amt', 'voucherAmt'],
  hs_code: ['hsTariffCode', 'hs_code_10', 'customsTariffNo', 'commodity_code', 'tariff_hs_code'],
  lot_expiry_date: ['expirationDate', 'use_by_date', 'shelfLifeEndDate', 'coldchain_exp_dt'],
  b2b_credit_limit: ['partnerCreditLimit', 'credit_limit_krw', 'maxReceivableLimit', 'wholesale_credit_cap'],
  return_weight_gram: ['returnedWeightG', 'ret_pkg_weight', 'inboundReturnGram', 'measured_return_wt'],
  udi_serial_no: ['medicalUdiCode', 'pharma_serial_code', 'gs1_udi_barcode', 'kpis_std_serial'],
  coldchain_temp_c: ['transitTempCelsius', 'logger_temp_c', 'reefer_temp_val', 'storageTempDegC'],
  marketplace_commission_fee: ['platform_commission_amt', 'marketFeeAmount', 'fulfillment_service_fee', 'openmarket_deducted_fee'],
  customs_tariff_rate_pct: ['tariff_rate_pct', 'customsDutyRate', 'import_tariff_percent', 'declared_duty_rate']
};

for (const [k, arr] of Object.entries(DRIFTFLOW_SCHEMA_BRIDGE_DICTIONARY)) {
  Object.defineProperty(arr, 'aliases', { value: arr, enumerable: false });
  Object.defineProperty(arr, 'type', {
    value: DRIFTFLOW_NUMERIC_TARGET_KEYS.has(k) ? 'numeric' : 'string',
    enumerable: false
  });
}

const defaultWorkflowTopologySentinel = new WorkflowTopologySentinel();
WorkflowTopologySentinel.autoMountEngineProfile = (payload, options) => defaultWorkflowTopologySentinel.autoMountEngineProfile(payload, options);
WorkflowTopologySentinel.dockWorkflowIntoActiveEngine = (payload, options) => defaultWorkflowTopologySentinel.dockWorkflowIntoActiveEngine(payload, options);

module.exports = {
  WorkflowTopologySentinel,
  workflowTopologySentinel: defaultWorkflowTopologySentinel,
  NODE_ENCLAVE_HMAC_SECRET,
  OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP,
  EXTERNAL_NODE_RECOMMENDATION_CATALOG: OFFICIAL_NODE_MODULE_RECOMMENDATION_MAP,
  DRIFTFLOW_SCHEMA_BRIDGE_DICTIONARY,
  AUTOFLOW_EXTERNAL_NODE_CONTROLLERS,
  AUTOFLOW_CUSTOM_SPECIAL_NODES,
  recommendModulesForWorkflowNodes: (...args) => defaultWorkflowTopologySentinel.recommendModulesForWorkflowNodes(...args),
  recommendWorkflowAndModules: (...args) => defaultWorkflowTopologySentinel.recommendModulesForWorkflowNodes(...args),
  bindExternalNodeControllers: (...args) => defaultWorkflowTopologySentinel.bindExternalNodeControllers(...args),
  injectCustomAutoFlowNodes: (...args) => defaultWorkflowTopologySentinel.injectCustomAutoFlowNodes(...args),
  buildActiveNodeScopeRegistry: (...args) => defaultWorkflowTopologySentinel.buildActiveNodeScopeRegistry(...args),
  getDashboardActiveNodeScopeSummary: (...args) => defaultWorkflowTopologySentinel.getDashboardActiveNodeScopeSummary(...args),
  handleIncomingNodeEventScoped: (...args) => defaultWorkflowTopologySentinel.handleIncomingNodeEventScoped(...args),
  detectDynamicBranchGroups: (...args) => defaultWorkflowTopologySentinel.detectDynamicBranchGroups(...args),
  evaluateBranchQuorumAndReset: (...args) => defaultWorkflowTopologySentinel.evaluateBranchQuorumAndReset(...args),
  applyCustomerApprovedBranchSync: (...args) => defaultWorkflowTopologySentinel.applyCustomerApprovedBranchSync(...args),
  setActiveModuleBitmask: (...args) => defaultWorkflowTopologySentinel.setActiveModuleBitmask(...args),
  getActiveModuleBitmask: (...args) => defaultWorkflowTopologySentinel.getActiveModuleBitmask(...args),
  executeModularEnginePipeline: (...args) => defaultWorkflowTopologySentinel.executeModularEnginePipeline(...args),
  executeCompositeInterlockPipeline: (...args) => defaultWorkflowTopologySentinel.executeCompositeInterlockPipeline(...args),
  resolveSchemaDriftQuarantine: (...args) => defaultWorkflowTopologySentinel.resolveSchemaDriftQuarantine(...args),
  executeMcpModuleTool: (...args) => defaultWorkflowTopologySentinel.executeMcpModuleTool(...args),
  calculateIndividualNodePricing: (...args) => defaultWorkflowTopologySentinel.calculateIndividualNodePricing(...args),
  issueNodeRuntimeEnclaveToken: (...args) => defaultWorkflowTopologySentinel.issueNodeRuntimeEnclaveToken(...args),
  verifyNodeRuntimeEnclaveBinding: (...args) => defaultWorkflowTopologySentinel.verifyNodeRuntimeEnclaveBinding(...args),
  introspectCustomerWorkflowNodes: (...args) => defaultWorkflowTopologySentinel.introspectCustomerWorkflowNodes(...args),
  importCustomCustomerWorkflow: (...args) => defaultWorkflowTopologySentinel.importCustomCustomerWorkflow(...args),
  autoMountEngineProfile: (...args) => defaultWorkflowTopologySentinel.autoMountEngineProfile(...args),
  dockWorkflow: (...args) => defaultWorkflowTopologySentinel.dockWorkflow(...args),
  dockWorkflowIntoActiveEngine: (...args) => defaultWorkflowTopologySentinel.dockWorkflowIntoActiveEngine(...args),
  getDockedWorkflowsSummary: (...args) => defaultWorkflowTopologySentinel.getDockedWorkflowsSummary(...args),
  getEngineAndCartridgeArchitecture: (...args) => defaultWorkflowTopologySentinel.getEngineAndCartridgeArchitecture(...args),
  diagnoseWorkflowAndQuoteStackingCartridges: (...args) => defaultWorkflowTopologySentinel.diagnoseWorkflowAndQuoteStackingCartridges(...args),
  measureCartridgeHeartbeatSize: (...args) => defaultWorkflowTopologySentinel.measureCartridgeHeartbeatSize(...args),
  registerDynamicCartridgeOta: (...args) => defaultWorkflowTopologySentinel.registerDynamicCartridgeOta(...args),
  applyCartridgeRenameOta: (...args) => defaultWorkflowTopologySentinel.applyCartridgeRenameOta(...args),
  applyCartridgeDeprecationAndSwapOta: (...args) => defaultWorkflowTopologySentinel.applyCartridgeDeprecationAndSwapOta(...args),
  getTieredModuleHierarchyAndFlywheelSpec: (...args) => defaultWorkflowTopologySentinel.getTieredModuleHierarchyAndFlywheelSpec(...args),
  evaluateAiBuildVsBuyAndAntiCopyVerdict: (...args) => defaultWorkflowTopologySentinel.evaluateAiBuildVsBuyAndAntiCopyVerdict(...args),
  createCartridgeForNewNodeOrWorkflow: (...args) => defaultWorkflowTopologySentinel.createCartridgeForNewNodeOrWorkflow(...args)
};


