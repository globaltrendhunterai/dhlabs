/**
 * AutoFlow Rocket Growth Inbound Barcode Sentinel (Gate 41: GATE_BIZ_12)
 * 
 * [비즈니스 & 물류 컴플라이언스]
 * 1. 쿠팡 로켓그로스(제트배송) 및 풀필먼트(CGF) 물류센터(FC) 입고 기준 준수
 * 2. EAN-13 국제 표준 모듈로-10 체크섬(Check Digit) 및 Code 128 자릿수 정밀 검증
 * 3. 식품·화장품·공산품 유통기한(소비기한) 70% 이상 잔여 기준 사전 감별 (전량 회송/반송 방어)
 * 4. 파레트당 수십만 원의 왕복 용차 물류비 및 쿠팡 입고 지연/정지 패널티 원천 차단
 * 5. Pure White Clean Enterprise 라이트 모드 및 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건)
 */

"use strict";

const fs = require("fs");
const path = require("path");

class InboundBarcodeSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/inbound_barcode_inspections.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/inbound_barcode_config.json");

    this.ensureDirectory(this.storagePath);
    this.ensureDirectory(this.configPath);
  }

  ensureDirectory(filePath) {
    try {
      if (!filePath || typeof filePath !== "string") return;
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    } catch (e) {
      // ignore
    }
  }

  _loadAudits() {
    try {
      if (fs.existsSync(this.storagePath)) {
        const raw = fs.readFileSync(this.storagePath, "utf8");
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) ? parsed.filter(x => x && typeof x === "object") : [];
      }
    } catch (e) {
      // ignore
    }
    return [];
  }

  _saveAudits(audits) {
    try {
      const valid = (Array.isArray(audits) ? audits : []).filter(x => x && typeof x === "object");
      fs.writeFileSync(this.storagePath, JSON.stringify(valid, null, 2), "utf8");
      return true;
    } catch (e) {
      return false;
    }
  }

  getConfig() {
    const defaults = {
      enabled: true,
      storeName: "오토플로우 공식 스토어",
      sellerName: "대표자",
      minExpiryRatio: 0.70, // 쿠팡 FC 입고 시 잔여 유통기한 70% 이상 요구
      estimatedRoundtripFreightCost: 350000, // 파레트/차량 1회 반송 시 왕복 용차비(원)
      supportedBarcodeTypes: ["EAN-13", "CODE-128", "COUPANG-SKU"]
    };

    if (fs.existsSync(this.configPath)) {
      try {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        return Object.assign({}, defaults, (parsed && typeof parsed === "object") ? parsed : {});
      } catch (e) {
        return defaults;
      }
    }
    return defaults;
  }

  saveConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object") ? newConfig : {};
    const current = this.getConfig();
    const merged = Object.assign({}, current, newConfig);
    fs.writeFileSync(this.configPath, JSON.stringify(merged, null, 2), "utf8");
    return merged;
  }

  /**
   * EAN-13 표준 바코드 모듈로-10 체크섬 검증
   * @param {string} barcode 13자리 바코드
   * @returns {boolean}
   */
  isValidEan13(barcode) {
    if (!barcode || typeof barcode !== "string") return false;
    const clean = barcode.trim();
    if (!/^[0-9]{13}$/.test(clean)) return false;

    let sum = 0;
    for (let i = 0; i < 12; i++) {
      const digit = parseInt(clean[i], 10);
      sum += (i % 2 === 0) ? digit : digit * 3;
    }

    const checkDigit = (10 - (sum % 10)) % 10;
    return checkDigit === parseInt(clean[12], 10);
  }

  /**
   * Code 128 및 쿠팡 SKU 바코드 포맷 검증
   * 규격: 알파벳 대소문자, 숫자, 하이픈(-) 포함 6~30자리
   * @param {string} barcode
   * @returns {boolean}
   */
  isValidCode128(barcode) {
    if (!barcode || typeof barcode !== "string") return false;
    const clean = barcode.trim();
    return /^[A-Za-z0-9\-_]{6,30}$/.test(clean);
  }

  /**
   * 유통기한(소비기한) 잔여일수 및 쿠팡 FC 입고 적합성 판정
   * @param {string} mfgDate 제조일자 (YYYY-MM-DD 또는 YYYY.MM.DD)
   * @param {string} expDate 만료일자 (YYYY-MM-DD 또는 YYYY.MM.DD)
   * @param {string} inboundDate 입고예정일자 (기본 오늘)
   * @param {number} requiredRatio 요구 잔여율 (기본 0.70)
   * @returns {Object}
   */
  evaluateExpiryDate(mfgDate, expDate, inboundDate, requiredRatio = 0.70) {
    if (mfgDate && typeof mfgDate === "object") {
      const p = mfgDate;
      mfgDate = p.mfgDate || p.manufactureDate;
      expDate = expDate || p.expDate || p.expiryDate;
      inboundDate = inboundDate || p.inboundDate;
      if (p.requiredRatio !== undefined) requiredRatio = p.requiredRatio;
    }
    requiredRatio = (typeof requiredRatio === "number" && !isNaN(requiredRatio)) ? requiredRatio : 0.70;

    if (!expDate || typeof expDate !== "string" || !expDate.trim()) {
      return {
        hasExpiry: false,
        status: "NOT_APPLICABLE",
        isCompliant: true,
        message: "유통기한 관리 비대상 공산품"
      };
    }

    const cleanExp = expDate.replace(/\./g, "-").trim();
    const rawInbound = (typeof inboundDate === "string" && inboundDate.trim())
      ? inboundDate
      : new Date().toISOString().slice(0, 10);
    const cleanInbound = rawInbound.replace(/\./g, "-").trim();

    const expTime = new Date(cleanExp).getTime();
    const inTimeRaw = new Date(cleanInbound).getTime();
    const inTime = isNaN(inTimeRaw) ? Date.now() : inTimeRaw;

    if (isNaN(expTime)) {
      return {
        hasExpiry: true,
        status: "INVALID_FORMAT",
        isCompliant: false,
        message: "만료일자 날짜 포맷 오류 (YYYY-MM-DD 권장)"
      };
    }

    const remainingDays = Math.ceil((expTime - inTime) / (1000 * 3600 * 24));

    if (remainingDays <= 0) {
      return {
        hasExpiry: true,
        status: "EXPIRED",
        isCompliant: false,
        remainingDays,
        message: `유통기한 만료 (${remainingDays}일 경과, 입고 즉시 폐기/반송)`
      };
    }

    let totalLifespanDays = null;
    let remainingRatio = null;

    if (mfgDate && typeof mfgDate === "string" && mfgDate.trim()) {
      const cleanMfg = mfgDate.replace(/\./g, "-").trim();
      const mfgTime = new Date(cleanMfg).getTime();
      if (!isNaN(mfgTime) && expTime > mfgTime) {
        totalLifespanDays = Math.ceil((expTime - mfgTime) / (1000 * 3600 * 24));
        remainingRatio = remainingDays / totalLifespanDays;
      }
    }

    let status = "SAFE_INBOUND";
    let isCompliant = true;
    let message = `잔여 유통기한 ${remainingDays}일 (쿠팡 FC 입고 적합)`;

    if (remainingRatio !== null) {
      const ratioPercent = Math.round(remainingRatio * 100);
      if (remainingRatio < 0.50) {
        status = "CRITICAL_REJECT";
        isCompliant = false;
        message = `잔여 유통기한 ${ratioPercent}%로 기준(70%) 대폭 미달 (전량 반송 위험)`;
      } else if (remainingRatio < requiredRatio) {
        status = "EXPIRY_WARNING";
        isCompliant = false;
        message = `잔여 유통기한 ${ratioPercent}%로 쿠팡 권장 70% 미달 (입고 거부 주의)`;
      } else {
        message = `잔여 유통기한 ${ratioPercent}% (${remainingDays}일 잔여, 완벽 적합)`;
      }
    } else if (remainingDays < 90) {
      status = "EXPIRY_WARNING";
      isCompliant = false;
      message = `잔여일수 ${remainingDays}일 미만 (입고 승인 여부 사전 확인 요망)`;
    }

    return {
      hasExpiry: true,
      status,
      isCompliant,
      remainingDays,
      totalLifespanDays,
      remainingRatio,
      message
    };
  }

  /**
   * 로켓그로스 입고 상품 단일 검품
   * @param {Object} item 입고 상품 정보
   * @param {Object} customOptions
   * @returns {Object} 검품 결과
   */
  inspectInboundItem(item = {}, customOptions = {}) {
    item = (item && typeof item === "object") ? item : {};
    customOptions = (customOptions && typeof customOptions === "object") ? customOptions : {};
    const config = Object.assign({}, this.getConfig(), customOptions);

    const skuId = item.skuId || `SKU-${Date.now().toString().slice(-6)}`;
    const productName = item.productName || "입고 상품";
    const barcode = String(item.barcode || "").trim();
    const barcodeType = String(item.barcodeType || "EAN-13").toUpperCase();
    const palletQuantity = Math.max(1, parseInt(item.quantity || 1, 10) || 1);

    // 1. 바코드 정합성 판정
    let isBarcodeValid = false;
    let barcodeStatus = "UNKNOWN";
    let barcodeMessage = "";

    if (barcodeType === "EAN-13") {
      isBarcodeValid = this.isValidEan13(barcode);
      barcodeStatus = isBarcodeValid ? "VALID_EAN13" : "INVALID_EAN13_CHECKSUM";
      barcodeMessage = isBarcodeValid
        ? "EAN-13 체크섬(Modulo 10) 100% 정상 통과"
        : "EAN-13 체크섬 불일치 또는 13자리 숫자 미충족 (FC 스캐너 인식 불가)";
    } else {
      isBarcodeValid = this.isValidCode128(barcode);
      barcodeStatus = isBarcodeValid ? "VALID_CODE128" : "INVALID_CODE128_FORMAT";
      barcodeMessage = isBarcodeValid
        ? "Code 128 / 쿠팡 SKU 바코드 포맷 정상"
        : "Code 128 규격 미달 (특수문자 오류 또는 길이 미충족)";
    }

    // 2. 유통기한 판정
    const expiryEval = this.evaluateExpiryDate(
      item.manufactureDate || item.mfgDate,
      item.expiryDate || item.expDate,
      item.inboundDate,
      config.minExpiryRatio
    );

    // 3. 종합 위험도 및 반송 위험 비용 산출
    const isApproved = isBarcodeValid && expiryEval.isCompliant;
    let riskLevel = "SAFE";
    let rejectReason = null;
    let potentialFreightLoss = 0;

    if (!isApproved) {
      potentialFreightLoss = config.estimatedRoundtripFreightCost;
      if (!isBarcodeValid) {
        riskLevel = "CRITICAL_BARCODE_ERROR";
        rejectReason = barcodeMessage;
      } else if (!expiryEval.isCompliant) {
        riskLevel = expiryEval.status === "CRITICAL_REJECT" ? "CRITICAL_EXPIRY_REJECT" : "WARNING_EXPIRY_SHORTAGE";
        rejectReason = expiryEval.message;
      }
    }

    const actionRequired = !isApproved
      ? (isBarcodeValid ? "유통기한 미달 입고 전면 보류 및 공급사 반품" : "바코드 스티커 재부착 및 재발행")
      : "입고 승인 (이상 없음)";

    return {
      inspectionId: `INB-CHK-${Date.now()}`,
      timestamp: new Date().toISOString(),
      skuId,
      productName,
      barcode,
      barcodeType,
      palletQuantity,
      isBarcodeValid,
      barcodeStatus,
      barcodeMessage,
      expiryEvaluation: expiryEval,
      isApproved,
      overallPass: isApproved,
      riskLevel,
      rejectReason,
      potentialFreightLoss,
      savedReturnCost: potentialFreightLoss,
      actionRequired,
      barcodeResult: {
        isValid: isBarcodeValid,
        status: barcodeStatus,
        message: barcodeMessage,
        type: barcodeType
      },
      expiryResult: expiryEval,
      carrierDestination: item.fcCode || "쿠팡 안성/동탄/이천 물류센터(FC)"
    };
  }

  /**
   * Pure White Clean Enterprise 라이트 모드 국세청/쿠팡 공식 입고 검품 확인서 HTML 렌더링
   * 대한민국 공문서 표준 `(인쇄 시 직인 생략)` 준수 (붉은 직인 0건)
   * @param {Object} inspectionResult
   * @returns {string} HTML
   */
  generateInboundInspectionReportHtml(inspectionResult = {}) {
    inspectionResult = (inspectionResult && typeof inspectionResult === "object") ? inspectionResult : {};
    const base = this.inspectInboundItem(inspectionResult);
    inspectionResult = Object.assign({}, base, inspectionResult);
    const config = this.getConfig();
    const currentDate = new Date().toISOString().slice(0, 10);
    const exp = (inspectionResult.expiryEvaluation && typeof inspectionResult.expiryEvaluation === "object")
      ? Object.assign({}, base.expiryEvaluation, inspectionResult.expiryEvaluation)
      : base.expiryEvaluation;

    return `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>쿠팡 로켓그로스 풀필먼트(FC) 입고 바코드 사전 검품 확인서</title>
  <style>
    @page { size: A4 portrait; margin: 15mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Malgun Gothic", "Apple SD Gothic Neo", sans-serif;
      background: #ffffff;
      color: #0f172a;
      line-height: 1.5;
      margin: 0;
      padding: 24px;
    }
    .page-container {
      max-width: 800px;
      margin: 0 auto;
      border: 1px solid #cbd5e1;
      padding: 32px;
      background: #ffffff;
    }
    .header-table { width: 100%; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
    .title { font-size: 20px; font-weight: 800; color: #0f172a; }
    .doc-meta { font-size: 11px; color: #475569; text-align: right; }
    .section-title { font-size: 13px; font-weight: 800; color: #0f172a; margin: 18px 0 8px 0; border-left: 3px solid #2563eb; padding-left: 8px; }
    .info-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px; }
    .info-table th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 7px 10px; text-align: left; width: 24%; color: #334155; }
    .info-table td { border: 1px solid #cbd5e1; padding: 7px 10px; color: #0f172a; }
    .summary-box { background: #f1f5f9; border: 1px solid #cbd5e1; padding: 14px; border-radius: 4px; margin-bottom: 18px; }
    .stat-badge-pass { color: #16a34a; font-weight: 800; }
    .stat-badge-fail { color: #dc2626; font-weight: 800; }
    .official-sign { margin-top: 36px; text-align: center; border-top: 1px solid #cbd5e1; padding-top: 20px; font-size: 12px; color: #334155; }
    .no-print-btn { text-align: center; margin-bottom: 16px; }
    @media print {
      .no-print-btn { display: none; }
      body { padding: 0; }
      .page-container { border: none; padding: 0; }
    }
  </style>
</head>
<body>
  <div class="no-print-btn">
    <button onclick="window.print()" style="padding: 8px 18px; background: #0f172a; color: #ffffff; border: none; border-radius: 4px; font-size: 12px; font-weight: 700; cursor: pointer;">🖨️ 확인서 인쇄 / PDF 저장</button>
  </div>

  <div class="page-container">
    <table class="header-table">
      <tr>
        <td class="title">쿠팡 로켓그로스 입고 바코드 사전 검품 확인서</td>
        <td class="doc-meta">
          문서번호: ${inspectionResult.inspectionId}<br>
          검품일자: ${currentDate}<br>
          입고센터: ${inspectionResult.carrierDestination}
        </td>
      </tr>
    </table>

    <table class="info-table">
      <tr>
        <th>납품 화주 (스토어명)</th>
        <td>${config.storeName}</td>
        <th>납품 책임자</th>
        <td>${config.sellerName}</td>
      </tr>
      <tr>
        <th>상품명 (품명)</th>
        <td colspan="3" style="font-weight: 600;">${inspectionResult.productName}</td>
      </tr>
      <tr>
        <th>SKU 코드</th>
        <td style="font-family: monospace;">${inspectionResult.skuId}</td>
        <th>입고 수량</th>
        <td><strong>${Number(inspectionResult.palletQuantity).toLocaleString()} 개</strong></td>
      </tr>
    </table>

    <div class="summary-box">
      <table style="width: 100%; font-size: 12px;">
        <tr>
          <td style="width: 33%; text-align: center; border-right: 1px solid #cbd5e1;">
            <div style="font-size: 11px; color: #64748b;">바코드 스캔 규격</div>
            <div style="font-size: 16px; font-weight: 800; color: ${inspectionResult.isBarcodeValid ? '#16a34a' : '#dc2626'}; margin-top: 4px;">
              ${inspectionResult.isBarcodeValid ? '✅ 정격 통과' : '❌ 규격 오류'}
            </div>
          </td>
          <td style="width: 33%; text-align: center; border-right: 1px solid #cbd5e1;">
            <div style="font-size: 11px; color: #64748b;">유통기한 입고 적합성</div>
            <div style="font-size: 16px; font-weight: 800; color: ${exp.isCompliant ? '#16a34a' : '#dc2626'}; margin-top: 4px;">
              ${exp.isCompliant ? '✅ 잔여율 충족' : '⚠️ 입고 거부 위험'}
            </div>
          </td>
          <td style="width: 33%; text-align: center;">
            <div style="font-size: 11px; color: #64748b;">방어된 반송 용차비</div>
            <div style="font-size: 16px; font-weight: 800; color: #2563eb; margin-top: 4px;">
              ₩${Number(config.estimatedRoundtripFreightCost).toLocaleString()}원
            </div>
          </td>
        </tr>
      </table>
    </div>

    <div class="section-title">1. 바코드 라벨 물리적·디지털 정합성 상세 명세</div>
    <table class="info-table">
      <tr>
        <th>바코드 형태</th>
        <td>${inspectionResult.barcodeType}</td>
        <th>바코드 일련번호</th>
        <td style="font-family: monospace; font-weight: 700; font-size: 13px;">${inspectionResult.barcode}</td>
      </tr>
      <tr>
        <th>체크섬 검증 결과</th>
        <td colspan="3" class="${inspectionResult.isBarcodeValid ? 'stat-badge-pass' : 'stat-badge-fail'}">
          ${inspectionResult.barcodeMessage}
        </td>
      </tr>
    </table>

    <div class="section-title">2. 유통기한(소비기한) 풀필먼트 입고 기준 대사 명세</div>
    <table class="info-table">
      <tr>
        <th>관리 대상 여부</th>
        <td>${exp.hasExpiry ? '유통기한 관리 대상 품목' : '비관리 공산품'}</td>
        <th>잔여 유통기한</th>
        <td>${exp.remainingDays ? exp.remainingDays + '일 잔여' : '해당 없음'}</td>
      </tr>
      <tr>
        <th>쿠팡 FC 잔여율 판정</th>
        <td colspan="3" class="${exp.isCompliant ? 'stat-badge-pass' : 'stat-badge-fail'}">
          ${exp.message}
        </td>
      </tr>
    </table>

    <div style="font-size: 10px; color: #64748b; line-height: 1.6; margin-top: 16px;">
      1. 본 확인서는 쿠팡 로켓그로스 입고 가이드라인에 명시된 EAN-13 모듈로-10 체크섬 및 유통기한 70% 이상 잔여 기준을 사전 실측 검품한 증적입니다.<br>
      2. 바코드 체크섬 오류가 있는 제품을 물류센터에 입고시킬 경우 전량 하차 거부 및 왕복 용차비(약 35만 원)가 부과되므로, 반드시 본 확인서 승인 후 배차하십시오.<br>
      3. 물류센터 입고 검수 시 스캐너 인식 불량 분쟁 발생 시 본 증적서를 물류 지점장에 제출하여 소명할 수 있습니다.
    </div>

    <div class="official-sign">
      상기 입고 예정 물품은 쿠팡 풀필먼트 물류센터 사전 검품 규격을 100% 충족함을 확인합니다.<br><br>
      <strong>${currentDate}</strong><br><br>
      <strong>발급 화주: ${config.storeName} (${config.sellerName}) (인쇄 시 직인 생략)</strong><br>
      <span style="font-size: 10px; color: #94a3b8;">발급 시스템: AutoFlow Enterprise Inbound Barcode Sentinel v2.0 (인쇄 시 직인 생략)</span>
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * 검품 결과 영속화 및 통계 갱신
   * @param {Object} inspectionResult
   */
  recordInspection(inspectionResult = {}) {
    if (!inspectionResult || typeof inspectionResult !== "object") return false;
    try {
      let records = this._loadAudits();
      records.unshift(inspectionResult);
      if (records.length > 100) records = records.slice(0, 100);

      return this._saveAudits(records);
    } catch (e) {
      return false;
    }
  }

  /**
   * 입고 검품 요약 통계 조회
   * @returns {Object}
   */
  getInboundSummary() {
    let totalInspections = 0;
    let approvedCount = 0;
    let rejectedCount = 0;
    let totalProtectedFreight = 0;
    let pendingIssuesCount = 0;
    let recentInspections = this._loadAudits();

    totalInspections = recentInspections.length;

    recentInspections.forEach(rec => {
      if (!rec || typeof rec !== "object") return;
      if (rec.isApproved) {
        approvedCount++;
      } else {
        rejectedCount++;
        totalProtectedFreight += (rec.potentialFreightLoss || 350000);
        if (rec.riskLevel !== "RESOLVED_SAFE") {
          pendingIssuesCount++;
        }
      }
    });

    return {
      totalInspections,
      totalPassed: approvedCount,
      approvedCount,
      totalBlocked: rejectedCount,
      rejectedCount,
      totalSavedCost: totalProtectedFreight,
      totalProtectedFreight,
      pendingIssuesCount,
      recentInspections: recentInspections.slice(0, 10)
    };
  }

  getSummary() {
    return this.getInboundSummary();
  }

  /**
   * 바코드 재부착 또는 유통기한 정정 종결 처리
   * @param {string} inspectionId
   * @param {string} action
   * @param {string} note
   * @returns {Object}
   */
  resolveInboundIssue(inspectionId, action = "BARCODE_REPRINTED", note = "") {
    if (inspectionId && typeof inspectionId === "object") {
      const p = inspectionId;
      action = p.action || action;
      note = p.note || note;
      inspectionId = p.inspectionId || "";
    }
    inspectionId = typeof inspectionId === "string" ? inspectionId : String(inspectionId || "");
    if (!fs.existsSync(this.storagePath)) return { success: false, message: "검품 원장 없음" };

    try {
      let records = this._loadAudits();
      const target = records.find(r => r && r.inspectionId === inspectionId);
      if (!target) return { success: false, message: "검품 기록을 찾을 수 없음" };

      target.isApproved = true;
      target.riskLevel = "RESOLVED_SAFE";
      target.resolvedAt = new Date().toISOString();
      target.resolveAction = typeof action === "string" ? action : "BARCODE_REPRINTED";
      target.resolveNote = (typeof note === "string" && note) ? note : "바코드 재출력 및 라벨 재부착 완료 (입고 승인)";

      this._saveAudits(records);
      return { success: true, updatedRecord: target };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
}

module.exports = {
  InboundBarcodeSentinel,
  createInboundBarcodeSentinel: (options = {}) => new InboundBarcodeSentinel((options && typeof options === "object") ? options : {})
};
