#!/usr/bin/env node
/**
 * core/recharge_cli_kmong.js
 * AutoFlow Engine License Recharge Forwarder (Kmong Marketplace Edition)
 * Ponytail Ultra-Lightweight SSoT Forwarder (< 20 lines)
 */
process.env.AUTOFLOW_RECHARGE_CHANNEL = 'kmong';
module.exports = require('./recharge_cli.js');
