/**
 * core/safety_governor_spool_engine.js
 * AutoFlow Resident Defense Engine — 70% Safety Factor Limiter & Overflow Spool-Resume Dam
 *
 * [핵심 공학 원리 (Mechanical/Electrical Governor & Spillway Dam)]
 * 1. 워크플로우 단품(.n8n.json)은 카피가 가능한 정적 설계도이므로 리미터가 없는 직결(Unregulated) 구조임.
 *    소량(한계치 70% 이하)일 때는 단독으로도 돌아가지만, 대량 물량이 몰리면 외부 API(구글시트 분당 60회,
 *    쿠팡/스마트스토어 초당 제한) 및 메모리 한계(100%)를 정면 돌파하여 429 차단·중간 멈춤이 발생함.
 * 2. 상주형 방어 엔진(Resident Defense Engine — 30/90/365일 기간권 라이선스 활성 상태)이 켜져 있으면:
 *    - [Step 1: 잔여 스풀 선입선출 병합] 이전 턴에 모아둔 미처리 스풀 데이터를 1순위로 꺼내 신규 유입분과 병합(중복 자동 소거).
 *    - [Step 2: 한계치 70% 정격 절단] 파이프라인 내 가장 좁은 병목 구간의 물리적 한계치(100%)의 70%(Safety Factor = 0.70)만
 *      이번 턴에 안전 통과(approved_batch).
 *    - [Step 3: 초과분 원자적 스풀 적재] 70% 리미트를 넘어간 나머지 데이터(overflow_batch)는 버리지 않고
 *      로컬 디스크 스풀 금고(data/overflow_spool/)에 원자적(fsync + rename)으로 모아둠.
 *    - [Step 4: 쿨다운 후 무중단 자동 이어하기(Auto-Drain Resume)] 앞 작업 완료 및 안전 쿨다운 직후,
 *      모아둔 스풀 금고에서 다음 70% 물량을 자동으로 꺼내어 잔여 물량이 0건이 될 때까지 끝까지 이어서 완주함.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const SAFETY_FACTOR = 0.70; // 모든 물리적 한계치의 70%를 실사용 정격 한도(Rated Limit)로 강제
const MAX_RECENT_APPROVED_KEYS = 2000; // 기승인 주문 멱등키 링버퍼 크기

/**
 * 외부 API 및 로컬 리소스별 물리적 한계치(100% Max Capacity) 및 70% 안전 정격 한도 정의
 */
const CHANNEL_CAPACITY_SPECS = Object.freeze({
  GOOGLE_SHEETS: {
    channel: 'GOOGLE_SHEETS',
    labelKo: '구글 시트 API (분당 쓰기 한계 60건)',
    maxCapacity: 60,
    ratedLimit70: Math.floor(60 * SAFETY_FACTOR), // 42건
    cooldownMs: 60000
  },
  NAVER_SMARTSTORE: {
    channel: 'NAVER_SMARTSTORE',
    labelKo: '네이버 커머스 API (분당 안전 호출 한계 60건)',
    maxCapacity: 60,
    ratedLimit70: Math.floor(60 * SAFETY_FACTOR), // 42건
    cooldownMs: 30000
  },
  COUPANG_WING: {
    channel: 'COUPANG_WING',
    labelKo: '쿠팡 WING OpenAPI (배치 호출 한계 100건)',
    maxCapacity: 100,
    ratedLimit70: Math.floor(100 * SAFETY_FACTOR), // 70건
    cooldownMs: 15000
  },
  SOLAPI_ALIMTALK: {
    channel: 'SOLAPI_ALIMTALK',
    labelKo: '카카오 알림톡/SMS 발송 API (배치 한계 100건)',
    maxCapacity: 100,
    ratedLimit70: Math.floor(100 * SAFETY_FACTOR), // 70건
    cooldownMs: 10000
  },
  RECON_4WAY_SETTLEMENT: {
    channel: 'RECON_4WAY_SETTLEMENT',
    labelKo: '4자 대사 정산 메모리 배치 (단일 힙 한계 500건)',
    maxCapacity: 500,
    ratedLimit70: Math.floor(500 * SAFETY_FACTOR), // 350건
    cooldownMs: 15000
  },
  DEFAULT_PIPELINE: {
    channel: 'DEFAULT_PIPELINE',
    labelKo: '표준 복합 파이프라인 (구글시트+마켓 병목 기준 60건)',
    maxCapacity: 60,
    ratedLimit70: Math.floor(60 * SAFETY_FACTOR), // 42건
    cooldownMs: 60000
  }
});

const DEFAULT_SPOOL_DIR = path.join(__dirname, '..', 'data', 'overflow_spool');
const DEFAULT_AUDIT_LOG = path.join(__dirname, '..', 'logs', 'safety_governor_spool_audit.jsonl');

function resolveSpoolDir(options = {}, instanceSpoolDir = null) {
  if (options && options.spoolDir) return options.spoolDir;
  if (process.env.AUTOFLOW_OVERFLOW_SPOOL_DIR) return process.env.AUTOFLOW_OVERFLOW_SPOOL_DIR;
  if (instanceSpoolDir) return instanceSpoolDir;
  return DEFAULT_SPOOL_DIR;
}

function resolveAuditLogPath(options = {}, instanceAuditLogPath = null) {
  if (options && options.auditLogPath) return options.auditLogPath;
  if (process.env.AUTOFLOW_GOVERNOR_AUDIT_LOG_PATH) return process.env.AUTOFLOW_GOVERNOR_AUDIT_LOG_PATH;
  if (instanceAuditLogPath) return instanceAuditLogPath;
  return DEFAULT_AUDIT_LOG;
}

function ensureDirectory(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function sanitizeWorkflowId(rawId) {
  if (rawId && typeof rawId === 'object') {
    rawId = rawId.workflow_id || rawId.workflowId || 'default_workflow';
  }
  const cleaned = String(rawId || 'default_workflow').trim().replace(/[^a-zA-Z0-9_-]/g, '_');
  return cleaned || 'default_workflow';
}

/**
 * 개별 데이터 아이템의 멱등성 고유 키 추출 (중복 적재 및 중복 발송 원천 차단)
 */
function extractItemDedupKey(item) {
  if (item === null || item === undefined) return 'null_item';
  const target = (item && typeof item === 'object' && item.json && typeof item.json === 'object')
    ? item.json
    : item;

  if (typeof target === 'object') {
    const candidate = target.order_id || target.orderId || target.id || target.settlement_id || target.inquiry_id || target.product_id || target.dedup_key;
    if (candidate !== undefined && candidate !== null && String(candidate).trim() !== '') {
      return `ID:${String(candidate).trim()}`;
    }
  }
  const rawStr = typeof target === 'string' ? target : JSON.stringify(target);
  return `HASH:${crypto.createHash('sha256').update(rawStr).digest('hex').slice(0, 24)}`;
}

/**
 * 복합 채널 목록에서 가장 좁은 물리적 병목(Minimum Bottleneck)의 70% 안전 한도 산출
 */
function resolveBottleneckSpec(channels, customMaxCapacity = null) {
  if (Number.isFinite(customMaxCapacity) && customMaxCapacity > 0) {
    const maxCap = Math.max(1, Math.floor(customMaxCapacity));
    const rated = Math.max(1, Math.floor(maxCap * SAFETY_FACTOR));
    return {
      channel: 'CUSTOM_CAPACITY',
      labelKo: `사용자 지정 물리 한계(${maxCap}건)의 70% 안전 리미트`,
      maxCapacity: maxCap,
      ratedLimit70: rated,
      safetyFactor: SAFETY_FACTOR,
      cooldownMs: 30000
    };
  }

  const list = Array.isArray(channels) && channels.length > 0
    ? channels
    : (typeof channels === 'string' && channels.trim() ? [channels.trim()] : ['DEFAULT_PIPELINE']);

  let bottleneck = null;
  for (const rawCh of list) {
    const key = String(rawCh || '').trim().toUpperCase();
    const spec = CHANNEL_CAPACITY_SPECS[key] || CHANNEL_CAPACITY_SPECS.DEFAULT_PIPELINE;
    if (!bottleneck || spec.ratedLimit70 < bottleneck.ratedLimit70) {
      bottleneck = spec;
    }
  }

  const chosen = bottleneck || CHANNEL_CAPACITY_SPECS.DEFAULT_PIPELINE;
  return {
    ...chosen,
    safetyFactor: SAFETY_FACTOR
  };
}

function getInFlightItems(inFlightBatch) {
  if (!inFlightBatch) return [];
  if (Array.isArray(inFlightBatch)) return inFlightBatch;
  if (Array.isArray(inFlightBatch.items)) return inFlightBatch.items;
  return [];
}

function appendRecentApprovedKeys(existingKeys, itemsToAdd) {
  const list = Array.isArray(existingKeys) ? [...existingKeys] : [];
  const seen = new Set(list);
  for (const item of itemsToAdd) {
    const key = (typeof item === 'string' && (item.startsWith('ID:') || item.startsWith('HASH:') || item === 'null_item'))
      ? item
      : extractItemDedupKey(item);
    if (!seen.has(key)) {
      seen.add(key);
      list.push(key);
    }
  }
  while (list.length > MAX_RECENT_APPROVED_KEYS) {
    list.shift();
  }
  return list;
}

function evaluateLicenseGate(licenseStatus) {
  if (!licenseStatus || typeof licenseStatus !== 'object') {
    return { active: false, status: 'UNLICENSED' };
  }
  const active = Boolean(
    (licenseStatus.status === 'ACTIVE' || licenseStatus.active === true) &&
    !licenseStatus.is_expired &&
    !licenseStatus.is_blocked
  );
  return {
    active,
    status: licenseStatus.status || (active ? 'ACTIVE' : 'UNLICENSED')
  };
}

function appendAuditRecord(entry, options = {}) {
  try {
    const auditLogPath = resolveAuditLogPath(options);
    ensureDirectory(path.dirname(auditLogPath));
    const record = {
      timestamp: new Date().toISOString(),
      ...entry
    };
    fs.appendFileSync(auditLogPath, `${JSON.stringify(record)}\n`, 'utf8');
  } catch (e) {
    // non-fatal audit logging
  }
}

class SafetyGovernorSpoolEngine {
  constructor(options = {}) {
    this._customSpoolDir = options.spoolDir || null;
    this._customAuditLogPath = options.auditLogPath || null;
    this.spoolDir = resolveSpoolDir(options);
    this.auditLogPath = resolveAuditLogPath(options);
  }

  getSpoolFilePath(workflowId, options = {}) {
    const safeId = sanitizeWorkflowId(workflowId);
    const spoolDir = resolveSpoolDir(options, this._customSpoolDir);
    return path.join(spoolDir, `${safeId}.spool.json`);
  }

  appendAudit(entry, options = {}) {
    const mergedOptions = {
      ...options,
      auditLogPath: (options && options.auditLogPath) || this._customAuditLogPath || process.env.AUTOFLOW_GOVERNOR_AUDIT_LOG_PATH || DEFAULT_AUDIT_LOG
    };
    appendAuditRecord(entry, mergedOptions);
  }

  appendAuditRecord(entry, options = {}) {
    this.appendAudit(entry, options);
  }

  /**
   * 스풀 금고 파일 로드 (Torn-Write 발생 시 .bak 백업 자동 복구)
   */
  loadSpoolState(workflowId, options = {}) {
    const safeId = sanitizeWorkflowId(workflowId);
    const filePath = this.getSpoolFilePath(safeId, options);
    const bakPath = `${filePath}.bak`;

    const normalizeLoaded = (parsed) => {
      if (!parsed || !Array.isArray(parsed.queue)) return null;
      if (!Array.isArray(parsed.recent_approved_keys)) {
        parsed.recent_approved_keys = [];
      } else if (parsed.recent_approved_keys.length > MAX_RECENT_APPROVED_KEYS) {
        parsed.recent_approved_keys = parsed.recent_approved_keys.slice(-MAX_RECENT_APPROVED_KEYS);
      }
      if (Array.isArray(parsed.in_flight_batch)) {
        parsed.in_flight_batch = parsed.in_flight_batch.length > 0
          ? {
              batch_id: `BATCH-LEGACY-${Date.now()}`,
              source: 'DRAIN',
              created_at: parsed.last_drained_at || parsed.last_regulated_at || new Date().toISOString(),
              items: parsed.in_flight_batch
            }
          : null;
      } else if (parsed.in_flight_batch && typeof parsed.in_flight_batch === 'object') {
        if (!Array.isArray(parsed.in_flight_batch.items) || parsed.in_flight_batch.items.length === 0) {
          parsed.in_flight_batch = null;
        }
      } else {
        parsed.in_flight_batch = null;
      }
      parsed.total_ingested = parsed.total_ingested || 0;
      parsed.total_approved = parsed.total_approved || 0;
      parsed.total_spooled = parsed.total_spooled || 0;
      parsed.total_duplicates_dropped = parsed.total_duplicates_dropped || 0;
      parsed.total_drained_resumed = parsed.total_drained_resumed || 0;
      parsed.batches_completed = parsed.batches_completed || 0;
      return parsed;
    };

    const tryParse = (p) => {
      if (!fs.existsSync(p)) return null;
      try {
        const raw = fs.readFileSync(p, 'utf8');
        const parsed = JSON.parse(raw);
        return normalizeLoaded(parsed);
      } catch (e) {
        return null;
      }
    };

    const primary = tryParse(filePath);
    if (primary) return primary;

    const backup = tryParse(bakPath);
    if (backup) return backup;

    return {
      workflow_id: safeId,
      channel_spec: CHANNEL_CAPACITY_SPECS.DEFAULT_PIPELINE,
      queue: [],
      in_flight_batch: null,
      recent_approved_keys: [],
      total_ingested: 0,
      total_approved: 0,
      total_spooled: 0,
      total_duplicates_dropped: 0,
      total_drained_resumed: 0,
      batches_completed: 0,
      last_regulated_at: null,
      last_drained_at: null,
      last_committed_at: null,
      next_resume_available_at: null
    };
  }

  /**
   * 원자적(Atomic) 스풀 금고 저장 (fsync + rename + .bak 보존)
   */
  saveSpoolState(workflowId, state, options = {}) {
    const safeId = sanitizeWorkflowId(workflowId);
    const spoolDir = resolveSpoolDir(options, this._customSpoolDir);
    ensureDirectory(spoolDir);
    const filePath = this.getSpoolFilePath(safeId, options);
    const bakPath = `${filePath}.bak`;
    const tmpPath = `${filePath}.tmp.${process.pid}.${Date.now()}`;

    const serialized = JSON.stringify(state, null, 2);
    const fd = fs.openSync(tmpPath, 'w');
    try {
      fs.writeSync(fd, serialized, 0, 'utf8');
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }

    if (fs.existsSync(filePath)) {
      try {
        fs.copyFileSync(filePath, bakPath);
      } catch (e) {}
    }
    fs.renameSync(tmpPath, filePath);
  }

  /**
   * [핵심 1] 유입 데이터 70% 안전율 리미트 절단 + 초과분 스풀 금고 적재
   * - 라이선스가 비활성(만료/미보유)이면 리미터 없이 직결 통과(UNREGULATED_PASSTHROUGH)시켜
   *   워크플로우 불법 복제본이나 단품 단독 실행 시에는 70% 안전 댐 혜택을 받지 못하게 분리함.
   */
  regulateAndSpool(params = {}, licenseStatus = { status: 'ACTIVE', is_expired: false }, options = {}) {
    params = (params && typeof params === 'object') ? params : {};
    const workflowId = sanitizeWorkflowId(params.workflow_id || params.workflowId || 'default_workflow');
    const incomingItems = Array.isArray(params.items) ? params.items : [];
    const spec = resolveBottleneckSpec(params.channels || params.channel, params.max_capacity || params.maxCapacity);
    const spoolState = this.loadSpoolState(workflowId, options);
    const licenseGate = evaluateLicenseGate(licenseStatus);

    // 1. 상주형 방어 엔진 라이선스가 없거나 만료된 경우: 리미트 없는 직결 모드 (과부하 위험 노출)
    if (!licenseGate.active) {
      const willOverload = incomingItems.length > spec.maxCapacity;
      const exceedsSafety70 = incomingItems.length > spec.ratedLimit70;
      const warningMsg = exceedsSafety70
        ? `⚠️ [과부하 위험] 유입 데이터(${incomingItems.length}건)가 안전 한도(${spec.ratedLimit70}건, 한계치 ${spec.maxCapacity}건의 70%)를 초과했습니다! 상주형 방어 엔진 기간권이 비활성 상태이므로 리미트 없이 직결 실행되어 API 429 차단 또는 중간 멈춤이 발생할 수 있습니다.`
        : null;

      this.appendAudit({
        action: 'UNREGULATED_PASSTHROUGH_WARNING',
        workflow_id: workflowId,
        incoming_count: incomingItems.length,
        max_capacity: spec.maxCapacity,
        rated_limit_70: spec.ratedLimit70,
        will_overload: willOverload,
        license_status: licenseGate.status
      }, options);

      return {
        ok: true,
        status: 'UNREGULATED_PASSTHROUGH',
        governor_active: false,
        license_status: licenseGate.status,
        workflow_id: workflowId,
        channel: spec.channel,
        safety_factor: SAFETY_FACTOR,
        max_capacity: spec.maxCapacity,
        rated_limit_70: spec.ratedLimit70,
        incoming_count: incomingItems.length,
        duplicate_dropped_count: 0,
        duplicates_filtered: 0,
        approved_count: incomingItems.length,
        approved_batch: incomingItems, // 리미트 없이 100% 직결 방출 -> 대량일 때 외부 API 429/OOM 발생
        spooled_overflow_count: 0,
        spooled_count: 0,
        remaining_spool_count: spoolState.queue.length,
        remaining_queue_depth: spoolState.queue.length,
        overload_risk_warning: warningMsg,
        message: warningMsg || '⚠️ 상주형 방어 엔진 비활성 (무제한 직결 통과 모드)',
        message_en: exceedsSafety70
          ? `[Overload Risk] Incoming batch (${incomingItems.length} items) exceeds 70% rated limit (${spec.ratedLimit70}/${spec.maxCapacity}). Resident engine is inactive (unregulated passthrough).`
          : 'Resident defense engine inactive (unregulated passthrough mode).',
        upgrade_required_message: '70% 안전율 리미터 및 초과 데이터 자동 모아두기·이어하기(Overflow Spool & Resume)는 상주형 무인 방어 엔진(30/90/365일 패스) 활성 시에만 작동합니다.'
      };
    }

    // 2. 상주형 방어 엔진 라이선스 ACTIVE:
    //    기승인 링버퍼(recent_approved_keys) + 진행중 배치(in_flight_batch) + 기존 스풀 대기열(queue) 기준 멱등 중복 제거
    const combined = [];
    const seenKeys = new Set(Array.isArray(spoolState.recent_approved_keys) ? spoolState.recent_approved_keys : []);
    const inFlightItems = getInFlightItems(spoolState.in_flight_batch);
    for (const infItem of inFlightItems) {
      seenKeys.add(extractItemDedupKey(infItem));
    }

    const priorQueueLength = Array.isArray(spoolState.queue) ? spoolState.queue.length : 0;
    const queueKeys = new Set();
    for (const existingItem of spoolState.queue) {
      const key = extractItemDedupKey(existingItem);
      if (!queueKeys.has(key)) {
        queueKeys.add(key);
        seenKeys.add(key);
        combined.push(existingItem);
      }
    }

    const dedupedIncoming = [];
    let duplicateDroppedCount = 0;
    for (const newItem of incomingItems) {
      const key = extractItemDedupKey(newItem);
      if (!seenKeys.has(key)) {
        seenKeys.add(key);
        dedupedIncoming.push(newItem);
        combined.push(newItem);
      } else {
        duplicateDroppedCount++;
      }
    }

    // 3. 한계치의 70% 정격 한도(ratedLimit70)만큼만 이번 턴 통과, 나머지는 스풀 금고 적재
    const ratedLimit = spec.ratedLimit70;
    const approvedBatch = combined.slice(0, ratedLimit);
    const overflowQueue = combined.slice(ratedLimit);

    const nowMs = Date.now();
    const nowIso = new Date(nowMs).toISOString();
    const nextResumeIso = overflowQueue.length > 0
      ? new Date(nowMs + spec.cooldownMs).toISOString()
      : null;

    spoolState.channel_spec = spec;
    spoolState.queue = overflowQueue;
    if (approvedBatch.length > 0) {
      spoolState.in_flight_batch = {
        batch_id: `BATCH-${nowMs}-${Math.random().toString(36).slice(2, 8)}`,
        source: 'REGULATE',
        created_at: nowIso,
        items: approvedBatch
      };
      spoolState.recent_approved_keys = appendRecentApprovedKeys(spoolState.recent_approved_keys, approvedBatch);
    }
    const newlySpooledCount = Math.max(0, overflowQueue.length - Math.max(0, priorQueueLength - approvedBatch.length));
    spoolState.total_ingested = (spoolState.total_ingested || 0) + dedupedIncoming.length;
    spoolState.total_duplicates_dropped = (spoolState.total_duplicates_dropped || 0) + duplicateDroppedCount;
    spoolState.total_approved = (spoolState.total_approved || 0) + approvedBatch.length;
    spoolState.total_spooled = (spoolState.total_spooled || 0) + newlySpooledCount;
    spoolState.batches_completed = (spoolState.batches_completed || 0) + (approvedBatch.length > 0 ? 1 : 0);
    spoolState.last_regulated_at = nowIso;
    spoolState.next_resume_available_at = nextResumeIso;

    this.saveSpoolState(workflowId, spoolState, options);

    this.appendAudit({
      action: 'REGULATED_70_SPOOL_SLICE',
      workflow_id: workflowId,
      channel: spec.channel,
      max_capacity: spec.maxCapacity,
      rated_limit_70: ratedLimit,
      incoming_count: incomingItems.length,
      deduped_incoming_count: dedupedIncoming.length,
      approved_count: approvedBatch.length,
      remaining_spool_count: overflowQueue.length,
      duplicates_filtered: duplicateDroppedCount
    }, options);

    return {
      ok: true,
      status: 'REGULATED_70_SPOOL_ACTIVE',
      governor_active: true,
      license_status: 'ACTIVE',
      workflow_id: workflowId,
      channel: spec.channel,
      channel_label_ko: spec.labelKo,
      safety_factor: SAFETY_FACTOR,
      max_capacity: spec.maxCapacity,
      rated_limit_70: ratedLimit,
      incoming_count: incomingItems.length,
      deduped_incoming_count: dedupedIncoming.length,
      duplicates_filtered: duplicateDroppedCount,
      duplicate_dropped_count: duplicateDroppedCount,
      approved_count: approvedBatch.length,
      approved_batch: approvedBatch,
      spooled_overflow_count: overflowQueue.length,
      spooled_count: overflowQueue.length,
      remaining_spool_count: overflowQueue.length,
      remaining_queue_depth: overflowQueue.length,
      auto_resume_scheduled: overflowQueue.length > 0,
      cooldown_ms: spec.cooldownMs,
      next_resume_available_at: nextResumeIso,
      message: overflowQueue.length > 0
        ? `🛡️ [70% 안전 리미터 작동] 물리적 한계(${spec.maxCapacity}건)의 70%인 ${approvedBatch.length}건을 안전 통과시키고, 초과된 ${overflowQueue.length}건은 로컬 스풀 금고에 적재했습니다. 쿨다운 후 자동으로 이어서 처리합니다.`
        : `✅ [70% 안전 구간 이내] 전체 ${approvedBatch.length}건이 안전 정격 한도(${ratedLimit}건) 이내이므로 즉시 처리합니다.`,
      message_en: overflowQueue.length > 0
        ? `[70% Safety Limiter Active] Approved ${approvedBatch.length} items (70% of ${spec.maxCapacity} limit) and safely spooled ${overflowQueue.length} overflow items for automatic cooldown resume.`
        : `[Within 70% Rated Limit] All ${approvedBatch.length} items are within the ${ratedLimit}-item safety limit and processed immediately.`
    };
  }

  /**
   * [핵심 2] 스풀 금고에 모아놓은 초과 데이터를 다음 70% 안전 배치만큼 꺼내어 이어서 작업 진행 (Auto-Drain & Resume)
   */
  drainNextBatch(params = {}, licenseStatus = { status: 'ACTIVE', is_expired: false }, options = {}) {
    params = (params && typeof params === 'object') ? params : {};
    const workflowId = sanitizeWorkflowId(params.workflow_id || params.workflowId || 'default_workflow');
    const spoolState = this.loadSpoolState(workflowId, options);
    const licenseGate = evaluateLicenseGate(licenseStatus);

    if (!licenseGate.active) {
      return {
        ok: false,
        status: 'DRAIN_BLOCKED_LICENSE_EXPIRED',
        governor_active: false,
        workflow_id: workflowId,
        drained_count: 0,
        drained_batch: [],
        remaining_spool_count: spoolState.queue.length,
        remaining_queue_depth: spoolState.queue.length,
        message: `⚠️ 스풀 금고에 ${spoolState.queue.length}건의 미처리 초과 데이터가 안전하게 보관되어 있습니다. 상주형 방어 엔진 기간권을 연장하시면 즉시 이어서 완주됩니다.`,
        message_en: `Spool vault holds ${spoolState.queue.length} pending overflow items. Activate or renew your Resident Defense Engine pass to resume draining immediately.`
      };
    }

    const spec = spoolState.channel_spec || CHANNEL_CAPACITY_SPECS.DEFAULT_PIPELINE;
    const channel = spec.channel || 'DEFAULT_PIPELINE';
    const ratedLimit = params.custom_limit
      ? Math.max(1, Math.floor(Number(params.custom_limit)))
      : (spec.ratedLimit70 || Math.floor(60 * SAFETY_FACTOR));

    if (!Array.isArray(spoolState.queue) || spoolState.queue.length === 0) {
      spoolState.next_resume_available_at = null;
      this.saveSpoolState(workflowId, spoolState, options);
      return {
        ok: true,
        status: 'SPOOL_COMPLETELY_DRAINED',
        governor_active: true,
        workflow_id: workflowId,
        channel,
        rated_limit_70: ratedLimit,
        drained_count: 0,
        drained_batch: [],
        remaining_spool_count: 0,
        remaining_queue_depth: 0,
        total_ingested: spoolState.total_ingested || 0,
        total_approved: spoolState.total_approved || 0,
        total_spooled: spoolState.total_spooled || 0,
        total_duplicates_dropped: spoolState.total_duplicates_dropped || 0,
        total_drained_resumed: spoolState.total_drained_resumed || 0,
        batches_completed: spoolState.batches_completed || 0,
        message: '✅ 스풀 금고에 대기 중이던 모든 초과 데이터 이어하기가 100% 완료되었습니다 (잔여 0건).',
        message_en: 'All spooled overflow items have been 100% drained and resumed (0 remaining).'
      };
    }

    const nowMs = Date.now();
    const enforceCooldown = Boolean(params.enforce_cooldown === true || (options && options.enforceCooldown === true));
    if (enforceCooldown && spoolState.next_resume_available_at && nowMs < Date.parse(spoolState.next_resume_available_at)) {
      return {
        ok: true,
        status: 'COOLDOWN_WAIT',
        governor_active: true,
        workflow_id: workflowId,
        channel,
        drained_count: 0,
        drained_batch: [],
        remaining_queue_depth: spoolState.queue.length,
        remaining_spool_count: spoolState.queue.length,
        next_resume_available_at: spoolState.next_resume_available_at,
        wait_ms: Math.max(0, Date.parse(spoolState.next_resume_available_at) - nowMs),
        message: '쿨다운 대기 중입니다.',
        message_en: 'Waiting for safety cooldown window before next batch drain.'
      };
    }

    const drainedBatch = spoolState.queue.slice(0, ratedLimit);
    const remainingQueue = spoolState.queue.slice(ratedLimit);

    const nowIso = new Date(nowMs).toISOString();
    const nextResumeIso = remainingQueue.length > 0
      ? new Date(nowMs + (spec.cooldownMs || 60000)).toISOString()
      : null;

    spoolState.queue = remainingQueue;
    spoolState.in_flight_batch = {
      batch_id: `BATCH-${nowMs}-${Math.random().toString(36).slice(2, 8)}`,
      source: 'DRAIN',
      created_at: nowIso,
      items: drainedBatch
    };
    spoolState.recent_approved_keys = appendRecentApprovedKeys(spoolState.recent_approved_keys, drainedBatch);
    spoolState.total_approved = (spoolState.total_approved || 0) + drainedBatch.length;
    spoolState.total_drained_resumed = (spoolState.total_drained_resumed || 0) + drainedBatch.length;
    spoolState.batches_completed = (spoolState.batches_completed || 0) + 1;
    spoolState.last_drained_at = nowIso;
    spoolState.next_resume_available_at = nextResumeIso;

    this.saveSpoolState(workflowId, spoolState, options);

    this.appendAudit({
      action: 'SPOOL_BATCH_DRAINED_RESUMED',
      workflow_id: workflowId,
      drained_count: drainedBatch.length,
      remaining_spool_count: remainingQueue.length,
      total_drained_resumed: spoolState.total_drained_resumed
    }, options);

    return {
      ok: true,
      status: remainingQueue.length > 0 ? 'RESUMED_BATCH_MORE_PENDING' : 'RESUMED_FINAL_BATCH_COMPLETED',
      governor_active: true,
      workflow_id: workflowId,
      channel,
      safety_factor: SAFETY_FACTOR,
      max_capacity: spec.maxCapacity,
      rated_limit_70: ratedLimit,
      drained_count: drainedBatch.length,
      drained_batch: drainedBatch,
      remaining_spool_count: remainingQueue.length,
      remaining_queue_depth: remainingQueue.length,
      total_ingested: spoolState.total_ingested,
      total_approved: spoolState.total_approved,
      total_drained_resumed: spoolState.total_drained_resumed,
      batches_completed: spoolState.batches_completed,
      next_resume_available_at: nextResumeIso,
      message: remainingQueue.length > 0
        ? `🔄 [자동 이어하기 진행 중] 스풀 금고에서 ${drainedBatch.length}건을 꺼내 이어서 처리했습니다. (남은 대기 물량: ${remainingQueue.length}건)`
        : `🎉 [전량 이어하기 완주] 마지막 ${drainedBatch.length}건까지 모두 꺼내어 처리를 완료했습니다! (남은 대기 물량: 0건)`,
      message_en: remainingQueue.length > 0
        ? `[Auto-Resume In Progress] Drained ${drainedBatch.length} items from spool vault. (${remainingQueue.length} remaining)`
        : `[Auto-Resume Complete] Final ${drainedBatch.length} items drained and completed! (0 remaining)`
    };
  }

  /**
   * [핵심 2-B] 진행 중인 배치(in_flight_batch) 최종 성공 확정 (Commit)
   */
  commitInFlightBatch(paramsOrWorkflowId, options = {}) {
    const safeId = sanitizeWorkflowId(paramsOrWorkflowId);
    const spoolState = this.loadSpoolState(safeId, options);
    const inFlightItems = getInFlightItems(spoolState.in_flight_batch);
    const committedSource = (spoolState.in_flight_batch && spoolState.in_flight_batch.source) || null;

    if (inFlightItems.length === 0) {
      return {
        ok: true,
        status: 'NO_IN_FLIGHT_BATCH_TO_COMMIT',
        workflow_id: safeId,
        committed_count: 0,
        remaining_spool_count: spoolState.queue.length,
        remaining_queue_depth: spoolState.queue.length
      };
    }

    spoolState.recent_approved_keys = appendRecentApprovedKeys(spoolState.recent_approved_keys, inFlightItems);
    spoolState.in_flight_batch = null;
    spoolState.last_committed_at = new Date().toISOString();
    this.saveSpoolState(safeId, spoolState, options);

    this.appendAudit({
      action: 'IN_FLIGHT_BATCH_COMMITTED',
      workflow_id: safeId,
      source: committedSource,
      committed_count: inFlightItems.length,
      remaining_spool_count: spoolState.queue.length
    }, options);

    return {
      ok: true,
      status: 'IN_FLIGHT_BATCH_COMMITTED',
      workflow_id: safeId,
      source: committedSource,
      committed_count: inFlightItems.length,
      remaining_spool_count: spoolState.queue.length,
      remaining_queue_depth: spoolState.queue.length
    };
  }

  /**
   * [핵심 3] 이어하기 도중 외부 네트워크 단절 발생 시 꺼냈던 배치 원상복구 (Zero Data Loss Rollback)
   */
  rollbackInFlightBatch(paramsOrWorkflowId, options = {}) {
    const safeId = sanitizeWorkflowId(paramsOrWorkflowId);
    const spoolState = this.loadSpoolState(safeId, options);
    const restoredItems = getInFlightItems(spoolState.in_flight_batch);
    const rolledBackSource = (spoolState.in_flight_batch && spoolState.in_flight_batch.source) || 'DRAIN';

    if (restoredItems.length === 0) {
      return {
        ok: true,
        status: 'NO_IN_FLIGHT_BATCH',
        workflow_id: safeId,
        restored_count: 0,
        remaining_spool_count: spoolState.queue.length,
        remaining_queue_depth: spoolState.queue.length
      };
    }

    // 롤백된 아이템의 멱등키를 recent_approved_keys에서 제거하여 재처리 및 대기열 유효성 보존
    const rolledBackKeySet = new Set(restoredItems.map(extractItemDedupKey));
    spoolState.recent_approved_keys = (Array.isArray(spoolState.recent_approved_keys) ? spoolState.recent_approved_keys : [])
      .filter(k => !rolledBackKeySet.has(k));

    // 선입선출 순서 유지를 위해 restoredItems를 queue 맨 앞에 재적재(중복 제거)
    const restoredQueue = [];
    const seen = new Set();
    for (const item of [...restoredItems, ...spoolState.queue]) {
      const k = extractItemDedupKey(item);
      if (!seen.has(k)) {
        seen.add(k);
        restoredQueue.push(item);
      }
    }

    spoolState.queue = restoredQueue;
    spoolState.in_flight_batch = null;
    spoolState.total_approved = Math.max(0, (spoolState.total_approved || 0) - restoredItems.length);
    spoolState.batches_completed = Math.max(0, (spoolState.batches_completed || 0) - 1);
    if (rolledBackSource === 'DRAIN') {
      spoolState.total_drained_resumed = Math.max(0, (spoolState.total_drained_resumed || 0) - restoredItems.length);
    } else if (rolledBackSource === 'REGULATE') {
      spoolState.total_spooled = (spoolState.total_spooled || 0) + restoredItems.length;
    }

    this.saveSpoolState(safeId, spoolState, options);

    this.appendAudit({
      action: 'IN_FLIGHT_BATCH_ROLLED_BACK_TO_SPOOL',
      workflow_id: safeId,
      source: rolledBackSource,
      restored_count: restoredItems.length,
      remaining_spool_count: restoredQueue.length
    }, options);

    return {
      ok: true,
      status: 'ROLLED_BACK_TO_SPOOL_FRONT',
      workflow_id: safeId,
      source: rolledBackSource,
      restored_count: restoredItems.length,
      remaining_spool_count: restoredQueue.length,
      remaining_queue_depth: restoredQueue.length,
      total_approved: spoolState.total_approved,
      total_drained_resumed: spoolState.total_drained_resumed,
      batches_completed: spoolState.batches_completed
    };
  }

  /**
   * 쿨다운이 경과한 모든 대기 워크플로우 스풀 자동 이어하기 헬퍼
   */
  drainAllReadyWorkflows(licenseStatus = { status: 'ACTIVE', is_expired: false }, options = {}) {
    const licenseGate = evaluateLicenseGate(licenseStatus);
    if (!licenseGate.active) {
      return {
        ok: false,
        status: 'DRAIN_BLOCKED_LICENSE_EXPIRED',
        governor_active: false,
        drained_workflows_count: 0,
        results: []
      };
    }
    const spoolDir = resolveSpoolDir(options, this._customSpoolDir);
    if (!fs.existsSync(spoolDir)) {
      return { ok: true, governor_active: true, drained_workflows_count: 0, results: [] };
    }
    const files = fs.readdirSync(spoolDir).filter(f => f.endsWith('.spool.json'));
    const nowMs = Date.now();
    const results = [];

    for (const file of files) {
      const wfId = file.replace(/\.spool\.json$/, '');
      const st = this.loadSpoolState(wfId, options);
      const hasQueue = Array.isArray(st.queue) && st.queue.length > 0;
      const cooldownReady = !st.next_resume_available_at || nowMs >= Date.parse(st.next_resume_available_at);
      if (hasQueue && cooldownReady) {
        const res = this.drainNextBatch({ workflow_id: wfId, enforce_cooldown: true }, licenseStatus, options);
        results.push(res);
      }
    }

    const drainedWorkflowsCount = results.filter(r => r && r.ok && r.drained_count > 0).length;

    return {
      ok: true,
      governor_active: true,
      drained_workflows_count: drainedWorkflowsCount,
      results
    };
  }

  /**
   * 전체 워크플로우 스풀 금고 상태 요약 조회
   */
  getAllSpoolSummary(licenseStatus = { status: 'ACTIVE', is_expired: false }, options = {}) {
    const spoolDir = resolveSpoolDir(options, this._customSpoolDir);
    const files = fs.existsSync(spoolDir)
      ? fs.readdirSync(spoolDir).filter(f => f.endsWith('.spool.json'))
      : [];
    const targetFilterId = options && options.workflowId ? sanitizeWorkflowId(options.workflowId) : null;

    const workflows = [];
    let totalPendingInSpool = 0;
    let totalDrainedResumed = 0;
    let totalIngested = 0;
    let totalApproved = 0;
    let totalSpooled = 0;
    let totalDuplicatesDropped = 0;
    let totalBatchesCompleted = 0;

    for (const file of files) {
      const wfId = file.replace(/\.spool\.json$/, '');
      if (targetFilterId && wfId !== targetFilterId) continue;
      const st = this.loadSpoolState(wfId, options);
      const pending = Array.isArray(st.queue) ? st.queue.length : 0;
      totalPendingInSpool += pending;
      totalDrainedResumed += (st.total_drained_resumed || 0);
      totalIngested += (st.total_ingested || 0);
      totalApproved += (st.total_approved || 0);
      totalSpooled += (st.total_spooled || 0);
      totalDuplicatesDropped += (st.total_duplicates_dropped || 0);
      totalBatchesCompleted += (st.batches_completed || 0);

      workflows.push({
        workflow_id: st.workflow_id || wfId,
        channel: (st.channel_spec && st.channel_spec.channel) || 'DEFAULT_PIPELINE',
        max_capacity: (st.channel_spec && st.channel_spec.maxCapacity) || 60,
        rated_limit_70: (st.channel_spec && st.channel_spec.ratedLimit70) || 42,
        pending_spool_count: pending,
        spooled_queue_depth: pending,
        remaining_queue_depth: pending,
        in_flight_count: getInFlightItems(st.in_flight_batch).length,
        total_ingested: st.total_ingested || 0,
        total_approved: st.total_approved || 0,
        total_spooled: st.total_spooled || 0,
        total_duplicates_dropped: st.total_duplicates_dropped || 0,
        total_drained_resumed: st.total_drained_resumed || 0,
        batches_completed: st.batches_completed || 0,
        last_regulated_at: st.last_regulated_at,
        last_drained_at: st.last_drained_at,
        last_committed_at: st.last_committed_at || null,
        next_resume_available_at: st.next_resume_available_at
      });
    }

    const licenseGate = evaluateLicenseGate(licenseStatus);

    return {
      status: 'HEALTHY',
      governor_active: licenseGate.active,
      license_status: licenseGate.status,
      safety_factor: SAFETY_FACTOR,
      safety_factor_percent: 70,
      channel_specs: CHANNEL_CAPACITY_SPECS,
      total_pending_in_spool: totalPendingInSpool,
      spooled_queue_depth: totalPendingInSpool,
      total_ingested: totalIngested,
      total_approved: totalApproved,
      total_spooled: totalSpooled,
      total_duplicates_dropped: totalDuplicatesDropped,
      total_drained_resumed: totalDrainedResumed,
      batches_completed: totalBatchesCompleted,
      workflows
    };
  }
}

function regulateAndSpool(params = {}, licenseStatus = { status: 'ACTIVE', is_expired: false }, options = {}) {
  return new SafetyGovernorSpoolEngine(options).regulateAndSpool(params, licenseStatus, options);
}

function drainNextBatch(params = {}, licenseStatus = { status: 'ACTIVE', is_expired: false }, options = {}) {
  return new SafetyGovernorSpoolEngine(options).drainNextBatch(params, licenseStatus, options);
}

function commitInFlightBatch(paramsOrWorkflowId, options = {}) {
  return new SafetyGovernorSpoolEngine(options).commitInFlightBatch(paramsOrWorkflowId, options);
}

function rollbackInFlightBatch(paramsOrWorkflowId, options = {}) {
  return new SafetyGovernorSpoolEngine(options).rollbackInFlightBatch(paramsOrWorkflowId, options);
}

function drainAllReadyWorkflows(licenseStatus = { status: 'ACTIVE', is_expired: false }, options = {}) {
  return new SafetyGovernorSpoolEngine(options).drainAllReadyWorkflows(licenseStatus, options);
}

function getAllSpoolSummary(licenseStatus = { status: 'ACTIVE', is_expired: false }, options = {}) {
  return new SafetyGovernorSpoolEngine(options).getAllSpoolSummary(licenseStatus, options);
}

module.exports = {
  SAFETY_FACTOR,
  MAX_RECENT_APPROVED_KEYS,
  CHANNEL_CAPACITY_SPECS,
  SafetyGovernorSpoolEngine,
  resolveBottleneckSpec,
  extractItemDedupKey,
  appendAuditRecord,
  regulateAndSpool,
  drainNextBatch,
  commitInFlightBatch,
  rollbackInFlightBatch,
  drainAllReadyWorkflows,
  getAllSpoolSummary
};
