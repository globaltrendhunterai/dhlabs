#!/bin/bash
# AutoFlow Engine - License Top-Up Quick Launcher (macOS Universal Edition)
xattr -dr com.apple.quarantine "$(cd "$(dirname "$0")" && pwd)" 2>/dev/null || true
cd "$(dirname "$0")"
chmod +x ./bin/node ../bin/node 2>/dev/null || true

echo "============================================================"
echo "[AutoFlow Universal Self-Healing Engine License Top-Up]"
echo "============================================================"

# Resolve node executable (./bin/node -> ../bin/node -> /opt/homebrew/bin/node -> /usr/local/bin/node -> command -v node)
NODE_BIN=""
for candidate in "./bin/node" "../bin/node" "/opt/homebrew/bin/node" "/usr/local/bin/node"; do
  if [ -x "$candidate" ] && "$candidate" -v >/dev/null 2>&1; then
    NODE_BIN="$candidate"
    break
  fi
done
if [ -z "$NODE_BIN" ] && command -v node >/dev/null 2>&1; then
  CANDIDATE_CMD="$(command -v node)"
  if "$CANDIDATE_CMD" -v >/dev/null 2>&1; then
    NODE_BIN="$CANDIDATE_CMD"
  fi
fi

if [ -z "$NODE_BIN" ]; then
  echo "[ERROR] Node.js runtime not detected. Please install Node.js from https://nodejs.org"
  if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
    read -p "Press [Enter] to exit..."
  fi
  exit 1
fi

SCRIPT_FILE="recharge_cli.js"
if [ ! -f "$SCRIPT_FILE" ] && [ -f "./core/recharge_cli.js" ]; then
  SCRIPT_FILE="./core/recharge_cli.js"
fi

echo ""
echo "Select the duration of the license you purchased:"
echo "  [1] 30-Day Starter Top-Up (+30 days)"
echo "  [2] 90-Day Pro Top-Up (+90 days)"
echo "  [3] 180-Day Semi-Annual Top-Up (+180 days)"
echo "  [Enter] Default to 30 days"
USER_CHOICE=""
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "Enter choice (1/2/3 or days) [Default: 1]: " USER_CHOICE
fi

DAYS=30
if [ "$USER_CHOICE" = "2" ] || [ "$USER_CHOICE" = "90" ]; then
  DAYS=90
elif [ "$USER_CHOICE" = "3" ] || [ "$USER_CHOICE" = "180" ]; then
  DAYS=180
elif [ "$USER_CHOICE" = "1" ] || [ "$USER_CHOICE" = "30" ] || [ -z "$USER_CHOICE" ]; then
  DAYS=30
elif [[ "$USER_CHOICE" =~ ^[0-9]+$ ]]; then
  DAYS="$USER_CHOICE"
fi

echo ""
USER_KEY=""
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "Enter your Gumroad License Key (optional, press Enter to skip): " USER_KEY
fi
if [ -z "$USER_KEY" ]; then
  USER_KEY="GUMROAD_TOPUP_$(date +%s)"
fi

echo ""
"$NODE_BIN" "$SCRIPT_FILE" "$DAYS" "$USER_KEY" "Gumroad Top-Up (+${DAYS} days)" --lang=en

echo ""
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "Press [Enter] to close this window..."
fi
