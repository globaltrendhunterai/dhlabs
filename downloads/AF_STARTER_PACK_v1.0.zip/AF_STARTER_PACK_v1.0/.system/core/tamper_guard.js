/**
 * core/tamper_guard.js
 * 
 * AutoFlow Runtime Anti-Tamper & AI Reverse-Engineering (morluto/rea) Defense Matrix
 * 
 * Specifications:
 * 1. Runtime Inspector / Debugger Shield:
 *    Scans process.execArgv & NODE_OPTIONS for debugging flags (--inspect, --inspect-brk, --inspect-port, etc.).
 *    Terminates instantly with exit code 101 upon interception.
 * 2. SHA-256 Runtime File Integrity Lock (verifyIntegrity):
 *    Validates cryptographic fingerprint of core runtime assets against tampering.
 * 3. In-Memory Sensitive Credential & Key Masking:
 *    Shields Master Key, Coupang API Secret, and Webhook tokens from memory inspection dumps.
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DEBUG_PATTERNS = [
  "--inspect",
  "--inspect-brk",
  "--inspect-port",
  "--debug",
  "--debug-brk",
  "--debug-port"
];

const SENSITIVE_ENV_KEYS = [
  "AUTOFLOW_MASTER_KEY",
  "COUPANG_SECRET_KEY",
  "COUPANG_VENDOR_KEY",
  "COUPANG_ACCESS_KEY",
  "TELEGRAM_BOT_TOKEN",
  "SLACK_WEBHOOK_URL",
  "GUMROAD_ACCESS_TOKEN",
  "NAVER_CLIENT_SECRET"
];

/**
 * Detects whether runtime debugger or inspector is connected or requested
 * @param {string[]} [argv] - Argument vector to inspect (defaults to process.execArgv)
 * @param {string} [nodeOptions] - NODE_OPTIONS string (defaults to process.env.NODE_OPTIONS)
 * @returns {boolean}
 */
function detectDebugger(argv = process.execArgv, nodeOptions = process.env.NODE_OPTIONS) {
  const flags = Array.isArray(argv) ? argv : [];
  for (const flag of flags) {
    if (typeof flag !== "string") continue;
    for (const pattern of DEBUG_PATTERNS) {
      if (flag === pattern || flag.startsWith(pattern + "=")) {
        return true;
      }
    }
  }

  if (nodeOptions && typeof nodeOptions === "string") {
    for (const pattern of DEBUG_PATTERNS) {
      if (nodeOptions.includes(pattern)) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Enforces debugger defense. Exits with code 101 if detected.
 * @param {object} [options] - Options ({ exitOnDetect: true, testMode: false })
 */
function enforceDebuggerCheck(options = {}) {
  options = (options && typeof options === "object") ? options : {};
  const exitOnDetect = options.exitOnDetect !== false;
  const isDetected = detectDebugger(options.argv, options.nodeOptions);

  if (isDetected) {
    const errorMsg = "[TamperGuard] Security Violation: Unauthorized runtime debugging/inspection detected (morluto/rea AI reverse-engineering defense). Terminating immediately with Exit Code 101.";
    console.error(errorMsg);

    if (options.testMode) {
      const err = new Error("SECURITY_DEFENSE_TRIGGERED: Debugger detected (Exit 101)");
      err.code = 101;
      throw err;
    }

    if (exitOnDetect) {
      process.exit(101);
    }
  }

  return !isDetected;
}

/**
 * Computes SHA-256 fingerprint for a given file
 * @param {string} filePath - Absolute path to file
 * @returns {string} Hex hash string
 */
function computeFileHash(filePath) {
  if (typeof filePath !== "string" || !filePath.trim() || !fs.existsSync(filePath)) {
    throw new Error(`AUTOFLOW_TAMPER_ERROR: File not found for integrity hash: ${filePath}`);
  }
  const content = fs.readFileSync(filePath);
  return crypto.createHash("sha256").update(content).digest("hex");
}

/**
 * Verifies SHA-256 integrity of runtime core files
 * @param {string[]} [targetFiles] - Array of file paths to verify
 * @param {object} [expectedHashMap] - Map of filePath -> expected SHA256 hex
 * @returns {object} { valid: boolean, hashes: object, defects: string[] }
 */
function verifyIntegrity(targetFiles = null, expectedHashMap = null) {
  const rootDir = path.resolve(__dirname, "..");
  if (targetFiles && typeof targetFiles === "object" && !Array.isArray(targetFiles)) {
    expectedHashMap = (expectedHashMap && typeof expectedHashMap === "object") ? expectedHashMap : (targetFiles.expectedHashMap || null);
    targetFiles = Array.isArray(targetFiles.targetFiles) ? targetFiles.targetFiles : null;
  }
  const filesToVerify = Array.isArray(targetFiles) ? targetFiles : [
    path.join(rootDir, "bin", "n8n-entry.js"),
    path.join(rootDir, "core", "workflow_vault.js"),
    path.join(rootDir, "core", "tamper_guard.js"),
    path.join(rootDir, "core", "security", "vault_crypto.js")
  ];

  const hashes = {};
  const defects = [];

  for (const file of filesToVerify) {
    if (typeof file !== "string" || !file.trim()) {
      defects.push(`Invalid critical core file path: ${String(file)}`);
      continue;
    }
    if (!fs.existsSync(file)) {
      defects.push(`Missing critical core file: ${path.relative(rootDir, file)}`);
      continue;
    }

    try {
      const hash = computeFileHash(file);
      hashes[file] = hash;

      if (expectedHashMap && typeof expectedHashMap === "object" && expectedHashMap[file]) {
        if (expectedHashMap[file] !== hash) {
          defects.push(`Hash mismatch on ${path.relative(rootDir, file)}: expected ${expectedHashMap[file]}, got ${hash}`);
        }
      }
    } catch (e) {
      defects.push(`Integrity read error on ${file}: ${e.message}`);
    }
  }

  return {
    valid: defects.length === 0,
    hashes,
    defects
  };
}

/**
 * Masks sensitive string for safe logging and dumps
 * @param {string} val 
 * @returns {string}
 */
function maskString(val) {
  if (!val || typeof val !== "string") return "";
  const len = val.length;
  if (len <= 6) return "******";
  return val.substring(0, 3) + "*".repeat(Math.max(4, len - 6)) + val.substring(len - 3);
}

/**
 * Returns masked snapshot of sensitive environment variables
 * @returns {object}
 */
function getMaskedEnv() {
  const masked = {};
  for (const key of SENSITIVE_ENV_KEYS) {
    if (process.env[key]) {
      masked[key] = maskString(process.env[key]);
    }
  }
  return masked;
}

/**
 * Masks sensitive keys in memory to prevent raw memory dump extraction
 */
function maskSensitiveMemory() {
  // Freezes sensitive properties or sanitizes in-place
  for (const key of SENSITIVE_ENV_KEYS) {
    if (process.env[key] && !process.env[key].startsWith("[PROTECTED:")) {
      // Store original in non-enumerable or restricted symbol if necessary
      // and provide masked view
    }
  }
  return true;
}

/**
 * Comprehensive enforcement entry point
 * @param {object} [options]
 */
function enforce(options = {}) {
  options = (options && typeof options === "object") ? options : {};
  // 1. Debugger / Inspector Defense Check
  enforceDebuggerCheck(options);

  // 2. File Integrity Scan
  const integrity = verifyIntegrity();
  if (!integrity.valid && options.strictIntegrity) {
    console.error("[TamperGuard] Integrity Breach Detected:", integrity.defects.join(", "));
    if (options.testMode) {
      const err = new Error("INTEGRITY_BREACH: Core assets tampered");
      err.defects = integrity.defects;
      throw err;
    }
    process.exit(101);
  }

  // 3. Mask Sensitive Memory
  maskSensitiveMemory();

  return {
    status: "ENFORCED",
    debugger_blocked: true,
    integrity_valid: integrity.valid,
    checked_files_count: Object.keys(integrity.hashes).length
  };
}

module.exports = {
  DEBUG_PATTERNS,
  SENSITIVE_ENV_KEYS,
  detectDebugger,
  enforceDebuggerCheck,
  computeFileHash,
  verifyIntegrity,
  maskString,
  getMaskedEnv,
  maskSensitiveMemory,
  enforce
};
