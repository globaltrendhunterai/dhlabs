/**
 * core/workflow_vault.js
 * 
 * AutoFlow Enterprise Workflow Enclave & Anti-Reverse-Engineering Vault
 * Protects embedded n8n blueprint workflows against AI decompilation (morluto/rea).
 * 
 * Specifications:
 * - AES-256-GCM Authenticated Encryption with 128-bit Auth Tag
 * - Machine HWID & Master Key dual-bound Scrypt KDF Salt derivation
 * - In-memory decryption only; zero plaintext exposure on disk
 * - Strict Zero Python, Native Node.js crypto
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const os = require("os");

const UNIVERSAL_HWID = "AF-HWID-UNIVERSAL-ENCLAVE";

/**
 * Derives machine-unique Hardware ID (HWID)
 * Identical algorithm to n8n-entry.js and license manager
 */
function getLocalMachineHwid() {
  const nets = os.networkInterfaces();
  const macs = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (!net.internal && net.mac && net.mac !== "00:00:00:00:00:00") {
        macs.push(net.mac);
      }
    }
  }
  macs.sort();
  const seed = [os.hostname(), os.platform(), os.arch(), macs.join(":")].join("|");
  const hash = crypto.createHash("sha256").update(seed).digest("hex").substring(0, 16).toUpperCase();
  return `AF-HWID-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`;
}

/**
 * Resolves master passphrase from env, file, or default secure enterprise seed
 */
function resolveMasterPassphrase(customKey = null) {
  if (customKey && typeof customKey === "string" && customKey.trim().length > 0) {
    return customKey.trim();
  }
  if (process.env.AUTOFLOW_MASTER_KEY && process.env.AUTOFLOW_MASTER_KEY.trim() !== "") {
    return process.env.AUTOFLOW_MASTER_KEY.trim();
  }

  const rootDir = path.resolve(__dirname, "..");
  const candidateFiles = [".env.production", ".env"];

  for (const envFile of candidateFiles) {
    const envPath = path.join(rootDir, envFile);
    if (fs.existsSync(envPath)) {
      try {
        const content = fs.readFileSync(envPath, "utf8");
        const match = content.match(/^AUTOFLOW_MASTER_KEY\s*=\s*(.+)$/m);
        if (match && match[1]) {
          const key = match[1].trim().replace(/^['"]|['"]$/g, "");
          if (key) return key;
        }
      } catch (err) {
        // continue
      }
    }
  }

  return "AUTOFLOW_ENTERPRISE_OFFLINE_MASTER_KEY_2026_N8N_SECURE_VAULT_SEED";
}

/**
 * Derives a 32-byte AES-256 key bound to both salt and machine HWID
 */
function deriveHwidKey(passphrase, salt, hwid) {
  if (!passphrase || typeof passphrase !== "string") {
    throw new Error("AUTOFLOW_VAULT_ERROR: Passphrase must be a non-empty string");
  }
  if (!Buffer.isBuffer(salt)) {
    throw new Error("AUTOFLOW_VAULT_ERROR: Salt must be a valid Buffer");
  }

  const effectiveHwid = hwid || UNIVERSAL_HWID;
  const combinedSalt = crypto
    .createHash("sha256")
    .update(salt)
    .update(Buffer.from(effectiveHwid, "utf8"))
    .digest();

  return crypto.scryptSync(passphrase, combinedSalt, 32, {
    N: 16384,
    r: 8,
    p: 1,
    maxmem: 64 * 1024 * 1024
  });
}

/**
 * Encrypts arbitrary workflow object/JSON into an AES-256-GCM cipher envelope
 * 
 * @param {object|string} workflowData - Workflow JSON or string
 * @param {string} [customMasterKey] - Optional master key override
 * @param {string} [targetHwid] - Optional HWID binding ('AF-HWID-UNIVERSAL-ENCLAVE' or specific HWID)
 * @returns {object} Cipher envelope
 */
function encryptWorkflow(workflowData, customMasterKey = null, targetHwid = null) {
  const masterKey = resolveMasterPassphrase(customMasterKey);
  const effectiveHwid = targetHwid || UNIVERSAL_HWID;

  let plainText;
  let nodeCount = 0;
  let tier = "AUTOFLOW_READY_MADE";

  if (typeof workflowData === "string") {
    plainText = workflowData;
    try {
      const parsed = JSON.parse(workflowData);
      nodeCount = (parsed.nodes && parsed.nodes.length) || 0;
      tier = parsed.tier || tier;
    } catch (e) {
      // plain string
    }
  } else if (typeof workflowData === "object" && workflowData !== null) {
    plainText = JSON.stringify(workflowData);
    nodeCount = (workflowData.nodes && workflowData.nodes.length) || 0;
    tier = workflowData.tier || tier;
  } else {
    throw new Error("AUTOFLOW_VAULT_ERROR: workflowData must be an object or JSON string");
  }

  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12); // NIST 96-bit IV
  const key = deriveHwidKey(masterKey, salt, effectiveHwid);

  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([
    cipher.update(Buffer.from(plainText, "utf8")),
    cipher.final()
  ]);

  const tag = cipher.getAuthTag(); // 128-bit authentication tag

  return {
    format: "AUTOFLOW-VAULT-v1",
    cipher: "AES-256-GCM",
    kdf: "scrypt-hwid",
    hwid: effectiveHwid,
    salt: salt.toString("hex"),
    iv: iv.toString("hex"),
    tag: tag.toString("hex"),
    ciphertext: encrypted.toString("hex"),
    node_count: nodeCount,
    tier: tier,
    created_at: new Date().toISOString()
  };
}

/**
 * Decrypts an AES-256-GCM cipher envelope strictly in memory
 * 
 * @param {object|string} envelope - Cipher envelope
 * @param {string} [customMasterKey] - Optional master key override
 * @param {string} [currentHwid] - Current machine HWID for strict binding verification
 * @returns {object} Decrypted workflow object
 */
function decryptWorkflow(envelope, customMasterKey = null, currentHwid = null) {
  let env = envelope;
  if (typeof envelope === "string") {
    try {
      env = JSON.parse(envelope);
    } catch (e) {
      throw new Error("AUTOFLOW_VAULT_ERROR: Invalid envelope JSON: " + e.message);
    }
  }

  if (!env || !env.salt || !env.iv || !env.tag || !env.ciphertext) {
    throw new Error("AUTOFLOW_VAULT_ERROR: Malformed cipher envelope. Missing required security parameters");
  }

  // HWID Lock Verification: If bound to a specific HWID, ensure matching
  const expectedHwid = env.hwid || UNIVERSAL_HWID;
  if (expectedHwid !== UNIVERSAL_HWID && currentHwid) {
    if (expectedHwid !== currentHwid) {
      throw new Error(`AUTOFLOW_VAULT_HWID_MISMATCH: Encrypted asset is locked to HWID ${expectedHwid}, current machine is ${currentHwid}`);
    }
  }

  const masterKey = resolveMasterPassphrase(customMasterKey);
  const salt = Buffer.from(env.salt, "hex");
  const iv = Buffer.from(env.iv, "hex");
  const tag = Buffer.from(env.tag, "hex");
  const ciphertext = Buffer.from(env.ciphertext, "hex");

  const key = deriveHwidKey(masterKey, salt, expectedHwid);
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(tag);

  let decryptedStr;
  try {
    decryptedStr = Buffer.concat([
      decipher.update(ciphertext),
      decipher.final()
    ]).toString("utf8");
  } catch (err) {
    throw new Error(`AUTOFLOW_VAULT_INTEGRITY_FAIL: Authentication tag mismatch or corrupted ciphertext (${err.message})`);
  }

  try {
    return JSON.parse(decryptedStr);
  } catch (parseErr) {
    throw new Error(`AUTOFLOW_VAULT_PARSE_ERROR: Failed to parse decrypted workflow JSON (${parseErr.message})`);
  }
}

/**
 * Encrypts a source JSON file to a destination .enc file on disk
 * 
 * @param {string} srcJsonPath - Path to plaintext workflow JSON
 * @param {string} destEncPath - Path to encrypted destination .enc file
 * @param {string} [customMasterKey] - Optional master key override
 * @param {string} [targetHwid] - Optional HWID binding
 * @returns {object} Cipher envelope written
 */
function encryptWorkflowFile(srcJsonPath, destEncPath, customMasterKey = null, targetHwid = null) {
  if (!fs.existsSync(srcJsonPath)) {
    throw new Error(`AUTOFLOW_VAULT_FILE_NOT_FOUND: Source workflow JSON not found at ${srcJsonPath}`);
  }

  const rawJson = fs.readFileSync(srcJsonPath, "utf8");
  const parsed = JSON.parse(rawJson);
  const envelope = encryptWorkflow(parsed, customMasterKey, targetHwid);

  const destDir = path.dirname(destEncPath);
  if (!fs.existsSync(destDir)) {
    fs.mkdirSync(destDir, { recursive: true });
  }

  fs.writeFileSync(destEncPath, JSON.stringify(envelope, null, 2), "utf8");
  return envelope;
}

/**
 * Loads and decrypts an encrypted .enc workflow file strictly in-memory
 * 
 * @param {string} encPath - Path to .enc file
 * @param {string} [customMasterKey] - Optional master key override
 * @param {string} [currentHwid] - Optional machine HWID
 * @returns {object} Decrypted workflow JSON object
 */
function loadEncryptedWorkflow(encPath, customMasterKey = null, currentHwid = null) {
  if (!fs.existsSync(encPath)) {
    throw new Error(`AUTOFLOW_VAULT_FILE_NOT_FOUND: Encrypted workflow file not found at ${encPath}`);
  }

  const rawEnc = fs.readFileSync(encPath, "utf8");
  const envelope = JSON.parse(rawEnc);
  const effectiveHwid = currentHwid || getLocalMachineHwid();

  return decryptWorkflow(envelope, customMasterKey, effectiveHwid);
}

module.exports = {
  UNIVERSAL_HWID,
  getLocalMachineHwid,
  resolveMasterPassphrase,
  deriveHwidKey,
  encryptWorkflow,
  decryptWorkflow,
  encryptWorkflowFile,
  loadEncryptedWorkflow
};
