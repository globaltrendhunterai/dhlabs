#!/usr/bin/env node
/**
 * core/activate_trial_cli.js
 * AutoFlow Engine On-Demand Complimentary Trial Activation Utility
 * Dual Language Support: English / Korean
 * Strict Zero Emojis / Pure ASCII Formatting
 * 
 * Modes:
 * 1. Online Mode (Daemon running): Sends HTTP POST to http://127.0.0.1:8080/api/license/activate_trial
 * 2. Offline Mode (Daemon stopped): Atomically updates license_state.json directly
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const os = require('os');
const crypto = require('crypto');

const PORT = parseInt(process.env.AUTOFLOW_PORT || '8080', 10);
const HOST = process.env.AUTOFLOW_HOST || '127.0.0.1';
const STATE_PATH = process.env.AUTOFLOW_LICENSE_STATE_PATH || path.join(__dirname, 'license_state.json');

// Language detection
const sysLang = (process.env.LANG || process.env.LC_ALL || '').toLowerCase();
const isEn = process.argv.includes('--lang=en') || (!sysLang.includes('ko') && !sysLang.includes('kr') && !process.argv.includes('--lang=ko'));

const T = {
  en: {
    header: '============================================================\n[AutoFlow Self-Healing Engine Trial Activation]\n============================================================',
    successTitle: '[OK] Complimentary Enterprise Engine Trial Activated!',
    engineStatus: 'Engine Status',
    statusActive: 'ACTIVE & OPERATIONAL',
    activatedAt: 'Activated At',
    trialPeriod: 'Trial Period',
    days: 'days',
    validUntil: 'Valid Until',
    machineHwid: 'Machine HWID',
    modeOnline: 'Online (Daemon Live)',
    modeOffline: 'Offline (Direct State File)',
    guardMessage: '[INFO] 127ms autonomous self-healing (Module A) and Dynamic N-Way Branch\n       Quorum Reconciliation (Module B) are fully active (TRIAL_7D_ALL_MODULES).',
    extendGuide: '[INFO] Workflow single purchase (WF_ENTRY 9,900 / WF_STANDARD 19,000 / WF_COMPLEX 29,000)\n       is perpetually owned and runs 24/7 forever. After the 7-day engine test,\n       pick only the modules you need (MODULE_A1_BYOK / MODULE_A2_MANAGED_AI / MODULE_B_BRANCH_RECON).',
    errInvalidDays: '[ERROR] Trial period must be a positive integer greater than 0.',
    usage: 'Usage: node activate_trial_cli.js [days] [token] [note] [--sku=WF_ENTRY|WF_STANDARD|WF_COMPLEX] [--lang=en|--lang=ko]'
  },
  ko: {
    header: '============================================================\n[AutoFlow 워크플로우 영구소장 + 7일 전체 엔진 무료 테스트 시동]\n============================================================',
    successTitle: '[OK] 사내 상주형 전체 엔진 모듈(A+B) 무료 테스트가 활성화되었습니다!',
    engineStatus: '엔진 가동 상태',
    statusActive: '정상 가동 중 (ACTIVE / TRIAL_7D_ALL_MODULES)',
    activatedAt: '시동 일시',
    trialPeriod: '무료 체험 기간',
    days: '일',
    validUntil: '유효 만료일',
    machineHwid: '기기 식별자 (HWID)',
    modeOnline: '온라인 (데몬 실시간 반영)',
    modeOffline: '오프라인 (로컬 상태 파일 갱신)',
    guardMessage: '[INFO] 127ms 무인 자가치유 엔진(모듈 A) 및 동적 다중 분기 정합성\n       합의 엔진(모듈 B)이 사내 PC에서 즉시 활성화되었습니다.',
    extendGuide: '[INFO] 구매하신 워크플로우 단품(입문 9,900원 / 표준 19,000원 / 복합 29,000원)은\n       7일 테스트 종료 후에도 멈추지 않고 평생 무료로 24시간 가동됩니다.\n       부가 엔진은 필요한 모듈(MODULE_A1_BYOK / MODULE_A2_MANAGED_AI / MODULE_B_BRANCH_RECON)만 골라 연장하십시오.',
    errInvalidDays: '[ERROR] 체험 일수는 1 이상의 양수여야 합니다.',
    usage: '사용법: node activate_trial_cli.js [일수] [토큰] [메모] [--sku=WF_ENTRY|WF_STANDARD|WF_COMPLEX] [--lang=en|--lang=ko]'
  }
};

const STR = isEn ? T.en : T.ko;

function getHwid() {
  try {
    if (fs.existsSync(STATE_PATH)) {
      const raw = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
      if (raw.hwid) return raw.hwid;
    }
  } catch (e) {}

  const nets = os.networkInterfaces();
  const macs = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (!net.internal && net.mac && net.mac !== '00:00:00:00:00:00') {
        macs.push(net.mac);
      }
    }
  }
  macs.sort();
  const seed = [os.hostname(), os.platform(), os.arch(), macs.join(':')].join('|');
  const hash = crypto.createHash('sha256').update(seed).digest('hex').substring(0, 16).toUpperCase();
  return `AF-HWID-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`;
}

const HWID = getHwid();

// Parse CLI Arguments
const skuArg = process.argv.find(a => a.startsWith('--sku='));
const requestedSku = skuArg ? skuArg.split('=')[1].toUpperCase() : 'WF_STANDARD';
const workflowSku = ['WF_ENTRY', 'WF_STANDARD', 'WF_COMPLEX'].includes(requestedSku) ? requestedSku : 'WF_STANDARD';
const rawArgs = process.argv.slice(2).filter(a => !a.startsWith('--lang=') && !a.startsWith('--sku='));

let days = skuArg ? 7 : 30;
if (rawArgs[0]) {
  const parsed = parseInt(rawArgs[0], 10);
  if (!isNaN(parsed) && parsed > 0) {
    days = parsed;
  } else {
    console.error(STR.errInvalidDays);
    console.log(STR.usage);
    process.exit(1);
  }
}

const token = rawArgs[1] || (isEn ? 'FREE_TRIAL_ACTIVATION' : '무료체험_활성화');
const note = rawArgs[2] || (isEn ? `${days}-Day Complimentary Engine Trial (${workflowSku})` : `${days}일 전체 엔진 무료 체험 시동 (${workflowSku})`);

function activateTrial() {
  const payload = JSON.stringify({ days, token, note, hwid: HWID, workflow_sku: workflowSku });
  const req = http.request(`http://${HOST}:${PORT}/api/license/activate_trial`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    },
    timeout: 3000
  }, (res) => {
    let raw = '';
    res.on('data', chunk => { raw += chunk; });
    res.on('end', () => {
      try {
        const json = JSON.parse(raw);
        if (res.statusCode === 200 && json.success) {
          printSuccess(days, json.activated_at, json.valid_until, STR.modeOnline);
        } else {
          fallbackDirectFileActivation();
        }
      } catch (e) {
        fallbackDirectFileActivation();
      }
    });
  });

  req.on('error', () => {
    fallbackDirectFileActivation();
  });

  req.on('timeout', () => {
    req.destroy();
    fallbackDirectFileActivation();
  });

  req.write(payload);
  req.end();
}

function fallbackDirectFileActivation() {
  try {
    let state = {};
    if (fs.existsSync(STATE_PATH)) {
      try {
        state = JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
      } catch (e) {
        state = {};
      }
    }

    const now = new Date();
    const expiryDate = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);

    state.status = 'ACTIVE';
    state.license_key = state.license_key || 'AF-ENTERPRISE-LOCAL';
    state.tier = state.tier || 'TRIAL_7D_ALL_MODULES';
    state.workflow_sku = workflowSku;
    state.workflow_perpetual_owned = true;
    state.enabled_modules = {
      self_healing: true,
      ai_mode: 'MANAGED',
      branch_reconciliation: true,
      trial_all_modules: true
    };
    state.activated_at = now.toISOString();
    state.valid_until = expiryDate.toISOString();
    state.total_extended_days = (state.total_extended_days || 0) + days;
    state.hwid = HWID;
    state.client_uuid = state.client_uuid || crypto.randomUUID();

    state.extension_history = state.extension_history || [];
    state.extension_history.push({
      add_days: days,
      extended_at: now.toISOString(),
      token: token,
      note: note,
      new_expiry: expiryDate.toISOString()
    });

    const tmpPath = `${STATE_PATH}.tmp.${Date.now()}`;
    fs.writeFileSync(tmpPath, JSON.stringify(state, null, 2), 'utf8');
    fs.renameSync(tmpPath, STATE_PATH);

    printSuccess(days, state.activated_at, state.valid_until, STR.modeOffline);
  } catch (err) {
    console.error(`[ERROR] Failed to activate trial directly: ${err.message}`);
    process.exit(1);
  }
}

function printSuccess(trialDays, activatedAt, validUntil, mode) {
  console.log(STR.header);
  console.log(STR.successTitle);
  console.log('------------------------------------------------------------');
  console.log(`- ${STR.engineStatus} : ${STR.statusActive}`);
  console.log(`- Workflow SKU  : ${workflowSku} (Perpetual Ownership Guaranteed)`);
  console.log(`- ${STR.activatedAt}  : ${activatedAt}`);
  console.log(`- ${STR.trialPeriod}  : ${trialDays} ${STR.days}`);
  console.log(`- ${STR.validUntil}   : ${validUntil}`);
  console.log(`- ${STR.machineHwid}  : ${HWID}`);
  console.log(`- Mode          : ${mode}`);
  console.log('------------------------------------------------------------');
  console.log(STR.guardMessage);
  console.log(STR.extendGuide);
  console.log('============================================================\n');
}

// Execute
activateTrial();
