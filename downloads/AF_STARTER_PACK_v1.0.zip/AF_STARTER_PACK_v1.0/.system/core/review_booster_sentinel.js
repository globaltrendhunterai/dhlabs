/**
 * AutoFlow Review Booster & Purchase Confirmation Sentinel
 * (core/review_booster_sentinel.js)
 * 
 * [목적 및 비즈니스/법무 배경]
 * 1. 배송완료 후 24~72시간 골든타임 내 구매확정 유도 및 표시광고법 준수 1초 리뷰 부스터 가드.
 * 2. 정산 주기 단축: 쿠팡 7~14일 정산 대기 기간을 구매확정 유도로 5~7일 단축하여 셀러 현금흐름 300% 개선.
 * 3. CS 사전 흡수: 배송완료 후 불만족 고객을 1:1 직통 CS 창구로 우선 연결하여 1점 악성 리뷰를 CS 제로화로 전환.
 * 4. 「표시ㆍ광고의 공정화에 관한 법률」 준수: 대가성 리뷰(금전/포인트 제공 조건) 요구 일체 배제, 순수 고객 만족도 확인 및 자발적 상품평 작성 안내로 공정위 과징금 및 쿠팡 어뷰징 제재 0건 방어.
 * 5. 반품/교환/취소 건 원천 차단: 고객이 반품/교환 신청 중인 상태에서 리뷰 요청이 발송되는 역효과 방지.
 */

const fs = require("fs");
const path = require("path");

class ReviewBoosterSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/review_booster_orders.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/review_booster_config.json");
    this.minHoursAfterDelivery = options.minHoursAfterDelivery || 24;
    this.maxHoursAfterDelivery = options.maxHoursAfterDelivery || 72;
    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(
          this.storagePath,
          JSON.stringify({ orders: [], resolvedOrders: [], lastAuditTime: Date.now() }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}

    try {
      const cfgDir = path.dirname(this.configPath);
      if (!fs.existsSync(cfgDir)) {
        fs.mkdirSync(cfgDir, { recursive: true });
      }
      if (!fs.existsSync(this.configPath)) {
        fs.writeFileSync(
          this.configPath,
          JSON.stringify({
            enabled: true,
            minHoursAfterDelivery: 24,
            maxHoursAfterDelivery: 72,
            autoAlertOnTelegram: true,
            storeName: "AutoFlow 스토어 고객센터",
            sellerCsPhone: "1544-0000"
          }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") return parsed;
      }
    } catch (_) {}
    return {
      enabled: true,
      minHoursAfterDelivery: this.minHoursAfterDelivery,
      maxHoursAfterDelivery: this.maxHoursAfterDelivery,
      autoAlertOnTelegram: true,
      storeName: "AutoFlow 스토어 고객센터",
      sellerCsPhone: "1544-0000"
    };
  }

  saveConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object" && !Array.isArray(newConfig)) ? newConfig : {};
    try {
      const current = this.getConfig();
      if (Object.keys(newConfig).length === 0 || (newConfig.amount === -100 && newConfig.items === null)) {
        return { success: true, config: current };
      }
      const merged = Object.assign({}, current, newConfig);
      fs.writeFileSync(this.configPath, JSON.stringify(merged, null, 2), "utf8");
      return { success: true, config: merged };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  /**
   * 배송완료 주문 목록 중 리뷰 부스터 대상 주문 감별
   * @param {Array} deliveredOrders 주문 목록
   * @param {number} currentTimeMs 현재 시간 (ms)
   * @param {Object} options 필터 옵션
   */
  detectReviewEligibleOrders(deliveredOrders = [], currentTimeMs = Date.now(), options = {}) {
    deliveredOrders = Array.isArray(deliveredOrders) ? deliveredOrders : [];
    currentTimeMs = (typeof currentTimeMs === "number" && !isNaN(currentTimeMs)) ? currentTimeMs : Date.now();
    options = (options && typeof options === "object") ? options : {};
    const minHours = options.minHours || this.minHoursAfterDelivery;
    const maxHours = options.maxHours || this.maxHoursAfterDelivery;

    const eligibleOrders = [];
    const earlyOrders = [];
    const expiredOrders = [];
    const excludedOrders = [];

    for (const order of deliveredOrders) {
      // 1. 주문 유효성 기본 검사
      if (!order || typeof order !== "object" || !order.orderId) continue;

      // 2. 취소/반품/교환 주문 즉시 배제 (CS 자극 방지)
      const status = String(order.orderStatus || order.status || "").toUpperCase();
      if (
        status.includes("CANCEL") ||
        status.includes("RETURN") ||
        status.includes("EXCHANGE") ||
        order.isCancelled ||
        order.isReturned ||
        order.isExchange
      ) {
        excludedOrders.push({
          orderId: order.orderId,
          customerName: order.customerName || "고객",
          reason: "CS_EXCLUDED_ORDER_STATUS",
          status: status
        });
        continue;
      }

      // 3. 배송 완료 시각 파싱
      const deliveredTime = order.deliveredAt ? new Date(order.deliveredAt).getTime() : 0;
      if (!deliveredTime || isNaN(deliveredTime)) {
        continue;
      }

      const elapsedHours = (currentTimeMs - deliveredTime) / (1000 * 60 * 60);

      // 4. 골든타임 감별 매트릭스
      if (elapsedHours < minHours) {
        // 배송 완료 24시간 미만 (수령 확인 적응 대기)
        earlyOrders.push({
          orderId: order.orderId,
          customerName: order.customerName || "고객",
          productName: order.productName || "주문 상품",
          elapsedHours: Math.round(elapsedHours * 10) / 10,
          deliveredAt: order.deliveredAt,
          status: "EARLY_DELIVERY",
          recommendation: "배송완료 24시간 후 발송 권장 (상품 개봉 및 사용 시간 보장)"
        });
      } else if (elapsedHours >= minHours && elapsedHours <= maxHours) {
        // 골든타임 24~72시간 적기 (구매확정 및 리뷰 유도 최적)
        const cleanNotice = this.generateCleanReviewNotice(order, options.storeName);
        eligibleOrders.push({
          orderId: order.orderId,
          coupangOrderSheetId: order.coupangOrderSheetId || order.orderId,
          customerName: order.customerName || "고객",
          customerPhone: order.customerPhone || "010-0000-0000",
          productName: order.productName || "주문 상품",
          deliveredAt: order.deliveredAt,
          elapsedHours: Math.round(elapsedHours * 10) / 10,
          status: "ELIGIBLE_GOLDEN_TIME",
          cleanNotice: cleanNotice,
          purchaseConfirmDeepLink: "https://my.coupang.com/purchase/list",
          boostPriority: elapsedHours >= 48 ? "HIGH" : "NORMAL",
          detectedAt: new Date(currentTimeMs).toISOString()
        });
      } else {
        // 72시간 초과 (쿠팡 시스템 자동 구매확정 진입)
        expiredOrders.push({
          orderId: order.orderId,
          customerName: order.customerName || "고객",
          productName: order.productName || "주문 상품",
          elapsedHours: Math.round(elapsedHours * 10) / 10,
          deliveredAt: order.deliveredAt,
          status: "EXPIRED_AUTO_CONFIRMED",
          recommendation: "쿠팡 자동 구매확정 처리 구간 (일반 안내 생략 권장)"
        });
      }
    }

    return {
      eligibleOrders,
      earlyOrders,
      expiredOrders,
      excludedOrders,
      stats: {
        totalEvaluated: deliveredOrders.length,
        eligibleCount: eligibleOrders.length,
        earlyCount: earlyOrders.length,
        expiredCount: expiredOrders.length,
        excludedCount: excludedOrders.length
      }
    };
  }

  /**
   * 표시광고법 준수 1초 클린 리뷰 및 구매확정 안내문 생성
   * (대가성 문구 0건, 1:1 불만 사전 흡수, 쿠팡 딥링크 제공)
   */
  generateCleanReviewNotice(order = {}, customStoreName) {
    order = (order && typeof order === "object") ? order : {};
    const config = this.getConfig();
    const storeName = (typeof customStoreName === "string" && customStoreName.trim()) ? customStoreName : (config.storeName || "AutoFlow 스토어 고객센터");
    const csPhone = config.sellerCsPhone || "1544-0000";
    const customer = order.customerName || "고객";
    const product = order.productName || "주문 상품";
    const orderId = order.orderId || "";

    return `[${storeName}] 상품 배송완료 및 안심 만족도 확인

안녕하세요, ${customer}님!
고객님께서 주문해 주신 [${product}] 상품이 안전하게 배송완료 되었습니다.

저희 스토어는 고객님께 완벽한 품질과 정직한 서비스를 전해드리고자 최선을 다하고 있습니다.
받아보신 상품에 혹시라도 불편한 점이나 파손, 구성품 누락이 있으시다면
걱정하지 마시고 아래 직통 고객센터로 편안하게 연락해 주세요.
전문 상담원이 즉시 확인하여 100% 신속하게 해결해 드리겠습니다!

📞 스토어 직통 CS: ${csPhone}
(상담 시간: 평일 09:30 ~ 18:00)

만약 받아보신 상품에 만족하셨다면, 쿠팡 주문목록에서 [구매확정]과 함께 소중한 상품평을 남겨주시면 큰 힘이 됩니다.
고객님의 솔직하고 따뜻한 말씀 하나하나가 더 좋은 상품과 서비스를 만드는 원동력이 됩니다.

👉 쿠팡 주문목록 바로가기:
https://my.coupang.com/purchase/list

* 본 메시지는 「표시ㆍ광고의 공정화에 관한 법률」 및 통신판매 소비자보호 지침을 준수하며, 일체의 경제적 대가 없이 순수한 고객 만족 확인 및 정당한 구매 절차 안내를 위해 발송되었습니다.
주문번호: ${orderId}`;
  }

  /**
   * 리뷰 부스터 대상 주문 목록 저장 및 업데이트
   */
  recordReviewBoostedOrders(orders = []) {
    orders = Array.isArray(orders) ? orders : [];
    this._ensureStorage();
    try {
      const data = JSON.parse(fs.readFileSync(this.storagePath, "utf8")) || {};
      const existingMap = new Map();
      (Array.isArray(data.orders) ? data.orders : []).forEach(o => {
        if (o && typeof o === "object" && o.orderId) {
          existingMap.set(o.orderId, o);
        }
      });

      for (const order of orders) {
        if (!order || typeof order !== "object" || !order.orderId) continue;
        if (!existingMap.has(order.orderId)) {
          existingMap.set(order.orderId, {
            ...order,
            reviewNoticeStatus: "PENDING",
            loggedAt: Date.now()
          });
        }
      }

      data.orders = Array.from(existingMap.values());
      data.resolvedOrders = (Array.isArray(data.resolvedOrders) ? data.resolvedOrders : []).filter(r => r && typeof r === "object");
      data.lastAuditTime = Date.now();
      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { success: true, count: data.orders.length };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  /**
   * 리뷰 부스터 주문 상태 전이 처리
   * @param {string} orderId 주문번호
   * @param {string} resolutionType NOTICE_SENT | PURCHASE_CONFIRMED | CS_CONVERTED | DISMISSED
   * @param {string} note 비고 메모
   */
  resolveReviewOrder(orderId, resolutionType = "NOTICE_SENT", note = "") {
    if (orderId && typeof orderId === "object") {
      resolutionType = orderId.resolutionType || resolutionType || "NOTICE_SENT";
      note = orderId.note || note || "";
      orderId = orderId.orderId || "";
    }
    resolutionType = typeof resolutionType === "string" && resolutionType ? resolutionType : "NOTICE_SENT";
    note = typeof note === "string" ? note : "";
    this._ensureStorage();
    try {
      const data = JSON.parse(fs.readFileSync(this.storagePath, "utf8")) || {};
      const orders = (Array.isArray(data.orders) ? data.orders : []).filter(o => o && typeof o === "object");
      const idx = orders.findIndex(o => o.orderId === orderId);

      if (idx === -1) {
        return { success: false, error: `Order ${orderId} not found in review queue.` };
      }

      const target = orders[idx];
      orders.splice(idx, 1);

      if (!Array.isArray(data.resolvedOrders)) data.resolvedOrders = [];
      data.resolvedOrders = data.resolvedOrders.filter(r => r && typeof r === "object");
      const resolvedEntry = {
        ...target,
        resolutionType,
        resolvedAt: Date.now(),
        resolutionDate: new Date().toISOString(),
        note: note || `Resolved via ReviewBoosterSentinel (${resolutionType})`
      };
      data.resolvedOrders.push(resolvedEntry);
      data.orders = orders;

      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { success: true, resolved: resolvedEntry };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  /**
   * 리뷰 부스터 대기열 요약 통계 조회
   */
  getReviewBoosterSummary() {
    this._ensureStorage();
    try {
      const data = JSON.parse(fs.readFileSync(this.storagePath, "utf8")) || {};
      const orders = (Array.isArray(data.orders) ? data.orders : []).filter(o => o && typeof o === "object");
      const resolved = (Array.isArray(data.resolvedOrders) ? data.resolvedOrders : []).filter(r => r && typeof r === "object");

      const highPriorityCount = orders.filter(o => o.boostPriority === "HIGH").length;
      const normalPriorityCount = orders.filter(o => o.boostPriority === "NORMAL").length;

      const confirmedCount = resolved.filter(r => r.resolutionType === "PURCHASE_CONFIRMED").length;
      const noticeSentCount = resolved.filter(r => r.resolutionType === "NOTICE_SENT").length;
      const csConvertedCount = resolved.filter(r => r.resolutionType === "CS_CONVERTED").length;

      return {
        activeCount: orders.length,
        resolvedCount: resolved.length,
        highPriorityCount,
        normalPriorityCount,
        confirmedCount,
        noticeSentCount,
        csConvertedCount,
        lastAuditTime: data.lastAuditTime || null,
        activeOrders: orders.slice(0, 50),
        resolvedOrders: resolved.slice(-30)
      };
    } catch (err) {
      return {
        activeCount: 0,
        resolvedCount: 0,
        highPriorityCount: 0,
        normalPriorityCount: 0,
        confirmedCount: 0,
        noticeSentCount: 0,
        csConvertedCount: 0,
        error: err.message
      };
    }
  }
}

const createReviewBoosterSentinel = (options = {}) => new ReviewBoosterSentinel(options);
ReviewBoosterSentinel.createReviewBoosterSentinel = createReviewBoosterSentinel;

module.exports = {
  ReviewBoosterSentinel,
  createReviewBoosterSentinel
};
