/**
 * core/watchdog.js
 * AutoFlow Autonomous Process Watchdog & Self-Recovery Supervisor
 * 
 * Features:
 * 1. Checks sidecar daemon (port 8080) and dynamic active n8n engine port every 15 seconds.
 * 2. Fork-bomb prevention: Verifies whether daemon PID is alive before spawning.
 * 3. Debounce: Triggers recovery only after 3 consecutive healthcheck failures.
 * 4. Keeps logs clean and rotated.
 */

const { spawn, execSync } = require('child_process');
const http = require('http');
const path = require('path');
const fs = require('fs');

const APP_ROOT = path.resolve(__dirname, '..');
const DAEMON_SCRIPT = path.join(__dirname, 'autoflow_sidecar_daemon.js');
const LOG_FILE = path.join(APP_ROOT, 'logs', 'watchdog.log');
const ACTIVE_PORT_FILE = path.join(APP_ROOT, 'logs', 'active_port.txt');
const ENGINE_PID_FILE = path.join(APP_ROOT, 'logs', 'engine.pid');

const logDir = path.dirname(LOG_FILE);
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  try {
    fs.appendFileSync(LOG_FILE, line, 'utf8');
  } catch (e) {
    console.warn("[AutoFlow Safety] Failed to append watchdog log:", e.message);
  }
  console.log(`[Watchdog] ${msg}`);
}

function getActivePort() {
  try {
    if (fs.existsSync(ACTIVE_PORT_FILE)) {
      const content = fs.readFileSync(ACTIVE_PORT_FILE, 'utf8').trim();
      const p = parseInt(content, 10);
      if (!isNaN(p) && p > 0 && p < 65536) {
        return p;
      }
    }
  } catch (e) {
    console.warn("[AutoFlow Safety] Failed to read active port:", e.message);
  }
  return parseInt(process.env.PORT || process.env.N8N_PORT || '5678', 10);
}

/**
 * PID 생존 및 프로세스 바이너리 커맨드라인 이중 교차 검증
 * 1단계: process.kill(pid, 0) 신호 테스트
 * 2단계: macOS/Linux 환경에서 ps -p [pid] -o comm= 커맨드로 실행 파일명이 node/n8n 포함하는지 검증
 * 타 앱(Chrome, Zoom 등)의 PID Wraparound(재사용) 오탐 방어
 */
function isPidRunning(pid, expectedKeywords = ['node', 'n8n']) {
  if (!pid || isNaN(pid) || pid <= 0) return false;

  // 1단계: 시그널 테스트
  let alive = false;
  try {
    process.kill(pid, 0);
    alive = true;
  } catch (e) {
    if (e.code === 'EPERM') {
      alive = true;
    } else {
      return false; // ESRCH
    }
  }

  if (!alive) return false;

  // 2단계: 프로세스 바이너리 실행명 교차 대조 (PID Wraparound 오탐 방어)
  try {
    if (process.platform === 'win32') {
      const out = execSync(`tasklist /FI "PID eq ${pid}" /NH`, {
        encoding: 'utf8',
        stdio: ['pipe', 'pipe', 'ignore'],
        timeout: 2000
      }).toLowerCase();
      return expectedKeywords.some(kw => out.includes(kw.toLowerCase()));
    } else {
      const comm = execSync(`ps -p ${pid} -o comm=`, {
        encoding: 'utf8',
        stdio: ['pipe', 'pipe', 'ignore'],
        timeout: 2000
      }).trim().toLowerCase();
      return expectedKeywords.some(kw => comm.includes(kw.toLowerCase()));
    }
  } catch (err) {
    console.warn(`[AutoFlow Safety] PID ${pid} process command cross-check warning:`, err.message);
    return false;
  }
}

function checkHttp(port, checkPath = '/healthz') {
  return new Promise((resolve) => {
    const req = http.get(`http://127.0.0.1:${port}${checkPath}`, (res) => {
      resolve(res.statusCode >= 200 && res.statusCode < 500);
    });
    req.on('error', () => resolve(false));
    req.setTimeout(2500, () => {
      req.destroy();
      resolve(false);
    });
  });
}

let daemonProc = null;
let consecutiveN8nFailures = 0;

function startDaemon() {
  if (daemonProc && !daemonProc.killed) {
    try { daemonProc.kill('SIGTERM'); } catch (e) {
      console.warn("[AutoFlow Safety] Failed to SIGTERM previous daemon:", e.message);
    }
  }
  log('Starting AutoFlow Sidecar Daemon on port 8080...');
  daemonProc = spawn(process.execPath, [DAEMON_SCRIPT], {
    detached: true,
    stdio: 'ignore',
    env: { ...process.env, AUTOFLOW_PORT: '8080' }
  });
  daemonProc.unref();
}

function recoverN8n() {
  const activePort = getActivePort();

  // 0. Fork Bomb Prevention: Verify if PID is currently running
  if (fs.existsSync(ENGINE_PID_FILE)) {
    try {
      const recordedPid = parseInt(fs.readFileSync(ENGINE_PID_FILE, 'utf8').trim(), 10);
      if (isPidRunning(recordedPid)) {
        log(`🛡️ Fork Bomb Guard: n8n engine process (PID: ${recordedPid}) is already running. Skipping recovery duplicate spawn.`);
        return false;
      }
    } catch (e) {
      console.warn("[AutoFlow Safety] Failed to check engine PID file:", e.message);
    }
  }

  log(`⚠️ Core n8n Engine unreachable on port ${activePort}. Triggering recovery...`);
  const composePath = path.join(APP_ROOT, 'docker-compose.yml');
  const enterpriseComposePath = path.join(APP_ROOT, 'docker-compose.enterprise.yml');

  // 1. Try Docker container mode if compose file exists and docker command available
  if (fs.existsSync(composePath) || fs.existsSync(enterpriseComposePath)) {
    try {
      const targetCompose = fs.existsSync(enterpriseComposePath) ? enterpriseComposePath : composePath;
      const p = spawn('docker', ['compose', '-f', targetCompose, 'restart', 'n8n'], { cwd: APP_ROOT, detached: true, stdio: 'ignore' });
      p.unref();
      log(`Docker compose restart n8n triggered with: ${path.basename(targetCompose)}`);
      return true;
    } catch (e) {
      log(`Docker recovery attempt skipped: ${e.message}`);
    }
  }

  // 2. Standalone Portable V8 Engine recovery (bin/node + bin/n8n-entry.js)
  const portableNode = path.join(APP_ROOT, 'bin', 'node');
  const entryScript = path.join(APP_ROOT, 'bin', 'n8n-entry.js');
  const nodeBin = fs.existsSync(portableNode) ? portableNode : process.execPath;

  if (fs.existsSync(entryScript)) {
    try {
      log('Starting standalone portable n8n engine process...');
      const standaloneLog = path.join(APP_ROOT, 'logs', 'standalone_engine.log');
      const out = fs.openSync(standaloneLog, 'a');
      const p = spawn(nodeBin, [entryScript], {
        cwd: APP_ROOT,
        detached: true,
        stdio: ['ignore', out, out],
        env: { ...process.env, PORT: String(activePort), N8N_PORT: String(activePort) }
      });
      p.unref();
      try {
        fs.closeSync(out);
      } catch (_) {}
      try {
        fs.writeFileSync(ENGINE_PID_FILE, String(p.pid), 'utf8');
      } catch (e) {
        console.warn("[AutoFlow Safety] Failed to persist engine PID:", e.message);
      }
      log(`Standalone n8n process spawned (PID: ${p.pid}, Port: ${activePort}).`);
      return true;
    } catch (e) {
      log(`Standalone recovery error: ${e.message}`);
    }
  }
  return false;
}

async function cycle() {
  const isDaemonAlive = await checkHttp(8080, '/healthz');
  if (!isDaemonAlive) {
    log('⚠️ Sidecar Daemon unreachable on port 8080. Initiating auto-recovery...');
    startDaemon();
  }

  const currentPort = getActivePort();
  const isN8nAlive = await checkHttp(currentPort, '/healthz');
  if (!isN8nAlive) {
    consecutiveN8nFailures++;
    log(`⚠️ Core n8n Engine unreachable on port ${currentPort} (${consecutiveN8nFailures}/3 failure count).`);
    if (consecutiveN8nFailures >= 3) {
      log(`🚨 3 consecutive healthcheck failures reached on port ${currentPort}. Executing recovery...`);
      consecutiveN8nFailures = 0;
      recoverN8n();
    }
  } else {
    if (consecutiveN8nFailures > 0) {
      log(`✅ Core n8n Engine recovered on port ${currentPort}. Resetting failure counter.`);
    }
    consecutiveN8nFailures = 0;
  }
}

if (require.main === module) {
  const activePort = getActivePort();
  log(`Watchdog Supervisor active. Monitoring ports 8080 (Daemon) & ${activePort} (n8n)...`);
  cycle();
  setInterval(cycle, 15000);
}

module.exports = {
  getActivePort,
  isPidRunning,
  checkHttp,
  recoverN8n,
  cycle,
  startDaemon,
  getConsecutiveFailures: () => consecutiveN8nFailures,
  setConsecutiveFailures: (v) => { consecutiveN8nFailures = v; }
};
