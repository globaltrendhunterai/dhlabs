@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title AutoFlow Enterprise Engine License & Top-Up Console
cd /d "%~dp0"

set "NODE_BIN="
if exist "%~dp0bin\node.exe" (
    set "NODE_BIN=%~dp0bin\node.exe"
) else if exist "%~dp0..\bin\node.exe" (
    set "NODE_BIN=%~dp0..\bin\node.exe"
) else (
    where node >nul 2>nul
    if !errorlevel! equ 0 set "NODE_BIN=node"
)

if "!NODE_BIN!"=="" (
    echo [*] Auto-downloading portable Node.js runtime ^(node-v20.18.0-win-x64^)...
    if not exist "%~dp0bin" mkdir "%~dp0bin"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference = 'SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $zipUrl = 'https://nodejs.org/dist/v20.18.0/node-v20.18.0-win-x64.zip'; $zipPath = Join-Path '%~dp0' 'bin\node_win_x64.zip'; $extractDir = Join-Path '%~dp0' 'bin\node_extract_tmp'; Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing; if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }; Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force; Copy-Item -Path (Join-Path $extractDir 'node-v20.18.0-win-x64\node.exe') -Destination (Join-Path '%~dp0' 'bin\node.exe') -Force; Remove-Item $zipPath -Force -ErrorAction SilentlyContinue; Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue"
    if exist "%~dp0bin\node.exe" (
        set "NODE_BIN=%~dp0bin\node.exe"
    ) else (
        echo ❌ Failed to download portable Node.js runtime. Please check your internet connection.
        pause
        exit /b 1
    )
)

set "SCRIPT_FILE=%~dp0recharge_cli.js"
if not exist "!SCRIPT_FILE!" (
    if exist "%~dp0core\recharge_cli.js" set "SCRIPT_FILE=%~dp0core\recharge_cli.js"
)

cls
echo ============================================================
echo ⚡ AutoFlow Enterprise Engine License ^& Top-Up Console
echo ============================================================
echo.
"!NODE_BIN!" "!SCRIPT_FILE!" status --lang=en
echo.
echo Select an operation:
echo  [1] Apply 1-Month (30 Days) Top-Up Pack  ($49)
echo  [2] Apply 3-Month (90 Days) Top-Up Pack  ($129 - 12%% OFF)
echo  [3] Apply 1-Year (365 Days) Top-Up Pack ($399 - 32%% OFF)
echo  [4] Enter Custom Days
echo  [5] Bind License Key / Token
echo  [6] Refresh Status
echo  [q] Quit
echo.
set /p choice="Your choice (1-6, q): "

if "!choice!"=="1" (
    "!NODE_BIN!" "!SCRIPT_FILE!" 30 "TOPUP_30DAYS_WIN_%RANDOM%" "1-Month Top-Up" --lang=en
) else if "!choice!"=="2" (
    "!NODE_BIN!" "!SCRIPT_FILE!" 90 "TOPUP_90DAYS_WIN_%RANDOM%" "3-Month Top-Up" --lang=en
) else if "!choice!"=="3" (
    "!NODE_BIN!" "!SCRIPT_FILE!" 365 "TOPUP_365DAYS_WIN_%RANDOM%" "1-Year Top-Up" --lang=en
) else if "!choice!"=="4" (
    set /p custom_days="Enter number of days to add: "
    "!NODE_BIN!" "!SCRIPT_FILE!" !custom_days! "TOPUP_CUSTOM_WIN_%RANDOM%" "Custom Top-Up" --lang=en
) else if "!choice!"=="5" (
    set /p token_val="Enter your License Key or Voucher Token: "
    "!NODE_BIN!" "!SCRIPT_FILE!" bind "!token_val!" --lang=en
) else if "!choice!"=="6" (
    cls
    "!NODE_BIN!" "!SCRIPT_FILE!" status --lang=en
) else if /i "!choice!"=="q" (
    exit /b 0
) else (
    echo Invalid option.
)

echo.
pause
