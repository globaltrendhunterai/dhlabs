#!/usr/bin/env node
/**
 * core/recharge_cli_gumroad.js
 * AutoFlow Engine License Recharge Forwarder (Gumroad Global Edition)
 * Ponytail Ultra-Lightweight SSoT Forwarder (< 20 lines)
 */
process.env.AUTOFLOW_RECHARGE_CHANNEL = 'gumroad';
module.exports = require('./recharge_cli.js');
