/**
 * AutoFlow Circuit Alert Sentinel (쿠팡 WING 인증 만료 긴급 안심 다이렉트 알림 센티널)
 * 
 * [목적]
 * 1. 3회 연속 인증 실패로 서킷 브레이커(계정 보호) 발동 시, 등록된 텔레그램/슬랙으로 
 *    단 1회 정갈한 [⚠️ 쿠팡 WING 인증 정보 갱신 안내] 긴급 알림을 다이렉트 발송.
 * 2. 무한 알림 도배(Spam) 및 레이트 리밋 차단을 방지하는 1회 발송 잠금(Alert Cooldown/Lock).
 * 3. 셋업 마법사 1초 수집 재개(POST /api/system/resume-engine) 시 안전 상태 리셋 지원.
 */

const https = require("https");
const http = require("http");
const fs = require("fs");
const path = require("path");

class CircuitAlertSentinel {
  constructor(options = {}) {
    this.alertSent = false;
    this.lastAlertTime = 0;
    this.alertCooldownMs = options.alertCooldownMs || (30 * 60 * 1000); // 30분 쿨다운
  }

  /**
   * 알림 발송 가능 여부 검사
   */
  canSendAlert() {
    if (this.alertSent) return false;
    const now = Date.now();
    if (now - this.lastAlertTime < this.alertCooldownMs) return false;
    return true;
  }

  /**
   * 긴급 안내 메시지 포맷팅
   */
  formatAlertMessage(reason = "AUTH_FAIL_LIMIT", failCount = 3) {
    return [
      "🛡️ [AutoFlow 안심 가드] 쿠팡 판매자 계정 보호 일시 정지 안내",
      "",
      "쿠팡 WING API 연속 인증 실패가 감지되어, 판매자 계정 잠김(Account Lock)을 예방하기 위해 자동 수집을 안전하게 일시 중단했습니다.",
      "",
      `• 상태: 쿠팡 API 인증 ${failCount}회 실패 일시 정지`,
      "• 원인 추정: 쿠팡 비밀번호 변경, 2차 인증 만료, 또는 WING API 키 재발급",
      "• 조치 안내: 셋업 마법사에 접속하여 최신 키로 갱신하거나 [수집 재개]를 눌러주세요.",
      "",
      "👉 셋업 마법사 열기: http://localhost:5678",
      "(안내: 본 알림은 계정 보호를 위해 1회만 발송되며, 설정 저장 시 자동 해제됩니다.)"
    ].join("\n");
  }

  /**
   * 등록된 채널(텔레그램/슬랙)로 비동기 긴급 안내 발송
   * @param {object} config - notification_settings.json 객체
   * @param {string} reason
   * @param {number} failCount
   * @returns {Promise<{sent: boolean, channel: string, message: string}>}
   */
  async sendDirectAlert(config = {}, reason = "AUTH_FAIL_LIMIT", failCount = 3) {
    if (!this.canSendAlert()) {
      return { sent: false, reason: "ALERT_ALREADY_SENT_OR_COOLDOWN" };
    }

    const message = this.formatAlertMessage(reason, failCount);
    let sentCount = 0;

    // 1. 텔레그램 발송 시도
    if (config.telegramToken && config.telegramChatId) {
      try {
        await this._sendTelegram(config.telegramToken.trim(), config.telegramChatId.trim(), message);
        sentCount++;
      } catch (e) {
        console.error("[CircuitAlertSentinel] 텔레그램 긴급 알림 발송 실패 (non-fatal):", e.message);
      }
    }

    // 2. 슬랙 발송 시도
    if (config.slackWebhookUrl) {
      try {
        await this._sendSlack(config.slackWebhookUrl.trim(), message);
        sentCount++;
      } catch (e) {
        console.error("[CircuitAlertSentinel] 슬랙 긴급 알림 발송 실패 (non-fatal):", e.message);
      }
    }

    this.alertSent = true;
    this.lastAlertTime = Date.now();

    return {
      sent: sentCount > 0,
      sent_channels: sentCount,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * 텔레그램 봇 API 호출 (네이티브 https)
   */
  _sendTelegram(token, chatId, text) {
    return new Promise((resolve, reject) => {
      const postData = JSON.stringify({
        chat_id: chatId,
        text: text,
        disable_web_page_preview: true
      });

      const options = {
        hostname: "api.telegram.org",
        port: 443,
        path: `/bot${token}/sendMessage`,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(postData)
        },
        timeout: 5000
      };

      const req = https.request(options, (res) => {
        let resData = "";
        res.on("data", chunk => resData += chunk);
        res.on("end", () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(resData);
          } else {
            reject(new Error(`Telegram API status ${res.statusCode}: ${resData}`));
          }
        });
      });

      req.on("error", reject);
      req.on("timeout", () => {
        req.destroy();
        reject(new Error("Telegram API request timed out (5s)"));
      });

      req.write(postData);
      req.end();
    });
  }

  /**
   * 슬랙 웹훅 호출 (네이티브 https/http)
   */
  _sendSlack(webhookUrl, text) {
    return new Promise((resolve, reject) => {
      const postData = JSON.stringify({ text: text });
      let urlObj;
      try {
        urlObj = new URL(webhookUrl);
      } catch (e) {
        return reject(new Error("Invalid Slack Webhook URL"));
      }

      const client = urlObj.protocol === "https:" ? https : http;
      const options = {
        hostname: urlObj.hostname,
        port: urlObj.port || (urlObj.protocol === "https:" ? 443 : 80),
        path: urlObj.pathname + urlObj.search,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(postData)
        },
        timeout: 5000
      };

      const req = client.request(options, (res) => {
        let resData = "";
        res.on("data", chunk => resData += chunk);
        res.on("end", () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(resData);
          } else {
            reject(new Error(`Slack API status ${res.statusCode}: ${resData}`));
          }
        });
      });

      req.on("error", reject);
      req.on("timeout", () => {
        req.destroy();
        reject(new Error("Slack Webhook request timed out (5s)"));
      });

      req.write(postData);
      req.end();
    });
  }

  /**
   * 서킷 브레이커 해제 및 수집 재개 시 상태 리셋
   */
  reset() {
    this.alertSent = false;
    this.lastAlertTime = 0;
  }
}

const defaultCircuitAlertSentinel = new CircuitAlertSentinel();

module.exports = {
  CircuitAlertSentinel,
  circuitAlertSentinel: defaultCircuitAlertSentinel
};
