/**
 * AutoFlow Tracking Validation & Fake-Invoice Defense Sentinel
 * 
 * [설계 목적]
 * 셀러가 송장 번호 오입력, 자릿수 누락, 택배사 코드 불일치 상태로 쿠팡 WING에
 * 출고 등록을 시도하여 발생하는 '가송장 등록 패널티', 판매자 신용 등급 강등,
 * 계정 정지 및 정산 보류를 사전에 1초 만에 원천 차단하는 송장 유효성 에어백 가드.
 * 
 * [주요 기능]
 * 1. 국내 8대 메이저 택배사(CJ대한통운, 우체국, 한진, 롯데, 로젠 등) 자릿수 규격 정밀 검증
 * 2. 가송장 의심 패턴(연속 번호, 동일 번호 반복, 자릿수 미달) 즉각 적출
 * 3. 텔레그램/슬랙 가송장 위험 사전 경고 포맷팅
 * 4. 셋업 마법사 1초 송장 검증 인터랙티브 모달 지원
 */

const fs = require("fs");
const path = require("path");

class TrackingValidationSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    // 국내 주요 택배사별 표준 자릿수 규격 맵
    this.courierSpecs = {
      CJ: { name: "CJ대한통운", validLengths: [10, 12], regex: /^\d{10}$|^\d{12}$/ },
      POST: { name: "우체국택배", validLengths: [13], regex: /^\d{13}$/ },
      HANJIN: { name: "한진택배", validLengths: [10, 12], regex: /^\d{10}$|^\d{12}$/ },
      LOTTE: { name: "롯데택배", validLengths: [12], regex: /^\d{12}$/ },
      LOGEN: { name: "로젠택배", validLengths: [11], regex: /^\d{11}$/ },
      KDEXP: { name: "경동택배", validLengths: [11, 16], regex: /^\d{11}$|^\d{16}$/ },
      DAESIN: { name: "대신택배", validLengths: [13], regex: /^\d{13}$/ },
      ILYANG: { name: "일양로지스", validLengths: [10], regex: /^\d{10}$/ }
    };
  }

  getCourierList() {
    return Object.keys(this.courierSpecs).map(code => ({
      code,
      name: this.courierSpecs[code].name,
      validLengths: this.courierSpecs[code].validLengths
    }));
  }

  /**
   * 가송장 의심 패턴(더미/테스트 번호) 감별
   */
  isSuspiciousFakeInvoice(cleanNum) {
    const str = String(
      typeof cleanNum === "string" || typeof cleanNum === "number"
        ? cleanNum
        : (cleanNum && (cleanNum.invoiceNumber || cleanNum.trackingNumber)) || ""
    ).trim();
    if (!str) return true;

    // 1. 모든 숫자가 동일한 경우 (예: 1111111111, 000000000000)
    if (/^(\d)\1+$/.test(str)) {
      return true;
    }

    // 2. 대표적 더미 시퀀스 (1234567890 등)
    if (str.startsWith("12345678") || str.startsWith("01234567")) {
      return true;
    }

    return false;
  }

  /**
   * 송장 번호 유효성 종합 검증
   * @param {string} courierCode - 택배사 코드 (CJ, POST, HANJIN 등)
   * @param {string} rawTrackingNumber - 원본 송장 번호
   * @returns {Object} 검증 결과
   */
  validate(courierCode, rawTrackingNumber) {
    if (courierCode && typeof courierCode === "object") {
      if (rawTrackingNumber === undefined || rawTrackingNumber === null) {
        rawTrackingNumber = courierCode.rawTrackingNumber || courierCode.trackingNumber || courierCode.invoiceNumber || "";
      }
      courierCode = courierCode.courierCode || courierCode.carrierCode || courierCode.courier || "CJ";
    }
    if (rawTrackingNumber && typeof rawTrackingNumber === "object") {
      rawTrackingNumber = rawTrackingNumber.rawTrackingNumber || rawTrackingNumber.trackingNumber || rawTrackingNumber.invoiceNumber || "";
    }
    const code = String(courierCode || "CJ").toUpperCase().trim();
    const raw = String(rawTrackingNumber || "").trim();
    const cleanNum = raw.replace(/[^0-9]/g, ""); // 하이픈 및 공백 제거

    const spec = this.courierSpecs[code];
    if (!spec) {
      return {
        isValid: false,
        courierCode: code,
        courierName: "미확인 택배사",
        cleanTrackingNumber: cleanNum,
        reason: `지원되지 않는 택배사 코드입니다: [${code}]`
      };
    }

    // 1. 공란 검사
    if (!cleanNum) {
      return {
        isValid: false,
        courierCode: code,
        courierName: spec.name,
        cleanTrackingNumber: "",
        reason: "송장 번호가 비어있습니다. (공란 발송 차단)"
      };
    }

    // 2. 자릿수 및 포맷 검사
    if (!spec.regex.test(cleanNum)) {
      return {
        isValid: false,
        courierCode: code,
        courierName: spec.name,
        cleanTrackingNumber: cleanNum,
        reason: `${spec.name} 송장 규격(${spec.validLengths.join(" 또는 ")}자리 숫자)과 일치하지 않습니다. (입력: ${cleanNum.length}자리)`
      };
    }

    // 3. 가송장 의심 패턴 검사
    if (this.isSuspiciousFakeInvoice(cleanNum)) {
      return {
        isValid: false,
        courierCode: code,
        courierName: spec.name,
        cleanTrackingNumber: cleanNum,
        reason: "가송장 의심 번호(연속/반복 더미 패턴)로 감지되었습니다. 쿠팡 패널티 예방을 위해 등록이 차단되었습니다."
      };
    }

    return {
      isValid: true,
      courierCode: code,
      courierName: spec.name,
      cleanTrackingNumber: cleanNum,
      reason: "정상 규격 송장 번호입니다."
    };
  }

  /**
   * 가송장 위험 경고 메시지 포맷팅
   */
  formatAlert(courierCode, trackingNumber, reason) {
    if (courierCode && typeof courierCode === "object") {
      trackingNumber = trackingNumber !== undefined ? trackingNumber : (courierCode.trackingNumber || courierCode.cleanTrackingNumber || "");
      reason = reason !== undefined ? reason : (courierCode.reason || "");
      courierCode = courierCode.courierCode || courierCode.carrierCode || "CJ";
    }
    const code = String(courierCode || "CJ").toUpperCase().trim();
    const spec = this.courierSpecs[code] || { name: code || "미확인 택배사" };
    const safeTracking = (trackingNumber && typeof trackingNumber === "object") ? "" : String(trackingNumber || "");
    const safeReason = (reason && typeof reason === "object") ? "" : String(reason || "송장 규격 불일치");
    return [
      "⚠️ [쿠팡 가송장 패널티 방어 — 비정상 송장 등록 차단]",
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
      `• 택배사: ${spec.name}`,
      `• 입력송장: ${safeTracking}`,
      `• 차단사유: ${safeReason}`,
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
      "🚨 잘못된 송장 등록 시 쿠팡 정산 보류 및 판매자 등급 강등이 발생합니다.",
      "송장 번호를 다시 확인하신 후 재전송하십시오."
    ].join("\n");
  }
}

const defaultTrackingValidationSentinel = new TrackingValidationSentinel();
const createTrackingValidationSentinel = (options = {}) => new TrackingValidationSentinel(options);
TrackingValidationSentinel.createTrackingValidationSentinel = createTrackingValidationSentinel;

module.exports = {
  TrackingValidationSentinel,
  trackingValidationSentinel: defaultTrackingValidationSentinel,
  createTrackingValidationSentinel
};
