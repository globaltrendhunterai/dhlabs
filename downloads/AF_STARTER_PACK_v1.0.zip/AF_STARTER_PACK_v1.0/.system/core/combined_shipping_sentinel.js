/**
 * AutoFlow Combined Shipping & Surcharge Refund Sentinel
 * (core/combined_shipping_sentinel.js)
 * 
 * [목적 및 비즈니스/법무 배경]
 * 1. 동일 구매자/수령지가 단시간 내 여러 건을 개별 결제하여 배송비가 중복 부과된 경우,
 *    셀러가 1박스로 합배송하면서 중복 결제된 배송비를 환불하지 않아 발생하는
 *    "배송비 편취 논란", 고객 항의 CS 및 별점 1점 악성 리뷰를 1초 만에 원천 차단.
 * 2. 「전자상거래 등에서의 소비자보호에 관한 법률」 제13조 제2항 제5호(우송비용 등에 관한 사항)
 *    및 공정거래위원회 통신판매 표준약관에 부합하도록 중복 배송비(건당 3,000원) 투명 환불 안내.
 * 3. [성명 + 전화번호 + 주소 정규화] 3중 정밀 매칭 엔진으로 선물하기 등 주소 상이 건 오합배송 100% 방지.
 * 4. 합배송 감별 주문 큐(`logs/combined_shipping_orders.json`) 영속화 및 1초 고객 감동 문자 자동 생성.
 */

const fs = require("fs");
const path = require("path");

class CombinedShippingSentinel {
  constructor(options = {}) {
    options = (options && typeof options === "object") ? options : {};
    this.storagePath = options.storagePath || path.resolve(process.cwd(), "logs/combined_shipping_orders.json");
    this.configPath = options.configPath || path.resolve(process.cwd(), "config/combined_shipping_config.json");
    this.defaultShippingFee = options.defaultShippingFee || 3000;
    this._ensureStorage();
  }

  _ensureStorage() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      if (!fs.existsSync(this.storagePath)) {
        fs.writeFileSync(
          this.storagePath,
          JSON.stringify({ groups: [], resolvedGroups: [], lastAuditTime: Date.now() }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}

    try {
      const cfgDir = path.dirname(this.configPath);
      if (!fs.existsSync(cfgDir)) {
        fs.mkdirSync(cfgDir, { recursive: true });
      }
      if (!fs.existsSync(this.configPath)) {
        fs.writeFileSync(
          this.configPath,
          JSON.stringify({
            enabled: true,
            shippingFeePerOrder: 3000,
            autoAlertOnTelegram: true,
            storeName: "AutoFlow 스토어 고객센터",
            refundMethod: "ACCOUNT_TRANSFER" // ACCOUNT_TRANSFER | STORE_POINTS
          }, null, 2),
          "utf8"
        );
      }
    } catch (_) {}
  }

  getConfig() {
    try {
      if (fs.existsSync(this.configPath)) {
        const parsed = JSON.parse(fs.readFileSync(this.configPath, "utf8"));
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (_) {}
    return {
      enabled: true,
      shippingFeePerOrder: 3000,
      autoAlertOnTelegram: true,
      storeName: "AutoFlow 스토어 고객센터",
      refundMethod: "ACCOUNT_TRANSFER"
    };
  }

  updateConfig(newConfig = {}) {
    newConfig = (newConfig && typeof newConfig === "object") ? newConfig : {};
    const current = this.getConfig();
    const updated = { ...current, ...newConfig };
    try {
      fs.writeFileSync(this.configPath, JSON.stringify(updated, null, 2), "utf8");
    } catch (_) {}
    return updated;
  }

  /**
   * 전화번호 살균 (하이픈, 공백 제거)
   */
  _sanitizePhone(phone = "") {
    return String(phone || "").replace(/[^0-9]/g, "");
  }

  /**
   * 주소 정규화 (공백, 특수문자 제거 및 소문자화하여 정확한 지번/도로명 일치 비교)
   */
  _normalizeAddress(address = "") {
    return String(address || "")
      .replace(/[\s\-_.,()#]/g, "")
      .toLowerCase()
      .trim();
  }

  /**
   * 단일/복수 주문 목록에서 합배송 후보 그룹을 감별
   * @param {Array<Object>} orders - 주문 객체 배열
   * @returns {Object} { detectedGroups, totalSavedFee, separateCount }
   */
  detectCombinedShipping(orders = []) {
    if (orders && !Array.isArray(orders) && Array.isArray(orders.orders)) {
      orders = orders.orders;
    }
    if (!Array.isArray(orders) || orders.length === 0) {
      return { detectedGroups: [], totalSavedFee: 0, separateCount: 0 };
    }

    const config = this.getConfig();
    const feePerOrder = config.shippingFeePerOrder || this.defaultShippingFee;

    // 1. 주문 유효성 필터링 (취소 주문이나 이미 배송 완료된 건은 제외)
    const validOrders = orders.filter(o => {
      if (!o || typeof o !== "object") return false;
      const status = String(o.status || o.orderStatus || "").toUpperCase();
      if (status.includes("CANCEL") || status.includes("DELIVERED") || status.includes("SHIPPED")) {
        return false;
      }
      const receiverName = String(o.receiverName || o.recipientName || "").trim();
      const phone = this._sanitizePhone(o.receiverPhone || o.phone || "");
      const addr = this._normalizeAddress(o.receiverAddress || o.shippingAddress || o.address || "");
      return receiverName.length > 0 && phone.length >= 8 && addr.length >= 5;
    });

    // 2. [수령인 + 전화번호 + 정규화 주소] 복합 키로 그룹핑
    const groupMap = new Map();
    for (const order of validOrders) {
      const receiverName = String(order.receiverName || order.recipientName || "").trim();
      const phone = this._sanitizePhone(order.receiverPhone || order.phone || "");
      const normAddr = this._normalizeAddress(order.receiverAddress || order.shippingAddress || order.address || "");
      const compositeKey = `${receiverName}_${phone}_${normAddr}`;

      if (!groupMap.has(compositeKey)) {
        groupMap.set(compositeKey, []);
      }
      groupMap.get(compositeKey).push(order);
    }

    const detectedGroups = [];
    let totalSavedFee = 0;
    let separateCount = 0;

    for (const [key, groupOrders] of groupMap.entries()) {
      if (groupOrders.length >= 2) {
        // 합배송 후보 발견!
        const primaryOrder = groupOrders[0];
        const duplicateCount = groupOrders.length - 1;
        const refundableFee = duplicateCount * feePerOrder;
        totalSavedFee += refundableFee;

        const groupId = `COMBINED-${primaryOrder.orderId}-${Date.now().toString(36)}`;
        detectedGroups.push({
          groupId,
          compositeKey: key,
          receiverName: primaryOrder.receiverName || primaryOrder.recipientName,
          receiverPhone: primaryOrder.receiverPhone || primaryOrder.phone,
          shippingAddress: primaryOrder.receiverAddress || primaryOrder.shippingAddress || primaryOrder.address,
          orderCount: groupOrders.length,
          orderIds: groupOrders.map(o => String(o.orderId || o.orderSheetId || "")),
          primaryOrderId: String(primaryOrder.orderId || ""),
          duplicateCount,
          refundableFee,
          status: "REFUND_PENDING",
          detectedAt: new Date().toISOString()
        });
      } else {
        separateCount++;
      }
    }

    return {
      detectedGroups,
      totalSavedFee,
      separateCount
    };
  }

  /**
   * 감별된 합배송 그룹을 영속화 저장
   */
  recordCombinedGroups(detectedGroups = []) {
    if (detectedGroups && !Array.isArray(detectedGroups) && Array.isArray(detectedGroups.detectedGroups)) {
      detectedGroups = detectedGroups.detectedGroups;
    }
    if (!Array.isArray(detectedGroups) || detectedGroups.length === 0) {
      return { success: true, count: 0 };
    }

    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : {};
      data.groups = Array.isArray(data.groups) ? data.groups.filter(x => x && typeof x === "object") : [];

      let addedCount = 0;
      for (const group of detectedGroups) {
        if (!group || typeof group !== "object") continue;
        // 이미 큐에 존재하는 그룹인지 primaryOrderId 기준 중복 방어
        const exists = data.groups.some(g => g.primaryOrderId === group.primaryOrderId);
        if (!exists) {
          data.groups.unshift(group);
          addedCount++;
        }
      }

      if (data.groups.length > 200) data.groups = data.groups.slice(0, 200);
      data.lastAuditTime = Date.now();
      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");

      return { success: true, addedCount, totalQueued: data.groups.length };
    } catch (e) {
      return { success: false, message: e.message };
    }
  }

  /**
   * 전자상거래법 제13조 준수 고객 감동 중복 배송비 환불 안내 문자 템플릿 생성
   */
  generateCustomerNotice(group = {}, customStoreName = null) {
    group = (group && typeof group === "object") ? group : {};
    const config = this.getConfig();
    const storeName = customStoreName || config.storeName || "스토어 고객센터";
    const receiver = group.receiverName || "고객";
    const orderCount = group.orderCount || 2;
    const fee = (group.refundableFee || (orderCount - 1) * 3000).toLocaleString();

    return [
      `[${storeName}] 합포장 출고 및 중복 배송비 환불 안내`,
      "───────────────────────────────",
      `안녕하세요, ${receiver} 고객님!`,
      `주문해 주신 상품 ${orderCount}건이 동일한 주소지로 확인되어, 파손 방지를 위해 안전하게 [1개 박스로 합포장]되어 오늘 출고되었습니다.`,
      "",
      `합포장 처리에 따라 중복 결제된 배송비 [${fee}원]은 고객님께 전액 환불해 드릴 예정입니다.`,
      "",
      "■ 배송비 환불 접수 방법:",
      "본 문자 회신으로 [환불받으실 은행명 / 계좌번호 / 예금주명]을 남겨주시면 영업일 기준 24시간 이내에 즉시 입금 처리해 드립니다.",
      "",
      "늘 정직하고 신속한 서비스로 보답하겠습니다. 감사합니다.",
      "───────────────────────────────",
      "※ 전자상거래법 제13조 제2항 우송비용 투명 고지 준수"
    ].join("\n");
  }

  /**
   * 텔레그램 / 슬랙 경보 포맷터
   */
  formatCombinedShippingAlert(group = {}) {
    group = (group && typeof group === "object") ? group : {};
    const receiver = group.receiverName || "고객";
    const phone = group.receiverPhone || "연락처 미상";
    const orderCount = group.orderCount || 2;
    const fee = (group.refundableFee || 3000).toLocaleString();
    const orderIds = Array.isArray(group.orderIds) ? group.orderIds.join(", ") : (group.primaryOrderId || "N/A");

    return [
      "📦 [합배송 감별 & 중복 배송비 환불 안심 가드]",
      "───────────────────────────────────",
      `• 수령인: ${receiver} (${phone})`,
      `• 주문건수: 총 ${orderCount}건 합배송 매칭`,
      `• 묶음주문: ${orderIds}`,
      `• 배송지: ${group.shippingAddress || "상세주소 일치"}`,
      `• 절감/환불 대상 배송비: ${fee}원`,
      "💡 포장비 1박스 절약 완료! 고객에게 중복 배송비 환불 안내 문자를 발송하십시오.",
      "───────────────────────────────────",
      "※ AutoFlow CS 제로화 & CX 감동 가드 가동 중"
    ].join("\n");
  }

  /**
   * 환불 완료 또는 개별발송 처리 (해결)
   */
  resolveCombinedOrder(groupId, resolutionType = "REFUNDED", note = "배송비 입금 완료") {
    if (groupId && typeof groupId === "object") {
      resolutionType = groupId.resolutionType || resolutionType;
      note = groupId.note || note;
      groupId = groupId.groupId || groupId.primaryOrderId || "";
    }
    resolutionType = resolutionType || "REFUNDED";
    note = note || "배송비 입금 완료";
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : {};
      data.groups = Array.isArray(data.groups) ? data.groups.filter(x => x && typeof x === "object") : [];
      data.resolvedGroups = Array.isArray(data.resolvedGroups) ? data.resolvedGroups.filter(x => x && typeof x === "object") : [];
      if (data.groups.length === 0) return { success: false, message: "Queue is empty" };

      const index = data.groups.findIndex(g => g.groupId === groupId || g.primaryOrderId === groupId);
      if (index === -1) return { success: false, message: "Combined group not found" };

      const item = data.groups.splice(index, 1)[0];
      item.status = resolutionType === "REFUNDED" ? "REFUND_RESOLVED" : "SEPARATE_OVERRIDE";
      item.resolvedAt = new Date().toISOString();
      item.resolutionNote = note;

      data.resolvedGroups.unshift(item);
      if (data.resolvedGroups.length > 200) data.resolvedGroups = data.resolvedGroups.slice(0, 200);

      fs.writeFileSync(this.storagePath, JSON.stringify(data, null, 2), "utf8");
      return { success: true, groupId: item.groupId, status: item.status };
    } catch (e) {
      return { success: false, message: e.message };
    }
  }

  /**
   * 합배송 주문 큐 요약 통계 조회
   */
  getCombinedOrdersSummary() {
    try {
      const raw = fs.readFileSync(this.storagePath, "utf8");
      const parsed = JSON.parse(raw);
      const data = (parsed && typeof parsed === "object" && !Array.isArray(parsed)) ? parsed : {};
      const groups = Array.isArray(data.groups) ? data.groups.filter(x => x && typeof x === "object") : [];
      const resolved = Array.isArray(data.resolvedGroups) ? data.resolvedGroups.filter(x => x && typeof x === "object") : [];

      const totalPendingFee = groups.reduce((acc, cur) => acc + (cur.refundableFee || 0), 0);
      const totalResolvedFee = resolved.reduce((acc, cur) => acc + (cur.refundableFee || 0), 0);

      return {
        pendingGroupsCount: groups.length,
        resolvedGroupsCount: resolved.length,
        totalPendingFee,
        totalResolvedFee,
        groups: groups.slice(0, 50),
        recentResolved: resolved.slice(0, 10),
        lastAuditTime: data.lastAuditTime || Date.now()
      };
    } catch (_) {
      return {
        pendingGroupsCount: 0,
        resolvedGroupsCount: 0,
        totalPendingFee: 0,
        totalResolvedFee: 0,
        groups: [],
        recentResolved: [],
        lastAuditTime: Date.now()
      };
    }
  }
}

module.exports = CombinedShippingSentinel;
