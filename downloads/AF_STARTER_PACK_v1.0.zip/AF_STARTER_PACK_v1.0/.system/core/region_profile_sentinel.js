/**
 * core/region_profile_sentinel.js
 * 
 * AutoFlow Multi-Region & Platform Profile Sentinel (Pure Node.js)
 * 
 * [목적]
 * 1. 국가(REGION) 및 플랫폼(PLATFORM) 프로필 분리 엔진.
 *    - KR: 대한민국 이커머스 (COUPANG, SMARTSTORE, 국세청 홈택스, 알림톡)
 *    - GLOBAL: 북미/글로벌 이커머스 (GUMROAD, SHOPIFY, STRIPE, 디스코드)
 * 2. 프로필별 활성 워크플로우, 기능 태그, 통화(Currency), 알림 채널 분리 관리.
 * 3. 런타임 동적 전환(switchProfile) 및 영속 파일(config/region_profile.json) 100% 동기화.
 */

const fs = require("fs");
const path = require("path");

const VALID_REGIONS = ["KR", "GLOBAL"];

const PLATFORM_REGION_MAP = {
  COUPANG: "KR",
  SMARTSTORE: "KR",
  GUMROAD: "GLOBAL",
  SHOPIFY: "GLOBAL",
  STRIPE: "GLOBAL"
};

const PROFILE_CATALOG = {
  "KR:COUPANG": {
    region: "KR",
    platform: "COUPANG",
    displayName: "대한민국 쿠팡 WING (로켓배송 / 오픈마켓)",
    currency: "KRW",
    defaultChannels: ["TELEGRAM", "SLACK", "ALIMTALK"],
    activeFeatures: [
      "wing_order_sync",
      "out_of_stock_defense",
      "island_surcharge",
      "pccc_validation",
      "hometax_crosscheck",
      "item_winner_guard",
      "review_booster",
      "order_dedup"
    ],
    primaryWorkflow: "AF-KR-COUPANG-ORDER-NOTIFICATION",
    description: "쿠팡 WING 오픈마켓 24시간 실시간 주문 수집 및 자동 배송처리 에어백 가동"
  },
  "KR:SMARTSTORE": {
    region: "KR",
    platform: "SMARTSTORE",
    displayName: "대한민국 네이버 스마트스토어 (커머스 API)",
    currency: "KRW",
    defaultChannels: ["TELEGRAM", "SLACK", "ALIMTALK"],
    activeFeatures: [
      "smartstore_sync",
      "dispatch_deadline",
      "pii_masking",
      "settlement_recon",
      "hometax_crosscheck",
      "fraud_detection"
    ],
    primaryWorkflow: "AF-KR-SMARTSTORE-ORDER-NOTIFICATION",
    description: "네이버 커머스솔루션 API 기반 주문 수집 및 자동 송장 등록 파이프라인"
  },
  "GLOBAL:GUMROAD": {
    region: "GLOBAL",
    platform: "GUMROAD",
    displayName: "Global Gumroad Digital Products & Creator MoR",
    currency: "USD",
    defaultChannels: ["DISCORD", "SLACK", "EMAIL_WEBHOOK"],
    activeFeatures: [
      "gumroad_ping_webhook",
      "license_key_generation",
      "device_hwid_binding",
      "fraud_detection",
      "pii_masking",
      "circuit_alert"
    ],
    primaryWorkflow: "AF-GLOBAL-GUMROAD-LICENSE-ISSUER",
    description: "글로벌 Gumroad 판매 즉시 Ping 수신 및 1:1 HWID 기기 종속 영구 라이선스 자동 발급"
  },
  "GLOBAL:SHOPIFY": {
    region: "GLOBAL",
    platform: "SHOPIFY",
    displayName: "Global Shopify Direct-to-Consumer Store",
    currency: "USD",
    defaultChannels: ["DISCORD", "SLACK", "EMAIL_WEBHOOK"],
    activeFeatures: [
      "shopify_order_webhook",
      "customs_declared_value",
      "tracking_validation",
      "pii_masking",
      "order_dedup"
    ],
    primaryWorkflow: "AF-GLOBAL-SHOPIFY-FULFILLMENT",
    description: "북미/글로벌 Shopify 스토어 실시간 주문 동기화 및 글로벌 배송 송장 자동 연동"
  },
  "GLOBAL:STRIPE": {
    region: "GLOBAL",
    platform: "STRIPE",
    displayName: "Global Stripe SaaS Subscription & Billing",
    currency: "USD",
    defaultChannels: ["DISCORD", "SLACK"],
    activeFeatures: [
      "stripe_invoice_payment",
      "license_seat_recharge",
      "settlement_recon",
      "fraud_detection"
    ],
    primaryWorkflow: "AF-GLOBAL-STRIPE-RECON",
    description: "Stripe 글로벌 정기 결제 웹훅 연동 및 구독 라이선스 연장 자동화"
  }
};

class RegionProfileSentinel {
  constructor(options = {}) {
    this.appRoot = options.appRoot || path.resolve(__dirname, "..");
    this.configPath = options.configPath || path.join(this.appRoot, "config", "region_profile.json");
    this.activeProfile = {
      region: "KR",
      platform: "COUPANG",
      updatedAt: new Date().toISOString()
    };
    this.loadProfile();
  }

  /**
   * 설정 파일에서 프로필 로드. 파일 부재 시 기본값으로 안전 초기화.
   */
  loadProfile() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf8");
        const parsed = JSON.parse(raw);
        if (this.isValidProfile(parsed.region, parsed.platform)) {
          this.activeProfile = {
            region: parsed.region,
            platform: parsed.platform,
            updatedAt: parsed.updatedAt || new Date().toISOString()
          };
          return this.activeProfile;
        }
      }
    } catch (err) {
      console.warn("[RegionProfileSentinel] Failed to parse config, using default KR/COUPANG:", err.message);
    }

    // 기본 프로필 영속화
    this.activeProfile = {
      region: "KR",
      platform: "COUPANG",
      updatedAt: new Date().toISOString()
    };
    this.saveProfile();
    return this.activeProfile;
  }

  /**
   * 프로필 유효성 검증
   * @param {string} region
   * @param {string} platform
   * @returns {boolean}
   */
  isValidProfile(region, platform) {
    if (!region || !platform) return false;
    const r = String(region).toUpperCase().trim();
    const p = String(platform).toUpperCase().trim();
    const key = `${r}:${p}`;
    return Boolean(PROFILE_CATALOG[key]);
  }

  /**
   * 현재 활성 프로필 설정 파일로 영속화
   */
  saveProfile() {
    try {
      const dir = path.dirname(this.configPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(this.configPath, JSON.stringify(this.activeProfile, null, 2), "utf8");
      return true;
    } catch (err) {
      console.error("[RegionProfileSentinel] Failed to save config:", err.message);
      return false;
    }
  }

  /**
   * 국가 및 플랫폼 프로필 런타임 동적 전환
   * @param {string} rawRegion
   * @param {string} rawPlatform
   * @returns {object} 전환된 프로필 메타데이터
   */
  switchProfile(rawRegion, rawPlatform) {
    const region = String(rawRegion || "").toUpperCase().trim();
    const platform = String(rawPlatform || "").toUpperCase().trim();

    if (!this.isValidProfile(region, platform)) {
      throw new Error(`[RegionProfileSentinel] 유효하지 않은 프로필 조합입니다: REGION=${rawRegion}, PLATFORM=${rawPlatform}`);
    }

    this.activeProfile = {
      region: region,
      platform: platform,
      updatedAt: new Date().toISOString()
    };

    this.saveProfile();
    return this.getActiveProfile();
  }

  /**
   * 현재 활성 프로필 및 메타데이터 반환
   * @returns {object}
   */
  getActiveProfile() {
    const key = `${this.activeProfile.region}:${this.activeProfile.platform}`;
    const meta = PROFILE_CATALOG[key] || PROFILE_CATALOG["KR:COUPANG"];
    return {
      status: "SUCCESS",
      region: this.activeProfile.region,
      platform: this.activeProfile.platform,
      updatedAt: this.activeProfile.updatedAt,
      metadata: meta
    };
  }

  /**
   * 지원하는 모든 국가/플랫폼 프로필 목록 반환
   * @returns {object}
   */
  getAllowedProfiles() {
    return {
      regions: VALID_REGIONS,
      platforms: Object.keys(PLATFORM_REGION_MAP),
      catalog: PROFILE_CATALOG
    };
  }

  /**
   * 특정 프로필 키의 상세 메타데이터 반환
   * @param {string} region
   * @param {string} platform
   * @returns {object|null}
   */
  getProfileMetadata(region, platform) {
    const r = String(region || "").toUpperCase().trim();
    const p = String(platform || "").toUpperCase().trim();
    const key = `${r}:${p}`;
    return PROFILE_CATALOG[key] || null;
  }

  /**
   * 활성 프로필에 부합하는 워크플로우 필터링
   * @param {Array<{id: string, name: string}>} workflowList
   * @returns {Array}
   */
  filterWorkflowsForActiveProfile(workflowList = []) {
    if (!Array.isArray(workflowList)) return [];
    const activeRegion = this.activeProfile.region;
    const activePlatform = this.activeProfile.platform;

    return workflowList.filter(wf => {
      const name = (wf.name || "").toUpperCase();
      const id = (wf.id || "").toUpperCase();
      const target = `${id}_${name}`;

      // 지역 매칭 (KR vs GLOBAL)
      if (activeRegion === "KR") {
        if (target.includes("GLOBAL") || target.includes("GUMROAD") || target.includes("SHOPIFY") || target.includes("STRIPE")) {
          return false;
        }
        if (activePlatform === "COUPANG" && target.includes("SMARTSTORE")) {
          return false;
        }
        if (activePlatform === "SMARTSTORE" && target.includes("COUPANG")) {
          return false;
        }
        return true;
      } else {
        // GLOBAL
        if (target.includes("KR-") || target.includes("COUPANG") || target.includes("SMARTSTORE")) {
          return false;
        }
        return true;
      }
    });
  }
}

const defaultRegionProfileSentinel = new RegionProfileSentinel();

module.exports = {
  RegionProfileSentinel,
  regionProfileSentinel: defaultRegionProfileSentinel,
  VALID_REGIONS,
  PLATFORM_REGION_MAP,
  PROFILE_CATALOG
};
