#!/bin/bash
# AutoFlow Engine - 30일 무료 체험 온디맨드 시동 런처 (macOS)
xattr -dr com.apple.quarantine "$(cd "$(dirname "$0")" && pwd)" 2>/dev/null || true
cd "$(dirname "$0")"
chmod +x ./bin/node ../bin/node 2>/dev/null || true

echo "============================================================"
echo "[AutoFlow 자가치유 엔진 30일 무료 체험 온디맨드 시동]"
echo "============================================================"

# Resolve node executable (./bin/node -> ../bin/node -> /opt/homebrew/bin/node -> /usr/local/bin/node -> command -v node)
NODE_BIN=""
for candidate in "./bin/node" "../bin/node" "/opt/homebrew/bin/node" "/usr/local/bin/node"; do
  if [ -x "$candidate" ] && "$candidate" -v >/dev/null 2>&1; then
    NODE_BIN="$candidate"
    break
  fi
done
if [ -z "$NODE_BIN" ] && command -v node >/dev/null 2>&1; then
  CANDIDATE_CMD="$(command -v node)"
  if "$CANDIDATE_CMD" -v >/dev/null 2>&1; then
    NODE_BIN="$CANDIDATE_CMD"
  fi
fi

if [ -z "$NODE_BIN" ]; then
  echo "[ERROR] Node.js 런타임을 찾을 수 없습니다. Node.js를 설치해 주세요 (https://nodejs.org)."
  if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
    read -p "엔터(Enter) 키를 누르면 창이 닫힙니다..."
  fi
  exit 1
fi

SCRIPT_FILE="activate_trial_cli.js"
if [ ! -f "$SCRIPT_FILE" ] && [ -f "./core/activate_trial_cli.js" ]; then
  SCRIPT_FILE="./core/activate_trial_cli.js"
fi

"$NODE_BIN" "$SCRIPT_FILE" 30 "KMONG_FREE_TRIAL" "30일 무료 체험 엔진 시동" --lang=ko

echo ""
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "창을 닫으려면 엔터(Enter) 키를 누르세요..."
fi
