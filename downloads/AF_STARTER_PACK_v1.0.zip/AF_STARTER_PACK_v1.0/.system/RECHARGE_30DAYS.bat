@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title AutoFlow 자가치유 엔진 30일 기간 연장 충전팩
cd /d "%~dp0"

echo ============================================================
echo ⚡ AutoFlow 자가치유 엔진 30일 기간 연장 충전팩 적용
echo ============================================================

set "NODE_BIN="
if exist "%~dp0bin\node.exe" (
    set "NODE_BIN=%~dp0bin\node.exe"
) else if exist "%~dp0..\bin\node.exe" (
    set "NODE_BIN=%~dp0..\bin\node.exe"
) else (
    where node >nul 2>nul
    if !errorlevel! equ 0 set "NODE_BIN=node"
)

if "!NODE_BIN!"=="" (
    echo [*] Windows 포터블 Node.js 런타임^(node-v20.18.0-win-x64^) 무인 자동 다운로드 중...
    if not exist "%~dp0bin" mkdir "%~dp0bin"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference = 'SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $zipUrl = 'https://nodejs.org/dist/v20.18.0/node-v20.18.0-win-x64.zip'; $zipPath = Join-Path '%~dp0' 'bin\node_win_x64.zip'; $extractDir = Join-Path '%~dp0' 'bin\node_extract_tmp'; Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing; if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }; Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force; Copy-Item -Path (Join-Path $extractDir 'node-v20.18.0-win-x64\node.exe') -Destination (Join-Path '%~dp0' 'bin\node.exe') -Force; Remove-Item $zipPath -Force -ErrorAction SilentlyContinue; Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue"
    if exist "%~dp0bin\node.exe" (
        set "NODE_BIN=%~dp0bin\node.exe"
    ) else (
        echo ❌ Node.js 런타임 자동 다운로드에 실패했습니다. 네트워크 연결을 확인해 주세요.
        pause
        exit /b 1
    )
)

set "SCRIPT_FILE=%~dp0recharge_cli.js"
if not exist "!SCRIPT_FILE!" (
    if exist "%~dp0core\recharge_cli.js" set "SCRIPT_FILE=%~dp0core\recharge_cli.js"
)

"!NODE_BIN!" "!SCRIPT_FILE!" 30 "TOPUP_30DAYS_WIN_%RANDOM%" "검로드 30일 충전팩 더블클릭 적용"

echo.
pause
