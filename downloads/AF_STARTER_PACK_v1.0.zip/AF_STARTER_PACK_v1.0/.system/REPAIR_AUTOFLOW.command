#!/usr/bin/env bash
# ==============================================================================
#   AutoFlow 24시간 무인 자가치유 실행기 (macOS 지능형 자가치유)
#   사내 영구 무인 자동화 엔진 환경 소독 및 자가 복구 스크립트
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
xattr -dr com.apple.quarantine "$SCRIPT_DIR" 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/autoflow_rust 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/bin/node "$SCRIPT_DIR"/bin/*.sh "$SCRIPT_DIR"/scripts/*.sh 2>/dev/null || true

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

echo -e "${CYAN}==============================================================================${NC}"
echo -e "${CYAN}${BOLD}  AutoFlow 24시간 무인 자가치유 실행기 (macOS 지능형 자가치유)${NC}"
echo -e "${CYAN}  사내 영구 무인 자동화 엔진 환경 소독 및 자가 복구를 진행합니다.${NC}"
echo -e "${CYAN}==============================================================================${NC}"
echo ""

# 2. 번들 Node 런타임 탐색 (Strict Zero Python 규격)
NODE_BIN=""
if [ -f "./bin/node" ] && [ -x "./bin/node" ]; then
    NODE_BIN="./bin/node"
elif [ -f "../bin/node" ] && [ -x "../bin/node" ]; then
    NODE_BIN="../bin/node"
elif [ -x "/opt/homebrew/bin/node" ]; then
    NODE_BIN="/opt/homebrew/bin/node"
elif [ -x "/usr/local/bin/node" ]; then
    NODE_BIN="/usr/local/bin/node"
elif command -v node >/dev/null 2>&1; then
    NODE_BIN="$(command -v node)"
fi

if [ -z "$NODE_BIN" ]; then
    echo -e "${RED}[오류] 번들 Node.js 런타임을 찾을 수 없습니다.${NC}"
    echo -e "${YELLOW}터미널에서 'brew install node' 또는 https://nodejs.org 에서 Node.js를 설치해 주세요.${NC}"
    if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
        read -p "창을 닫으려면 엔터(Enter) 키를 누르세요..."
    fi
    exit 1
fi

# 3. 엔트리 파일 탐색
ENTRY_FILE=""
if [ -f "./bin/n8n-entry.js" ]; then
    ENTRY_FILE="./bin/n8n-entry.js"
elif [ -f "./n8n-entry.js" ]; then
    ENTRY_FILE="./n8n-entry.js"
elif [ -f "../bin/n8n-entry.js" ]; then
    ENTRY_FILE="../bin/n8n-entry.js"
fi

if [ -z "$ENTRY_FILE" ]; then
    echo -e "${RED}[오류] AutoFlow 엔진 진입점(n8n-entry.js)을 찾을 수 없습니다.${NC}"
    if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
        read -p "창을 닫으려면 엔터(Enter) 키를 누르세요..."
    fi
    exit 1
fi

mkdir -p logs

echo -e "${YELLOW}[Step 1] 기존 엔진 상태 진단 및 유령 프로세스 환경 소독...${NC}"

# 기존 프로세스 정리 (logs/engine.pid 또는 유령 프로세스)
if [ -f "logs/engine.pid" ]; then
    OLD_PID=$(cat "logs/engine.pid" 2>/dev/null | tr -d '[:space:]')
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        echo -e "   - 기존 엔진 프로세스(PID: ${OLD_PID}) 종료 및 소독 중..."
        kill -15 "$OLD_PID" 2>/dev/null || kill -9 "$OLD_PID" 2>/dev/null
        sleep 1
    fi
    rm -f "logs/engine.pid" 2>/dev/null || true
fi

# 로컬 SQLite 락 파일 소독
if [ -d "$HOME/.n8n" ]; then
    find "$HOME/.n8n" -name "*.lock" -delete 2>/dev/null || true
    echo -e "   ${GREEN}[OK] n8n 로컬 락 파일 소독 완료${NC}"
fi

# 4. 번들 엔진 백그라운드 안전 기동
echo ""
echo -e "${YELLOW}[Step 2] 번들 Node 엔진 백그라운드 안전 기동...${NC}"
rm -f "logs/active_port.txt" 2>/dev/null || true

nohup "$NODE_BIN" "$ENTRY_FILE" > logs/autoflow_engine.log 2>&1 &
ENGINE_PID=$!
echo "$ENGINE_PID" > logs/engine.pid 2>/dev/null || true
echo -e "   - 백그라운드 엔진 기동됨 (PID: ${ENGINE_PID})"

# 5. 능동 헬스체크 및 동적 포트 감지 루프 (최대 15초)
echo ""
echo -e "${YELLOW}[Step 3] 엔진 부팅 완료 및 동적 바인딩 포트 감지 (능동 헬스체크)...${NC}"
BOOTED=0
ACTUAL_PORT=5678

for i in {1..30}; do
    if [ -f "logs/active_port.txt" ]; then
        READ_PORT=$(cat "logs/active_port.txt" 2>/dev/null | tr -d '[:space:]')
        if [ -n "$READ_PORT" ]; then
            ACTUAL_PORT=$READ_PORT
            HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 1 "http://127.0.0.1:${ACTUAL_PORT}/setup_wizard.html" || true)
            if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "401" ] || [ "$HTTP_CODE" = "302" ]; then
                BOOTED=1
                echo -e "   ${GREEN}[OK] AutoFlow 엔진 응답 확인 완료 (포트 ${ACTUAL_PORT}, HTTP ${HTTP_CODE})${NC}"
                break
            fi
        fi
    fi
    HTTP_CODE_5678=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 1 "http://127.0.0.1:5678/setup_wizard.html" || true)
    if [ "$HTTP_CODE_5678" = "200" ] || [ "$HTTP_CODE_5678" = "401" ] || [ "$HTTP_CODE_5678" = "302" ]; then
        BOOTED=1
        ACTUAL_PORT=5678
        echo -e "   ${GREEN}[OK] AutoFlow 엔진 응답 확인 완료 (포트 5678, HTTP ${HTTP_CODE_5678})${NC}"
        break
    fi
    sleep 0.5
done

TARGET_URL="http://localhost:${ACTUAL_PORT}/setup_wizard.html"

# 6. 결과 판정 및 브라우저 오픈 (가짜 성공 EXIT_CODE=0 은폐 차단)
echo ""
echo -e "${YELLOW}[Step 4] 자가치유 복구 결과 검증...${NC}"
if [ $BOOTED -eq 1 ]; then
    echo -e "${GREEN}==============================================================================${NC}"
    echo -e "${GREEN}${BOLD}  [성공] AutoFlow 자동화 엔진 자가치유 복구가 완료되었습니다!${NC}"
    echo -e "  * 복구 대시보드 URL: ${CYAN}${TARGET_URL}${NC}"
    echo -e "  * 활성 포트: ${YELLOW}${ACTUAL_PORT}${NC}"
    echo -e "  * 실패 노드 상태 복원 및 프로세스 소독 완료"
    echo -e "${GREEN}==============================================================================${NC}"
    echo ""
    if [ "${AUTOFLOW_NO_BROWSER:-0}" != "1" ]; then
        open "${TARGET_URL}" 2>/dev/null || true
    fi
    if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
        read -p "창을 닫으려면 엔터(Enter) 키를 누르세요..."
    fi
    exit 0
else
    echo -e "${RED}==============================================================================${NC}"
    echo -e "${RED}${BOLD}  [복구 실패] 엔진 기동에 실패했습니다.${NC}"
    if [ -f "logs/engine.pid" ]; then
        SAVED_PID=$(cat "logs/engine.pid" 2>/dev/null | tr -d '[:space:]')
        if [ -n "$SAVED_PID" ] && ! kill -0 "$SAVED_PID" 2>/dev/null; then
            echo -e "${RED}  * 엔진 프로세스(PID: ${SAVED_PID})가 비정상 종료되었습니다.${NC}"
        fi
    fi
    if [ -f "logs/autoflow_engine.log" ]; then
        echo -e "${YELLOW}  * 최근 엔진 에러 로그 (logs/autoflow_engine.log):${NC}"
        tail -n 20 logs/autoflow_engine.log
    fi
    echo -e "${RED}==============================================================================${NC}"
    echo ""
    if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
        read -p "창을 닫으려면 엔터(Enter) 키를 누르세요..."
    fi
    exit 1
fi
