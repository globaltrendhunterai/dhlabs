#!/bin/bash
# AutoFlow Engine - 30 Days Top-Up Quick Launcher (macOS)
xattr -dr com.apple.quarantine "$(cd "$(dirname "$0")" && pwd)" 2>/dev/null || true
cd "$(dirname "$0")"
chmod +x ./bin/node ../bin/node 2>/dev/null || true

echo "============================================================"
echo "⚡ AutoFlow 자가치유 엔진 30일 기간 연장 충전팩 적용"
echo "============================================================"

# Resolve node executable (./bin/node -> ../bin/node -> /opt/homebrew/bin/node -> /usr/local/bin/node -> command -v node)
NODE_BIN=""
for candidate in "./bin/node" "../bin/node" "/opt/homebrew/bin/node" "/usr/local/bin/node"; do
  if [ -x "$candidate" ] && "$candidate" -v >/dev/null 2>&1; then
    NODE_BIN="$candidate"
    break
  fi
done
if [ -z "$NODE_BIN" ] && command -v node >/dev/null 2>&1; then
  CANDIDATE_CMD="$(command -v node)"
  if "$CANDIDATE_CMD" -v >/dev/null 2>&1; then
    NODE_BIN="$CANDIDATE_CMD"
  fi
fi

if [ -z "$NODE_BIN" ]; then
  echo "❌ Node.js 런타임을 찾을 수 없습니다. Node.js를 설치해 주세요."
  if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
    read -p "엔터를 누르면 창이 닫힙니다..."
  fi
  exit 1
fi

SCRIPT_FILE="recharge_cli.js"
if [ ! -f "$SCRIPT_FILE" ] && [ -f "./core/recharge_cli.js" ]; then
  SCRIPT_FILE="./core/recharge_cli.js"
fi

"$NODE_BIN" "$SCRIPT_FILE" 30 "TOPUP_30DAYS_$(date +%s)" "검로드 30일 충전팩 더블클릭 적용"

echo ""
if [ "${AUTOFLOW_NONINTERACTIVE:-0}" != "1" ]; then
  read -p "창을 닫으려면 엔터(Enter) 키를 누르세요..."
fi
