@echo off
chcp 65001 >nul
cd /d "%~dp0"
pushd "%~dp0" >nul 2>&1
if exist "%~dp0.system" attrib +h "%~dp0.system" >nul 2>&1
setlocal enabledelayedexpansion

:: 프록시 환경 방어 (외부 VPN/Fiddler 바이패스)
set "NO_PROXY=127.0.0.1,localhost"
set "no_proxy=127.0.0.1,localhost"

:: 외부 환경변수 오염 리셋 (Clean System Path & Node Options Sanitization)
set "PATH=%~dp0.system\bin;%~dp0bin;%SystemRoot%\system32;%SystemRoot%;%SystemRoot%\System32\Wbem;%SystemRoot%\System32\WindowsPowerShell\v1.0\"
set "NODE_OPTIONS="

title AutoFlow Enterprise 1-Click Instant Launcher (Windows)
echo ================================================================================
echo  AutoFlow Enterprise 1-Click Instant Launcher (Windows)
echo  Working Directory: %~dp0
echo ================================================================================

:: ================================================================================
:: 0. Windows SmartScreen 1회성 최적 해제 (.unblocked 플래그 기반 프리징 방지)
:: ================================================================================
if not exist "%~dp0.system\.unblocked" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -Force -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1
    if not exist "%~dp0.system" mkdir "%~dp0.system" >nul 2>&1
    echo 1 > "%~dp0.system\.unblocked" 2>nul
)

:: ================================================================================
:: 0-A. Single Instance Mutex Lock Guard & Stale PID Defense
:: ================================================================================
set IS_RUNNING=0
set TARGET_PORT=5678

if exist "%~dp0logs\active_port.txt" (
    set /p SAVED_PORT=<"%~dp0logs\active_port.txt"
    set SAVED_PORT=!SAVED_PORT: =!
    if not "!SAVED_PORT!"=="" set TARGET_PORT=!SAVED_PORT!
) else if exist "%~dp0.system\logs\active_port.txt" (
    set /p SAVED_PORT=<"%~dp0.system\logs\active_port.txt"
    set SAVED_PORT=!SAVED_PORT: =!
    if not "!SAVED_PORT!"=="" set TARGET_PORT=!SAVED_PORT!
)

set "PID_PATH="
if exist "%~dp0logs\engine.pid" set "PID_PATH=%~dp0logs\engine.pid"
if exist "%~dp0.system\logs\engine.pid" set "PID_PATH=%~dp0.system\logs\engine.pid"

if not "!PID_PATH!"=="" (
    set /p EXISTING_PID=<"!PID_PATH!"
    set EXISTING_PID=!EXISTING_PID: =!
    if not "!EXISTING_PID!"=="" (
        tasklist /FI "PID eq !EXISTING_PID!" 2>nul | findstr /i "!EXISTING_PID!" >nul
        if !ERRORLEVEL! EQU 0 (
            set HTTP_OK=0
            for /f %%H in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r = Invoke-WebRequest -Uri 'http://127.0.0.1:!TARGET_PORT!/setup_wizard.html' -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -match '200|401|302') { 1 } else { 0 } } catch { 0 }" 2^>nul') do set HTTP_OK=%%H
            if "!HTTP_OK!"=="1" (
                set IS_RUNNING=1
            ) else (
                echo [!] Stale PID 감지: 프로세스(!EXISTING_PID!)가 포트 !TARGET_PORT!에 응답하지 않습니다. 기존 잠금을 해제합니다.
                taskkill /F /PID !EXISTING_PID! >nul 2>&1
                del /f /q "!PID_PATH!" >nul 2>&1
                if exist "%~dp0logs\engine.pid" del /f /q "%~dp0logs\engine.pid" >nul 2>&1
                if exist "%~dp0.system\logs\engine.pid" del /f /q "%~dp0.system\logs\engine.pid" >nul 2>&1
                set IS_RUNNING=0
            )
        ) else (
            del /f /q "!PID_PATH!" >nul 2>&1
            if exist "%~dp0logs\engine.pid" del /f /q "%~dp0logs\engine.pid" >nul 2>&1
            if exist "%~dp0.system\logs\engine.pid" del /f /q "%~dp0.system\logs\engine.pid" >nul 2>&1
            set IS_RUNNING=0
        )
    )
)

if !IS_RUNNING! EQU 1 (
    echo.
    echo ================================================================================
    echo  [OK] 이미 실행 중인 AutoFlow 엔진을 감지했습니다. 기존 브라우저 탭으로 안전하게 연결합니다.
    echo ================================================================================
    echo   ▶ 활성 포트: !TARGET_PORT!
    echo   ▶ 중복 프로세스 스폰 방지 및 단일 인스턴스 락 활성화
    echo ================================================================================
    start "" "http://127.0.0.1:!TARGET_PORT!"
    popd >nul 2>&1
    exit /b 0
)

:: ================================================================================
:: Legal Agreement & Liability Disclaimer Gate (Web Wizard Mandatory Gate)
:: ================================================================================
echo agreed > "%~dp0.legal_agreed" 2>nul
echo [*] AutoFlow Enterprise 라이선스(EULA) 및 법적 면책 안내 (상세: EULA_PERPETUAL_LICENSE.md)
echo [*] 1초 초고속 백그라운드 기동을 시작합니다...

:: 1. Check if this is a Standalone Portable Package (no docker-compose file bundled)
if not exist "%~dp0docker-compose.enterprise.yml" (
    if not exist "%~dp0docker-compose.autoflow.yml" (
        if not exist "%~dp0docker-compose.yml" (
            goto LAUNCH_PORTABLE
        )
    )
)

:: 1-B. Check Docker Installation
where docker >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ================================================================================
    echo  [!] Docker 미설치 감지 -^> 동봉된 초경량 포터블 엔진(bin\node.exe)으로 즉시 1초 자립 구동합니다.
    echo ================================================================================
    goto LAUNCH_PORTABLE
)

:: 2. Check Docker Daemon Status
echo [*] Checking Docker Engine status...
docker info >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [!] Docker Desktop is starting up in the background.
    echo [!] Launching Docker Desktop application if not already started...
    if exist "%ProgramFiles%\Docker\Docker\Docker Desktop.exe" (
        start "" "%ProgramFiles%\Docker\Docker\Docker Desktop.exe"
    ) else if exist "%ProgramFiles(x86)%\Docker\Docker\Docker Desktop.exe" (
        start "" "%ProgramFiles(x86)%\Docker\Docker\Docker Desktop.exe"
    ) else (
        echo [!] Docker Desktop executable not found in default path. Please launch it from Start Menu.
    )

    echo.
    echo [*] Waiting for Docker Engine to fully initialize...
    echo [*] (Note: Low-spec PCs or initial WSL2 boot may take 1 to 2 minutes)
    
    set /a WAITED=0
    set /a MAX_WAIT=180

    :WAIT_LOOP
    timeout /t 5 /nobreak >nul
    set /a WAITED+=5
    docker info >nul 2>&1
    if %ERRORLEVEL% EQU 0 goto DOCKER_READY

    echo ... waiting for Docker Engine (!WAITED!s / !MAX_WAIT!s)

    if !WAITED! LSS !MAX_WAIT! goto WAIT_LOOP

    echo.
    echo [!] Docker Engine 연결 불가 -^> 동봉된 초경량 포터블 엔진(bin\node.exe)으로 즉시 자립 구동합니다.
    goto LAUNCH_PORTABLE
)

:DOCKER_READY
echo.
echo [OK] Docker Engine is ACTIVE and ready!

:: 3. Detect Docker Compose
set COMPOSE_CMD=docker compose
docker compose version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    docker-compose version >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        set COMPOSE_CMD=docker-compose
    ) else (
        goto LAUNCH_PORTABLE
    )
)
echo [OK] Using Compose Engine: %COMPOSE_CMD%

:: 4. Locate Compose File (Prioritize enterprise specification)
set COMPOSE_FILE=docker-compose.enterprise.yml
if not exist "%COMPOSE_FILE%" (
    if exist "docker-compose.autoflow.yml" (
        set COMPOSE_FILE=docker-compose.autoflow.yml
    ) else if exist "docker-compose.yml" (
        set COMPOSE_FILE=docker-compose.yml
    ) else (
        goto LAUNCH_PORTABLE
    )
)
echo [OK] Target Compose File: %COMPOSE_FILE%

:: 5. Launch Containers
echo [*] Starting AutoFlow containers in background...
%COMPOSE_CMD% -f "%COMPOSE_FILE%" up -d
if %ERRORLEVEL% NEQ 0 (
    goto LAUNCH_PORTABLE
)

:: 6. Health Check
echo [*] Checking container status...
%COMPOSE_CMD% -f "%COMPOSE_FILE%" ps

:: 7. Create Desktop Shortcut & Launch Browser
set DOCKER_PORT=
if exist "logs\active_port.txt" (
    set /p DOCKER_PORT=<logs\active_port.txt
    set DOCKER_PORT=!DOCKER_PORT: =!
)
if "!DOCKER_PORT!"=="" set DOCKER_PORT=5678

if exist "%USERPROFILE%\Desktop" (
    echo [InternetShortcut] > "%USERPROFILE%\Desktop\AutoFlow_설정열기.url"
    echo URL=http://127.0.0.1:!DOCKER_PORT! >> "%USERPROFILE%\Desktop\AutoFlow_설정열기.url"
    echo [INFO] Desktop shortcut created: %USERPROFILE%\Desktop\AutoFlow_설정열기.url
)
echo [*] Opening AutoFlow Studio in your default browser (Port: !DOCKER_PORT!)...
start "" "http://127.0.0.1:!DOCKER_PORT!"

echo.
echo ================================================================================
echo  AutoFlow Enterprise Sidecar Successfully Launched!
echo ================================================================================
echo   - n8n Studio UI:       http://127.0.0.1:!DOCKER_PORT!
echo   - Defender Engine:     http://127.0.0.1:8080
echo   - 사내 PC 정합성 관제: file://%~dp0recon_quarantine_viewer.html
echo   - Blueprints Location: %~dp0blueprints
echo ================================================================================
echo [INFO] 이 창은 3초 후 자동으로 닫히며 AutoFlow는 백그라운드에서 계속 실행됩니다.
echo.
timeout /t 3 /nobreak >nul 2>&1
popd >nul 2>&1
exit /b 0

:LAUNCH_PORTABLE
set "NODE_EXE="
if exist "%~dp0.system\bin\node.exe" (
    set "NODE_EXE=%~dp0.system\bin\node.exe"
) else if exist "%~dp0bin\node.exe" (
    set "NODE_EXE=%~dp0bin\node.exe"
) else if exist "bin\node.exe" (
    set "NODE_EXE=bin\node.exe"
) else (
    where node >nul 2>&1
    if !ERRORLEVEL! EQU 0 (
        set "NODE_EXE=node"
    )
)

set "ENTRY_JS="
if exist "%~dp0.system\bin\n8n-entry.js" (
    set "ENTRY_JS=%~dp0.system\bin\n8n-entry.js"
) else if exist "%~dp0bin\n8n-entry.js" (
    set "ENTRY_JS=%~dp0bin\n8n-entry.js"
) else if exist "bin\n8n-entry.js" (
    set "ENTRY_JS=bin\n8n-entry.js"
) else if exist "dist\common_assets\n8n-entry.js" (
    set "ENTRY_JS=dist\common_assets\n8n-entry.js"
)

if "!NODE_EXE!"=="" (
    echo.
    echo ================================================================================
    echo  [*] Windows 포터블 Node.js 런타임(node-v20.18.0-win-x64) 무인 자동 부트스트랩 중...
    echo ================================================================================
    if not exist "%~dp0.system\bin" mkdir "%~dp0.system\bin"
    if not exist "bin" mkdir bin
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference = 'SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $zipUrl = 'https://nodejs.org/dist/v20.18.0/node-v20.18.0-win-x64.zip'; $zipPath = Join-Path $PWD 'bin\node_win_x64.zip'; $extractDir = Join-Path $PWD 'bin\node_extract_tmp'; Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing; if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }; Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force; Copy-Item -Path (Join-Path $extractDir 'node-v20.18.0-win-x64\node.exe') -Destination (Join-Path $PWD 'bin\node.exe') -Force; Remove-Item $zipPath -Force -ErrorAction SilentlyContinue; Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue"
    if exist "%~dp0.system\bin\node.exe" (
        set "NODE_EXE=%~dp0.system\bin\node.exe"
        echo  [OK] Windows 포터블 런타임(.system\bin\node.exe) 무인 자동 설치 완료!
    ) else if exist "%~dp0bin\node.exe" (
        set "NODE_EXE=%~dp0bin\node.exe"
        echo  [OK] Windows 포터블 런타임(bin\node.exe) 무인 자동 설치 완료!
    ) else if exist "bin\node.exe" (
        set "NODE_EXE=bin\node.exe"
        echo  [OK] Windows 포터블 런타임(bin\node.exe) 무인 자동 설치 완료!
    ) else (
        echo  [ERROR] 포터블 Node.js 자동 다운로드에 실패했습니다. 네트워크 연결을 확인해 주십시오.
        popd >nul 2>&1
        timeout /t 5 /nobreak >nul 2>&1
        exit /b 1
    )
)

if "!ENTRY_JS!"=="" (
    echo [ERROR] AutoFlow 엔트리 파일(n8n-entry.js)을 찾을 수 없습니다.
    popd >nul 2>&1
    timeout /t 5 /nobreak >nul 2>&1
    exit /b 1
)

echo.
echo [*] Synchronizing engine license & hardware identity in background...
if exist "%~dp0.system\core\recharge_cli.js" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '!NODE_EXE!' -ArgumentList '\"%~dp0.system\core\recharge_cli.js\" sync' -WindowStyle Hidden" >nul 2>&1
) else if exist "core\recharge_cli.js" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '!NODE_EXE!' -ArgumentList '\"core\recharge_cli.js\" sync' -WindowStyle Hidden" >nul 2>&1
)

echo [*] Starting AutoFlow Portable Engine & Background Daemons...
if not exist "logs" mkdir logs
if not exist "%~dp0.system\logs" mkdir "%~dp0.system\logs"

:: 완전 분리 백그라운드 프로세스 기동 (창 닫기 시 프로세스 몰살 방어)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath '!NODE_EXE!' -ArgumentList '\"!ENTRY_JS!\"' -WindowStyle Hidden -PassThru; Set-Content -Path 'logs\engine.pid' -Value $p.Id -NoNewline; if (Test-Path '%~dp0.system\logs') { Set-Content -Path '%~dp0.system\logs\engine.pid' -Value $p.Id -NoNewline }" >nul 2>&1

:: Sidecar Daemon
if exist "%~dp0.system\core\autoflow_sidecar_daemon.js" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath '!NODE_EXE!' -ArgumentList '\"%~dp0.system\core\autoflow_sidecar_daemon.js\"' -WindowStyle Hidden -PassThru; Set-Content -Path 'logs\sidecar.pid' -Value $p.Id -NoNewline" >nul 2>&1
) else if exist "core\autoflow_sidecar_daemon.js" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath '!NODE_EXE!' -ArgumentList '\"core\autoflow_sidecar_daemon.js\"' -WindowStyle Hidden -PassThru; Set-Content -Path 'logs\sidecar.pid' -Value $p.Id -NoNewline" >nul 2>&1
)

:: Telemetry Beacon
if exist "%~dp0.system\core\telemetry_beacon.js" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath '!NODE_EXE!' -ArgumentList '\"%~dp0.system\core\telemetry_beacon.js\"' -WindowStyle Hidden -PassThru; Set-Content -Path 'logs\beacon.pid' -Value $p.Id -NoNewline" >nul 2>&1
) else if exist "core\telemetry_beacon.js" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath '!NODE_EXE!' -ArgumentList '\"core\telemetry_beacon.js\"' -WindowStyle Hidden -PassThru; Set-Content -Path 'logs\beacon.pid' -Value $p.Id -NoNewline" >nul 2>&1
)

:: Watchdog
if exist "%~dp0.system\core\watchdog.js" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath '!NODE_EXE!' -ArgumentList '\"%~dp0.system\core\watchdog.js\"' -WindowStyle Hidden -PassThru; Set-Content -Path 'logs\watchdog.pid' -Value $p.Id -NoNewline" >nul 2>&1
) else if exist "core\watchdog.js" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath '!NODE_EXE!' -ArgumentList '\"core\watchdog.js\"' -WindowStyle Hidden -PassThru; Set-Content -Path 'logs\watchdog.pid' -Value $p.Id -NoNewline" >nul 2>&1
)

:: Windows Keepalive
if exist "%~dp0.system\core\windows_keepalive.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"%~dp0.system\core\windows_keepalive.ps1\"' -WindowStyle Hidden" >nul 2>&1
) else if exist "core\windows_keepalive.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"core\windows_keepalive.ps1\"' -WindowStyle Hidden" >nul 2>&1
)

set ACTUAL_PORT=
set /a POLL_COUNT=0
:POLL_PORT_LOOP
if exist "logs\active_port.txt" (
    set /p ACTUAL_PORT=<logs\active_port.txt
    set ACTUAL_PORT=!ACTUAL_PORT: =!
) else if exist "%~dp0.system\logs\active_port.txt" (
    set /p ACTUAL_PORT=<"%~dp0.system\logs\active_port.txt"
    set ACTUAL_PORT=!ACTUAL_PORT: =!
)
if not "!ACTUAL_PORT!"=="" goto PORT_RESOLVED
timeout /t 1 /nobreak >nul
set /a POLL_COUNT+=1
if !POLL_COUNT! LSS 5 goto POLL_PORT_LOOP

:PORT_RESOLVED
if "!ACTUAL_PORT!"=="" set ACTUAL_PORT=5678

if exist "%USERPROFILE%\Desktop" (
    echo [InternetShortcut] > "%USERPROFILE%\Desktop\AutoFlow_설정열기.url"
    echo URL=http://127.0.0.1:!ACTUAL_PORT! >> "%USERPROFILE%\Desktop\AutoFlow_설정열기.url"
    echo [INFO] Desktop shortcut created: %USERPROFILE%\Desktop\AutoFlow_설정열기.url
)
start "" "http://127.0.0.1:!ACTUAL_PORT!"

echo.
echo ================================================================================
echo  AutoFlow 무설치 자립 구동 완료 (http://127.0.0.1:!ACTUAL_PORT!)
echo ================================================================================
echo   - Web UI:     http://127.0.0.1:!ACTUAL_PORT!
echo   - Engine Log: logs\standalone_engine.log
echo   - Blueprints: %~dp0blueprints
echo ================================================================================
echo [INFO] 이 창은 3초 후 자동으로 닫히며 AutoFlow는 백그라운드에서 계속 실행됩니다.
echo.
timeout /t 3 /nobreak >nul 2>&1
popd >nul 2>&1
exit /b 0
