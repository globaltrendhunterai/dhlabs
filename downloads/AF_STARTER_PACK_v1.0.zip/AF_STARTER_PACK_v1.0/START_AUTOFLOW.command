#!/usr/bin/env bash
# ==============================================================================
#   AutoFlow Production Workflow Suite - 1-Click Smart Launcher (macOS)
#   사내 영구 무인 자동화 엔진 - 1초 더블클릭 런처
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
xattr -dr com.apple.quarantine "$SCRIPT_DIR" 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/*.command 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/autoflow_rust 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/bin/node "$SCRIPT_DIR"/bin/*.sh "$SCRIPT_DIR"/scripts/*.sh 2>/dev/null || true

# 2. 포터블 Node.js 번들 우선 및 흔한 환경 경로(Homebrew, NVM, FNM 등) 자동 확장
export PATH="./bin:./.internal_vault/bin:/opt/homebrew/bin:/usr/local/bin:$HOME/.nvm/versions/node/$(ls "$HOME/.nvm/versions/node" 2>/dev/null | tail -1)/bin:$HOME/.fnm/current/bin:$PATH"

# 2-B. 스타터팩 Rust 네이티브 게이트웨이 기동 분기
if [ -f "./.system/autoflow_rust" ] || [ -f "./autoflow_rust" ]; then
    RUST_BIN="./.system/autoflow_rust"
    if [ ! -f "$RUST_BIN" ]; then RUST_BIN="./autoflow_rust"; fi
    echo "[INFO] 최초 실행을 감지했습니다. AutoFlow 고성능 런타임 게이트웨이를 기동합니다..."
    export PORT="${PORT:-18080}"
    RUST_PORT="$PORT"
    mkdir -p logs
    nohup env PORT="$RUST_PORT" "$RUST_BIN" > logs/rust_boot.log 2>&1 &
    RUST_PID=$!
    echo "$RUST_PID" > .rust_gateway.pid

    # 백그라운드 엔진 기동 실패 가드 (가짜 성공 EXIT_CODE=0 은폐 차단)
    sleep 0.5
    if ! kill -0 "$RUST_PID" 2>/dev/null; then
        echo -e "\033[0;31m[오류] AutoFlow 런타임 게이트웨이 기동에 실패했습니다 (PID: $RUST_PID 종료됨).\033[0m"
        if [ -f "logs/rust_boot.log" ]; then
            echo -e "\033[1;33m[부팅 로그 (rust_boot.log)]:\033[0m"
            cat logs/rust_boot.log
        fi
        echo ""
        read -p "엔터를 누르면 종료합니다..."
        exit 1
    fi

    if [ "${AUTOFLOW_NO_BROWSER:-0}" != "1" ]; then
        open "http://localhost:${RUST_PORT}/setup_wizard.html" 2>/dev/null || true
    fi
    exit 0
fi

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

TARGET_PORT=${N8N_PORT:-5678}
TARGET_URL="http://localhost:${TARGET_PORT}/setup_wizard.html"

# [방어벽 3차] 비상용 CONFIG_HERE.txt 기본 생성
if [ ! -f "CONFIG_HERE.txt" ]; then
    cat << 'EOF' > CONFIG_HERE.txt
# AutoFlow 초간편 메모장 설정 (브라우저 미오픈 시 사용)
# 아래 항목에 발급받으신 키를 입력하고 저장하신 후 런처를 다시 실행하시면 자동 적용됩니다.
AUTORUN_LICENSE_SN=
MARKET_API_KEY=
MARKET_SECRET_KEY=
EOF
fi

clear
echo -e "${CYAN}==============================================================================${NC}"
echo -e "${CYAN}${BOLD}   AutoFlow Production Workflow Suite - 1초 더블클릭 런처 (macOS)${NC}"
echo -e "${CYAN}   사내 영구 무인 자동화 엔진을 안전하게 기동합니다.${NC}"
echo -e "${CYAN}==============================================================================${NC}"
echo ""

# 3. n8n 기동 점검 및 백그라운드 실행
IS_RUNNING=0
if [ -n "$SKU_ID" ]; then
    export N8N_USER_FOLDER="$HOME/.autoflow/instances/$SKU_ID"
    mkdir -p "$N8N_USER_FOLDER"
    echo -e "${CYAN}[SANDBOX] SKU '${SKU_ID}' 격리 인스턴스: ${N8N_USER_FOLDER}${NC}"
fi

# [Sector 4 엄격 판정] 단순 포트 점유(lsof)가 아닌 실제 AutoFlow 엔진 프로세스 생존 검사
if [ -f "logs/engine.pid" ]; then
    SAVED_PID=$(cat "logs/engine.pid" 2>/dev/null | tr -d '[:space:]')
    if [ -n "$SAVED_PID" ] && kill -0 "$SAVED_PID" 2>/dev/null; then
        IS_RUNNING=1
    fi
fi

if [ $IS_RUNNING -eq 0 ]; then
    CHECK_PORT=${TARGET_PORT}
    if [ -f "logs/active_port.txt" ]; then
        SAVED_PORT=$(cat "logs/active_port.txt" 2>/dev/null | tr -d '[:space:]')
        if [ -n "$SAVED_PORT" ]; then
            CHECK_PORT=$SAVED_PORT
        fi
    fi
    AF_RESP=$(curl -s --connect-timeout 1 "http://localhost:${CHECK_PORT}/api/active-workflow" 2>/dev/null || true)
    if echo "$AF_RESP" | grep -q "workflow_id\|active_tier\|success\|sku"; then
        IS_RUNNING=1
    fi
fi

if [ $IS_RUNNING -eq 1 ]; then
    echo -e "${GREEN}[OK] AutoFlow 엔진 인스턴스가 이미 가동 중입니다.${NC}"
else
    echo -e "${YELLOW}[INFO] AutoFlow 자동화 엔진을 백그라운드에서 기동합니다...${NC}"
    mkdir -p logs
    rm -f logs/active_port.txt 2>/dev/null || true
    if [ -f "./bin/node" ] && [ -f "./bin/n8n-entry.js" ]; then
        echo -e "${CYAN}[INFO] 번들링된 포터블 Node.js로 무인 실행합니다...${NC}"
        nohup ./bin/node ./bin/n8n-entry.js > logs/engine_boot.log 2>&1 &
        echo "$!" > logs/engine.pid
    elif command -v node >/dev/null 2>&1 && [ -f "./bin/n8n-entry.js" ]; then
        echo -e "${CYAN}[INFO] 시스템 Node.js로 무인 실행합니다...${NC}"
        nohup node ./bin/n8n-entry.js > logs/engine_boot.log 2>&1 &
        echo "$!" > logs/engine.pid
    elif command -v n8n >/dev/null 2>&1; then
        nohup n8n start > logs/engine_boot.log 2>&1 &
        echo "$!" > logs/engine.pid
    elif command -v npx >/dev/null 2>&1; then
        echo -e "${CYAN}[INFO] npx를 통해 최신 공식 n8n을 무설치 실행합니다...${NC}"
        nohup npx --yes n8n start > logs/engine_boot.log 2>&1 &
        echo "$!" > logs/engine.pid
    else
        echo -e "${RED}[오류] 시스템에 Node.js 또는 n8n이 감지되지 않았습니다.${NC}"
        echo -e "${YELLOW}터미널에서 'brew install node' 또는 https://nodejs.org 에서 Node.js를 설치해주세요.${NC}"
        read -p "엔터를 누르면 종료합니다..."
        exit 1
    fi

    # [콜드 스타트 방어 & 동적 바인딩 포트 감지 루프 (최대 10초)]
    echo -e "${CYAN}[INFO] 엔진 응답 및 동적 바인딩 포트를 감지하고 있습니다 (능동 헬스체크)...${NC}"
    for i in {1..20}; do
        if [ -f "logs/active_port.txt" ]; then
            BOUND_PORT=$(cat "logs/active_port.txt" 2>/dev/null | tr -d '[:space:]')
            if [ -n "$BOUND_PORT" ]; then
                HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 1 "http://localhost:${BOUND_PORT}/setup_wizard.html" || true)
                if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "401" ] || [ "$HTTP_CODE" = "302" ]; then
                    IS_RUNNING=1
                    echo -e "${GREEN}[OK] AutoFlow 엔진 응답 확인 완료 (포트 ${BOUND_PORT}, HTTP ${HTTP_CODE}).${NC}"
                    break
                fi
            fi
        fi
        sleep 0.5
    done

    # 백그라운드 엔진 기동 실패 가드 (브라우저 오픈 차단 및 에러 출력)
    if [ $IS_RUNNING -eq 0 ]; then
        echo ""
        echo -e "${RED}[오류] AutoFlow 백그라운드 엔진 기동에 실패했거나 응답이 없습니다.${NC}"
        if [ -f "logs/engine.pid" ]; then
            SAVED_PID=$(cat "logs/engine.pid" 2>/dev/null | tr -d '[:space:]')
            if [ -n "$SAVED_PID" ] && ! kill -0 "$SAVED_PID" 2>/dev/null; then
                echo -e "${RED}[진단] 엔진 프로세스(PID: $SAVED_PID)가 비정상 종료되었습니다.${NC}"
            fi
        fi
        if [ -f "logs/engine_boot.log" ]; then
            echo -e "${YELLOW}[부팅 에러 로그 (logs/engine_boot.log)]:${NC}"
            tail -n 20 logs/engine_boot.log
        fi
        echo ""
        read -p "엔터를 누르면 종료합니다..."
        exit 1
    fi
fi

# [Sector 4 동적 포트 반영] logs/active_port.txt 확인
ACTUAL_PORT=${TARGET_PORT}
if [ -f "logs/active_port.txt" ]; then
    READ_PORT=$(cat "logs/active_port.txt" 2>/dev/null | tr -d '[:space:]')
    if [ -n "$READ_PORT" ]; then
        ACTUAL_PORT=$READ_PORT
    fi
fi
TARGET_URL="http://localhost:${ACTUAL_PORT}/setup_wizard.html"

# [방어벽 2차] 주소 클립보드 자동복사
echo -n "${TARGET_URL}" | pbcopy 2>/dev/null || true
echo -e "${GREEN}[안내] 설정 주소가 클립보드에 자동 복사되었습니다 (Cmd+V로 붙여넣기 가능).${NC}"

# [방어벽 1차] OS 네이티브 App Mode 단독 창 오픈 시도
OPENED=0
if [ -d "/Applications/Google Chrome.app" ]; then
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --app="${TARGET_URL}" >/dev/null 2>&1 &
    OPENED=1
elif [ -d "/Applications/Microsoft Edge.app" ]; then
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" --app="${TARGET_URL}" >/dev/null 2>&1 &
    OPENED=1
fi

if [ $OPENED -eq 0 ]; then
    open "${TARGET_URL}" || open "http://localhost:${ACTUAL_PORT}"
fi

echo ""
echo -e "${GREEN}==============================================================================${NC}"
echo -e "${GREEN}${BOLD}  AutoFlow 엔진이 정상적으로 연결되었습니다!${NC}"
echo -e "  * 브라우저 URL: ${CYAN}${TARGET_URL}${NC}"
echo -e "  * 활성 포트: ${YELLOW}${ACTUAL_PORT}${NC}"
echo -e "  * 워크플로우 적용 방법:"
echo -e "    1. n8n 화면 우측 상단 'Add workflow' 또는 'Import from File' 클릭"
echo -e "    2. 본 패키지 내의 ${YELLOW}.n8n.json${NC} 파일을 캔버스 위로 드래그 앤 드롭"
echo -e "    3. 우측 상단 ${GREEN}'Active'${NC} 토글 스위치를 켜면 즉시 실무 가동 완료!"
echo -e "  * 상세 매뉴얼: ${CYAN}3MIN_QUICKSTART_GUIDE.md${NC} 참고"
echo -e "${GREEN}==============================================================================${NC}"
echo -e "${YELLOW}※ 본 창을 닫아도 백그라운드에서 자동화 엔진이 계속 동작합니다.${NC}"
echo ""
