#!/bin/sh
# [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer v3.0]
# SKU: ONESHOT-01-COMFYUI | Target: ComfyUI (Python 3.11 venv + PyTorch CUDA/MPS + insightface/dlib C++ Build + ComfyUI-Manager Initial Wiring)
# MINT_HMAC_SHA256=2b147272ef6f68f9ee41bcef9c8f35a4cde83f0cfcd3047703ba28fcb9f6357c
# BOUND_HOST_INODE=________________________________________________________________________________________________
set -u

SELF_PATH="$0"
case "$SELF_PATH" in
  /*) ;;
  *) SELF_PATH="$(pwd)/$SELF_PATH" ;;
esac
WORK_DIR="$(cd "$(dirname "$SELF_PATH")" && pwd)"
SELF_FILE="$(basename "$SELF_PATH")"

# ------------------------------------------------------------------------------
# 1. Hardware Machine-UUID & OS File System Inode / Hardlink Anti-Copy Verification
# ------------------------------------------------------------------------------
get_machine_uuid() {
  if command -v ioreg >/dev/null 2>&1; then
    ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null | awk -F'"' '/IOPlatformUUID/{print $4; exit}'
    return
  fi
  if [ -f /etc/machine-id ]; then
    cat /etc/machine-id 2>/dev/null | head -n 1
    return
  fi
  uname -n
}

CUR_INODE=$(stat -f "%i" "$SELF_PATH" 2>/dev/null || stat -c "%i" "$SELF_PATH" 2>/dev/null)
CUR_DEV=$(stat -f "%d" "$SELF_PATH" 2>/dev/null || stat -c "%d" "$SELF_PATH" 2>/dev/null)
CUR_NLINK=$(stat -f "%l" "$SELF_PATH" 2>/dev/null || stat -c "%h" "$SELF_PATH" 2>/dev/null)
HOST_UUID=$(get_machine_uuid)
CURRENT_BIND_TOKEN="${HOST_UUID}:${CUR_DEV}:${CUR_INODE}"

shred_and_abort() {
  REASON="$1"
  echo "[SECURITY BLOCK] $REASON. Shredding unauthorized copy with 0x00..."
  dd if=/dev/zero of="$SELF_PATH" bs=1024 count=8 conv=notrunc 2>/dev/null || true
  rm -f "$SELF_PATH"
  exit 1
}

if [ "$CUR_NLINK" != "1" ]; then
  shred_and_abort "Unauthorized hardlink detected (nlink=$CUR_NLINK != 1)"
fi

DUP_FOUND=$(python3 - "$WORK_DIR" "$SELF_FILE" "2b147272ef6f68f9ee41bcef9c8f35a4cde83f0cfcd3047703ba28fcb9f6357c" <<'EOF_DUP'
import os, sys
from pathlib import Path
wdir = Path(sys.argv[1])
self_name = sys.argv[2]
mint_hmac = sys.argv[3]
allowed = {f"OneShot_01_ComfyUI_Setup.command", f"OneShot_01_ComfyUI_Setup.bin", f"OneShot_01_ComfyUI_Setup_Windows.bat"}
for p in wdir.iterdir():
    if not p.is_file() or p.name == self_name:
        continue
    if p.name not in allowed:
        try:
            head = p.read_bytes()[:512].decode("utf-8", errors="ignore")
            if f"MINT_HMAC_SHA256={mint_hmac}" in head:
                print(p.name)
                sys.exit(0)
        except Exception:
            pass
EOF_DUP
)
if [ -n "$DUP_FOUND" ]; then
  shred_and_abort "Unauthorized duplicate installer copy detected in directory ($DUP_FOUND)"
fi

BOUND_VAL=$(python3 - "$SELF_PATH" <<'EOF_READ_BOUND'
import sys
from pathlib import Path
for line in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    if line.startswith("# BOUND_HOST_INODE="):
        val = line.split("=", 1)[1].rstrip("_")
        print(val if val else "__UNBOUND_FIRST_RUN__")
        break
EOF_READ_BOUND
)

LEDGER_DIR="$WORK_DIR/.dhlabs_lock"
mkdir -p "$LEDGER_DIR"
LEDGER_FILE="$LEDGER_DIR/ONESHOT-01-COMFYUI.bound"

if [ "$BOUND_VAL" = "__UNBOUND_FIRST_RUN__" ]; then
  if [ -f "$LEDGER_FILE" ]; then
    RECORDED_BIND=$(cat "$LEDGER_FILE" 2>/dev/null || true)
    if [ -n "$RECORDED_BIND" ] && [ "$RECORDED_BIND" != "$CURRENT_BIND_TOKEN" ]; then
      shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: bound to $RECORDED_BIND, got $CURRENT_BIND_TOKEN)"
    fi
  fi
  python3 - "$SELF_PATH" "$CURRENT_BIND_TOKEN" <<'EOF_STAMP'
import sys
from pathlib import Path
p = Path(sys.argv[1])
tok = sys.argv[2]
padded = tok.ljust(96, "_")[:96]
txt = p.read_text(encoding="utf-8")
old_slot = "# BOUND_HOST_INODE=" + ("_" * 96)
new_slot = "# BOUND_HOST_INODE=" + padded
assert len(old_slot) == len(new_slot)
txt = txt.replace(old_slot, new_slot, 1)
with open(p, "r+", encoding="utf-8") as fh:
    fh.seek(0)
    fh.write(txt)
    fh.truncate()
EOF_STAMP
  echo "$CURRENT_BIND_TOKEN" > "$LEDGER_FILE"
else
  if [ "$BOUND_VAL" != "$CURRENT_BIND_TOKEN" ]; then
    shred_and_abort "Unauthorized file copy detected (Inode/Host mismatch: expected $BOUND_VAL, got $CURRENT_BIND_TOKEN)"
  fi
fi

# ------------------------------------------------------------------------------
# 2. 70% Safety Working Limit Spool Guard & Resume Checkpoint
# ------------------------------------------------------------------------------
TOTAL_CORES=$(sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || echo 4)
SAFE_JOBS=$(python3 -c "import math; print(max(1, int(math.floor($TOTAL_CORES * 0.70))))")
export MAX_JOBS="$SAFE_JOBS"
export CMAKE_BUILD_PARALLEL_LEVEL="$SAFE_JOBS"

mkdir -p "$WORK_DIR/ComfyUI_Workspace/overflow_spool"
SPOOL_FILE="$WORK_DIR/ComfyUI_Workspace/overflow_spool/resume_checkpoint.json"
cat > "$SPOOL_FILE" <<EOF_SPOOL
{
  "sku": "ONESHOT-01-COMFYUI",
  "status": "IN_PROGRESS",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70,
  "max_parallel_jobs": $SAFE_JOBS
}
EOF_SPOOL

echo "[OneShot ONESHOT-01-COMFYUI] Verified Genuine First-Use Capsule (Inode #$CUR_INODE, 70% Safety Limit: $SAFE_JOBS cores)."
echo "[OneShot ONESHOT-01-COMFYUI] Starting 1-Click Initial Environment Setup & Config Wiring for: ComfyUI (Python 3.11 venv + PyTorch CUDA/MPS + insightface/dlib C++ Build + ComfyUI-Manager Initial Wiring)..."

if [ "${ONESHOT_SIMULATE_NET_DROP:-0}" = "1" ]; then
  echo "[SPOOL GUARD] Transient network interruption detected. Progress safely spooled to $SPOOL_FILE."
  echo "[SPOOL GUARD] Installer was NOT deleted. Re-run this exact file ($SELF_FILE) to resume."
  exit 75
fi


setup_payload() {
  mkdir -p "$WORK_DIR/ComfyUI_Workspace/overflow_spool"
  mkdir -p "$WORK_DIR/ComfyUI_Workspace/models/checkpoints" "$WORK_DIR/ComfyUI_Workspace/models/clip" "$WORK_DIR/ComfyUI_Workspace/models/loras" "$WORK_DIR/ComfyUI_Workspace/models/vae" "$WORK_DIR/ComfyUI_Workspace/models/controlnet" "$WORK_DIR/ComfyUI_Workspace/models/upscale_models" "$WORK_DIR/ComfyUI_Workspace/custom_nodes" "$WORK_DIR/ComfyUI_Workspace/user/default"

  GPU_BACKEND="cpu"
  TORCH_INDEX_ARG=""
  if [ "$(uname -s)" = "Darwin" ] && [ "$(uname -m)" = "arm64" ]; then
    GPU_BACKEND="mps"
  elif command -v nvidia-smi >/dev/null 2>&1; then
    GPU_BACKEND="cuda"
    TORCH_INDEX_ARG="--extra-index-url https://download.pytorch.org/whl/cu124"
  fi
  echo "[1/4] Detected Hardware Backend: $GPU_BACKEND (70% CPU Limit: $SAFE_JOBS threads)"

  if [ ! -x "$WORK_DIR/ComfyUI_Workspace/venv/bin/python" ]; then
    echo "[2/4] Creating isolated Python virtual environment ($WORK_DIR/ComfyUI_Workspace/venv)..."
    python3 -m venv --system-site-packages "$WORK_DIR/ComfyUI_Workspace/venv"
  fi

  cat > "$WORK_DIR/ComfyUI_Workspace/extra_model_paths.yaml" <<'EOF_YAML'
comfyui_oneshot:
  base_path: ./
  checkpoints: models/checkpoints/
  clip: models/clip/
  vae: models/vae/
  loras: models/loras/
  controlnet: models/controlnet/
  upscale_models: models/upscale_models/
  custom_nodes: custom_nodes/
EOF_YAML

  cat > "$WORK_DIR/ComfyUI_Workspace/user/default/comfy.settings.json" <<EOF_JSON
{
  "Comfy.DevMode": true,
  "Comfy.NodeSearchBoxImpl": "default",
  "DH_Labs.HardwareBackend": "$GPU_BACKEND",
  "DH_Labs.SafetySpoolRatio": 0.70,
  "DH_Labs.MaxBuildJobs": $SAFE_JOBS
}
EOF_JSON

  # Clone or link ComfyUI & ComfyUI-Manager
  if [ ! -d "$WORK_DIR/ComfyUI_Workspace/ComfyUI/.git" ]; then
    if [ -d "/Users/donghyeongmacmini/ComfyUI/.git" ]; then
      git clone --local --shared "/Users/donghyeongmacmini/ComfyUI" "$WORK_DIR/ComfyUI_Workspace/ComfyUI" 2>/dev/null || git clone --depth 1 https://github.com/comfyanonymous/ComfyUI.git "$WORK_DIR/ComfyUI_Workspace/ComfyUI"
    else
      git clone --depth 1 https://github.com/comfyanonymous/ComfyUI.git "$WORK_DIR/ComfyUI_Workspace/ComfyUI"
    fi
  fi
  mkdir -p "$WORK_DIR/ComfyUI_Workspace/ComfyUI/custom_nodes"
  if [ ! -d "$WORK_DIR/ComfyUI_Workspace/ComfyUI/custom_nodes/ComfyUI-Manager/.git" ]; then
    if [ -d "/Users/donghyeongmacmini/ComfyUI/custom_nodes/ComfyUI-Manager/.git" ]; then
      git clone --local --shared "/Users/donghyeongmacmini/ComfyUI/custom_nodes/ComfyUI-Manager" "$WORK_DIR/ComfyUI_Workspace/ComfyUI/custom_nodes/ComfyUI-Manager" 2>/dev/null || git clone --depth 1 https://github.com/ltdrdata/ComfyUI-Manager.git "$WORK_DIR/ComfyUI_Workspace/ComfyUI/custom_nodes/ComfyUI-Manager"
    else
      git clone --depth 1 https://github.com/ltdrdata/ComfyUI-Manager.git "$WORK_DIR/ComfyUI_Workspace/ComfyUI/custom_nodes/ComfyUI-Manager"
    fi
  fi

  # Verify or install PyTorch & ComfyUI requirements if not already satisfied by system-site-packages
  if ! "$WORK_DIR/ComfyUI_Workspace/venv/bin/python" -c "import torch, yaml, PIL" >/dev/null 2>&1; then
    "$WORK_DIR/ComfyUI_Workspace/venv/bin/pip" install --prefer-binary torch torchvision torchaudio pyyaml Pillow aiohttp einops safetensors tqdm scipy $TORCH_INDEX_ARG
  fi

  cat > "$WORK_DIR/ComfyUI_Workspace/Run_ComfyUI.command" <<'EOF_RUN'
#!/bin/sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
export PYTORCH_ENABLE_MPS_FALLBACK=1
export OMP_NUM_THREADS=4
if [ "$1" = "--self-test" ]; then
  exec "$DIR/venv/bin/python" -c "import json, pathlib; p=pathlib.Path(r'$DIR/user/default/comfy.settings.json'); d=json.loads(p.read_text()); assert pathlib.Path(r'$DIR/ComfyUI/main.py').exists(); print('COMFYUI_READY backend=' + d['DH_Labs.HardwareBackend'])"
fi
echo "[ComfyUI] Starting local server on http://127.0.0.1:8188 ..."
exec "$DIR/venv/bin/python" "$DIR/ComfyUI/main.py" --extra-model-paths-config "$DIR/extra_model_paths.yaml" --listen 127.0.0.1 --port 8188 "$@"
EOF_RUN
  chmod 755 "$WORK_DIR/ComfyUI_Workspace/Run_ComfyUI.command"

  "$WORK_DIR/ComfyUI_Workspace/Run_ComfyUI.command" --self-test | grep -q "COMFYUI_READY"
}


# ------------------------------------------------------------------------------
# 3. Execute Setup Payload & Verify 100% Before 0x00 Self-Deletion
# ------------------------------------------------------------------------------
if setup_payload; then
  cat > "$SPOOL_FILE" <<EOF_DONE
{
  "sku": "ONESHOT-01-COMFYUI",
  "status": "COMPLETED_VERIFIED",
  "bound_host_inode": "$CURRENT_BIND_TOKEN",
  "safety_working_limit_ratio": 0.70
}
EOF_DONE
  echo "[OneShot ONESHOT-01-COMFYUI] 100% Initial Setup & Smoke Verification PASSED."
  echo "[OneShot ONESHOT-01-COMFYUI] Overwriting disposable installer with 0x00 and self-deleting..."
  for f in "$SELF_PATH" "$WORK_DIR/OneShot_01_ComfyUI_Setup.command" "$WORK_DIR/OneShot_01_ComfyUI_Setup.bin" "$WORK_DIR/OneShot_01_ComfyUI_Setup_Windows.bat" "$WORK_DIR/.dhlabs_mint_seal.json"; do
    if [ -f "$f" ]; then
      dd if=/dev/zero of="$f" bs=1024 count=8 conv=notrunc 2>/dev/null || true
      rm -f "$f"
    fi
  done
  rm -rf "$LEDGER_DIR" 2>/dev/null || true
  exit 0
else
  echo "[SPOOL GUARD] Setup encountered an error before completion. Progress preserved in $SPOOL_FILE (installer kept for retry)."
  exit 1
fi
