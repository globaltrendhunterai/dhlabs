@echo off
REM [DH Labs MacMiniMasterMinter Sealed Disposable Initial-Setup Installer — Windows Launcher]
REM SKU: ONESHOT-01-COMFYUI | MINT_HMAC_SHA256=b0961d19e3031ce73727ffb5cabcf7f999816d5e57611ab4e509f5bca3e713ab
SETLOCAL EnableDelayedExpansion
cd /d "%~dp0"
where bash >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    bash "%~dp0OneShot_01_ComfyUI_Setup.command"
    exit /b %ERRORLEVEL%
)
echo [OneShot ONESHOT-01-COMFYUI] Please ensure Git Bash or WSL + Python 3.10+ is installed, then double-click again.
exit /b 1
